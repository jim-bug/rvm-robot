package codecLib.mp3;

class l {
  int long;
  
  int l;
  
  int c;
  
  int d;
  
  int i;
  
  int f;
  
  int for;
  
  int goto;
  
  int else;
  
  int a;
  
  int int;
  
  int void;
  
  int case;
  
  int do;
  
  int try;
  
  int g;
  
  int k;
  
  int char;
  
  int byte;
  
  int h;
  
  int null;
  
  int j;
  
  int if;
  
  int e;
  
  int new;
  
  int b;
}


/* Location:              /home/jim_bug/rvm-robot/!/codecLib/mp3/l.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */