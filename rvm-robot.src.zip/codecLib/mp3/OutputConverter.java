package codecLib.mp3;

public class OutputConverter {
  public static void convert(byte[] paramArrayOfbyte, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
    for (byte b = 0; b < paramInt3; b++) {
      float f = paramArrayOffloat[paramInt2++];
      int i = (int)f;
      i = (i >= 32767) ? 32767 : ((i <= -32768) ? -32768 : i);
      paramArrayOfbyte[paramInt1 + b * 2] = (byte)(i >> 8);
      paramArrayOfbyte[paramInt1 + b * 2 + 1] = (byte)i;
    } 
  }
  
  public static void convert(byte[] paramArrayOfbyte, int paramInt1, float[] paramArrayOffloat1, int paramInt2, float[] paramArrayOffloat2, int paramInt3, int paramInt4) {
    for (byte b = 0; b < paramInt4; b++) {
      float f = paramArrayOffloat1[paramInt2++];
      int i = (int)f;
      i = (i >= 32767) ? 32767 : ((i <= -32768) ? -32768 : i);
      paramArrayOfbyte[paramInt1 + b * 4] = (byte)(i >> 8);
      paramArrayOfbyte[paramInt1 + b * 4 + 1] = (byte)i;
      f = paramArrayOffloat2[paramInt3++];
      i = (int)f;
      i = (i >= 32767) ? 32767 : ((i <= -32768) ? -32768 : i);
      paramArrayOfbyte[paramInt1 + b * 4 + 2] = (byte)(i >> 8);
      paramArrayOfbyte[paramInt1 + b * 4 + 3] = (byte)i;
    } 
  }
  
  public static void convert(short[] paramArrayOfshort, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
    for (byte b = 0; b < paramInt3; b++) {
      float f = paramArrayOffloat[paramInt2++];
      int i = (int)f;
      i = (i >= 32767) ? 32767 : ((i <= -32768) ? -32768 : i);
      paramArrayOfshort[paramInt1 + b] = (short)i;
    } 
  }
  
  public static void convert(short[] paramArrayOfshort, int paramInt1, float[] paramArrayOffloat1, int paramInt2, float[] paramArrayOffloat2, int paramInt3, int paramInt4) {
    for (byte b = 0; b < paramInt4; b++) {
      float f = paramArrayOffloat1[paramInt2++];
      int i = (int)f;
      i = (i >= 32767) ? 32767 : ((i <= -32768) ? -32768 : i);
      paramArrayOfshort[paramInt1 + 2 * b] = (short)i;
      f = paramArrayOffloat2[paramInt3++];
      i = (int)f;
      i = (i >= 32767) ? 32767 : ((i <= -32768) ? -32768 : i);
      paramArrayOfshort[paramInt1 + 2 * b + 1] = (short)i;
    } 
  }
  
  public static void convert24Bit(byte[] paramArrayOfbyte, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
    float f = 256.0F;
    for (byte b = 0; b < paramInt3; b++) {
      float f1 = paramArrayOffloat[paramInt2++] * f;
      int i = (int)f1;
      i = (i >= 8388607) ? 8388607 : ((i <= -8388608) ? -8388608 : i);
      paramArrayOfbyte[paramInt1 + b * 3] = (byte)(i >> 16);
      paramArrayOfbyte[paramInt1 + b * 3 + 1] = (byte)(i >> 8);
      paramArrayOfbyte[paramInt1 + b * 3 + 2] = (byte)i;
    } 
  }
  
  public static void convert24Bit(byte[] paramArrayOfbyte, int paramInt1, float[] paramArrayOffloat1, int paramInt2, float[] paramArrayOffloat2, int paramInt3, int paramInt4) {
    float f = 256.0F;
    for (byte b = 0; b < paramInt4; b++) {
      float f1 = paramArrayOffloat1[paramInt2++] * f;
      int i = (int)f1;
      i = (i >= 8388607) ? 8388607 : ((i <= -8388608) ? -8388608 : i);
      paramArrayOfbyte[paramInt1 + b * 6] = (byte)(i >> 16);
      paramArrayOfbyte[paramInt1 + b * 6 + 1] = (byte)(i >> 8);
      paramArrayOfbyte[paramInt1 + b * 6 + 2] = (byte)i;
      f1 = paramArrayOffloat2[paramInt3++] * f;
      i = (int)f1;
      i = (i >= 8388607) ? 8388607 : ((i <= -8388608) ? -8388608 : i);
      paramArrayOfbyte[paramInt1 + b * 6 + 3] = (byte)(i >> 16);
      paramArrayOfbyte[paramInt1 + b * 6 + 4] = (byte)(i >> 8);
      paramArrayOfbyte[paramInt1 + b * 6 + 5] = (byte)i;
    } 
  }
  
  public static void convert24Bit(int[] paramArrayOfint, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
    float f = 256.0F;
    for (byte b = 0; b < paramInt3; b++) {
      float f1 = paramArrayOffloat[paramInt2++] * f;
      int i = (int)f1;
      i = (i >= 8388607) ? 8388607 : ((i <= -8388608) ? -8388608 : i);
      paramArrayOfint[paramInt1 + b] = i;
    } 
  }
  
  public static void convert24Bit(int[] paramArrayOfint, int paramInt1, float[] paramArrayOffloat1, int paramInt2, float[] paramArrayOffloat2, int paramInt3, int paramInt4) {
    float f = 256.0F;
    for (byte b = 0; b < paramInt4; b++) {
      float f1 = paramArrayOffloat1[paramInt2++] * f;
      int i = (int)f1;
      i = (i >= 8388607) ? 8388607 : ((i <= -8388608) ? -8388608 : i);
      paramArrayOfint[paramInt1 + 2 * b] = i;
      f1 = paramArrayOffloat2[paramInt3++] * f;
      i = (int)f1;
      i = (i >= 8388607) ? 8388607 : ((i <= -8388608) ? -8388608 : i);
      paramArrayOfint[paramInt1 + 2 * b + 1] = i;
    } 
  }
}


/* Location:              /home/jim_bug/rvm-robot/!/codecLib/mp3/OutputConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */