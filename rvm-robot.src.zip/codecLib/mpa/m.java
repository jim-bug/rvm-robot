package codecLib.mpa;

class m extends Defines {
  g bq = new g();
  
  b bv = new b();
  
  float[][] bm;
  
  int[] bo;
  
  l bn = new l();
  
  float[][][][] bu = new float[3][12][12][32];
  
  byte[][][] bs = new byte[3][7][32];
  
  byte[][][] bp = new byte[3][7][32];
  
  int by;
  
  int bk;
  
  int br;
  
  int bz;
  
  int bt;
  
  f bA;
  
  byte[][] bw = new byte[4][];
  
  a bx;
  
  float[][][] bl = new float[2][8][45];
}


/* Location:              /home/jim_bug/rvm-robot/!/codecLib/mpa/m.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */