package codecLib.mpa;

class i extends Defines implements Constants {
  protected m a8;
  
  protected h aZ = new h(2);
  
  static final byte[][] bf = new byte[][] { { 1, 2 }, { 5, 3 } };
  
  static final byte[] a1 = new byte[] { 8, 9 };
  
  static final byte[] aO = new byte[] { 9, 4 };
  
  static final short[][] bh = new short[][] { { 72, 128 }, { 136, 256 } };
  
  static final int bj = 4;
  
  static final int aU = 3;
  
  static final int a6 = 36;
  
  static final int be = 39;
  
  static final int bd = 576;
  
  static final int a9 = 31;
  
  static final int aQ = 2;
  
  static final int ba = 0;
  
  private short[][][] aS = new short[2][2][39];
  
  private byte[][] aP = new byte[2][4];
  
  private d[][] aY = new d[2][2];
  
  private byte[] aW = new byte[2016];
  
  private int bc = 0;
  
  static final float[] aX = new float[] { 0.0F, 0.21132487F, 0.3660254F, 0.5F, 0.6339746F, 0.7886751F, 1.0F };
  
  static final float[][] aV = new float[][] { { 
        1.0F, 0.8408964F, 0.70710677F, 0.59460354F, 0.5F, 0.4204482F, 0.35355338F, 0.29730177F, 0.25F, 0.2102241F, 
        0.17677669F, 0.14865088F, 0.125F, 0.10511205F, 0.088388346F, 0.07432544F }, { 
        1.0F, 0.70710677F, 0.5F, 0.35355338F, 0.25F, 0.17677669F, 0.125F, 0.088388346F, 0.0625F, 0.044194173F, 
        0.03125F, 0.022097087F, 0.015625F, 0.011048543F, 0.0078125F, 0.005524272F } };
  
  static final byte[] a2 = new byte[] { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 1, 1, 1, 1, 2, 2, 3, 3, 3, 
      2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0 };
  
  static final int bb = 21;
  
  static final int bg = 8;
  
  static final int a4 = 6;
  
  static final int bi = 27;
  
  static final byte[][] a5 = new byte[][] { { 11, 10 }, { 18, 18 }, { 17, 18 } };
  
  static final byte[][] aN = new byte[][] { { 6, 1 }, { 5, 1 }, { 5, 2 }, { 5, 2 } };
  
  static final byte[][] aT = new byte[][] { { 
        0, 0, 0, 0, 3, 1, 1, 1, 2, 2, 
        2, 3, 3, 3, 4, 4 }, { 
        0, 1, 2, 3, 0, 1, 2, 3, 1, 2, 
        3, 1, 2, 3, 2, 3 } };
  
  static final byte[][][] a0 = new byte[][][] { { { 6, 5, 5, 5 }, { 9, 9, 9, 9 }, { 6, 9, 9, 9 } }, { { 6, 5, 7, 3 }, { 9, 9, 12, 6 }, { 6, 9, 12, 6 } }, { { 11, 10, 0, 0 }, { 18, 18, 0, 0 }, { 15, 18, 0, 0 } }, { { 7, 7, 7, 0 }, { 12, 12, 12, 0 }, { 6, 15, 12, 0 } }, { { 6, 6, 6, 3 }, { 12, 9, 9, 6 }, { 6, 12, 9, 6 } }, { { 8, 8, 5, 0 }, { 15, 12, 9, 0 }, { 6, 18, 9, 0 } } };
  
  static final float[] aR = new float[] { 
      5.144879E-12F, 6.1183268E-12F, 7.2759576E-12F, 8.65262E-12F, 1.0289758E-11F, 1.2236653E-11F, 1.4551915E-11F, 1.7305242E-11F, 2.0579516E-11F, 2.4473305E-11F, 
      2.910383E-11F, 3.461048E-11F, 4.115903E-11F, 4.894661E-11F, 5.820766E-11F, 6.922097E-11F, 8.231806E-11F, 9.789322E-11F, 1.1641532E-10F, 1.3844192E-10F, 
      1.6463612E-10F, 1.9578644E-10F, 2.3283064E-10F, 2.7688385E-10F, 3.2927225E-10F, 3.9157289E-10F, 4.656613E-10F, 5.537677E-10F, 6.585445E-10F, 7.8314577E-10F, 
      9.313226E-10F, 1.1075354E-9F, 1.317089E-9F, 1.5662915E-9F, 1.8626451E-9F, 2.2150708E-9F, 2.634178E-9F, 3.132583E-9F, 3.7252903E-9F, 4.4301416E-9F, 
      5.268356E-9F, 6.265166E-9F, 7.4505806E-9F, 8.860283E-9F, 1.0536712E-8F, 1.2530332E-8F, 1.4901161E-8F, 1.7720568E-8F, 2.1073424E-8F, 2.5060665E-8F, 
      2.9802322E-8F, 3.5441136E-8F, 4.2146848E-8F, 5.012133E-8F, 5.9604645E-8F, 7.0882265E-8F, 8.4293696E-8F, 1.0024266E-7F, 1.1920929E-7F, 1.4176453E-7F, 
      1.6858739E-7F, 2.0048533E-7F, 2.3841856E-7F, 2.8352906E-7F, 3.3717478E-7F, 4.0097066E-7F, 4.7683713E-7F, 5.670582E-7F, 6.7434956E-7F, 8.0194127E-7F, 
      9.536743E-7F, 1.1341162E-6F, 1.3486991E-6F, 1.6038825E-6F, 1.9073486E-6F, 2.2682327E-6F, 2.6973983E-6F, 3.207765E-6F, 3.8146973E-6F, 4.536465E-6F, 
      5.3947965E-6F, 6.41553E-6F, 7.6293945E-6F, 9.07293E-6F, 1.0789593E-5F, 1.283106E-5F, 1.5258789E-5F, 1.814586E-5F, 2.1579186E-5F, 2.5662122E-5F, 
      3.0517578E-5F, 3.629172E-5F, 4.3158372E-5F, 5.132424E-5F, 6.1035156E-5F, 7.258344E-5F, 8.6316744E-5F, 1.0264848E-4F, 1.2207031E-4F, 1.4516688E-4F, 
      1.7263349E-4F, 2.0529696E-4F, 2.4414061E-4F, 2.9033376E-4F, 3.4526698E-4F, 4.1059393E-4F, 4.8828125E-4F, 5.806675E-4F, 6.9053395E-4F, 8.2118786E-4F, 
      9.765625E-4F, 0.001161335F, 0.0013810679F, 0.0016423757F, 0.001953125F, 0.00232267F, 0.0027621358F, 0.0032847514F, 0.00390625F, 0.0046453406F, 
      0.0055242716F, 0.006569503F, 0.0078125F, 0.009290681F, 0.011048543F, 0.013139006F, 0.015625F, 0.01858136F, 0.022097087F, 0.026278013F, 
      0.03125F, 0.03716272F, 0.044194173F, 0.052556023F, 0.0625F, 0.07432544F, 0.088388346F, 0.10511205F, 0.125F, 0.14865088F, 
      0.17677669F, 0.21022409F, 0.25F, 0.29730177F, 0.35355338F, 0.42044818F, 0.5F, 0.59460354F, 0.70710677F, 0.84089637F, 
      1.0F, 1.1892071F, 1.4142135F, 1.6817927F, 2.0F, 2.3784142F, 2.8284273F, 3.3635855F, 4.0F, 4.756829F, 
      5.656854F, 6.727171F, 8.0F, 9.513657F, 11.313708F, 13.454342F, 16.0F, 19.027315F, 22.627417F, 26.908684F, 
      32.0F, 38.054626F, 45.254833F, 53.817368F, 64.0F, 76.10926F, 90.50967F, 107.63474F, 128.0F, 152.2185F, 
      181.01933F, 215.26947F, 256.0F, 304.437F, 362.03867F, 430.53894F, 512.0F, 608.874F, 724.07733F, 861.0779F, 
      1024.0F, 1217.748F, 1448.1547F, 1722.1558F, 2048.0F, 2435.496F, 2896.3093F, 3444.3118F, 4096.0F, 4870.992F, 
      5792.6187F, 6888.623F, 8192.0F, 9741.985F, 11585.237F, 13777.246F, 16384.0F, 19483.97F, 23170.475F, 27554.492F, 
      32768.0F, 38967.94F, 46340.95F, 55108.984F, 65536.0F, 77935.88F, 92681.9F, 110217.97F, 131072.0F, 155871.77F, 
      185363.8F, 220435.94F, 262144.0F, 311743.53F, 370727.6F, 440871.88F, 524288.0F, 623487.0F, 741455.2F, 881743.75F, 
      1048576.0F, 1246974.0F, 1482910.4F, 1763487.5F, 2097151.9F, 2493948.0F, 2965820.8F, 3526975.2F, 4194303.8F, 4987896.5F, 
      5931641.5F, 7053950.0F, 8388608.0F, 9975793.0F, 1.1863283E7F, 1.41079E7F, 1.6777215E7F, 1.9951586E7F, 2.3726566E7F, 2.82158E7F, 
      3.3554432E7F, 3.9903168E7F, 4.7453132E7F, 5.6431604E7F, 6.7108864E7F, 7.9806336E7F };
  
  static final short[][][][] a7 = new short[][][][] { { { { 
            6, 6, 6, 6, 6, 6, 8, 10, 12, 14, 
            16, 20, 24, 28, 32, 38, 46, 52, 60, 68, 
            58, 54 }, { 
            4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 
            6, 6, 6, 6, 6, 8, 8, 8, 10, 10, 
            10, 14, 14, 14, 18, 18, 18, 26, 26, 26, 
            32, 32, 32, 42, 42, 42, 18, 18, 18 }, { 
            6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
            6, 6, 8, 8, 8, 10, 10, 10, 14, 14, 
            14, 18, 18, 18, 26, 26, 26, 32, 32, 32, 
            42, 42, 42, 18, 18, 18, 0, 0, 0 } }, { { 
            6, 6, 6, 6, 6, 6, 8, 10, 12, 14, 
            16, 18, 22, 26, 32, 38, 46, 54, 62, 70, 
            76, 36 }, { 
            4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 
            6, 6, 8, 8, 8, 10, 10, 10, 12, 12, 
            12, 14, 14, 14, 18, 18, 18, 24, 24, 24, 
            32, 32, 32, 44, 44, 44, 12, 12, 12 }, { 
            6, 6, 6, 6, 6, 6, 6, 6, 6, 8, 
            8, 8, 10, 10, 10, 12, 12, 12, 14, 14, 
            14, 18, 18, 18, 24, 24, 24, 32, 32, 32, 
            44, 44, 44, 12, 12, 12, 0, 0, 0 } }, { { 
            6, 6, 6, 6, 6, 6, 8, 10, 12, 14, 
            16, 20, 24, 28, 32, 38, 46, 52, 60, 68, 
            58, 54 }, { 
            4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 
            6, 6, 8, 8, 8, 10, 10, 10, 12, 12, 
            12, 14, 14, 14, 18, 18, 18, 24, 24, 24, 
            30, 30, 30, 40, 40, 40, 18, 18, 18 }, { 
            6, 6, 6, 6, 6, 6, 6, 6, 6, 8, 
            8, 8, 10, 10, 10, 12, 12, 12, 14, 14, 
            14, 18, 18, 18, 24, 24, 24, 30, 30, 30, 
            40, 40, 40, 18, 18, 18, 0, 0, 0 } } }, { { { 
            4, 4, 4, 4, 4, 4, 6, 6, 8, 8, 
            10, 12, 16, 20, 24, 28, 34, 42, 50, 54, 
            76, 158 }, { 
            4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
            4, 4, 6, 6, 6, 8, 8, 8, 10, 10, 
            10, 12, 12, 12, 14, 14, 14, 18, 18, 18, 
            22, 22, 22, 30, 30, 30, 56, 56, 56 }, { 
            4, 4, 4, 4, 4, 4, 6, 6, 4, 4, 
            4, 6, 6, 6, 8, 8, 8, 10, 10, 10, 
            12, 12, 12, 14, 14, 14, 18, 18, 18, 22, 
            22, 22, 30, 30, 30, 56, 56, 56, 0 } }, { { 
            4, 4, 4, 4, 4, 4, 6, 6, 6, 8, 
            10, 12, 16, 18, 22, 28, 34, 40, 46, 54, 
            54, 192 }, { 
            4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
            4, 4, 6, 6, 6, 6, 6, 6, 10, 10, 
            10, 12, 12, 12, 14, 14, 14, 16, 16, 16, 
            20, 20, 20, 26, 26, 26, 66, 66, 66 }, { 
            4, 4, 4, 4, 4, 4, 6, 6, 4, 4, 
            4, 6, 6, 6, 6, 6, 6, 10, 10, 10, 
            12, 12, 12, 14, 14, 14, 16, 16, 16, 20, 
            20, 20, 26, 26, 26, 66, 66, 66, 0 } }, { { 
            4, 4, 4, 4, 4, 4, 6, 6, 8, 10, 
            12, 16, 20, 24, 30, 38, 46, 56, 68, 84, 
            102, 26 }, { 
            4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
            4, 4, 6, 6, 6, 8, 8, 8, 12, 12, 
            12, 16, 16, 16, 20, 20, 20, 26, 26, 26, 
            34, 34, 34, 42, 42, 42, 12, 12, 12 }, { 
            4, 4, 4, 4, 4, 4, 6, 6, 4, 4, 
            4, 6, 6, 6, 8, 8, 8, 12, 12, 12, 
            16, 16, 16, 20, 20, 20, 26, 26, 26, 34, 
            34, 34, 42, 42, 42, 12, 12, 12, 0 } } } };
  
  static final int[][][][] a3 = new int[][][][] { { { { 22, 0 }, { 39, 13 }, { 36, 10 } }, { { 22, 0 }, { 39, 13 }, { 36, 10 } }, { { 22, 0 }, { 39, 13 }, { 36, 10 } } }, { { { 22, 0 }, { 39, 13 }, { 38, 10 } }, { { 22, 0 }, { 39, 13 }, { 38, 10 } }, { { 22, 0 }, { 39, 13 }, { 38, 10 } } } };
  
  i(m paramm) {
    this.a8 = paramm;
    n.goto();
  }
  
  void char() throws MPADException {
    throw new MPADException();
  }
  
  void else() throws MPADException {
    byte b1;
    byte b = 0;
    byte[] arrayOfByte = new byte[1952];
    float[][][] arrayOfFloat = new float[2][2][];
    int k = this.a8.bn.k;
    short s = bh[this.a8.bn.long][k - 1];
    if (this.a8.bv.goto() < s)
      throw new MPADException(-3); 
    int n = this.a8.bv.byte();
    int j = this.a8.bn.do - this.a8.bn.if;
    if (this.a8.bv.goto() >= j) {
      b1 = n + (j >> 3);
    } else {
      b1 = 0;
    } 
    if (this.a8.bn.b == 0) {
      a(this.a8);
    } else {
      this.a8.bn.null = 0;
    } 
    if (this.a8.br == 0 && this.a8.bn.c == 0 && this.a8.bq.do(this.a8.bv, this.a8.bn, s) != 0) {
      b = -2;
    } else {
      byte b2;
      byte b3 = aO[this.a8.bn.long];
      int i1 = this.a8.bv.if();
      int i2 = this.a8.bv.if(a1[this.a8.bn.long]);
      this.a8.bv.do(bf[this.a8.bn.long][k - 1]);
      if (this.a8.bn.long == 0) {
        b2 = 1;
      } else {
        for (byte b5 = 0; b5 < k; b5++) {
          for (byte b6 = 0; b6 < 4; b6++)
            this.aP[b5][b6] = (byte)this.a8.bv.if(1); 
        } 
        b2 = 2;
      } 
      int i3 = 0;
      byte b4;
      for (b4 = 0; b4 < b2; b4++) {
        for (byte b5 = 0; b5 < k; b5++) {
          this.aY[b5][b4] = new d();
          (this.aY[b5][b4]).case = this.a8.bv.if(12);
          i3 += (this.aY[b5][b4]).case;
          (this.aY[b5][b4]).g = this.a8.bv.if(9);
          if ((this.aY[b5][b4]).g > 288)
            b = -1; 
          (this.aY[b5][b4]).byte = this.a8.bv.if(8);
          (this.aY[b5][b4]).b = this.a8.bv.if(b3);
          if (0 != ((this.aY[b5][b4]).d = this.a8.bv.if(1))) {
            int i5 = this.a8.bv.if(13);
            (this.aY[b5][b4]).i = i5 >>> 11;
            (this.aY[b5][b4]).c = i5 >>> 10 & 0x1;
            (this.aY[b5][b4]).long[0] = i5 >>> 5 & 0x1F;
            (this.aY[b5][b4]).long[1] = i5 & 0x1F;
            (this.aY[b5][b4]).long[2] = 0;
            for (byte b6 = 0; b6 < 3; b6++) {
              if ((this.aY[b5][b4]).long[b6] == 4 || (this.aY[b5][b4]).long[b6] == 14)
                b = -1; 
            } 
            i5 = this.a8.bv.if(9);
            (this.aY[b5][b4]).goto[0] = i5 >>> 6;
            (this.aY[b5][b4]).goto[1] = i5 >>> 3 & 0x7;
            (this.aY[b5][b4]).goto[2] = i5 & 0x7;
          } else {
            int i5 = this.a8.bv.if(15);
            (this.aY[b5][b4]).long[0] = i5 >>> 10;
            (this.aY[b5][b4]).long[1] = i5 >>> 5 & 0x1F;
            (this.aY[b5][b4]).long[2] = i5 & 0x1F;
            i5 = this.a8.bv.if(7);
            (this.aY[b5][b4]).a = i5 >>> 3;
            (this.aY[b5][b4]).char = i5 & 0x7;
          } 
          if (this.a8.bn.long != 0) {
            (this.aY[b5][b4]).e = this.a8.bv.if(1);
          } else {
            (this.aY[b5][b4]).e = 0;
          } 
          int i4 = this.a8.bv.if(2);
          (this.aY[b5][b4]).new = i4 >>> 1;
          (this.aY[b5][b4]).if = i4 & 0x1;
        } 
      } 
      if (b == 0) {
        boolean bool;
        if (this.a8.bv.goto() < i3 - (i2 << 3))
          throw new MPADException(-3); 
        int i5 = this.a8.bn.do - this.a8.bn.if - this.a8.bv.if() - i1;
        if (this.a8.bn.null >= 0) {
          bool = i5 - i3 - 8 * (this.a8.bn.null - i2);
          if (bool < 0)
            b = -1; 
        } else {
          bool = false;
          this.a8.bn.do = this.a8.bn.if + this.a8.bv.if() - i1;
          if (i2 << 3 < i3)
            this.a8.bn.do += i3 - (i2 << 3); 
        } 
        this.a8.bn.new = bool;
        j = i5;
        if (i5 > this.a8.bv.goto())
          j = this.a8.bv.goto(); 
        if (i2 > this.bc) {
          int i6 = this.a8.bv.char() - (this.a8.bn.if >> 3);
          if (this.bc == 0 && i6 >= i2) {
            a(arrayOfByte, 0, this.a8.bv.else(), i6 - i2, i2);
          } else {
            int i7 = (this.bc == 0) ? i6 : this.bc;
            if (i7 > 511)
              i7 = 511; 
            a(arrayOfByte, 0, this.a8.bv.else(), i6 - i7, i7);
            a(arrayOfByte, i7, this.a8.bv.else(), this.a8.bv.byte(), j >> 3);
            i7 += j >> 3;
            int i8 = i2 + (j >> 3) - (i3 + 7 >> 3);
            if (i8 > i7)
              i8 = i7; 
            if (i8 > this.a8.bn.null)
              if (this.a8.bn.null >= 0) {
                i8 = this.a8.bn.null;
              } else if (i8 > 511) {
                i8 = 511;
              }  
            a(this.aW, 0, arrayOfByte, i7 - i8, i8);
            this.bc = i8;
            throw new MPADException(-9);
          } 
        } else {
          a(arrayOfByte, 0, this.aW, this.bc - i2, i2);
        } 
        a(arrayOfByte, i2, this.a8.bv.else(), this.a8.bv.byte(), j >> 3);
        this.a8.bv.a(arrayOfByte, 0, (j >> 3) + i2);
        i1 = this.a8.bv.if();
        for (b4 = 0; b4 < b2; b4++) {
          for (byte b5 = 0; b5 < k; b5++) {
            if (b4 == 1)
              for (byte b6 = 0; b6 < 39; b6++)
                this.aS[b5][1][b6] = this.aS[b5][0][b6];  
            float[] arrayOfFloat1 = arrayOfFloat[b5][b4] = new float[576];
            d d1 = this.aY[b5][b4];
            a(d1);
            int i6 = this.a8.bv.if();
            if (this.a8.bn.long == 1) {
              a(d1, this.aP[b5], this.aS[b5][b4], b4);
            } else {
              a(d1, this.aS[b5][b4], b5);
            } 
            if(d1);
            if (n.a(d1, this.a8.bv, arrayOfFloat1, this.a8.bv.if() - i6) != 0) {
              b = -1;
              // Byte code: goto -> 2380
            } 
            a(d1, this.aS[b5][b4], arrayOfFloat1);
            i6 = d1.case - this.a8.bv.if() - i6;
            if (i6 != 0)
              this.a8.bv.a(i6); 
          } 
        } 
        if (j < i5)
          throw new MPADException(-4); 
        i5 >>= 3;
        i5 += i2;
        int i4 = i5 - (this.a8.bv.if() - i1 >> 3);
        j = this.a8.bn.null;
        if (j < 0) {
          j = 511;
          if (i4 < 511)
            j = i4; 
        } 
        a(this.aW, 0, arrayOfByte, i5 - j, j);
        this.bc = j;
        if (this.a8.bn.goto == 1 && this.a8.bn.else != 0)
          if (this.a8.bn.else == 2) {
            if(arrayOfFloat[0][0], 0, arrayOfFloat[1][0], 0, 576);
            if (b2 == 2)
              if(arrayOfFloat[0][1], 0, arrayOfFloat[1][1], 0, 576); 
          } else {
            a(this.aY[1][0], arrayOfFloat[0][0], arrayOfFloat[1][0], this.aS[1][0]);
            if (b2 == 2)
              a(this.aY[1][1], arrayOfFloat[0][1], arrayOfFloat[1][1], this.aS[1][1]); 
          }  
        for (b4 = 0; b4 < b2; b4++) {
          for (byte b5 = 0; b5 < k; b5++) {
            float[] arrayOfFloat1 = arrayOfFloat[b5][b4];
            d d1 = this.aY[b5][b4];
            if (d1.try != 0)
              a(d1.void, d1.do, d1.h, arrayOfFloat1); 
            this.aZ.a(arrayOfFloat1, this.a8.bm[b5], (b4 * 576 >> this.a8.bz) + this.a8.bo[b5], (this.aY[b5][b4]).i, 2 * (this.aY[b5][b4]).c, b5, this.a8.bz);
          } 
        } 
        return;
      } 
    } 
    if (b1) {
      int i1 = s >> 3;
      j = b1 - n;
      if (j - i1 >= 511) {
        a(this.aW, 0, this.a8.bv.else(), b1 - 511, 511);
        this.bc = 511;
      } else {
        a(this.aW, this.bc, this.a8.bv.else(), n + i1, j - i1);
        this.bc += j - i1;
        if (this.bc > 1024) {
          a(this.aW, 0, this.aW, this.bc - 511, 511);
          this.bc = 511;
        } 
      } 
    } 
    if (b != 0)
      throw new MPADException(b); 
  }
  
  private static void a(m paramm) {
    byte[] arrayOfByte = paramm.bv.else();
    int j = paramm.bv.char() - (paramm.bn.if >> 3);
    j += paramm.bn.do >> 3;
    int k = paramm.bv.try();
    if (j + 4 > k) {
      paramm.bn.null = -1;
      return;
    } 
    if ((arrayOfByte[j] & 0xFF) != 255 || (arrayOfByte[j + 1] & 0xF6) != 242) {
      paramm.bn.null = -1;
      return;
    } 
    int n = arrayOfByte[j + 1] >> 3 & 0x1;
    int i1 = arrayOfByte[j + 1] & 0x1 ^ 0x1;
    j += 4 + (i1 << 1);
    if (n == 1) {
      if (j + 1 >= k) {
        paramm.bn.null = -1;
        return;
      } 
      paramm.bn.null = (arrayOfByte[j] & 0xFF) << 1 | (arrayOfByte[j + 1] & 0xFF) >> 7;
    } else {
      if (j >= k) {
        paramm.bn.null = -1;
        return;
      } 
      paramm.bn.null = arrayOfByte[j] & 0xFF;
    } 
  }
  
  void a(d paramd) {
    if (paramd.d != 0) {
      if (paramd.i == 2) {
        if (paramd.c == 0) {
          paramd.a = 8;
          paramd.try = 1;
        } else {
          paramd.a = 7;
          paramd.try = 2;
        } 
      } else {
        paramd.a = 7;
        paramd.try = 0;
      } 
      paramd.char = 63;
    } else {
      paramd.i = 0;
      paramd.try = 0;
      paramd.c = 0;
    } 
    paramd.void = a7[this.a8.bn.long][this.a8.bn.i][paramd.try];
    paramd.h = a3[this.a8.bn.long][this.a8.bn.i][paramd.try][0];
    paramd.do = a3[this.a8.bn.long][this.a8.bn.i][paramd.try][1];
  }
  
  int a(d paramd, byte[] paramArrayOfbyte, short[] paramArrayOfshort, int paramInt) {
    byte b1 = aT[0][paramd.b];
    byte b2 = aT[1][paramd.b];
    byte b3 = a5[paramd.try][0];
    byte b4 = a5[paramd.try][1];
    int j = 0;
    if (paramd.try == 0 && paramInt == 1) {
      for (byte b5 = 0; b5 < 4; b5++) {
        if (paramArrayOfbyte[b5] == 0)
          if (aN[b5][1] == 1) {
            this.a8.bv.a(paramArrayOfshort, j, b1, aN[b5][0]);
          } else {
            this.a8.bv.a(paramArrayOfshort, j, b2, aN[b5][0]);
          }  
        j += aN[b5][0];
      } 
    } else {
      this.a8.bv.a(paramArrayOfshort, j, b1, b3);
      j += b3;
      this.a8.bv.a(paramArrayOfshort, j, b2, b4);
      j += b4;
    } 
    for (byte b = 0; b < 3; b++)
      paramArrayOfshort[j++] = 0; 
    paramd.f[0] = b1;
    paramd.f[1] = b2;
    paramd.f[3] = 0;
    paramd.f[2] = 0;
    paramd.for[0] = b3;
    paramd.for[1] = b4;
    paramd.for[3] = 0;
    paramd.for[2] = 0;
    return 1;
  }
  
  int a(d paramd, short[] paramArrayOfshort, int paramInt) {
    boolean bool;
    byte b = 0;
    int i1 = this.a8.bn.else;
    int n = paramd.b;
    paramd.e = 0;
    if ((i1 & 0x1) == 0 || paramInt == 0) {
      paramd.null = 0;
      if (n < 400) {
        paramd.f[0] = (n >> 4) / 5;
        paramd.f[1] = (n >> 4) % 5;
        paramd.f[2] = (n & 0xF) >> 2;
        paramd.f[3] = n & 0x3;
        b = 0;
      } else if (n < 500) {
        n -= 400;
        paramd.f[0] = (n >> 2) / 5;
        paramd.f[1] = (n >> 2) % 5;
        paramd.f[2] = n & 0x3;
        paramd.f[3] = 0;
        b = 1;
      } else if (n < 512) {
        n -= 500;
        paramd.f[0] = n / 3;
        paramd.f[1] = n % 3;
        paramd.f[2] = 0;
        paramd.f[3] = 0;
        paramd.e = 1;
        b = 2;
      } 
    } else {
      paramd.null = n & 0x1;
      n >>= 1;
      if (n < 180) {
        paramd.f[0] = n / 36;
        paramd.f[1] = n % 36 / 6;
        paramd.f[2] = n % 36 % 6;
        paramd.f[3] = 0;
        b = 3;
      } else if (n < 244) {
        n -= 180;
        paramd.f[0] = (n & 0x3F) >> 4;
        paramd.f[1] = (n & 0xF) >> 2;
        paramd.f[2] = n & 0x3;
        paramd.f[3] = 0;
        b = 4;
      } else if (n <= 255) {
        n -= 244;
        paramd.f[0] = n / 3;
        paramd.f[1] = n % 3;
        paramd.f[2] = 0;
        paramd.f[3] = 0;
        b = 5;
      } 
    } 
    if (paramd.i == 2) {
      bool = 1 + paramd.c;
    } else {
      bool = false;
    } 
    int k = 0;
    int j;
    for (j = 0; j < 4; j++) {
      byte b1 = a0[b][bool][j];
      this.a8.bv.a(paramArrayOfshort, k, paramd.f[j], b1);
      k += b1;
      paramd.for[j] = b1;
    } 
    j = 3;
    while (j-- > 0)
      paramArrayOfshort[k++] = 0; 
    return 1;
  }
  
  void if(d paramd) {
    short[] arrayOfShort = paramd.void;
    byte b2 = 0;
    int j = 0;
    byte b1 = 0;
    b2 = 0;
    while (j < paramd.g * 2) {
      j += arrayOfShort[b2++];
      b1++;
    } 
    int k = paramd.a + 1;
    int n = paramd.char + 1;
    if (b1 < 2)
      n = 0; 
    if (b1 == 0)
      k = 0; 
    if (n + k > b1)
      n = b1 - k; 
    int i1 = b1 - n - k;
    if (i1 < 0)
      i1 = 0; 
    j = 0;
    b2 = 0;
    int i2 = k - 1;
    while (i2-- >= 0)
      j += arrayOfShort[b2++]; 
    paramd.else[0] = j >> 1;
    if (paramd.else[0] > paramd.g)
      paramd.else[0] = paramd.g; 
    j = 0;
    i2 = n - 1;
    while (i2-- >= 0)
      j += arrayOfShort[b2++]; 
    paramd.else[1] = j >> 1;
    if (paramd.else[1] > paramd.g - paramd.else[0])
      paramd.else[1] = paramd.g - paramd.else[0]; 
    paramd.else[2] = paramd.g - paramd.else[0] - paramd.else[1];
  }
  
  void a(d paramd, short[] paramArrayOfshort, float[] paramArrayOffloat) {
    int[] arrayOfInt = new int[39];
    int k = 1 + paramd.new;
    byte b2 = 0;
    byte b3 = 0;
    int j = paramd.byte;
    if (paramd.try == 0) {
      if (paramd.e != 0) {
        byte b = 0;
        int n = paramd.h - 1;
        while (n-- >= 0)
          arrayOfInt[b3++] = j - (paramArrayOfshort[b2++] + a2[b++] << k); 
      } else {
        int n = paramd.h - 1;
        while (n-- >= 0)
          arrayOfInt[b3++] = j - (paramArrayOfshort[b2++] << k); 
      } 
    } else {
      int i1 = 8 * paramd.goto[0];
      int i2 = 8 * paramd.goto[1];
      int i3 = 8 * paramd.goto[2];
      int n = paramd.h - paramd.do * 3 - 1;
      while (n-- >= 0)
        arrayOfInt[b3++] = j - (paramArrayOfshort[b2++] << k); 
      n = paramd.do - 1;
      while (n-- >= 0) {
        arrayOfInt[b3++] = j - (paramArrayOfshort[b2++] << k) - i1;
        arrayOfInt[b3++] = j - (paramArrayOfshort[b2++] << k) - i2;
        arrayOfInt[b3++] = j - (paramArrayOfshort[b2++] << k) - i3;
      } 
    } 
    byte b4 = 0;
    byte b5 = 0;
    b3 = 0;
    for (byte b1 = 0; b1 < paramd.h; b1++) {
      short s = paramd.void[b4++];
      float f = aR[arrayOfInt[b3++]];
      for (byte b = 0; b < s; b++)
        paramArrayOffloat[b5++] = paramArrayOffloat[b5++] * f; 
    } 
  }
  
  static void if(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
    for (byte b = 0; b < paramInt3; b++) {
      float f1 = paramArrayOffloat1[paramInt1 + b] * 0.70710677F;
      float f2 = paramArrayOffloat2[paramInt2 + b] * 0.70710677F;
      paramArrayOffloat1[paramInt1 + b] = f1 + f2;
      paramArrayOffloat2[paramInt2 + b] = f1 - f2;
    } 
  }
  
  void a(d paramd, float[] paramArrayOffloat1, float[] paramArrayOffloat2, short[] paramArrayOfshort) {
    int i4 = 0;
    int i5 = 0;
    short[] arrayOfShort = new short[39];
    int j = 38;
    while (j-- >= 0)
      arrayOfShort[i5++] = paramArrayOfshort[i4++]; 
    int k = paramd.h;
    int n = paramd.do;
    int i1 = k - n * 3;
    int i2 = 575;
    int i6 = k - 1;
    i5 = k - 1;
    a(paramArrayOffloat2, i2, n, i1, paramd.void, i6, arrayOfShort, i5);
    if (this.a8.bn.long == 1) {
      paramd.f[1] = 3;
      paramd.f[0] = 3;
    } 
    a(paramd, arrayOfShort);
    if (n != 0) {
      i4 = i5 - 3;
      arrayOfShort[i5--] = paramArrayOfshort[i4--];
      arrayOfShort[i5--] = paramArrayOfshort[i4--];
      arrayOfShort[i5--] = paramArrayOfshort[i4--];
      i5 += 3;
    } else {
      arrayOfShort[i5] = arrayOfShort[i5 - 1];
    } 
    i6 = 0;
    i5 = 0;
    int i3 = i2 = 0;
    j = k;
    while (j-- > 0) {
      short s = paramd.void[i6++];
      if (arrayOfShort[i5] == 31) {
        if (this.a8.bn.else == 3)
          if(paramArrayOffloat1, i3, paramArrayOffloat2, i2, s); 
      } else {
        a(paramArrayOffloat1, i3, paramArrayOffloat2, i2, arrayOfShort[i5], s, this.a8.bn.long, paramd.null);
      } 
      i5++;
      i3 += s;
      i2 += s;
    } 
  }
  
  void a(float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3, short[] paramArrayOfshort1, int paramInt4, short[] paramArrayOfshort2, int paramInt5) {
    byte b = -1;
    int[] arrayOfInt = new int[3];
    arrayOfInt[2] = -1;
    arrayOfInt[1] = -1;
    arrayOfInt[0] = -1;
    int j = paramInt2 - 1;
    while (j-- >= 0) {
      byte b1 = 2;
      int k = 2;
      while (k-- >= 0) {
        short s = paramArrayOfshort1[paramInt4--];
        if (arrayOfInt[b1] == -1) {
          float f = a(paramArrayOffloat, paramInt1 - s + 1, s);
          if (f != 0.0F) {
            arrayOfInt[b1] = j + 2;
            b = 1;
            paramArrayOfshort2[paramInt5] = 31;
          } 
        } else {
          paramArrayOfshort2[paramInt5] = 31;
        } 
        b1--;
        paramInt1 -= s;
        paramInt5--;
      } 
    } 
    arrayOfInt[2] = b;
    arrayOfInt[1] = b;
    arrayOfInt[0] = b;
    j = paramInt3 - 1;
    while (j-- >= 0) {
      byte b1 = 2;
      short s = paramArrayOfshort1[paramInt4--];
      if (arrayOfInt[b1] == -1) {
        float f = a(paramArrayOffloat, paramInt1 - s + 1, s);
        if (f != 0.0F) {
          arrayOfInt[b1] = j + 2;
          b = 1;
          paramArrayOfshort2[paramInt5] = 31;
        } 
      } else {
        paramArrayOfshort2[paramInt5] = 31;
      } 
      b1--;
      paramInt1 -= s;
      paramInt5--;
    } 
  }
  
  float a(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    float f = 0.0F;
    for (byte b = 0; b < paramInt2; b++) {
      float f1 = paramArrayOffloat[paramInt1 + b];
      f += f1 * f1;
    } 
    return f;
  }
  
  void a(d paramd, short[] paramArrayOfshort) {
    int k = 0;
    byte b1 = 0;
    byte b2 = 0;
    int[] arrayOfInt1 = paramd.for;
    int[] arrayOfInt2 = paramd.f;
    int j = 3;
    while (j-- >= 0) {
      int n = 1;
      if (arrayOfInt2[b2] != 0) {
        n <<= arrayOfInt2[b2];
        n--;
        int i1 = arrayOfInt1[b1] - 1;
        while (i1-- >= 0) {
          if (paramArrayOfshort[k] == n)
            paramArrayOfshort[k] = 31; 
          k++;
        } 
      } else {
        k += arrayOfInt1[b1];
      } 
      b1++;
      b2++;
    } 
  }
  
  void a(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    float f1;
    float f2;
    if (paramInt5 == 1) {
      f1 = aX[paramInt3];
      f2 = aX[6 - paramInt3];
    } else {
      int j = paramInt3 & 0x1;
      int k = paramInt3 + 1 >> 1;
      if (j == 0) {
        f2 = aV[paramInt6][k];
        f1 = 1.0F;
      } else {
        f1 = aV[paramInt6][k];
        f2 = 1.0F;
      } 
    } 
    for (byte b = 0; b < paramInt4; b++) {
      float f = paramArrayOffloat1[paramInt1 + b];
      paramArrayOffloat1[paramInt1 + b] = f * f1;
      paramArrayOffloat2[paramInt2 + b] = f * f2;
    } 
  }
  
  void a(short[] paramArrayOfshort, int paramInt1, int paramInt2, float[] paramArrayOffloat) {
    float[] arrayOfFloat = new float[576];
    int k = 0;
    int n = 0;
    int i1 = 0;
    byte b = 0;
    int j = paramInt2 - paramInt1 * 3 - 1;
    while (j-- >= 0)
      k += paramArrayOfshort[b++]; 
    i1 += k;
    j = paramInt1 - 1;
    while (j-- >= 0) {
      short s = paramArrayOfshort[b];
      a(paramArrayOffloat, i1, arrayOfFloat, n, s);
      i1 += 3 * s;
      n += 3 * s;
      b += 3;
    } 
    for (j = 0; j < 576 - k; j++)
      paramArrayOffloat[k + j] = arrayOfFloat[j]; 
  }
  
  static void a(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
    int j = paramInt1;
    int k = paramInt1 + paramInt3;
    int n = paramInt1 + paramInt3 * 2;
    for (byte b = 0; b < paramInt3 >> 1; b++) {
      paramArrayOffloat2[paramInt2 + 6 * b + 0] = paramArrayOffloat1[j + 2 * b];
      paramArrayOffloat2[paramInt2 + 6 * b + 1] = paramArrayOffloat1[k + 2 * b];
      paramArrayOffloat2[paramInt2 + 6 * b + 2] = paramArrayOffloat1[n + 2 * b];
      paramArrayOffloat2[paramInt2 + 6 * b + 3] = paramArrayOffloat1[j + 2 * b + 1];
      paramArrayOffloat2[paramInt2 + 6 * b + 4] = paramArrayOffloat1[k + 2 * b + 1];
      paramArrayOffloat2[paramInt2 + 6 * b + 5] = paramArrayOffloat1[n + 2 * b + 1];
    } 
  }
  
  static void a(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3) {
    for (byte b = 0; b < paramInt3; b++)
      paramArrayOfbyte1[paramInt1 + b] = paramArrayOfbyte2[paramInt2 + b]; 
  }
}


/* Location:              /home/jim_bug/rvm-robot/!/codecLib/mpa/i.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */