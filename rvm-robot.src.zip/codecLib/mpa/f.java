package codecLib.mpa;

class f {
  byte int;
  
  byte do;
  
  byte[] a;
  
  byte[][] if;
  
  byte[][] for;
  
  f(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2) {
    this.int = (byte)paramInt1;
    this.do = (byte)paramInt2;
    this.a = paramArrayOfbyte;
    this.if = paramArrayOfbyte1;
    this.for = paramArrayOfbyte2;
  }
}


/* Location:              /home/jim_bug/rvm-robot/!/codecLib/mpa/f.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */