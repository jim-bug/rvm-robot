package codecLib.mpa;

class h extends PolySynthesis {
  private float[][] x = new float[2][576];
  
  private float[] p = new float[576];
  
  static final int z = 2;
  
  private static final float[] v = new float[] { 
      -0.3381169F, -0.3070072F, -0.2751725F, -0.24207844F, -0.20710678F, -0.16950515F, -0.12831505F, -0.08226233F, -0.0295814F, 0.03228243F, 
      0.10720636F, 0.20141427F, 0.32561636F, 0.5F, 0.7677747F, 1.2412229F, 2.3319511F, 7.7441506F };
  
  private static final float[] r = new float[] { 0.5019099F, 0.5176381F, 0.55168897F, 0.61038727F, 0.70710677F, 0.8717234F, 1.1831008F, 1.9318516F, 5.7368565F };
  
  private static final float[] o = new float[] { 0.9848077F, 0.8660254F, 0.64278764F, 0.34202015F, 0.9396926F, 0.76604444F, 0.5F, 0.17364818F };
  
  private static final float[] w = new float[] { -0.3070072F, -0.20710678F, -0.08226233F, 0.10720636F, 0.5F, 2.3319511F };
  
  private static final float[] n = new float[] { 0.5176381F, 0.70710677F, 1.9318516F };
  
  private static final float[] t = new float[] { 0.8660254F, 0.5F };
  
  private static final float[] q = new float[] { 7.595754F, 2.4142137F, 1.3032254F };
  
  private static final float[] A = new float[] { 22.903765F, 7.595754F, 4.5107083F, 3.1715949F, 2.4142137F, 1.9209821F, 1.5696856F, 1.3032254F, 1.0913085F, 0.0F };
  
  private static final float[] y = new float[] { 
      22.925585F, 7.661298F, 4.6202264F, 3.3255095F, 2.613126F, 2.1656806F, 1.8452365F, 1.5176381F, 1.1743115F, 0.9010809F, 
      0.6286263F, 0.24293F };
  
  private static final float[] s = new float[] { 0.8574929F, 0.881742F, 0.94962865F, 0.9833146F, 0.9955178F, 0.9991606F, 0.9998992F, 0.99999315F };
  
  private static final float[] u = new float[] { -0.51449573F, -0.47173196F, -0.31337744F, -0.1819132F, -0.09457419F, -0.040965583F, -0.014198569F, -0.003699975F };
  
  public h(int paramInt) {}
  
  int a(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt4 > 12)
      return -1; 
    a(paramArrayOffloat1, this.p, this.x[paramInt4], paramInt2, paramInt3, 32);
    a(this.p, paramArrayOffloat2, paramInt1, paramInt4, paramInt5);
    return 0;
  }
  
  private void a(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt1;
    int j = i + (32 >> paramInt3);
    for (byte b = 0; b < 9; b++) {
      for (byte b1 = 0; b1 < 16 >> paramInt3; b1++) {
        paramArrayOffloat2[i + 2 * b1] = paramArrayOffloat1[2 * b + 36 * b1];
        paramArrayOffloat2[i + 2 * b1 + 1] = paramArrayOffloat1[2 * b + 36 * b1 + 18];
        paramArrayOffloat2[j + 2 * b1] = paramArrayOffloat1[2 * b + 36 * b1 + 1];
        paramArrayOffloat2[j + 2 * b1 + 1] = -paramArrayOffloat1[2 * b + 36 * b1 + 19];
      } 
      if (paramInt3 == 0) {
        kernel32(paramArrayOffloat2, i, paramInt2);
        kernel32(paramArrayOffloat2, j, paramInt2);
      } else if (paramInt3 == 1) {
        kernel16(paramArrayOffloat2, i, paramInt2);
        kernel16(paramArrayOffloat2, j, paramInt2);
      } else if (paramInt3 == 2) {
        kernel8(paramArrayOffloat2, i, paramInt2);
        kernel8(paramArrayOffloat2, j, paramInt2);
      } 
      i += 64 >> paramInt3;
      j += 64 >> paramInt3;
    } 
  }
  
  private static void a(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 != 2)
      a(paramArrayOffloat1); 
    for (byte b = 0; b < paramInt3; b++) {
      int i;
      if (b < paramInt2) {
        i = 0;
      } else {
        i = paramInt1;
      } 
      a(paramArrayOffloat2, paramArrayOffloat1, paramArrayOffloat3, 18 * b, i);
    } 
  }
  
  private static void a(float[] paramArrayOffloat) {
    byte b2 = 10;
    float f1 = s[0];
    float f2 = s[1];
    float f3 = s[2];
    float f4 = s[3];
    float f5 = s[4];
    float f6 = s[5];
    float f7 = s[6];
    float f8 = s[7];
    float f9 = u[0];
    float f10 = u[1];
    float f11 = u[2];
    float f12 = u[3];
    float f13 = u[4];
    float f14 = u[5];
    float f15 = u[6];
    float f16 = u[7];
    for (byte b1 = 1; b1 < 32; b1++) {
      float f17 = paramArrayOffloat[b2 + 0];
      float f18 = paramArrayOffloat[b2 + 1];
      float f19 = paramArrayOffloat[b2 + 2];
      float f20 = paramArrayOffloat[b2 + 3];
      float f21 = paramArrayOffloat[b2 + 4];
      float f22 = paramArrayOffloat[b2 + 5];
      float f23 = paramArrayOffloat[b2 + 6];
      float f24 = paramArrayOffloat[b2 + 7];
      float f25 = paramArrayOffloat[b2 + 8];
      float f26 = paramArrayOffloat[b2 + 9];
      float f27 = paramArrayOffloat[b2 + 10];
      float f28 = paramArrayOffloat[b2 + 11];
      float f29 = paramArrayOffloat[b2 + 12];
      float f30 = paramArrayOffloat[b2 + 13];
      float f31 = paramArrayOffloat[b2 + 14];
      float f32 = paramArrayOffloat[b2 + 15];
      paramArrayOffloat[b2 + 0] = f17 * f8 - f32 * f16;
      paramArrayOffloat[b2 + 1] = f18 * f7 - f31 * f15;
      paramArrayOffloat[b2 + 2] = f19 * f6 - f30 * f14;
      paramArrayOffloat[b2 + 3] = f20 * f5 - f29 * f13;
      paramArrayOffloat[b2 + 4] = f21 * f4 - f28 * f12;
      paramArrayOffloat[b2 + 5] = f22 * f3 - f27 * f11;
      paramArrayOffloat[b2 + 6] = f23 * f2 - f26 * f10;
      paramArrayOffloat[b2 + 7] = f24 * f1 - f25 * f9;
      paramArrayOffloat[b2 + 8] = f25 * f1 + f24 * f9;
      paramArrayOffloat[b2 + 9] = f26 * f2 + f23 * f10;
      paramArrayOffloat[b2 + 10] = f27 * f3 + f22 * f11;
      paramArrayOffloat[b2 + 11] = f28 * f4 + f21 * f12;
      paramArrayOffloat[b2 + 12] = f29 * f5 + f20 * f13;
      paramArrayOffloat[b2 + 13] = f30 * f6 + f19 * f14;
      paramArrayOffloat[b2 + 14] = f31 * f7 + f18 * f15;
      paramArrayOffloat[b2 + 15] = f32 * f8 + f17 * f16;
      b2 += 18;
    } 
  }
  
  private static void a(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt1, int paramInt2) {
    if (paramInt2 != 2) {
      float[] arrayOfFloat = new float[18];
      a(arrayOfFloat, paramArrayOffloat2, paramInt1);
      if (paramInt2 != 3) {
        paramArrayOffloat1[paramInt1 + 0] = paramArrayOffloat3[paramInt1 + 0] - arrayOfFloat[9];
        paramArrayOffloat1[paramInt1 + 1] = paramArrayOffloat3[paramInt1 + 1] - arrayOfFloat[10];
        paramArrayOffloat1[paramInt1 + 2] = paramArrayOffloat3[paramInt1 + 2] - arrayOfFloat[11];
        paramArrayOffloat1[paramInt1 + 3] = paramArrayOffloat3[paramInt1 + 3] - arrayOfFloat[12];
        paramArrayOffloat1[paramInt1 + 4] = paramArrayOffloat3[paramInt1 + 4] - arrayOfFloat[13];
        paramArrayOffloat1[paramInt1 + 5] = paramArrayOffloat3[paramInt1 + 5] - arrayOfFloat[14];
        paramArrayOffloat1[paramInt1 + 6] = paramArrayOffloat3[paramInt1 + 6] - arrayOfFloat[15];
        paramArrayOffloat1[paramInt1 + 7] = paramArrayOffloat3[paramInt1 + 7] - arrayOfFloat[16];
        paramArrayOffloat1[paramInt1 + 8] = paramArrayOffloat3[paramInt1 + 8] - arrayOfFloat[17];
        paramArrayOffloat1[paramInt1 + 9] = paramArrayOffloat3[paramInt1 + 9] + arrayOfFloat[17] * A[8];
        paramArrayOffloat1[paramInt1 + 10] = paramArrayOffloat3[paramInt1 + 10] + arrayOfFloat[16] * A[7];
        paramArrayOffloat1[paramInt1 + 11] = paramArrayOffloat3[paramInt1 + 11] + arrayOfFloat[15] * A[6];
        paramArrayOffloat1[paramInt1 + 12] = paramArrayOffloat3[paramInt1 + 12] + arrayOfFloat[14] * A[5];
        paramArrayOffloat1[paramInt1 + 13] = paramArrayOffloat3[paramInt1 + 13] + arrayOfFloat[13] * A[4];
        paramArrayOffloat1[paramInt1 + 14] = paramArrayOffloat3[paramInt1 + 14] + arrayOfFloat[12] * A[3];
        paramArrayOffloat1[paramInt1 + 15] = paramArrayOffloat3[paramInt1 + 15] + arrayOfFloat[11] * A[2];
        paramArrayOffloat1[paramInt1 + 16] = paramArrayOffloat3[paramInt1 + 16] + arrayOfFloat[10] * A[1];
        paramArrayOffloat1[paramInt1 + 17] = paramArrayOffloat3[paramInt1 + 17] + arrayOfFloat[9] * A[0];
      } else {
        paramArrayOffloat1[paramInt1 + 0] = paramArrayOffloat3[paramInt1 + 0];
        paramArrayOffloat1[paramInt1 + 1] = paramArrayOffloat3[paramInt1 + 1];
        paramArrayOffloat1[paramInt1 + 2] = paramArrayOffloat3[paramInt1 + 2];
        paramArrayOffloat1[paramInt1 + 3] = paramArrayOffloat3[paramInt1 + 3];
        paramArrayOffloat1[paramInt1 + 4] = paramArrayOffloat3[paramInt1 + 4];
        paramArrayOffloat1[paramInt1 + 5] = paramArrayOffloat3[paramInt1 + 5];
        paramArrayOffloat1[paramInt1 + 6] = paramArrayOffloat3[paramInt1 + 6] - arrayOfFloat[15] * y[11];
        paramArrayOffloat1[paramInt1 + 7] = paramArrayOffloat3[paramInt1 + 7] - arrayOfFloat[16] * y[10];
        paramArrayOffloat1[paramInt1 + 8] = paramArrayOffloat3[paramInt1 + 8] - arrayOfFloat[17] * y[9];
        paramArrayOffloat1[paramInt1 + 9] = paramArrayOffloat3[paramInt1 + 9] + arrayOfFloat[17] * y[8];
        paramArrayOffloat1[paramInt1 + 10] = paramArrayOffloat3[paramInt1 + 10] + arrayOfFloat[16] * y[7];
        paramArrayOffloat1[paramInt1 + 11] = paramArrayOffloat3[paramInt1 + 11] + arrayOfFloat[15] * y[6];
        paramArrayOffloat1[paramInt1 + 12] = paramArrayOffloat3[paramInt1 + 12] + arrayOfFloat[14] * y[5];
        paramArrayOffloat1[paramInt1 + 13] = paramArrayOffloat3[paramInt1 + 13] + arrayOfFloat[13] * y[4];
        paramArrayOffloat1[paramInt1 + 14] = paramArrayOffloat3[paramInt1 + 14] + arrayOfFloat[12] * y[3];
        paramArrayOffloat1[paramInt1 + 15] = paramArrayOffloat3[paramInt1 + 15] + arrayOfFloat[11] * y[2];
        paramArrayOffloat1[paramInt1 + 16] = paramArrayOffloat3[paramInt1 + 16] + arrayOfFloat[10] * y[1];
        paramArrayOffloat1[paramInt1 + 17] = paramArrayOffloat3[paramInt1 + 17] + arrayOfFloat[9] * y[0];
      } 
      if (paramInt2 != 1) {
        paramArrayOffloat3[paramInt1 + 0] = arrayOfFloat[8] * A[0];
        paramArrayOffloat3[paramInt1 + 1] = arrayOfFloat[7] * A[1];
        paramArrayOffloat3[paramInt1 + 2] = arrayOfFloat[6] * A[2];
        paramArrayOffloat3[paramInt1 + 3] = arrayOfFloat[5] * A[3];
        paramArrayOffloat3[paramInt1 + 4] = arrayOfFloat[4] * A[4];
        paramArrayOffloat3[paramInt1 + 5] = arrayOfFloat[3] * A[5];
        paramArrayOffloat3[paramInt1 + 6] = arrayOfFloat[2] * A[6];
        paramArrayOffloat3[paramInt1 + 7] = arrayOfFloat[1] * A[7];
        paramArrayOffloat3[paramInt1 + 8] = arrayOfFloat[0] * A[8];
        paramArrayOffloat3[paramInt1 + 9] = arrayOfFloat[0];
        paramArrayOffloat3[paramInt1 + 10] = arrayOfFloat[1];
        paramArrayOffloat3[paramInt1 + 11] = arrayOfFloat[2];
        paramArrayOffloat3[paramInt1 + 12] = arrayOfFloat[3];
        paramArrayOffloat3[paramInt1 + 13] = arrayOfFloat[4];
        paramArrayOffloat3[paramInt1 + 14] = arrayOfFloat[5];
        paramArrayOffloat3[paramInt1 + 15] = arrayOfFloat[6];
        paramArrayOffloat3[paramInt1 + 16] = arrayOfFloat[7];
        paramArrayOffloat3[paramInt1 + 17] = arrayOfFloat[8];
      } else {
        paramArrayOffloat3[paramInt1 + 0] = arrayOfFloat[8] * y[0];
        paramArrayOffloat3[paramInt1 + 1] = arrayOfFloat[7] * y[1];
        paramArrayOffloat3[paramInt1 + 2] = arrayOfFloat[6] * y[2];
        paramArrayOffloat3[paramInt1 + 3] = arrayOfFloat[5] * y[3];
        paramArrayOffloat3[paramInt1 + 4] = arrayOfFloat[4] * y[4];
        paramArrayOffloat3[paramInt1 + 5] = arrayOfFloat[3] * y[5];
        paramArrayOffloat3[paramInt1 + 6] = arrayOfFloat[2] * y[6];
        paramArrayOffloat3[paramInt1 + 7] = arrayOfFloat[1] * y[7];
        paramArrayOffloat3[paramInt1 + 8] = arrayOfFloat[0] * y[8];
        paramArrayOffloat3[paramInt1 + 9] = arrayOfFloat[0] * y[9];
        paramArrayOffloat3[paramInt1 + 10] = arrayOfFloat[1] * y[10];
        paramArrayOffloat3[paramInt1 + 11] = arrayOfFloat[2] * y[11];
        paramArrayOffloat3[paramInt1 + 12] = 0.0F;
        paramArrayOffloat3[paramInt1 + 13] = 0.0F;
        paramArrayOffloat3[paramInt1 + 14] = 0.0F;
        paramArrayOffloat3[paramInt1 + 15] = 0.0F;
        paramArrayOffloat3[paramInt1 + 16] = 0.0F;
        paramArrayOffloat3[paramInt1 + 17] = 0.0F;
      } 
    } else {
      float[][] arrayOfFloat = new float[3][6];
      if(arrayOfFloat[0], paramArrayOffloat2, paramInt1 + 0);
      if(arrayOfFloat[1], paramArrayOffloat2, paramInt1 + 1);
      if(arrayOfFloat[2], paramArrayOffloat2, paramInt1 + 2);
      paramArrayOffloat1[paramInt1 + 0] = paramArrayOffloat3[paramInt1 + 0];
      paramArrayOffloat1[paramInt1 + 1] = paramArrayOffloat3[paramInt1 + 1];
      paramArrayOffloat1[paramInt1 + 2] = paramArrayOffloat3[paramInt1 + 2];
      paramArrayOffloat1[paramInt1 + 3] = paramArrayOffloat3[paramInt1 + 3];
      paramArrayOffloat1[paramInt1 + 4] = paramArrayOffloat3[paramInt1 + 4];
      paramArrayOffloat1[paramInt1 + 5] = paramArrayOffloat3[paramInt1 + 5];
      paramArrayOffloat1[paramInt1 + 6] = paramArrayOffloat3[paramInt1 + 6] - arrayOfFloat[0][3];
      paramArrayOffloat1[paramInt1 + 7] = paramArrayOffloat3[paramInt1 + 7] - arrayOfFloat[0][4];
      paramArrayOffloat1[paramInt1 + 8] = paramArrayOffloat3[paramInt1 + 8] - arrayOfFloat[0][5];
      paramArrayOffloat1[paramInt1 + 9] = paramArrayOffloat3[paramInt1 + 9] + arrayOfFloat[0][5] * q[2];
      paramArrayOffloat1[paramInt1 + 10] = paramArrayOffloat3[paramInt1 + 10] + arrayOfFloat[0][4] * q[1];
      paramArrayOffloat1[paramInt1 + 11] = paramArrayOffloat3[paramInt1 + 11] + arrayOfFloat[0][3] * q[0];
      paramArrayOffloat1[paramInt1 + 12] = paramArrayOffloat3[paramInt1 + 12] + arrayOfFloat[0][2] * q[0] - arrayOfFloat[1][3];
      paramArrayOffloat1[paramInt1 + 13] = paramArrayOffloat3[paramInt1 + 13] + arrayOfFloat[0][1] * q[1] - arrayOfFloat[1][4];
      paramArrayOffloat1[paramInt1 + 14] = paramArrayOffloat3[paramInt1 + 14] + arrayOfFloat[0][0] * q[2] - arrayOfFloat[1][5];
      paramArrayOffloat1[paramInt1 + 15] = paramArrayOffloat3[paramInt1 + 15] + arrayOfFloat[0][0] + arrayOfFloat[1][5] * q[2];
      paramArrayOffloat1[paramInt1 + 16] = paramArrayOffloat3[paramInt1 + 16] + arrayOfFloat[0][1] + arrayOfFloat[1][4] * q[1];
      paramArrayOffloat1[paramInt1 + 17] = paramArrayOffloat3[paramInt1 + 17] + arrayOfFloat[0][2] + arrayOfFloat[1][3] * q[0];
      paramArrayOffloat3[paramInt1 + 0] = -arrayOfFloat[2][3] + arrayOfFloat[1][2] * q[0];
      paramArrayOffloat3[paramInt1 + 1] = -arrayOfFloat[2][4] + arrayOfFloat[1][1] * q[1];
      paramArrayOffloat3[paramInt1 + 2] = -arrayOfFloat[2][5] + arrayOfFloat[1][0] * q[2];
      paramArrayOffloat3[paramInt1 + 3] = arrayOfFloat[2][5] * q[2] + arrayOfFloat[1][0];
      paramArrayOffloat3[paramInt1 + 4] = arrayOfFloat[2][4] * q[1] + arrayOfFloat[1][1];
      paramArrayOffloat3[paramInt1 + 5] = arrayOfFloat[2][3] * q[0] + arrayOfFloat[1][2];
      paramArrayOffloat3[paramInt1 + 6] = arrayOfFloat[2][2] * q[0];
      paramArrayOffloat3[paramInt1 + 7] = arrayOfFloat[2][1] * q[1];
      paramArrayOffloat3[paramInt1 + 8] = arrayOfFloat[2][0] * q[2];
      paramArrayOffloat3[paramInt1 + 9] = arrayOfFloat[2][0];
      paramArrayOffloat3[paramInt1 + 10] = arrayOfFloat[2][1];
      paramArrayOffloat3[paramInt1 + 11] = arrayOfFloat[2][2];
      paramArrayOffloat3[paramInt1 + 12] = 0.0F;
      paramArrayOffloat3[paramInt1 + 13] = 0.0F;
      paramArrayOffloat3[paramInt1 + 14] = 0.0F;
      paramArrayOffloat3[paramInt1 + 15] = 0.0F;
      paramArrayOffloat3[paramInt1 + 16] = 0.0F;
      paramArrayOffloat3[paramInt1 + 17] = 0.0F;
    } 
  }
  
  private static void if(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt) {
    float f5 = paramArrayOffloat2[paramInt + 0] - paramArrayOffloat2[paramInt + 12] + paramArrayOffloat2[paramInt + 9];
    float f1 = paramArrayOffloat2[paramInt + 0] + (paramArrayOffloat2[paramInt + 12] + paramArrayOffloat2[paramInt + 9]) * t[1];
    float f2 = (paramArrayOffloat2[paramInt + 3] + paramArrayOffloat2[paramInt + 6]) * t[0];
    float f4 = f1 + f2;
    float f6 = f1 - f2;
    float f10 = paramArrayOffloat2[paramInt + 3] + paramArrayOffloat2[paramInt + 0];
    float f11 = paramArrayOffloat2[paramInt + 9] + paramArrayOffloat2[paramInt + 6];
    float f12 = paramArrayOffloat2[paramInt + 15] + paramArrayOffloat2[paramInt + 12] + f11;
    float f8 = f10 - f12;
    f1 = (f11 + f10) * t[0];
    f2 = f10 + f12 * t[1];
    float f9 = f2 + f1;
    float f7 = f2 - f1;
    f1 = f9 * n[0];
    f2 = f8 * n[1];
    float f3 = f7 * n[2];
    paramArrayOffloat1[0] = w[0] * (f1 + f4);
    paramArrayOffloat1[1] = w[1] * (f2 + f5);
    paramArrayOffloat1[2] = w[2] * (f3 + f6);
    paramArrayOffloat1[3] = w[3] * (f3 - f6);
    paramArrayOffloat1[4] = w[4] * (f2 - f5);
    paramArrayOffloat1[5] = w[5] * (f1 - f4);
  }
  
  private static void a(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt) {
    float f18 = paramArrayOffloat2[paramInt + 17];
    float f17 = paramArrayOffloat2[paramInt + 16];
    f18 += f17;
    float f16 = paramArrayOffloat2[paramInt + 15];
    float f15 = paramArrayOffloat2[paramInt + 14];
    f17 += f16;
    f16 += f15;
    f18 += f16;
    float f14 = paramArrayOffloat2[paramInt + 13];
    float f13 = paramArrayOffloat2[paramInt + 12];
    f15 += f14;
    f14 += f13;
    f16 += f14;
    float f12 = paramArrayOffloat2[paramInt + 11];
    float f11 = paramArrayOffloat2[paramInt + 10];
    f13 += f12;
    f12 += f11;
    f14 += f12;
    float f10 = paramArrayOffloat2[paramInt + 9];
    float f9 = paramArrayOffloat2[paramInt + 8];
    f11 += f10;
    f10 += f9;
    f12 += f10;
    float f8 = paramArrayOffloat2[paramInt + 7];
    float f7 = paramArrayOffloat2[paramInt + 6];
    f9 += f8;
    f8 += f7;
    f10 += f8;
    float f6 = paramArrayOffloat2[paramInt + 5];
    float f5 = paramArrayOffloat2[paramInt + 4];
    f7 += f6;
    f6 += f5;
    f8 += f6;
    float f4 = paramArrayOffloat2[paramInt + 3];
    float f3 = paramArrayOffloat2[paramInt + 2];
    f5 += f4;
    f4 += f3;
    f6 += f4;
    float f2 = paramArrayOffloat2[paramInt + 1];
    float f1 = paramArrayOffloat2[paramInt + 0];
    f3 += f2;
    f2 += f1;
    f4 += f2;
    float f19 = o[0] * (f3 + f11);
    float f20 = o[0] * (f4 + f12);
    float f21 = o[1] * f7;
    float f22 = o[1] * f8;
    float f25 = o[3] * (f15 - f11);
    float f26 = o[3] * (f16 - f12);
    float f27 = f3 - f11 - f15;
    float f28 = f4 - f12 - f16;
    float f23 = o[2] * (f15 + f3);
    float f24 = o[2] * (f4 + f16);
    f15 = f21 + f19 + f25;
    f16 = f22 + f20 + f26;
    f11 = f27 * o[1];
    f12 = f28 * o[1];
    f7 = f25 + f23 - f21;
    f8 = f26 + f24 - f22;
    f3 = f19 - f21 - f23;
    f4 = f20 - f22 - f24;
    f19 = o[4] * (f5 + f9);
    f20 = o[4] * (f6 + f10);
    f23 = o[6] * f13 + f1;
    f24 = o[6] * f14 + f2;
    f25 = o[7] * (f17 - f9);
    f26 = o[7] * (f18 - f10);
    f27 = f9 + f17 - f5;
    f28 = f10 + f18 - f6;
    float f29 = f1 - f13;
    float f30 = f2 - f14;
    f21 = o[5] * (f5 + f17);
    f22 = o[5] * (f6 + f18);
    f1 = f23 + f19 + f25;
    f2 = f24 + f20 + f26;
    f5 = f29 - f27 * o[6];
    f6 = f30 - f28 * o[6];
    f9 = f23 - f19 + f21;
    f10 = f24 - f20 + f22;
    f13 = f23 - f21 - f25;
    f14 = f24 - f22 - f26;
    f17 = f29 + f27;
    f18 = f30 + f28;
    float f31 = f1;
    float f32 = f2;
    f1 = f31 + f15;
    f2 = f32 + f16;
    f15 = f31 - f15;
    f16 = f32 - f16;
    float f33 = f16 * r[8];
    paramArrayOffloat1[9] = (f33 - f15) * v[9];
    paramArrayOffloat1[8] = (f33 + f15) * v[8];
    f31 = f5;
    f32 = f6;
    f5 = f31 + f11;
    f6 = f32 + f12;
    f11 = f31 - f11;
    f12 = f32 - f12;
    f33 = f2 * r[0];
    float f34 = f6 * r[1];
    paramArrayOffloat1[0] = (f33 + f1) * v[0];
    paramArrayOffloat1[1] = (f34 + f5) * v[1];
    paramArrayOffloat1[16] = (f34 - f5) * v[16];
    paramArrayOffloat1[17] = (f33 - f1) * v[17];
    f31 = f9;
    f32 = f10;
    f9 = f31 + f7;
    f10 = f32 + f8;
    f7 = f31 - f7;
    f8 = f32 - f8;
    f33 = f8 * r[6];
    f34 = f12 * r[7];
    paramArrayOffloat1[6] = (f33 + f7) * v[6];
    paramArrayOffloat1[7] = (f34 + f11) * v[7];
    paramArrayOffloat1[10] = (f34 - f11) * v[10];
    paramArrayOffloat1[11] = (f33 - f7) * v[11];
    f31 = f13;
    f32 = f14;
    f13 = f31 + f3;
    f14 = f32 + f4;
    f3 = f31 - f3;
    f4 = f32 - f4;
    f33 = f10 * r[2];
    f34 = f14 * r[3];
    paramArrayOffloat1[2] = (f33 + f9) * v[2];
    paramArrayOffloat1[3] = (f34 + f13) * v[3];
    paramArrayOffloat1[14] = (f34 - f13) * v[14];
    paramArrayOffloat1[15] = (f33 - f9) * v[15];
    f33 = f18 * r[4];
    f34 = f4 * r[5];
    paramArrayOffloat1[4] = (f33 + f17) * v[4];
    paramArrayOffloat1[5] = (f34 + f3) * v[5];
    paramArrayOffloat1[12] = (f34 - f3) * v[12];
    paramArrayOffloat1[13] = (f33 - f17) * v[13];
  }
}


/* Location:              /home/jim_bug/rvm-robot/!/codecLib/mpa/h.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */