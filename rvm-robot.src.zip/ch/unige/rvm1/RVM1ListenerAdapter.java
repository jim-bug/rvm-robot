/*
 * User: jelmini8
 * Date: Jan 9, 2002
 * Time: 6:20:29 PM
 */
package ch.unige.rvm1;

public class RVM1ListenerAdapter implements RVM1Listener {

    public void busy() {
    }

    public void error(int errType, String command, String message) {
    }

    public void ready() {
    }
}
