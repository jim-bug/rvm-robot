/*    */ package ch.unige.rvm1;
/*    */ 
/*    */ import gnu.io.SerialPortEvent;
/*    */ import gnu.io.SerialPortEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements SerialPortEventListener
/*    */ {
/*    */   public void serialEvent(SerialPortEvent paramSerialPortEvent) {
/* 28 */     if (paramSerialPortEvent.getEventType() == 6 && SerialConnection.this._serialPort
/* 29 */       .isCD() && !SerialConnection.this._ready) {
/* 30 */       SerialConnection.this._ready = true;
/* 31 */       SerialConnection.this.notifyState(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/ch/unige/rvm1/SerialConnection$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */