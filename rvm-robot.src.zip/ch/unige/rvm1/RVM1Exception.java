/*
 * User: jelmini8
 * Date: Dec 1, 2001
 * Time: 3:38:56 PM
 */
package ch.unige.rvm1;

public class RVM1Exception extends Exception {

    public RVM1Exception() {
    }

    public RVM1Exception(String s) {
        super(s);
    }
}
