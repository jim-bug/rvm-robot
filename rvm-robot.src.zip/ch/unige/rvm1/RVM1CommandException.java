/*
 * User: jelmini8
 * Date: Jan 9, 2002
 * Time: 10:26:18 AM
 */
package ch.unige.rvm1;

public class RVM1CommandException extends Exception {

    public RVM1CommandException() {
    }

    public RVM1CommandException(String s) {
        super(s);
    }
}
