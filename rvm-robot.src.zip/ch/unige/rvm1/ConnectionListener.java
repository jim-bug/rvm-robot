/*
 * User: jelmini8
 * Date: Dec 22, 2001
 * Time: 3:13:40 PM
 */
package ch.unige.rvm1;

public interface ConnectionListener {
    void stateChanged(boolean ready);
}
