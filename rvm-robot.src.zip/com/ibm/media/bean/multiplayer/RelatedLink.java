/*    */ package com.ibm.media.bean.multiplayer;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelatedLink
/*    */ {
/*    */   public String link;
/* 31 */   public long startTime = 0L;
/* 32 */   public long stopTime = 0L;
/* 33 */   public URL uLink = null;
/*    */   public String description;
/* 35 */   private MultiPlayerBean owner = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RelatedLink(String rl, long st, long et, MultiPlayerBean o) throws MalformedURLException {
/* 50 */     this.owner = o;
/* 51 */     this.uLink = this.owner.getURL(rl);
/* 52 */     if (this.uLink == null)
/*    */     {
/* 54 */       throw new MalformedURLException();
/*    */     }
/* 56 */     this.link = rl;
/* 57 */     this.startTime = st;
/* 58 */     this.stopTime = et;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLink(String l) {
/* 67 */     this.link = l;
/* 68 */     this.uLink = this.owner.getURL(l);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/bean/multiplayer/RelatedLink.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */