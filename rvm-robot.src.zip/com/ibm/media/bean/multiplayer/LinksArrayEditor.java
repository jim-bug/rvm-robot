/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.awt.Button;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Label;
/*     */ import java.awt.List;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.TextField;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.beans.PropertyEditor;
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinksArrayEditor
/*     */   extends PropertyEditorSupport
/*     */   implements PropertyEditor, Serializable, ActionListener, ItemListener
/*     */ {
/*  84 */   PropertyChangeSupport support = new PropertyChangeSupport(this);
/*  85 */   Panel linksPanel = new Panel();
/*     */   transient String[] oldValue;
/*  87 */   List mediaGroup = new List(5); transient String[] newValue;
/*  88 */   List related = new List(5);
/*  89 */   List start = new List(5);
/*  90 */   List stop = new List(5);
/*  91 */   TextField relatedField = new TextField(20);
/*  92 */   TextField startField = new TextField(3);
/*  93 */   TextField stopField = new TextField(3);
/*  94 */   TextField mediaNumField = new TextField(3);
/*  95 */   Button addLink = new Button(JMFUtil.getBIString("ADD"));
/*  96 */   Button delLink = new Button(JMFUtil.getBIString("DELETE"));
/*  97 */   Label mediaLabel = new Label(JMFUtil.getBIString("MEDIA_GROUP"));
/*  98 */   Label linkLabel = new Label(JMFUtil.getBIString("RELATED_LINK_URL"));
/*  99 */   Label startLabel = new Label(JMFUtil.getBIString("START_TIME"));
/* 100 */   Label stopLabel = new Label(JMFUtil.getBIString("STOP_TIME"));
/* 101 */   Panel pan = null;
/*     */ 
/*     */   
/* 104 */   String addLinkC = "addLink";
/* 105 */   String delLinkC = "delLink";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getCustomEditor() {
/* 113 */     if (this.pan == null)
/* 114 */       this.pan = createGuiPanel(); 
/* 115 */     return this.pan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintValue(Graphics g, Rectangle r) {
/* 125 */     g.setColor(Color.black);
/* 126 */     g.draw3DRect(1, 1, r.width - 2, r.height - 2, true);
/* 127 */     g.setColor(Color.black);
/* 128 */     g.setFont(new Font("Helevetica", 1, 9));
/* 129 */     g.drawString(getAsText(), 5, r.height / 2 + 5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsCustomEditor() {
/* 138 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAsText(String s) {
/* 149 */     setValue(JMFUtil.parseStringIntoArray(s));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAsText() {
/* 162 */     return JMFUtil.parseArrayIntoString(this.newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaInitializationString() {
/* 178 */     StringBuffer initString = new StringBuffer("");
/*     */     
/* 180 */     if (this.newValue == null) return "null";
/*     */ 
/*     */     
/* 183 */     initString = new StringBuffer("new String[] {\"");
/* 184 */     for (int i = 0; i < this.newValue.length; i++) {
/*     */       
/* 186 */       initString.append(JMFUtil.convertString(this.newValue[i]));
/* 187 */       if (i + 1 != this.newValue.length)
/*     */       {
/* 189 */         initString.append("\",\"");
/*     */       }
/*     */     } 
/* 192 */     initString.append("\"}");
/*     */     
/* 194 */     return initString.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPaintable() {
/* 204 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Object val) {
/* 214 */     this.oldValue = this.newValue;
/* 215 */     if (val instanceof String)
/* 216 */     { this.newValue = JMFUtil.parseStringIntoArray((String)val); }
/* 217 */     else { this.newValue = (String[])val; }
/* 218 */      firePropertyChange();
/* 219 */     this.support.firePropertyChange("links", (Object)null, this.newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 231 */     return this.newValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Panel createGuiPanel() {
/* 241 */     GridBagLayout gridbag = new GridBagLayout();
/* 242 */     GridBagConstraints c = new GridBagConstraints();
/* 243 */     this.linksPanel.setLayout(gridbag);
/* 244 */     this.linksPanel.setBackground(Color.lightGray);
/* 245 */     this.linksPanel.setForeground(Color.black);
/*     */     
/* 247 */     this.delLink.setEnabled(false);
/*     */     
/* 249 */     this.linksPanel.setLayout(gridbag);
/* 250 */     refreshLists();
/*     */ 
/*     */     
/* 253 */     c.gridx = 1;
/* 254 */     c.gridy = 1;
/* 255 */     c.gridwidth = 1;
/* 256 */     c.gridheight = 1;
/* 257 */     c.anchor = 17;
/* 258 */     c.fill = 0;
/* 259 */     c.weightx = 0.0D;
/* 260 */     c.weighty = 0.0D;
/* 261 */     this.linksPanel.add(this.mediaLabel, c);
/*     */ 
/*     */     
/* 264 */     c.gridx = 2;
/* 265 */     c.gridy = 1;
/* 266 */     c.gridwidth = 3;
/* 267 */     c.gridheight = 1;
/* 268 */     c.anchor = 17;
/* 269 */     c.fill = 0;
/* 270 */     c.weightx = 0.0D;
/* 271 */     c.weighty = 0.0D;
/* 272 */     this.linksPanel.add(this.linkLabel, c);
/*     */ 
/*     */     
/* 275 */     c.gridx = 5;
/* 276 */     c.gridy = 1;
/* 277 */     c.gridwidth = 1;
/* 278 */     c.gridheight = 1;
/* 279 */     c.anchor = 17;
/* 280 */     c.fill = 0;
/* 281 */     c.weightx = 0.0D;
/* 282 */     c.weighty = 0.0D;
/* 283 */     this.linksPanel.add(this.startLabel, c);
/*     */ 
/*     */     
/* 286 */     c.gridx = 6;
/* 287 */     c.gridy = 1;
/* 288 */     c.gridwidth = 1;
/* 289 */     c.gridheight = 1;
/* 290 */     c.anchor = 17;
/* 291 */     c.fill = 0;
/* 292 */     c.weightx = 0.0D;
/* 293 */     c.weighty = 0.0D;
/* 294 */     this.linksPanel.add(this.stopLabel, c);
/*     */ 
/*     */     
/* 297 */     c.gridx = 1;
/* 298 */     c.gridy = 2;
/* 299 */     c.gridwidth = 1;
/* 300 */     c.gridheight = 5;
/* 301 */     c.anchor = 17;
/* 302 */     c.fill = 3;
/* 303 */     c.weightx = 1.0D;
/* 304 */     c.weighty = 0.0D;
/* 305 */     this.mediaGroup.addItemListener(this);
/* 306 */     this.linksPanel.add(this.mediaGroup, c);
/*     */ 
/*     */     
/* 309 */     c.gridx = 2;
/* 310 */     c.gridy = 2;
/* 311 */     c.gridwidth = 3;
/* 312 */     c.gridheight = 5;
/* 313 */     c.anchor = 17;
/* 314 */     c.fill = 1;
/* 315 */     c.weightx = 1.0D;
/* 316 */     c.weighty = 1.0D;
/* 317 */     this.related.addItemListener(this);
/* 318 */     this.linksPanel.add(this.related, c);
/*     */ 
/*     */     
/* 321 */     c.gridx = 5;
/* 322 */     c.gridy = 2;
/* 323 */     c.gridwidth = 1;
/* 324 */     c.gridheight = 5;
/* 325 */     c.anchor = 17;
/* 326 */     c.fill = 3;
/* 327 */     c.weightx = 1.0D;
/* 328 */     c.weighty = 0.0D;
/* 329 */     this.start.addItemListener(this);
/* 330 */     this.linksPanel.add(this.start, c);
/*     */ 
/*     */     
/* 333 */     c.gridx = 6;
/* 334 */     c.gridy = 2;
/* 335 */     c.gridwidth = 1;
/* 336 */     c.gridheight = 5;
/* 337 */     c.anchor = 17;
/* 338 */     c.fill = 3;
/* 339 */     c.weightx = 1.0D;
/* 340 */     c.weighty = 0.0D;
/* 341 */     this.stop.addItemListener(this);
/* 342 */     this.linksPanel.add(this.stop, c);
/*     */ 
/*     */     
/* 345 */     c.gridx = 1;
/* 346 */     c.gridy = 7;
/* 347 */     c.gridwidth = 1;
/* 348 */     c.gridheight = 1;
/* 349 */     c.insets = new Insets(1, 1, 1, 1);
/* 350 */     c.anchor = 10;
/* 351 */     c.fill = 0;
/* 352 */     c.weightx = 0.0D;
/* 353 */     c.weighty = 0.0D;
/* 354 */     this.linksPanel.add(this.mediaNumField, c);
/*     */ 
/*     */     
/* 357 */     c.gridx = 2;
/* 358 */     c.gridy = 7;
/* 359 */     c.gridwidth = 1;
/* 360 */     c.gridheight = 1;
/* 361 */     c.insets = new Insets(1, 1, 1, 1);
/* 362 */     c.anchor = 17;
/* 363 */     c.fill = 0;
/* 364 */     c.weightx = 0.0D;
/* 365 */     c.weighty = 0.0D;
/* 366 */     this.linksPanel.add(new Label("http://"), c);
/*     */ 
/*     */     
/* 369 */     c.gridx = 3;
/* 370 */     c.gridy = 7;
/* 371 */     c.gridwidth = 2;
/* 372 */     c.gridheight = 1;
/* 373 */     c.insets = new Insets(1, 1, 1, 1);
/* 374 */     c.anchor = 10;
/* 375 */     c.fill = 2;
/* 376 */     c.weightx = 0.0D;
/* 377 */     c.weighty = 1.0D;
/* 378 */     this.linksPanel.add(this.relatedField, c);
/*     */ 
/*     */     
/* 381 */     c.gridx = 5;
/* 382 */     c.gridy = 7;
/* 383 */     c.gridwidth = 1;
/* 384 */     c.gridheight = 1;
/* 385 */     c.insets = new Insets(1, 1, 1, 1);
/* 386 */     c.anchor = 10;
/* 387 */     c.fill = 0;
/* 388 */     c.weightx = 0.0D;
/* 389 */     c.weighty = 0.0D;
/* 390 */     this.linksPanel.add(this.startField, c);
/*     */ 
/*     */     
/* 393 */     c.gridx = 6;
/* 394 */     c.gridy = 7;
/* 395 */     c.gridwidth = 1;
/* 396 */     c.gridheight = 1;
/* 397 */     c.insets = new Insets(1, 1, 1, 1);
/* 398 */     c.anchor = 10;
/* 399 */     c.fill = 0;
/* 400 */     c.weightx = 0.0D;
/* 401 */     c.weighty = 0.0D;
/* 402 */     this.linksPanel.add(this.stopField, c);
/*     */ 
/*     */     
/* 405 */     c.gridx = 1;
/* 406 */     c.gridy = 9;
/* 407 */     c.gridwidth = 1;
/* 408 */     c.gridheight = 1;
/* 409 */     c.insets = new Insets(1, 1, 1, 1);
/* 410 */     c.anchor = 10;
/* 411 */     c.fill = 0;
/* 412 */     c.weightx = 0.0D;
/* 413 */     c.weighty = 0.0D;
/* 414 */     this.addLink.addActionListener(this);
/* 415 */     this.addLink.setActionCommand(this.addLinkC);
/* 416 */     this.linksPanel.add(this.addLink, c);
/*     */ 
/*     */     
/* 419 */     c.gridx = 2;
/* 420 */     c.gridy = 9;
/* 421 */     c.gridwidth = 1;
/* 422 */     c.gridheight = 1;
/* 423 */     c.insets = new Insets(1, 1, 1, 1);
/* 424 */     c.anchor = 10;
/* 425 */     c.fill = 0;
/* 426 */     c.weightx = 0.0D;
/* 427 */     c.weighty = 0.0D;
/* 428 */     this.delLink.addActionListener(this);
/* 429 */     this.delLink.setActionCommand(this.delLinkC);
/* 430 */     this.linksPanel.add(this.delLink, c);
/*     */     
/* 432 */     return this.linksPanel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void refreshLists() {
/* 442 */     this.mediaGroup.removeAll();
/* 443 */     this.related.removeAll();
/* 444 */     this.start.removeAll();
/* 445 */     this.stop.removeAll();
/*     */     
/* 447 */     if (this.newValue != null) {
/* 448 */       for (int i = 0; i < this.newValue.length; i += 4) {
/*     */         
/* 450 */         this.mediaGroup.add(this.newValue[i]);
/* 451 */         this.related.add(this.newValue[i + 1]);
/* 452 */         this.start.add(this.newValue[i + 2]);
/* 453 */         this.stop.add(this.newValue[i + 3]);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 469 */     if (e.getActionCommand().equals(this.addLinkC)) {
/*     */       
/* 471 */       processAdd();
/*     */     
/*     */     }
/* 474 */     else if (e.getActionCommand().equals(this.delLinkC)) {
/*     */       
/* 476 */       deleteLink();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void itemStateChanged(ItemEvent e) {
/* 491 */     Object o1 = e.getItemSelectable();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 496 */     if (o1 instanceof List) {
/*     */       
/* 498 */       List l1 = (List)o1;
/* 499 */       int i = ((Integer)e.getItem()).intValue();
/* 500 */       int state = e.getStateChange();
/*     */       
/* 502 */       if (l1 == this.related || l1 == this.start || l1 == this.stop || l1 == this.mediaGroup) {
/*     */         
/* 504 */         l1 = this.related;
/* 505 */         List l2 = this.start;
/* 506 */         List l3 = this.stop;
/* 507 */         List l4 = this.mediaGroup;
/*     */ 
/*     */         
/* 510 */         if (state == 1) {
/*     */           
/* 512 */           l1.select(i);
/* 513 */           l2.select(i);
/* 514 */           l3.select(i);
/* 515 */           l4.select(i);
/* 516 */           this.delLink.setEnabled(true);
/*     */         
/*     */         }
/* 519 */         else if (state == 2) {
/*     */           
/* 521 */           l1.deselect(i);
/* 522 */           l2.deselect(i);
/* 523 */           l3.deselect(i);
/* 524 */           l4.deselect(i);
/* 525 */           this.delLink.setEnabled(false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processAdd() {
/*     */     long startTime, stopTime;
/*     */     int mediaIndex;
/* 538 */     StringBuffer relatedBuffer = new StringBuffer("http://");
/* 539 */     String mString = this.mediaNumField.getText();
/* 540 */     String rString = this.relatedField.getText();
/* 541 */     String startString = this.startField.getText();
/* 542 */     String stopString = this.stopField.getText();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 547 */     if (startString.equals("") && stopString.equals("")) {
/*     */       
/* 549 */       startString = new String("0");
/* 550 */       stopString = new String("0");
/*     */     } 
/*     */ 
/*     */     
/* 554 */     if (mString.equals("") || rString.equals("") || startString.equals("") || stopString.equals("")) {
/*     */       
/* 556 */       DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("NOVALUE"));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 563 */       startTime = Long.parseLong(startString);
/* 564 */       stopTime = Long.parseLong(stopString);
/*     */     } catch (NumberFormatException e) {
/*     */       
/* 567 */       DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("TIMES") + ": " + JMFUtil.getBIString("0orGreater"));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 573 */       mediaIndex = Integer.parseInt(mString);
/*     */     } catch (NumberFormatException e) {
/*     */       
/* 576 */       DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("INDEX") + ": " + JMFUtil.getBIString("1orGreater"));
/*     */       
/*     */       return;
/*     */     } 
/* 580 */     if (startTime < 0L || stopTime < 0L) {
/*     */       
/* 582 */       DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("TIMES") + ": " + JMFUtil.getBIString("0orGreater"));
/*     */       
/*     */       return;
/*     */     } 
/* 586 */     if (mediaIndex < 1) {
/*     */       
/* 588 */       DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("INDEX") + ": " + JMFUtil.getBIString("1orGreater"));
/*     */       
/*     */       return;
/*     */     } 
/* 592 */     relatedBuffer.append(rString);
/*     */     
/* 594 */     if (duplicate(mString, relatedBuffer.toString(), startString, stopString)) {
/*     */       
/* 596 */       DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("DUPLICATE_LINK"));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 602 */     int l = 0;
/*     */     
/* 604 */     if (this.newValue != null) {
/* 605 */       l = this.newValue.length;
/*     */     }
/* 607 */     String[] temp = new String[l + 4];
/* 608 */     JMFUtil.copyStringArray(this.newValue, temp);
/*     */ 
/*     */     
/* 611 */     temp[l] = mString;
/* 612 */     temp[l + 1] = relatedBuffer.toString();
/* 613 */     temp[l + 2] = startString;
/* 614 */     temp[l + 3] = stopString;
/* 615 */     this.mediaGroup.add(temp[l]);
/* 616 */     this.related.add(temp[l + 1]);
/* 617 */     this.start.add(temp[l + 2]);
/* 618 */     this.stop.add(temp[l + 3]);
/* 619 */     this.mediaNumField.setText("");
/* 620 */     this.relatedField.setText("");
/* 621 */     this.startField.setText("");
/* 622 */     this.stopField.setText("");
/* 623 */     setValue(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean duplicate(String media, String relatedS, String startS, String stopS) {
/* 637 */     for (int i = 0; i < this.mediaGroup.getItemCount(); i++) {
/*     */       
/* 639 */       if ((media.equals(this.mediaGroup.getItem(i)) & relatedS.equals(this.related.getItem(i)) & startS.equals(this.start.getItem(i)) & stopS.equals(this.stop.getItem(i))) != 0)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 644 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 648 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deleteLink() {
/* 658 */     String[] temp = null;
/* 659 */     int j = this.mediaGroup.getSelectedIndex();
/* 660 */     int index = j * 4;
/* 661 */     int newSize = 0;
/*     */ 
/*     */     
/* 664 */     if (this.newValue != null) {
/*     */       
/* 666 */       newSize = this.newValue.length - 4;
/* 667 */       if (newSize > 4) {
/*     */         
/* 669 */         temp = new String[newSize];
/* 670 */         JMFUtil.copyShortenStringArray(this.newValue, temp, index, 4);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 675 */     this.mediaGroup.remove(j);
/* 676 */     this.related.remove(j);
/* 677 */     this.start.remove(j);
/* 678 */     this.stop.remove(j);
/*     */     
/* 680 */     this.delLink.setEnabled(false);
/*     */ 
/*     */     
/* 683 */     setValue(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 698 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 711 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/bean/multiplayer/LinksArrayEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */