/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.image.FilteredImageSource;
/*     */ import java.awt.image.ImageFilter;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageButton
/*     */   extends ImageLabel
/*     */ {
/*     */   protected static final int defaultBorderWidth = 4;
/*  58 */   protected static final Color defaultBorderColor = new Color(160, 160, 160);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean txtButton = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mouseIsDown = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String actionCommand;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient ActionListener actionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient MouseListener mouseListener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient MouseMotionListener mouseMotionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int darkness;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Image grayImage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageButton(String imageURLString)
/*     */   {
/* 113 */     super(imageURLString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 371 */     this.darkness = -5263441;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 390 */     this.grayImage = null; enableEvents(144L); setBorders(); } public ImageButton(URL imageURL) { super(imageURL); this.darkness = -5263441; this.grayImage = null; enableEvents(144L); setBorders(); } public ImageButton(URL imageDirectory, String imageFile) { super(imageDirectory, imageFile); this.darkness = -5263441; this.grayImage = null; enableEvents(144L); setBorders(); } public ImageButton(Image image) { super(image); this.darkness = -5263441; this.grayImage = null; enableEvents(144L); setBorders(); } public void waitForImage(boolean doLayout) { if (this.txtButton) { resize(this.width, this.height); this.doneLoading = true; return; }  super.waitForImage(doLayout); } public void paint(Graphics g) { if (!this.doneLoading) { waitForImage(true); } else if (!this.txtButton) { if (this.explicitSize) { g.drawImage(this.image, this.border, this.border, this.width - 2 * this.border, this.height - 2 * this.border, this); } else { g.drawImage(this.image, this.border, this.border, this); }  drawRect(g, 0, 0, this.width - 1, this.height - 1, this.border, this.borderColor); if (this.grayImage == null) createGrayImage(g);  } else { int tsize = this.text.length * 9 / 2; g.drawChars(this.text, 0, this.text.length, this.width / 2 - tsize, this.height / 2 + 5); }  drawBorder(true); } public void setActionCommand(String command) { this.actionCommand = command; } public String getActionCommand() { return this.actionCommand; } public synchronized void addActionListener(ActionListener l) { debug("[addActionListener]: " + l); this.actionListener = AWTEventMulticaster.add(this.actionListener, l); this.newEventsOnly = true; } public synchronized void removeActionListener(ActionListener l) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, l); } public ImageButton() { this.darkness = -5263441; this.grayImage = null; enableEvents(144L); setBorders(); } protected void processEvent(AWTEvent e) { debug("[processEvent]: " + e); if (e instanceof ActionEvent) { processActionEvent((ActionEvent)e); return; }  if (e instanceof MouseEvent) { processMouseEvent((MouseEvent)e); return; }  super.processEvent(e); } protected void processMouseEvent(MouseEvent e) { if (e.getID() == 502) { this.mouseIsDown = false; paint(getGraphics()); processEvent(new ActionEvent(this, 1001, this.actionCommand)); } else if (e.getID() == 501) { this.mouseIsDown = true; Graphics g = getGraphics(); int border = getBorder(); if (!this.txtButton) if (hasExplicitSize()) { g.drawImage(getGrayImage(), border, border, getWidth() - 2 * border, getHeight() - 2 * border, this); } else { g.drawImage(getGrayImage(), border, border, this); }   drawBorder(false); } else if (e.getID() == 505) { if (this.mouseIsDown) paint(getGraphics());  }  super.processMouseEvent(e); } protected void processActionEvent(ActionEvent e) { debug("Action Event occurred."); if (this.actionListener != null) this.actionListener.actionPerformed(e);  } protected void setText(String t) { if (this.txtButton) { this.text = new char[t.length()]; t.getChars(0, t.length(), this.text, 0); paint(getGraphics()); validate(); }  } public int getDarkness() { return this.darkness; } public void setDarkness(int darkness) { this.darkness = darkness; } public ImageButton(String text, boolean txt, int width, int height) { this.darkness = -5263441; this.grayImage = null; this.width = width; this.height = height; if (txt) {
/*     */       int length = text.length(); this.text = new char[length]; text.getChars(0, length, this.text, 0); this.txtButton = txt;
/*     */     }  enableEvents(144L);
/*     */     setBorders(); } public Image getGrayImage() { return this.grayImage; }
/*     */   public void setGrayImage(Image grayImage) { this.grayImage = grayImage; }
/* 395 */   public void drawBorder(boolean isUp) { Graphics g = getGraphics();
/* 396 */     if (g == null)
/* 397 */       return;  g.setColor(getBorderColor());
/* 398 */     int left = 0;
/* 399 */     int top = 0;
/* 400 */     int width = getWidth();
/* 401 */     int height = getHeight();
/* 402 */     int border = getBorder();
/* 403 */     for (int i = 0; i < border; i++) {
/* 404 */       g.draw3DRect(left, top, width, height, isUp);
/* 405 */       left++;
/* 406 */       top++;
/* 407 */       width -= 2;
/* 408 */       height -= 2;
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setBorders() {
/* 415 */     setBorder(4);
/* 416 */     setBorderColor(defaultBorderColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createGrayImage(Graphics g) {
/* 426 */     ImageFilter filter = new GrayFilter(this.darkness);
/* 427 */     ImageProducer producer = new FilteredImageSource(getImage().getSource(), filter);
/*     */ 
/*     */     
/* 430 */     this.grayImage = createImage(producer);
/* 431 */     int border = getBorder();
/* 432 */     if (hasExplicitSize()) {
/* 433 */       prepareImage(this.grayImage, getWidth() - 2 * border, getHeight() - 2 * border, this);
/*     */     } else {
/*     */       
/* 436 */       prepareImage(this.grayImage, this);
/* 437 */     }  super.paint(g);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/bean/multiplayer/ImageButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */