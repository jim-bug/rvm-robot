/*    */ package com.ibm.media.controls;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.util.Hashtable;
/*    */ import javax.media.Control;
/*    */ 
/*    */ 
/*    */ public class ParametersControl
/*    */   implements Control
/*    */ {
/* 11 */   Hashtable parameters = new Hashtable();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String get(String param) {
/* 22 */     return (String)this.parameters.get(param);
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(String param, String value) {
/* 27 */     this.parameters.remove(param);
/* 28 */     this.parameters.put(param, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Component getControlComponent() {
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/controls/ParametersControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */