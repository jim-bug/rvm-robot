/*     */ package com.ibm.media.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MergingDataSource
/*     */   extends DataSource
/*     */ {
/*     */   DataSource[] sources;
/*  28 */   SourceStream[] streams = null;
/*  29 */   Object[] controls = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MergingDataSource(DataSource[] sources) {
/*  37 */     this.sources = sources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  47 */     if (this.sources.length == 1) {
/*  48 */       return this.sources[0].getContentType();
/*     */     }
/*  50 */     boolean isRaw = true;
/*     */     
/*  52 */     for (int index = 0; index < this.sources.length; index++) {
/*  53 */       if (!this.sources[index].getContentType().equals("raw")) {
/*  54 */         isRaw = false;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  59 */     if (isRaw)
/*  60 */       return "raw"; 
/*  61 */     if (this.sources.length == 1) {
/*  62 */       return this.sources[0].getContentType();
/*     */     }
/*  64 */     return "application.mixed-data";
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  69 */     for (int i = 0; i < this.sources.length; i++) {
/*  70 */       this.sources[i].connect();
/*     */     }
/*     */   }
/*     */   
/*     */   public void disconnect() {
/*  75 */     for (int i = 0; i < this.sources.length; i++) {
/*  76 */       this.sources[i].disconnect();
/*     */     }
/*     */   }
/*     */   
/*     */   public void start() throws IOException {
/*  81 */     for (int i = 0; i < this.sources.length; i++) {
/*  82 */       this.sources[i].start();
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop() throws IOException {
/*  87 */     for (int i = 0; i < this.sources.length; i++) {
/*  88 */       this.sources[i].stop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 102 */     if (this.controls == null) {
/* 103 */       Vector vcontrols = new Vector(1);
/* 104 */       for (int i = 0; i < this.sources.length; i++) {
/* 105 */         Object[] cs = this.sources[i].getControls();
/* 106 */         if (cs.length > 0) {
/* 107 */           for (int j = 0; j < cs.length; j++) {
/* 108 */             vcontrols.addElement(cs[j]);
/*     */           }
/*     */         }
/*     */       } 
/* 112 */       this.controls = new Object[vcontrols.size()];
/* 113 */       for (int c = 0; c < vcontrols.size(); c++) {
/* 114 */         this.controls[c] = vcontrols.elementAt(c);
/*     */       }
/*     */     } 
/* 117 */     return this.controls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/*     */     try {
/* 134 */       Class cls = Class.forName(controlType);
/* 135 */       Object[] cs = getControls();
/* 136 */       for (int i = 0; i < cs.length; i++) {
/* 137 */         if (cls.isInstance(cs[i]))
/* 138 */           return cs[i]; 
/*     */       } 
/* 140 */       return null;
/*     */     } catch (Exception e) {
/*     */       
/* 143 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getDuration() {
/* 159 */     Time longest = new Time(0L);
/*     */     
/* 161 */     for (int i = 0; i < this.sources.length; i++) {
/* 162 */       Time sourceDuration = this.sources[i].getDuration();
/* 163 */       if (sourceDuration.getSeconds() > longest.getSeconds()) {
/* 164 */         longest = sourceDuration;
/*     */       }
/*     */     } 
/* 167 */     return longest;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/protocol/MergingDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */