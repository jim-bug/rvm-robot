/*     */ package com.ibm.media.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.media.CaptureDeviceInfo;
/*     */ import javax.media.Time;
/*     */ import javax.media.control.FormatControl;
/*     */ import javax.media.protocol.CaptureDevice;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullBufferDataSource;
/*     */ import javax.media.protocol.PullBufferStream;
/*     */ import javax.media.protocol.SourceCloneable;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CloneableCapturePullBufferDataSource
/*     */   extends PullBufferDataSource
/*     */   implements SourceCloneable, CaptureDevice
/*     */ {
/*     */   private SuperCloneableDataSource superClass;
/*     */   
/*     */   public CloneableCapturePullBufferDataSource(PullBufferDataSource source) {
/*  34 */     this.superClass = new SuperCloneableDataSource((DataSource)source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PullBufferStream[] getStreams() {
/*  48 */     if (this.superClass.streams == null) {
/*  49 */       this.superClass.streams = (SourceStream[])new PullBufferStream[this.superClass.streamsAdapters.length];
/*  50 */       for (int i = 0; i < this.superClass.streamsAdapters.length; i++) {
/*  51 */         this.superClass.streams[i] = this.superClass.streamsAdapters[i].getAdapter();
/*     */       }
/*     */     } 
/*  54 */     return (PullBufferStream[])this.superClass.streams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource createClone() {
/*  68 */     return this.superClass.createClone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  82 */     return this.superClass.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  97 */     this.superClass.connect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 112 */     this.superClass.disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 125 */     this.superClass.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/* 135 */     this.superClass.stop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 150 */     return this.superClass.getControls();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 167 */     return this.superClass.getControl(controlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getDuration() {
/* 182 */     return this.superClass.getDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CaptureDeviceInfo getCaptureDeviceInfo() {
/* 193 */     return ((CaptureDevice)this.superClass.input).getCaptureDeviceInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormatControl[] getFormatControls() {
/* 205 */     return ((CaptureDevice)this.superClass.input).getFormatControls();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/protocol/CloneableCapturePullBufferDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */