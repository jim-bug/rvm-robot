package com.ibm.media.protocol;

public interface SourceStreamSlave {
  void connect();
  
  void disconnect();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/protocol/SourceStreamSlave.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */