/*     */ package com.ibm.media.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.media.CaptureDeviceInfo;
/*     */ import javax.media.Time;
/*     */ import javax.media.control.FormatControl;
/*     */ import javax.media.protocol.CaptureDevice;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.SourceCloneable;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CloneableCapturePullDataSource
/*     */   extends PullDataSource
/*     */   implements SourceCloneable, CaptureDevice
/*     */ {
/*     */   private SuperCloneableDataSource superClass;
/*     */   
/*     */   public CloneableCapturePullDataSource(PullDataSource source) {
/*  33 */     this.superClass = new SuperCloneableDataSource((DataSource)source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PullSourceStream[] getStreams() {
/*  47 */     if (this.superClass.streams == null) {
/*  48 */       this.superClass.streams = (SourceStream[])new PullSourceStream[this.superClass.streamsAdapters.length];
/*  49 */       for (int i = 0; i < this.superClass.streamsAdapters.length; i++) {
/*  50 */         this.superClass.streams[i] = this.superClass.streamsAdapters[i].getAdapter();
/*     */       }
/*     */     } 
/*  53 */     return (PullSourceStream[])this.superClass.streams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource createClone() {
/*  67 */     return this.superClass.createClone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  81 */     return this.superClass.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  96 */     this.superClass.connect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 111 */     this.superClass.disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 124 */     this.superClass.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/* 134 */     this.superClass.stop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 149 */     return this.superClass.getControls();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 166 */     return this.superClass.getControl(controlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getDuration() {
/* 181 */     return this.superClass.getDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CaptureDeviceInfo getCaptureDeviceInfo() {
/* 192 */     return ((CaptureDevice)this.superClass.input).getCaptureDeviceInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormatControl[] getFormatControls() {
/* 204 */     return ((CaptureDevice)this.superClass.input).getFormatControls();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/protocol/CloneableCapturePullDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */