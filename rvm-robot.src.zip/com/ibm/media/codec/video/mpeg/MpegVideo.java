/*     */ package com.ibm.media.codec.video.mpeg;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.control.FrameProcessingControl;
/*     */ import javax.media.control.QualityControl;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.format.YUVFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MpegVideo
/*     */   extends BasicCodec
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1998, 1999.";
/*     */   static final int VERSION_BUF_LEN = 70;
/*     */   static final int MPEG_INTERNAL_BUF_SIZE = 65536;
/*     */   static final int IN_STREAM_BUF_LEN = 102400;
/*     */   static final int OUT_FRAME_BUF_LEN = 270000;
/*     */   static final int NO_PICTURE = 0;
/*     */   static final int I_PICTURE = 1;
/*     */   static final int P_PICTURE = 2;
/*     */   static final int B_PICTURE = 3;
/*     */   static final int D_PICTURE = 4;
/*     */   static final int MPEG_NOERROR = 0;
/*     */   static final int MPEG_ERROR = -1;
/*     */   static final int MPEG_PARAM_ERROR = -2;
/*     */   static final int MPEG_BUF_ERROR = -3;
/*     */   static final int MPEG_ALLOC_ERROR = -4;
/*     */   static final int MPEG_EOS = -5;
/*  93 */   private Object methodsSync = new Object();
/*     */ 
/*     */   
/*  96 */   protected VideoFormat[] supportedInFormats = null;
/*  97 */   protected VideoFormat[] supportedOutFormats = null;
/*  98 */   protected VideoFormat inputFormat = null;
/*  99 */   protected VideoFormat outputFormat = null;
/*     */   
/*     */   private boolean corruptedFlag = false;
/*     */   
/*     */   private boolean firstTimeFlag = true;
/*     */   
/*     */   private boolean inputEOMFlag = false;
/*     */   private boolean processEOMFlag = false;
/*     */   private boolean resetFlag = true;
/* 108 */   private long accumulatedTimeNs = 0L;
/* 109 */   private double deltaPictureTimeNS = 0.0D;
/* 110 */   private double dAccumulatedTime = 0.0D;
/* 111 */   private long[] pdata = new long[1];
/* 112 */   private byte[] versionBuf = new byte[70];
/* 113 */   private int[] inBytesReq = new int[1];
/* 114 */   private int frameNumber = -1;
/* 115 */   private byte[] inBufByte = new byte[102400];
/* 116 */   private byte[] outBufByte = null;
/* 117 */   private int inDataOffset = 0;
/* 118 */   private int outBufOffset = 0;
/* 119 */   private int numDataBytes = 0;
/* 120 */   private int numFramesBehind = 0;
/* 121 */   private int dropCount = 0;
/*     */   
/* 123 */   private int[] imgWidth = new int[1];
/* 124 */   private int[] imgHeight = new int[1];
/* 125 */   private int[] imgType = new int[1];
/* 126 */   private int[] inBytesRead = new int[1];
/* 127 */   private int[] outBufWrote = new int[1];
/*     */ 
/*     */   
/*     */   private static boolean available;
/*     */ 
/*     */   
/*     */   private Control[] controls;
/*     */   
/*     */   private DC dc;
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 140 */       JMFSecurityManager.loadLibrary("jmutil");
/* 141 */       JMFSecurityManager.loadLibrary("jmmpegv");
/* 142 */       available = true;
/*     */     } catch (Exception e) {
/* 144 */       available = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 172 */     return "MPEG-1 Video Decoder";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/* 179 */     return (Format[])this.supportedInFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format format) {
/* 186 */     if (format == null) {
/* 187 */       return (Format[])this.supportedOutFormats;
/*     */     }
/* 189 */     if (format instanceof VideoFormat && BasicPlugIn.matches(format, (Format[])this.supportedInFormats) != null) {
/*     */ 
/*     */       
/* 192 */       VideoFormat inf = (VideoFormat)format;
/* 193 */       Dimension size = inf.getSize();
/* 194 */       if (size == null || size.width == 0 || size.height == 0) {
/* 195 */         size = new Dimension(320, 240);
/*     */       }
/*     */       
/* 198 */       int area = size.width * size.height;
/* 199 */       YUVFormat outf = new YUVFormat(size, area + (area >> 1), Format.byteArray, inf.getFrameRate(), 2, size.width, size.width >> 1, 0, area, area + (area >> 2));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 212 */       Format[] tempFormats = new Format[1];
/* 213 */       tempFormats[0] = (Format)outf;
/* 214 */       return tempFormats;
/*     */     } 
/* 216 */     return new Format[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format in) {
/* 223 */     if (!(in instanceof VideoFormat) || BasicPlugIn.matches(in, (Format[])this.supportedInFormats) == null)
/*     */     {
/* 225 */       return null;
/*     */     }
/* 227 */     this.inputFormat = (VideoFormat)in;
/* 228 */     return in;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setOutputFormat(Format out) {
/* 234 */     if (out != null && out instanceof YUVFormat && ((YUVFormat)out).getYuvType() == 2) {
/*     */       
/* 236 */       this.outputFormat = (VideoFormat)out;
/* 237 */       return out;
/*     */     } 
/* 239 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 249 */     if (!available) {
/* 250 */       throw new ResourceUnavailableException("Can't find shared library jmmpegv");
/*     */     }
/* 252 */     synchronized (this.methodsSync) {
/*     */       
/* 254 */       if (videoInitialize(this.pdata, this.versionBuf, 0, 70) != 0) {
/* 255 */         throw new ResourceUnavailableException("MPEG video decoder initialization failed");
/*     */       }
/* 257 */       available = false;
/* 258 */       this.inBytesReq[0] = 65536;
/*     */     } 
/* 260 */     float ftmp = this.inputFormat.getFrameRate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     if (ftmp > 0.0F) {
/* 268 */       this.deltaPictureTimeNS = 1.0E9D / ftmp;
/*     */     } else {
/* 270 */       this.deltaPictureTimeNS = 0.0D;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 279 */     synchronized (this.methodsSync) {
/*     */       
/* 281 */       this.corruptedFlag = false;
/* 282 */       this.inputEOMFlag = false;
/* 283 */       this.processEOMFlag = false;
/* 284 */       this.inBytesReq[0] = 65536;
/* 285 */       this.frameNumber = -1;
/* 286 */       this.inDataOffset = 0;
/* 287 */       this.outBufOffset = 0;
/* 288 */       this.numDataBytes = 0;
/* 289 */       this.numFramesBehind = 0;
/* 290 */       this.dropCount = 0;
/* 291 */       int rc = videoSeek(this.pdata[0]);
/* 292 */       if (rc != 0) {
/* 293 */         this.corruptedFlag = true;
/*     */       }
/* 295 */       this.resetFlag = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 301 */     synchronized (this.methodsSync) {
/*     */ 
/*     */       
/* 304 */       videoTerminate(this.pdata[0]);
/*     */       
/* 306 */       this.corruptedFlag = false;
/* 307 */       this.firstTimeFlag = true;
/* 308 */       this.inputEOMFlag = false;
/* 309 */       this.processEOMFlag = false;
/* 310 */       this.pdata = new long[1];
/* 311 */       this.inBytesReq[0] = 65536;
/* 312 */       this.frameNumber = -1;
/* 313 */       this.inDataOffset = 0;
/* 314 */       this.outBufOffset = 0;
/* 315 */       this.numDataBytes = 0;
/* 316 */       this.numFramesBehind = 0;
/* 317 */       this.dropCount = 0;
/* 318 */       available = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean doInit(Buffer inbuffer, Buffer outbuffer) {
/* 327 */     int[] imgWidth = new int[1];
/* 328 */     int[] imgHeight = new int[1];
/*     */ 
/*     */     
/* 331 */     Object data = inbuffer.getData();
/* 332 */     int bufLen = inbuffer.getLength();
/* 333 */     int offset = inbuffer.getOffset();
/*     */     
/* 335 */     if (bufLen < 512) {
/* 336 */       return false;
/*     */     }
/*     */     
/* 339 */     int rc = initImageParam(this.pdata[0], (byte[])data, offset, bufLen, imgWidth, imgHeight);
/* 340 */     if (rc != 0) {
/* 341 */       return false;
/*     */     }
/* 343 */     int frameWriteLen = (int)((imgWidth[0] * imgHeight[0]) * 1.5D);
/* 344 */     this.outBufByte = new byte[frameWriteLen];
/* 345 */     Dimension size = new Dimension(imgWidth[0], imgHeight[0]);
/*     */     
/* 347 */     int area = size.width * size.height;
/* 348 */     this.outputFormat = (VideoFormat)new YUVFormat(size, area + (area >> 1), Format.byteArray, this.inputFormat.getFrameRate(), 2, size.width, size.width >> 1, 0, area, area + (area >> 2));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 360 */     outbuffer.setFormat((Format)this.outputFormat);
/* 361 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inbuffer, Buffer outbuffer) {
/* 369 */     this.imgWidth[0] = 0;
/* 370 */     this.imgHeight[0] = 0;
/* 371 */     this.imgType[0] = 0;
/* 372 */     this.inBytesRead[0] = 0;
/* 373 */     this.outBufWrote[0] = 0;
/*     */     
/* 375 */     int returnResult = 0;
/*     */ 
/*     */     
/* 378 */     synchronized (this.methodsSync) {
/*     */       
/* 380 */       if (!checkInputBuffer(inbuffer)) {
/* 381 */         return 1;
/*     */       }
/*     */       
/* 384 */       if (this.processEOMFlag) {
/* 385 */         propagateEOM(outbuffer);
/* 386 */         return 0;
/*     */       } 
/* 388 */       if (this.corruptedFlag) {
/* 389 */         return 1;
/*     */       }
/*     */       
/* 392 */       if (isEOM(inbuffer)) {
/* 393 */         this.inputEOMFlag = true;
/*     */       }
/*     */       
/* 396 */       if (this.firstTimeFlag) {
/* 397 */         if (!doInit(inbuffer, outbuffer)) {
/* 398 */           return 1;
/*     */         }
/* 400 */         this.firstTimeFlag = false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 405 */       if (this.numDataBytes < this.inBytesReq[0] && !this.inputEOMFlag) {
/* 406 */         byte[] data = (byte[])inbuffer.getData();
/* 407 */         int bufLen = inbuffer.getLength();
/* 408 */         int offset = inbuffer.getOffset();
/* 409 */         int num2read = 102400 - this.numDataBytes - 1;
/*     */ 
/*     */         
/* 412 */         if (this.numDataBytes > 0 && this.inDataOffset > 0) {
/* 413 */           System.arraycopy(this.inBufByte, this.inDataOffset, this.inBufByte, 0, this.numDataBytes);
/*     */         }
/*     */         
/* 416 */         this.inDataOffset = 0;
/*     */ 
/*     */         
/* 419 */         if (num2read > bufLen) {
/* 420 */           num2read = bufLen;
/*     */         }
/* 422 */         if (num2read > 0) {
/* 423 */           System.arraycopy(data, offset, this.inBufByte, this.numDataBytes, num2read);
/*     */         }
/* 425 */         if (num2read < bufLen) {
/* 426 */           returnResult |= 0x2;
/*     */         }
/* 428 */         inbuffer.setOffset(offset + num2read);
/* 429 */         inbuffer.setLength(bufLen - num2read);
/* 430 */         if (bufLen == num2read) {
/* 431 */           inbuffer.setOffset(0);
/*     */         }
/*     */         
/* 434 */         if (num2read > 0) {
/* 435 */           this.numDataBytes += num2read;
/*     */         }
/*     */         
/* 438 */         if (this.numDataBytes < this.inBytesReq[0]) {
/* 439 */           return returnResult | 0x0 | 0x4;
/*     */         }
/*     */       }
/* 442 */       else if (this.inputEOMFlag) {
/* 443 */         if (this.processEOMFlag) {
/* 444 */           propagateEOM(outbuffer);
/* 445 */           return 0;
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 451 */         returnResult |= 0x2;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 456 */       this.frameNumber++;
/*     */       
/* 458 */       if ((inbuffer.getFlags() & 0x1000) == 0) {
/*     */         
/* 460 */         if (this.resetFlag) {
/* 461 */           this.accumulatedTimeNs = inbuffer.getTimeStamp();
/* 462 */           this.dAccumulatedTime = 1.0D * this.accumulatedTimeNs;
/* 463 */           this.resetFlag = false;
/*     */         } 
/* 465 */         outbuffer.setTimeStamp(this.accumulatedTimeNs);
/* 466 */         this.dAccumulatedTime += this.deltaPictureTimeNS;
/* 467 */         this.accumulatedTimeNs = (long)this.dAccumulatedTime;
/*     */       }
/*     */       else {
/*     */         
/* 471 */         outbuffer.setTimeStamp(inbuffer.getTimeStamp());
/*     */       } 
/*     */       
/* 474 */       outbuffer.setSequenceNumber(this.frameNumber);
/*     */ 
/*     */       
/* 477 */       outbuffer.setFlags(outbuffer.getFlags() | 0x20);
/*     */       
/* 479 */       Object outData = validateData(outbuffer, 0, true);
/* 480 */       long outBytes = getNativeData(outData);
/*     */       
/* 482 */       int rc = videoDecode(this.pdata[0], this.inBufByte, this.inDataOffset, this.numDataBytes, this.numFramesBehind, outData, outBytes, 0, this.outputFormat.getMaxDataLength(), this.imgWidth, this.imgHeight, this.imgType, this.inBytesRead, this.outBufWrote, this.inBytesReq);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 508 */       if (rc != 0) {
/* 509 */         if (rc == -5) {
/* 510 */           propagateEOM(outbuffer);
/*     */           
/* 512 */           this.processEOMFlag = true;
/* 513 */           return 0;
/*     */         } 
/* 515 */         System.out.println("MPEG VIDEO: decode process error  rc:" + rc);
/* 516 */         System.out.flush();
/* 517 */         this.corruptedFlag = true;
/* 518 */         return 1;
/*     */       } 
/*     */ 
/*     */       
/* 522 */       updateOutput(outbuffer, (Format)this.outputFormat, this.outBufWrote[0], 0);
/*     */ 
/*     */       
/* 525 */       this.numDataBytes -= this.inBytesRead[0];
/* 526 */       this.inDataOffset += this.inBytesRead[0];
/* 527 */       if (this.outBufWrote[0] == 0) {
/* 528 */         outbuffer.setDiscard(true);
/* 529 */         returnResult |= 0x4;
/* 530 */         if (this.imgType[0] != 0) {
/* 531 */           this.dropCount++;
/*     */         }
/*     */       } 
/*     */       
/* 535 */       return returnResult | 0x0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MpegVideo()
/*     */   {
/* 544 */     this.controls = null;
/* 545 */     this.dc = null; if (available) {
/*     */       this.supportedInFormats = new VideoFormat[2]; this.supportedInFormats[0] = new VideoFormat("mpeg"); this.supportedInFormats[1] = new VideoFormat("MPGI"); this.supportedOutFormats = new VideoFormat[1]; this.supportedOutFormats[0] = (VideoFormat)new YUVFormat(2);
/*     */     } else {
/*     */       this.supportedInFormats = new VideoFormat[0];
/* 549 */     }  } public Object[] getControls() { if (this.dc == null) {
/* 550 */       this.dc = new DC(this);
/* 551 */       this.controls = new Control[1];
/* 552 */       this.controls[0] = (Control)this.dc;
/*     */     } 
/* 554 */     return (Object[])this.controls; }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void propagateEOM(Buffer outBuffer) {
/* 559 */     super.propagateEOM(outBuffer);
/* 560 */     outBuffer.setTimeStamp(this.accumulatedTimeNs);
/* 561 */     this.dAccumulatedTime += this.deltaPictureTimeNS;
/* 562 */     this.accumulatedTimeNs = (long)this.dAccumulatedTime;
/*     */   } private native int videoInitialize(long[] paramArrayOflong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*     */   private native int initImageParam(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*     */   private native int videoDecode(long paramLong1, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, Object paramObject, long paramLong2, int paramInt4, int paramInt5, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int[] paramArrayOfint5, int[] paramArrayOfint6);
/*     */   void setMpegFramesBehind(int num) {
/* 567 */     this.numFramesBehind = num;
/*     */   } private native int videoTerminate(long paramLong);
/*     */   private native int videoReset(long paramLong);
/*     */   private native int videoSeek(long paramLong);
/*     */   class DC implements FrameProcessingControl, QualityControl { private final MpegVideo this$0;
/*     */     DC(MpegVideo this$0) {
/* 573 */       this.this$0 = this$0;
/*     */     } public int getFramesDropped() {
/* 575 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public Component getControlComponent() {
/* 580 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setMinimalProcessing(boolean on) {
/* 585 */       this.this$0.setMpegFramesBehind(5);
/* 586 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setFramesBehind(float framesBehind) {
/* 601 */       this.this$0.setMpegFramesBehind((int)framesBehind);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float setQuality(float quality) {
/* 619 */       return 1.0F;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getQuality() {
/* 627 */       return 1.0F;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getPreferredQuality() {
/* 636 */       return 1.0F;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTemporalSpatialTradeoffSupported() {
/* 641 */       return false;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/video/mpeg/MpegVideo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */