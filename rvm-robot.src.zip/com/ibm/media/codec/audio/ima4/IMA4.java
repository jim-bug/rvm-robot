/*     */ package com.ibm.media.codec.audio.ima4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IMA4
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1998.";
/*  23 */   public static int[] indexTable = new int[] { -1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  28 */   public static int[] stepsizeTable = new int[] { 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   public static int[] diffLUT = new int[1424];
/*     */   
/*     */   static {
/*  43 */     for (int delta = 0; delta < 16; delta++) {
/*  44 */       for (int lastIndex = 0; lastIndex <= 88; lastIndex++) {
/*     */         
/*  46 */         int sign = delta & 0x8;
/*  47 */         int step = stepsizeTable[lastIndex];
/*     */         
/*  49 */         int vpdiff = step >> 3;
/*  50 */         if ((delta & 0x4) != 0) vpdiff += step; 
/*  51 */         if ((delta & 0x2) != 0) vpdiff += step >> 1; 
/*  52 */         if ((delta & 0x1) != 0) vpdiff += step >> 2;
/*     */         
/*  54 */         if (sign != 0)
/*  55 */           vpdiff = -vpdiff; 
/*  56 */         diffLUT[(lastIndex << 4) + delta] = vpdiff;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void encode(byte[] indata, int inOffset, byte[] outdata, int outOffset, int len, IMA4State state, int stride) {
/*  76 */     int outputbuffer = 0;
/*     */ 
/*     */ 
/*     */     
/*  80 */     int valpred = state.valprev;
/*  81 */     int index = state.index;
/*  82 */     int step = stepsizeTable[index];
/*     */     
/*  84 */     boolean bufferstep = true;
/*     */     
/*  86 */     for (; len > 0; len--) {
/*  87 */       byte b; int temp = indata[inOffset++] & 0xFF;
/*  88 */       int val = indata[inOffset++] << 8 | temp;
/*  89 */       inOffset += stride;
/*     */ 
/*     */       
/*  92 */       int diff = val - valpred;
/*     */       
/*  94 */       if (diff < 0) {
/*  95 */         b = 8;
/*  96 */         diff = -diff;
/*     */       } else {
/*  98 */         b = 0;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 110 */       int delta = 0;
/* 111 */       int vpdiff = step >> 3;
/*     */       
/* 113 */       if (diff >= step) {
/* 114 */         delta = 4;
/* 115 */         diff -= step;
/* 116 */         vpdiff += step;
/*     */       } 
/* 118 */       step >>= 1;
/* 119 */       if (diff >= step) {
/* 120 */         delta |= 0x2;
/* 121 */         diff -= step;
/* 122 */         vpdiff += step;
/*     */       } 
/* 124 */       step >>= 1;
/* 125 */       if (diff >= step) {
/* 126 */         delta |= 0x1;
/* 127 */         vpdiff += step;
/*     */       } 
/*     */ 
/*     */       
/* 131 */       if (b) {
/* 132 */         valpred -= vpdiff;
/*     */       } else {
/* 134 */         valpred += vpdiff;
/*     */       } 
/*     */       
/* 137 */       if (valpred > 32767) {
/* 138 */         valpred = 32767;
/* 139 */       } else if (valpred < -32768) {
/* 140 */         valpred = -32768;
/*     */       } 
/*     */       
/* 143 */       delta |= b;
/*     */       
/* 145 */       index += indexTable[delta];
/* 146 */       if (index < 0) { index = 0; }
/* 147 */       else if (index > 88) { index = 88; }
/*     */       
/* 149 */       step = stepsizeTable[index];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 155 */       if (bufferstep) {
/* 156 */         outputbuffer = delta;
/*     */       } else {
/* 158 */         outdata[outOffset++] = (byte)(delta << 4 | outputbuffer);
/*     */       } 
/*     */       
/* 161 */       bufferstep = !bufferstep;
/*     */     } 
/*     */ 
/*     */     
/* 165 */     if (bufferstep) {
/* 166 */       outdata[outOffset++] = (byte)outputbuffer;
/*     */     }
/* 168 */     state.valprev = valpred;
/* 169 */     state.index = index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void decode(byte[] indata, int inOffset, byte[] outdata, int outOffset, int len, IMA4State state, int stride) {
/* 182 */     int inputbuffer = 0;
/* 183 */     boolean bufferstep = false;
/*     */     
/* 185 */     byte[] outp = outdata;
/* 186 */     byte[] inp = indata;
/*     */     
/* 188 */     int valpred = state.valprev;
/* 189 */     int index = state.index;
/* 190 */     int lastIndex = index;
/*     */     
/* 192 */     for (; len > 0; len--) {
/*     */       int i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 202 */       if (bufferstep) {
/* 203 */         i = inputbuffer >> 4 & 0xF;
/*     */       } else {
/* 205 */         inputbuffer = inp[inOffset++];
/* 206 */         i = inputbuffer & 0xF;
/*     */       } 
/* 208 */       bufferstep = !bufferstep;
/*     */ 
/*     */       
/* 211 */       index += indexTable[i];
/* 212 */       if (index < 0) { index = 0; }
/* 213 */       else if (index > 88) { index = 88; }
/*     */ 
/*     */       
/* 216 */       valpred += diffLUT[(lastIndex << 4) + i];
/*     */ 
/*     */       
/* 219 */       if (valpred > 32767) {
/* 220 */         valpred = 32767;
/* 221 */       } else if (valpred < -32768) {
/* 222 */         valpred = -32768;
/*     */       } 
/*     */       
/* 225 */       lastIndex = index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       outp[outOffset++] = (byte)(valpred >> 8);
/* 232 */       outp[outOffset++] = (byte)valpred;
/*     */       
/* 234 */       outOffset += stride;
/*     */     } 
/*     */ 
/*     */     
/* 238 */     state.valprev = valpred;
/* 239 */     state.index = index;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/ima4/IMA4.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */