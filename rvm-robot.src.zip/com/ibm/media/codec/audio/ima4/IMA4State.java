package com.ibm.media.codec.audio.ima4;

class IMA4State {
  public int valprev;
  
  public int index;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/ima4/IMA4State.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */