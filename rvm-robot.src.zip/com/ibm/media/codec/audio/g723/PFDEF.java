package com.ibm.media.codec.audio.g723;

class PFDEF {
  int Indx;
  
  float Gain;
  
  float ScGn;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/g723/PFDEF.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */