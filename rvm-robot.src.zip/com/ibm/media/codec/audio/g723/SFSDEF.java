package com.ibm.media.codec.audio.g723;

class SFSDEF {
  int AcLg;
  
  int AcGn;
  
  int Mamp;
  
  int Grid;
  
  int Tran;
  
  int Pamp;
  
  int Ppos;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/g723/SFSDEF.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */