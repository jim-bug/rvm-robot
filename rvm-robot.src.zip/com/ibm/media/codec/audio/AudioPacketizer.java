/*     */ package com.ibm.media.codec.audio;
/*     */ 
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AudioPacketizer
/*     */   extends AudioCodec
/*     */ {
/*     */   protected byte[] history;
/*     */   protected int packetSize;
/*     */   protected int historyLength;
/*     */   protected int sample_count;
/*     */   
/*     */   public synchronized int process(Buffer inputBuffer, Buffer outputBuffer) {
/*  52 */     int inpLength = inputBuffer.getLength();
/*  53 */     int outLength = this.packetSize;
/*     */     
/*  55 */     byte[] inpData = (byte[])inputBuffer.getData();
/*  56 */     byte[] outData = validateByteArraySize(outputBuffer, outLength);
/*     */ 
/*     */     
/*  59 */     if (inpLength + this.historyLength >= this.packetSize) {
/*  60 */       int copyFromHistory = Math.min(this.historyLength, this.packetSize);
/*     */       
/*  62 */       System.arraycopy(this.history, 0, outData, 0, copyFromHistory);
/*     */       
/*  64 */       int remainingBytes = this.packetSize - copyFromHistory;
/*  65 */       System.arraycopy(inpData, inputBuffer.getOffset(), outData, this.historyLength, remainingBytes);
/*     */       
/*  67 */       this.historyLength -= copyFromHistory;
/*  68 */       inputBuffer.setOffset(inputBuffer.getOffset() + remainingBytes);
/*  69 */       inputBuffer.setLength(inpLength - remainingBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  78 */       updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
/*     */       
/*  80 */       return 2;
/*     */     } 
/*     */     
/*  83 */     if (inputBuffer.isEOM()) {
/*     */       
/*  85 */       System.arraycopy(this.history, 0, outData, 0, this.historyLength);
/*  86 */       System.arraycopy(inpData, inputBuffer.getOffset(), outData, this.historyLength, inpLength);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       updateOutput(outputBuffer, (Format)this.outputFormat, inpLength + this.historyLength, 0);
/*     */       
/*  97 */       this.historyLength = 0;
/*     */       
/*  99 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 103 */     System.arraycopy(inpData, inputBuffer.getOffset(), this.history, this.historyLength, inpLength);
/* 104 */     this.historyLength += inpLength;
/* 105 */     return 4;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 109 */     this.historyLength = 0;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/AudioPacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */