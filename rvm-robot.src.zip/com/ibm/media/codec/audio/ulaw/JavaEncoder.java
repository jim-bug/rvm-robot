/*     */ package com.ibm.media.codec.audio.ulaw;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaEncoder
/*     */   extends AudioCodec
/*     */ {
/*  17 */   private Format lastFormat = null;
/*     */   private int numberOfInputChannels;
/*  19 */   private int numberOfOutputChannels = 1;
/*     */   
/*     */   private boolean downmix = false;
/*     */   private int inputSampleSize;
/*     */   private int lsbOffset;
/*     */   private int msbOffset;
/*     */   private int inputBias;
/*     */   private int signMask;
/*     */   
/*     */   public JavaEncoder() {
/*  29 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 1, -1, -1), new AudioFormat("LINEAR", -1.0D, 16, 2, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 1, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 2, -1, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("ULAW", 8000.0D, 8, 1, -1, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     this.PLUGIN_NAME = "pcm to mu-law converter";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  79 */     AudioFormat inFormat = (AudioFormat)in;
/*  80 */     int channels = inFormat.getChannels();
/*  81 */     int sampleRate = (int)inFormat.getSampleRate();
/*     */ 
/*     */     
/*  84 */     if (channels == 2) {
/*  85 */       this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("ULAW", sampleRate, 8, 2, -1, -1), new AudioFormat("ULAW", sampleRate, 8, 1, -1, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 105 */       this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("ULAW", sampleRate, 8, 1, -1, -1) };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     return (Format[])this.supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/* 131 */     if (!checkInputBuffer(inputBuffer)) {
/* 132 */       return 1;
/*     */     }
/*     */     
/* 135 */     if (isEOM(inputBuffer)) {
/* 136 */       propagateEOM(outputBuffer);
/* 137 */       return 0;
/*     */     } 
/*     */     
/* 140 */     Format newFormat = inputBuffer.getFormat();
/*     */     
/* 142 */     if (this.lastFormat != newFormat) {
/* 143 */       initConverter((AudioFormat)newFormat);
/*     */     }
/*     */     
/* 146 */     int inpLength = inputBuffer.getLength();
/* 147 */     int outLength = calculateOutputSize(inputBuffer.getLength());
/*     */     
/* 149 */     byte[] inpData = (byte[])inputBuffer.getData();
/* 150 */     byte[] outData = validateByteArraySize(outputBuffer, outLength);
/*     */     
/* 152 */     convert(inpData, inputBuffer.getOffset(), inpLength, outData, 0);
/*     */     
/* 154 */     updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
/* 155 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int calculateOutputSize(int inputLength) {
/* 161 */     if (this.inputSampleSize == 16) {
/* 162 */       inputLength /= 2;
/*     */     }
/*     */     
/* 165 */     if (this.downmix) {
/* 166 */       inputLength /= 2;
/*     */     }
/*     */     
/* 169 */     return inputLength;
/*     */   }
/*     */ 
/*     */   
/*     */   private void initConverter(AudioFormat inFormat) {
/* 174 */     this.lastFormat = (Format)inFormat;
/* 175 */     this.numberOfInputChannels = inFormat.getChannels();
/* 176 */     if (this.outputFormat != null)
/* 177 */       this.numberOfOutputChannels = this.outputFormat.getChannels(); 
/* 178 */     this.inputSampleSize = inFormat.getSampleSizeInBits();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (inFormat.getEndian() == 1 || 8 == this.inputSampleSize) {
/* 184 */       this.lsbOffset = 1;
/* 185 */       this.msbOffset = 0;
/*     */     } else {
/*     */       
/* 188 */       this.lsbOffset = -1;
/* 189 */       this.msbOffset = 1;
/*     */     } 
/*     */     
/* 192 */     if (inFormat.getSigned() == 1) {
/* 193 */       this.inputBias = 0;
/* 194 */       this.signMask = -1;
/*     */     } else {
/*     */       
/* 197 */       this.inputBias = 32768;
/* 198 */       this.signMask = 65535;
/*     */     } 
/*     */     
/* 201 */     if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 1) {
/* 202 */       this.downmix = true;
/*     */     } else {
/*     */       
/* 205 */       this.downmix = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void convert(byte[] input, int inputOffset, int inputLength, byte[] outData, int outputOffset) {
/* 215 */     for (int i = inputOffset + this.msbOffset; i < inputLength + inputOffset; ) {
/*     */       boolean bool;
/*     */       int j;
/* 218 */       if (8 == this.inputSampleSize) {
/* 219 */         j = input[i++] << 8;
/*     */         
/* 221 */         if (this.downmix) {
/* 222 */           j = (j & this.signMask) + (input[i++] << 8 & this.signMask) >> 1;
/*     */         }
/*     */       } else {
/*     */         
/* 226 */         j = (input[i] << 8) + (0xFF & input[i + this.lsbOffset]);
/* 227 */         i += 2;
/*     */         
/* 229 */         if (this.downmix) {
/* 230 */           j = (j & this.signMask) + ((input[i] << 8) + (0xFF & input[i + this.lsbOffset]) & this.signMask) >> 1;
/* 231 */           i += 2;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 236 */       int sample = (short)(j + this.inputBias);
/*     */ 
/*     */       
/* 239 */       if (sample >= 0) {
/* 240 */         bool = true;
/*     */       } else {
/* 242 */         sample = -sample;
/* 243 */         bool = false;
/*     */       } 
/*     */       
/* 246 */       sample = 132 + sample >> 3;
/*     */       
/* 248 */       outData[outputOffset++] = (sample < 32) ? (byte)(bool | 0x70 | 31 - (sample >> 0)) : ((sample < 64) ? (byte)(bool | 0x60 | 31 - (sample >> 1)) : ((sample < 128) ? (byte)(bool | 0x50 | 31 - (sample >> 2)) : ((sample < 256) ? (byte)(bool | 0x40 | 31 - (sample >> 3)) : ((sample < 512) ? (byte)(bool | 0x30 | 31 - (sample >> 4)) : ((sample < 1024) ? (byte)(bool | 0x20 | 31 - (sample >> 5)) : ((sample < 2048) ? (byte)(bool | 0x10 | 31 - (sample >> 6)) : ((sample < 4096) ? (byte)(bool | false | 31 - (sample >> 7)) : (byte)(bool | false | 0x0))))))));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/ulaw/JavaEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */