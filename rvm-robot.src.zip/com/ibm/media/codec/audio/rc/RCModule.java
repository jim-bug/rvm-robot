/*     */ package com.ibm.media.codec.audio.rc;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RCModule
/*     */   extends AudioCodec
/*     */ {
/*  19 */   private RateConversion rateConversion = null;
/*  20 */   private Format lastInputFormat = null;
/*  21 */   private Format lastOutputFormat = null;
/*     */   private static boolean DEBUG = false;
/*     */   
/*     */   public RCModule() {
/*  25 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 2, -1, -1), new AudioFormat("LINEAR", -1.0D, 16, 1, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 2, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 1, -1, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", 8000.0D, 16, 2, 0, 1), new AudioFormat("LINEAR", 8000.0D, 16, 1, 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     this.PLUGIN_NAME = "Rate Conversion";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format format) {
/* 168 */     if (!isSampleRateSupported(format)) return null;
/*     */ 
/*     */     
/* 171 */     return super.setInputFormat(format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/* 179 */     if (!isSampleRateSupported(in)) return new Format[0];
/*     */     
/* 181 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", 8000.0D, 16, 1, 0, 1), new AudioFormat("LINEAR", 8000.0D, 16, 2, 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     return (Format[])this.supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {}
/*     */ 
/*     */   
/*     */   public void reset() {
/* 218 */     if (null != this.rateConversion) {
/* 219 */       this.rateConversion.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() {
/* 224 */     if (null != this.rateConversion) {
/* 225 */       this.rateConversion.close();
/*     */     }
/*     */     
/* 228 */     this.rateConversion = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/* 235 */     if (!checkInputBuffer(inputBuffer)) {
/* 236 */       return 1;
/*     */     }
/*     */     
/* 239 */     if (isEOM(inputBuffer)) {
/* 240 */       propagateEOM(outputBuffer);
/* 241 */       return 0;
/*     */     } 
/*     */     
/* 244 */     int inputLength = inputBuffer.getLength();
/*     */     
/* 246 */     if (this.lastInputFormat != this.inputFormat || this.lastOutputFormat != this.outputFormat || this.rateConversion == null)
/*     */     {
/* 248 */       if (false == initConverter(this.inputFormat, this.outputFormat, inputLength))
/*     */       {
/* 250 */         return 1;
/*     */       }
/*     */     }
/*     */     
/* 254 */     int maxOutLength = this.rateConversion.getMaxOutputLength(inputLength);
/* 255 */     byte[] inputData = (byte[])inputBuffer.getData();
/* 256 */     byte[] outData = validateByteArraySize(outputBuffer, maxOutLength);
/*     */     
/* 258 */     int outLength = this.rateConversion.process(inputData, inputBuffer.getOffset(), inputLength, outData, outputBuffer.getOffset());
/*     */ 
/*     */     
/* 261 */     updateOutput(outputBuffer, (Format)this.outputFormat, outLength, outputBuffer.getOffset());
/*     */     
/* 263 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSampleRateSupported(Format format) {
/*     */     try {
/* 270 */       int sampleRate = (int)((AudioFormat)format).getSampleRate();
/*     */ 
/*     */       
/* 273 */       if (sampleRate != 11025 && sampleRate != 11127 && sampleRate != 16000 && sampleRate != 22050 && sampleRate != 22254 && sampleRate != 22255 && sampleRate != 32000 && sampleRate != 44100 && sampleRate != 48000)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 278 */         if (DEBUG) {
/* 279 */           System.out.println("RCModule - input format sampling rate isn't supported");
/*     */         }
/* 281 */         return false;
/*     */       }
/*     */     
/*     */     } catch (Throwable t) {
/*     */       
/* 286 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initConverter(AudioFormat inFormat, AudioFormat outFormat, int inputLength) {
/* 306 */     this.lastInputFormat = (Format)inFormat;
/* 307 */     this.lastOutputFormat = (Format)outFormat;
/*     */     
/* 309 */     boolean isSigned = false;
/* 310 */     int numberOfInputChannels = inFormat.getChannels();
/* 311 */     int numberOfOutputChannels = outFormat.getChannels();
/* 312 */     int inputSampleSize = inFormat.getSampleSizeInBits();
/* 313 */     int sampleRate = (int)inFormat.getSampleRate();
/* 314 */     boolean ulawOutput = false;
/*     */ 
/*     */     
/* 317 */     if (sampleRate == 8000) {
/* 318 */       return false;
/*     */     }
/*     */     
/* 321 */     int pcmType = 1;
/*     */     
/* 323 */     if (inFormat.getEndian() == 1) {
/* 324 */       pcmType = 0;
/*     */     }
/*     */     
/* 327 */     if (8 == inputSampleSize) {
/* 328 */       pcmType = 2;
/*     */     }
/*     */     
/* 331 */     if (inFormat.getSigned() == 1) {
/* 332 */       isSigned = true;
/*     */     }
/*     */ 
/*     */     
/* 336 */     if (this.rateConversion != null) {
/* 337 */       close();
/*     */     }
/*     */ 
/*     */     
/* 341 */     if (outFormat.getEncoding() == "ULAW") {
/* 342 */       ulawOutput = true;
/*     */     }
/*     */     
/* 345 */     this.rateConversion = new RateConversion();
/* 346 */     if (-1 != this.rateConversion.init(inputLength, sampleRate, 8000, numberOfInputChannels, numberOfOutputChannels, pcmType, isSigned, ulawOutput)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 354 */       this.rateConversion = null;
/* 355 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 360 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/rc/RCModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */