package com.ibm.media.codec.audio.dvi;

class DVIState {
  public int valprev;
  
  public int index;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/dvi/DVIState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */