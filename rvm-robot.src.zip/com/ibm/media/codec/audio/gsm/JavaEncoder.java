/*     */ package com.ibm.media.codec.audio.gsm;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.ibm.media.codec.audio.BufferedEncoder;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaEncoder
/*     */   extends BufferedEncoder
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
/*     */   protected GsmEncoder encoder;
/*  40 */   private int sample_count = 160;
/*     */   
/*  42 */   private long currentSeq = (long)(System.currentTimeMillis() * Math.random());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private long timestamp = 0L;
/*     */ 
/*     */   
/*  50 */   byte[] pendingBuffer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaEncoder() {
/*  56 */     ((AudioCodec)this).supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 1, 0, 1, -1, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     ((AudioCodec)this).defaultOutputFormats = new AudioFormat[] { new AudioFormat("gsm") };
/*     */ 
/*     */ 
/*     */     
/*  71 */     ((AudioCodec)this).PLUGIN_NAME = "GSM Encoder";
/*  72 */     this.historySize = 320;
/*  73 */     this.pendingFrames = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.packetSize = 33;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  84 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  86 */     ((AudioCodec)this).supportedOutputFormats = new AudioFormat[] { new AudioFormat("gsm", af.getSampleRate(), 16, af.getChannels(), -1, -1, 264, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     return (Format[])((AudioCodec)this).supportedOutputFormats;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 116 */     this.encoder = new GsmVadEncoder();
/* 117 */     this.encoder.gsm_encoder_reset();
/*     */   }
/*     */   
/*     */   public void codecReset() {
/* 121 */     this.encoder.gsm_encoder_reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 126 */     this.encoder = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/* 133 */     int retVal = super.process(inputBuffer, outputBuffer);
/*     */ 
/*     */     
/* 136 */     if (!((AudioCodec)this).outputFormat.getEncoding().equals("gsm/rtp")) {
/* 137 */       return retVal;
/*     */     }
/*     */     
/* 140 */     if (((AudioCodec)this).outputFormat.getEncoding().equals("gsm/rtp")) {
/*     */ 
/*     */ 
/*     */       
/* 144 */       if (retVal == 1)
/* 145 */         return retVal; 
/* 146 */       if (isEOM(inputBuffer)) {
/* 147 */         propagateEOM(outputBuffer);
/* 148 */         return 0;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 154 */       if (this.pendingFrames == 0) {
/* 155 */         this.pendingBuffer = (byte[])outputBuffer.getData();
/*     */       }
/*     */ 
/*     */       
/* 159 */       byte[] outData = new byte[this.packetSize];
/* 160 */       outputBuffer.setData(outData);
/* 161 */       updateOutput(outputBuffer, (Format)((AudioCodec)this).outputFormat, this.packetSize, 0);
/* 162 */       outputBuffer.setSequenceNumber(this.currentSeq++);
/* 163 */       outputBuffer.setTimeStamp(this.timestamp);
/* 164 */       this.timestamp += this.sample_count;
/*     */       
/* 166 */       System.arraycopy(this.pendingBuffer, this.regions[this.pendingFrames], outData, 0, this.packetSize);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 172 */       if (this.pendingFrames + 1 == this.frameNumber[0]) {
/* 173 */         this.pendingFrames = 0;
/* 174 */         this.pendingBuffer = null;
/* 175 */         return 0;
/*     */       } 
/* 177 */       this.pendingFrames++;
/*     */       
/* 179 */       return 2;
/*     */     } 
/*     */ 
/*     */     
/* 183 */     return retVal;
/*     */   }
/*     */   
/*     */   protected int calculateOutputSize(int inputSize) {
/* 187 */     return calculateFramesNumber(inputSize) * 33;
/*     */   }
/*     */   
/*     */   protected int calculateFramesNumber(int inputSize) {
/* 191 */     return inputSize / 320;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean codecProcess(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength, int[] readBytes, int[] writeBytes, int[] frameNumber, int[] regions, int[] regionsTypes) {
/* 203 */     int inCount = 0;
/* 204 */     int outCount = 0;
/* 205 */     int channels = ((AudioCodec)this).inputFormat.getChannels();
/* 206 */     boolean isStereo = (channels == 2);
/*     */     
/* 208 */     int frames = inpLength / 320;
/*     */     
/* 210 */     regions[0] = writePtr;
/*     */     
/* 212 */     for (int frameCounter = 0; frameCounter < frames; frameCounter++) {
/* 213 */       this.encoder.gsm_encode_frame(inpData, readPtr, outData, writePtr);
/* 214 */       readPtr += 320;
/* 215 */       inCount += 320;
/*     */       
/* 217 */       outCount += 33;
/* 218 */       writePtr += 33;
/*     */ 
/*     */       
/* 221 */       regions[frameCounter + 1] = writePtr;
/* 222 */       regionsTypes[frameCounter] = 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 227 */     readBytes[0] = inCount;
/* 228 */     writeBytes[0] = outCount;
/* 229 */     frameNumber[0] = frames;
/*     */     
/* 231 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/codec/audio/gsm/JavaEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */