/*    */ package com.ibm.media;
/*    */ 
/*    */ import java.net.URL;
/*    */ import javax.media.Controller;
/*    */ import javax.media.ControllerEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplaceURLEvent
/*    */   extends ControllerEvent
/*    */ {
/*    */   private URL u;
/*    */   
/*    */   public ReplaceURLEvent(Controller from, URL u) {
/* 29 */     super(from);
/* 30 */     this.u = u;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public URL getURL() {
/* 40 */     return this.u;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/ReplaceURLEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */