/*    */ package com.ibm.media.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import javax.media.protocol.PullSourceStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PullSourceStream2InputStream
/*    */   extends InputStream
/*    */ {
/*    */   PullSourceStream pss;
/* 27 */   byte[] buffer = new byte[1];
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PullSourceStream2InputStream(PullSourceStream pss) {
/* 34 */     this.pss = pss;
/*    */   }
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 39 */     if (this.pss.endOfStream()) {
/* 40 */       System.out.println("end of stream");
/* 41 */       return -1;
/*    */     } 
/*    */     
/* 44 */     this.pss.read(this.buffer, 0, 1);
/* 45 */     return this.buffer[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public int read(byte[] b) throws IOException {
/* 50 */     return this.pss.read(b, 0, b.length);
/*    */   }
/*    */ 
/*    */   
/*    */   public int read(byte[] b, int off, int len) throws IOException {
/* 55 */     return this.pss.read(b, off, len);
/*    */   }
/*    */ 
/*    */   
/*    */   public long skip(long n) throws IOException {
/* 60 */     byte[] buffer = new byte[(int)n];
/* 61 */     int read = read(buffer);
/*    */     
/* 63 */     return read;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int available() throws IOException {
/* 69 */     System.out.println("available was called");
/*    */     
/* 71 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() throws IOException {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean markSupported() {
/* 81 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/ibm/media/util/PullSourceStream2InputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */