/*     */ package com.jogamp.common;
/*     */ 
/*     */ import com.jogamp.common.util.JogampVersion;
/*     */ import com.jogamp.common.util.SHASum;
/*     */ import com.jogamp.common.util.VersionUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.jar.Manifest;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlueGenVersion
/*     */   extends JogampVersion
/*     */ {
/*     */   protected static volatile GlueGenVersion jogampCommonVersionInfo;
/*     */   
/*     */   protected GlueGenVersion(String paramString, Manifest paramManifest) {
/*  49 */     super(paramString, paramManifest);
/*     */   }
/*     */   
/*     */   public static GlueGenVersion getInstance() {
/*  53 */     if (null == jogampCommonVersionInfo) {
/*  54 */       synchronized (GlueGenVersion.class) {
/*  55 */         if (null == jogampCommonVersionInfo) {
/*     */ 
/*     */           
/*  58 */           Manifest manifest = VersionUtil.getManifest(GlueGenVersion.class.getClassLoader(), "com.jogamp.common");
/*  59 */           if (null != manifest) {
/*  60 */             jogampCommonVersionInfo = new GlueGenVersion("com.jogamp.common", manifest);
/*     */           } else {
/*  62 */             manifest = VersionUtil.getManifest(GlueGenVersion.class.getClassLoader(), "com.jogamp.gluegen");
/*  63 */             jogampCommonVersionInfo = new GlueGenVersion("com.jogamp.gluegen", manifest);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*  68 */     return jogampCommonVersionInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GluGenRTJarSHASum
/*     */     extends SHASum.TempJarSHASum
/*     */   {
/*     */     public GluGenRTJarSHASum() throws SecurityException, IllegalArgumentException, NoSuchAlgorithmException, IOException, URISyntaxException {
/*  92 */       super(MessageDigest.getInstance("SHA-256"), GlueGenVersion.class, new ArrayList(), new ArrayList());
/*  93 */       List<Pattern> list1 = getExcludes();
/*  94 */       List<Pattern> list2 = getIncludes();
/*  95 */       String str = getOrigin();
/*  96 */       list1.add(Pattern.compile(str + "/jogamp/android/launcher"));
/*  97 */       list1.add(Pattern.compile(str + "/jogamp/common/os/android"));
/*  98 */       list1.add(Pattern.compile(str + "/com/jogamp/gluegen/jcpp"));
/*  99 */       list2.add(Pattern.compile(str + "/com/jogamp/gluegen/runtime/.*\\.class"));
/* 100 */       list2.add(Pattern.compile(str + "/com/jogamp/common/.*"));
/* 101 */       list2.add(Pattern.compile(str + "/jogamp/common/.*"));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 106 */     System.err.println(VersionUtil.getPlatformInfo());
/* 107 */     System.err.println(getInstance());
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/GlueGenVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */