/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WeakIdentityHashMap<K, V>
/*     */   implements Map<K, V>
/*     */ {
/*  76 */   private final ReferenceQueue<K> queue = new ReferenceQueue<>();
/*     */ 
/*     */   
/*     */   private final Map<IdentityWeakReference<K>, V> backingStore;
/*     */ 
/*     */   
/*     */   public WeakIdentityHashMap() {
/*  83 */     this.backingStore = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WeakIdentityHashMap(int paramInt, float paramFloat) {
/* 100 */     this.backingStore = new HashMap<>(paramInt, paramFloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WeakIdentityHashMap<?, ?> createWithRequiredSize(int paramInt, float paramFloat) {
/* 113 */     float[] arrayOfFloat = { paramFloat };
/* 114 */     int i = capacityForRequiredSize(paramInt, arrayOfFloat);
/* 115 */     return new WeakIdentityHashMap<>(i, arrayOfFloat[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int capacityForRequiredSize(int paramInt, float[] paramArrayOffloat) {
/* 133 */     if (paramInt >= 1073741824) {
/* 134 */       return Integer.MAX_VALUE;
/*     */     }
/* 136 */     float f = paramArrayOffloat[0];
/* 137 */     int i = (int)(paramInt / f + 1.0F);
/* 138 */     if (!Bitfield.Util.isPowerOf2(i) || 0.86F <= f) {
/* 139 */       return i;
/*     */     }
/*     */     do {
/* 142 */       f += 0.01F;
/* 143 */       i = (int)(paramInt / f + 1.0F);
/* 144 */     } while (Bitfield.Util.isPowerOf2(i) && 0.86F > f);
/*     */     
/* 146 */     paramArrayOffloat[0] = f;
/* 147 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 152 */     this.backingStore.clear();
/* 153 */     reap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object paramObject) {
/* 159 */     reap();
/* 160 */     return this.backingStore.containsKey(new IdentityWeakReference(paramObject, this.queue));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object paramObject) {
/* 165 */     reap();
/* 166 */     return this.backingStore.containsValue(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 171 */     reap();
/* 172 */     HashSet<Map.Entry<K, V>> hashSet = new HashSet();
/* 173 */     for (Map.Entry<IdentityWeakReference<K>, V> entry : this.backingStore.entrySet()) {
/* 174 */       final Object key = ((IdentityWeakReference<Object>)entry.getKey()).get();
/* 175 */       if (null != object) {
/* 176 */         final Object value = entry.getValue();
/* 177 */         Map.Entry<K, V> entry1 = new Map.Entry<K, V>()
/*     */           {
/*     */             public K getKey() {
/* 180 */               return (K)key;
/*     */             }
/*     */ 
/*     */             
/*     */             public V getValue() {
/* 185 */               return (V)value;
/*     */             }
/*     */ 
/*     */             
/*     */             public V setValue(V param1V) {
/* 190 */               throw new UnsupportedOperationException();
/*     */             }
/*     */           };
/* 193 */         hashSet.add(entry1);
/*     */       } 
/*     */     } 
/* 196 */     return Collections.unmodifiableSet(hashSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 201 */     reap();
/* 202 */     HashSet<? extends K> hashSet = new HashSet();
/* 203 */     for (IdentityWeakReference<Object> identityWeakReference : this.backingStore.keySet()) {
/* 204 */       Object object = identityWeakReference.get();
/* 205 */       if (null != object) {
/* 206 */         hashSet.add(object);
/*     */       }
/*     */     } 
/* 209 */     return Collections.unmodifiableSet(hashSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 214 */     if (!(paramObject instanceof WeakIdentityHashMap)) {
/* 215 */       return false;
/*     */     }
/* 217 */     return this.backingStore.equals(((WeakIdentityHashMap)paramObject).backingStore);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object paramObject) {
/* 223 */     reap();
/* 224 */     return this.backingStore.get(new IdentityWeakReference(paramObject, this.queue));
/*     */   }
/*     */ 
/*     */   
/*     */   public V put(K paramK, V paramV) {
/* 229 */     reap();
/* 230 */     return this.backingStore.put(new IdentityWeakReference<>(paramK, this.queue), paramV);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 235 */     reap();
/* 236 */     return this.backingStore.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 241 */     reap();
/* 242 */     return this.backingStore.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> paramMap) {
/* 247 */     int i = paramMap.size();
/* 248 */     if (0 < i) {
/* 249 */       float[] arrayOfFloat = { 0.75F };
/* 250 */       int j = capacityForRequiredSize(i, arrayOfFloat);
/* 251 */       HashMap<Object, Object> hashMap = new HashMap<>(j, arrayOfFloat[0]);
/* 252 */       for (Map.Entry<? extends K, ? extends V> entry : paramMap.entrySet()) {
/* 253 */         hashMap.put(new IdentityWeakReference<>((K)entry.getKey(), this.queue), entry.getValue());
/*     */       }
/* 255 */       this.backingStore.putAll((Map)hashMap);
/* 256 */       reap();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V remove(Object paramObject) {
/* 263 */     reap();
/* 264 */     return this.backingStore.remove(new IdentityWeakReference(paramObject, this.queue));
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 269 */     reap();
/* 270 */     return this.backingStore.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 275 */     reap();
/* 276 */     return this.backingStore.values();
/*     */   }
/*     */   
/*     */   private synchronized void reap() {
/* 280 */     Reference<? extends K> reference = this.queue.poll();
/*     */     
/* 282 */     while (reference != null) {
/*     */       
/* 284 */       IdentityWeakReference identityWeakReference = (IdentityWeakReference)reference;
/* 285 */       this.backingStore.remove(identityWeakReference);
/* 286 */       reference = this.queue.poll();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class IdentityWeakReference<K> extends WeakReference<K> {
/*     */     final int hash;
/*     */     
/*     */     IdentityWeakReference(K param1K, ReferenceQueue<K> param1ReferenceQueue) {
/* 294 */       super(param1K, param1ReferenceQueue);
/* 295 */       this.hash = System.identityHashCode(param1K);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 300 */       return this.hash;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 305 */       if (this == param1Object) {
/* 306 */         return true;
/*     */       }
/* 308 */       if (!(param1Object instanceof IdentityWeakReference)) {
/* 309 */         return false;
/*     */       }
/*     */       
/* 312 */       IdentityWeakReference<K> identityWeakReference = (IdentityWeakReference)param1Object;
/* 313 */       return (get() == identityWeakReference.get());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/WeakIdentityHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */