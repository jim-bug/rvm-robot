/*    */ package com.jogamp.common.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RunnableExecutor
/*    */ {
/* 34 */   public static final RunnableExecutor currentThreadExecutor = new CurrentThreadExecutor();
/*    */ 
/*    */   
/*    */   void invoke(boolean paramBoolean, Runnable paramRunnable);
/*    */ 
/*    */   
/*    */   public static class CurrentThreadExecutor
/*    */     implements RunnableExecutor
/*    */   {
/*    */     private CurrentThreadExecutor() {}
/*    */ 
/*    */     
/*    */     public void invoke(boolean param1Boolean, Runnable param1Runnable) {
/* 47 */       param1Runnable.run();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/RunnableExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */