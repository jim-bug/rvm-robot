/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Deflater;
/*     */ import java.util.zip.Inflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomCompress
/*     */ {
/*     */   public static final int MAGIC = -554588192;
/*     */   
/*     */   public static byte[] inflateFromStream(InputStream paramInputStream) throws IOException, ArrayIndexOutOfBoundsException, IllegalArgumentException {
/*  68 */     DataInputStream dataInputStream = new DataInputStream(paramInputStream);
/*  69 */     int k = dataInputStream.readInt();
/*  70 */     if (k != -554588192) {
/*  71 */       throw new IOException("wrong magic: " + Integer.toHexString(k) + ", expected " + Integer.toHexString(-554588192));
/*     */     }
/*  73 */     int i = dataInputStream.readInt();
/*  74 */     int j = dataInputStream.readInt();
/*     */     
/*  76 */     return inflateFromStream(paramInputStream, i, j, new byte[j], 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] inflateFromStream(InputStream paramInputStream, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3) throws IOException, ArrayIndexOutOfBoundsException, IllegalArgumentException {
/*  95 */     if (paramInt1 <= 0 || paramInt2 <= 0) {
/*  96 */       throw new IllegalArgumentException("Length[input " + paramInt1 + ", output " + paramInt2 + "]");
/*     */     }
/*  98 */     if (paramInt3 < 0 || paramArrayOfbyte.length < paramInt3 + paramInt2) {
/*  99 */       throw new ArrayIndexOutOfBoundsException("output.length " + paramArrayOfbyte.length + ", offset " + paramInt3 + ", length " + paramInt2);
/*     */     }
/* 101 */     byte[] arrayOfByte = new byte[paramInt1];
/* 102 */     int i = 0;
/*     */     try {
/*     */       while (true) {
/* 105 */         int j = paramInt1 - i;
/*     */         int k;
/* 107 */         if (0 >= j || (k = paramInputStream.read(arrayOfByte, i, j)) == -1) {
/*     */           break;
/*     */         }
/* 110 */         i += k;
/*     */       } 
/*     */     } finally {
/* 113 */       paramInputStream.close();
/*     */     } 
/* 115 */     if (paramInt1 != i) {
/* 116 */       throw new IOException("Got " + i + " bytes != expected " + paramInt1);
/*     */     }
/*     */     try {
/* 119 */       Inflater inflater = new Inflater();
/* 120 */       inflater.setInput(arrayOfByte, 0, paramInt1);
/* 121 */       int j = inflater.inflate(paramArrayOfbyte, paramInt3, paramInt2);
/* 122 */       inflater.end();
/* 123 */       if (paramInt2 != j) {
/* 124 */         throw new IOException("Got inflated " + j + " bytes != expected " + paramInt2);
/*     */       }
/* 126 */     } catch (DataFormatException dataFormatException) {
/* 127 */       throw new IOException(dataFormatException);
/*     */     } 
/* 129 */     return paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int deflateToStream(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, OutputStream paramOutputStream) throws IOException, ArrayIndexOutOfBoundsException, IllegalArgumentException {
/* 145 */     if (paramInt2 <= 0) {
/* 146 */       throw new IllegalArgumentException("Length[input " + paramInt2 + "]");
/*     */     }
/* 148 */     if (paramInt1 < 0 || paramArrayOfbyte.length < paramInt1 + paramInt2) {
/* 149 */       throw new ArrayIndexOutOfBoundsException("input.length " + paramArrayOfbyte.length + ", offset " + paramInt1 + ", length " + paramInt2);
/*     */     }
/* 151 */     byte[] arrayOfByte = new byte[paramInt2];
/* 152 */     Deflater deflater = new Deflater(paramInt3);
/* 153 */     deflater.setInput(paramArrayOfbyte, paramInt1, paramInt2);
/* 154 */     deflater.finish();
/* 155 */     int i = deflater.deflate(arrayOfByte, 0, paramInt2);
/* 156 */     deflater.end();
/*     */     
/* 158 */     DataOutputStream dataOutputStream = new DataOutputStream(paramOutputStream);
/* 159 */     dataOutputStream.writeInt(-554588192);
/* 160 */     dataOutputStream.writeInt(i);
/* 161 */     dataOutputStream.writeInt(paramInt2);
/*     */     
/* 163 */     paramOutputStream.write(arrayOfByte, 0, i);
/* 164 */     return i;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/CustomCompress.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */