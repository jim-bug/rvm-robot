/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.os.Platform;
/*     */ import java.util.Set;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.Manifest;
/*     */ import jogamp.common.os.AndroidUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JogampVersion
/*     */ {
/*  43 */   public static final Attributes.Name IMPLEMENTATION_BUILD = new Attributes.Name("Implementation-Build");
/*     */   
/*  45 */   public static final Attributes.Name IMPLEMENTATION_BRANCH = new Attributes.Name("Implementation-Branch");
/*     */   
/*  47 */   public static final Attributes.Name IMPLEMENTATION_COMMIT = new Attributes.Name("Implementation-Commit");
/*     */   
/*  49 */   public static final Attributes.Name IMPLEMENTATION_SHA_SOURCES = new Attributes.Name("Implementation-SHA-Sources");
/*     */   
/*  51 */   public static final Attributes.Name IMPLEMENTATION_SHA_CLASSES = new Attributes.Name("Implementation-SHA-Classes");
/*     */   
/*  53 */   public static final Attributes.Name IMPLEMENTATION_SHA_CLASSES_THIS = new Attributes.Name("Implementation-SHA-Classes-this");
/*     */   
/*  55 */   public static final Attributes.Name IMPLEMENTATION_SHA_NATIVES = new Attributes.Name("Implementation-SHA-Natives");
/*     */   
/*  57 */   public static final Attributes.Name IMPLEMENTATION_SHA_NATIVES_THIS = new Attributes.Name("Implementation-SHA-Natives-this");
/*     */   
/*     */   private static final String packageNameFAT = "com.jogamp";
/*     */   
/*     */   private final String packageName;
/*     */   
/*     */   private final Manifest mf;
/*     */   
/*     */   private final int hash;
/*     */   private final Attributes mainAttributes;
/*     */   private final Set<?> mainAttributeNames;
/*     */   private final String androidPackageVersionName;
/*     */   
/*     */   protected JogampVersion(String paramString, Manifest paramManifest) {
/*  71 */     if (null != paramManifest) {
/*     */       
/*  73 */       this.mf = paramManifest;
/*  74 */       this.packageName = paramString;
/*     */     } else {
/*     */       
/*  77 */       Manifest manifest = VersionUtil.getManifest(JogampVersion.class.getClassLoader(), "com.jogamp");
/*  78 */       if (null != manifest) {
/*     */         
/*  80 */         this.mf = manifest;
/*  81 */         this.packageName = "com.jogamp";
/*     */       } else {
/*     */         
/*  84 */         this.mf = new Manifest();
/*  85 */         this.packageName = paramString;
/*     */       } 
/*     */     } 
/*  88 */     this.hash = this.mf.hashCode();
/*  89 */     this.mainAttributes = this.mf.getMainAttributes();
/*  90 */     this.mainAttributeNames = this.mainAttributes.keySet();
/*  91 */     this.androidPackageVersionName = AndroidUtils.getPackageInfoVersionName(this.packageName);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/*  96 */     return this.hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 101 */     if (paramObject instanceof JogampVersion) {
/* 102 */       return this.mf.equals(((JogampVersion)paramObject).getManifest());
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   public final Manifest getManifest() {
/* 108 */     return this.mf;
/*     */   }
/*     */   
/*     */   public final String getPackageName() {
/* 112 */     return this.packageName;
/*     */   }
/*     */   
/*     */   public final String getAttribute(Attributes.Name paramName) {
/* 116 */     return (null != paramName) ? (String)this.mainAttributes.get(paramName) : null;
/*     */   }
/*     */   
/*     */   public final String getAttribute(String paramString) {
/* 120 */     return getAttribute(getAttributeName(paramString));
/*     */   }
/*     */   
/*     */   public final Attributes.Name getAttributeName(String paramString) {
/* 124 */     for (Attributes.Name name : this.mainAttributeNames) {
/*     */       
/* 126 */       if (name.toString().equals(paramString)) {
/* 127 */         return name;
/*     */       }
/*     */     } 
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Set<?> getAttributeNames() {
/* 137 */     return this.mainAttributeNames;
/*     */   }
/*     */   
/*     */   public final String getExtensionName() {
/* 141 */     if (null != this.androidPackageVersionName) {
/* 142 */       return this.packageName;
/*     */     }
/* 144 */     return getAttribute(Attributes.Name.EXTENSION_NAME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationBuild() {
/* 151 */     return getAttribute(IMPLEMENTATION_BUILD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationBranch() {
/* 158 */     return getAttribute(IMPLEMENTATION_BRANCH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationCommit() {
/* 165 */     return getAttribute(IMPLEMENTATION_COMMIT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationSHASources() {
/* 172 */     return getAttribute(IMPLEMENTATION_SHA_SOURCES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationSHAClasses() {
/* 179 */     return getAttribute(IMPLEMENTATION_SHA_CLASSES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationSHAClassesThis() {
/* 186 */     return getAttribute(IMPLEMENTATION_SHA_CLASSES_THIS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationSHANatives() {
/* 193 */     return getAttribute(IMPLEMENTATION_SHA_NATIVES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationSHANativesThis() {
/* 200 */     return getAttribute(IMPLEMENTATION_SHA_NATIVES_THIS);
/*     */   }
/*     */   
/*     */   public final String getImplementationTitle() {
/* 204 */     return getAttribute(Attributes.Name.IMPLEMENTATION_TITLE);
/*     */   }
/*     */   
/*     */   public final String getImplementationVendor() {
/* 208 */     return getAttribute(Attributes.Name.IMPLEMENTATION_VENDOR);
/*     */   }
/*     */   
/*     */   public final String getImplementationVendorID() {
/* 212 */     return getAttribute(Attributes.Name.IMPLEMENTATION_VENDOR_ID);
/*     */   }
/*     */   
/*     */   public final String getImplementationURL() {
/* 216 */     return getAttribute(Attributes.Name.IMPLEMENTATION_URL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getImplementationVersion() {
/* 227 */     return getAttribute(Attributes.Name.IMPLEMENTATION_VERSION);
/*     */   }
/*     */   
/*     */   public final String getAndroidPackageVersionName() {
/* 231 */     return this.androidPackageVersionName;
/*     */   }
/*     */   
/*     */   public final String getSpecificationTitle() {
/* 235 */     return getAttribute(Attributes.Name.SPECIFICATION_TITLE);
/*     */   }
/*     */   
/*     */   public final String getSpecificationVendor() {
/* 239 */     return getAttribute(Attributes.Name.SPECIFICATION_VENDOR);
/*     */   }
/*     */   
/*     */   public final String getSpecificationVersion() {
/* 243 */     return getAttribute(Attributes.Name.SPECIFICATION_VERSION);
/*     */   }
/*     */   
/*     */   public final StringBuilder getFullManifestInfo(StringBuilder paramStringBuilder) {
/* 247 */     return VersionUtil.getFullManifestInfo(getManifest(), paramStringBuilder);
/*     */   }
/*     */   
/*     */   public StringBuilder getManifestInfo(StringBuilder paramStringBuilder) {
/* 251 */     if (null == paramStringBuilder) {
/* 252 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 254 */     String str = Platform.getNewline();
/* 255 */     paramStringBuilder.append("Package: ").append(getPackageName()).append(str);
/* 256 */     paramStringBuilder.append("Extension Name: ").append(getExtensionName()).append(str);
/* 257 */     paramStringBuilder.append("Specification Title: ").append(getSpecificationTitle()).append(str);
/* 258 */     paramStringBuilder.append("Specification Vendor: ").append(getSpecificationVendor()).append(str);
/* 259 */     paramStringBuilder.append("Specification Version: ").append(getSpecificationVersion()).append(str);
/* 260 */     paramStringBuilder.append("Implementation Title: ").append(getImplementationTitle()).append(str);
/* 261 */     paramStringBuilder.append("Implementation Vendor: ").append(getImplementationVendor()).append(str);
/* 262 */     paramStringBuilder.append("Implementation Vendor ID: ").append(getImplementationVendorID()).append(str);
/* 263 */     paramStringBuilder.append("Implementation URL: ").append(getImplementationURL()).append(str);
/* 264 */     paramStringBuilder.append("Implementation Version: ").append(getImplementationVersion()).append(str);
/* 265 */     paramStringBuilder.append("Implementation Build: ").append(getImplementationBuild()).append(str);
/* 266 */     paramStringBuilder.append("Implementation Branch: ").append(getImplementationBranch()).append(str);
/* 267 */     paramStringBuilder.append("Implementation Commit: ").append(getImplementationCommit()).append(str);
/* 268 */     paramStringBuilder.append("Implementation SHA Sources: ").append(getImplementationSHASources()).append(str);
/* 269 */     paramStringBuilder.append("Implementation SHA Classes: ").append(getImplementationSHAClasses()).append(str);
/* 270 */     paramStringBuilder.append("Implementation SHA Classes-this: ").append(getImplementationSHAClassesThis()).append(str);
/* 271 */     paramStringBuilder.append("Implementation SHA Natives: ").append(getImplementationSHANatives()).append(str);
/* 272 */     paramStringBuilder.append("Implementation SHA Natives-this: ").append(getImplementationSHANativesThis()).append(str);
/* 273 */     if (null != getAndroidPackageVersionName()) {
/* 274 */       paramStringBuilder.append("Android Package Version: ").append(getAndroidPackageVersionName()).append(str);
/*     */     }
/* 276 */     return paramStringBuilder;
/*     */   }
/*     */   
/*     */   public StringBuilder toString(StringBuilder paramStringBuilder) {
/* 280 */     if (null == paramStringBuilder) {
/* 281 */       paramStringBuilder = new StringBuilder();
/*     */     }
/*     */     
/* 284 */     paramStringBuilder.append("-----------------------------------------------------------------------------------------------------").append(Platform.getNewline());
/* 285 */     getManifestInfo(paramStringBuilder);
/* 286 */     paramStringBuilder.append("-----------------------------------------------------------------------------------------------------");
/*     */     
/* 288 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 293 */     return toString(null).toString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/JogampVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */