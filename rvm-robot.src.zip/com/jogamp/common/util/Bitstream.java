/*      */ package com.jogamp.common.util;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.Locale;
/*      */ import jogamp.common.Debug;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Bitstream<T>
/*      */ {
/*   52 */   private static final boolean DEBUG = Debug.debug("Bitstream");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int EOS = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ByteStream<T> bytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bitBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bitsDataMark;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bitCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bitsCountMark;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean outputMode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean throwIOExceptionOnEOF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean useFastPathStream = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean useFastPathTypes = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String strZeroPadding = "0000000000000000000000000000000000000000000000000000000000000000";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ByteArrayStream
/*      */     implements ByteStream<byte[]>
/*      */   {
/*      */     private byte[] media;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int pos;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int posMark;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteArrayStream(byte[] param1ArrayOfbyte) {
/*  177 */       setStream(param1ArrayOfbyte);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setStream(byte[] param1ArrayOfbyte) {
/*  182 */       this.media = param1ArrayOfbyte;
/*  183 */       this.pos = 0;
/*  184 */       this.posMark = -1;
/*      */     }
/*      */     
/*      */     public byte[] getStream() {
/*  188 */       return this.media;
/*      */     }
/*      */     
/*      */     public void close() {
/*  192 */       this.media = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void flush() {}
/*      */ 
/*      */     
/*      */     public boolean canInput() {
/*  200 */       return true;
/*      */     }
/*      */     public boolean canOutput() {
/*  203 */       return true;
/*      */     }
/*      */     public long position() {
/*  206 */       return this.pos;
/*      */     }
/*      */     
/*      */     public long position(long param1Long) throws UnsupportedOperationException, IllegalArgumentException {
/*  210 */       if (param1Long >= this.media.length) {
/*  211 */         return -1L;
/*      */       }
/*  213 */       this.pos = (int)param1Long;
/*  214 */       if (this.posMark > this.pos) {
/*  215 */         this.posMark = -1;
/*      */       }
/*  217 */       return this.pos;
/*      */     }
/*      */ 
/*      */     
/*      */     public long skip(long param1Long) {
/*      */       long l;
/*  223 */       if (param1Long >= 0L) {
/*  224 */         int i = this.media.length - this.pos;
/*  225 */         l = Math.min(i, (int)param1Long);
/*      */       } else {
/*  227 */         int i = (int)param1Long * -1;
/*  228 */         l = (-1 * Math.min(this.pos, i));
/*      */       } 
/*  230 */       this.pos = (int)(this.pos + l);
/*  231 */       return l;
/*      */     }
/*      */ 
/*      */     
/*      */     public void mark(int param1Int) {
/*  236 */       this.posMark = this.pos;
/*      */     }
/*      */ 
/*      */     
/*      */     public void reset() throws IllegalStateException {
/*  241 */       if (0 > this.posMark) {
/*  242 */         throw new IllegalStateException("markpos not set");
/*      */       }
/*  244 */       if (Bitstream.DEBUG) System.err.println("rewind: " + this.pos + " -> " + this.posMark); 
/*  245 */       this.pos = this.posMark;
/*      */     }
/*      */ 
/*      */     
/*      */     public int read() {
/*      */       byte b;
/*  251 */       if (this.media.length > this.pos) {
/*  252 */         b = 0xFF & this.media[this.pos++];
/*      */       } else {
/*  254 */         b = -1;
/*      */       } 
/*  256 */       if (Bitstream.DEBUG) {
/*  257 */         if (-1 != b) {
/*  258 */           System.err.println("u8[" + (this.pos - 1) + "] -> " + Bitstream.toHexBinString(true, b, 8));
/*      */         } else {
/*  260 */           System.err.println("u8[" + (this.pos - 0) + "] -> EOS");
/*      */         } 
/*      */       }
/*  263 */       return b;
/*      */     }
/*      */ 
/*      */     
/*      */     public int write(byte param1Byte) {
/*      */       byte b;
/*  269 */       if (this.media.length > this.pos) {
/*  270 */         this.media[this.pos++] = param1Byte;
/*  271 */         b = 0xFF & param1Byte;
/*      */       } else {
/*  273 */         b = -1;
/*      */       } 
/*  275 */       if (Bitstream.DEBUG) {
/*  276 */         if (-1 != b) {
/*  277 */           System.err.println("u8[" + (this.pos - 1) + "] <- " + Bitstream.toHexBinString(true, b, 8));
/*      */         } else {
/*  279 */           System.err.println("u8[" + (this.pos - 0) + "] <- EOS");
/*      */         } 
/*      */       }
/*  282 */       return b;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class ByteBufferStream
/*      */     implements ByteStream<ByteBuffer>
/*      */   {
/*      */     private ByteBuffer media;
/*      */     
/*      */     private int pos;
/*      */     
/*      */     private int posMark;
/*      */ 
/*      */     
/*      */     public ByteBufferStream(ByteBuffer param1ByteBuffer) {
/*  298 */       setStream(param1ByteBuffer);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setStream(ByteBuffer param1ByteBuffer) {
/*  303 */       this.media = param1ByteBuffer;
/*  304 */       this.pos = 0;
/*  305 */       this.posMark = -1;
/*      */     }
/*      */     
/*      */     public ByteBuffer getStream() {
/*  309 */       return this.media;
/*      */     }
/*      */     
/*      */     public void close() {
/*  313 */       this.media = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void flush() {}
/*      */ 
/*      */     
/*      */     public boolean canInput() {
/*  321 */       return true;
/*      */     }
/*      */     public boolean canOutput() {
/*  324 */       return true;
/*      */     }
/*      */     public long position() {
/*  327 */       return this.pos;
/*      */     }
/*      */     
/*      */     public long position(long param1Long) throws UnsupportedOperationException, IllegalArgumentException {
/*  331 */       if (param1Long >= this.media.limit()) {
/*  332 */         return -1L;
/*      */       }
/*  334 */       this.media.position((int)param1Long);
/*  335 */       this.pos = (int)param1Long;
/*  336 */       if (this.posMark > this.pos) {
/*  337 */         this.posMark = -1;
/*      */       }
/*  339 */       return this.pos;
/*      */     }
/*      */ 
/*      */     
/*      */     public long skip(long param1Long) {
/*      */       long l;
/*  345 */       if (param1Long >= 0L) {
/*  346 */         int i = this.media.limit() - this.pos;
/*  347 */         l = Math.min(i, (int)param1Long);
/*      */       } else {
/*  349 */         int i = (int)param1Long * -1;
/*  350 */         l = (-1 * Math.min(this.pos, i));
/*      */       } 
/*  352 */       this.pos = (int)(this.pos + l);
/*  353 */       return l;
/*      */     }
/*      */ 
/*      */     
/*      */     public void mark(int param1Int) {
/*  358 */       this.posMark = this.pos;
/*      */     }
/*      */ 
/*      */     
/*      */     public void reset() throws IllegalStateException {
/*  363 */       if (0 > this.posMark) {
/*  364 */         throw new IllegalStateException("markpos not set");
/*      */       }
/*  366 */       if (Bitstream.DEBUG) System.err.println("rewind: " + this.pos + " -> " + this.posMark); 
/*  367 */       this.media.position(this.posMark);
/*  368 */       this.pos = this.posMark;
/*      */     }
/*      */ 
/*      */     
/*      */     public int read() {
/*      */       byte b;
/*  374 */       if (this.media.limit() > this.pos) {
/*  375 */         b = 0xFF & this.media.get(this.pos++);
/*      */       } else {
/*  377 */         b = -1;
/*      */       } 
/*  379 */       if (Bitstream.DEBUG) {
/*  380 */         if (-1 != b) {
/*  381 */           System.err.println("u8[" + (this.pos - 1) + "] -> " + Bitstream.toHexBinString(true, b, 8));
/*      */         } else {
/*  383 */           System.err.println("u8[" + (this.pos - 0) + "] -> EOS");
/*      */         } 
/*      */       }
/*  386 */       return b;
/*      */     }
/*      */ 
/*      */     
/*      */     public int write(byte param1Byte) {
/*      */       byte b;
/*  392 */       if (this.media.limit() > this.pos) {
/*  393 */         this.media.put(this.pos++, param1Byte);
/*  394 */         b = 0xFF & param1Byte;
/*      */       } else {
/*  396 */         b = -1;
/*      */       } 
/*  398 */       if (Bitstream.DEBUG) {
/*  399 */         if (-1 != b) {
/*  400 */           System.err.println("u8[" + (this.pos - 1) + "] <- " + Bitstream.toHexBinString(true, b, 8));
/*      */         } else {
/*  402 */           System.err.println("u8[" + (this.pos - 0) + "] <- EOS");
/*      */         } 
/*      */       }
/*  405 */       return b;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class ByteInputStream
/*      */     implements ByteStream<InputStream>
/*      */   {
/*      */     private BufferedInputStream media;
/*      */     
/*      */     private long pos;
/*      */     
/*      */     private long posMark;
/*      */ 
/*      */     
/*      */     public ByteInputStream(InputStream param1InputStream) {
/*  421 */       setStream(param1InputStream);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setStream(InputStream param1InputStream) {
/*  426 */       if (param1InputStream instanceof BufferedInputStream) {
/*  427 */         this.media = (BufferedInputStream)param1InputStream;
/*  428 */       } else if (null != param1InputStream) {
/*  429 */         this.media = new BufferedInputStream(param1InputStream);
/*      */       } else {
/*  431 */         this.media = null;
/*      */       } 
/*  433 */       this.pos = 0L;
/*  434 */       this.posMark = -1L;
/*      */     }
/*      */     
/*      */     public InputStream getStream() {
/*  438 */       return this.media;
/*      */     }
/*      */     
/*      */     public void close() throws IOException {
/*  442 */       if (null != this.media) {
/*  443 */         this.media.close();
/*  444 */         this.media = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void flush() {}
/*      */ 
/*      */     
/*      */     public boolean canInput() {
/*  453 */       return true;
/*      */     }
/*      */     public boolean canOutput() {
/*  456 */       return false;
/*      */     }
/*      */     public long position() {
/*  459 */       return this.pos;
/*      */     }
/*      */     
/*      */     public long position(long param1Long) throws UnsupportedOperationException, IllegalArgumentException {
/*  463 */       throw new UnsupportedOperationException("N/a for " + getClass().getCanonicalName());
/*      */     }
/*      */ 
/*      */     
/*      */     public long skip(long param1Long) throws IOException {
/*  468 */       long l = this.media.skip(param1Long);
/*  469 */       this.pos += l;
/*  470 */       return l;
/*      */     }
/*      */ 
/*      */     
/*      */     public void mark(int param1Int) {
/*  475 */       this.media.mark(param1Int);
/*  476 */       this.posMark = this.pos;
/*      */     }
/*      */ 
/*      */     
/*      */     public void reset() throws IllegalStateException, IOException {
/*  481 */       if (0L > this.posMark) {
/*  482 */         throw new IllegalStateException("markpos not set");
/*      */       }
/*  484 */       if (Bitstream.DEBUG) System.err.println("rewind: " + this.pos + " -> " + this.posMark); 
/*  485 */       this.media.reset();
/*  486 */       this.pos = this.posMark;
/*      */     }
/*      */ 
/*      */     
/*      */     public int read() throws IOException {
/*  491 */       int i = this.media.read();
/*  492 */       if (Bitstream.DEBUG) {
/*  493 */         if (-1 != i) {
/*  494 */           System.err.println("u8[" + this.pos + "] -> " + Bitstream.toHexBinString(true, i, 8));
/*      */         } else {
/*  496 */           System.err.println("u8[" + this.pos + "] -> EOS");
/*      */         } 
/*      */       }
/*  499 */       if (-1 != i) {
/*  500 */         this.pos++;
/*      */       }
/*  502 */       return i;
/*      */     }
/*      */ 
/*      */     
/*      */     public int write(byte param1Byte) throws UnsupportedOperationException {
/*  507 */       throw new UnsupportedOperationException("not allowed with input stream");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ByteOutputStream
/*      */     implements ByteStream<OutputStream>
/*      */   {
/*      */     private BufferedOutputStream media;
/*      */ 
/*      */     
/*  519 */     private long pos = 0L;
/*      */     
/*      */     public ByteOutputStream(OutputStream param1OutputStream) {
/*  522 */       setStream(param1OutputStream);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setStream(OutputStream param1OutputStream) {
/*  527 */       if (param1OutputStream instanceof BufferedOutputStream) {
/*  528 */         this.media = (BufferedOutputStream)param1OutputStream;
/*  529 */       } else if (null != param1OutputStream) {
/*  530 */         this.media = new BufferedOutputStream(param1OutputStream);
/*      */       } else {
/*  532 */         this.media = null;
/*      */       } 
/*  534 */       this.pos = 0L;
/*      */     }
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/*  539 */       if (null != this.media) {
/*  540 */         this.media.close();
/*  541 */         this.media = null;
/*      */       } 
/*      */     }
/*      */     
/*      */     public void flush() throws IOException {
/*  546 */       if (null != this.media) {
/*  547 */         this.media.flush();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean canInput() {
/*  552 */       return false;
/*      */     }
/*      */     public boolean canOutput() {
/*  555 */       return true;
/*      */     }
/*      */     public long position() {
/*  558 */       return this.pos;
/*      */     }
/*      */     
/*      */     public long position(long param1Long) throws UnsupportedOperationException, IllegalArgumentException {
/*  562 */       throw new UnsupportedOperationException("N/a for " + getClass().getCanonicalName());
/*      */     }
/*      */ 
/*      */     
/*      */     public long skip(long param1Long) throws IOException {
/*  567 */       long l1 = param1Long;
/*  568 */       while (l1 > 0L) {
/*  569 */         this.media.write(0);
/*  570 */         l1--;
/*      */       } 
/*  572 */       long l2 = param1Long - l1;
/*  573 */       this.pos += l2;
/*  574 */       return l2;
/*      */     }
/*      */     
/*      */     public OutputStream getStream() {
/*  578 */       return this.media;
/*      */     }
/*      */     
/*      */     public void mark(int param1Int) throws UnsupportedOperationException {
/*  582 */       throw new UnsupportedOperationException("not allowed with output stream");
/*      */     }
/*      */ 
/*      */     
/*      */     public void reset() throws UnsupportedOperationException {
/*  587 */       throw new UnsupportedOperationException("not allowed with output stream");
/*      */     }
/*      */ 
/*      */     
/*      */     public int read() throws UnsupportedOperationException {
/*  592 */       throw new UnsupportedOperationException("not allowed with output stream");
/*      */     }
/*      */ 
/*      */     
/*      */     public int write(byte param1Byte) throws IOException {
/*  597 */       int i = 0xFF & param1Byte;
/*  598 */       this.media.write(i);
/*  599 */       if (Bitstream.DEBUG) {
/*  600 */         System.err.println("u8[" + this.pos + "] <- " + Bitstream.toHexBinString(true, i, 8));
/*      */       }
/*  602 */       this.pos++;
/*  603 */       return i;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Bitstream(ByteStream<T> paramByteStream, boolean paramBoolean) throws IllegalArgumentException {
/*  625 */     this.bytes = paramByteStream;
/*  626 */     this.outputMode = paramBoolean;
/*  627 */     resetLocal();
/*  628 */     validateMode();
/*  629 */     this.throwIOExceptionOnEOF = false;
/*      */   }
/*      */   
/*      */   private final void resetLocal() {
/*  633 */     this.bitBuffer = 0;
/*  634 */     this.bitCount = 0;
/*  635 */     this.bitsDataMark = 0;
/*  636 */     this.bitsCountMark = -1;
/*      */   }
/*      */   private final void validateMode() throws IllegalArgumentException {
/*  639 */     if (!canInput() && !canOutput()) {
/*  640 */       throw new IllegalArgumentException("stream can neither input nor output: " + this);
/*      */     }
/*  642 */     if (this.outputMode && !canOutput()) {
/*  643 */       throw new IllegalArgumentException("stream cannot output as requested: " + this);
/*      */     }
/*  645 */     if (!this.outputMode && !canInput()) {
/*  646 */       throw new IllegalArgumentException("stream cannot input as requested: " + this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setThrowIOExceptionOnEOF(boolean paramBoolean) {
/*  657 */     this.throwIOExceptionOnEOF = paramBoolean;
/*      */   }
/*      */   
/*      */   public final boolean getThrowIOExceptionOnEOF() {
/*  661 */     return this.throwIOExceptionOnEOF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStream(T paramT, boolean paramBoolean) throws IllegalArgumentException, IOException {
/*  673 */     if (null != this.bytes && this.outputMode) {
/*  674 */       flush();
/*      */     }
/*  676 */     this.bytes.setStream(paramT);
/*  677 */     this.outputMode = paramBoolean;
/*  678 */     resetLocal();
/*  679 */     validateMode();
/*      */   }
/*      */   
/*      */   public final ByteStream<T> getStream() {
/*  683 */     return this.bytes;
/*      */   }
/*      */   public final T getSubStream() {
/*  686 */     return this.bytes.getStream();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void close() throws IOException {
/*  702 */     if (null != this.bytes && this.outputMode) {
/*  703 */       flush();
/*      */     }
/*  705 */     this.bytes.close();
/*  706 */     this.bytes = null;
/*  707 */     resetLocal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int flush() throws IllegalStateException, IOException {
/*  721 */     if (!this.outputMode || null == this.bytes) {
/*  722 */       throw new IllegalStateException("not in output-mode: " + this);
/*      */     }
/*  724 */     this.bytes.flush();
/*  725 */     if (0 != this.bitCount) {
/*  726 */       int i = this.bytes.write((byte)this.bitBuffer);
/*  727 */       this.bitBuffer = 0;
/*  728 */       this.bitCount = 0;
/*  729 */       if (-1 == i) {
/*  730 */         if (this.throwIOExceptionOnEOF) {
/*  731 */           throw new IOException("EOS " + this);
/*      */         }
/*  733 */         return -1;
/*      */       } 
/*      */     } 
/*  736 */     return 0;
/*      */   }
/*      */   
/*      */   public final boolean canInput() {
/*  740 */     return (null != this.bytes) ? this.bytes.canInput() : false;
/*      */   }
/*      */   public final boolean canOutput() {
/*  743 */     return (null != this.bytes) ? this.bytes.canOutput() : false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void mark(int paramInt) throws IllegalStateException {
/*  751 */     if (this.outputMode || null == this.bytes) {
/*  752 */       throw new IllegalStateException("not in input-mode: " + this);
/*      */     }
/*  754 */     this.bytes.mark(paramInt);
/*  755 */     this.bitsDataMark = this.bitBuffer;
/*  756 */     this.bitsCountMark = this.bitCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void reset() throws IllegalStateException, IOException {
/*  769 */     if (this.outputMode || null == this.bytes) {
/*  770 */       throw new IllegalStateException("not in input-mode: " + this);
/*      */     }
/*  772 */     if (0 > this.bitsCountMark) {
/*  773 */       throw new IllegalStateException("markpos not set: " + this);
/*      */     }
/*  775 */     this.bytes.reset();
/*  776 */     this.bitBuffer = this.bitsDataMark;
/*  777 */     this.bitCount = this.bitsCountMark;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getBitCount() {
/*  791 */     return this.bitCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getLastBitPos() {
/*  800 */     return 7 - this.bitCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getBitPosition() {
/*  810 */     if (0 == this.bitCount) {
/*  811 */       return 0;
/*      */     }
/*  813 */     return 8 - this.bitCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getBitBuffer() {
/*  821 */     return this.bitBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long position() {
/*  829 */     if (null == this.bytes)
/*  830 */       return -1L; 
/*  831 */     if (0 == this.bitCount) {
/*  832 */       return this.bytes.position() << 3L;
/*      */     }
/*  834 */     long l = this.bytes.position() - (this.outputMode ? 0L : 1L);
/*  835 */     return (l << 3L) + 8L - this.bitCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long position(long paramLong) throws UnsupportedOperationException, IllegalArgumentException, IllegalStateException, IOException {
/*  862 */     if (0L > paramLong) {
/*  863 */       throw new IllegalArgumentException("new position not positive: " + paramLong);
/*      */     }
/*  865 */     this.bytes.position(0L);
/*  866 */     resetLocal();
/*  867 */     if (paramLong > skip(paramLong)) {
/*  868 */       return -1L;
/*      */     }
/*  870 */     return paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int readBit(boolean paramBoolean) throws UnsupportedOperationException, IllegalStateException, IOException {
/*  880 */     if (this.outputMode || null == this.bytes) {
/*  881 */       throw new IllegalStateException("not in input-mode: " + this);
/*      */     }
/*  883 */     if (0 < this.bitCount) {
/*  884 */       this.bitCount--;
/*  885 */       if (paramBoolean) {
/*  886 */         return this.bitBuffer >>> this.bitCount & 0x1;
/*      */       }
/*  888 */       return this.bitBuffer >>> 7 - this.bitCount & 0x1;
/*      */     } 
/*      */     
/*  891 */     this.bitBuffer = this.bytes.read();
/*  892 */     if (-1 == this.bitBuffer) {
/*  893 */       if (this.throwIOExceptionOnEOF) {
/*  894 */         throw new IOException("EOS " + this);
/*      */       }
/*  896 */       return -1;
/*      */     } 
/*  898 */     this.bitCount = 7;
/*  899 */     if (paramBoolean) {
/*  900 */       return this.bitBuffer >>> 7;
/*      */     }
/*  902 */     return this.bitBuffer & 0x1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int writeBit(boolean paramBoolean, int paramInt) throws IllegalStateException, IOException {
/*  916 */     if (!this.outputMode || null == this.bytes) {
/*  917 */       throw new IllegalStateException("not in output-mode: " + this);
/*      */     }
/*  919 */     if (0 < this.bitCount) {
/*  920 */       this.bitCount--;
/*  921 */       if (paramBoolean) {
/*  922 */         this.bitBuffer |= (0x1 & paramInt) << this.bitCount;
/*      */       } else {
/*  924 */         this.bitBuffer |= (0x1 & paramInt) << 7 - this.bitCount;
/*      */       } 
/*  926 */       if (0 == this.bitCount) {
/*  927 */         int i = this.bytes.write((byte)this.bitBuffer);
/*  928 */         if (this.throwIOExceptionOnEOF && -1 == i) {
/*  929 */           throw new IOException("EOS " + this);
/*      */         }
/*  931 */         return i;
/*      */       } 
/*      */     } else {
/*  934 */       this.bitCount = 7;
/*  935 */       if (paramBoolean) {
/*  936 */         this.bitBuffer = (0x1 & paramInt) << 7;
/*      */       } else {
/*  938 */         this.bitBuffer = 0x1 & paramInt;
/*      */       } 
/*      */     } 
/*  941 */     return this.bitBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long skip(long paramLong) throws IllegalStateException, IOException {
/*  953 */     if (null == this.bytes) {
/*  954 */       throw new IllegalStateException("closed: " + this);
/*      */     }
/*  956 */     if (DEBUG) {
/*  957 */       System.err.println("Bitstream.skip.0: " + paramLong + " - " + toStringImpl());
/*      */     }
/*  959 */     if (paramLong > 0L) {
/*  960 */       if (paramLong <= this.bitCount) {
/*  961 */         this.bitCount -= (int)paramLong;
/*  962 */         if (DEBUG) {
/*  963 */           System.err.println("Bitstream.skip.F_N1: " + paramLong + " - " + toStringImpl());
/*      */         }
/*  965 */         return paramLong;
/*      */       } 
/*  967 */       if (this.outputMode) {
/*  968 */         if (0 < this.bitCount && 
/*  969 */           -1 == this.bytes.write((byte)this.bitBuffer)) {
/*  970 */           return 0L;
/*      */         }
/*      */         
/*  973 */         this.bitBuffer = 0;
/*      */       } 
/*  975 */       long l1 = paramLong - this.bitCount;
/*  976 */       long l2 = l1 >>> 3L;
/*  977 */       long l3 = this.bytes.skip(l2);
/*  978 */       int i = (int)(l1 - (l2 << 3L));
/*  979 */       long l4 = (l3 << 3L) + i + this.bitCount;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  984 */       if (l4 < paramLong) {
/*      */         
/*  986 */         this.bitCount = 0;
/*  987 */         this.bitBuffer = 0;
/*  988 */         if (DEBUG) {
/*  989 */           System.err.println("Bitstream.skip.F_EOS: " + paramLong + " - " + toStringImpl());
/*      */         }
/*  991 */         if (this.throwIOExceptionOnEOF) {
/*  992 */           throw new IOException("EOS " + this);
/*      */         }
/*  994 */         return l4;
/*      */       } 
/*  996 */       this.bitCount = 8 - i & 0x7;
/*  997 */       int j = 0;
/*  998 */       if (!this.outputMode && 0 < this.bitCount) {
/*  999 */         this.bitBuffer = this.bytes.read();
/* 1000 */         if (-1 == this.bitBuffer) {
/* 1001 */           j = this.bitCount;
/* 1002 */           this.bitCount = 0;
/*      */         } 
/*      */       } 
/* 1005 */       if (DEBUG) {
/* 1006 */         System.err.println("Bitstream.skip.F_N2: " + paramLong + ", notReadBits " + j + " - " + toStringImpl());
/*      */       }
/* 1008 */       return l4 - j;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1013 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBits31(int paramInt) throws IllegalArgumentException, IOException {
/*      */     int k;
/* 1032 */     if (31 < paramInt) {
/* 1033 */       throw new IllegalArgumentException("n > 31: " + paramInt);
/*      */     }
/* 1035 */     if (this.outputMode || null == this.bytes) {
/* 1036 */       throw new IllegalStateException("not in input-mode: " + this);
/*      */     }
/* 1038 */     if (0 == paramInt) {
/* 1039 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1057 */     int i = paramInt;
/* 1058 */     int j = Math.min(paramInt, this.bitCount);
/*      */     
/* 1060 */     if (0 < j) {
/* 1061 */       int n = (1 << j) - 1;
/* 1062 */       int i1 = 7 - this.bitCount + 1;
/* 1063 */       this.bitCount -= j;
/* 1064 */       i -= j;
/*      */       
/* 1066 */       k = n & this.bitBuffer >>> i1;
/* 1067 */       if (0 == i) {
/* 1068 */         return k;
/*      */       }
/*      */     } else {
/* 1071 */       k = 0;
/*      */     } 
/* 1073 */     assert 0 == this.bitCount;
/* 1074 */     int m = j;
/*      */     while (true) {
/* 1076 */       this.bitBuffer = this.bytes.read();
/* 1077 */       if (-1 == this.bitBuffer) {
/* 1078 */         if (this.throwIOExceptionOnEOF) {
/* 1079 */           throw new IOException("EOS " + this);
/*      */         }
/* 1081 */         return -1;
/*      */       } 
/* 1083 */       int n = Math.min(i, 8);
/* 1084 */       int i1 = (1 << n) - 1;
/* 1085 */       this.bitCount = 8 - n;
/* 1086 */       i -= n;
/*      */       
/* 1088 */       k |= (i1 & this.bitBuffer) << m;
/* 1089 */       m += n;
/* 1090 */       if (0 >= i) {
/* 1091 */         return k;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBits31(int paramInt1, int paramInt2) throws IllegalStateException, IllegalArgumentException, IOException {
/* 1109 */     if (31 < paramInt1) {
/* 1110 */       throw new IllegalArgumentException("n > 31: " + paramInt1);
/*      */     }
/* 1112 */     if (!this.outputMode || null == this.bytes) {
/* 1113 */       throw new IllegalStateException("not in output-mode: " + this);
/*      */     }
/* 1115 */     if (0 < paramInt1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1126 */       int i = paramInt1;
/* 1127 */       int j = Math.min(paramInt1, this.bitCount);
/* 1128 */       if (0 < j) {
/* 1129 */         int m = (1 << j) - 1;
/* 1130 */         int n = 7 - this.bitCount + 1;
/* 1131 */         this.bitCount -= j;
/* 1132 */         i -= j;
/*      */         
/* 1134 */         this.bitBuffer |= (m & paramInt2) << n;
/* 1135 */         if (0 == this.bitCount && 
/* 1136 */           -1 == this.bytes.write((byte)this.bitBuffer)) {
/* 1137 */           if (this.throwIOExceptionOnEOF) {
/* 1138 */             throw new IOException("EOS " + this);
/*      */           }
/* 1140 */           return -1;
/*      */         } 
/*      */         
/* 1143 */         if (0 == i) {
/* 1144 */           return paramInt2;
/*      */         }
/*      */       } 
/* 1147 */       assert 0 == this.bitCount;
/* 1148 */       int k = j;
/*      */       do {
/* 1150 */         int m = Math.min(i, 8);
/* 1151 */         int n = (1 << m) - 1;
/* 1152 */         this.bitCount = 8 - m;
/* 1153 */         i -= m;
/*      */         
/* 1155 */         this.bitBuffer = n & paramInt2 >>> k;
/* 1156 */         k += m;
/* 1157 */         if (0 == this.bitCount && 
/* 1158 */           -1 == this.bytes.write((byte)this.bitBuffer)) {
/* 1159 */           if (this.throwIOExceptionOnEOF) {
/* 1160 */             throw new IOException("EOS " + this);
/*      */           }
/* 1162 */           return -1;
/*      */         }
/*      */       
/* 1165 */       } while (0 < i);
/*      */     } 
/*      */     
/* 1168 */     return paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int readUInt8() throws IllegalStateException, IOException {
/* 1182 */     if (0 == this.bitCount) {
/*      */       
/* 1184 */       if (this.outputMode || null == this.bytes) {
/* 1185 */         throw new IllegalStateException("not in input-mode: " + this);
/*      */       }
/* 1187 */       int i = this.bytes.read();
/* 1188 */       if (this.throwIOExceptionOnEOF && -1 == i) {
/* 1189 */         throw new IOException("EOS " + this);
/*      */       }
/* 1191 */       return i;
/*      */     } 
/* 1193 */     return readBits31(8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int writeInt8(byte paramByte) throws IllegalStateException, IOException {
/* 1204 */     if (0 == this.bitCount) {
/*      */       
/* 1206 */       if (!this.outputMode || null == this.bytes) {
/* 1207 */         throw new IllegalStateException("not in output-mode: " + this);
/*      */       }
/* 1209 */       int i = this.bytes.write(paramByte);
/* 1210 */       if (this.throwIOExceptionOnEOF && -1 == i) {
/* 1211 */         throw new IOException("EOS " + this);
/*      */       }
/* 1213 */       return i;
/*      */     } 
/* 1215 */     return writeBits31(8, paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int readUInt16(boolean paramBoolean) throws IllegalStateException, IOException {
/* 1232 */     if (0 == this.bitCount) {
/*      */       
/* 1234 */       if (this.outputMode || null == this.bytes) {
/* 1235 */         throw new IllegalStateException("not in input-mode: " + this);
/*      */       }
/* 1237 */       int j = this.bytes.read();
/* 1238 */       byte b = (-1 != j) ? this.bytes.read() : -1;
/* 1239 */       if (-1 == b) {
/* 1240 */         if (this.throwIOExceptionOnEOF) {
/* 1241 */           throw new IOException("EOS " + this);
/*      */         }
/* 1243 */         return -1;
/* 1244 */       }  if (paramBoolean) {
/* 1245 */         return j << 8 | b;
/*      */       }
/* 1247 */       return b << 8 | j;
/*      */     } 
/*      */     
/* 1250 */     int i = readBits31(16);
/* 1251 */     if (-1 == i)
/* 1252 */       return -1; 
/* 1253 */     if (paramBoolean) {
/* 1254 */       int j = 0xFF & i >>> 8;
/* 1255 */       int k = 0xFF & i;
/* 1256 */       return k << 8 | j;
/*      */     } 
/* 1258 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int readUInt16(boolean paramBoolean, byte[] paramArrayOfbyte, int paramInt) throws IndexOutOfBoundsException {
/* 1273 */     checkBounds(paramArrayOfbyte, paramInt, 2);
/*      */     
/* 1275 */     int i = paramArrayOfbyte[paramInt] & 0xFF;
/* 1276 */     int j = paramArrayOfbyte[paramInt + 1] & 0xFF;
/* 1277 */     if (paramBoolean) {
/* 1278 */       return i << 8 | j;
/*      */     }
/* 1280 */     return j << 8 | i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int writeInt16(boolean paramBoolean, short paramShort) throws IllegalStateException, IOException {
/* 1293 */     if (0 == this.bitCount) {
/*      */       byte b3, b4;
/* 1295 */       if (!this.outputMode || null == this.bytes) {
/* 1296 */         throw new IllegalStateException("not in output-mode: " + this);
/*      */       }
/* 1298 */       byte b1 = (byte)(0xFF & paramShort >>> 8);
/* 1299 */       byte b2 = (byte)(0xFF & paramShort);
/*      */       
/* 1301 */       if (paramBoolean) {
/* 1302 */         b3 = b1;
/* 1303 */         b4 = b2;
/*      */       } else {
/* 1305 */         b3 = b2;
/* 1306 */         b4 = b1;
/*      */       } 
/* 1308 */       if (-1 != this.bytes.write(b3) && 
/* 1309 */         -1 != this.bytes.write(b4)) {
/* 1310 */         return paramShort;
/*      */       }
/*      */       
/* 1313 */       if (this.throwIOExceptionOnEOF) {
/* 1314 */         throw new IOException("EOS " + this);
/*      */       }
/* 1316 */       return -1;
/* 1317 */     }  if (paramBoolean) {
/* 1318 */       int i = 0xFF & paramShort >>> 8;
/* 1319 */       int j = 0xFF & paramShort;
/* 1320 */       return writeBits31(16, j << 8 | i);
/*      */     } 
/* 1322 */     return writeBits31(16, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long readUInt32(boolean paramBoolean) throws IllegalStateException, IOException {
/* 1339 */     if (0 == this.bitCount) {
/*      */       
/* 1341 */       if (this.outputMode || null == this.bytes) {
/* 1342 */         throw new IllegalStateException("not in input-mode: " + this);
/*      */       }
/* 1344 */       int j = this.bytes.read();
/* 1345 */       byte b1 = (-1 != j) ? this.bytes.read() : -1;
/* 1346 */       byte b2 = (-1 != b1) ? this.bytes.read() : -1;
/* 1347 */       byte b3 = (-1 != b2) ? this.bytes.read() : -1;
/* 1348 */       if (-1 == b3) {
/* 1349 */         if (this.throwIOExceptionOnEOF) {
/* 1350 */           throw new IOException("EOS " + this);
/*      */         }
/* 1352 */         return -1L;
/* 1353 */       }  if (paramBoolean) {
/* 1354 */         return 0xFFFFFFFFL & (j << 24 | b1 << 16 | b2 << 8 | b3);
/*      */       }
/* 1356 */       return 0xFFFFFFFFL & (b3 << 24 | b2 << 16 | b1 << 8 | j);
/*      */     } 
/*      */     
/* 1359 */     int i = readBits31(16);
/* 1360 */     byte b = (-1 != i) ? readBits31(16) : -1;
/* 1361 */     if (-1 == b)
/* 1362 */       return -1L; 
/* 1363 */     if (paramBoolean) {
/* 1364 */       int j = 0xFF & b >>> 8;
/* 1365 */       int k = 0xFF & b;
/* 1366 */       int m = 0xFF & i >>> 8;
/* 1367 */       int n = 0xFF & i;
/* 1368 */       return 0xFFFFFFFFL & (n << 24 | m << 16 | k << 8 | j);
/*      */     } 
/* 1370 */     return 0xFFFFFFFFL & (b << 16 | i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final long readUInt32(boolean paramBoolean, byte[] paramArrayOfbyte, int paramInt) throws IndexOutOfBoundsException {
/* 1385 */     checkBounds(paramArrayOfbyte, paramInt, 4);
/* 1386 */     byte b1 = paramArrayOfbyte[paramInt];
/* 1387 */     byte b2 = paramArrayOfbyte[paramInt + 1];
/* 1388 */     byte b3 = paramArrayOfbyte[paramInt + 2];
/* 1389 */     byte b4 = paramArrayOfbyte[paramInt + 3];
/* 1390 */     if (paramBoolean) {
/* 1391 */       return 0xFFFFFFFFL & (b1 << 24 | b2 << 16 | b3 << 8 | b4);
/*      */     }
/* 1393 */     return 0xFFFFFFFFL & (b4 << 24 | b3 << 16 | b2 << 8 | b1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int writeInt32(boolean paramBoolean, int paramInt) throws IllegalStateException, IOException {
/* 1406 */     if (0 == this.bitCount) {
/*      */       byte b5, b6, b7, b8;
/* 1408 */       if (!this.outputMode || null == this.bytes) {
/* 1409 */         throw new IllegalStateException("not in output-mode: " + this);
/*      */       }
/* 1411 */       byte b1 = (byte)(0xFF & paramInt >>> 24);
/* 1412 */       byte b2 = (byte)(0xFF & paramInt >>> 16);
/* 1413 */       byte b3 = (byte)(0xFF & paramInt >>> 8);
/* 1414 */       byte b4 = (byte)(0xFF & paramInt);
/*      */       
/* 1416 */       if (paramBoolean) {
/* 1417 */         b5 = b1;
/* 1418 */         b6 = b2;
/* 1419 */         b7 = b3;
/* 1420 */         b8 = b4;
/*      */       } else {
/* 1422 */         b5 = b4;
/* 1423 */         b6 = b3;
/* 1424 */         b7 = b2;
/* 1425 */         b8 = b1;
/*      */       } 
/* 1427 */       if (-1 != this.bytes.write(b5) && 
/* 1428 */         -1 != this.bytes.write(b6) && 
/* 1429 */         -1 != this.bytes.write(b7) && 
/* 1430 */         -1 != this.bytes.write(b8)) {
/* 1431 */         return paramInt;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1436 */       if (this.throwIOExceptionOnEOF) {
/* 1437 */         throw new IOException("EOS " + this);
/*      */       }
/* 1439 */       return -1;
/* 1440 */     }  if (paramBoolean) {
/* 1441 */       int k = 0xFF & paramInt >>> 24;
/* 1442 */       int m = 0xFF & paramInt >>> 16;
/* 1443 */       int n = 0xFF & paramInt >>> 8;
/* 1444 */       int i1 = 0xFF & paramInt;
/* 1445 */       if (-1 != writeBits31(16, m << 8 | k) && 
/* 1446 */         -1 != writeBits31(16, i1 << 8 | n)) {
/* 1447 */         return paramInt;
/*      */       }
/*      */       
/* 1450 */       return -1;
/*      */     } 
/* 1452 */     int i = 0xFFFF & paramInt >>> 16;
/* 1453 */     int j = 0xFFFF & paramInt;
/* 1454 */     if (-1 != writeBits31(16, j) && 
/* 1455 */       -1 != writeBits31(16, i)) {
/* 1456 */       return paramInt;
/*      */     }
/*      */     
/* 1459 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final long toUInt32Long(int paramInt) {
/* 1471 */     return 0xFFFFFFFFL & paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int toUInt32Int(int paramInt) {
/* 1481 */     return uint32LongToInt(toUInt32Long(paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int uint32LongToInt(long paramLong) {
/* 1490 */     if (2147483647L >= paramLong) {
/* 1491 */       return (int)paramLong;
/*      */     }
/* 1493 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1499 */     return String.format("Bitstream[%s]", new Object[] { toStringImpl() });
/*      */   }
/*      */   protected String toStringImpl() {
/*      */     String str;
/*      */     long l;
/* 1504 */     if (null == this.bytes) {
/* 1505 */       str = "closed";
/* 1506 */       l = -1L;
/*      */     } else {
/* 1508 */       str = this.outputMode ? "output" : "input";
/* 1509 */       l = this.bytes.position();
/*      */     } 
/* 1511 */     return String.format((Locale)null, "%s, pos %d [byteP %d, bitCnt %d], bitbuf %s", new Object[] { str, 
/* 1512 */           Long.valueOf(position()), Long.valueOf(l), Integer.valueOf(this.bitCount), toHexBinString(true, this.bitBuffer, 8) });
/*      */   }
/*      */ 
/*      */   
/*      */   public static String toBinString(boolean paramBoolean, int paramInt1, int paramInt2) {
/* 1517 */     if (0 == paramInt2) {
/* 1518 */       return "";
/*      */     }
/* 1520 */     if (paramBoolean) {
/* 1521 */       int i = (int)((1L << paramInt2) - 1L);
/* 1522 */       String str1 = Integer.toBinaryString(i & paramInt1);
/* 1523 */       return "0000000000000000000000000000000000000000000000000000000000000000".substring(0, paramInt2 - str1.length()) + str1;
/*      */     } 
/* 1525 */     char[] arrayOfChar = new char[32];
/* 1526 */     for (byte b = 0; b < paramInt2; b++) {
/* 1527 */       arrayOfChar[b] = (0 != (paramInt1 & 1 << b)) ? '1' : '0';
/*      */     }
/* 1529 */     String str = new String(arrayOfChar, 0, paramInt2);
/* 1530 */     return str + "0000000000000000000000000000000000000000000000000000000000000000".substring(0, paramInt2 - str.length());
/*      */   }
/*      */   
/*      */   public static String toHexBinString(boolean paramBoolean, int paramInt1, int paramInt2) {
/* 1534 */     boolean bool = (0 == paramInt2) ? true : ((paramInt2 + 3) / 4);
/* 1535 */     return String.format((Locale)null, "[0x%0" + bool + "X, msbFirst %b, %s]", new Object[] { Integer.valueOf(paramInt1), Boolean.valueOf(paramBoolean), toBinString(paramBoolean, paramInt1, paramInt2) });
/*      */   }
/*      */   public static final String toHexBinString(boolean paramBoolean, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 1538 */     StringBuilder stringBuilder = new StringBuilder();
/* 1539 */     stringBuilder.append("[");
/* 1540 */     for (byte b = 0; b < paramInt2; b++) {
/* 1541 */       int i = 0xFF & paramArrayOfbyte[paramInt1 + b];
/* 1542 */       stringBuilder.append(toHexBinString(paramBoolean, i, 8)).append(", ");
/*      */     } 
/* 1544 */     stringBuilder.append("]");
/* 1545 */     return stringBuilder.toString();
/*      */   }
/*      */   public static final String toHexBinString(boolean paramBoolean, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) {
/* 1548 */     StringBuilder stringBuilder = new StringBuilder();
/* 1549 */     stringBuilder.append("[");
/* 1550 */     for (byte b = 0; b < paramInt2; b++) {
/* 1551 */       int i = 0xFF & paramByteBuffer.get(paramInt1 + b);
/* 1552 */       stringBuilder.append(toHexBinString(paramBoolean, i, 8)).append(", ");
/*      */     } 
/* 1554 */     stringBuilder.append("]");
/* 1555 */     return stringBuilder.toString();
/*      */   }
/*      */   
/*      */   public static void checkBounds(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IndexOutOfBoundsException {
/* 1559 */     if (paramInt1 + paramInt2 > paramArrayOfbyte.length)
/* 1560 */       throw new IndexOutOfBoundsException("Buffer of size " + paramArrayOfbyte.length + " cannot hold offset " + paramInt1 + " + remaining " + paramInt2); 
/*      */   }
/*      */   
/*      */   public static interface ByteStream<T> {
/*      */     void setStream(T param1T);
/*      */     
/*      */     T getStream();
/*      */     
/*      */     void close() throws IOException;
/*      */     
/*      */     void flush() throws IOException;
/*      */     
/*      */     boolean canInput();
/*      */     
/*      */     boolean canOutput();
/*      */     
/*      */     long position();
/*      */     
/*      */     long position(long param1Long) throws UnsupportedOperationException, IllegalArgumentException;
/*      */     
/*      */     long skip(long param1Long) throws IOException;
/*      */     
/*      */     void mark(int param1Int) throws UnsupportedOperationException;
/*      */     
/*      */     void reset() throws UnsupportedOperationException, IllegalStateException, IOException;
/*      */     
/*      */     int read() throws UnsupportedOperationException, IOException;
/*      */     
/*      */     int write(byte param1Byte) throws UnsupportedOperationException, IOException;
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/Bitstream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */