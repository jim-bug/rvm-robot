/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.ExceptionUtils;
/*     */ import com.jogamp.common.JogampRuntimeException;
/*     */ import com.jogamp.common.os.Clock;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReflectionUtil
/*     */ {
/*     */   public static final boolean DEBUG;
/*     */   public static final boolean DEBUG_STATS_FORNAME;
/*     */   private static final Object forNameLock;
/*     */   private static final Map<String, ClassNameLookup> forNameStats;
/*  63 */   private static int forNameCount = 0;
/*  64 */   private static long forNameNanoCosts = 0L; private static final Class<?>[] zeroTypes; public static class AWTNames {
/*     */     public static final String ComponentClass = "java.awt.Component"; public static final String GraphicsEnvironmentClass = "java.awt.GraphicsEnvironment"; public static final String isHeadlessMethod = "isHeadless"; }
/*     */   static {
/*  67 */     Debug.initSingleton();
/*  68 */     DEBUG = Debug.debug("ReflectionUtil");
/*  69 */     DEBUG_STATS_FORNAME = PropertyAccess.isPropertyDefined("jogamp.debug.ReflectionUtil.forNameStats", true);
/*  70 */     if (DEBUG_STATS_FORNAME) {
/*  71 */       forNameLock = new Object();
/*  72 */       forNameStats = new HashMap<>();
/*     */     } else {
/*  74 */       forNameLock = null;
/*  75 */       forNameStats = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     zeroTypes = new Class[0];
/*     */   }
/*     */   
/*     */   private static class ClassNameLookup { public ClassNameLookup(String param1String) {
/*  88 */       this.name = param1String;
/*  89 */       this.nanoCosts = 0L;
/*  90 */       this.count = 0;
/*     */     }
/*     */     public final String name;
/*     */     public long nanoCosts;
/*     */     public int count;
/*     */     
/*     */     public String toString() {
/*  97 */       return String.format((Locale)null, "%8.3f ms, %03d invoc, %s", new Object[] { Double.valueOf(this.nanoCosts / 1000000.0D), Integer.valueOf(this.count), this.name });
/*     */     } }
/*     */   
/*     */   public static void resetForNameCount() {
/* 101 */     if (DEBUG_STATS_FORNAME)
/* 102 */       synchronized (forNameLock) {
/* 103 */         forNameCount = 0;
/* 104 */         forNameNanoCosts = 0L;
/* 105 */         forNameStats.clear();
/*     */       }  
/*     */   }
/*     */   
/*     */   public static StringBuilder getForNameStats(StringBuilder paramStringBuilder) {
/* 110 */     if (null == paramStringBuilder) {
/* 111 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 113 */     if (DEBUG_STATS_FORNAME)
/* 114 */       synchronized (forNameLock) {
/* 115 */         paramStringBuilder.append(String.format("ReflectionUtil.forName: %8.3f ms, %03d invoc%n", new Object[] { Double.valueOf(forNameNanoCosts / 1000000.0D), Integer.valueOf(forNameCount) }));
/* 116 */         Set<Map.Entry<String, ClassNameLookup>> set = forNameStats.entrySet();
/* 117 */         byte b = 0;
/* 118 */         for (Map.Entry<String, ClassNameLookup> entry : set) {
/*     */           
/* 120 */           paramStringBuilder.append(String.format("ReflectionUtil.forName[%03d]: %s%n", new Object[] { Integer.valueOf(b), entry.getValue() }));
/*     */           b++;
/*     */         } 
/*     */       }  
/* 124 */     return paramStringBuilder;
/*     */   }
/*     */   
/*     */   private static Class<?> getClassImpl(String paramString, boolean paramBoolean, ClassLoader paramClassLoader) throws ClassNotFoundException {
/* 128 */     if (DEBUG_STATS_FORNAME) {
/* 129 */       long l1 = Clock.currentNanos();
/* 130 */       Class<?> clazz = Class.forName(paramString, paramBoolean, paramClassLoader);
/* 131 */       long l2 = Clock.currentNanos();
/* 132 */       long l3 = l2 - l1;
/* 133 */       synchronized (forNameLock) {
/* 134 */         forNameCount++;
/* 135 */         forNameNanoCosts += l3;
/* 136 */         ClassNameLookup classNameLookup = forNameStats.get(paramString);
/* 137 */         if (null == classNameLookup) {
/* 138 */           classNameLookup = new ClassNameLookup(paramString);
/* 139 */           forNameStats.put(paramString, classNameLookup);
/*     */         } 
/* 141 */         classNameLookup.count++;
/* 142 */         classNameLookup.nanoCosts += l3;
/* 143 */         System.err.printf("ReflectionUtil.getClassImpl.%03d: %8.3f ms, init %b, [%s]@ Thread %s%n", new Object[] {
/* 144 */               Integer.valueOf(forNameCount), Double.valueOf(l3 / 1000000.0D), Boolean.valueOf(paramBoolean), classNameLookup.toString(), Thread.currentThread().getName() });
/* 145 */         if (DEBUG) {
/* 146 */           ExceptionUtils.dumpStack(System.err);
/*     */         }
/*     */       } 
/* 149 */       return clazz;
/*     */     } 
/* 151 */     return Class.forName(paramString, paramBoolean, paramClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isClassAvailable(String paramString, ClassLoader paramClassLoader) {
/*     */     try {
/* 160 */       return (null != getClassImpl(paramString, false, paramClassLoader));
/* 161 */     } catch (ClassNotFoundException classNotFoundException) {
/* 162 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Class<?> getClass(String paramString, boolean paramBoolean, ClassLoader paramClassLoader) throws JogampRuntimeException {
/*     */     try {
/* 173 */       return getClassImpl(paramString, paramBoolean, paramClassLoader);
/* 174 */     } catch (ClassNotFoundException classNotFoundException) {
/* 175 */       throw new JogampRuntimeException(paramString + " not available", classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Constructor<?> getConstructor(String paramString, Class<?>[] paramArrayOfClass, boolean paramBoolean, ClassLoader paramClassLoader) throws JogampRuntimeException {
/*     */     try {
/* 186 */       return getConstructor(getClassImpl(paramString, paramBoolean, paramClassLoader), paramArrayOfClass);
/* 187 */     } catch (ClassNotFoundException classNotFoundException) {
/* 188 */       throw new JogampRuntimeException(paramString + " not available", classNotFoundException);
/*     */     } 
/*     */   }
/*     */   
/*     */   static final String asString(Class<?>[] paramArrayOfClass) {
/* 193 */     StringBuilder stringBuilder = new StringBuilder();
/* 194 */     boolean bool = false;
/* 195 */     if (null != paramArrayOfClass) {
/* 196 */       for (byte b = 0; b < paramArrayOfClass.length; b++) {
/* 197 */         if (bool) {
/* 198 */           stringBuilder.append(", ");
/*     */         }
/* 200 */         stringBuilder.append(paramArrayOfClass[b].getName());
/* 201 */         bool = true;
/*     */       } 
/*     */     }
/* 204 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Constructor<?> getConstructor(Class<?> paramClass, Class<?>... paramVarArgs) throws JogampRuntimeException {
/* 222 */     if (null == paramVarArgs) {
/* 223 */       paramVarArgs = zeroTypes;
/*     */     }
/* 225 */     Constructor<?> constructor = null;
/*     */     try {
/* 227 */       constructor = paramClass.getDeclaredConstructor(paramVarArgs);
/* 228 */     } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */     
/* 231 */     if (null == constructor) {
/* 232 */       Constructor[] arrayOfConstructor = (Constructor[])paramClass.getConstructors();
/* 233 */       for (byte b = 0; null == constructor && b < arrayOfConstructor.length; b++) {
/* 234 */         Constructor<?> constructor1 = arrayOfConstructor[b];
/* 235 */         Class[] arrayOfClass = constructor1.getParameterTypes();
/* 236 */         if (arrayOfClass.length == paramVarArgs.length) {
/*     */           byte b1;
/* 238 */           for (b1 = 0; b1 < arrayOfClass.length && 
/* 239 */             arrayOfClass[b1].isAssignableFrom(paramVarArgs[b1]); b1++);
/*     */ 
/*     */ 
/*     */           
/* 243 */           if (arrayOfClass.length == b1) {
/* 244 */             constructor = constructor1;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 249 */     if (null == constructor) {
/* 250 */       throw new JogampRuntimeException("Constructor: '" + paramClass.getName() + "(" + asString(paramVarArgs) + ")' not found");
/*     */     }
/* 252 */     return constructor;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final Constructor<?> getConstructor(String paramString, ClassLoader paramClassLoader) throws JogampRuntimeException {
/* 257 */     return getConstructor(paramString, null, true, paramClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object createInstance(Constructor<?> paramConstructor, Object... paramVarArgs) throws JogampRuntimeException, RuntimeException {
/*     */     try {
/* 267 */       return paramConstructor.newInstance(paramVarArgs);
/* 268 */     } catch (Exception exception) {
/* 269 */       Throwable throwable = exception;
/* 270 */       if (throwable instanceof InvocationTargetException) {
/* 271 */         throwable = ((InvocationTargetException)throwable).getTargetException();
/*     */       }
/* 273 */       if (throwable instanceof Error) {
/* 274 */         throw (Error)throwable;
/*     */       }
/* 276 */       if (throwable instanceof RuntimeException) {
/* 277 */         throw (RuntimeException)throwable;
/*     */       }
/* 279 */       throw new JogampRuntimeException("can not create instance of " + paramConstructor.getName(), throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object createInstance(Class<?> paramClass, Class<?>[] paramArrayOfClass, Object... paramVarArgs) throws JogampRuntimeException, RuntimeException {
/* 289 */     return createInstance(getConstructor(paramClass, paramArrayOfClass), paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object createInstance(Class<?> paramClass, Object... paramVarArgs) throws JogampRuntimeException, RuntimeException {
/* 295 */     Class[] arrayOfClass = null;
/* 296 */     if (null != paramVarArgs) {
/* 297 */       arrayOfClass = new Class[paramVarArgs.length];
/* 298 */       for (byte b = 0; b < paramVarArgs.length; b++) {
/* 299 */         arrayOfClass[b] = paramVarArgs[b].getClass();
/*     */       }
/*     */     } 
/* 302 */     return createInstance(paramClass, arrayOfClass, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object createInstance(String paramString, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject, ClassLoader paramClassLoader) throws JogampRuntimeException, RuntimeException {
/*     */     try {
/* 309 */       return createInstance(getClassImpl(paramString, true, paramClassLoader), paramArrayOfClass, paramArrayOfObject);
/* 310 */     } catch (ClassNotFoundException classNotFoundException) {
/* 311 */       throw new JogampRuntimeException(paramString + " not available", classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object createInstance(String paramString, Object[] paramArrayOfObject, ClassLoader paramClassLoader) throws JogampRuntimeException, RuntimeException {
/* 318 */     Class[] arrayOfClass = null;
/* 319 */     if (null != paramArrayOfObject) {
/* 320 */       arrayOfClass = new Class[paramArrayOfObject.length];
/* 321 */       for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 322 */         arrayOfClass[b] = paramArrayOfObject[b].getClass();
/*     */       }
/*     */     } 
/* 325 */     return createInstance(paramString, arrayOfClass, paramArrayOfObject, paramClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object createInstance(String paramString, ClassLoader paramClassLoader) throws JogampRuntimeException, RuntimeException {
/* 331 */     return createInstance(paramString, null, null, paramClassLoader);
/*     */   }
/*     */   
/*     */   public static final boolean instanceOf(Object paramObject, String paramString) {
/* 335 */     return instanceOf(paramObject.getClass(), paramString);
/*     */   }
/*     */   public static final boolean instanceOf(Class<?> paramClass, String paramString) {
/*     */     while (true) {
/* 339 */       if (paramClass.getName().equals(paramString)) {
/* 340 */         return true;
/*     */       }
/* 342 */       paramClass = paramClass.getSuperclass();
/* 343 */       if (paramClass == null)
/* 344 */         return false; 
/*     */     } 
/*     */   }
/*     */   public static final boolean implementationOf(Object paramObject, String paramString) {
/* 348 */     return implementationOf(paramObject.getClass(), paramString);
/*     */   }
/*     */   public static final boolean implementationOf(Class<?> paramClass, String paramString) {
/*     */     while (true) {
/* 352 */       Class[] arrayOfClass = paramClass.getInterfaces();
/* 353 */       for (int i = arrayOfClass.length - 1; i >= 0; i--) {
/* 354 */         Class clazz = arrayOfClass[i];
/* 355 */         if (clazz.getName().equals(paramString)) {
/* 356 */           return true;
/*     */         }
/*     */       } 
/* 359 */       paramClass = paramClass.getSuperclass();
/* 360 */       if (paramClass == null)
/* 361 */         return false; 
/*     */     } 
/*     */   }
/*     */   public static boolean isAWTComponent(Object paramObject) {
/* 365 */     return instanceOf(paramObject, "java.awt.Component");
/*     */   }
/*     */   
/*     */   public static boolean isAWTComponent(Class<?> paramClass) {
/* 369 */     return instanceOf(paramClass, "java.awt.Component");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Method getMethod(Class<?> paramClass, String paramString, Class<?>... paramVarArgs) throws JogampRuntimeException, RuntimeException {
/*     */     NoSuchMethodException noSuchMethodException;
/* 378 */     NoClassDefFoundError noClassDefFoundError = null;
/* 379 */     Method method = null;
/*     */     try {
/* 381 */       method = paramClass.getDeclaredMethod(paramString, paramVarArgs);
/* 382 */     } catch (NoClassDefFoundError noClassDefFoundError1) {
/* 383 */       noClassDefFoundError = noClassDefFoundError1;
/* 384 */     } catch (NoSuchMethodException noSuchMethodException1) {
/* 385 */       noSuchMethodException = noSuchMethodException1;
/*     */     } 
/* 387 */     if (null != noSuchMethodException) {
/* 388 */       throw new JogampRuntimeException("Method: '" + paramClass + "." + paramString + "(" + asString(paramVarArgs) + ")' not found", noSuchMethodException);
/*     */     }
/* 390 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Method getMethod(String paramString1, String paramString2, Class<?>[] paramArrayOfClass, ClassLoader paramClassLoader) throws JogampRuntimeException, RuntimeException {
/*     */     try {
/* 400 */       return getMethod(getClassImpl(paramString1, true, paramClassLoader), paramString2, paramArrayOfClass);
/* 401 */     } catch (ClassNotFoundException classNotFoundException) {
/* 402 */       throw new JogampRuntimeException(paramString1 + " not available", classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object callMethod(Object paramObject, Method paramMethod, Object... paramVarArgs) throws JogampRuntimeException, RuntimeException {
/*     */     try {
/* 418 */       return paramMethod.invoke(paramObject, paramVarArgs);
/* 419 */     } catch (Exception exception) {
/* 420 */       Throwable throwable = exception;
/* 421 */       if (throwable instanceof InvocationTargetException) {
/* 422 */         throwable = ((InvocationTargetException)throwable).getTargetException();
/*     */       }
/* 424 */       if (throwable instanceof Error) {
/* 425 */         throw (Error)throwable;
/*     */       }
/* 427 */       if (throwable instanceof RuntimeException) {
/* 428 */         throw (RuntimeException)throwable;
/*     */       }
/* 430 */       throw new JogampRuntimeException("calling " + paramMethod + " failed", throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object callStaticMethod(String paramString1, String paramString2, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject, ClassLoader paramClassLoader) throws JogampRuntimeException, RuntimeException {
/* 440 */     return callMethod(null, getMethod(paramString1, paramString2, paramArrayOfClass, paramClassLoader), paramArrayOfObject);
/*     */   }
/*     */   
/*     */   public static class MethodAccessor
/*     */   {
/* 445 */     Method m = null;
/*     */ 
/*     */     
/*     */     public MethodAccessor(Class<?> param1Class, String param1String, Class<?>... param1VarArgs) {
/*     */       try {
/* 450 */         this.m = ReflectionUtil.getMethod(param1Class, param1String, param1VarArgs);
/* 451 */       } catch (JogampRuntimeException jogampRuntimeException) {}
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean available() {
/* 456 */       return (null != this.m);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object callMethod(Object param1Object, Object... param1VarArgs) {
/* 464 */       if (null == this.m) {
/* 465 */         throw new JogampRuntimeException("Method not available. Instance: " + param1Object);
/*     */       }
/* 467 */       return ReflectionUtil.callMethod(param1Object, this.m, param1VarArgs);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/ReflectionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */