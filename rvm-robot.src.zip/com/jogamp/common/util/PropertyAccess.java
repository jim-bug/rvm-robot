/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.security.AccessControlException;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyAccess
/*     */ {
/*     */   public static final String jnlp_prefix = "jnlp.";
/*     */   public static final String javaws_prefix = "javaws.";
/*  46 */   static final HashSet<String> trustedPrefixes = new HashSet<>(); static {
/*  47 */     trustedPrefixes.add("javaws.");
/*  48 */     trustedPrefixes.add("jnlp.");
/*     */   }
/*     */   
/*  51 */   static final HashSet<String> trusted = new HashSet<>(); static {
/*  52 */     trusted.add("sun.java2d.opengl");
/*  53 */     trusted.add("sun.java2d.noddraw");
/*  54 */     trusted.add("sun.java2d.d3d");
/*  55 */     trusted.add("sun.awt.noerasebackground");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final void addTrustedPrefix(String paramString) throws AccessControlException {
/*  63 */     SecurityUtil.checkAllPermissions();
/*  64 */     trustedPrefixes.add(paramString);
/*     */   }
/*     */   
/*     */   public static final boolean isTrusted(String paramString) {
/*  68 */     int i = paramString.indexOf('.');
/*  69 */     if (0 <= i) {
/*  70 */       return (trustedPrefixes.contains(paramString.substring(0, i + 1)) || trusted.contains(paramString));
/*     */     }
/*  72 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getIntProperty(String paramString, boolean paramBoolean, int paramInt) {
/*  78 */     int i = paramInt;
/*     */     try {
/*  80 */       String str = getProperty(paramString, paramBoolean);
/*  81 */       if (null != str) {
/*  82 */         i = Integer.parseInt(str);
/*     */       }
/*  84 */     } catch (NumberFormatException numberFormatException) {}
/*  85 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final long getLongProperty(String paramString, boolean paramBoolean, long paramLong) {
/*  90 */     long l = paramLong;
/*     */     try {
/*  92 */       String str = getProperty(paramString, paramBoolean);
/*  93 */       if (null != str) {
/*  94 */         l = Long.parseLong(str);
/*     */       }
/*  96 */     } catch (NumberFormatException numberFormatException) {}
/*  97 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean getBooleanProperty(String paramString, boolean paramBoolean) {
/* 102 */     return Boolean.valueOf(getProperty(paramString, paramBoolean)).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean getBooleanProperty(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 107 */     String str = getProperty(paramString, paramBoolean1);
/* 108 */     if (null != str) {
/* 109 */       return Boolean.valueOf(str).booleanValue();
/*     */     }
/* 111 */     return paramBoolean2;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean isPropertyDefined(String paramString, boolean paramBoolean) {
/* 116 */     return (getProperty(paramString, paramBoolean) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getProperty(String paramString, boolean paramBoolean) throws SecurityException, NullPointerException, IllegalArgumentException {
/* 140 */     if (null == paramString) {
/* 141 */       throw new NullPointerException("propertyKey is NULL");
/*     */     }
/* 143 */     if (0 == paramString.length()) {
/* 144 */       throw new IllegalArgumentException("propertyKey is empty");
/*     */     }
/* 146 */     String str = null;
/*     */     
/* 148 */     if (isTrusted(paramString)) {
/*     */       
/* 150 */       str = getTrustedPropKey(paramString);
/*     */     } else {
/*     */       
/* 153 */       str = System.getProperty(paramString);
/*     */     } 
/* 155 */     if (null == str && paramBoolean)
/*     */     {
/* 157 */       if (!paramString.startsWith("jnlp."))
/*     */       {
/*     */         
/* 160 */         str = getTrustedPropKey("jnlp." + paramString);
/*     */       }
/*     */     }
/* 163 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getProperty(String paramString1, boolean paramBoolean, String paramString2) throws SecurityException, NullPointerException, IllegalArgumentException {
/* 169 */     String str = getProperty(paramString1, paramBoolean);
/* 170 */     if (null != str) {
/* 171 */       return str;
/*     */     }
/* 173 */     return paramString2;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final String getTrustedPropKey(final String propertyKey) {
/* 178 */     return SecurityUtil.<String>doPrivileged(new PrivilegedAction<String>()
/*     */         {
/*     */           public String run() {
/*     */             try {
/* 182 */               return System.getProperty(propertyKey);
/* 183 */             } catch (SecurityException securityException) {
/* 184 */               throw new SecurityException("Could not access trusted property '" + propertyKey + "'", securityException);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/PropertyAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */