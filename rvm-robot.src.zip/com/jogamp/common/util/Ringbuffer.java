package com.jogamp.common.util;

import java.io.PrintStream;

public interface Ringbuffer<T> {
  String toString();
  
  void dump(PrintStream paramPrintStream, String paramString);
  
  int capacity();
  
  void clear();
  
  void resetFull(T[] paramArrayOfT) throws IllegalArgumentException;
  
  int size();
  
  int getFreeSlots();
  
  boolean isEmpty();
  
  boolean isFull();
  
  T get();
  
  T getBlocking() throws InterruptedException;
  
  T peek();
  
  T peekBlocking() throws InterruptedException;
  
  boolean put(T paramT);
  
  void putBlocking(T paramT) throws InterruptedException;
  
  boolean putSame(boolean paramBoolean) throws InterruptedException;
  
  void waitForFreeSlots(int paramInt) throws InterruptedException;
  
  void growEmptyBuffer(T[] paramArrayOfT) throws IllegalStateException, IllegalArgumentException;
  
  void growFullBuffer(int paramInt) throws IllegalStateException, IllegalArgumentException;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/Ringbuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */