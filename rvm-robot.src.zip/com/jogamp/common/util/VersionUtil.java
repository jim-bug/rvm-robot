/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.os.AndroidVersion;
/*     */ import com.jogamp.common.os.Platform;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Set;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.Manifest;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionUtil
/*     */ {
/*     */   public static final String SEPERATOR = "-----------------------------------------------------------------------------------------------------";
/*     */   
/*     */   public static StringBuilder getPlatformInfo(StringBuilder paramStringBuilder) {
/*  53 */     if (null == paramStringBuilder) {
/*  54 */       paramStringBuilder = new StringBuilder();
/*     */     }
/*     */     
/*  57 */     paramStringBuilder.append("-----------------------------------------------------------------------------------------------------").append(Platform.getNewline());
/*     */ 
/*     */     
/*  60 */     paramStringBuilder.append("Platform: ").append(Platform.getOSType()).append(" / ").append(Platform.getOSName()).append(' ').append(Platform.getOSVersion()).append(" (").append(Platform.getOSVersionNumber()).append("), ");
/*  61 */     paramStringBuilder.append(Platform.getArchName()).append(" (").append(Platform.getCPUType()).append(", ").append(Platform.getABIType()).append("), ");
/*  62 */     paramStringBuilder.append(Runtime.getRuntime().availableProcessors()).append(" cores, ").append("littleEndian ").append(PlatformPropsImpl.LITTLE_ENDIAN);
/*  63 */     paramStringBuilder.append(Platform.getNewline());
/*  64 */     if (Platform.OSType.ANDROID == PlatformPropsImpl.OS_TYPE) {
/*  65 */       paramStringBuilder.append("Platform: Android Version: ").append(AndroidVersion.CODENAME).append(", ");
/*  66 */       paramStringBuilder.append(AndroidVersion.RELEASE).append(" [").append(AndroidVersion.RELEASE).append("], SDK: ").append(AndroidVersion.SDK_INT).append(", ").append(AndroidVersion.SDK_NAME);
/*  67 */       paramStringBuilder.append(Platform.getNewline());
/*     */     } 
/*     */     
/*  70 */     Platform.getMachineDataInfo().toString(paramStringBuilder).append(Platform.getNewline());
/*     */ 
/*     */     
/*  73 */     paramStringBuilder.append("Platform: Java Version: ").append(Platform.getJavaVersion()).append(" (").append(Platform.getJavaVersionNumber()).append("u").append(PlatformPropsImpl.JAVA_VERSION_UPDATE).append("), VM: ").append(Platform.getJavaVMName());
/*  74 */     paramStringBuilder.append(", Runtime: ").append(Platform.getJavaRuntimeName()).append(Platform.getNewline());
/*  75 */     paramStringBuilder.append("Platform: Java Vendor: ").append(Platform.getJavaVendor()).append(", ").append(Platform.getJavaVendorURL());
/*  76 */     if (PlatformPropsImpl.JAVA_21) {
/*  77 */       paramStringBuilder.append(", Java21");
/*  78 */     } else if (PlatformPropsImpl.JAVA_17) {
/*  79 */       paramStringBuilder.append(", Java17");
/*  80 */     } else if (PlatformPropsImpl.JAVA_9) {
/*  81 */       paramStringBuilder.append(", Java9");
/*  82 */     } else if (PlatformPropsImpl.JAVA_6) {
/*  83 */       paramStringBuilder.append(", Java6");
/*  84 */     } else if (PlatformPropsImpl.JAVA_SE) {
/*  85 */       paramStringBuilder.append(", JavaSE");
/*     */     } 
/*  87 */     paramStringBuilder.append(", dynamicLib: ").append(PlatformPropsImpl.useDynamicLibraries);
/*  88 */     paramStringBuilder.append(", AWT enabled: ").append(Platform.AWT_AVAILABLE);
/*  89 */     paramStringBuilder.append(Platform.getNewline()).append("-----------------------------------------------------------------------------------------------------");
/*     */     
/*  91 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPlatformInfo() {
/*  99 */     return getPlatformInfo(null).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Manifest getManifest(ClassLoader paramClassLoader, String paramString) {
/* 110 */     return getManifest(paramClassLoader, new String[] { paramString });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Manifest getManifest(ClassLoader paramClassLoader, String[] paramArrayOfString) {
/* 122 */     Manifest[] arrayOfManifest = new Manifest[paramArrayOfString.length];
/*     */     try {
/* 124 */       Enumeration<URL> enumeration = paramClassLoader.getResources("META-INF/MANIFEST.MF");
/* 125 */       while (enumeration.hasMoreElements()) {
/* 126 */         Manifest manifest; InputStream inputStream = ((URL)enumeration.nextElement()).openStream();
/*     */         
/*     */         try {
/* 129 */           manifest = new Manifest(inputStream);
/*     */         } finally {
/* 131 */           IOUtil.close(inputStream, false);
/*     */         } 
/* 133 */         Attributes attributes = manifest.getMainAttributes();
/* 134 */         if (attributes != null) {
/* 135 */           for (byte b1 = 0; b1 < paramArrayOfString.length && null == arrayOfManifest[b1]; b1++) {
/* 136 */             String str = paramArrayOfString[b1];
/* 137 */             if (str.equals(attributes.getValue(Attributes.Name.EXTENSION_NAME))) {
/* 138 */               if (0 == b1) {
/* 139 */                 return manifest;
/*     */               }
/* 141 */               arrayOfManifest[b1] = manifest;
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/* 146 */     } catch (IOException iOException) {
/* 147 */       throw new RuntimeException("Unable to read manifest.", iOException);
/*     */     } 
/* 149 */     for (byte b = 1; b < arrayOfManifest.length; b++) {
/* 150 */       if (null != arrayOfManifest[b]) {
/* 151 */         return arrayOfManifest[b];
/*     */       }
/*     */     } 
/* 154 */     return null;
/*     */   }
/*     */   
/*     */   public static StringBuilder getFullManifestInfo(Manifest paramManifest, StringBuilder paramStringBuilder) {
/* 158 */     if (null == paramManifest) {
/* 159 */       return paramStringBuilder;
/*     */     }
/*     */     
/* 162 */     if (null == paramStringBuilder) {
/* 163 */       paramStringBuilder = new StringBuilder();
/*     */     }
/*     */     
/* 166 */     Attributes attributes = paramManifest.getMainAttributes();
/* 167 */     Set<Object> set = attributes.keySet();
/* 168 */     for (Attributes.Name name : set) {
/*     */       
/* 170 */       String str = attributes.getValue(name);
/* 171 */       paramStringBuilder.append(" ");
/* 172 */       paramStringBuilder.append(name);
/* 173 */       paramStringBuilder.append(" = ");
/* 174 */       paramStringBuilder.append(str);
/* 175 */       paramStringBuilder.append(Platform.getNewline());
/*     */     } 
/* 177 */     return paramStringBuilder;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/VersionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */