/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.AllPermission;
/*     */ import java.security.CodeSource;
/*     */ import java.security.Permission;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.security.cert.Certificate;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityUtil
/*     */ {
/*     */   private static final SecurityManager securityManager;
/*     */   
/*     */   public static final SecurityManager getSecurityManager() {
/*  57 */     if (PlatformPropsImpl.JAVA_17) {
/*  58 */       return null;
/*     */     }
/*  60 */     return System.getSecurityManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T doPrivileged(PrivilegedAction<T> paramPrivilegedAction) {
/*  79 */     if (PlatformPropsImpl.JAVA_17) {
/*  80 */       return paramPrivilegedAction.run();
/*     */     }
/*  82 */     return AccessController.doPrivileged(paramPrivilegedAction);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  87 */   private static final Permission allPermissions = new AllPermission(); private static final boolean DEBUG = false; private static final RuntimePermission allLinkPermission;
/*  88 */   static { securityManager = getSecurityManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     allLinkPermission = new RuntimePermission("loadLibrary.*"); }
/*     */   public static final boolean hasAllPermissions() { return hasPermission(allPermissions); }
/*     */   public static final boolean hasPermission(Permission paramPermission) { try {
/*     */       checkPermission(paramPermission);
/*     */       return true;
/*     */     } catch (SecurityException securityException) {
/*     */       return false;
/*     */     }  }
/* 206 */   public static final void checkAllPermissions() throws SecurityException { checkPermission(allPermissions); } public static final Certificate[] getCerts(Class<?> paramClass) throws SecurityException { ProtectionDomain protectionDomain = paramClass.getProtectionDomain();
/* 207 */     CodeSource codeSource = (null != protectionDomain) ? protectionDomain.getCodeSource() : null;
/* 208 */     Certificate[] arrayOfCertificate = (null != codeSource) ? codeSource.getCertificates() : null;
/* 209 */     return (null != arrayOfCertificate && arrayOfCertificate.length > 0) ? arrayOfCertificate : null; }
/*     */   public static final void checkPermission(Permission paramPermission) throws SecurityException { if (null != securityManager) securityManager.checkPermission(paramPermission);  }
/*     */   public static final boolean hasLinkPermission(String paramString) { try { checkLinkPermission(paramString); return true; } catch (SecurityException securityException) { return false; }  }
/*     */   public static final void checkLinkPermission(String paramString) throws SecurityException { if (null != securityManager) securityManager.checkLink(paramString);  }
/* 213 */   public static final void checkAllLinkPermission() throws SecurityException { if (null != securityManager) securityManager.checkPermission(allLinkPermission);  } public static final boolean equals(Certificate[] paramArrayOfCertificate1, Certificate[] paramArrayOfCertificate2) { if (paramArrayOfCertificate1 == paramArrayOfCertificate2) {
/* 214 */       return true;
/*     */     }
/* 216 */     if (paramArrayOfCertificate1 == null || paramArrayOfCertificate2 == null) {
/* 217 */       return false;
/*     */     }
/* 219 */     if (paramArrayOfCertificate1.length != paramArrayOfCertificate2.length) {
/* 220 */       return false;
/*     */     }
/*     */     
/* 223 */     byte b = 0;
/* 224 */     while (b < paramArrayOfCertificate1.length && paramArrayOfCertificate1[b].equals(paramArrayOfCertificate2[b])) {
/* 225 */       b++;
/*     */     }
/* 227 */     return (b == paramArrayOfCertificate1.length); }
/*     */ 
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/SecurityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */