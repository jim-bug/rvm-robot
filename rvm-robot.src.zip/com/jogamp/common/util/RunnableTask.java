/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.JogampRuntimeException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunnableTask
/*     */   extends TaskBase
/*     */ {
/*     */   protected final Runnable runnable;
/*     */   
/*     */   public static RunnableTask invokeOnCurrentThread(Runnable paramRunnable) {
/*  50 */     RunnableTask runnableTask = new RunnableTask(paramRunnable, null, false, null);
/*  51 */     runnableTask.run();
/*  52 */     return runnableTask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RunnableTask invokeOnNewThread(ThreadGroup paramThreadGroup, String paramString, boolean paramBoolean, Runnable paramRunnable) {
/*     */     RunnableTask runnableTask;
/*  69 */     if (!paramBoolean) {
/*  70 */       runnableTask = new RunnableTask(paramRunnable, null, true, System.err);
/*  71 */       InterruptSource.Thread thread = InterruptSource.Thread.create(paramThreadGroup, runnableTask, paramString);
/*  72 */       thread.start();
/*     */     } else {
/*  74 */       Object object = new Object();
/*  75 */       runnableTask = new RunnableTask(paramRunnable, object, true, null);
/*  76 */       InterruptSource.Thread thread = InterruptSource.Thread.create(paramThreadGroup, runnableTask, paramString);
/*  77 */       synchronized (object) {
/*  78 */         thread.start();
/*  79 */         while (runnableTask.isInQueue()) {
/*     */           try {
/*  81 */             object.wait();
/*  82 */           } catch (InterruptedException interruptedException) {
/*  83 */             throw new InterruptedRuntimeException(interruptedException);
/*     */           } 
/*  85 */           Throwable throwable = runnableTask.getThrowable();
/*  86 */           if (null != throwable) {
/*  87 */             throw new JogampRuntimeException(throwable);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*  92 */     return runnableTask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RunnableTask(Runnable paramRunnable, Object paramObject, boolean paramBoolean, PrintStream paramPrintStream) {
/* 108 */     super(paramObject, paramBoolean, paramPrintStream);
/* 109 */     this.runnable = paramRunnable;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Runnable getRunnable() {
/* 114 */     return this.runnable;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void run() {
/* 119 */     this.execThread = Thread.currentThread();
/*     */     
/* 121 */     this.runnableException = null;
/* 122 */     this.tStarted = System.currentTimeMillis();
/* 123 */     if (null == this.syncObject) {
/*     */       try {
/* 125 */         this.runnable.run();
/* 126 */       } catch (Throwable throwable) {
/* 127 */         this.runnableException = throwable;
/* 128 */         if (null != this.exceptionOut) {
/* 129 */           this.exceptionOut.println("RunnableTask.run(): " + getExceptionOutIntro() + " exception occured on thread " + Thread.currentThread().getName() + ": " + toString());
/* 130 */           printSourceTrace();
/* 131 */           this.runnableException.printStackTrace(this.exceptionOut);
/*     */         } 
/* 133 */         if (!this.catchExceptions) {
/* 134 */           throw new RuntimeException(this.runnableException);
/*     */         }
/*     */       } finally {
/* 137 */         this.tExecuted = System.currentTimeMillis();
/* 138 */         this.isExecuted = true;
/*     */       } 
/*     */     } else {
/* 141 */       synchronized (this.syncObject) {
/*     */         try {
/* 143 */           this.runnable.run();
/* 144 */         } catch (Throwable throwable) {
/* 145 */           this.runnableException = throwable;
/* 146 */           if (null != this.exceptionOut) {
/* 147 */             this.exceptionOut.println("RunnableTask.run(): " + getExceptionOutIntro() + " exception occured on thread " + Thread.currentThread().getName() + ": " + toString());
/* 148 */             printSourceTrace();
/* 149 */             throwable.printStackTrace(this.exceptionOut);
/*     */           } 
/* 151 */           if (!this.catchExceptions) {
/* 152 */             throw new RuntimeException(this.runnableException);
/*     */           }
/*     */         } finally {
/* 155 */           this.tExecuted = System.currentTimeMillis();
/* 156 */           this.isExecuted = true;
/* 157 */           this.syncObject.notifyAll();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/RunnableTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */