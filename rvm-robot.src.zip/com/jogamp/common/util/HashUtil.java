/*    */ package com.jogamp.common.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HashUtil
/*    */ {
/*    */   public static int getAddrHash32_EqualDist(long paramLong) {
/* 38 */     int i = 31 + (int)paramLong;
/* 39 */     return (i << 5) - i + (int)(paramLong >>> 32L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getAddrSizeHash32_EqualDist(long paramLong1, long paramLong2) {
/* 49 */     int i = 31 + (int)paramLong1;
/* 50 */     i = (i << 5) - i + (int)(paramLong1 >>> 32L);
/* 51 */     i = (i << 5) - i + (int)paramLong2;
/* 52 */     return (i << 5) - i + (int)(paramLong2 >>> 32L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static long getHash64(long paramLong1, long paramLong2) {
/* 61 */     long l = 31L + paramLong1;
/* 62 */     return (l << 5L) - l + paramLong2;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/HashUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */