/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionNumber
/*     */   implements Comparable<Object>
/*     */ {
/*  55 */   public static final VersionNumber zeroVersion = new VersionNumber(0, 0, 0, -1, (short)0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pattern getVersionNumberPattern(String paramString) {
/*  76 */     return Pattern.compile("\\D*(\\d+)[^\\" + paramString + "\\s]*(?:\\" + paramString + "\\D*(\\d+)[^\\" + paramString + "\\s]*(?:\\" + paramString + "\\D*(\\d+))?)?");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pattern getDefaultVersionNumberPattern() {
/*  87 */     if (null == defPattern) {
/*  88 */       synchronized (VersionNumber.class) {
/*  89 */         if (null == defPattern) {
/*  90 */           defPattern = getVersionNumberPattern(".");
/*     */         }
/*     */       } 
/*     */     }
/*  94 */     return defPattern;
/*     */   }
/*  96 */   private static volatile Pattern defPattern = null; protected final int major;
/*     */   protected final int minor;
/*     */   protected final int sub;
/*     */   protected final int strEnd;
/*     */   protected final short state;
/*     */   protected static final short HAS_MAJOR = 1;
/*     */   protected static final short HAS_MINOR = 2;
/*     */   protected static final short HAS_SUB = 4;
/*     */   
/*     */   protected VersionNumber(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort) {
/* 106 */     this.major = paramInt1;
/* 107 */     this.minor = paramInt2;
/* 108 */     this.sub = paramInt3;
/* 109 */     this.strEnd = paramInt4;
/* 110 */     this.state = paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionNumber(int paramInt1, int paramInt2, int paramInt3) {
/* 120 */     this(paramInt1, paramInt2, paramInt3, -1, (short)7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionNumber(String paramString) {
/* 139 */     this(paramString, getDefaultVersionNumberPattern());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionNumber(String paramString1, String paramString2) {
/* 159 */     this(paramString1, getVersionNumberPattern(paramString2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionNumber(String paramString, Pattern paramPattern) {
/* 179 */     int[] arrayOfInt = new int[3];
/* 180 */     int i = 0;
/* 181 */     short s = 0;
/*     */     try {
/* 183 */       Matcher matcher = paramPattern.matcher(paramString);
/* 184 */       if (matcher.lookingAt()) {
/* 185 */         i = matcher.end();
/* 186 */         int j = matcher.groupCount();
/* 187 */         if (1 <= j) {
/* 188 */           arrayOfInt[0] = Integer.parseInt(matcher.group(1));
/* 189 */           s = 1;
/* 190 */           if (2 <= j) {
/* 191 */             arrayOfInt[1] = Integer.parseInt(matcher.group(2));
/* 192 */             s = (short)(s | 0x2);
/* 193 */             if (3 <= j) {
/* 194 */               arrayOfInt[2] = Integer.parseInt(matcher.group(3));
/* 195 */               s = (short)(s | 0x4);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 200 */     } catch (Exception exception) {}
/*     */     
/* 202 */     this.major = arrayOfInt[0];
/* 203 */     this.minor = arrayOfInt[1];
/* 204 */     this.sub = arrayOfInt[2];
/* 205 */     this.strEnd = i;
/* 206 */     this.state = s;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isZero() {
/* 211 */     return (this.major == 0 && this.minor == 0 && this.sub == 0);
/*     */   }
/*     */   
/*     */   public final boolean hasMajor() {
/* 215 */     return (0 != (0x1 & this.state));
/*     */   } public final boolean hasMinor() {
/* 217 */     return (0 != (0x2 & this.state));
/*     */   } public final boolean hasSub() {
/* 219 */     return (0 != (0x4 & this.state));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int endOfStringMatch() {
/* 225 */     return this.strEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 230 */     int i = 31 + this.major;
/* 231 */     i = (i << 5) - i + this.minor;
/* 232 */     return (i << 5) - i + this.sub;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 237 */     if (paramObject instanceof VersionNumber) {
/* 238 */       return (0 == compareTo((VersionNumber)paramObject));
/*     */     }
/* 240 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int compareTo(Object paramObject) {
/* 245 */     if (!(paramObject instanceof VersionNumber)) {
/* 246 */       Class<?> clazz = (null != paramObject) ? paramObject.getClass() : null;
/* 247 */       throw new ClassCastException("Not a VersionNumber object: " + clazz);
/*     */     } 
/* 249 */     return compareTo((VersionNumber)paramObject);
/*     */   }
/*     */   
/*     */   public final int compareTo(VersionNumber paramVersionNumber) {
/* 253 */     if (this.major > paramVersionNumber.major)
/* 254 */       return 1; 
/* 255 */     if (this.major < paramVersionNumber.major)
/* 256 */       return -1; 
/* 257 */     if (this.minor > paramVersionNumber.minor)
/* 258 */       return 1; 
/* 259 */     if (this.minor < paramVersionNumber.minor)
/* 260 */       return -1; 
/* 261 */     if (this.sub > paramVersionNumber.sub)
/* 262 */       return 1; 
/* 263 */     if (this.sub < paramVersionNumber.sub) {
/* 264 */       return -1;
/*     */     }
/* 266 */     return 0;
/*     */   }
/*     */   
/*     */   public final int getMajor() {
/* 270 */     return this.major;
/*     */   }
/*     */   
/*     */   public final int getMinor() {
/* 274 */     return this.minor;
/*     */   }
/*     */   
/*     */   public final int getSub() {
/* 278 */     return this.sub;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 283 */     return this.major + "." + this.minor + "." + this.sub;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/VersionNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */