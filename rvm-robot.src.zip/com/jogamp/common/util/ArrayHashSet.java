/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayHashSet<E>
/*     */   implements Cloneable, Collection<E>, List<E>
/*     */ {
/*     */   public static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   public static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   private final HashMap<E, E> map;
/*     */   private final ArrayList<E> data;
/*     */   private final boolean supportNullValue;
/*     */   
/*     */   public ArrayHashSet(boolean paramBoolean, int paramInt, float paramFloat) {
/*  94 */     this.map = new HashMap<>(paramInt, paramFloat);
/*  95 */     this.data = new ArrayList<>(paramInt);
/*  96 */     this.supportNullValue = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayHashSet(ArrayHashSet<E> paramArrayHashSet) {
/* 103 */     this.map = new HashMap<>(paramArrayHashSet.map);
/* 104 */     this.data = new ArrayList<>(paramArrayHashSet.data);
/* 105 */     this.supportNullValue = paramArrayHashSet.supportNullValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean supportsNullValue() {
/* 116 */     return this.supportNullValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object clone() {
/* 127 */     return new ArrayHashSet(this);
/*     */   }
/*     */   
/*     */   public final ArrayList<E> getData() {
/* 131 */     return this.data;
/*     */   } public final HashMap<E, E> getMap() {
/* 133 */     return this.map;
/*     */   }
/*     */   public final String toString() {
/* 136 */     return this.data.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void clear() {
/* 144 */     this.data.clear();
/* 145 */     this.map.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean add(E paramE) throws NullPointerException {
/* 162 */     if (!this.supportNullValue) {
/* 163 */       checkNull(paramE);
/*     */     }
/* 165 */     if (!this.map.containsKey(paramE)) {
/*     */       
/* 167 */       if (null != this.map.put(paramE, paramE))
/*     */       {
/* 169 */         throw new InternalError("Already existing, but checked before: " + paramE);
/*     */       }
/* 171 */       if (!this.data.add(paramE)) {
/* 172 */         throw new InternalError("Couldn't add element: " + paramE);
/*     */       }
/* 174 */       return true;
/*     */     } 
/* 176 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean remove(Object paramObject) throws NullPointerException {
/* 194 */     if (this.supportNullValue) {
/* 195 */       if (this.map.containsKey(paramObject)) {
/*     */         
/* 197 */         this.map.remove(paramObject);
/* 198 */         if (!this.data.remove(paramObject)) {
/* 199 */           throw new InternalError("Couldn't remove prev mapped element: " + paramObject);
/*     */         }
/* 201 */         return true;
/*     */       } 
/*     */     } else {
/* 204 */       checkNull(paramObject);
/* 205 */       if (null != this.map.remove(paramObject)) {
/*     */         
/* 207 */         if (!this.data.remove(paramObject)) {
/* 208 */           throw new InternalError("Couldn't remove prev mapped element: " + paramObject);
/*     */         }
/* 210 */         return true;
/*     */       } 
/*     */     } 
/* 213 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean addAll(Collection<? extends E> paramCollection) {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_2
/*     */     //   2: aload_1
/*     */     //   3: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   8: astore_3
/*     */     //   9: aload_3
/*     */     //   10: invokeinterface hasNext : ()Z
/*     */     //   15: ifeq -> 38
/*     */     //   18: aload_3
/*     */     //   19: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   24: astore #4
/*     */     //   26: iload_2
/*     */     //   27: aload_0
/*     */     //   28: aload #4
/*     */     //   30: invokevirtual add : (Ljava/lang/Object;)Z
/*     */     //   33: ior
/*     */     //   34: istore_2
/*     */     //   35: goto -> 9
/*     */     //   38: iload_2
/*     */     //   39: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #229	-> 0
/*     */     //   #230	-> 2
/*     */     //   #231	-> 26
/*     */     //   #232	-> 35
/*     */     //   #233	-> 38
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean contains(Object paramObject) {
/* 249 */     return this.map.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean containsAll(Collection<?> paramCollection) {
/* 265 */     for (Object object : paramCollection) {
/* 266 */       if (!contains(object)) {
/* 267 */         return false;
/*     */       }
/*     */     } 
/* 270 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean removeAll(Collection<?> paramCollection) {
/* 286 */     boolean bool = false;
/* 287 */     for (Object object : paramCollection) {
/* 288 */       bool |= remove(object);
/*     */     }
/* 290 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean retainAll(Collection<?> paramCollection) {
/* 307 */     boolean bool = false;
/* 308 */     for (Object object : paramCollection) {
/* 309 */       if (!paramCollection.contains(object)) {
/* 310 */         bool |= remove(object);
/*     */       }
/*     */     } 
/* 313 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 327 */     if (!(paramObject instanceof ArrayHashSet)) {
/* 328 */       return false;
/*     */     }
/* 330 */     return this.data.equals(((ArrayHashSet)paramObject).data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 344 */     return this.data.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isEmpty() {
/* 349 */     return this.data.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Iterator<E> iterator() {
/* 354 */     return this.data.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int size() {
/* 359 */     return this.data.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object[] toArray() {
/* 364 */     return this.data.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public final <T> T[] toArray(T[] paramArrayOfT) {
/* 369 */     return this.data.toArray(paramArrayOfT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final E get(int paramInt) {
/* 378 */     return this.data.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int indexOf(Object paramObject) {
/* 383 */     return this.data.indexOf(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(int paramInt, E paramE) throws IllegalArgumentException, NullPointerException {
/* 399 */     if (!this.supportNullValue) {
/* 400 */       checkNull(paramE);
/*     */     }
/* 402 */     if (this.map.containsKey(paramE)) {
/* 403 */       throw new IllegalArgumentException("Element " + paramE + " is already contained");
/*     */     }
/* 405 */     if (null != this.map.put(paramE, paramE))
/*     */     {
/* 407 */       throw new InternalError("Already existing, but checked before: " + paramE);
/*     */     }
/*     */     
/* 410 */     this.data.add(paramInt, paramE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean addAll(int paramInt, Collection<? extends E> paramCollection) throws UnsupportedOperationException {
/* 421 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final E set(int paramInt, E paramE) {
/* 431 */     E e = remove(paramInt);
/* 432 */     if (null != e) {
/* 433 */       add(paramInt, paramE);
/*     */     }
/* 435 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final E remove(int paramInt) {
/* 450 */     E e = get(paramInt);
/* 451 */     if (null != e && remove(e)) {
/* 452 */       return e;
/*     */     }
/* 454 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int lastIndexOf(Object paramObject) {
/* 469 */     return indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ListIterator<E> listIterator() {
/* 474 */     return this.data.listIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ListIterator<E> listIterator(int paramInt) {
/* 479 */     return this.data.listIterator(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final List<E> subList(int paramInt1, int paramInt2) {
/* 484 */     return this.data.subList(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ArrayList<E> toArrayList() {
/* 495 */     return new ArrayList<>(this.data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final E get(Object paramObject) {
/* 508 */     return this.map.get(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final E getOrAdd(E paramE) throws NullPointerException {
/* 523 */     if (this.supportNullValue) {
/* 524 */       if (this.map.containsKey(paramE))
/*     */       {
/* 526 */         return this.map.get(paramE);
/*     */       }
/*     */     } else {
/* 529 */       checkNull(paramE);
/* 530 */       E e = this.map.get(paramE);
/* 531 */       if (null != e)
/*     */       {
/* 533 */         return e;
/*     */       }
/*     */     } 
/*     */     
/* 537 */     if (!add(paramE)) {
/* 538 */       throw new InternalError("Element not mapped, but contained in list: " + paramE);
/*     */     }
/* 540 */     return paramE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean containsSafe(Object paramObject) {
/* 556 */     return this.data.contains(paramObject);
/*     */   }
/*     */   
/*     */   private static final void checkNull(Object paramObject) throws NullPointerException {
/* 560 */     if (null == paramObject)
/* 561 */       throw new NullPointerException("Null element not supported"); 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/ArrayHashSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */