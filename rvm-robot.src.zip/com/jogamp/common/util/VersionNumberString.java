/*    */ package com.jogamp.common.util;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VersionNumberString
/*    */   extends VersionNumber
/*    */ {
/* 43 */   public static final VersionNumberString zeroVersion = new VersionNumberString(0, 0, 0, -1, (short)0, "n/a");
/*    */   
/*    */   protected final String strVal;
/*    */   
/*    */   protected VersionNumberString(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString) {
/* 48 */     super(paramInt1, paramInt2, paramInt3, paramInt4, paramShort);
/* 49 */     this.strVal = paramString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VersionNumberString(int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 56 */     this(paramInt1, paramInt2, paramInt3, -1, (short)7, paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VersionNumberString(String paramString) {
/* 63 */     super(paramString);
/* 64 */     this.strVal = paramString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VersionNumberString(String paramString1, String paramString2) {
/* 71 */     super(paramString1, paramString2);
/* 72 */     this.strVal = paramString1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VersionNumberString(String paramString, Pattern paramPattern) {
/* 79 */     super(paramString, paramPattern);
/* 80 */     this.strVal = paramString;
/*    */   }
/*    */   
/*    */   public final String getVersionString() {
/* 84 */     return this.strVal;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 88 */     return super.toString() + " (" + this.strVal + ")";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/VersionNumberString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */