/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TaskBase
/*     */   implements Runnable
/*     */ {
/*     */   static {
/*  44 */     Debug.initSingleton();
/*  45 */   } private static final boolean TRACE_SOURCE = PropertyAccess.isPropertyDefined("jogamp.debug.TaskBase.TraceSource", true);
/*     */   
/*     */   protected final Object syncObject;
/*     */   
/*     */   protected final boolean catchExceptions;
/*     */   
/*     */   protected final PrintStream exceptionOut;
/*     */   
/*     */   protected final Throwable sourceStack;
/*     */   
/*     */   protected Object attachment;
/*     */   
/*     */   protected Throwable runnableException;
/*     */   
/*     */   protected long tCreated;
/*     */   
/*     */   protected long tStarted;
/*     */   
/*     */   protected volatile long tExecuted;
/*     */   
/*     */   protected volatile boolean isExecuted;
/*     */   protected volatile boolean isFlushed;
/*     */   protected volatile Thread execThread;
/*     */   
/*     */   protected TaskBase(Object paramObject, boolean paramBoolean, PrintStream paramPrintStream) {
/*  70 */     this.syncObject = paramObject;
/*  71 */     this.catchExceptions = paramBoolean;
/*  72 */     this.exceptionOut = paramPrintStream;
/*  73 */     this.sourceStack = TRACE_SOURCE ? new Throwable("Creation @") : null;
/*  74 */     this.tCreated = System.currentTimeMillis();
/*  75 */     this.tStarted = 0L;
/*  76 */     this.tExecuted = 0L;
/*  77 */     this.isExecuted = false;
/*  78 */     this.isFlushed = false;
/*  79 */     this.execThread = null;
/*     */   }
/*     */   
/*     */   protected final String getExceptionOutIntro() {
/*  83 */     return this.catchExceptions ? "A caught" : "An uncaught";
/*     */   }
/*     */   protected final void printSourceTrace() {
/*  86 */     if (null != this.sourceStack && null != this.exceptionOut) {
/*  87 */       this.sourceStack.printStackTrace(this.exceptionOut);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Thread getExecutionThread() {
/*  96 */     return this.execThread;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getSyncObject() {
/* 104 */     return this.syncObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setAttachment(Object paramObject) {
/* 112 */     this.attachment = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getAttachment() {
/* 120 */     return this.attachment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void flush(Throwable paramThrowable) {
/* 137 */     if (!isExecuted() && hasWaiter()) {
/* 138 */       this.runnableException = paramThrowable;
/* 139 */       synchronized (this.syncObject) {
/* 140 */         this.isFlushed = true;
/* 141 */         this.syncObject.notifyAll();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isInQueue() {
/* 149 */     return (!this.isExecuted && !this.isFlushed);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isExecuted() {
/* 154 */     return this.isExecuted;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isFlushed() {
/* 159 */     return this.isFlushed;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasWaiter() {
/* 165 */     return (null != this.syncObject);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Throwable getThrowable() {
/* 171 */     return this.runnableException;
/*     */   }
/* 173 */   public final long getTimestampCreate() { return this.tCreated; }
/* 174 */   public final long getTimestampBeforeExec() { return this.tStarted; }
/* 175 */   public final long getTimestampAfterExec() { return this.tExecuted; }
/* 176 */   public final long getDurationInQueue() { return this.tStarted - this.tCreated; }
/* 177 */   public final long getDurationInExec() { return (0L < this.tExecuted) ? (this.tExecuted - this.tStarted) : 0L; } public final long getDurationTotal() {
/* 178 */     return (0L < this.tExecuted) ? (this.tExecuted - this.tCreated) : (this.tStarted - this.tCreated);
/*     */   }
/*     */   
/*     */   public String toString() {
/*     */     String str1;
/*     */     String str2;
/* 184 */     if (null != this.execThread) {
/* 185 */       str1 = this.execThread.getName();
/* 186 */       str2 = "0x" + Integer.toHexString(this.execThread.hashCode());
/*     */     } else {
/* 188 */       str1 = "n/a";
/* 189 */       str2 = "n/a";
/*     */     } 
/* 191 */     return "RunnableTask[enqueued " + isInQueue() + "[executed " + isExecuted() + ", flushed " + isFlushed() + ", thread[" + str2 + ", " + str1 + "]], tTotal " + getDurationTotal() + " ms, tExec " + getDurationInExec() + " ms, tQueue " + getDurationInQueue() + " ms, attachment " + this.attachment + ", throwable " + getThrowable() + "]";
/*     */   }
/*     */   
/*     */   public abstract void run();
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/TaskBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */