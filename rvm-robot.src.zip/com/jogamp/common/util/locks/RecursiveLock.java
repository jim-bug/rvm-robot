package com.jogamp.common.util.locks;

public interface RecursiveLock extends ThreadLock {
  int getHoldCount();
  
  int getQueueLength();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/locks/RecursiveLock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */