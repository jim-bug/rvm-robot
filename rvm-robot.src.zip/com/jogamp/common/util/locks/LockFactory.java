/*    */ package com.jogamp.common.util.locks;
/*    */ 
/*    */ import jogamp.common.util.locks.RecursiveLockImpl01CompleteFair;
/*    */ import jogamp.common.util.locks.RecursiveLockImpl01Unfairish;
/*    */ import jogamp.common.util.locks.RecursiveLockImplJava5;
/*    */ import jogamp.common.util.locks.RecursiveThreadGroupLockImpl01Unfairish;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LockFactory
/*    */ {
/*    */   public enum ImplType
/*    */   {
/* 38 */     Int01(0), Java5(1), Int02ThreadGroup(2);
/*    */     
/*    */     public final int id;
/*    */     
/*    */     ImplType(int param1Int1) {
/* 43 */       this.id = param1Int1;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static RecursiveLock createRecursiveLock() {
/* 49 */     return (RecursiveLock)new RecursiveLockImpl01Unfairish();
/*    */   }
/*    */ 
/*    */   
/*    */   public static RecursiveThreadGroupLock createRecursiveThreadGroupLock() {
/* 54 */     return (RecursiveThreadGroupLock)new RecursiveThreadGroupLockImpl01Unfairish();
/*    */   }
/*    */   
/*    */   public static RecursiveLock createRecursiveLock(ImplType paramImplType, boolean paramBoolean) {
/* 58 */     switch (paramImplType) {
/*    */       case Int01:
/* 60 */         return paramBoolean ? (RecursiveLock)new RecursiveLockImpl01CompleteFair() : (RecursiveLock)new RecursiveLockImpl01Unfairish();
/*    */       case Java5:
/* 62 */         return (RecursiveLock)new RecursiveLockImplJava5(paramBoolean);
/*    */       case Int02ThreadGroup:
/* 64 */         return (RecursiveLock)new RecursiveThreadGroupLockImpl01Unfairish();
/*    */     } 
/* 66 */     throw new InternalError("XXX");
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/locks/LockFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */