package com.jogamp.common.util.locks;

public interface ThreadLock extends Lock {
  boolean isLockedByOtherThread();
  
  boolean isOwner(Thread paramThread);
  
  Thread getOwner();
  
  void validateLocked() throws RuntimeException;
  
  void unlock(Runnable paramRunnable);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/locks/ThreadLock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */