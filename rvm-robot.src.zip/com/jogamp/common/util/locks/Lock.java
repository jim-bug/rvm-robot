/*    */ package com.jogamp.common.util.locks;
/*    */ 
/*    */ import jogamp.common.Debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Lock
/*    */ {
/* 39 */   public static final boolean DEBUG = Debug.debug("Lock");
/*    */ 
/*    */   
/* 42 */   public static final boolean TRACE_LOCK = Debug.isPropertyDefined("jogamp.debug.Lock.TraceLock", true);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final long DEFAULT_TIMEOUT = 5000L;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public static final long TIMEOUT = Debug.getLongProperty("jogamp.common.utils.locks.Lock.timeout", true, 5000L);
/*    */   
/*    */   void lock() throws RuntimeException;
/*    */   
/*    */   boolean tryLock(long paramLong) throws InterruptedException;
/*    */   
/*    */   void unlock() throws RuntimeException;
/*    */   
/*    */   boolean isLocked();
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/locks/Lock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */