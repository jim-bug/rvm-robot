package com.jogamp.common.util.locks;

public interface RecursiveThreadGroupLock extends RecursiveLock {
  boolean isOriginalOwner();
  
  boolean isOriginalOwner(Thread paramThread);
  
  void addOwner(Thread paramThread) throws RuntimeException, IllegalArgumentException;
  
  void removeOwner(Thread paramThread) throws RuntimeException, IllegalArgumentException;
  
  void unlock() throws RuntimeException;
  
  void unlock(Runnable paramRunnable);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/locks/RecursiveThreadGroupLock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */