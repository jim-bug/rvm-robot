/*     */ package com.jogamp.common.util.locks;
/*     */ 
/*     */ import java.io.File;
/*     */ import jogamp.common.util.locks.SingletonInstanceFileLock;
/*     */ import jogamp.common.util.locks.SingletonInstanceServerSocket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SingletonInstance
/*     */   implements Lock
/*     */ {
/*     */   protected static final boolean DEBUG = true;
/*     */   private final long poll_ms;
/*     */   private boolean locked;
/*     */   
/*     */   public static SingletonInstance createFileLock(long paramLong, String paramString) {
/*  41 */     return (SingletonInstance)new SingletonInstanceFileLock(paramLong, paramString);
/*     */   }
/*     */   
/*     */   public static SingletonInstance createFileLock(long paramLong, File paramFile) {
/*  45 */     return (SingletonInstance)new SingletonInstanceFileLock(paramLong, paramFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SingletonInstance createServerSocket(long paramLong, int paramInt) {
/*  62 */     return (SingletonInstance)new SingletonInstanceServerSocket(paramLong, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SingletonInstance(long paramLong) {
/* 150 */     this.locked = false;
/*     */     this.poll_ms = Math.max(10L, paramLong);
/*     */   }
/*     */   
/*     */   public final long getPollPeriod() {
/*     */     return this.poll_ms;
/*     */   }
/*     */   
/*     */   public abstract String getName();
/*     */   
/*     */   public final String toString() {
/*     */     return getName();
/*     */   }
/*     */   
/*     */   public synchronized void lock() throws RuntimeException {
/*     */     try {
/*     */       do {
/*     */       
/*     */       } while (!tryLock(TIMEOUT));
/*     */       return;
/*     */     } catch (RuntimeException runtimeException) {
/*     */       throw new RuntimeException(runtimeException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized boolean tryLock(long paramLong) throws RuntimeException {
/*     */     if (this.locked)
/*     */       return true; 
/*     */     long l1 = System.currentTimeMillis();
/*     */     byte b = 0;
/*     */     try {
/*     */       do {
/*     */         long l = System.currentTimeMillis();
/*     */         this.locked = tryLockImpl();
/*     */         if (this.locked) {
/*     */           long l3 = System.currentTimeMillis();
/*     */           System.err.println(infoPrefix(l3) + " +++ " + getName() + " - Locked within " + (l3 - l1) + " ms, " + (b + 1) + " attempts");
/*     */           return true;
/*     */         } 
/*     */         if (0 == b)
/*     */           System.err.println(infoPrefix(System.currentTimeMillis()) + " III " + getName() + " - Wait for lock"); 
/*     */         Thread.sleep(this.poll_ms);
/*     */         paramLong -= System.currentTimeMillis() - l;
/*     */         b++;
/*     */       } while (0L < paramLong);
/*     */     } catch (InterruptedException interruptedException) {
/*     */       long l = System.currentTimeMillis();
/*     */       throw new RuntimeException(infoPrefix(l) + " EEE (1) " + getName() + " - couldn't get lock within " + (l - l1) + " ms, " + b + " attempts", interruptedException);
/*     */     } 
/*     */     long l2 = System.currentTimeMillis();
/*     */     System.err.println(infoPrefix(l2) + " +++ EEE (2) " + getName() + " - couldn't get lock within " + (l2 - l1) + " ms, " + b + " attempts");
/*     */     return false;
/*     */   }
/*     */   
/*     */   protected abstract boolean tryLockImpl();
/*     */   
/*     */   public void unlock() throws RuntimeException {
/*     */     long l = System.currentTimeMillis();
/*     */     if (this.locked) {
/*     */       this.locked = !unlockImpl();
/*     */       long l1 = System.currentTimeMillis();
/*     */       System.err.println(infoPrefix(l1) + " --- " + getName() + " - Unlock " + (this.locked ? "failed" : "ok") + " within " + (l1 - l) + " ms");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract boolean unlockImpl();
/*     */   
/*     */   public synchronized boolean isLocked() {
/*     */     return this.locked;
/*     */   }
/*     */   
/*     */   protected String infoPrefix(long paramLong) {
/*     */     return "SLOCK [T " + Thread.currentThread().getName() + " @ " + paramLong + " ms";
/*     */   }
/*     */   
/*     */   protected String infoPrefix() {
/*     */     return infoPrefix(System.currentTimeMillis());
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/locks/SingletonInstance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */