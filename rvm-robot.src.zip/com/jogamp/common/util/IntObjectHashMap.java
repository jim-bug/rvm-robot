/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.JogampRuntimeException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntObjectHashMap
/*     */   implements Cloneable, Iterable<IntObjectHashMap.Entry>
/*     */ {
/*     */   private final float loadFactor;
/*     */   private Entry[] table;
/*     */   private int size;
/*     */   private int mask;
/*     */   private int capacity;
/*     */   private int threshold;
/*  71 */   private Object keyNotFoundValue = null;
/*     */   private static final boolean isPrimitive;
/*     */   private static final Constructor<Entry> entryConstructor;
/*     */   private static final Method equalsMethod;
/*     */   
/*     */   static class EntryCM {
/*  77 */     Constructor<IntObjectHashMap.Entry> c = null; Method m1 = null; }
/*     */   
/*     */   static {
/*  80 */     final Class<Object> valueClazz = Object.class;
/*  81 */     final Class<int> keyClazz = int.class;
/*     */     
/*  83 */     isPrimitive = clazz.isPrimitive();
/*     */     
/*  85 */     if (!isPrimitive) {
/*  86 */       EntryCM entryCM = SecurityUtil.<EntryCM>doPrivileged(new PrivilegedAction<EntryCM>()
/*     */           {
/*     */             public IntObjectHashMap.EntryCM run()
/*     */             {
/*  90 */               IntObjectHashMap.EntryCM entryCM = new IntObjectHashMap.EntryCM();
/*  91 */               entryCM
/*  92 */                 .c = (Constructor)ReflectionUtil.getConstructor(IntObjectHashMap.Entry.class, new Class[] { this.val$keyClazz, this.val$valueClazz, IntObjectHashMap.Entry.class });
/*     */               
/*     */               try {
/*  95 */                 entryCM.m1 = valueClazz.getDeclaredMethod("equals", new Class[] { Object.class });
/*  96 */               } catch (NoSuchMethodException noSuchMethodException) {
/*  97 */                 throw new JogampRuntimeException("Class " + valueClazz + " doesn't support equals(Object)");
/*     */               } 
/*  99 */               return entryCM; }
/*     */           });
/* 101 */       entryConstructor = entryCM.c;
/* 102 */       equalsMethod = entryCM.m1;
/*     */     } else {
/* 104 */       entryConstructor = null;
/* 105 */       equalsMethod = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public IntObjectHashMap() {
/* 110 */     this(16, 0.75F);
/*     */   }
/*     */   
/*     */   public IntObjectHashMap(int paramInt) {
/* 114 */     this(paramInt, 0.75F);
/*     */   }
/*     */   
/*     */   public IntObjectHashMap(int paramInt, float paramFloat) {
/* 118 */     if (paramInt > 1073741824) {
/* 119 */       throw new IllegalArgumentException("initialCapacity is too large.");
/*     */     }
/* 121 */     if (paramInt < 0) {
/* 122 */       throw new IllegalArgumentException("initialCapacity must be greater than zero.");
/*     */     }
/* 124 */     if (paramFloat <= 0.0F) {
/* 125 */       throw new IllegalArgumentException("loadFactor must be greater than zero.");
/*     */     }
/* 127 */     this.capacity = 1;
/* 128 */     while (this.capacity < paramInt) {
/* 129 */       this.capacity <<= 1;
/*     */     }
/* 131 */     this.loadFactor = paramFloat;
/* 132 */     this.threshold = (int)(this.capacity * paramFloat);
/* 133 */     this.table = new Entry[this.capacity];
/* 134 */     this.mask = this.capacity - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private IntObjectHashMap(float paramFloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, Object paramObject) {
/* 140 */     this.loadFactor = paramFloat;
/* 141 */     this.table = new Entry[paramInt1];
/* 142 */     this.size = paramInt2;
/*     */     
/* 144 */     this.mask = paramInt3;
/* 145 */     this.capacity = paramInt4;
/* 146 */     this.threshold = paramInt5;
/*     */     
/* 148 */     this.keyNotFoundValue = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 159 */     IntObjectHashMap intObjectHashMap = new IntObjectHashMap(this.loadFactor, this.table.length, this.size, this.mask, this.capacity, this.threshold, this.keyNotFoundValue);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     ArrayList<Entry> arrayList = new ArrayList();
/* 165 */     for (int i = this.table.length - 1; i >= 0; i--) {
/*     */       
/* 167 */       Entry entry1 = this.table[i];
/* 168 */       while (null != entry1) {
/* 169 */         arrayList.add(entry1);
/* 170 */         entry1 = entry1.next;
/*     */       } 
/*     */       
/* 173 */       int j = arrayList.size();
/* 174 */       Entry entry2 = null;
/* 175 */       for (int k = j - 1; k >= 0; k--) {
/* 176 */         entry1 = arrayList.remove(k);
/* 177 */         if (isPrimitive) {
/* 178 */           entry2 = new Entry(entry1.key, entry1.value, entry2);
/*     */         } else {
/* 180 */           Object object = ReflectionUtil.callMethod(entry1.value, getCloneMethod(entry1.value), new Object[0]);
/* 181 */           entry2 = (Entry)ReflectionUtil.createInstance(entryConstructor, new Object[] { Integer.valueOf(entry1.key), object, entry2 });
/*     */         } 
/*     */       } 
/*     */       
/* 185 */       intObjectHashMap.table[i] = entry2;
/*     */     } 
/* 187 */     return intObjectHashMap;
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object paramObject) {
/* 191 */     Entry[] arrayOfEntry = this.table;
/* 192 */     for (int i = arrayOfEntry.length; i-- > 0;) {
/* 193 */       for (Entry entry = arrayOfEntry[i]; entry != null; entry = entry.next) {
/* 194 */         if (isPrimitive) {
/* 195 */           if (entry.value == paramObject) {
/* 196 */             return true;
/*     */           }
/*     */         } else {
/* 199 */           Boolean bool = (Boolean)ReflectionUtil.callMethod(paramObject, equalsMethod, new Object[] { entry.value });
/* 200 */           if (bool.booleanValue()) {
/* 201 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 206 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(int paramInt) {
/* 211 */     Entry[] arrayOfEntry = this.table;
/* 212 */     int i = paramInt & this.mask;
/* 213 */     for (Entry entry = arrayOfEntry[i]; entry != null; entry = entry.next) {
/* 214 */       if (entry.key == paramInt) {
/* 215 */         return true;
/*     */       }
/*     */     } 
/* 218 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int paramInt) {
/* 227 */     Entry[] arrayOfEntry = this.table;
/* 228 */     int i = paramInt & this.mask;
/* 229 */     for (Entry entry = arrayOfEntry[i]; entry != null; entry = entry.next) {
/* 230 */       if (entry.key == paramInt) {
/* 231 */         return entry.value;
/*     */       }
/*     */     } 
/* 234 */     return this.keyNotFoundValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(int paramInt, Object paramObject) {
/* 243 */     Entry[] arrayOfEntry = this.table;
/* 244 */     int i = paramInt & this.mask;
/*     */     
/* 246 */     for (Entry entry = arrayOfEntry[i]; entry != null; ) {
/* 247 */       if (entry.key != paramInt) {
/*     */         entry = entry.next; continue;
/*     */       } 
/* 250 */       Object object = entry.value;
/* 251 */       entry.value = paramObject;
/* 252 */       return object;
/*     */     } 
/* 254 */     arrayOfEntry[i] = new Entry(paramInt, paramObject, arrayOfEntry[i]);
/*     */     
/* 256 */     if (this.size++ >= this.threshold) {
/*     */       
/* 258 */       int j = 2 * this.capacity;
/* 259 */       Entry[] arrayOfEntry1 = new Entry[j];
/* 260 */       int k = j - 1;
/* 261 */       for (byte b = 0; b < arrayOfEntry.length; b++) {
/* 262 */         Entry entry1 = arrayOfEntry[b];
/* 263 */         if (entry1 != null) {
/* 264 */           arrayOfEntry[b] = null;
/*     */           do {
/* 266 */             Entry entry2 = entry1.next;
/* 267 */             int m = entry1.key & k;
/* 268 */             entry1.next = arrayOfEntry1[m];
/* 269 */             arrayOfEntry1[m] = entry1;
/* 270 */             entry1 = entry2;
/* 271 */           } while (entry1 != null);
/*     */         } 
/*     */       } 
/* 274 */       this.table = arrayOfEntry1;
/* 275 */       this.capacity = j;
/* 276 */       this.threshold = (int)(j * this.loadFactor);
/* 277 */       this.mask = k;
/*     */     } 
/* 279 */     return this.keyNotFoundValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(IntObjectHashMap paramIntObjectHashMap) {
/* 286 */     Iterator<Entry> iterator = paramIntObjectHashMap.iterator();
/* 287 */     while (iterator.hasNext()) {
/* 288 */       Entry entry = iterator.next();
/* 289 */       put(entry.key, entry.value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(int paramInt) {
/* 299 */     Entry[] arrayOfEntry = this.table;
/* 300 */     int i = paramInt & this.mask;
/* 301 */     Entry entry1 = arrayOfEntry[i];
/* 302 */     Entry entry2 = entry1;
/*     */     
/* 304 */     while (entry2 != null) {
/* 305 */       Entry entry = entry2.next;
/* 306 */       if (entry2.key == paramInt) {
/* 307 */         this.size--;
/* 308 */         if (entry1 == entry2) {
/* 309 */           arrayOfEntry[i] = entry;
/*     */         } else {
/* 311 */           entry1.next = entry;
/*     */         } 
/* 313 */         return entry2.value;
/*     */       } 
/* 315 */       entry1 = entry2;
/* 316 */       entry2 = entry;
/*     */     } 
/* 318 */     return this.keyNotFoundValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 325 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int capacity() {
/* 332 */     return this.capacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 339 */     Arrays.fill((Object[])this.table, (Object)null);
/* 340 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Entry> iterator() {
/* 349 */     return new EntryIterator(this.table);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object setKeyNotFoundValue(Object paramObject) {
/* 362 */     Object object = this.keyNotFoundValue;
/* 363 */     this.keyNotFoundValue = paramObject;
/* 364 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getKeyNotFoundValue() {
/* 373 */     return this.keyNotFoundValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder toString(StringBuilder paramStringBuilder) {
/* 381 */     if (null == paramStringBuilder) {
/* 382 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 384 */     paramStringBuilder.append("{");
/* 385 */     Iterator<Entry> iterator = iterator();
/* 386 */     while (iterator.hasNext()) {
/* 387 */       ((Entry)iterator.next()).toString(paramStringBuilder);
/* 388 */       if (iterator.hasNext()) {
/* 389 */         paramStringBuilder.append(", ");
/*     */       }
/*     */     } 
/* 392 */     paramStringBuilder.append("}");
/* 393 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 398 */     return toString(null).toString();
/*     */   }
/*     */   
/*     */   private static final class EntryIterator
/*     */     implements Iterator<Entry>
/*     */   {
/*     */     private final IntObjectHashMap.Entry[] entries;
/*     */     private int index;
/*     */     private IntObjectHashMap.Entry next;
/*     */     
/*     */     private EntryIterator(IntObjectHashMap.Entry[] param1ArrayOfEntry) {
/* 409 */       this.entries = param1ArrayOfEntry;
/*     */       
/* 411 */       next();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 416 */       return (this.next != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public IntObjectHashMap.Entry next() {
/* 421 */       IntObjectHashMap.Entry entry = this.next;
/*     */       
/* 423 */       if (entry != null && entry.next != null) {
/* 424 */         this.next = entry.next;
/*     */       } else {
/* 426 */         while (this.index < this.entries.length) {
/* 427 */           IntObjectHashMap.Entry entry1 = this.entries[this.index++];
/* 428 */           if (entry1 != null) {
/* 429 */             this.next = entry1;
/* 430 */             return entry;
/*     */           } 
/*     */         } 
/* 433 */         this.next = null;
/*     */       } 
/*     */       
/* 436 */       return entry;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 441 */       throw new UnsupportedOperationException("Not supported yet.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Entry
/*     */   {
/*     */     public final int key;
/*     */     
/*     */     public Object value;
/*     */     
/*     */     Entry next;
/*     */ 
/*     */     
/*     */     Entry(int param1Int, Object param1Object, Entry param1Entry) {
/* 457 */       this.key = param1Int;
/* 458 */       this.value = param1Object;
/* 459 */       this.next = param1Entry;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getKey() {
/* 466 */       return this.key;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue() {
/* 473 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValue(Object param1Object) {
/* 480 */       this.value = param1Object;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StringBuilder toString(StringBuilder param1StringBuilder) {
/* 488 */       if (null == param1StringBuilder) {
/* 489 */         param1StringBuilder = new StringBuilder();
/*     */       }
/* 491 */       param1StringBuilder.append("[").append(this.key).append(":").append(this.value).append("]");
/* 492 */       return param1StringBuilder;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 497 */       return toString(null).toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static Method getCloneMethod(Object paramObject) {
/* 503 */     final Class<?> clazz = paramObject.getClass();
/* 504 */     return SecurityUtil.<Method>doPrivileged(new PrivilegedAction<Method>()
/*     */         {
/*     */           public Method run() {
/*     */             try {
/* 508 */               return clazz.getDeclaredMethod("clone", new Class[0]);
/* 509 */             } catch (NoSuchMethodException noSuchMethodException) {
/* 510 */               throw new JogampRuntimeException("Class " + clazz + " doesn't support clone()", noSuchMethodException);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/IntObjectHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */