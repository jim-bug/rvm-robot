/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncedRingbuffer<T>
/*     */   implements Ringbuffer<T>
/*     */ {
/*  53 */   private final Object syncGlobal = new Object();
/*     */   
/*     */   private T[] array;
/*     */   private int capacity;
/*     */   private int readPos;
/*     */   private int writePos;
/*     */   private int size;
/*     */   
/*     */   public final String toString() {
/*  62 */     return "SyncedRingbuffer<?>[filled " + this.size + " / " + this.capacity + ", writePos " + this.writePos + ", readPos " + this.readPos + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(PrintStream paramPrintStream, String paramString) {
/*  67 */     paramPrintStream.println(paramString + " " + toString() + " {");
/*  68 */     for (byte b = 0; b < this.capacity; b++) {
/*  69 */       paramPrintStream.println("\t[" + b + "]: " + this.array[b]);
/*     */     }
/*  71 */     paramPrintStream.println("}");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncedRingbuffer(T[] paramArrayOfT) throws IllegalArgumentException {
/*  96 */     this.capacity = paramArrayOfT.length;
/*  97 */     this.array = newArray((Class)paramArrayOfT.getClass(), this.capacity);
/*  98 */     resetImpl(true, paramArrayOfT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncedRingbuffer(Class<? extends T[]> paramClass, int paramInt) {
/* 119 */     this.capacity = paramInt;
/* 120 */     this.array = newArray(paramClass, paramInt);
/* 121 */     resetImpl(false, null);
/*     */   }
/*     */   
/*     */   public final int capacity() {
/* 125 */     return this.capacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void clear() {
/* 135 */     synchronized (this.syncGlobal) {
/* 136 */       resetImpl(false, null);
/* 137 */       for (byte b = 0; b < this.capacity; b++) {
/* 138 */         this.array[b] = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void resetFull(T[] paramArrayOfT) throws IllegalArgumentException {
/* 145 */     resetImpl(true, paramArrayOfT);
/*     */   }
/*     */   
/*     */   private final void resetImpl(boolean paramBoolean, T[] paramArrayOfT) throws IllegalArgumentException {
/* 149 */     synchronized (this.syncGlobal) {
/* 150 */       if (null != paramArrayOfT) {
/* 151 */         if (paramArrayOfT.length != capacity()) {
/* 152 */           throw new IllegalArgumentException("copyFrom array length " + paramArrayOfT.length + " != capacity " + this);
/*     */         }
/* 154 */         System.arraycopy(paramArrayOfT, 0, this.array, 0, paramArrayOfT.length);
/* 155 */       } else if (paramBoolean) {
/* 156 */         throw new IllegalArgumentException("copyFrom array is null");
/*     */       } 
/* 158 */       this.readPos = 0;
/* 159 */       this.writePos = 0;
/* 160 */       this.size = paramBoolean ? this.capacity : 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final int size() {
/* 166 */     synchronized (this.syncGlobal) {
/* 167 */       return this.size;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getFreeSlots() {
/* 173 */     synchronized (this.syncGlobal) {
/* 174 */       return this.capacity - this.size;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isEmpty() {
/* 180 */     synchronized (this.syncGlobal) {
/* 181 */       return (0 == this.size);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isFull() {
/* 187 */     synchronized (this.syncGlobal) {
/* 188 */       return (this.capacity == this.size);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T get() {
/*     */     
/* 201 */     try { return getImpl(false, false); }
/* 202 */     catch (InterruptedException interruptedException) { throw new RuntimeException(interruptedException); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getBlocking() throws InterruptedException {
/* 213 */     return getImpl(true, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public final T peek() {
/*     */     
/* 219 */     try { return getImpl(false, true); }
/* 220 */     catch (InterruptedException interruptedException) { throw new RuntimeException(interruptedException); }
/*     */   
/*     */   }
/*     */   public final T peekBlocking() throws InterruptedException {
/* 224 */     return getImpl(true, true);
/*     */   }
/*     */   
/*     */   private final T getImpl(boolean paramBoolean1, boolean paramBoolean2) throws InterruptedException {
/* 228 */     synchronized (this.syncGlobal) {
/* 229 */       if (0 == this.size) {
/* 230 */         if (paramBoolean1) {
/* 231 */           while (0 == this.size) {
/* 232 */             this.syncGlobal.wait();
/*     */           }
/*     */         } else {
/* 235 */           return null;
/*     */         } 
/*     */       }
/* 238 */       int i = this.readPos;
/* 239 */       T t = this.array[i];
/* 240 */       if (!paramBoolean2) {
/* 241 */         this.array[i] = null;
/* 242 */         this.size--;
/* 243 */         this.readPos = (i + 1) % this.capacity;
/* 244 */         this.syncGlobal.notifyAll();
/*     */       } 
/* 246 */       return t;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean put(T paramT) {
/*     */     
/* 259 */     try { return putImpl(paramT, false, false); }
/* 260 */     catch (InterruptedException interruptedException) { throw new RuntimeException(interruptedException); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void putBlocking(T paramT) throws InterruptedException {
/* 271 */     if (!putImpl(paramT, false, true)) {
/* 272 */       throw new InternalError("Blocking put failed: " + this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean putSame(boolean paramBoolean) throws InterruptedException {
/* 284 */     return putImpl(null, true, paramBoolean);
/*     */   }
/*     */   
/*     */   private final boolean putImpl(T paramT, boolean paramBoolean1, boolean paramBoolean2) throws InterruptedException {
/* 288 */     synchronized (this.syncGlobal) {
/* 289 */       if (this.capacity == this.size) {
/* 290 */         if (paramBoolean2) {
/* 291 */           while (this.capacity == this.size) {
/* 292 */             this.syncGlobal.wait();
/*     */           }
/*     */         } else {
/* 295 */           return false;
/*     */         } 
/*     */       }
/* 298 */       int i = this.writePos;
/* 299 */       if (!paramBoolean1) {
/* 300 */         this.array[i] = paramT;
/*     */       }
/* 302 */       this.size++;
/* 303 */       this.writePos = (i + 1) % this.capacity;
/* 304 */       this.syncGlobal.notifyAll();
/* 305 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void waitForFreeSlots(int paramInt) throws InterruptedException {
/* 311 */     synchronized (this.syncGlobal) {
/* 312 */       if (this.capacity - this.size < paramInt) {
/* 313 */         while (this.capacity - this.size < paramInt) {
/* 314 */           this.syncGlobal.wait();
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void growEmptyBuffer(T[] paramArrayOfT) throws IllegalStateException, IllegalArgumentException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield syncGlobal : Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aconst_null
/*     */     //   8: aload_1
/*     */     //   9: if_acmpne -> 22
/*     */     //   12: new java/lang/IllegalArgumentException
/*     */     //   15: dup
/*     */     //   16: ldc 'newElements is null'
/*     */     //   18: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   21: athrow
/*     */     //   22: aload_0
/*     */     //   23: getfield array : [Ljava/lang/Object;
/*     */     //   26: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   29: astore_3
/*     */     //   30: aload_1
/*     */     //   31: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   34: astore #4
/*     */     //   36: aload_3
/*     */     //   37: aload #4
/*     */     //   39: if_acmpeq -> 79
/*     */     //   42: new java/lang/IllegalArgumentException
/*     */     //   45: dup
/*     */     //   46: new java/lang/StringBuilder
/*     */     //   49: dup
/*     */     //   50: invokespecial <init> : ()V
/*     */     //   53: ldc 'newElements array-type mismatch, internal '
/*     */     //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   58: aload_3
/*     */     //   59: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   62: ldc ', newElements '
/*     */     //   64: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   67: aload #4
/*     */     //   69: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   72: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   75: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   78: athrow
/*     */     //   79: iconst_0
/*     */     //   80: aload_0
/*     */     //   81: getfield size : I
/*     */     //   84: if_icmpeq -> 114
/*     */     //   87: new java/lang/IllegalStateException
/*     */     //   90: dup
/*     */     //   91: new java/lang/StringBuilder
/*     */     //   94: dup
/*     */     //   95: invokespecial <init> : ()V
/*     */     //   98: ldc 'Buffer is not empty: '
/*     */     //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   103: aload_0
/*     */     //   104: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   107: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   110: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   113: athrow
/*     */     //   114: aload_0
/*     */     //   115: getfield readPos : I
/*     */     //   118: aload_0
/*     */     //   119: getfield writePos : I
/*     */     //   122: if_icmpeq -> 152
/*     */     //   125: new java/lang/InternalError
/*     */     //   128: dup
/*     */     //   129: new java/lang/StringBuilder
/*     */     //   132: dup
/*     */     //   133: invokespecial <init> : ()V
/*     */     //   136: ldc 'R/W pos not equal: '
/*     */     //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   141: aload_0
/*     */     //   142: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   145: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   148: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   151: athrow
/*     */     //   152: aload_1
/*     */     //   153: arraylength
/*     */     //   154: istore #5
/*     */     //   156: aload_0
/*     */     //   157: getfield capacity : I
/*     */     //   160: iload #5
/*     */     //   162: iadd
/*     */     //   163: istore #6
/*     */     //   165: aload_0
/*     */     //   166: getfield array : [Ljava/lang/Object;
/*     */     //   169: astore #7
/*     */     //   171: aload_3
/*     */     //   172: iload #6
/*     */     //   174: invokestatic newArray : (Ljava/lang/Class;I)[Ljava/lang/Object;
/*     */     //   177: astore #8
/*     */     //   179: aload_0
/*     */     //   180: dup
/*     */     //   181: getfield writePos : I
/*     */     //   184: iload #5
/*     */     //   186: iadd
/*     */     //   187: putfield writePos : I
/*     */     //   190: aload_0
/*     */     //   191: getfield readPos : I
/*     */     //   194: ifle -> 210
/*     */     //   197: aload #7
/*     */     //   199: iconst_0
/*     */     //   200: aload #8
/*     */     //   202: iconst_0
/*     */     //   203: aload_0
/*     */     //   204: getfield readPos : I
/*     */     //   207: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   210: iload #5
/*     */     //   212: ifle -> 228
/*     */     //   215: aload_1
/*     */     //   216: iconst_0
/*     */     //   217: aload #8
/*     */     //   219: aload_0
/*     */     //   220: getfield readPos : I
/*     */     //   223: iload #5
/*     */     //   225: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   228: aload_0
/*     */     //   229: getfield capacity : I
/*     */     //   232: aload_0
/*     */     //   233: getfield readPos : I
/*     */     //   236: isub
/*     */     //   237: istore #9
/*     */     //   239: iload #9
/*     */     //   241: ifle -> 261
/*     */     //   244: aload #7
/*     */     //   246: aload_0
/*     */     //   247: getfield readPos : I
/*     */     //   250: aload #8
/*     */     //   252: aload_0
/*     */     //   253: getfield writePos : I
/*     */     //   256: iload #9
/*     */     //   258: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   261: aload_0
/*     */     //   262: iload #5
/*     */     //   264: putfield size : I
/*     */     //   267: aload_0
/*     */     //   268: iload #6
/*     */     //   270: putfield capacity : I
/*     */     //   273: aload_0
/*     */     //   274: aload #8
/*     */     //   276: putfield array : [Ljava/lang/Object;
/*     */     //   279: aload_2
/*     */     //   280: monitorexit
/*     */     //   281: goto -> 291
/*     */     //   284: astore #10
/*     */     //   286: aload_2
/*     */     //   287: monitorexit
/*     */     //   288: aload #10
/*     */     //   290: athrow
/*     */     //   291: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #323	-> 0
/*     */     //   #324	-> 7
/*     */     //   #325	-> 12
/*     */     //   #328	-> 22
/*     */     //   #330	-> 30
/*     */     //   #331	-> 36
/*     */     //   #332	-> 42
/*     */     //   #334	-> 79
/*     */     //   #335	-> 87
/*     */     //   #337	-> 114
/*     */     //   #338	-> 125
/*     */     //   #341	-> 152
/*     */     //   #342	-> 156
/*     */     //   #343	-> 165
/*     */     //   #344	-> 171
/*     */     //   #347	-> 179
/*     */     //   #349	-> 190
/*     */     //   #350	-> 197
/*     */     //   #352	-> 210
/*     */     //   #353	-> 215
/*     */     //   #355	-> 228
/*     */     //   #356	-> 239
/*     */     //   #357	-> 244
/*     */     //   #359	-> 261
/*     */     //   #361	-> 267
/*     */     //   #362	-> 273
/*     */     //   #363	-> 279
/*     */     //   #364	-> 291
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	281	284	finally
/*     */     //   284	288	284	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void growFullBuffer(int paramInt) throws IllegalStateException, IllegalArgumentException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield syncGlobal : Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: iconst_0
/*     */     //   8: iload_1
/*     */     //   9: if_icmple -> 44
/*     */     //   12: new java/lang/IllegalArgumentException
/*     */     //   15: dup
/*     */     //   16: new java/lang/StringBuilder
/*     */     //   19: dup
/*     */     //   20: invokespecial <init> : ()V
/*     */     //   23: ldc 'amount '
/*     */     //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   28: iload_1
/*     */     //   29: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   32: ldc ' < 0 '
/*     */     //   34: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   37: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   40: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   43: athrow
/*     */     //   44: aload_0
/*     */     //   45: getfield capacity : I
/*     */     //   48: aload_0
/*     */     //   49: getfield size : I
/*     */     //   52: if_icmpeq -> 82
/*     */     //   55: new java/lang/IllegalStateException
/*     */     //   58: dup
/*     */     //   59: new java/lang/StringBuilder
/*     */     //   62: dup
/*     */     //   63: invokespecial <init> : ()V
/*     */     //   66: ldc 'Buffer is not full: '
/*     */     //   68: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   71: aload_0
/*     */     //   72: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   75: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   78: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   81: athrow
/*     */     //   82: aload_0
/*     */     //   83: getfield readPos : I
/*     */     //   86: aload_0
/*     */     //   87: getfield writePos : I
/*     */     //   90: if_icmpeq -> 120
/*     */     //   93: new java/lang/InternalError
/*     */     //   96: dup
/*     */     //   97: new java/lang/StringBuilder
/*     */     //   100: dup
/*     */     //   101: invokespecial <init> : ()V
/*     */     //   104: ldc 'R/W pos not equal: '
/*     */     //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   109: aload_0
/*     */     //   110: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   113: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   116: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   119: athrow
/*     */     //   120: aload_0
/*     */     //   121: getfield array : [Ljava/lang/Object;
/*     */     //   124: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   127: astore_3
/*     */     //   128: aload_0
/*     */     //   129: getfield capacity : I
/*     */     //   132: iload_1
/*     */     //   133: iadd
/*     */     //   134: istore #4
/*     */     //   136: aload_0
/*     */     //   137: getfield array : [Ljava/lang/Object;
/*     */     //   140: astore #5
/*     */     //   142: aload_3
/*     */     //   143: iload #4
/*     */     //   145: invokestatic newArray : (Ljava/lang/Class;I)[Ljava/lang/Object;
/*     */     //   148: astore #6
/*     */     //   150: aload_0
/*     */     //   151: dup
/*     */     //   152: getfield readPos : I
/*     */     //   155: iload_1
/*     */     //   156: iadd
/*     */     //   157: putfield readPos : I
/*     */     //   160: aload_0
/*     */     //   161: getfield writePos : I
/*     */     //   164: ifle -> 180
/*     */     //   167: aload #5
/*     */     //   169: iconst_0
/*     */     //   170: aload #6
/*     */     //   172: iconst_0
/*     */     //   173: aload_0
/*     */     //   174: getfield writePos : I
/*     */     //   177: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   180: aload_0
/*     */     //   181: getfield capacity : I
/*     */     //   184: aload_0
/*     */     //   185: getfield writePos : I
/*     */     //   188: isub
/*     */     //   189: istore #7
/*     */     //   191: iload #7
/*     */     //   193: ifle -> 213
/*     */     //   196: aload #5
/*     */     //   198: aload_0
/*     */     //   199: getfield writePos : I
/*     */     //   202: aload #6
/*     */     //   204: aload_0
/*     */     //   205: getfield readPos : I
/*     */     //   208: iload #7
/*     */     //   210: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   213: aload_0
/*     */     //   214: iload #4
/*     */     //   216: putfield capacity : I
/*     */     //   219: aload_0
/*     */     //   220: aload #6
/*     */     //   222: putfield array : [Ljava/lang/Object;
/*     */     //   225: aload_2
/*     */     //   226: monitorexit
/*     */     //   227: goto -> 237
/*     */     //   230: astore #8
/*     */     //   232: aload_2
/*     */     //   233: monitorexit
/*     */     //   234: aload #8
/*     */     //   236: athrow
/*     */     //   237: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #368	-> 0
/*     */     //   #369	-> 7
/*     */     //   #370	-> 12
/*     */     //   #372	-> 44
/*     */     //   #373	-> 55
/*     */     //   #375	-> 82
/*     */     //   #376	-> 93
/*     */     //   #379	-> 120
/*     */     //   #381	-> 128
/*     */     //   #382	-> 136
/*     */     //   #383	-> 142
/*     */     //   #386	-> 150
/*     */     //   #388	-> 160
/*     */     //   #389	-> 167
/*     */     //   #391	-> 180
/*     */     //   #392	-> 191
/*     */     //   #393	-> 196
/*     */     //   #396	-> 213
/*     */     //   #397	-> 219
/*     */     //   #398	-> 225
/*     */     //   #399	-> 237
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	227	230	finally
/*     */     //   230	234	230	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T[] newArray(Class<? extends T[]> paramClass, int paramInt) {
/* 403 */     return (paramClass == Object[].class) ? 
/* 404 */       (T[])new Object[paramInt] : 
/* 405 */       (T[])Array.newInstance(paramClass.getComponentType(), paramInt);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/SyncedRingbuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */