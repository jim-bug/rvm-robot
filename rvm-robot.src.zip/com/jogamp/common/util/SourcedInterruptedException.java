/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.ExceptionUtils;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourcedInterruptedException
/*     */   extends InterruptedException
/*     */   implements ExceptionUtils.CustomStackTrace
/*     */ {
/*     */   final Throwable interruptSource;
/*     */   
/*     */   public static InterruptedException wrap(InterruptedException paramInterruptedException) {
/*  63 */     return wrap(paramInterruptedException, InterruptSource.Util.currentThread());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InterruptedException wrap(InterruptedException paramInterruptedException, InterruptSource paramInterruptSource) {
/*  81 */     if (!(paramInterruptedException instanceof SourcedInterruptedException) && null != paramInterruptSource) {
/*  82 */       return new SourcedInterruptedException(paramInterruptedException, paramInterruptSource.getInterruptSource(true));
/*     */     }
/*  84 */     return paramInterruptedException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourcedInterruptedException(String paramString, InterruptedException paramInterruptedException, Throwable paramThrowable) {
/*  94 */     super(paramString);
/*  95 */     if (null != paramInterruptedException) {
/*  96 */       initCause(paramInterruptedException);
/*     */     }
/*  98 */     this.interruptSource = paramThrowable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourcedInterruptedException(InterruptedException paramInterruptedException, Throwable paramThrowable) {
/* 106 */     super(paramInterruptedException.getMessage());
/* 107 */     initCause(paramInterruptedException);
/* 108 */     this.interruptSource = paramThrowable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Throwable getInterruptSource() {
/* 116 */     return this.interruptSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InterruptedException getCause() {
/* 128 */     return (InterruptedException)super.getCause();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 133 */     StringBuilder stringBuilder = new StringBuilder(256);
/* 134 */     stringBuilder.append(getClass().getSimpleName()).append(": ");
/* 135 */     if (null != this.interruptSource) {
/* 136 */       stringBuilder.append("[sourced]");
/*     */     } else {
/* 138 */       stringBuilder.append("[unknown]");
/*     */     } 
/* 140 */     String str = getLocalizedMessage();
/* 141 */     if (null != str) {
/* 142 */       stringBuilder.append(" ").append(str);
/*     */     }
/* 144 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void printCauseStack(PrintStream paramPrintStream, String paramString, int paramInt1, int paramInt2) {
/* 149 */     String str = paramString + "[" + paramInt1 + "]";
/* 150 */     paramPrintStream.println(str + " by " + getClass().getSimpleName() + ": " + getMessage() + " on thread " + Thread.currentThread().getName());
/* 151 */     ExceptionUtils.dumpStack(paramPrintStream, getStackTrace(), 0, paramInt2);
/* 152 */     if (null != this.interruptSource) {
/* 153 */       ExceptionUtils.printCause(paramPrintStream, str, this.interruptSource, 0, 1, paramInt2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void printStackTrace(PrintStream paramPrintStream, int paramInt1, int paramInt2) {
/* 159 */     paramPrintStream.println(getClass().getSimpleName() + ": " + getMessage() + " on thread " + Thread.currentThread().getName());
/* 160 */     ExceptionUtils.dumpStack(paramPrintStream, getStackTrace(), 0, paramInt2);
/* 161 */     ExceptionUtils.printCause(paramPrintStream, "Caused", getCause(), 0, paramInt1, paramInt2);
/* 162 */     if (null != this.interruptSource)
/* 163 */       ExceptionUtils.printCause(paramPrintStream, "InterruptSource", this.interruptSource, 0, paramInt1, paramInt2); 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/SourcedInterruptedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */