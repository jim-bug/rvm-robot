/*     */ package com.jogamp.common.util.awt;
/*     */ 
/*     */ import com.jogamp.common.util.RunnableExecutor;
/*     */ import java.awt.EventQueue;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AWTEDTExecutor
/*     */   implements RunnableExecutor
/*     */ {
/*  42 */   public static final AWTEDTExecutor singleton = new AWTEDTExecutor();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(boolean paramBoolean, Runnable paramRunnable) {
/*  48 */     if (EventQueue.isDispatchThread()) {
/*  49 */       paramRunnable.run();
/*     */     } else {
/*     */       try {
/*  52 */         if (paramBoolean) {
/*  53 */           EventQueue.invokeAndWait(paramRunnable);
/*     */         } else {
/*  55 */           EventQueue.invokeLater(paramRunnable);
/*     */         } 
/*  57 */       } catch (InvocationTargetException invocationTargetException) {
/*  58 */         throw new RuntimeException(invocationTargetException.getTargetException());
/*  59 */       } catch (InterruptedException interruptedException) {
/*  60 */         throw new RuntimeException(interruptedException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean invoke(Object paramObject, boolean paramBoolean1, boolean paramBoolean2, Runnable paramRunnable) {
/*  87 */     if (EventQueue.isDispatchThread()) {
/*  88 */       paramRunnable.run();
/*  89 */       return true;
/*  90 */     }  if (!Thread.holdsLock(paramObject)) {
/*     */       try {
/*  92 */         if (paramBoolean2) {
/*  93 */           EventQueue.invokeAndWait(paramRunnable);
/*     */         } else {
/*  95 */           EventQueue.invokeLater(paramRunnable);
/*     */         } 
/*  97 */       } catch (InvocationTargetException invocationTargetException) {
/*  98 */         throw new RuntimeException(invocationTargetException.getTargetException());
/*  99 */       } catch (InterruptedException interruptedException) {
/* 100 */         throw new RuntimeException(interruptedException);
/*     */       } 
/* 102 */       return true;
/* 103 */     }  if (paramBoolean1) {
/* 104 */       paramRunnable.run();
/* 105 */       return true;
/*     */     } 
/* 107 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/awt/AWTEDTExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */