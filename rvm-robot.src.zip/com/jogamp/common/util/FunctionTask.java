/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.JogampRuntimeException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionTask<R, A>
/*     */   extends TaskBase
/*     */   implements Function<R, A>
/*     */ {
/*     */   protected Function<R, A> runnable;
/*     */   protected R result;
/*     */   protected A[] args;
/*     */   
/*     */   public static <U, V> FunctionTask<U, V> invokeOnCurrentThread(Function<U, V> paramFunction, V... paramVarArgs) {
/*  56 */     FunctionTask<U, V> functionTask = new FunctionTask<>(paramFunction, null, false, null);
/*  57 */     functionTask.args = (A[])paramVarArgs;
/*  58 */     functionTask.run();
/*  59 */     return functionTask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <U, V> FunctionTask<U, V> invokeOnNewThread(ThreadGroup paramThreadGroup, String paramString, boolean paramBoolean, Function<U, V> paramFunction, V... paramVarArgs) {
/*     */     FunctionTask<U, V> functionTask;
/*  80 */     if (!paramBoolean) {
/*  81 */       functionTask = new FunctionTask<>(paramFunction, null, true, System.err);
/*  82 */       InterruptSource.Thread thread = InterruptSource.Thread.create(paramThreadGroup, functionTask, paramString);
/*  83 */       functionTask.args = (A[])paramVarArgs;
/*  84 */       thread.start();
/*     */     } else {
/*  86 */       Object object = new Object();
/*  87 */       functionTask = new FunctionTask<>(paramFunction, object, true, null);
/*  88 */       InterruptSource.Thread thread = InterruptSource.Thread.create(paramThreadGroup, functionTask, paramString);
/*  89 */       synchronized (object) {
/*  90 */         functionTask.args = (A[])paramVarArgs;
/*  91 */         thread.start();
/*  92 */         while (functionTask.isInQueue()) {
/*     */           try {
/*  94 */             object.wait();
/*  95 */           } catch (InterruptedException interruptedException) {
/*  96 */             throw new InterruptedRuntimeException(interruptedException);
/*     */           } 
/*  98 */           Throwable throwable = functionTask.getThrowable();
/*  99 */           if (null != throwable) {
/* 100 */             throw new JogampRuntimeException(throwable);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 105 */     return functionTask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionTask(Function<R, A> paramFunction, Object paramObject, boolean paramBoolean, PrintStream paramPrintStream) {
/* 121 */     super(paramObject, paramBoolean, paramPrintStream);
/* 122 */     this.runnable = paramFunction;
/* 123 */     this.result = null;
/* 124 */     this.args = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Function<R, A> getRunnable() {
/* 129 */     return this.runnable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setArgs(A... paramVarArgs) {
/* 137 */     this.args = paramVarArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final R getResult() {
/* 145 */     R r = this.result;
/* 146 */     this.result = null;
/* 147 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void run() {
/* 162 */     this.execThread = Thread.currentThread();
/*     */     
/* 164 */     A[] arrayOfA = this.args;
/* 165 */     this.args = null;
/* 166 */     this.result = null;
/* 167 */     this.runnableException = null;
/* 168 */     this.tStarted = System.currentTimeMillis();
/* 169 */     if (null == this.syncObject) {
/*     */       try {
/* 171 */         this.result = this.runnable.eval(arrayOfA);
/* 172 */       } catch (Throwable throwable) {
/* 173 */         this.runnableException = throwable;
/* 174 */         if (null != this.exceptionOut) {
/* 175 */           this.exceptionOut.println("FunctionTask.run(): " + getExceptionOutIntro() + " exception occured on thread " + Thread.currentThread().getName() + ": " + toString());
/* 176 */           printSourceTrace();
/* 177 */           throwable.printStackTrace(this.exceptionOut);
/*     */         } 
/* 179 */         if (!this.catchExceptions) {
/* 180 */           throw new RuntimeException(this.runnableException);
/*     */         }
/*     */       } finally {
/* 183 */         this.tExecuted = System.currentTimeMillis();
/* 184 */         this.isExecuted = true;
/*     */       } 
/*     */     } else {
/* 187 */       synchronized (this.syncObject) {
/*     */         try {
/* 189 */           this.result = this.runnable.eval(arrayOfA);
/* 190 */         } catch (Throwable throwable) {
/* 191 */           this.runnableException = throwable;
/* 192 */           if (null != this.exceptionOut) {
/* 193 */             this.exceptionOut.println("FunctionTask.run(): " + getExceptionOutIntro() + " exception occured on thread " + Thread.currentThread().getName() + ": " + toString());
/* 194 */             printSourceTrace();
/* 195 */             throwable.printStackTrace(this.exceptionOut);
/*     */           } 
/* 197 */           if (!this.catchExceptions) {
/* 198 */             throw new RuntimeException(this.runnableException);
/*     */           }
/*     */         } finally {
/* 201 */           this.tExecuted = System.currentTimeMillis();
/* 202 */           this.isExecuted = true;
/* 203 */           this.syncObject.notifyAll();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final R eval(A... paramVarArgs) {
/* 211 */     this.args = paramVarArgs;
/* 212 */     run();
/* 213 */     R r = this.result;
/* 214 */     this.result = null;
/* 215 */     return r;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/FunctionTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */