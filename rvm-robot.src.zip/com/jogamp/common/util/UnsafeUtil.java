/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.ExceptionUtils;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.PrivilegedAction;
/*     */ import jogamp.common.Debug;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsafeUtil
/*     */ {
/*  48 */   static final boolean DEBUG = Debug.debug("UnsafeUtil");
/*     */   
/*     */   private static final Object theUnsafe;
/*     */   
/*     */   private static final Method unsafeCleanBB;
/*     */   
/*     */   private static volatile boolean hasUnsafeCleanBBError;
/*     */   
/*     */   private static final Method staticFieldOffset;
/*     */   
/*     */   private static final Method getObjectVolatile;
/*     */   
/*     */   private static final Method putObjectVolatile;
/*     */   private static volatile boolean hasGetPutObjectVolatile;
/*     */   private static final Class<?> illegalAccessLoggerClass;
/*     */   private static final Long illegalAccessLoggerOffset;
/*  64 */   private static final Object illegalAccessLoggerSync = new Object();
/*     */   private static volatile boolean hasIllegalAccessError;
/*     */   
/*     */   static {
/*  68 */     final Object[] _theUnsafe = { null };
/*  69 */     final Method[] _cleanBB = { null };
/*  70 */     final Method[] _staticFieldOffset = { null };
/*  71 */     final Method[] _objectVolatile = { null, null };
/*  72 */     final Class[] _illegalAccessLoggerClass = { null };
/*  73 */     final Long[] _loggerOffset = { null };
/*     */     
/*  75 */     SecurityUtil.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/*  78 */             Class<?> clazz = null;
/*     */             
/*     */             try {
/*  81 */               clazz = Class.forName("sun.misc.Unsafe");
/*     */               
/*  83 */               Field field = clazz.getDeclaredField("theUnsafe");
/*  84 */               field.setAccessible(true);
/*  85 */               _theUnsafe[0] = field.get(null);
/*     */               
/*  87 */               _cleanBB[0] = clazz.getMethod("invokeCleaner", new Class[] { ByteBuffer.class });
/*  88 */               _cleanBB[0].setAccessible(true);
/*  89 */             } catch (Throwable throwable) {
/*  90 */               if (UnsafeUtil.DEBUG) {
/*  91 */                 ExceptionUtils.dumpThrowable("UnsafeUtil", throwable);
/*     */               }
/*     */             } 
/*  94 */             if (null != _theUnsafe[0] && PlatformPropsImpl.JAVA_9) {
/*     */               try {
/*  96 */                 _staticFieldOffset[0] = clazz.getDeclaredMethod("staticFieldOffset", new Class[] { Field.class });
/*  97 */                 _objectVolatile[0] = clazz.getDeclaredMethod("getObjectVolatile", new Class[] { Object.class, long.class });
/*  98 */                 _objectVolatile[1] = clazz.getDeclaredMethod("putObjectVolatile", new Class[] { Object.class, long.class, Object.class });
/*     */                 
/* 100 */                 if (PlatformPropsImpl.JAVA_9) {
/* 101 */                   _illegalAccessLoggerClass[0] = Class.forName("jdk.internal.module.IllegalAccessLogger");
/* 102 */                   Field field = _illegalAccessLoggerClass[0].getDeclaredField("logger");
/* 103 */                   _loggerOffset[0] = (Long)_staticFieldOffset[0].invoke(_theUnsafe[0], new Object[] { field });
/*     */                 } 
/* 105 */               } catch (Throwable throwable) {
/* 106 */                 if (UnsafeUtil.DEBUG) {
/* 107 */                   ExceptionUtils.dumpThrowable("UnsafeUtil", throwable);
/*     */                 }
/*     */               } 
/*     */             }
/* 111 */             return null; }
/*     */         });
/* 113 */     theUnsafe = arrayOfObject[0];
/* 114 */     unsafeCleanBB = arrayOfMethod1[0];
/* 115 */     hasUnsafeCleanBBError = (null == theUnsafe || null == unsafeCleanBB);
/* 116 */     if (DEBUG) {
/* 117 */       System.err.println("UnsafeUtil.init: hasTheUnsafe: " + ((null != theUnsafe) ? 1 : 0) + ", hasInvokeCleaner: " + (!hasUnsafeCleanBBError ? 1 : 0));
/*     */     }
/*     */     
/* 120 */     staticFieldOffset = arrayOfMethod2[0];
/* 121 */     getObjectVolatile = arrayOfMethod3[0];
/* 122 */     putObjectVolatile = arrayOfMethod3[1];
/* 123 */     hasGetPutObjectVolatile = (null != staticFieldOffset && null != getObjectVolatile && null != putObjectVolatile);
/* 124 */     illegalAccessLoggerClass = arrayOfClass[0];
/* 125 */     illegalAccessLoggerOffset = arrayOfLong[0];
/* 126 */     hasIllegalAccessError = (!hasGetPutObjectVolatile || null == illegalAccessLoggerClass || null == illegalAccessLoggerOffset);
/* 127 */     if (DEBUG) {
/* 128 */       System.err.println("UnsafeUtil.init: hasUnsafeGetPutObjectVolatile: " + hasGetPutObjectVolatile + ", hasUnsafeIllegalAccessLogger: " + (!hasIllegalAccessError ? 1 : 0));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasInvokeCleaner() {
/* 137 */     return !hasUnsafeCleanBBError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean invokeCleaner(ByteBuffer paramByteBuffer) {
/* 149 */     if (hasUnsafeCleanBBError || !paramByteBuffer.isDirect()) {
/* 150 */       return false;
/*     */     }
/*     */     try {
/* 153 */       unsafeCleanBB.invoke(theUnsafe, new Object[] { paramByteBuffer });
/* 154 */       return true;
/* 155 */     } catch (Throwable throwable) {
/* 156 */       hasUnsafeCleanBBError = true;
/* 157 */       if (DEBUG) {
/* 158 */         ExceptionUtils.dumpThrowable("UnsafeUtil", throwable);
/*     */       }
/* 160 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasIllegalAccessLoggerAccess() {
/* 169 */     return !hasIllegalAccessError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T doWithoutIllegalAccessLogger(PrivilegedAction<T> paramPrivilegedAction) throws RuntimeException {
/* 185 */     if (!hasIllegalAccessError) {
/* 186 */       synchronized (illegalAccessLoggerSync) {
/* 187 */         Object object = null;
/* 188 */         Object object1 = null;
/*     */         try {
/* 190 */           object1 = getObjectVolatile.invoke(theUnsafe, new Object[] { illegalAccessLoggerClass, illegalAccessLoggerOffset });
/* 191 */           putObjectVolatile.invoke(theUnsafe, new Object[] { illegalAccessLoggerClass, illegalAccessLoggerOffset, object });
/* 192 */         } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/*     */           
/* 194 */           hasIllegalAccessError = true;
/* 195 */           if (DEBUG) {
/* 196 */             ExceptionUtils.dumpThrowable("UnsafeUtil", illegalAccessException);
/*     */           }
/* 198 */           return paramPrivilegedAction.run();
/*     */         } 
/*     */         try {
/* 201 */           return paramPrivilegedAction.run();
/* 202 */         } catch (Throwable throwable) {
/* 203 */           if (DEBUG) {
/* 204 */             throwable.printStackTrace();
/*     */           }
/* 206 */           throw new RuntimeException(throwable);
/*     */         } finally {
/*     */           try {
/* 209 */             putObjectVolatile.invoke(theUnsafe, new Object[] { illegalAccessLoggerClass, illegalAccessLoggerOffset, object1 });
/* 210 */           } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/*     */             
/* 212 */             hasIllegalAccessError = true;
/* 213 */             throw new InternalError(illegalAccessException);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 218 */     return paramPrivilegedAction.run();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/UnsafeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */