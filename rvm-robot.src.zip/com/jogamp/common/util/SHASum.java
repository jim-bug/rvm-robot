/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.util.cache.TempJarCache;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.regex.Pattern;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SHASum
/*     */ {
/*  74 */   private static final boolean DEBUG = Debug.debug("SHASum");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MessageDigest digest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<String> origins;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<Pattern> excludes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<Pattern> includes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long updateDigest(MessageDigest paramMessageDigest, List<String> paramList) throws IOException {
/* 103 */     long l = 0L;
/* 104 */     byte[] arrayOfByte = new byte[4096];
/* 105 */     for (byte b = 0; b < paramList.size(); b++) {
/* 106 */       BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(paramList.get(b)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder toHexString(byte[] paramArrayOfbyte, StringBuilder paramStringBuilder) {
/* 130 */     if (null == paramStringBuilder) {
/* 131 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 133 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/* 134 */       paramStringBuilder.append(String.format((Locale)null, "%02x", new Object[] { Byte.valueOf(paramArrayOfbyte[b]) }));
/*     */     } 
/* 136 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> sort(ArrayList<String> paramArrayList) {
/* 145 */     String[] arrayOfString = paramArrayList.<String>toArray(new String[paramArrayList.size()]);
/* 146 */     Arrays.sort(arrayOfString, 0, arrayOfString.length, null);
/* 147 */     return Arrays.asList(arrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SHASum(MessageDigest paramMessageDigest, List<String> paramList, List<Pattern> paramList1, List<Pattern> paramList2) {
/* 169 */     this.digest = paramMessageDigest;
/* 170 */     this.origins = paramList;
/* 171 */     this.excludes = paramList1;
/* 172 */     this.includes = paramList2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] compute(boolean paramBoolean) throws IOException {
/* 191 */     List<String> list = sort(IOUtil.filesOf(this.origins, this.excludes, this.includes));
/* 192 */     if (paramBoolean) {
/* 193 */       for (byte b = 0; b < list.size(); b++) {
/* 194 */         System.err.println(list.get(b));
/*     */       }
/*     */     }
/* 197 */     long l = updateDigest(this.digest, list);
/* 198 */     byte[] arrayOfByte = this.digest.digest();
/* 199 */     if (paramBoolean) {
/* 200 */       System.err.println("Digested " + l + " bytes, shasum size " + arrayOfByte.length + " bytes");
/* 201 */       System.err.println("Digested result: " + toHexString(arrayOfByte, null).toString());
/*     */     } 
/* 203 */     return arrayOfByte;
/*     */   }
/*     */   
/* 206 */   public final List<String> getOrigins() { return this.origins; }
/* 207 */   public final List<Pattern> getExcludes() { return this.excludes; } public final List<Pattern> getIncludes() {
/* 208 */     return this.includes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TempJarSHASum
/*     */     extends SHASum
/*     */   {
/*     */     public TempJarSHASum(MessageDigest param1MessageDigest, Class<?> param1Class, List<Pattern> param1List1, List<Pattern> param1List2) throws SecurityException, IllegalArgumentException, IOException, URISyntaxException {
/* 235 */       super(param1MessageDigest, Arrays.asList(new String[] { IOUtil.slashify(TempJarCache.getTempFileCache().getTempDir().getAbsolutePath(), false, false) }), param1List1, param1List2);
/*     */       
/* 237 */       TempJarCache.addAll(param1Class, JarUtil.getJarFileUri(param1Class.getName(), param1Class.getClassLoader()));
/*     */     }
/*     */     public final String getOrigin() {
/* 240 */       return this.origins.get(0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws IOException {
/*     */     MessageDigest messageDigest;
/* 273 */     boolean bool = false;
/* 274 */     int i = 256;
/*     */     
/* 276 */     ArrayList<String> arrayList = new ArrayList();
/* 277 */     ArrayList<Pattern> arrayList1 = new ArrayList();
/* 278 */     ArrayList<Pattern> arrayList2 = new ArrayList();
/*     */     byte b;
/* 280 */     for (b = 0; b < paramArrayOfString.length; b++) {
/* 281 */       if (null != paramArrayOfString[b]) {
/* 282 */         if (paramArrayOfString[b].startsWith("--")) {
/*     */           
/* 284 */           if (paramArrayOfString[b].equals("--algorithm")) {
/* 285 */             i = Integer.parseInt(paramArrayOfString[++b]);
/* 286 */           } else if (paramArrayOfString[b].equals("--exclude")) {
/* 287 */             arrayList1.add(Pattern.compile(paramArrayOfString[++b]));
/* 288 */             if (DEBUG) {
/* 289 */               System.err.println("adding exclude: <" + paramArrayOfString[b] + "> -> <" + arrayList1.get(arrayList1.size() - 1) + ">");
/*     */             }
/* 291 */           } else if (paramArrayOfString[b].equals("--include")) {
/* 292 */             arrayList2.add(Pattern.compile(paramArrayOfString[++b]));
/* 293 */             if (DEBUG) {
/* 294 */               System.err.println("adding include: <" + paramArrayOfString[b] + "> -> <" + arrayList2.get(arrayList2.size() - 1) + ">");
/*     */             }
/* 296 */           } else if (paramArrayOfString[b].equals("--listfilesonly")) {
/* 297 */             bool = true;
/*     */           } else {
/* 299 */             System.err.println("Abort, unknown argument: " + paramArrayOfString[b]);
/*     */             return;
/*     */           } 
/*     */         } else {
/* 303 */           arrayList.add(paramArrayOfString[b]);
/* 304 */           if (DEBUG) {
/* 305 */             System.err.println("adding path: <" + paramArrayOfString[b] + ">");
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 310 */     if (bool) {
/* 311 */       List<String> list = sort(IOUtil.filesOf(arrayList, arrayList1, arrayList2));
/* 312 */       for (b = 0; b < list.size(); b++) {
/* 313 */         System.out.println(list.get(b));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 318 */     String str = "SHA-" + i;
/*     */     
/*     */     try {
/* 321 */       messageDigest = MessageDigest.getInstance(str);
/* 322 */     } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
/* 323 */       System.err.println("Abort, implementation for " + str + " not available: " + noSuchAlgorithmException.getMessage());
/*     */       return;
/*     */     } 
/* 326 */     SHASum sHASum = new SHASum(messageDigest, arrayList, arrayList1, arrayList2);
/* 327 */     System.out.println(toHexString(sHASum.compute(DEBUG), null).toString());
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/SHASum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */