/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.nio.BufferOverflowException;
/*     */ import java.nio.BufferUnderflowException;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerStack
/*     */   implements PrimitiveStack
/*     */ {
/*     */   private int position;
/*     */   private int[] buffer;
/*     */   private int growSize;
/*     */   
/*     */   public IntegerStack(int paramInt1, int paramInt2) {
/*  54 */     this.position = 0;
/*  55 */     this.growSize = paramInt2;
/*  56 */     this.buffer = new int[paramInt1];
/*     */   }
/*     */   
/*     */   public final int capacity() {
/*  60 */     return this.buffer.length;
/*     */   }
/*     */   public final int position() {
/*  63 */     return this.position;
/*     */   }
/*     */   
/*     */   public final void position(int paramInt) throws IndexOutOfBoundsException {
/*  67 */     if (0 > this.position || this.position >= this.buffer.length) {
/*  68 */       throw new IndexOutOfBoundsException("Invalid new position " + paramInt + ", " + toString());
/*     */     }
/*  70 */     this.position = paramInt;
/*     */   }
/*     */   
/*     */   public final int remaining() {
/*  74 */     return this.buffer.length - this.position;
/*     */   }
/*     */   public final int getGrowSize() {
/*  77 */     return this.growSize;
/*     */   }
/*     */   public final void setGrowSize(int paramInt) {
/*  80 */     this.growSize = paramInt;
/*     */   }
/*     */   
/*     */   public final String toString() {
/*  84 */     return "IntegerStack[0..(pos " + this.position + ").." + this.buffer.length + ", remaining " + remaining() + "]";
/*     */   }
/*     */   public final int[] buffer() {
/*  87 */     return this.buffer;
/*     */   }
/*     */   private final void growIfNecessary(int paramInt) throws IndexOutOfBoundsException {
/*  90 */     if (this.position + paramInt > this.buffer.length) {
/*  91 */       if (0 >= this.growSize) {
/*  92 */         throw new IndexOutOfBoundsException("Out of fixed stack size: " + this);
/*     */       }
/*  94 */       int[] arrayOfInt = new int[this.buffer.length + this.growSize];
/*     */       
/*  96 */       System.arraycopy(this.buffer, 0, arrayOfInt, 0, this.position);
/*  97 */       this.buffer = arrayOfInt;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int[] putOnTop(int[] paramArrayOfint, int paramInt1, int paramInt2) throws IndexOutOfBoundsException {
/* 112 */     growIfNecessary(paramInt2);
/* 113 */     System.arraycopy(paramArrayOfint, paramInt1, this.buffer, this.position, paramInt2);
/* 114 */     this.position += paramInt2;
/* 115 */     return paramArrayOfint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IntBuffer putOnTop(IntBuffer paramIntBuffer, int paramInt) throws IndexOutOfBoundsException, BufferUnderflowException {
/* 129 */     growIfNecessary(paramInt);
/* 130 */     paramIntBuffer.get(this.buffer, this.position, paramInt);
/* 131 */     this.position += paramInt;
/* 132 */     return paramIntBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int[] getFromTop(int[] paramArrayOfint, int paramInt1, int paramInt2) throws IndexOutOfBoundsException {
/* 146 */     System.arraycopy(this.buffer, this.position - paramInt2, paramArrayOfint, paramInt1, paramInt2);
/* 147 */     this.position -= paramInt2;
/* 148 */     return paramArrayOfint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IntBuffer getFromTop(IntBuffer paramIntBuffer, int paramInt) throws IndexOutOfBoundsException, BufferOverflowException {
/* 162 */     paramIntBuffer.put(this.buffer, this.position - paramInt, paramInt);
/* 163 */     this.position -= paramInt;
/* 164 */     return paramIntBuffer;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/IntegerStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */