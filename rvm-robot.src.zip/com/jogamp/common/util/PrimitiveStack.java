package com.jogamp.common.util;

public interface PrimitiveStack {
  int capacity();
  
  int position();
  
  void position(int paramInt) throws IndexOutOfBoundsException;
  
  int remaining();
  
  int getGrowSize();
  
  void setGrowSize(int paramInt);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/PrimitiveStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */