/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayHashMap<K, V>
/*     */   implements Cloneable, Map<K, V>
/*     */ {
/*     */   public static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   public static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   private final HashMap<K, V> map;
/*     */   private final ArrayList<V> data;
/*     */   private final boolean supportNullValue;
/*     */   
/*     */   public ArrayHashMap(boolean paramBoolean, int paramInt, float paramFloat) {
/*  90 */     this.map = new HashMap<>(paramInt, paramFloat);
/*  91 */     this.data = new ArrayList<>(paramInt);
/*  92 */     this.supportNullValue = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayHashMap(ArrayHashMap<K, V> paramArrayHashMap) {
/*  99 */     this.map = new HashMap<>(paramArrayHashMap.map);
/* 100 */     this.data = new ArrayList<>(paramArrayHashMap.data);
/* 101 */     this.supportNullValue = paramArrayHashMap.supportNullValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean supportsNullValue() {
/* 112 */     return this.supportNullValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object clone() {
/* 124 */     return new ArrayHashMap(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ArrayList<V> getData() {
/* 131 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ArrayList<V> toArrayList() {
/* 138 */     return new ArrayList<>(this.data);
/*     */   }
/*     */   
/*     */   public final HashMap<K, V> getMap() {
/* 142 */     return this.map;
/*     */   }
/*     */   public final String toString() {
/* 145 */     return this.data.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void clear() {
/* 153 */     this.data.clear();
/* 154 */     this.map.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 159 */     return this.map.keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 172 */     return this.map.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 177 */     return this.map.entrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public final V get(Object paramObject) {
/* 182 */     return this.map.get(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V put(K paramK, V paramV) throws NullPointerException {
/*     */     V v;
/* 196 */     if (this.supportNullValue) {
/*     */       
/* 198 */       boolean bool = this.map.containsKey(paramK);
/* 199 */       if (!bool) {
/*     */         V v1;
/* 201 */         if (null != (v1 = this.map.put(paramK, paramV)))
/*     */         {
/* 203 */           throw new InternalError("Already existing, but checked before: " + paramK + " -> " + v1);
/*     */         }
/*     */       } else {
/*     */         
/* 207 */         V v1 = this.map.put(paramK, paramV);
/* 208 */         if (!this.data.remove(v1)) {
/* 209 */           throw new InternalError("Already existing, but not in list: " + v1);
/*     */         }
/*     */       } 
/*     */     } else {
/* 213 */       checkNullValue(paramV);
/*     */       
/* 215 */       if (null != (v = this.map.put(paramK, paramV)))
/*     */       {
/* 217 */         if (!this.data.remove(v)) {
/* 218 */           throw new InternalError("Already existing, but not in list: " + v);
/*     */         }
/*     */       }
/*     */     } 
/* 222 */     if (!this.data.add(paramV)) {
/* 223 */       throw new InternalError("Couldn't add value to list: " + paramV);
/*     */     }
/* 225 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> paramMap) {
/* 230 */     for (Map.Entry<? extends K, ? extends V> entry : paramMap.entrySet())
/*     */     {
/* 232 */       put((K)entry.getKey(), (V)entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V remove(Object paramObject) {
/* 245 */     if (this.supportNullValue) {
/* 246 */       if (this.map.containsKey(paramObject)) {
/*     */         
/* 248 */         V v = this.map.remove(paramObject);
/* 249 */         if (!this.data.remove(v)) {
/* 250 */           throw new InternalError("Couldn't remove prev mapped pair: " + paramObject + " -> " + v);
/*     */         }
/* 252 */         return v;
/*     */       } 
/*     */     } else {
/*     */       V v;
/* 256 */       if (null != (v = this.map.remove(paramObject)))
/*     */       {
/* 258 */         if (!this.data.remove(v)) {
/* 259 */           throw new InternalError("Couldn't remove prev mapped pair: " + paramObject + " -> " + v);
/*     */         }
/*     */       }
/* 262 */       return v;
/*     */     } 
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean containsKey(Object paramObject) {
/* 269 */     return this.map.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object paramObject) {
/* 274 */     return this.map.containsValue(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 279 */     if (!(paramObject instanceof ArrayHashMap)) {
/* 280 */       return false;
/*     */     }
/* 282 */     return this.map.equals(((ArrayHashMap)paramObject).map);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 287 */     return this.map.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isEmpty() {
/* 292 */     return this.data.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int size() {
/* 297 */     return this.data.size();
/*     */   }
/*     */   
/*     */   private static final void checkNullValue(Object paramObject) throws NullPointerException {
/* 301 */     if (null == paramObject)
/* 302 */       throw new NullPointerException("Null value not supported"); 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/ArrayHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */