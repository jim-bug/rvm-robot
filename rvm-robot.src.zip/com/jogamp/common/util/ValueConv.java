/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValueConv
/*     */ {
/*     */   public static final byte float_to_byte(float paramFloat, boolean paramBoolean) {
/*  42 */     if (paramBoolean) {
/*  43 */       return (byte)(int)(paramFloat * ((paramFloat > 0.0F) ? 127.0F : 128.0F));
/*     */     }
/*  45 */     return (byte)(int)(paramFloat * 255.0F);
/*     */   }
/*     */   
/*     */   public static final short float_to_short(float paramFloat, boolean paramBoolean) {
/*  49 */     if (paramBoolean) {
/*  50 */       return (short)(int)(paramFloat * ((paramFloat > 0.0F) ? 32767.0F : 32768.0F));
/*     */     }
/*  52 */     return (short)(int)(paramFloat * 65535.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int float_to_int(float paramFloat, boolean paramBoolean) {
/*  60 */     if (paramBoolean) {
/*  61 */       return (int)(paramFloat * ((paramFloat > 0.0F) ? 2.147483647E9D : 2.147483648E9D));
/*     */     }
/*  63 */     return (int)(long)(paramFloat * 4.294967295E9D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte double_to_byte(double paramDouble, boolean paramBoolean) {
/*  69 */     if (paramBoolean) {
/*  70 */       return (byte)(int)(paramDouble * ((paramDouble > 0.0D) ? 127.0D : 128.0D));
/*     */     }
/*  72 */     return (byte)(int)(paramDouble * 255.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final short double_to_short(double paramDouble, boolean paramBoolean) {
/*  77 */     if (paramBoolean) {
/*  78 */       return (short)(int)(paramDouble * ((paramDouble > 0.0D) ? 32767.0D : 32768.0D));
/*     */     }
/*  80 */     return (short)(int)(paramDouble * 65535.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int double_to_int(double paramDouble, boolean paramBoolean) {
/*  85 */     if (paramBoolean) {
/*  86 */       return (int)(paramDouble * ((paramDouble > 0.0D) ? 2.147483647E9D : 2.147483648E9D));
/*     */     }
/*  88 */     return (int)(long)(paramDouble * 4.294967295E9D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final float byte_to_float(byte paramByte, boolean paramBoolean) {
/*  93 */     if (paramBoolean) {
/*  94 */       return (paramByte & 0xFF) / ((paramByte > 0) ? 127.0F : -128.0F);
/*     */     }
/*  96 */     return (paramByte & 0xFF) / 255.0F;
/*     */   }
/*     */   
/*     */   public static final double byte_to_double(byte paramByte, boolean paramBoolean) {
/* 100 */     if (paramBoolean) {
/* 101 */       return (paramByte & 0xFF) / ((paramByte > 0) ? 127.0D : -128.0D);
/*     */     }
/* 103 */     return (paramByte & 0xFF) / 255.0D;
/*     */   }
/*     */   
/*     */   public static final float short_to_float(short paramShort, boolean paramBoolean) {
/* 107 */     if (paramBoolean) {
/* 108 */       return (paramShort & 0xFFFF) / ((paramShort > 0) ? 32767.0F : -32768.0F);
/*     */     }
/* 110 */     return (paramShort & 0xFFFF) / 65535.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double short_to_double(short paramShort, boolean paramBoolean) {
/* 115 */     if (paramBoolean) {
/* 116 */       return (paramShort & 0xFFFF) / ((paramShort > 0) ? 32767.0D : -32768.0D);
/*     */     }
/* 118 */     return (paramShort & 0xFFFF) / 65535.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final float int_to_float(int paramInt, boolean paramBoolean) {
/* 127 */     if (paramBoolean) {
/* 128 */       return (float)(paramInt / ((paramInt > 0) ? 2.147483647E9D : 2.147483648E9D));
/*     */     }
/* 130 */     return (float)((paramInt & 0xFFFFFFFFL) / 4.294967295E9D);
/*     */   }
/*     */   
/*     */   public static final double int_to_double(int paramInt, boolean paramBoolean) {
/* 134 */     if (paramBoolean) {
/* 135 */       return paramInt / ((paramInt > 0) ? 2.147483647E9D : 2.147483648E9D);
/*     */     }
/* 137 */     return (paramInt & 0xFFFFFFFFL) / 4.294967295E9D;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final short byte_to_short(byte paramByte, boolean paramBoolean1, boolean paramBoolean2) {
/* 142 */     return float_to_short(byte_to_float(paramByte, paramBoolean1), paramBoolean2);
/*     */   }
/*     */   public static final int byte_to_int(byte paramByte, boolean paramBoolean1, boolean paramBoolean2) {
/* 145 */     return float_to_int(byte_to_float(paramByte, paramBoolean1), paramBoolean2);
/*     */   }
/*     */   
/*     */   public static final byte short_to_byte(short paramShort, boolean paramBoolean1, boolean paramBoolean2) {
/* 149 */     return float_to_byte(short_to_float(paramShort, paramBoolean1), paramBoolean2);
/*     */   }
/*     */   public static final int short_to_int(short paramShort, boolean paramBoolean1, boolean paramBoolean2) {
/* 152 */     return float_to_int(short_to_float(paramShort, paramBoolean1), paramBoolean2);
/*     */   }
/*     */   
/*     */   public static final byte int_to_byte(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/* 156 */     return float_to_byte(int_to_float(paramInt, paramBoolean1), paramBoolean2);
/*     */   }
/*     */   public static final short int_to_short(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/* 159 */     return float_to_short(int_to_float(paramInt, paramBoolean1), paramBoolean2);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/ValueConv.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */