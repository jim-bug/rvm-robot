/*      */ package com.jogamp.common.util;
/*      */ 
/*      */ import com.jogamp.common.ExceptionUtils;
/*      */ import com.jogamp.common.JogampRuntimeException;
/*      */ import com.jogamp.common.net.AssetURLContext;
/*      */ import com.jogamp.common.net.Uri;
/*      */ import com.jogamp.common.nio.Buffers;
/*      */ import com.jogamp.common.os.MachineDataInfo;
/*      */ import com.jogamp.common.os.Platform;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FilePermission;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Reader;
/*      */ import java.io.SyncFailedException;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.regex.Pattern;
/*      */ import jogamp.common.Debug;
/*      */ import jogamp.common.os.AndroidUtils;
/*      */ import jogamp.common.os.PlatformPropsImpl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class IOUtil
/*      */ {
/*      */   public static final boolean DEBUG;
/*      */   private static final boolean DEBUG_EXE;
/*      */   private static final boolean DEBUG_EXE_NOSTREAM;
/*      */   private static final boolean DEBUG_EXE_EXISTING_FILE;
/*      */   private static final boolean testTempDirExec;
/*      */   private static final Method fileToPathGetter;
/*      */   private static final Method isExecutableQuery;
/*      */   private static final boolean useNativeExeFile;
/*      */   private static final String java_io_tmpdir_propkey = "java.io.tmpdir";
/*      */   private static final String user_home_propkey = "user.home";
/*      */   private static final String XDG_CACHE_HOME_envkey = "XDG_CACHE_HOME";
/*      */   public static final String tmpSubDir = "jogamp";
/*      */   private static final Pattern patternSingleBS;
/*      */   public static final Pattern patternSpaceEnc;
/*      */   private static final Object exeTestLock;
/*      */   private static WeakReference<byte[]> exeTestCodeRef;
/*      */   private static File tempRootExec;
/*      */   private static File tempRootNoexec;
/*      */   private static volatile boolean tempRootSet;
/*      */   
/*      */   static {
/*   80 */     final boolean[] _props = { false, false, false, false, false, false };
/*   81 */     Method[] arrayOfMethod = SecurityUtil.<Method[]>doPrivileged((PrivilegedAction)new PrivilegedAction<Method[]>()
/*      */         {
/*      */           public Method[] run() {
/*   84 */             Method[] arrayOfMethod = { null, null };
/*      */             try {
/*   86 */               byte b = 0;
/*   87 */               _props[b++] = Debug.debug("IOUtil");
/*   88 */               _props[b++] = PropertyAccess.isPropertyDefined("jogamp.debug.IOUtil.Exe", true);
/*   89 */               _props[b++] = PropertyAccess.isPropertyDefined("jogamp.debug.IOUtil.Exe.NoStream", true);
/*      */               
/*   91 */               _props[b++] = false;
/*   92 */               _props[b++] = PropertyAccess.getBooleanProperty("jogamp.gluegen.TestTempDirExec", true, true);
/*   93 */               _props[b++] = PropertyAccess.getBooleanProperty("jogamp.gluegen.UseNativeExeFile", true, false);
/*      */ 
/*      */               
/*   96 */               b = 0;
/*   97 */               arrayOfMethod[b] = File.class.getDeclaredMethod("toPath", new Class[0]);
/*   98 */               arrayOfMethod[b++].setAccessible(true);
/*   99 */               Class<?> clazz1 = ReflectionUtil.getClass("java.nio.file.Path", false, IOUtil.class.getClassLoader());
/*  100 */               Class<?> clazz2 = ReflectionUtil.getClass("java.nio.file.Files", false, IOUtil.class.getClassLoader());
/*  101 */               arrayOfMethod[b] = clazz2.getDeclaredMethod("isExecutable", new Class[] { clazz1 });
/*  102 */               arrayOfMethod[b++].setAccessible(true);
/*  103 */             } catch (Throwable throwable) {
/*  104 */               if (_props[0]) {
/*  105 */                 ExceptionUtils.dumpThrowable("ioutil-init", throwable);
/*      */               }
/*      */             } 
/*  108 */             return arrayOfMethod;
/*      */           }
/*      */         });
/*      */     
/*  112 */     byte b = 0;
/*  113 */     DEBUG = arrayOfBoolean[b++];
/*  114 */     DEBUG_EXE = arrayOfBoolean[b++];
/*  115 */     DEBUG_EXE_NOSTREAM = arrayOfBoolean[b++];
/*  116 */     DEBUG_EXE_EXISTING_FILE = arrayOfBoolean[b++];
/*  117 */     testTempDirExec = arrayOfBoolean[b++];
/*  118 */     useNativeExeFile = arrayOfBoolean[b++];
/*      */     
/*  120 */     b = 0;
/*  121 */     fileToPathGetter = arrayOfMethod[b++];
/*  122 */     isExecutableQuery = arrayOfMethod[b++];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  379 */     patternSingleBS = Pattern.compile("\\\\{1}");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  735 */     patternSpaceEnc = Pattern.compile("%20");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  823 */     exeTestLock = new Object();
/*  824 */     exeTestCodeRef = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1368 */     tempRootExec = null;
/* 1369 */     tempRootNoexec = null;
/* 1370 */     tempRootSet = false;
/*      */   }
/*      */   private static final Constructor<?> getFOSCtor() { Constructor constructor; Throwable throwable; try { constructor = ReflectionUtil.getConstructor("java.io.FileOutputStream", new Class[] { File.class }, true, IOUtil.class.getClassLoader()); throwable = null; } catch (Throwable throwable1) { constructor = null; throwable = throwable1; }  if (DEBUG) { System.err.println("IOUtil: java.io.FileOutputStream available: " + ((null != constructor) ? 1 : 0)); if (null != throwable) throwable.printStackTrace();  }  return constructor; }
/*      */   public static int copyURLConn2File(URLConnection paramURLConnection, File paramFile) throws IOException { paramURLConnection.connect(); int i = 0; BufferedInputStream bufferedInputStream = new BufferedInputStream(paramURLConnection.getInputStream()); try { i = copyStream2File(bufferedInputStream, paramFile); } finally { bufferedInputStream.close(); }  return i; }
/*      */   public static int copyStream2File(InputStream paramInputStream, File paramFile) throws IOException { BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramFile)); try { return copyStream2Stream(paramInputStream, bufferedOutputStream); } finally { bufferedOutputStream.close(); }  }
/*      */   public static int copyStream2Stream(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException { return copyStream2Stream(Platform.getMachineDataInfo().pageSizeInBytes(), paramInputStream, paramOutputStream); }
/*      */   public static int copyStream2Stream(int paramInt, InputStream paramInputStream, OutputStream paramOutputStream) throws IOException { byte[] arrayOfByte = new byte[paramInt]; int i = 0; int j; while ((j = paramInputStream.read(arrayOfByte)) != -1) { paramOutputStream.write(arrayOfByte, 0, j); i += j; }  return i; }
/*      */   public static StringBuilder appendCharStream(StringBuilder paramStringBuilder, Reader paramReader) throws IOException { char[] arrayOfChar = new char[1024]; int i; while (0 < (i = paramReader.read(arrayOfChar))) paramStringBuilder.append(arrayOfChar, 0, i);  return paramStringBuilder; }
/*      */   public static byte[] copyStream2ByteArray(InputStream paramInputStream) throws IOException { if (!(paramInputStream instanceof BufferedInputStream)) paramInputStream = new BufferedInputStream(paramInputStream);  int i = 0; int j = paramInputStream.available(); byte[] arrayOfByte = new byte[j]; int k = 0; do { if (i + j > arrayOfByte.length) { byte[] arrayOfByte1 = new byte[i + j]; System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i); arrayOfByte = arrayOfByte1; }  k = paramInputStream.read(arrayOfByte, i, j); if (k >= 0) i += k;  j = paramInputStream.available(); } while (j > 0 && k >= 0); if (i != arrayOfByte.length) { byte[] arrayOfByte1 = new byte[i]; System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i); arrayOfByte = arrayOfByte1; }  return arrayOfByte; }
/*      */   public static ByteBuffer copyStream2ByteBuffer(InputStream paramInputStream) throws IOException { return copyStream2ByteBuffer(paramInputStream, -1); }
/*      */   public static ByteBuffer copyStream2ByteBuffer(InputStream paramInputStream, int paramInt) throws IOException { if (!(paramInputStream instanceof BufferedInputStream)) paramInputStream = new BufferedInputStream(paramInputStream);  int i = paramInputStream.available(); if (paramInt < i) paramInt = i;  MachineDataInfo machineDataInfo = Platform.getMachineDataInfo(); ByteBuffer byteBuffer = Buffers.newDirectByteBuffer(machineDataInfo.pageAlignedSize(paramInt)); byte[] arrayOfByte = new byte[machineDataInfo.pageSizeInBytes()]; int j = Math.min(machineDataInfo.pageSizeInBytes(), i); int k = 0; do { if (i > byteBuffer.remaining()) { ByteBuffer byteBuffer1 = Buffers.newDirectByteBuffer(machineDataInfo.pageAlignedSize(byteBuffer.position() + i)); byteBuffer1.put(byteBuffer); byteBuffer = byteBuffer1; }  k = paramInputStream.read(arrayOfByte, 0, j); if (k > 0) byteBuffer.put(arrayOfByte, 0, k);  i = paramInputStream.available(); j = Math.min(machineDataInfo.pageSizeInBytes(), i); } while (k > 0); byteBuffer.flip(); return byteBuffer; }
/*      */   public static ByteBuffer copyStreamChunk2ByteBuffer(InputStream paramInputStream, int paramInt1, int paramInt2) throws IOException { if (!(paramInputStream instanceof BufferedInputStream)) paramInputStream = new BufferedInputStream(paramInputStream);  MachineDataInfo machineDataInfo = Platform.getMachineDataInfo(); ByteBuffer byteBuffer = Buffers.newDirectByteBuffer(machineDataInfo.pageAlignedSize(paramInt2)); byte[] arrayOfByte = new byte[machineDataInfo.pageSizeInBytes()]; int i = 1; while (i && paramInt1 > 0) { int j = Math.min(machineDataInfo.pageSizeInBytes(), paramInt1); i = paramInputStream.read(arrayOfByte, 0, j); paramInt1 -= i; }  while (i > 0 && paramInt2 > 0) { int j = Math.min(machineDataInfo.pageSizeInBytes(), paramInt2); i = paramInputStream.read(arrayOfByte, 0, j); if (i > 0) byteBuffer.put(arrayOfByte, 0, i);  paramInt2 -= i; }  byteBuffer.flip(); return byteBuffer; }
/*      */   public static String slashify(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws URISyntaxException { String str = patternSingleBS.matcher(paramString).replaceAll("/"); if (paramBoolean1 && !str.startsWith("/")) str = "/" + str;  if (paramBoolean2 && !str.endsWith("/")) str = str + "/";  return cleanPathString(str); }
/*      */   public static String getFileSuffix(File paramFile) { return getFileSuffix(paramFile.getName()); }
/*      */   public static String getFileSuffix(String paramString) { int i = paramString.lastIndexOf('.'); if (i < 0) return null;  return toLowerCase(paramString.substring(i + 1)); }
/*      */   private static String toLowerCase(String paramString) { if (paramString == null) return null;  return paramString.toLowerCase(); }
/*      */   public static FileOutputStream getFileOutputStream(File paramFile, boolean paramBoolean) throws IOException { Constructor<?> constructor = getFOSCtor(); if (null == constructor) throw new IOException("Cannot open file (" + paramFile + ") for writing, FileOutputStream feature not available.");  if (paramFile.exists() && !paramBoolean) throw new IOException("File already exists (" + paramFile + ") and overwrite=false");  try { return (FileOutputStream)constructor.newInstance(new Object[] { paramFile }); } catch (Exception exception) { throw new IOException("error opening " + paramFile + " for write. ", exception); }  }
/*      */   public static String getClassFileName(String paramString) { return paramString.replace('.', '/') + ".class"; }
/*      */   public static URL getClassURL(String paramString, ClassLoader paramClassLoader) throws IOException { URL uRL = paramClassLoader.getResource(getClassFileName(paramString)); if (null == uRL) throw new IOException("Cannot not find: " + paramString);  return uRL; }
/*      */   public static String getBasename(String paramString) throws URISyntaxException { paramString = slashify(paramString, false, false); int i = paramString.lastIndexOf('/'); if (i >= 0) paramString = paramString.substring(i + 1);  return paramString; }
/*      */   public static String getDirname(String paramString) throws URISyntaxException { paramString = slashify(paramString, false, false); int i = paramString.lastIndexOf('/'); if (i >= 0) paramString = paramString.substring(0, i + 1);  return paramString; }
/*      */   public static class ClassResources {
/* 1392 */     public final ClassLoader classLoader; public final Class<?> contextCL; public final String[] resourcePaths; public final int resourceCount() { return this.resourcePaths.length; } public ClassResources(String[] param1ArrayOfString, ClassLoader param1ClassLoader, Class<?> param1Class) { for (int i = param1ArrayOfString.length - 1; i >= 0; i--) { if (null == param1ArrayOfString[i]) throw new IllegalArgumentException("resourcePath[" + i + "] is null");  }  this.classLoader = param1ClassLoader; this.contextCL = param1Class; this.resourcePaths = param1ArrayOfString; } public URLConnection resolve(int param1Int) throws ArrayIndexOutOfBoundsException { return IOUtil.getResource(this.resourcePaths[param1Int], this.classLoader, this.contextCL); } } public static URLConnection getResource(String paramString, ClassLoader paramClassLoader, Class<?> paramClass) { if (null == paramString) return null;  URLConnection uRLConnection = null; if (null != paramClass) { String str = paramClass.getName().replace('.', '/'); int i = str.lastIndexOf('/'); if (i >= 0) { String str1 = str.substring(0, i + 1); uRLConnection = getResource(str1 + paramString, paramClassLoader); if (DEBUG) System.err.println("IOUtil: found <" + paramString + "> within class package <" + str1 + "> of given class <" + paramClass.getName() + ">: " + ((null != uRLConnection) ? 1 : 0));  }  } else if (DEBUG) { System.err.println("IOUtil: null context, skip rel. lookup"); }  if (null == uRLConnection) { uRLConnection = getResource(paramString, paramClassLoader); if (DEBUG) System.err.println("IOUtil: found <" + paramString + "> by classloader: " + ((null != uRLConnection) ? 1 : 0));  }  return uRLConnection; } public static URLConnection getResource(String paramString, ClassLoader paramClassLoader) { if (null == paramString) return null;  if (DEBUG) System.err.println("IOUtil: locating <" + paramString + ">, has cl: " + ((null != paramClassLoader) ? 1 : 0));  if (paramString.startsWith("asset:")) try { return AssetURLContext.createURL(paramString, paramClassLoader).openConnection(); } catch (IOException iOException) { if (DEBUG) ExceptionUtils.dumpThrowable("IOUtil", iOException);  return null; }   try { return AssetURLContext.resolve(paramString, paramClassLoader); } catch (IOException iOException) { if (DEBUG) ExceptionUtils.dumpThrowable("IOUtil", iOException);  return null; }  } public static File createTempFile(String paramString1, String paramString2, boolean paramBoolean) throws IllegalArgumentException, IOException, SecurityException { return File.createTempFile(paramString1, paramString2, getTempDir(paramBoolean)); }
/*      */   public static String getRelativeOf(File paramFile, String paramString) throws URISyntaxException { if (null == paramString) return null;  if (paramFile != null) { File file = new File(paramFile, paramString); return slashify(file.getPath(), false, false); }  return null; }
/*      */   public static String getParentOf(String paramString) throws URISyntaxException { byte b = (null != paramString) ? paramString.length() : 0; if (!b) throw new IllegalArgumentException("path is empty <" + paramString + ">");  int i = paramString.lastIndexOf("/"); if (i < 0) throw new URISyntaxException(paramString, "path contains no '/': <" + paramString + ">");  if (i == 0) throw new URISyntaxException(paramString, "path has no parents: <" + paramString + ">");  if (i < b - 1) return paramString.substring(0, i + 1);  int j = paramString.lastIndexOf("!") + 1; int k = paramString.lastIndexOf("/", i - 1); if (k >= j) return paramString.substring(0, k + 1);  String str = paramString.substring(j, i); if (str.equals("..")) throw new URISyntaxException(paramString, "parent is unresolved: <" + paramString + ">");  return paramString.substring(0, j); }
/*      */   public static String cleanPathString(String paramString) throws URISyntaxException { int i = paramString.length() - 1; while (i >= 1 && (i = paramString.lastIndexOf("./", i)) >= 0) { if (0 < i && paramString.charAt(i - 1) == '.') { i -= 2; continue; }  paramString = paramString.substring(0, i) + paramString.substring(i + 2); i--; }  i = 0; while ((i = paramString.indexOf("../", i)) >= 0) { if (0 == i) { i += 3; continue; }  paramString = getParentOf(paramString.substring(0, i)) + paramString.substring(i + 3); i = 0; }  return paramString; } public static String getUriFilePathOrASCII(Uri paramUri) { if (paramUri.isFileScheme()) return paramUri.toFile().getPath();  return paramUri.toASCIIString().get(); } public static URLConnection openURL(URL paramURL) { return openURL(paramURL, "."); } public static URLConnection openURL(URL paramURL, String paramString) { if (null != paramURL) { try { URLConnection uRLConnection = paramURL.openConnection(); uRLConnection.connect(); if (DEBUG) System.err.println("IOUtil: urlExists(" + paramURL + ") [" + paramString + "] - true");  return uRLConnection; } catch (IOException iOException) { if (DEBUG) ExceptionUtils.dumpThrowable("IOUtil: urlExists(" + paramURL + ") [" + paramString + "] - false -", iOException);  }  } else if (DEBUG) { System.err.println("IOUtil: no url - urlExists(null) [" + paramString + "]"); }  return null; } private static String getExeTestFileSuffix() { switch (PlatformPropsImpl.OS_TYPE) { case WINDOWS: if (useNativeExeFile && Platform.CPUFamily.X86 == PlatformPropsImpl.CPU_ARCH.family) return ".exe";  return ".bat"; }  return ".sh"; } private static String getExeTestShellCode() { switch (PlatformPropsImpl.OS_TYPE) { case WINDOWS: return "echo off" + PlatformPropsImpl.NEWLINE; }  return "#!/bin/true" + PlatformPropsImpl.NEWLINE; } private static String[] getExeTestCommandArgs(String paramString) { switch (PlatformPropsImpl.OS_TYPE) {  }  return new String[] { paramString }; } private static final byte[] readCode(String paramString) throws IOException { URLConnection uRLConnection = getResource(paramString, IOUtil.class.getClassLoader(), IOUtil.class); InputStream inputStream = uRLConnection.getInputStream(); byte[] arrayOfByte = null; try { arrayOfByte = CustomCompress.inflateFromStream(inputStream); } finally { inputStream.close(); }  return arrayOfByte; } private static void fillExeTestFile(File paramFile) throws IOException { if (useNativeExeFile && Platform.OSType.WINDOWS == PlatformPropsImpl.OS_TYPE && Platform.CPUFamily.X86 == PlatformPropsImpl.CPU_ARCH.family) { byte[] arrayOfByte; synchronized (exeTestLock) { byte[] arrayOfByte1 = null; if (null == exeTestCodeRef || null == (arrayOfByte1 = exeTestCodeRef.get())) { String str; if (Platform.CPUType.X86_64 == PlatformPropsImpl.CPU_ARCH) { str = "bin/exe-windows-x86_64.defl"; } else { str = "bin/exe-windows-i386.defl"; }  arrayOfByte = readCode(str); exeTestCodeRef = (WeakReference)new WeakReference<>(arrayOfByte); } else { arrayOfByte = arrayOfByte1; }  }  FileOutputStream fileOutputStream = new FileOutputStream(paramFile); try { fileOutputStream.write(arrayOfByte, 0, arrayOfByte.length); try { fileOutputStream.getFD().sync(); } catch (SyncFailedException syncFailedException) { ExceptionUtils.dumpThrowable("", syncFailedException); }  } finally { fileOutputStream.close(); }  } else { String str = getExeTestShellCode(); if (isStringSet(str)) { FileWriter fileWriter = new FileWriter(paramFile); try { fileWriter.write(str); try { fileWriter.flush(); } catch (IOException iOException) { ExceptionUtils.dumpThrowable("", iOException); }  } finally { fileWriter.close(); }  }  }  } private static boolean getOSHasNoexecFS() { switch (PlatformPropsImpl.OS_TYPE) { case OPENKODE: return false; }  return true; } private static boolean getOSHasFreeDesktopXDG() { switch (PlatformPropsImpl.OS_TYPE) { case WINDOWS: case OPENKODE: case ANDROID: case MACOS: case IOS: return false; }  return true; } public static boolean testFile(File paramFile, boolean paramBoolean1, boolean paramBoolean2) { if (!paramFile.exists()) { if (DEBUG) System.err.println("IOUtil.testFile: <" + paramFile.getAbsolutePath() + ">: does not exist");  return false; }  if (paramBoolean1 && !paramFile.isDirectory()) { if (DEBUG) System.err.println("IOUtil.testFile: <" + paramFile.getAbsolutePath() + ">: is not a directory");  return false; }  if (paramBoolean2 && !paramFile.canWrite()) { if (DEBUG) System.err.println("IOUtil.testFile: <" + paramFile.getAbsolutePath() + ">: is not writable");  return false; }  return true; } public static class StreamMonitor implements Runnable {
/* 1396 */     private final InputStream[] istreams; private final boolean[] eos; private final PrintStream ostream; private final String prefix; public StreamMonitor(InputStream[] param1ArrayOfInputStream, PrintStream param1PrintStream, String param1String) { this.istreams = param1ArrayOfInputStream; this.eos = new boolean[param1ArrayOfInputStream.length]; this.ostream = param1PrintStream; this.prefix = param1String; InterruptSource.Thread thread = new InterruptSource.Thread(null, this, "StreamMonitor-" + Thread.currentThread().getName()); thread.setDaemon(true); thread.start(); } public void run() { byte[] arrayOfByte = new byte[4096]; try { int i = this.istreams.length; byte b = 0; do { for (byte b1 = 0; b1 < this.istreams.length; b1++) { if (!this.eos[b1]) { int j = this.istreams[b1].read(arrayOfByte); if (j > 0) { if (null != this.ostream) { if (null != this.prefix) this.ostream.write(this.prefix.getBytes());  this.ostream.write(arrayOfByte, 0, j); }  } else { b++; this.eos[b1] = true; }  }  }  if (null == this.ostream) continue;  this.ostream.flush(); } while (b < i); } catch (IOException iOException) {  } finally { if (null != this.ostream) this.ostream.flush();  }  } } private static final Boolean isNioExecutableFile(File paramFile) { if (null != fileToPathGetter && null != isExecutableQuery) try { return (Boolean)isExecutableQuery.invoke(null, new Object[] { fileToPathGetter.invoke(paramFile, new Object[0]) }); } catch (Throwable throwable) { throw new JogampRuntimeException("error invoking Files.isExecutable(file.toPath())", throwable); }   return null; } public static boolean testDirExec(File paramFile) throws SecurityException { File file; boolean bool2; long l3; boolean bool1 = (DEBUG_EXE || DEBUG) ? true : false; if (!testTempDirExec) { if (DEBUG) System.err.println("IOUtil.testDirExec: <" + paramFile.getAbsolutePath() + ">: Disabled TestTempDirExec");  return false; }  if (!testFile(paramFile, true, true)) { if (bool1) System.err.println("IOUtil.testDirExec: <" + paramFile.getAbsolutePath() + ">: Not writeable dir");  return false; }  if (!getOSHasNoexecFS()) { if (bool1) System.err.println("IOUtil.testDirExec: <" + paramFile.getAbsolutePath() + ">: Always executable");  return true; }  long l1 = bool1 ? System.currentTimeMillis() : 0L; try { File file1 = DEBUG_EXE_EXISTING_FILE ? new File(paramFile, "jogamp_exe_tst" + getExeTestFileSuffix()) : null; if (null != file1 && file1.exists()) { file = file1; bool2 = true; } else { file = File.createTempFile("jogamp_exe_tst", getExeTestFileSuffix(), paramFile); bool2 = false; fillExeTestFile(file); }  } catch (SecurityException securityException) { throw securityException; } catch (IOException iOException) { if (bool1) iOException.printStackTrace();  return false; }  long l2 = bool1 ? System.currentTimeMillis() : 0L; byte b = -1; int i = -1; Boolean bool = null; if (bool2 || file.setExecutable(true, true)) { l3 = bool1 ? System.currentTimeMillis() : 0L; bool = isNioExecutableFile(file); if (null != bool) b = bool.booleanValue() ? 0 : -1;  if (null == bool || 0 <= b) { Process process = null; try { process = Runtime.getRuntime().exec(getExeTestCommandArgs(file.getCanonicalPath()), (String[])null, (File)null); if (DEBUG_EXE && !DEBUG_EXE_NOSTREAM) new StreamMonitor(new InputStream[] { process.getInputStream(), process.getErrorStream() }, System.err, "Exe-Tst: ");  process.waitFor(); i = process.exitValue(); if (0 == i) { b++; } else { b = -2; }  } catch (SecurityException securityException) { throw securityException; } catch (Throwable throwable) { l3 = bool1 ? System.currentTimeMillis() : 0L; b = -3; if (bool1) { System.err.println("IOUtil.testDirExec: <" + file.getAbsolutePath() + ">: Caught " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage()); throwable.printStackTrace(); }  } finally { if (null != process) try { process.destroy(); } catch (Throwable throwable) { ExceptionUtils.dumpThrowable("", throwable); }   }  }  } else { l3 = bool1 ? System.currentTimeMillis() : 0L; }  boolean bool3 = (0 <= b) ? true : false; if (!DEBUG_EXE && !bool2) file.delete();  if (bool1) { long l = System.currentTimeMillis(); System.err.println("IOUtil.testDirExec(): test-exe <" + file.getAbsolutePath() + ">, existingFile " + bool2 + ", isNioExec " + bool + ", returned " + i); System.err.println("IOUtil.testDirExec(): abs-path <" + paramFile.getAbsolutePath() + ">: res " + b + " -> " + bool3); System.err.println("IOUtil.testDirExec(): total " + (l - l1) + "ms, create " + (l2 - l1) + "ms, fill " + (l3 - l2) + "ms, execute " + (l - l3) + "ms"); }  return bool3; } private static File testDirImpl(File paramFile, boolean paramBoolean1, boolean paramBoolean2, String paramString) throws SecurityException { File file; if (paramBoolean1 && !paramFile.exists()) paramFile.mkdirs();  if (paramBoolean2) { file = testDirExec(paramFile) ? paramFile : null; } else { file = testFile(paramFile, true, true) ? paramFile : null; }  if (DEBUG) System.err.println("IOUtil.testDirImpl(" + paramString + "): <" + paramFile.getAbsolutePath() + ">, create " + paramBoolean1 + ", exec " + paramBoolean2 + ": " + ((null != file) ? 1 : 0));  return file; } public static File testDir(File paramFile, boolean paramBoolean1, boolean paramBoolean2) throws SecurityException { return testDirImpl(paramFile, paramBoolean1, paramBoolean2, "testDir"); } private static boolean isStringSet(String paramString) { return (null != paramString && 0 < paramString.length()); } private static File getSubTempDir(File paramFile, String paramString1, boolean paramBoolean, String paramString2) throws SecurityException { File file = null; if (null != testDirImpl(paramFile, true, paramBoolean, paramString2)) for (byte b = 0; null == file && b <= '✏'; b++) { String str = String.format((Locale)null, "_%04d", new Object[] { Integer.valueOf(b) }); file = testDirImpl(new File(paramFile, paramString1 + str), true, paramBoolean, paramString2); }   return file; } private static File getFile(String paramString) { if (isStringSet(paramString)) return new File(paramString);  return null; } public static File getTempDir(boolean paramBoolean) throws SecurityException, IOException { if (!tempRootSet) synchronized (IOUtil.class) { if (!tempRootSet) { File file2; String str2; tempRootSet = true; File file1 = AndroidUtils.getTempRoot(); if (null != file1) { tempRootNoexec = getSubTempDir(file1, "jogamp", false, "Android.ctxTemp"); tempRootExec = tempRootNoexec; return tempRootExec; }  file1 = getFile(PropertyAccess.getProperty("java.io.tmpdir", false)); if (DEBUG) System.err.println("IOUtil.getTempRoot(): tempX1 <" + file1 + ">, used " + ((null != file1) ? 1 : 0));  String str1 = System.getenv("TMPDIR"); if (!isStringSet(str1)) str1 = System.getenv("TEMP");  File file4 = getFile(str1); if (null != file4 && !file4.equals(file1)) { file2 = file4; } else { file2 = null; }  if (DEBUG) System.err.println("IOUtil.getTempRoot(): tempX3 <" + file4 + ">, used " + ((null != file2) ? 1 : 0));  File file3 = getFile(PropertyAccess.getProperty("user.home", false)); if (DEBUG) System.err.println("IOUtil.getTempRoot(): tempX4 <" + file3 + ">, used " + ((null != file3) ? 1 : 0));  if (getOSHasFreeDesktopXDG()) { str2 = System.getenv("XDG_CACHE_HOME"); if (!isStringSet(str2) && null != file3) str2 = file3.getAbsolutePath() + File.separator + ".cache";  } else { str2 = null; }  File file5 = getFile(str2); if (null != file5 && !file5.equals(file1)) { file4 = file5; } else { file4 = null; }  if (DEBUG) System.err.println("IOUtil.getTempRoot(): tempX2 <" + file5 + ">, used " + ((null != file4) ? 1 : 0));  if (null == tempRootExec && null != file1) if (Platform.OSType.MACOS == PlatformPropsImpl.OS_TYPE || Platform.OSType.IOS == PlatformPropsImpl.OS_TYPE) { tempRootExec = getSubTempDir(file1, "jogamp", false, "tempX1"); } else { tempRootExec = getSubTempDir(file1, "jogamp", true, "tempX1"); }   if (null == tempRootExec && null != file4) tempRootExec = getSubTempDir(file4, "jogamp", true, "tempX2");  if (null == tempRootExec && null != file2) tempRootExec = getSubTempDir(file2, "jogamp", true, "tempX3");  if (null == tempRootExec && null != file3) tempRootExec = getSubTempDir(file3, ".jogamp", true, "tempX4");  if (null != tempRootExec) { tempRootNoexec = tempRootExec; } else { if (null == tempRootNoexec && null != file1) tempRootNoexec = getSubTempDir(file1, "jogamp", false, "temp01");  if (null == tempRootNoexec && null != file4) tempRootNoexec = getSubTempDir(file4, "jogamp", false, "temp02");  if (null == tempRootNoexec && null != file2) tempRootNoexec = getSubTempDir(file2, "jogamp", false, "temp03");  if (null == tempRootNoexec && null != file3) tempRootNoexec = getSubTempDir(file3, ".jogamp", false, "temp04");  }  if (DEBUG) { str2 = (null != tempRootExec) ? tempRootExec.getAbsolutePath() : null; String str = (null != tempRootNoexec) ? tempRootNoexec.getAbsolutePath() : null; System.err.println("IOUtil.getTempRoot(): temp dirs: exec: " + str2 + ", noexec: " + str); }  }  }   File file = paramBoolean ? tempRootExec : tempRootNoexec; if (null == file) { String str = paramBoolean ? "executable " : ""; throw new IOException("Could not determine a temporary " + str + "directory"); }  FilePermission filePermission = new FilePermission(file.getAbsolutePath(), "read,write,delete"); SecurityUtil.checkPermission(filePermission); return file; } public static void close(Closeable paramCloseable, boolean paramBoolean) throws RuntimeException { if (null != paramCloseable) {
/*      */       try {
/* 1398 */         paramCloseable.close();
/* 1399 */       } catch (IOException iOException) {
/* 1400 */         if (paramBoolean)
/* 1401 */           throw new RuntimeException(iOException); 
/* 1402 */         if (DEBUG) {
/* 1403 */           System.err.println("Caught Exception: ");
/* 1404 */           iOException.printStackTrace();
/*      */         } 
/*      */       } 
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IOException close(Closeable paramCloseable, IOException[] paramArrayOfIOException, PrintStream paramPrintStream) {
/*      */     try {
/* 1420 */       paramCloseable.close();
/* 1421 */     } catch (IOException iOException) {
/* 1422 */       if (null == paramArrayOfIOException[0]) {
/* 1423 */         paramArrayOfIOException[0] = iOException;
/*      */       } else {
/* 1425 */         if (null != paramPrintStream) {
/* 1426 */           paramPrintStream.println("Caught " + iOException.getClass().getSimpleName() + ": " + iOException.getMessage());
/* 1427 */           iOException.printStackTrace(paramPrintStream);
/*      */         } 
/* 1429 */         return iOException;
/*      */       } 
/*      */     } 
/* 1432 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ArrayList<String> filesOf(List<String> paramList, List<Pattern> paramList1, List<Pattern> paramList2) {
/* 1443 */     ArrayList<String> arrayList1 = new ArrayList(paramList.size() * 32);
/* 1444 */     ArrayList<String> arrayList2 = new ArrayList<>(paramList);
/* 1445 */     while (arrayList2.size() > 0) {
/* 1446 */       String str = arrayList2.remove(0);
/* 1447 */       if (null != paramList1 && paramList1.size() > 0) {
/* 1448 */         boolean bool = false;
/* 1449 */         for (byte b = 0; !bool && b < paramList1.size(); b++) {
/* 1450 */           bool = ((Pattern)paramList1.get(b)).matcher(str).matches();
/* 1451 */           if (DEBUG && 
/* 1452 */             bool) {
/* 1453 */             System.err.println("IOUtil.filesOf(): excluding <" + str + "> (exclude[" + b + "]: " + paramList1.get(b) + ")");
/*      */           }
/*      */         } 
/*      */         
/* 1457 */         if (bool) {
/*      */           continue;
/*      */         }
/*      */       } 
/* 1461 */       File file = new File(str);
/* 1462 */       if (!file.exists()) {
/* 1463 */         if (DEBUG)
/* 1464 */           System.err.println("IOUtil.filesOf(): not existing: " + file); 
/*      */         continue;
/*      */       } 
/* 1467 */       if (file.isDirectory()) {
/* 1468 */         String[] arrayOfString = file.list();
/* 1469 */         if (null == arrayOfString) {
/* 1470 */           if (DEBUG)
/* 1471 */             System.err.println("IOUtil.filesOf(): null list of directory: " + file);  continue;
/*      */         } 
/* 1473 */         if (0 == arrayOfString.length) {
/* 1474 */           if (DEBUG)
/* 1475 */             System.err.println("IOUtil.filesOf(): empty list of directory: " + file); 
/*      */           continue;
/*      */         } 
/* 1478 */         byte b1 = 0;
/* 1479 */         String str1 = str.endsWith("/") ? str : (str + "/");
/* 1480 */         for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/* 1481 */           arrayList2.add(b1++, str1 + arrayOfString[b2]);
/*      */         }
/*      */         continue;
/*      */       } 
/* 1485 */       if (null != paramList2 && paramList2.size() > 0) {
/* 1486 */         boolean bool = false;
/* 1487 */         for (byte b = 0; !bool && b < paramList2.size(); b++) {
/* 1488 */           bool = ((Pattern)paramList2.get(b)).matcher(str).matches();
/* 1489 */           if (DEBUG && 
/* 1490 */             bool) {
/* 1491 */             System.err.println("IOUtil.filesOf(): including <" + str + "> (including[" + b + "]: " + paramList2.get(b) + ")");
/*      */           }
/*      */         } 
/*      */         
/* 1495 */         if (bool)
/* 1496 */           arrayList1.add(str); 
/*      */         continue;
/*      */       } 
/* 1499 */       arrayList1.add(str);
/*      */     } 
/*      */ 
/*      */     
/* 1503 */     return arrayList1;
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/IOUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */