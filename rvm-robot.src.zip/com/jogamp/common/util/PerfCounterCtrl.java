package com.jogamp.common.util;

import java.io.PrintStream;

public interface PerfCounterCtrl {
  void enable(boolean paramBoolean);
  
  void clear();
  
  long getTotalDuration();
  
  void print(PrintStream paramPrintStream);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/PerfCounterCtrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */