/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LFRingbuffer<T>
/*     */   implements Ringbuffer<T>
/*     */ {
/*  75 */   private final Object syncRead = new Object();
/*  76 */   private final Object syncWrite = new Object();
/*  77 */   private final Object syncGlobal = new Object();
/*     */   
/*     */   private volatile T[] array;
/*     */   private volatile int capacityPlusOne;
/*     */   private volatile int readPos;
/*     */   private volatile int writePos;
/*     */   private volatile int size;
/*     */   
/*     */   public final String toString() {
/*  86 */     return "LFRingbuffer<?>[filled " + this.size + " / " + (this.capacityPlusOne - 1) + ", writePos " + this.writePos + ", readPos " + this.readPos + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(PrintStream paramPrintStream, String paramString) {
/*  91 */     paramPrintStream.println(paramString + " " + toString() + " {");
/*  92 */     for (byte b = 0; b < this.capacityPlusOne; b++) {
/*  93 */       paramPrintStream.println("\t[" + b + "]: " + this.array[b]);
/*     */     }
/*  95 */     paramPrintStream.println("}");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LFRingbuffer(T[] paramArrayOfT) throws IllegalArgumentException {
/* 120 */     this.capacityPlusOne = paramArrayOfT.length + 1;
/* 121 */     this.array = newArray((Class)paramArrayOfT.getClass(), this.capacityPlusOne);
/* 122 */     resetImpl(true, paramArrayOfT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LFRingbuffer(Class<? extends T[]> paramClass, int paramInt) {
/* 143 */     this.capacityPlusOne = paramInt + 1;
/* 144 */     this.array = newArray(paramClass, this.capacityPlusOne);
/* 145 */     resetImpl(false, null);
/*     */   }
/*     */   
/*     */   public final int capacity() {
/* 149 */     return this.capacityPlusOne - 1;
/*     */   }
/*     */   
/*     */   public final void clear() {
/* 153 */     synchronized (this.syncGlobal) {
/* 154 */       resetImpl(false, null);
/* 155 */       for (byte b = 0; b < this.capacityPlusOne; b++) {
/* 156 */         this.array[b] = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void resetFull(T[] paramArrayOfT) throws IllegalArgumentException {
/* 163 */     resetImpl(true, paramArrayOfT);
/*     */   }
/*     */   
/*     */   private final void resetImpl(boolean paramBoolean, T[] paramArrayOfT) throws IllegalArgumentException {
/* 167 */     synchronized (this.syncGlobal) {
/* 168 */       if (null != paramArrayOfT) {
/* 169 */         if (paramArrayOfT.length != this.capacityPlusOne - 1) {
/* 170 */           throw new IllegalArgumentException("copyFrom array length " + paramArrayOfT.length + " != capacity " + this);
/*     */         }
/* 172 */         System.arraycopy(paramArrayOfT, 0, this.array, 0, paramArrayOfT.length);
/* 173 */         this.array[this.capacityPlusOne - 1] = null;
/* 174 */       } else if (paramBoolean) {
/* 175 */         throw new IllegalArgumentException("copyFrom array is null");
/*     */       } 
/* 177 */       this.readPos = this.capacityPlusOne - 1;
/* 178 */       if (paramBoolean) {
/* 179 */         this.writePos = this.readPos - 1;
/* 180 */         this.size = this.capacityPlusOne - 1;
/*     */       } else {
/* 182 */         this.writePos = this.readPos;
/* 183 */         this.size = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int size() {
/* 189 */     return this.size;
/*     */   }
/*     */   public final int getFreeSlots() {
/* 192 */     return this.capacityPlusOne - 1 - this.size;
/*     */   }
/*     */   public final boolean isEmpty() {
/* 195 */     return (0 == this.size);
/*     */   }
/*     */   public final boolean isFull() {
/* 198 */     return (this.capacityPlusOne - 1 == this.size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T get() {
/*     */     
/* 209 */     try { return getImpl(false, false); }
/* 210 */     catch (InterruptedException interruptedException) { throw new RuntimeException(interruptedException); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getBlocking() throws InterruptedException {
/* 221 */     return getImpl(true, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public final T peek() {
/*     */     
/* 227 */     try { return getImpl(false, true); }
/* 228 */     catch (InterruptedException interruptedException) { throw new RuntimeException(interruptedException); }
/*     */   
/*     */   }
/*     */   public final T peekBlocking() throws InterruptedException {
/* 232 */     return getImpl(true, true);
/*     */   }
/*     */   
/*     */   private final T getImpl(boolean paramBoolean1, boolean paramBoolean2) throws InterruptedException {
/* 236 */     int i = this.readPos;
/* 237 */     if (i == this.writePos) {
/* 238 */       if (paramBoolean1) {
/* 239 */         synchronized (this.syncRead) {
/* 240 */           while (i == this.writePos) {
/* 241 */             this.syncRead.wait();
/*     */           }
/*     */         } 
/*     */       } else {
/* 245 */         return null;
/*     */       } 
/*     */     }
/* 248 */     i = (i + 1) % this.capacityPlusOne;
/* 249 */     T t = this.array[i];
/* 250 */     if (!paramBoolean2) {
/* 251 */       this.array[i] = null;
/* 252 */       synchronized (this.syncWrite) {
/* 253 */         this.size--;
/* 254 */         this.readPos = i;
/* 255 */         this.syncWrite.notifyAll();
/*     */       } 
/*     */     } 
/* 258 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean put(T paramT) {
/*     */     
/* 270 */     try { return putImpl(paramT, false, false); }
/* 271 */     catch (InterruptedException interruptedException) { throw new RuntimeException(interruptedException); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void putBlocking(T paramT) throws InterruptedException {
/* 282 */     if (!putImpl(paramT, false, true)) {
/* 283 */       throw new InternalError("Blocking put failed: " + this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean putSame(boolean paramBoolean) throws InterruptedException {
/* 295 */     return putImpl(null, true, paramBoolean);
/*     */   }
/*     */   
/*     */   private final boolean putImpl(T paramT, boolean paramBoolean1, boolean paramBoolean2) throws InterruptedException {
/* 299 */     int i = this.writePos;
/* 300 */     i = (i + 1) % this.capacityPlusOne;
/* 301 */     if (i == this.readPos) {
/* 302 */       if (paramBoolean2) {
/* 303 */         synchronized (this.syncWrite) {
/* 304 */           while (i == this.readPos) {
/* 305 */             this.syncWrite.wait();
/*     */           }
/*     */         } 
/*     */       } else {
/* 309 */         return false;
/*     */       } 
/*     */     }
/* 312 */     if (!paramBoolean1) {
/* 313 */       this.array[i] = paramT;
/*     */     }
/* 315 */     synchronized (this.syncRead) {
/* 316 */       this.size++;
/* 317 */       this.writePos = i;
/* 318 */       this.syncRead.notifyAll();
/*     */     } 
/* 320 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void waitForFreeSlots(int paramInt) throws InterruptedException {
/* 326 */     synchronized (this.syncRead) {
/* 327 */       if (this.capacityPlusOne - 1 - this.size < paramInt) {
/* 328 */         while (this.capacityPlusOne - 1 - this.size < paramInt) {
/* 329 */           this.syncRead.wait();
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void growEmptyBuffer(T[] paramArrayOfT) throws IllegalStateException, IllegalArgumentException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield syncGlobal : Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aconst_null
/*     */     //   8: aload_1
/*     */     //   9: if_acmpne -> 22
/*     */     //   12: new java/lang/IllegalArgumentException
/*     */     //   15: dup
/*     */     //   16: ldc 'newElements is null'
/*     */     //   18: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   21: athrow
/*     */     //   22: aload_0
/*     */     //   23: getfield array : [Ljava/lang/Object;
/*     */     //   26: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   29: astore_3
/*     */     //   30: aload_1
/*     */     //   31: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   34: astore #4
/*     */     //   36: aload_3
/*     */     //   37: aload #4
/*     */     //   39: if_acmpeq -> 79
/*     */     //   42: new java/lang/IllegalArgumentException
/*     */     //   45: dup
/*     */     //   46: new java/lang/StringBuilder
/*     */     //   49: dup
/*     */     //   50: invokespecial <init> : ()V
/*     */     //   53: ldc 'newElements array-type mismatch, internal '
/*     */     //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   58: aload_3
/*     */     //   59: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   62: ldc ', newElements '
/*     */     //   64: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   67: aload #4
/*     */     //   69: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   72: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   75: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   78: athrow
/*     */     //   79: iconst_0
/*     */     //   80: aload_0
/*     */     //   81: getfield size : I
/*     */     //   84: if_icmpeq -> 114
/*     */     //   87: new java/lang/IllegalStateException
/*     */     //   90: dup
/*     */     //   91: new java/lang/StringBuilder
/*     */     //   94: dup
/*     */     //   95: invokespecial <init> : ()V
/*     */     //   98: ldc 'Buffer is not empty: '
/*     */     //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   103: aload_0
/*     */     //   104: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   107: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   110: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   113: athrow
/*     */     //   114: aload_0
/*     */     //   115: getfield readPos : I
/*     */     //   118: aload_0
/*     */     //   119: getfield writePos : I
/*     */     //   122: if_icmpeq -> 152
/*     */     //   125: new java/lang/InternalError
/*     */     //   128: dup
/*     */     //   129: new java/lang/StringBuilder
/*     */     //   132: dup
/*     */     //   133: invokespecial <init> : ()V
/*     */     //   136: ldc 'R/W pos not equal: '
/*     */     //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   141: aload_0
/*     */     //   142: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   145: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   148: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   151: athrow
/*     */     //   152: aload_0
/*     */     //   153: getfield readPos : I
/*     */     //   156: aload_0
/*     */     //   157: getfield writePos : I
/*     */     //   160: if_icmpeq -> 190
/*     */     //   163: new java/lang/InternalError
/*     */     //   166: dup
/*     */     //   167: new java/lang/StringBuilder
/*     */     //   170: dup
/*     */     //   171: invokespecial <init> : ()V
/*     */     //   174: ldc 'R/W pos not equal at empty: '
/*     */     //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   179: aload_0
/*     */     //   180: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   183: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   186: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   189: athrow
/*     */     //   190: aload_1
/*     */     //   191: arraylength
/*     */     //   192: istore #5
/*     */     //   194: aload_0
/*     */     //   195: getfield capacityPlusOne : I
/*     */     //   198: iload #5
/*     */     //   200: iadd
/*     */     //   201: istore #6
/*     */     //   203: aload_0
/*     */     //   204: getfield array : [Ljava/lang/Object;
/*     */     //   207: astore #7
/*     */     //   209: aload_3
/*     */     //   210: iload #6
/*     */     //   212: invokestatic newArray : (Ljava/lang/Class;I)[Ljava/lang/Object;
/*     */     //   215: astore #8
/*     */     //   217: aload_0
/*     */     //   218: dup
/*     */     //   219: getfield writePos : I
/*     */     //   222: iload #5
/*     */     //   224: iadd
/*     */     //   225: putfield writePos : I
/*     */     //   228: aload_0
/*     */     //   229: getfield readPos : I
/*     */     //   232: iflt -> 250
/*     */     //   235: aload #7
/*     */     //   237: iconst_0
/*     */     //   238: aload #8
/*     */     //   240: iconst_0
/*     */     //   241: aload_0
/*     */     //   242: getfield readPos : I
/*     */     //   245: iconst_1
/*     */     //   246: iadd
/*     */     //   247: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   250: iload #5
/*     */     //   252: ifle -> 270
/*     */     //   255: aload_1
/*     */     //   256: iconst_0
/*     */     //   257: aload #8
/*     */     //   259: aload_0
/*     */     //   260: getfield readPos : I
/*     */     //   263: iconst_1
/*     */     //   264: iadd
/*     */     //   265: iload #5
/*     */     //   267: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   270: aload_0
/*     */     //   271: getfield capacityPlusOne : I
/*     */     //   274: iconst_1
/*     */     //   275: isub
/*     */     //   276: aload_0
/*     */     //   277: getfield readPos : I
/*     */     //   280: isub
/*     */     //   281: istore #9
/*     */     //   283: iload #9
/*     */     //   285: ifle -> 309
/*     */     //   288: aload #7
/*     */     //   290: aload_0
/*     */     //   291: getfield readPos : I
/*     */     //   294: iconst_1
/*     */     //   295: iadd
/*     */     //   296: aload #8
/*     */     //   298: aload_0
/*     */     //   299: getfield writePos : I
/*     */     //   302: iconst_1
/*     */     //   303: iadd
/*     */     //   304: iload #9
/*     */     //   306: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   309: aload_0
/*     */     //   310: iload #5
/*     */     //   312: putfield size : I
/*     */     //   315: aload_0
/*     */     //   316: iload #6
/*     */     //   318: putfield capacityPlusOne : I
/*     */     //   321: aload_0
/*     */     //   322: aload #8
/*     */     //   324: putfield array : [Ljava/lang/Object;
/*     */     //   327: aload_2
/*     */     //   328: monitorexit
/*     */     //   329: goto -> 339
/*     */     //   332: astore #10
/*     */     //   334: aload_2
/*     */     //   335: monitorexit
/*     */     //   336: aload #10
/*     */     //   338: athrow
/*     */     //   339: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #337	-> 0
/*     */     //   #338	-> 7
/*     */     //   #339	-> 12
/*     */     //   #342	-> 22
/*     */     //   #344	-> 30
/*     */     //   #345	-> 36
/*     */     //   #346	-> 42
/*     */     //   #348	-> 79
/*     */     //   #349	-> 87
/*     */     //   #351	-> 114
/*     */     //   #352	-> 125
/*     */     //   #354	-> 152
/*     */     //   #355	-> 163
/*     */     //   #358	-> 190
/*     */     //   #359	-> 194
/*     */     //   #360	-> 203
/*     */     //   #361	-> 209
/*     */     //   #364	-> 217
/*     */     //   #366	-> 228
/*     */     //   #367	-> 235
/*     */     //   #369	-> 250
/*     */     //   #370	-> 255
/*     */     //   #372	-> 270
/*     */     //   #373	-> 283
/*     */     //   #374	-> 288
/*     */     //   #376	-> 309
/*     */     //   #378	-> 315
/*     */     //   #379	-> 321
/*     */     //   #380	-> 327
/*     */     //   #381	-> 339
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	329	332	finally
/*     */     //   332	336	332	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void growFullBuffer(int paramInt) throws IllegalStateException, IllegalArgumentException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield syncGlobal : Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: iconst_0
/*     */     //   8: iload_1
/*     */     //   9: if_icmple -> 44
/*     */     //   12: new java/lang/IllegalArgumentException
/*     */     //   15: dup
/*     */     //   16: new java/lang/StringBuilder
/*     */     //   19: dup
/*     */     //   20: invokespecial <init> : ()V
/*     */     //   23: ldc 'amount '
/*     */     //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   28: iload_1
/*     */     //   29: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   32: ldc ' < 0 '
/*     */     //   34: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   37: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   40: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   43: athrow
/*     */     //   44: aload_0
/*     */     //   45: getfield capacityPlusOne : I
/*     */     //   48: iconst_1
/*     */     //   49: isub
/*     */     //   50: aload_0
/*     */     //   51: getfield size : I
/*     */     //   54: if_icmpeq -> 84
/*     */     //   57: new java/lang/IllegalStateException
/*     */     //   60: dup
/*     */     //   61: new java/lang/StringBuilder
/*     */     //   64: dup
/*     */     //   65: invokespecial <init> : ()V
/*     */     //   68: ldc 'Buffer is not full: '
/*     */     //   70: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   73: aload_0
/*     */     //   74: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   77: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   80: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   83: athrow
/*     */     //   84: aload_0
/*     */     //   85: getfield writePos : I
/*     */     //   88: iconst_1
/*     */     //   89: iadd
/*     */     //   90: aload_0
/*     */     //   91: getfield capacityPlusOne : I
/*     */     //   94: irem
/*     */     //   95: istore_3
/*     */     //   96: iload_3
/*     */     //   97: aload_0
/*     */     //   98: getfield readPos : I
/*     */     //   101: if_icmpeq -> 131
/*     */     //   104: new java/lang/InternalError
/*     */     //   107: dup
/*     */     //   108: new java/lang/StringBuilder
/*     */     //   111: dup
/*     */     //   112: invokespecial <init> : ()V
/*     */     //   115: ldc 'R != W+1 pos at full: '
/*     */     //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   120: aload_0
/*     */     //   121: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   124: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   127: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   130: athrow
/*     */     //   131: aload_0
/*     */     //   132: getfield array : [Ljava/lang/Object;
/*     */     //   135: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   138: astore #4
/*     */     //   140: aload_0
/*     */     //   141: getfield capacityPlusOne : I
/*     */     //   144: iload_1
/*     */     //   145: iadd
/*     */     //   146: istore #5
/*     */     //   148: aload_0
/*     */     //   149: getfield array : [Ljava/lang/Object;
/*     */     //   152: astore #6
/*     */     //   154: aload #4
/*     */     //   156: iload #5
/*     */     //   158: invokestatic newArray : (Ljava/lang/Class;I)[Ljava/lang/Object;
/*     */     //   161: astore #7
/*     */     //   163: aload_0
/*     */     //   164: aload_0
/*     */     //   165: getfield writePos : I
/*     */     //   168: iconst_1
/*     */     //   169: iadd
/*     */     //   170: iload_1
/*     */     //   171: iadd
/*     */     //   172: iload #5
/*     */     //   174: irem
/*     */     //   175: putfield readPos : I
/*     */     //   178: aload_0
/*     */     //   179: getfield writePos : I
/*     */     //   182: iflt -> 200
/*     */     //   185: aload #6
/*     */     //   187: iconst_0
/*     */     //   188: aload #7
/*     */     //   190: iconst_0
/*     */     //   191: aload_0
/*     */     //   192: getfield writePos : I
/*     */     //   195: iconst_1
/*     */     //   196: iadd
/*     */     //   197: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   200: aload_0
/*     */     //   201: getfield capacityPlusOne : I
/*     */     //   204: iconst_1
/*     */     //   205: isub
/*     */     //   206: aload_0
/*     */     //   207: getfield writePos : I
/*     */     //   210: isub
/*     */     //   211: istore #8
/*     */     //   213: iload #8
/*     */     //   215: ifle -> 237
/*     */     //   218: aload #6
/*     */     //   220: aload_0
/*     */     //   221: getfield writePos : I
/*     */     //   224: iconst_1
/*     */     //   225: iadd
/*     */     //   226: aload #7
/*     */     //   228: aload_0
/*     */     //   229: getfield readPos : I
/*     */     //   232: iload #8
/*     */     //   234: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   237: aload_0
/*     */     //   238: iload #5
/*     */     //   240: putfield capacityPlusOne : I
/*     */     //   243: aload_0
/*     */     //   244: aload #7
/*     */     //   246: putfield array : [Ljava/lang/Object;
/*     */     //   249: aload_2
/*     */     //   250: monitorexit
/*     */     //   251: goto -> 261
/*     */     //   254: astore #9
/*     */     //   256: aload_2
/*     */     //   257: monitorexit
/*     */     //   258: aload #9
/*     */     //   260: athrow
/*     */     //   261: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #385	-> 0
/*     */     //   #386	-> 7
/*     */     //   #387	-> 12
/*     */     //   #389	-> 44
/*     */     //   #390	-> 57
/*     */     //   #392	-> 84
/*     */     //   #393	-> 96
/*     */     //   #394	-> 104
/*     */     //   #397	-> 131
/*     */     //   #399	-> 140
/*     */     //   #400	-> 148
/*     */     //   #401	-> 154
/*     */     //   #404	-> 163
/*     */     //   #406	-> 178
/*     */     //   #407	-> 185
/*     */     //   #409	-> 200
/*     */     //   #410	-> 213
/*     */     //   #411	-> 218
/*     */     //   #414	-> 237
/*     */     //   #415	-> 243
/*     */     //   #416	-> 249
/*     */     //   #417	-> 261
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	251	254	finally
/*     */     //   254	258	254	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T[] newArray(Class<? extends T[]> paramClass, int paramInt) {
/* 421 */     return (paramClass == Object[].class) ? 
/* 422 */       (T[])new Object[paramInt] : 
/* 423 */       (T[])Array.newInstance(paramClass.getComponentType(), paramInt);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/LFRingbuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */