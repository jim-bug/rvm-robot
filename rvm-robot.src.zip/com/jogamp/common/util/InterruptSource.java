/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface InterruptSource
/*     */ {
/*     */   Throwable getInterruptSource(boolean paramBoolean);
/*     */   
/*     */   int getInterruptCounter(boolean paramBoolean);
/*     */   
/*     */   void clearInterruptSource();
/*     */   
/*     */   public static class Util
/*     */   {
/*     */     public static InterruptSource get(Thread param1Thread) {
/*  60 */       if (param1Thread instanceof InterruptSource) {
/*  61 */         return (InterruptSource)param1Thread;
/*     */       }
/*  63 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static InterruptSource currentThread() {
/*  71 */       return get(Thread.currentThread());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Thread
/*     */     extends Thread
/*     */     implements InterruptSource
/*     */   {
/*  81 */     volatile Throwable interruptSource = null;
/*  82 */     volatile int interruptCounter = 0;
/*  83 */     final Object sync = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread(ThreadGroup param1ThreadGroup, Runnable param1Runnable) {
/*  97 */       super(param1ThreadGroup, param1Runnable);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread(ThreadGroup param1ThreadGroup, Runnable param1Runnable, String param1String) {
/* 106 */       super(param1ThreadGroup, param1Runnable, param1String);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Thread create(ThreadGroup param1ThreadGroup, Runnable param1Runnable, String param1String) {
/* 118 */       return (null != param1String) ? new Thread(param1ThreadGroup, param1Runnable, param1String) : new Thread(param1ThreadGroup, param1Runnable);
/*     */     }
/*     */ 
/*     */     
/*     */     public final Throwable getInterruptSource(boolean param1Boolean) {
/* 123 */       synchronized (this.sync) {
/* 124 */         Throwable throwable = this.interruptSource;
/* 125 */         if (param1Boolean) {
/* 126 */           clearInterruptSource();
/*     */         }
/* 128 */         return throwable;
/*     */       } 
/*     */     }
/*     */     
/*     */     public final int getInterruptCounter(boolean param1Boolean) {
/* 133 */       synchronized (this.sync) {
/* 134 */         int i = this.interruptCounter;
/* 135 */         if (param1Boolean) {
/* 136 */           clearInterruptSource();
/*     */         }
/* 138 */         return i;
/*     */       } 
/*     */     }
/*     */     
/*     */     public final void clearInterruptSource() {
/* 143 */       synchronized (this.sync) {
/* 144 */         this.interruptCounter = 0;
/* 145 */         this.interruptSource = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     public final void interrupt() {
/* 150 */       synchronized (this.sync) {
/* 151 */         this.interruptCounter++;
/* 152 */         this.interruptSource = new Throwable(getName() + ".interrupt() #" + this.interruptCounter);
/*     */       } 
/* 154 */       super.interrupt();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/InterruptSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */