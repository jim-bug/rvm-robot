/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import jogamp.common.util.Int32ArrayBitfield;
/*     */ import jogamp.common.util.Int32Bitfield;
/*     */ import jogamp.common.util.SyncedBitfield;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Bitfield
/*     */ {
/*     */   public static final int UNSIGNED_INT_MAX_VALUE = -1;
/*     */   
/*     */   int size();
/*     */   
/*     */   void clearField(boolean paramBoolean);
/*     */   
/*     */   int get32(int paramInt1, int paramInt2) throws IndexOutOfBoundsException;
/*     */   
/*     */   void put32(int paramInt1, int paramInt2, int paramInt3) throws IndexOutOfBoundsException;
/*     */   
/*     */   int copy32(int paramInt1, int paramInt2, int paramInt3) throws IndexOutOfBoundsException;
/*     */   
/*     */   boolean get(int paramInt) throws IndexOutOfBoundsException;
/*     */   
/*     */   boolean put(int paramInt, boolean paramBoolean) throws IndexOutOfBoundsException;
/*     */   
/*     */   void set(int paramInt) throws IndexOutOfBoundsException;
/*     */   
/*     */   void clear(int paramInt) throws IndexOutOfBoundsException;
/*     */   
/*     */   boolean copy(int paramInt1, int paramInt2) throws IndexOutOfBoundsException;
/*     */   
/*     */   int bitCount();
/*     */   
/*     */   public static class Util
/*     */   {
/*     */     public static final int MAX_POWER_OF_2 = 1073741824;
/*     */     
/*     */     public static int getBitMask(int param1Int) {
/*  60 */       if (32 > param1Int)
/*  61 */         return (1 << param1Int) - 1; 
/*  62 */       if (32 == param1Int) {
/*  63 */         return -1;
/*     */       }
/*  65 */       throw new IndexOutOfBoundsException("n <= 32 expected, is " + param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int bitCount(int param1Int) {
/*  94 */       param1Int -= param1Int >>> 1 & 0x55555555;
/*  95 */       param1Int = (param1Int & 0x33333333) + (param1Int >>> 2 & 0x33333333);
/*  96 */       param1Int = param1Int + (param1Int >>> 4) & 0xF0F0F0F;
/*  97 */       param1Int += param1Int >>> 8;
/*  98 */       param1Int += param1Int >>> 16;
/*  99 */       return param1Int & 0x3F;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final boolean isPowerOf2(int param1Int) {
/* 109 */       return (0 < param1Int && 0 == (param1Int & param1Int - 1));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int nextPowerOf2(int param1Int) {
/* 121 */       param1Int--;
/* 122 */       param1Int |= param1Int >>> 1;
/* 123 */       param1Int |= param1Int >>> 2;
/* 124 */       param1Int |= param1Int >>> 4;
/* 125 */       param1Int |= param1Int >>> 8;
/* 126 */       param1Int |= param1Int >>> 16;
/* 127 */       return (param1Int < 0) ? 1 : (param1Int + 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int roundToPowerOf2(int param1Int) {
/* 140 */       return isPowerOf2(param1Int) ? param1Int : nextPowerOf2(param1Int);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Factory
/*     */   {
/*     */     public static Bitfield create(int param1Int) {
/* 155 */       if (32 >= param1Int) {
/* 156 */         return (Bitfield)new Int32Bitfield();
/*     */       }
/* 158 */       return (Bitfield)new Int32ArrayBitfield(param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bitfield synchronize(Bitfield param1Bitfield) {
/* 165 */       return (Bitfield)new SyncedBitfield(param1Bitfield);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/Bitfield.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */