/*     */ package com.jogamp.common.util;
/*     */ 
/*     */ import com.jogamp.common.net.Uri;
/*     */ import com.jogamp.common.os.NativeLibrary;
/*     */ import com.jogamp.common.os.Platform;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarUtil
/*     */ {
/*  55 */   private static final boolean DEBUG = Debug.debug("JarUtil");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int BUFFER_SIZE = 4096;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Resolver resolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setResolver(Resolver paramResolver) throws IllegalArgumentException, IllegalStateException, SecurityException {
/*  87 */     if (paramResolver == null) {
/*  88 */       throw new IllegalArgumentException("Null Resolver passed");
/*     */     }
/*     */     
/*  91 */     if (resolver != null) {
/*  92 */       throw new IllegalStateException("Resolver already set!");
/*     */     }
/*     */     
/*  95 */     SecurityManager securityManager = System.getSecurityManager();
/*  96 */     if (securityManager != null) {
/*  97 */       securityManager.checkSetFactory();
/*     */     }
/*     */     
/* 100 */     resolver = paramResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasJarUri(String paramString, ClassLoader paramClassLoader) {
/*     */     try {
/* 118 */       return (null != getJarUri(paramString, paramClassLoader));
/* 119 */     } catch (Exception exception) {
/* 120 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri getJarUri(String paramString, ClassLoader paramClassLoader) throws IllegalArgumentException, IOException, URISyntaxException {
/*     */     Uri uri;
/* 140 */     if (null == paramString || null == paramClassLoader) {
/* 141 */       throw new IllegalArgumentException("null arguments: clazzBinName " + paramString + ", cl " + paramClassLoader);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 146 */     URL uRL = IOUtil.getClassURL(paramString, paramClassLoader);
/* 147 */     String str = uRL.getProtocol();
/* 148 */     if (null != resolver && 
/* 149 */       !str.equals("jar") && 
/* 150 */       !str.equals("file") && 
/* 151 */       !str.equals("http") && 
/* 152 */       !str.equals("https")) {
/*     */       
/* 154 */       URL uRL1 = resolver.resolve(uRL);
/* 155 */       uri = Uri.valueOf(uRL1);
/* 156 */       if (DEBUG) {
/* 157 */         System.err.println("getJarUri Resolver: " + uRL + "\n\t-> " + uRL1 + "\n\t-> " + uri);
/*     */       }
/*     */     } else {
/* 160 */       uri = Uri.valueOf(uRL);
/* 161 */       if (DEBUG) {
/* 162 */         System.err.println("getJarUri Default " + uRL + "\n\t-> " + uri);
/*     */       }
/*     */     } 
/*     */     
/* 166 */     if (!uri.isJarScheme()) {
/* 167 */       throw new IllegalArgumentException("Uri is not using scheme jar: <" + uri + ">");
/*     */     }
/* 169 */     if (DEBUG) {
/* 170 */       System.err.println("getJarUri res: " + paramString + " -> " + uRL + " -> " + uri);
/*     */     }
/* 172 */     return uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri.Encoded getJarBasename(Uri paramUri) throws IllegalArgumentException {
/* 190 */     if (null == paramUri) {
/* 191 */       throw new IllegalArgumentException("Uri is null");
/*     */     }
/* 193 */     if (!paramUri.isJarScheme()) {
/* 194 */       throw new IllegalArgumentException("Uri is not using scheme jar: <" + paramUri + ">");
/*     */     }
/* 196 */     Uri.Encoded encoded = paramUri.schemeSpecificPart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     int i = encoded.lastIndexOf(33);
/* 203 */     if (0 <= i) {
/* 204 */       encoded = encoded.substring(0, i);
/*     */     } else {
/* 206 */       throw new IllegalArgumentException("Uri does not contain jar uri terminator '!', in <" + paramUri + ">");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     i = encoded.lastIndexOf(47);
/* 214 */     if (0 > i) {
/*     */       
/* 216 */       i = encoded.lastIndexOf(58);
/* 217 */       if (0 > i) {
/* 218 */         throw new IllegalArgumentException("Uri does not contain protocol terminator ':', in <" + paramUri + ">");
/*     */       }
/*     */     } 
/* 221 */     encoded = encoded.substring(i + 1);
/*     */     
/* 223 */     if (0 >= encoded.lastIndexOf(".jar")) {
/* 224 */       throw new IllegalArgumentException("No Jar name in <" + paramUri + ">");
/*     */     }
/* 226 */     if (DEBUG) {
/* 227 */       System.err.println("getJarName res: " + encoded);
/*     */     }
/* 229 */     return encoded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri.Encoded getJarBasename(String paramString, ClassLoader paramClassLoader) throws IllegalArgumentException, IOException, URISyntaxException {
/* 249 */     return getJarBasename(getJarUri(paramString, paramClassLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri.Encoded getJarEntry(Uri paramUri) {
/* 262 */     if (null == paramUri) {
/* 263 */       throw new IllegalArgumentException("Uri is null");
/*     */     }
/* 265 */     if (!paramUri.isJarScheme()) {
/* 266 */       throw new IllegalArgumentException("Uri is not a using scheme jar: <" + paramUri + ">");
/*     */     }
/* 268 */     Uri.Encoded encoded = paramUri.schemeSpecificPart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     int i = encoded.lastIndexOf(33);
/* 275 */     if (0 <= i) {
/* 276 */       Uri.Encoded encoded1 = encoded.substring(i + 1);
/*     */       
/* 278 */       if (DEBUG) {
/* 279 */         System.err.println("getJarEntry res: " + paramUri + " -> " + encoded + " -> " + i + " -> " + encoded1);
/*     */       }
/* 281 */       return encoded1;
/*     */     } 
/* 283 */     throw new IllegalArgumentException("JAR Uri does not contain jar uri terminator '!', uri <" + paramUri + ">");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri getJarFileUri(String paramString, ClassLoader paramClassLoader) throws IllegalArgumentException, IOException, URISyntaxException {
/* 304 */     if (null == paramString || null == paramClassLoader) {
/* 305 */       throw new IllegalArgumentException("null arguments: clazzBinName " + paramString + ", cl " + paramClassLoader);
/*     */     }
/* 307 */     Uri uri1 = getJarUri(paramString, paramClassLoader).getContainedUri();
/* 308 */     Uri uri2 = Uri.cast("jar:" + uri1.toString() + "!/");
/* 309 */     if (DEBUG) {
/* 310 */       System.err.println("getJarFileUri res: " + uri2);
/*     */     }
/* 312 */     return uri2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri getJarFileUri(Uri paramUri, Uri.Encoded paramEncoded) throws IllegalArgumentException, URISyntaxException {
/* 323 */     if (null == paramUri || null == paramEncoded) {
/* 324 */       throw new IllegalArgumentException("null arguments: baseUri " + paramUri + ", jarFileName " + paramEncoded);
/*     */     }
/* 326 */     return Uri.cast("jar:" + paramUri.toString() + paramEncoded + "!/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri getJarFileUri(Uri paramUri) throws IllegalArgumentException, URISyntaxException {
/* 336 */     if (null == paramUri) {
/* 337 */       throw new IllegalArgumentException("jarSubUri is null");
/*     */     }
/* 339 */     return Uri.cast("jar:" + paramUri.toString() + "!/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri getJarFileUri(Uri.Encoded paramEncoded) throws IllegalArgumentException, URISyntaxException {
/* 349 */     if (null == paramEncoded) {
/* 350 */       throw new IllegalArgumentException("jarSubUriS is null");
/*     */     }
/* 352 */     return Uri.cast("jar:" + paramEncoded + "!/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri getJarEntryUri(Uri paramUri, Uri.Encoded paramEncoded) throws IllegalArgumentException, URISyntaxException {
/* 363 */     if (null == paramEncoded) {
/* 364 */       throw new IllegalArgumentException("jarEntry is null");
/*     */     }
/* 366 */     return Uri.cast(paramUri.toString() + paramEncoded);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JarFile getJarFile(String paramString, ClassLoader paramClassLoader) throws IOException, IllegalArgumentException, URISyntaxException {
/* 379 */     return getJarFile(getJarFileUri(paramString, paramClassLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JarFile getJarFile(Uri paramUri) throws IOException, IllegalArgumentException, URISyntaxException {
/* 390 */     if (null == paramUri) {
/* 391 */       throw new IllegalArgumentException("null jarFileUri");
/*     */     }
/* 393 */     if (DEBUG) {
/* 394 */       System.err.println("getJarFile.0: " + paramUri.toString());
/*     */     }
/* 396 */     URL uRL = paramUri.toURL();
/* 397 */     if (DEBUG) {
/* 398 */       System.err.println("getJarFile.1: " + uRL.toString());
/*     */     }
/* 400 */     URLConnection uRLConnection = uRL.openConnection();
/* 401 */     if (uRLConnection instanceof JarURLConnection) {
/* 402 */       JarURLConnection jarURLConnection = (JarURLConnection)uRL.openConnection();
/* 403 */       JarFile jarFile = jarURLConnection.getJarFile();
/* 404 */       if (DEBUG) {
/* 405 */         System.err.println("getJarFile res: " + jarFile.getName());
/*     */       }
/* 407 */       return jarFile;
/*     */     } 
/* 409 */     if (DEBUG) {
/* 410 */       System.err.println("getJarFile res: NULL");
/*     */     }
/* 412 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Uri getRelativeOf(Class<?> paramClass, Uri.Encoded paramEncoded1, Uri.Encoded paramEncoded2) throws IllegalArgumentException, IOException, URISyntaxException {
/*     */     Uri.Encoded encoded2;
/* 460 */     ClassLoader classLoader = paramClass.getClassLoader();
/* 461 */     Uri uri1 = getJarUri(paramClass.getName(), classLoader);
/* 462 */     if (DEBUG) {
/* 463 */       System.err.println("JarUtil.getRelativeOf: (classFromJavaJar " + paramClass + ", classJarUri " + uri1 + ", cutOffInclSubDir " + paramEncoded1 + ", relResPath " + paramEncoded2 + "): ");
/*     */     }
/*     */     
/* 466 */     Uri uri2 = uri1.getContainedUri();
/* 467 */     if (null == uri2) {
/* 468 */       throw new IllegalArgumentException("JarSubUri is null of: " + uri1);
/*     */     }
/* 470 */     Uri.Encoded encoded1 = uri2.getDirectory().getEncoded();
/* 471 */     if (DEBUG) {
/* 472 */       System.err.println("JarUtil.getRelativeOf: uri " + uri2.toString() + " -> " + encoded1);
/*     */     }
/*     */     
/* 475 */     if (null == paramEncoded1 || encoded1.endsWith(paramEncoded1.get())) {
/* 476 */       encoded2 = encoded1.concat(paramEncoded2);
/*     */     } else {
/* 478 */       encoded2 = encoded1.concat(paramEncoded1).concat(paramEncoded2);
/*     */     } 
/* 480 */     if (DEBUG) {
/* 481 */       System.err.println("JarUtil.getRelativeOf: ...  -> " + encoded2);
/*     */     }
/* 483 */     Uri uri3 = getJarFileUri(encoded2);
/* 484 */     if (DEBUG) {
/* 485 */       System.err.println("JarUtil.getRelativeOf: fin " + uri3);
/*     */     }
/* 487 */     return uri3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getNativeLibNames(JarFile paramJarFile) {
/* 494 */     if (DEBUG) {
/* 495 */       System.err.println("JarUtil: getNativeLibNames: " + paramJarFile);
/*     */     }
/*     */     
/* 498 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 499 */     Enumeration<JarEntry> enumeration = paramJarFile.entries();
/*     */     
/* 501 */     while (enumeration.hasMoreElements()) {
/* 502 */       JarEntry jarEntry = enumeration.nextElement();
/* 503 */       String str1 = jarEntry.getName();
/* 504 */       String str2 = NativeLibrary.isValidNativeLibraryName(str1, false);
/*     */       
/* 506 */       if (null != str2) {
/* 507 */         hashMap.put(str2, str1);
/*     */       }
/*     */     } 
/*     */     
/* 511 */     return (Map)hashMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int extract(File paramFile, Map<String, String> paramMap, JarFile paramJarFile, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) throws IOException {
/* 555 */     if (DEBUG) {
/* 556 */       System.err.println("JarUtil: extract: " + paramJarFile.getName() + " -> " + paramFile + ", extractNativeLibraries " + paramBoolean1 + " (" + paramString + "), extractClassFiles " + paramBoolean2 + ", extractOtherFiles " + paramBoolean3);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 561 */     byte b = 0;
/*     */     
/* 563 */     Enumeration<JarEntry> enumeration = paramJarFile.entries();
/* 564 */     while (enumeration.hasMoreElements()) {
/* 565 */       JarEntry jarEntry = enumeration.nextElement();
/* 566 */       String str1 = jarEntry.getName();
/*     */ 
/*     */       
/* 569 */       String str2 = NativeLibrary.isValidNativeLibraryName(str1, false);
/* 570 */       boolean bool1 = (null != str2) ? true : false;
/* 571 */       if (bool1) {
/* 572 */         if (!paramBoolean1) {
/* 573 */           if (DEBUG) {
/* 574 */             System.err.println("JarUtil: JarEntry : " + str1 + " native-lib skipped, skip all native libs");
/*     */           }
/*     */           continue;
/*     */         } 
/* 578 */         if (null != paramString) {
/*     */           String str3;
/*     */           String str4;
/*     */           try {
/* 582 */             str3 = IOUtil.slashify(paramString, false, true);
/* 583 */             str4 = IOUtil.getDirname(str1);
/* 584 */           } catch (URISyntaxException uRISyntaxException) {
/* 585 */             throw new IOException(uRISyntaxException);
/*     */           } 
/* 587 */           if (!str3.equals(str4)) {
/* 588 */             if (DEBUG) {
/* 589 */               System.err.println("JarUtil: JarEntry : " + str1 + " native-lib skipped, not in path: " + str3);
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } 
/*     */       } 
/* 596 */       boolean bool2 = str1.endsWith(".class");
/* 597 */       if (bool2 && !paramBoolean2) {
/* 598 */         if (DEBUG) {
/* 599 */           System.err.println("JarUtil: JarEntry : " + str1 + " class-file skipped");
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 604 */       if (!bool1 && !bool2 && !paramBoolean3) {
/* 605 */         if (DEBUG) {
/* 606 */           System.err.println("JarUtil: JarEntry : " + str1 + " other-file skipped");
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 611 */       boolean bool3 = str1.endsWith("/");
/*     */ 
/*     */       
/* 614 */       boolean bool4 = (str1.indexOf('/') == -1 && str1.indexOf(File.separatorChar) == -1) ? true : false;
/*     */       
/* 616 */       if (DEBUG) {
/* 617 */         System.err.println("JarUtil: JarEntry : isNativeLib " + bool1 + ", isClassFile " + bool2 + ", isDir " + bool3 + ", isRootEntry " + bool4);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 622 */       File file1 = new File(paramFile, str1);
/* 623 */       if (bool3) {
/* 624 */         if (DEBUG) {
/* 625 */           System.err.println("JarUtil: MKDIR: " + str1 + " -> " + file1);
/*     */         }
/* 627 */         file1.mkdirs(); continue;
/*     */       } 
/* 629 */       File file2 = new File(file1.getParent());
/* 630 */       if (!file2.exists()) {
/* 631 */         if (DEBUG) {
/* 632 */           System.err.println("JarUtil: MKDIR (parent): " + str1 + " -> " + file2);
/*     */         }
/* 634 */         file2.mkdirs();
/*     */       } 
/* 636 */       BufferedInputStream bufferedInputStream = new BufferedInputStream(paramJarFile.getInputStream(jarEntry));
/* 637 */       BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file1));
/* 638 */       int i = -1;
/*     */       try {
/* 640 */         i = IOUtil.copyStream2Stream(4096, bufferedInputStream, bufferedOutputStream);
/*     */       } finally {
/* 642 */         bufferedInputStream.close();
/* 643 */         bufferedOutputStream.close();
/*     */       } 
/* 645 */       boolean bool5 = false;
/* 646 */       if (i > 0) {
/* 647 */         b++;
/* 648 */         if (bool1 && (bool4 || !paramMap.containsKey(str2))) {
/* 649 */           paramMap.put(str2, file1.getAbsolutePath());
/* 650 */           bool5 = true;
/* 651 */           fixNativeLibAttribs(file1);
/*     */         } 
/*     */       } 
/* 654 */       if (DEBUG) {
/* 655 */         System.err.println("JarUtil: EXTRACT[" + b + "]: [" + str2 + " -> ] " + str1 + " -> " + file1 + ": " + i + " bytes, addedAsNativeLib: " + bool5);
/*     */       }
/*     */     } 
/*     */     
/* 659 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void fixNativeLibAttribs(File paramFile) {
/* 672 */     if (Platform.OSType.MACOS == Platform.getOSType() || Platform.OSType.IOS == Platform.getOSType()) {
/* 673 */       String str = paramFile.getAbsolutePath();
/*     */       try {
/* 675 */         fixNativeLibAttribs(str);
/* 676 */         if (DEBUG) {
/* 677 */           System.err.println("JarUtil.fixNativeLibAttribs: " + str + " - OK");
/*     */         }
/* 679 */       } catch (Throwable throwable) {
/* 680 */         if (DEBUG) {
/* 681 */           System.err.println("JarUtil.fixNativeLibAttribs: " + str + " - " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean fixNativeLibAttribs(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void validateCertificates(Certificate[] paramArrayOfCertificate, JarFile paramJarFile) throws IOException, SecurityException {
/* 699 */     if (DEBUG) {
/* 700 */       System.err.println("JarUtil: validateCertificates: " + paramJarFile.getName());
/*     */     }
/*     */     
/* 703 */     if (paramArrayOfCertificate == null || paramArrayOfCertificate.length == 0) {
/* 704 */       throw new IllegalArgumentException("Null certificates passed");
/*     */     }
/*     */     
/* 707 */     byte[] arrayOfByte = new byte[1024];
/* 708 */     Enumeration<JarEntry> enumeration = paramJarFile.entries();
/* 709 */     while (enumeration.hasMoreElements()) {
/* 710 */       JarEntry jarEntry = enumeration.nextElement();
/* 711 */       if (!jarEntry.isDirectory() && !jarEntry.getName().startsWith("META-INF/"))
/*     */       {
/* 713 */         validateCertificate(paramArrayOfCertificate, paramJarFile, jarEntry, arrayOfByte);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void validateCertificate(Certificate[] paramArrayOfCertificate, JarFile paramJarFile, JarEntry paramJarEntry, byte[] paramArrayOfbyte) throws IOException, SecurityException {
/* 725 */     if (DEBUG) {
/* 726 */       System.err.println("JarUtil: validate JarEntry : " + paramJarEntry.getName());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 732 */     InputStream inputStream = paramJarFile.getInputStream(paramJarEntry);
/*     */     try {
/* 734 */       while (inputStream.read(paramArrayOfbyte) > 0);
/*     */     } finally {
/* 736 */       inputStream.close();
/*     */     } 
/*     */ 
/*     */     
/* 740 */     Certificate[] arrayOfCertificate = paramJarEntry.getCertificates();
/* 741 */     if (arrayOfCertificate == null || arrayOfCertificate.length == 0) {
/* 742 */       throw new SecurityException("no certificate for " + paramJarEntry.getName() + " in " + paramJarFile.getName());
/*     */     }
/*     */     
/* 745 */     if (!SecurityUtil.equals(paramArrayOfCertificate, arrayOfCertificate))
/* 746 */       throw new SecurityException("certificates not equal for " + paramJarEntry.getName() + " in " + paramJarFile.getName()); 
/*     */   }
/*     */   
/*     */   public static interface Resolver {
/*     */     URL resolve(URL param1URL);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/JarUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */