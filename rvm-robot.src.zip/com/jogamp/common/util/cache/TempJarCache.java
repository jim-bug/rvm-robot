/*     */ package com.jogamp.common.util.cache;
/*     */ 
/*     */ import com.jogamp.common.JogampRuntimeException;
/*     */ import com.jogamp.common.net.Uri;
/*     */ import com.jogamp.common.os.NativeLibrary;
/*     */ import com.jogamp.common.util.JarUtil;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarFile;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TempJarCache
/*     */ {
/*     */   private static Map<String, String> nativeLibMap;
/*     */   private static Map<Uri, LoadState> nativeLibJars;
/*     */   private static Map<Uri, LoadState> classFileJars;
/*  53 */   private static final boolean DEBUG = Debug.debug("TempJarCache");
/*     */ 
/*     */   
/*     */   private static Map<Uri, LoadState> resourceFileJars;
/*     */   
/*     */   private static TempFileCache tmpFileCache;
/*     */ 
/*     */   
/*     */   public enum LoadState
/*     */   {
/*  63 */     LOOKED_UP, LOADED;
/*     */     
/*     */     public boolean compliesWith(LoadState param1LoadState) {
/*  66 */       return (null != param1LoadState) ? ((compareTo(param1LoadState) >= 0)) : false;
/*     */     } }
/*     */   
/*     */   private static boolean testLoadState(LoadState paramLoadState1, LoadState paramLoadState2) {
/*  70 */     if (null == paramLoadState1) {
/*  71 */       return (null == paramLoadState2);
/*     */     }
/*  73 */     return paramLoadState1.compliesWith(paramLoadState2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static volatile boolean staticInitError = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private static volatile boolean staticTempIsExecutable = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private static volatile boolean isInit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean initSingleton() {
/*  93 */     if (!isInit) {
/*  94 */       synchronized (TempJarCache.class) {
/*  95 */         if (!isInit) {
/*  96 */           staticInitError = !TempFileCache.initSingleton();
/*     */           
/*  98 */           if (!staticInitError) {
/*  99 */             tmpFileCache = new TempFileCache();
/* 100 */             staticInitError = !tmpFileCache.isValid(false);
/* 101 */             staticTempIsExecutable = tmpFileCache.isValid(true);
/*     */           } 
/*     */           
/* 104 */           if (!staticInitError) {
/*     */             
/* 106 */             nativeLibMap = new HashMap<>();
/* 107 */             nativeLibJars = new HashMap<>();
/* 108 */             classFileJars = new HashMap<>();
/* 109 */             resourceFileJars = new HashMap<>();
/*     */           } 
/* 111 */           if (DEBUG) {
/* 112 */             File file = (null != tmpFileCache) ? tmpFileCache.getTempDir() : null;
/* 113 */             String str = (null != file) ? file.getAbsolutePath() : null;
/* 114 */             System.err.println("TempJarCache.initSingleton(): ok " + ((false == staticInitError) ? 1 : 0) + ", " + str + ", executable " + staticTempIsExecutable);
/*     */           } 
/* 116 */           isInit = true;
/*     */         } 
/*     */       } 
/*     */     }
/* 120 */     return !staticInitError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isInitializedImpl() {
/* 164 */     if (!isInit) {
/* 165 */       synchronized (TempJarCache.class) {
/* 166 */         if (!isInit) {
/* 167 */           return false;
/*     */         }
/*     */       } 
/*     */     }
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInitialized(boolean paramBoolean) {
/* 179 */     return (isInitializedImpl() && !staticInitError && (!paramBoolean || staticTempIsExecutable));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void checkInitialized(boolean paramBoolean) {
/* 186 */     if (!isInitializedImpl()) {
/* 187 */       throw new JogampRuntimeException("initSingleton() has to be called first.");
/*     */     }
/* 189 */     if (staticInitError) {
/* 190 */       throw new JogampRuntimeException("initSingleton() failed.");
/*     */     }
/* 192 */     if (paramBoolean && !staticTempIsExecutable) {
/* 193 */       throw new JogampRuntimeException("TempJarCache folder not suitable for executables");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TempFileCache getTempFileCache() {
/* 202 */     checkInitialized(false);
/* 203 */     return tmpFileCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean checkNativeLibs(Uri paramUri, LoadState paramLoadState) throws IOException {
/* 214 */     checkInitialized(false);
/* 215 */     if (null == paramUri) {
/* 216 */       throw new IllegalArgumentException("jarUri is null");
/*     */     }
/* 218 */     return testLoadState(nativeLibJars.get(paramUri), paramLoadState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean checkClasses(Uri paramUri, LoadState paramLoadState) throws IOException {
/* 229 */     checkInitialized(false);
/* 230 */     if (null == paramUri) {
/* 231 */       throw new IllegalArgumentException("jarUri is null");
/*     */     }
/* 233 */     return testLoadState(classFileJars.get(paramUri), paramLoadState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean checkResources(Uri paramUri, LoadState paramLoadState) throws IOException {
/* 245 */     checkInitialized(false);
/* 246 */     if (null == paramUri) {
/* 247 */       throw new IllegalArgumentException("jarUri is null");
/*     */     }
/* 249 */     return testLoadState(resourceFileJars.get(paramUri), paramLoadState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized boolean addNativeLibs(Class<?> paramClass, Uri paramUri, String paramString) throws IOException, SecurityException, IllegalArgumentException, URISyntaxException {
/* 266 */     checkInitialized(true);
/* 267 */     LoadState loadState = nativeLibJars.get(paramUri);
/* 268 */     if (!testLoadState(loadState, LoadState.LOOKED_UP)) {
/* 269 */       nativeLibJars.put(paramUri, LoadState.LOOKED_UP);
/* 270 */       JarFile jarFile = JarUtil.getJarFile(paramUri);
/* 271 */       if (DEBUG) {
/* 272 */         System.err.println("TempJarCache: addNativeLibs: " + paramUri + ": nativeJar " + jarFile.getName() + " (NEW)");
/*     */       }
/* 274 */       validateCertificates(paramClass, jarFile);
/* 275 */       int i = JarUtil.extract(tmpFileCache.getTempDir(), nativeLibMap, jarFile, paramString, true, false, false);
/* 276 */       nativeLibJars.put(paramUri, LoadState.LOADED);
/* 277 */       return (i > 0);
/* 278 */     }  if (testLoadState(loadState, LoadState.LOADED)) {
/* 279 */       if (DEBUG) {
/* 280 */         System.err.println("TempJarCache: addNativeLibs: " + paramUri + ": nativeJar " + paramUri + " (REUSE)");
/*     */       }
/* 282 */       return true;
/*     */     } 
/* 284 */     throw new IOException("TempJarCache: addNativeLibs: " + paramUri + ", previous load attempt failed");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized void addClasses(Class<?> paramClass, Uri paramUri) throws IOException, SecurityException, IllegalArgumentException, URISyntaxException {
/* 302 */     checkInitialized(false);
/* 303 */     LoadState loadState = classFileJars.get(paramUri);
/* 304 */     if (!testLoadState(loadState, LoadState.LOOKED_UP)) {
/* 305 */       classFileJars.put(paramUri, LoadState.LOOKED_UP);
/* 306 */       JarFile jarFile = JarUtil.getJarFile(paramUri);
/* 307 */       if (DEBUG) {
/* 308 */         System.err.println("TempJarCache: addClasses: " + paramUri + ": nativeJar " + jarFile.getName());
/*     */       }
/* 310 */       validateCertificates(paramClass, jarFile);
/* 311 */       JarUtil.extract(tmpFileCache.getTempDir(), null, jarFile, null, false, true, false);
/*     */       
/* 313 */       classFileJars.put(paramUri, LoadState.LOADED);
/* 314 */     } else if (!testLoadState(loadState, LoadState.LOADED)) {
/* 315 */       throw new IOException("TempJarCache: addClasses: " + paramUri + ", previous load attempt failed");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized void addResources(Class<?> paramClass, Uri paramUri) throws IOException, SecurityException, IllegalArgumentException, URISyntaxException {
/* 332 */     checkInitialized(false);
/* 333 */     LoadState loadState = resourceFileJars.get(paramUri);
/* 334 */     if (!testLoadState(loadState, LoadState.LOOKED_UP)) {
/* 335 */       resourceFileJars.put(paramUri, LoadState.LOOKED_UP);
/* 336 */       JarFile jarFile = JarUtil.getJarFile(paramUri);
/* 337 */       if (DEBUG) {
/* 338 */         System.err.println("TempJarCache: addResources: " + paramUri + ": nativeJar " + jarFile.getName());
/*     */       }
/* 340 */       validateCertificates(paramClass, jarFile);
/* 341 */       JarUtil.extract(tmpFileCache.getTempDir(), null, jarFile, null, false, false, true);
/*     */       
/* 343 */       resourceFileJars.put(paramUri, LoadState.LOADED);
/* 344 */     } else if (!testLoadState(loadState, LoadState.LOADED)) {
/* 345 */       throw new IOException("TempJarCache: addResources: " + paramUri + ", previous load attempt failed");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized void addAll(Class<?> paramClass, Uri paramUri) throws IOException, SecurityException, IllegalArgumentException, URISyntaxException {
/* 365 */     checkInitialized(false);
/* 366 */     if (null == paramUri) {
/* 367 */       throw new IllegalArgumentException("jarUri is null");
/*     */     }
/* 369 */     LoadState loadState1 = nativeLibJars.get(paramUri);
/* 370 */     LoadState loadState2 = classFileJars.get(paramUri);
/* 371 */     LoadState loadState3 = resourceFileJars.get(paramUri);
/* 372 */     if (!testLoadState(loadState1, LoadState.LOOKED_UP) || 
/* 373 */       !testLoadState(loadState2, LoadState.LOOKED_UP) || 
/* 374 */       !testLoadState(loadState3, LoadState.LOOKED_UP)) {
/*     */       
/* 376 */       boolean bool1 = (staticTempIsExecutable && !testLoadState(loadState1, LoadState.LOADED)) ? true : false;
/* 377 */       boolean bool2 = !testLoadState(loadState2, LoadState.LOADED) ? true : false;
/* 378 */       boolean bool3 = !testLoadState(loadState3, LoadState.LOOKED_UP) ? true : false;
/*     */ 
/*     */       
/* 381 */       if (bool1) {
/* 382 */         nativeLibJars.put(paramUri, LoadState.LOOKED_UP);
/*     */       }
/* 384 */       if (bool2) {
/* 385 */         classFileJars.put(paramUri, LoadState.LOOKED_UP);
/*     */       }
/* 387 */       if (bool3) {
/* 388 */         resourceFileJars.put(paramUri, LoadState.LOOKED_UP);
/*     */       }
/*     */       
/* 391 */       JarFile jarFile = JarUtil.getJarFile(paramUri);
/* 392 */       if (DEBUG) {
/* 393 */         System.err.println("TempJarCache: addAll: " + paramUri + ": nativeJar " + jarFile.getName());
/*     */       }
/* 395 */       validateCertificates(paramClass, jarFile);
/* 396 */       JarUtil.extract(tmpFileCache.getTempDir(), nativeLibMap, jarFile, null, bool1, bool2, bool3);
/*     */ 
/*     */ 
/*     */       
/* 400 */       if (bool1) {
/* 401 */         nativeLibJars.put(paramUri, LoadState.LOADED);
/*     */       }
/* 403 */       if (bool2) {
/* 404 */         classFileJars.put(paramUri, LoadState.LOADED);
/*     */       }
/* 406 */       if (bool3) {
/* 407 */         resourceFileJars.put(paramUri, LoadState.LOADED);
/*     */       }
/* 409 */     } else if (!testLoadState(loadState1, LoadState.LOADED) || 
/* 410 */       !testLoadState(loadState2, LoadState.LOADED) || 
/* 411 */       !testLoadState(loadState3, LoadState.LOADED)) {
/* 412 */       throw new IOException("TempJarCache: addAll: " + paramUri + ", previous load attempt failed");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized String findLibrary(String paramString) {
/* 424 */     checkInitialized(false);
/* 425 */     if (!staticTempIsExecutable) {
/* 426 */       return null;
/*     */     }
/*     */     
/* 429 */     String str = nativeLibMap.get(paramString);
/* 430 */     if (null == str)
/*     */     {
/* 432 */       if (null != NativeLibrary.isValidNativeLibraryName(paramString, false)) {
/* 433 */         File file = new File(tmpFileCache.getTempDir(), paramString);
/* 434 */         if (file.exists()) {
/* 435 */           str = file.getAbsolutePath();
/*     */         }
/*     */       } 
/*     */     }
/* 439 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized String findResource(String paramString) {
/* 464 */     checkInitialized(false);
/* 465 */     File file = new File(tmpFileCache.getTempDir(), paramString);
/* 466 */     if (file.exists()) {
/* 467 */       return file.getAbsolutePath();
/*     */     }
/* 469 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized Uri getResourceUri(String paramString) throws URISyntaxException {
/* 480 */     checkInitialized(false);
/* 481 */     File file = new File(tmpFileCache.getTempDir(), paramString);
/* 482 */     if (file.exists()) {
/* 483 */       return Uri.valueOf(file);
/*     */     }
/* 485 */     return null;
/*     */   }
/*     */   
/*     */   private static void validateCertificates(Class<?> paramClass, JarFile paramJarFile) throws IOException, SecurityException {
/* 489 */     if (null == paramClass) {
/* 490 */       throw new IllegalArgumentException("certClass is null");
/*     */     }
/* 492 */     Certificate[] arrayOfCertificate = SecurityUtil.getCerts(paramClass);
/* 493 */     if (null != arrayOfCertificate) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 498 */       JarUtil.validateCertificates(arrayOfCertificate, paramJarFile);
/* 499 */       if (DEBUG) {
/* 500 */         System.err.println("TempJarCache: validateCertificates: OK - Matching rootCerts in given class " + paramClass.getName() + ", nativeJar " + paramJarFile.getName());
/*     */       }
/* 502 */     } else if (DEBUG) {
/* 503 */       System.err.println("TempJarCache: validateCertificates: OK - No rootCerts in given class " + paramClass.getName() + ", nativeJar " + paramJarFile.getName());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/cache/TempJarCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */