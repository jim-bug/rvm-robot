/*     */ package com.jogamp.common.util.cache;
/*     */ 
/*     */ import com.jogamp.common.util.IOUtil;
/*     */ import com.jogamp.common.util.InterruptSource;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TempFileCache
/*     */ {
/*  43 */   private static final boolean DEBUG = Debug.debug("TempFileCache");
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean staticInitError = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean staticTempIsExecutable = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String tmpDirPrefix = "file_cache";
/*     */ 
/*     */   
/*     */   private static final File tmpBaseDir;
/*     */ 
/*     */   
/*     */   static final String tmpRootPropName = "jnlp.jogamp.tmp.cache.root";
/*     */ 
/*     */   
/*     */   private static String tmpRootPropValue;
/*     */ 
/*     */   
/*     */   private static File tmpRootDir;
/*     */ 
/*     */   
/*     */   private boolean initError = false;
/*     */ 
/*     */   
/*     */   private File individualTmpDir;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  78 */     synchronized (System.out) {
/*     */ 
/*     */ 
/*     */       
/*  82 */       File file = null;
/*     */       try {
/*  84 */         file = new File(IOUtil.getTempDir(true), "file_cache");
/*  85 */         file = IOUtil.testDir(file, true, false);
/*  86 */         staticTempIsExecutable = true;
/*  87 */       } catch (Exception exception) {
/*  88 */         System.err.println("Warning: Caught Exception while retrieving executable temp base directory:");
/*  89 */         exception.printStackTrace();
/*  90 */         staticTempIsExecutable = false;
/*     */         try {
/*  92 */           file = new File(IOUtil.getTempDir(false), "file_cache");
/*  93 */           file = IOUtil.testDir(file, true, false);
/*  94 */         } catch (Exception exception1) {
/*  95 */           System.err.println("Warning: Caught Exception while retrieving non-executable temp base directory:");
/*  96 */           exception1.printStackTrace();
/*  97 */           staticInitError = true;
/*     */         } 
/*     */       } 
/* 100 */       tmpBaseDir = file;
/*     */       
/* 102 */       if (DEBUG) {
/* 103 */         String str = (null != tmpBaseDir) ? tmpBaseDir.getAbsolutePath() : null;
/* 104 */         System.err.println("TempFileCache: Static Initialization ---------------------------------------------- OK: " + (!staticInitError ? 1 : 0));
/* 105 */         System.err.println("TempFileCache: Thread: " + Thread.currentThread().getName() + ", CL 0x" + 
/* 106 */             Integer.toHexString(TempFileCache.class.getClassLoader().hashCode()) + ", tempBaseDir " + str + ", executable " + staticTempIsExecutable);
/*     */       } 
/*     */ 
/*     */       
/* 110 */       if (!staticInitError) {
/*     */         try {
/* 112 */           initTmpRoot();
/* 113 */         } catch (Exception exception) {
/* 114 */           System.err.println("Warning: Caught Exception due to initializing TmpRoot:");
/* 115 */           exception.printStackTrace();
/* 116 */           staticInitError = true;
/* 117 */           staticTempIsExecutable = false;
/*     */         } 
/*     */       }
/* 120 */       if (DEBUG) {
/* 121 */         System.err.println("------------------------------------------------------------------ OK: " + (!staticInitError ? 1 : 0));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean initSingleton() {
/* 131 */     return !staticInitError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initTmpRoot() throws IOException {
/* 186 */     tmpRootPropValue = System.getProperty("jnlp.jogamp.tmp.cache.root");
/*     */     
/* 188 */     if (tmpRootPropValue != null) {
/*     */       
/* 190 */       if (tmpRootPropValue.indexOf('/') >= 0 || tmpRootPropValue
/* 191 */         .indexOf(File.separatorChar) >= 0) {
/* 192 */         throw new IOException("Illegal value of: jnlp.jogamp.tmp.cache.root");
/*     */       }
/*     */ 
/*     */       
/* 196 */       if (DEBUG) {
/* 197 */         System.err.println("TempFileCache: Trying existing value of: jnlp.jogamp.tmp.cache.root=" + tmpRootPropValue);
/*     */       }
/*     */       
/* 200 */       tmpRootDir = new File(tmpBaseDir, tmpRootPropValue);
/* 201 */       if (DEBUG) {
/* 202 */         System.err.println("TempFileCache: Trying tmpRootDir = " + tmpRootDir.getAbsolutePath());
/*     */       }
/* 204 */       if (tmpRootDir.isDirectory()) {
/* 205 */         if (!tmpRootDir.canWrite()) {
/* 206 */           throw new IOException("Temp root directory is not writable: " + tmpRootDir.getAbsolutePath());
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 211 */         System.err.println("TempFileCache: None existing tmpRootDir = " + tmpRootDir.getAbsolutePath() + ", assuming new path due to update");
/* 212 */         tmpRootPropValue = null;
/* 213 */         tmpRootDir = null;
/* 214 */         System.clearProperty("jnlp.jogamp.tmp.cache.root");
/*     */       } 
/*     */     } 
/*     */     
/* 218 */     if (tmpRootPropValue == null) {
/*     */       
/* 220 */       File file1 = File.createTempFile("jln", ".tmp", tmpBaseDir);
/* 221 */       if (DEBUG) {
/* 222 */         System.err.println("TempFileCache: tmpFile = " + file1.getAbsolutePath());
/*     */       }
/* 224 */       final FileOutputStream tmpOut = new FileOutputStream(file1);
/* 225 */       FileChannel fileChannel1 = fileOutputStream1.getChannel();
/* 226 */       final FileLock tmpLock = fileChannel1.lock();
/*     */ 
/*     */       
/* 229 */       String str1 = file1.getAbsolutePath();
/* 230 */       String str2 = str1.substring(0, str1.lastIndexOf(".tmp"));
/*     */ 
/*     */       
/* 233 */       String str3 = str2 + ".lck";
/* 234 */       File file2 = new File(str3);
/* 235 */       if (DEBUG) {
/* 236 */         System.err.println("TempFileCache: lckFile = " + file2.getAbsolutePath());
/*     */       }
/* 238 */       file2.createNewFile();
/* 239 */       final FileOutputStream lckOut = new FileOutputStream(file2);
/* 240 */       FileChannel fileChannel2 = fileOutputStream2.getChannel();
/* 241 */       final FileLock lckLock = fileChannel2.lock();
/*     */ 
/*     */       
/* 244 */       tmpRootDir = new File(str2);
/* 245 */       if (DEBUG) {
/* 246 */         System.err.println("TempFileCache: tmpRootDir = " + tmpRootDir.getAbsolutePath());
/*     */       }
/* 248 */       if (!tmpRootDir.mkdir()) {
/* 249 */         throw new IOException("Cannot create " + tmpRootDir);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       Runtime.getRuntime().addShutdownHook((Thread)new InterruptSource.Thread()
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             public void run()
/*     */             {
/*     */               try {
/* 264 */                 tmpOut.close();
/* 265 */                 tmpLock.release();
/* 266 */                 lckOut.close();
/* 267 */                 lckLock.release();
/* 268 */               } catch (IOException iOException) {}
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 275 */       tmpRootPropValue = str2.substring(str2.lastIndexOf(File.separator) + 1);
/* 276 */       System.setProperty("jnlp.jogamp.tmp.cache.root", tmpRootPropValue);
/* 277 */       if (DEBUG) {
/* 278 */         System.err.println("TempFileCache: Setting jnlp.jogamp.tmp.cache.root=" + tmpRootPropValue);
/*     */       }
/*     */ 
/*     */       
/* 282 */       InterruptSource.Thread thread = new InterruptSource.Thread()
/*     */         {
/*     */           public void run()
/*     */           {
/* 286 */             TempFileCache.deleteOldTempDirs();
/*     */           }
/*     */         };
/* 289 */       thread.setName("TempFileCache-Reaper");
/* 290 */       thread.start();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void deleteOldTempDirs() {
/* 299 */     if (DEBUG) {
/* 300 */       System.err.println("TempFileCache: *** Reaper: deleteOldTempDirs in " + tmpBaseDir
/* 301 */           .getAbsolutePath());
/*     */     }
/*     */ 
/*     */     
/* 305 */     final String ourLockFile = tmpRootPropValue + ".lck";
/* 306 */     FilenameFilter filenameFilter = new FilenameFilter()
/*     */       {
/*     */         public boolean accept(File param1File, String param1String)
/*     */         {
/* 310 */           return (param1String.endsWith(".lck") && !param1String.equals(ourLockFile));
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     String[] arrayOfString = tmpBaseDir.list(filenameFilter);
/* 320 */     if (arrayOfString != null) {
/* 321 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 322 */         String str1 = arrayOfString[b];
/* 323 */         String str2 = str1.substring(0, str1.lastIndexOf(".lck"));
/* 324 */         String str3 = str2 + ".tmp";
/*     */         
/* 326 */         File file1 = new File(tmpBaseDir, str1);
/* 327 */         File file2 = new File(tmpBaseDir, str3);
/* 328 */         File file3 = new File(tmpBaseDir, str2);
/*     */         
/* 330 */         if (file1.exists() && file2.exists() && file3.isDirectory()) {
/* 331 */           FileOutputStream fileOutputStream = null;
/* 332 */           FileChannel fileChannel = null;
/* 333 */           FileLock fileLock = null;
/*     */           
/*     */           try {
/* 336 */             fileOutputStream = new FileOutputStream(file2);
/* 337 */             fileChannel = fileOutputStream.getChannel();
/* 338 */             fileLock = fileChannel.tryLock();
/* 339 */           } catch (Exception exception) {
/*     */             
/* 341 */             if (DEBUG) {
/* 342 */               exception.printStackTrace();
/*     */             }
/*     */           } 
/*     */           
/* 346 */           if (fileLock != null) {
/* 347 */             FileOutputStream fileOutputStream1 = null;
/* 348 */             FileChannel fileChannel1 = null;
/* 349 */             FileLock fileLock1 = null;
/*     */             
/*     */             try {
/* 352 */               fileOutputStream1 = new FileOutputStream(file1);
/* 353 */               fileChannel1 = fileOutputStream1.getChannel();
/* 354 */               fileLock1 = fileChannel1.tryLock();
/* 355 */             } catch (Exception exception) {
/* 356 */               if (DEBUG) {
/* 357 */                 exception.printStackTrace();
/*     */               }
/*     */             } 
/*     */             
/* 361 */             if (fileLock1 != null) {
/*     */ 
/*     */               
/* 364 */               removeAll(file3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               try {
/* 374 */                 fileOutputStream1.close();
/* 375 */               } catch (IOException iOException) {}
/*     */               
/* 377 */               file1.delete();
/*     */               try {
/* 379 */                 fileOutputStream.close();
/* 380 */               } catch (IOException iOException) {}
/*     */               
/* 382 */               file2.delete();
/*     */             } else {
/*     */               
/*     */               try {
/* 386 */                 if (fileOutputStream1 != null) {
/* 387 */                   fileOutputStream1.close();
/*     */                 }
/*     */ 
/*     */                 
/* 391 */                 fileOutputStream.close();
/* 392 */                 fileLock.release();
/* 393 */               } catch (IOException iOException) {
/* 394 */                 if (DEBUG) {
/* 395 */                   iOException.printStackTrace();
/*     */                 }
/*     */               }
/*     */             
/*     */             } 
/*     */           } 
/* 401 */         } else if (DEBUG) {
/* 402 */           System.err.println("TempFileCache: Skipping: " + file3.getAbsolutePath());
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void removeAll(File paramFile) {
/* 414 */     if (DEBUG) {
/* 415 */       System.err.println("TempFileCache: removeAll(" + paramFile + ")");
/*     */     }
/*     */     
/* 418 */     if (paramFile.isDirectory()) {
/*     */       
/* 420 */       File[] arrayOfFile = paramFile.listFiles();
/* 421 */       if (arrayOfFile != null) {
/* 422 */         for (byte b = 0; b < arrayOfFile.length; b++) {
/* 423 */           removeAll(arrayOfFile[b]);
/*     */         }
/*     */       }
/*     */     } 
/* 427 */     paramFile.delete();
/*     */   }
/*     */ 
/*     */   
/*     */   public TempFileCache() {
/* 432 */     if (DEBUG) {
/* 433 */       System.err.println("TempFileCache: new TempFileCache() --------------------- (static ok: " + (!staticInitError ? 1 : 0) + ")");
/* 434 */       System.err.println("TempFileCache: Thread: " + Thread.currentThread().getName() + ", CL 0x" + Integer.toHexString(TempFileCache.class.getClassLoader().hashCode()) + ", this 0x" + Integer.toHexString(hashCode()));
/*     */     } 
/* 436 */     if (!staticInitError) {
/*     */       try {
/* 438 */         createTmpDir();
/* 439 */       } catch (Exception exception) {
/* 440 */         exception.printStackTrace();
/* 441 */         this.initError = true;
/*     */       } 
/*     */     }
/* 444 */     if (DEBUG) {
/* 445 */       System.err.println("TempFileCache: tempDir " + this.individualTmpDir + " (ok: " + (!this.initError ? 1 : 0) + ")");
/* 446 */       System.err.println("----------------------------------------------------------");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 452 */     if (DEBUG) {
/* 453 */       System.err.println("TempFileCache: destroy() --------------------- (static ok: " + (!staticInitError ? 1 : 0) + ")");
/* 454 */       System.err.println("TempFileCache: Thread: " + Thread.currentThread().getName() + ", CL 0x" + Integer.toHexString(TempFileCache.class.getClassLoader().hashCode()) + ", this 0x" + Integer.toHexString(hashCode()));
/*     */     } 
/* 456 */     if (!staticInitError) {
/*     */       try {
/* 458 */         removeAll(this.individualTmpDir);
/* 459 */       } catch (Exception exception) {
/* 460 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/* 463 */     this.individualTmpDir = null;
/* 464 */     if (DEBUG) {
/* 465 */       System.err.println("TempFileCache: destroy() END");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid(boolean paramBoolean) {
/* 476 */     return (!staticInitError && !this.initError && (!paramBoolean || staticTempIsExecutable));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getBaseDir() {
/* 493 */     return tmpBaseDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getRootDir() {
/* 522 */     return tmpRootDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getTempDir() {
/* 546 */     return this.individualTmpDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createTmpDir() throws IOException {
/* 557 */     File file = File.createTempFile("jln", ".tmp", tmpRootDir);
/* 558 */     String str1 = file.getAbsolutePath();
/* 559 */     String str2 = str1.substring(0, str1.lastIndexOf(".tmp"));
/* 560 */     this.individualTmpDir = new File(str2);
/* 561 */     if (!this.individualTmpDir.mkdir())
/* 562 */       throw new IOException("Cannot create " + this.individualTmpDir); 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/cache/TempFileCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */