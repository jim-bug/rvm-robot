/*    */ package com.jogamp.common.util.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TempCacheReg
/*    */ {
/*    */   public static boolean isTempFileCacheUsed() {
/* 32 */     return (null != System.getProperty("jnlp.jogamp.tmp.cache.root"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isTempJarCacheUsed(boolean paramBoolean) {
/* 39 */     return TempJarCache.isInitialized(paramBoolean);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/util/cache/TempCacheReg.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */