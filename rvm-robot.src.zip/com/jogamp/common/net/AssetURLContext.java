/*     */ package com.jogamp.common.net;
/*     */ 
/*     */ import com.jogamp.common.os.AndroidVersion;
/*     */ import com.jogamp.common.util.IOUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AssetURLContext
/*     */   implements PiggybackURLContext
/*     */ {
/*  19 */   private static final boolean DEBUG = IOUtil.DEBUG;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String asset_protocol = "asset";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String asset_protocol_prefix = "asset:";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String assets_folder = "assets/";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssetURLContext create(final ClassLoader cl) {
/*  37 */     return new AssetURLContext()
/*     */       {
/*     */         public ClassLoader getClassLoader() {
/*  40 */           return cl;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public static AssetURLStreamHandler createHandler(ClassLoader paramClassLoader) {
/*  46 */     return new AssetURLStreamHandler(create(paramClassLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL createURL(String paramString, ClassLoader paramClassLoader) throws MalformedURLException {
/*  63 */     return new URL(null, paramString.startsWith("asset:") ? paramString : ("asset:" + paramString), createHandler(paramClassLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL createURL(String paramString) throws MalformedURLException {
/*  79 */     return new URL(paramString.startsWith("asset:") ? paramString : ("asset:" + paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URLStreamHandler getRegisteredHandler() {
/*  87 */     GenericURLStreamHandlerFactory genericURLStreamHandlerFactory = GenericURLStreamHandlerFactory.register();
/*  88 */     return (null != genericURLStreamHandlerFactory) ? genericURLStreamHandlerFactory.getHandler("asset") : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean registerHandler(ClassLoader paramClassLoader) {
/*  98 */     GenericURLStreamHandlerFactory genericURLStreamHandlerFactory = GenericURLStreamHandlerFactory.register();
/*  99 */     if (null != genericURLStreamHandlerFactory) {
/* 100 */       genericURLStreamHandlerFactory.setHandler("asset", createHandler(paramClassLoader));
/* 101 */       return true;
/*     */     } 
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ClassLoader getClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImplementedProtocol() {
/* 125 */     return "asset";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLConnection resolve(String paramString) throws IOException {
/* 145 */     return resolve(paramString, getClassLoader());
/*     */   }
/*     */   
/*     */   public static URLConnection resolve(String paramString, ClassLoader paramClassLoader) throws IOException {
/* 149 */     URL uRL = null;
/* 150 */     URLConnection uRLConnection = null;
/* 151 */     byte b = -1;
/*     */     
/* 153 */     if (DEBUG) {
/* 154 */       System.err.println("AssetURLContext.resolve: <" + paramString + ">");
/*     */     }
/*     */     try {
/* 157 */       paramString = IOUtil.cleanPathString(paramString);
/* 158 */     } catch (URISyntaxException uRISyntaxException) {
/* 159 */       throw new IOException(uRISyntaxException);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 164 */     try { uRL = new URL(paramString);
/* 165 */       uRLConnection = open(uRL);
/* 166 */       b = (null != uRLConnection) ? 1 : -1; }
/* 167 */     catch (MalformedURLException malformedURLException) { if (DEBUG) System.err.println("FAIL(1): " + malformedURLException.getMessage());  }
/*     */     
/* 169 */     if (null == uRLConnection && null != paramClassLoader) {
/*     */       
/* 171 */       String str = paramString;
/* 172 */       while (str.startsWith("/")) {
/* 173 */         str = str.substring(1);
/*     */       }
/* 175 */       if (AndroidVersion.isAvailable) {
/* 176 */         str = str.startsWith("assets/") ? str : ("assets/" + str);
/*     */       }
/* 178 */       uRL = paramClassLoader.getResource(str);
/* 179 */       uRLConnection = open(uRL);
/* 180 */       b = (null != uRLConnection) ? 2 : -1;
/*     */     } 
/*     */     
/* 183 */     if (null == uRLConnection)
/*     */ 
/*     */       
/* 186 */       try { File file = new File(paramString);
/* 187 */         if (file.exists()) {
/* 188 */           uRL = Uri.valueOf(file).toURL();
/* 189 */           uRLConnection = open(uRL);
/* 190 */           b = (null != uRLConnection) ? 3 : -1;
/*     */         }  }
/* 192 */       catch (Throwable throwable) { if (DEBUG) System.err.println("FAIL(3): " + throwable.getMessage());
/*     */          }
/*     */        
/* 195 */     if (DEBUG) {
/* 196 */       System.err.println("AssetURLContext.resolve: type " + b + ": url <" + uRL + ">, conn <" + uRLConnection + ">, connURL <" + ((null != uRLConnection) ? (String)uRLConnection.getURL() : null) + ">");
/*     */     }
/* 198 */     if (null == uRLConnection) {
/* 199 */       throw new FileNotFoundException("Could not look-up: " + paramString + " as URL, w/ ClassLoader or as File");
/*     */     }
/* 201 */     return uRLConnection;
/*     */   }
/*     */   
/*     */   private static URLConnection open(URL paramURL) {
/* 205 */     if (null == paramURL) {
/* 206 */       return null;
/*     */     }
/*     */     
/* 209 */     try { URLConnection uRLConnection = paramURL.openConnection();
/* 210 */       uRLConnection.connect();
/* 211 */       return uRLConnection; }
/* 212 */     catch (IOException iOException) { if (DEBUG) System.err.println("FAIL(2): " + iOException.getMessage()); 
/* 213 */       return null; }
/*     */   
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/AssetURLContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */