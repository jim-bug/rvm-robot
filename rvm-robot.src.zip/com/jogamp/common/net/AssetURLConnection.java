/*    */ package com.jogamp.common.net;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.JarURLConnection;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssetURLConnection
/*    */   extends PiggybackURLConnection<AssetURLContext>
/*    */ {
/*    */   public AssetURLConnection(URL paramURL, AssetURLContext paramAssetURLContext) {
/* 75 */     super(paramURL, paramAssetURLContext);
/*    */   }
/*    */   
/*    */   public String getEntryName() throws IOException {
/*    */     String str;
/* 80 */     if (!this.connected) {
/* 81 */       throw new IOException("not connected");
/*    */     }
/*    */ 
/*    */     
/* 85 */     if (this.subConn instanceof JarURLConnection) {
/* 86 */       str = ((JarURLConnection)this.subConn).getEntryName();
/*    */     } else {
/* 88 */       str = this.subConn.getURL().getPath();
/*    */     } 
/*    */     
/* 91 */     if (str.startsWith("assets/")) {
/* 92 */       return str.substring("assets/".length());
/*    */     }
/* 94 */     return str;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/AssetURLConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */