/*      */ package com.jogamp.common.net;
/*      */ 
/*      */ import com.jogamp.common.util.IOUtil;
/*      */ import com.jogamp.common.util.PropertyAccess;
/*      */ import java.io.File;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.regex.Pattern;
/*      */ import jogamp.common.Debug;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Uri
/*      */ {
/*      */   static {
/*  165 */     Debug.initSingleton();
/*  166 */   } private static final boolean DEBUG = (IOUtil.DEBUG || Debug.debug("Uri"));
/*  167 */   private static final boolean DEBUG_SHOWFIX = PropertyAccess.isPropertyDefined("jogamp.debug.Uri.ShowFix", true);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int PARSE_HINT_FIX_PATH = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DIGITS = "0123456789ABCDEF";
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String ENCODING = "UTF8";
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String MSG_ENCODING_NA = "Charset UTF8 not available";
/*      */ 
/*      */ 
/*      */   
/*  188 */   private static final Pattern patternSingleFS = Pattern.compile("/{1}");
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String UNRESERVED = "_-.~";
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String punct = ",;:$&+=";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String RESERVED = ",;:$&+=!*'()@/?#[]";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String RESERVED_2 = ",;:$&+=!*'()@/?[]";
/*      */ 
/*      */   
/*      */   public static final String USERINFO_LEGAL = "_-.~,;:$&+=";
/*      */ 
/*      */   
/*      */   public static final String AUTHORITY_LEGAL = "@[]_-.~,;:$&+=";
/*      */ 
/*      */   
/*      */   public static final String PATH_LEGAL = "/!_-.~";
/*      */ 
/*      */   
/*      */   public static final String QUERY_LEGAL = "_-.~,;:$&+=!*'()@/?[]\\\"";
/*      */ 
/*      */   
/*      */   public static final String SSP_LEGAL = "_-.~,;:$&+=!*'()@/?[]\\\"";
/*      */ 
/*      */   
/*      */   public static final String FRAG_LEGAL = "_-.~,;:$&+=!*'()@/?#[]";
/*      */ 
/*      */   
/*      */   public static final char SCHEME_SEPARATOR = ':';
/*      */ 
/*      */   
/*      */   public static final char QUERY_SEPARATOR = '?';
/*      */ 
/*      */   
/*      */   public static final char FRAGMENT_SEPARATOR = '#';
/*      */ 
/*      */   
/*      */   public static final String FILE_SCHEME = "file";
/*      */ 
/*      */   
/*      */   public static final String HTTP_SCHEME = "http";
/*      */ 
/*      */   
/*      */   public static final String HTTPS_SCHEME = "https";
/*      */ 
/*      */   
/*      */   public static final String JAR_SCHEME = "jar";
/*      */ 
/*      */   
/*      */   public static final char JAR_SCHEME_SEPARATOR = '!';
/*      */ 
/*      */   
/*      */   public final Encoded input;
/*      */ 
/*      */   
/*      */   private final Object lazyLock;
/*      */ 
/*      */   
/*      */   private ASCIIEncoded inputASCII;
/*      */ 
/*      */   
/*      */   private int hash;
/*      */ 
/*      */   
/*      */   public final Encoded scheme;
/*      */ 
/*      */   
/*      */   public final Encoded schemeSpecificPart;
/*      */ 
/*      */   
/*      */   public final Encoded path;
/*      */ 
/*      */   
/*      */   public final boolean hasAuthority;
/*      */ 
/*      */   
/*      */   public final Encoded authority;
/*      */ 
/*      */   
/*      */   public final Encoded userInfo;
/*      */ 
/*      */   
/*      */   public final Encoded host;
/*      */ 
/*      */   
/*      */   public final int port;
/*      */ 
/*      */   
/*      */   public final Encoded query;
/*      */ 
/*      */   
/*      */   public final Encoded fragment;
/*      */ 
/*      */   
/*      */   public final boolean absolute;
/*      */ 
/*      */   
/*      */   public final boolean opaque;
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Encoded
/*      */     implements Comparable<Encoded>, CharSequence
/*      */   {
/*      */     private final String s;
/*      */ 
/*      */ 
/*      */     
/*      */     public static Encoded cast(String param1String) {
/*  306 */       return new Encoded(param1String);
/*      */     }
/*      */     
/*      */     Encoded(String param1String) {
/*  310 */       this.s = param1String;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Encoded(String param1String1, String param1String2) {
/*  330 */       this.s = Uri.encode(param1String1, param1String2);
/*      */     }
/*      */     public boolean isASCII() {
/*  333 */       return false;
/*      */     }
/*      */     public final String get() {
/*  336 */       return this.s;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final String decode() {
/*  353 */       return Uri.decode(this.s);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final String toString() {
/*  366 */       return this.s;
/*      */     }
/*      */     public final int hashCode() {
/*  369 */       return this.s.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean equals(Object param1Object) {
/*  384 */       if (this == param1Object) {
/*  385 */         return true;
/*      */       }
/*  387 */       if (param1Object instanceof Encoded) {
/*  388 */         return this.s.equals(((Encoded)param1Object).s);
/*      */       }
/*  390 */       return this.s.equals(param1Object);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int length() {
/*  398 */       return this.s.length();
/*      */     }
/*      */     public final char charAt(int param1Int) {
/*  401 */       return this.s.charAt(param1Int);
/*      */     }
/*      */     public final CharSequence subSequence(int param1Int1, int param1Int2) {
/*  404 */       return this.s.subSequence(param1Int1, param1Int2);
/*      */     }
/*      */     public final int compareTo(Encoded param1Encoded) {
/*  407 */       return this.s.compareTo(param1Encoded.s);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Encoded concat(Encoded param1Encoded) {
/*  413 */       return new Encoded(this.s.concat(param1Encoded.s));
/*      */     }
/*      */     public final Encoded substring(int param1Int) {
/*  416 */       return new Encoded(this.s.substring(param1Int));
/*      */     } public final Encoded substring(int param1Int1, int param1Int2) {
/*  418 */       return new Encoded(this.s.substring(param1Int1, param1Int2));
/*      */     }
/*      */     public final int indexOf(int param1Int) {
/*  421 */       return this.s.indexOf(param1Int);
/*      */     } public final int indexOf(int param1Int1, int param1Int2) {
/*  423 */       return this.s.indexOf(param1Int1, param1Int2);
/*      */     } public final int indexOf(String param1String) {
/*  425 */       return this.s.indexOf(param1String);
/*      */     } public final int indexOf(String param1String, int param1Int) {
/*  427 */       return this.s.indexOf(param1String, param1Int);
/*      */     }
/*      */     public final int lastIndexOf(int param1Int) {
/*  430 */       return this.s.lastIndexOf(param1Int);
/*      */     } public int lastIndexOf(int param1Int1, int param1Int2) {
/*  432 */       return this.s.lastIndexOf(param1Int1, param1Int2);
/*      */     } public int lastIndexOf(String param1String) {
/*  434 */       return this.s.lastIndexOf(param1String);
/*      */     } public int lastIndexOf(String param1String, int param1Int) {
/*  436 */       return this.s.lastIndexOf(param1String, param1Int);
/*      */     }
/*      */     public boolean startsWith(String param1String) {
/*  439 */       return this.s.startsWith(param1String);
/*      */     } public boolean startsWith(String param1String, int param1Int) {
/*  441 */       return this.s.startsWith(param1String, param1Int);
/*      */     } public boolean endsWith(String param1String) {
/*  443 */       return this.s.endsWith(param1String);
/*      */     }
/*      */     public final boolean equalsIgnoreCase(Encoded param1Encoded) {
/*  446 */       return this.s.equalsIgnoreCase(param1Encoded.s);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ASCIIEncoded
/*      */     extends Encoded
/*      */   {
/*      */     public static ASCIIEncoded cast(String param1String) {
/*  457 */       return new ASCIIEncoded(param1String, null);
/*      */     }
/*      */     private ASCIIEncoded(String param1String, Object param1Object) {
/*  460 */       super(param1String);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ASCIIEncoded(String param1String) {
/*  476 */       super(Uri.encodeToASCIIString(param1String));
/*      */     } public boolean isASCII() {
/*  478 */       return true;
/*      */     } }
/*      */   
/*      */   private static void encodeChar2UTF8(StringBuilder paramStringBuilder, char paramChar) {
/*      */     byte[] arrayOfByte;
/*      */     try {
/*  484 */       arrayOfByte = (new String(new char[] { paramChar })).getBytes("UTF8");
/*  485 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  486 */       throw new RuntimeException("Charset UTF8 not available", unsupportedEncodingException);
/*      */     } 
/*      */     
/*  489 */     for (byte b = 0; b < arrayOfByte.length; b++) {
/*  490 */       byte b1 = arrayOfByte[b];
/*  491 */       paramStringBuilder.append('%');
/*  492 */       paramStringBuilder.append("0123456789ABCDEF".charAt((b1 & 0xF0) >> 4));
/*  493 */       paramStringBuilder.append("0123456789ABCDEF".charAt(b1 & 0xF));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encode(String paramString1, String paramString2) {
/*  519 */     if (null == paramString1) {
/*  520 */       return null;
/*      */     }
/*  522 */     StringBuilder stringBuilder = new StringBuilder();
/*  523 */     for (byte b = 0; b < paramString1.length(); b++) {
/*  524 */       char c = paramString1.charAt(b);
/*  525 */       if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || paramString2
/*      */ 
/*      */         
/*  528 */         .indexOf(c) > -1 || (c > '' && 
/*  529 */         !Character.isSpaceChar(c) && !Character.isISOControl(c))) {
/*      */         
/*  531 */         stringBuilder.append(c);
/*      */       } else {
/*  533 */         encodeChar2UTF8(stringBuilder, c);
/*      */       } 
/*      */     } 
/*  536 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeToASCIIString(String paramString) {
/*  554 */     StringBuilder stringBuilder = new StringBuilder();
/*  555 */     for (byte b = 0; b < paramString.length(); b++) {
/*  556 */       char c = paramString.charAt(b);
/*  557 */       if (c <= '') {
/*  558 */         stringBuilder.append(c);
/*      */       } else {
/*  560 */         encodeChar2UTF8(stringBuilder, c);
/*      */       } 
/*      */     } 
/*  563 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String decode(Encoded paramEncoded) {
/*  572 */     return (null != paramEncoded) ? paramEncoded.decode() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String decode(String paramString) {
/*  591 */     if (null == paramString) {
/*  592 */       return null;
/*      */     }
/*  594 */     StringBuilder stringBuilder = new StringBuilder();
/*  595 */     byte[] arrayOfByte = new byte[32];
/*  596 */     byte b1 = 0;
/*  597 */     for (byte b2 = 0; b2 < paramString.length(); ) {
/*  598 */       char c = paramString.charAt(b2);
/*  599 */       if (c == '%') {
/*  600 */         b1 = 0;
/*      */         do {
/*  602 */           if (b2 + 2 >= paramString.length()) {
/*  603 */             throw new IllegalArgumentException("missing '%' hex-digits at index " + b2);
/*      */           }
/*  605 */           int i = Character.digit(paramString.charAt(b2 + 1), 16);
/*  606 */           int j = Character.digit(paramString.charAt(b2 + 2), 16);
/*  607 */           if (i == -1 || j == -1) {
/*  608 */             throw new IllegalArgumentException("invalid hex-digits at index " + b2 + ": " + paramString.substring(b2, b2 + 3));
/*      */           }
/*  610 */           arrayOfByte[b1++] = (byte)((i << 4) + j);
/*  611 */           if (32 != b1)
/*  612 */             continue;  appendUTF8(stringBuilder, arrayOfByte, b1);
/*  613 */           b1 = 0;
/*      */           
/*  615 */           b2 += 3;
/*  616 */         } while (b2 < paramString.length() && paramString.charAt(b2) == '%');
/*  617 */         if (0 < b1)
/*  618 */           appendUTF8(stringBuilder, arrayOfByte, b1); 
/*      */         continue;
/*      */       } 
/*  621 */       stringBuilder.append(c);
/*  622 */       b2++;
/*      */     } 
/*      */     
/*  625 */     return stringBuilder.toString();
/*      */   }
/*      */   private static void appendUTF8(StringBuilder paramStringBuilder, byte[] paramArrayOfbyte, int paramInt) {
/*      */     try {
/*  629 */       paramStringBuilder.append(new String(paramArrayOfbyte, 0, paramInt, "UTF8"));
/*  630 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  631 */       throw new RuntimeException("Charset UTF8 not available", unsupportedEncodingException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri create(String paramString1, String paramString2, String paramString3) throws URISyntaxException {
/*  656 */     if (emptyString(paramString1) && emptyString(paramString2) && emptyString(paramString3)) {
/*  657 */       throw new URISyntaxException("", "all empty parts");
/*      */     }
/*  659 */     StringBuilder stringBuilder = new StringBuilder();
/*  660 */     if (!emptyString(paramString1)) {
/*  661 */       stringBuilder.append(paramString1);
/*  662 */       stringBuilder.append(':');
/*      */     } 
/*  664 */     if (!emptyString(paramString2))
/*      */     {
/*  666 */       stringBuilder.append(encode(paramString2, "_-.~,;:$&+=!*'()@/?[]\\\""));
/*      */     }
/*  668 */     if (!emptyString(paramString3)) {
/*  669 */       stringBuilder.append('#');
/*      */       
/*  671 */       stringBuilder.append(encode(paramString3, "_-.~,;:$&+=!*'()@/?#[]"));
/*      */     } 
/*  673 */     return new Uri(new Encoded(stringBuilder.toString()), false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri create(Encoded paramEncoded1, Encoded paramEncoded2, Encoded paramEncoded3) throws URISyntaxException {
/*  701 */     if (emptyString(paramEncoded1) && emptyString(paramEncoded2) && emptyString(paramEncoded3)) {
/*  702 */       throw new URISyntaxException("", "all empty parts");
/*      */     }
/*  704 */     StringBuilder stringBuilder = new StringBuilder();
/*  705 */     if (!emptyString(paramEncoded1)) {
/*  706 */       stringBuilder.append(paramEncoded1);
/*  707 */       stringBuilder.append(':');
/*      */     } 
/*  709 */     if (!emptyString(paramEncoded2)) {
/*  710 */       stringBuilder.append(paramEncoded2.get());
/*      */     }
/*  712 */     if (!emptyString(paramEncoded3)) {
/*  713 */       stringBuilder.append('#');
/*  714 */       stringBuilder.append(paramEncoded3.get());
/*      */     } 
/*  716 */     return new Uri(new Encoded(stringBuilder.toString()), false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri create(String paramString1, String paramString2, String paramString3, int paramInt, String paramString4, String paramString5, String paramString6) throws URISyntaxException {
/*  746 */     if (emptyString(paramString1) && emptyString(paramString2) && emptyString(paramString3) && emptyString(paramString4) && 
/*  747 */       emptyString(paramString5) && emptyString(paramString6)) {
/*  748 */       throw new URISyntaxException("", "all empty parts");
/*      */     }
/*      */     
/*  751 */     if (!emptyString(paramString1) && !emptyString(paramString4) && paramString4.length() > 0 && paramString4.charAt(0) != '/') {
/*  752 */       throw new URISyntaxException(paramString4, "path doesn't start with '/'");
/*      */     }
/*      */     
/*  755 */     StringBuilder stringBuilder = new StringBuilder();
/*  756 */     if (!emptyString(paramString1)) {
/*  757 */       stringBuilder.append(paramString1);
/*  758 */       stringBuilder.append(':');
/*      */     } 
/*      */     
/*  761 */     if (!emptyString(paramString2) || !emptyString(paramString3) || paramInt != -1) {
/*  762 */       stringBuilder.append("//");
/*      */     }
/*      */     
/*  765 */     if (!emptyString(paramString2)) {
/*      */       
/*  767 */       stringBuilder.append(encode(paramString2, "_-.~,;:$&+="));
/*  768 */       stringBuilder.append('@');
/*      */     } 
/*      */     
/*  771 */     if (!emptyString(paramString3)) {
/*      */ 
/*      */       
/*  774 */       if (paramString3.indexOf(':') != -1 && paramString3.indexOf(']') == -1 && paramString3
/*  775 */         .indexOf('[') == -1) {
/*  776 */         paramString3 = "[" + paramString3 + "]";
/*      */       }
/*  778 */       stringBuilder.append(paramString3);
/*      */     } 
/*      */     
/*  781 */     if (paramInt != -1) {
/*  782 */       stringBuilder.append(':');
/*  783 */       stringBuilder.append(paramInt);
/*      */     } 
/*      */     
/*  786 */     if (!emptyString(paramString4))
/*      */     {
/*  788 */       stringBuilder.append(encode(paramString4, "/!_-.~"));
/*      */     }
/*      */     
/*  791 */     if (!emptyString(paramString5)) {
/*  792 */       stringBuilder.append('?');
/*      */       
/*  794 */       stringBuilder.append(encode(paramString5, "_-.~,;:$&+=!*'()@/?[]\\\""));
/*      */     } 
/*      */     
/*  797 */     if (!emptyString(paramString6)) {
/*      */       
/*  799 */       stringBuilder.append('#');
/*  800 */       stringBuilder.append(encode(paramString6, "_-.~,;:$&+=!*'()@/?#[]"));
/*      */     } 
/*  802 */     return new Uri(new Encoded(stringBuilder.toString()), true, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri create(Encoded paramEncoded1, Encoded paramEncoded2, Encoded paramEncoded3, int paramInt, Encoded paramEncoded4, Encoded paramEncoded5, Encoded paramEncoded6) throws URISyntaxException {
/*  836 */     if (emptyString(paramEncoded1) && emptyString(paramEncoded2) && emptyString(paramEncoded3) && emptyString(paramEncoded4) && 
/*  837 */       emptyString(paramEncoded5) && emptyString(paramEncoded6)) {
/*  838 */       throw new URISyntaxException("", "all empty parts");
/*      */     }
/*      */     
/*  841 */     if (!emptyString(paramEncoded1) && !emptyString(paramEncoded4) && paramEncoded4.length() > 0 && paramEncoded4.charAt(0) != '/') {
/*  842 */       throw new URISyntaxException(paramEncoded4.get(), "path doesn't start with '/'");
/*      */     }
/*      */     
/*  845 */     StringBuilder stringBuilder = new StringBuilder();
/*  846 */     if (!emptyString(paramEncoded1)) {
/*  847 */       stringBuilder.append(paramEncoded1);
/*  848 */       stringBuilder.append(':');
/*      */     } 
/*      */     
/*  851 */     if (!emptyString(paramEncoded2) || !emptyString(paramEncoded3) || paramInt != -1) {
/*  852 */       stringBuilder.append("//");
/*      */     }
/*      */     
/*  855 */     if (!emptyString(paramEncoded2)) {
/*  856 */       stringBuilder.append(paramEncoded2.get());
/*  857 */       stringBuilder.append('@');
/*      */     } 
/*      */     
/*  860 */     if (!emptyString(paramEncoded3)) {
/*  861 */       stringBuilder.append(paramEncoded3.get());
/*      */     }
/*      */     
/*  864 */     if (paramInt != -1) {
/*  865 */       stringBuilder.append(':');
/*  866 */       stringBuilder.append(paramInt);
/*      */     } 
/*      */     
/*  869 */     if (!emptyString(paramEncoded4)) {
/*  870 */       stringBuilder.append(paramEncoded4.get());
/*      */     }
/*      */     
/*  873 */     if (!emptyString(paramEncoded5)) {
/*  874 */       stringBuilder.append('?');
/*  875 */       stringBuilder.append(paramEncoded5.get());
/*      */     } 
/*      */     
/*  878 */     if (!emptyString(paramEncoded6)) {
/*  879 */       stringBuilder.append('#');
/*  880 */       stringBuilder.append(paramEncoded6.get());
/*      */     } 
/*  882 */     return new Uri(new Encoded(stringBuilder.toString()), true, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri create(String paramString1, String paramString2, String paramString3, String paramString4) throws URISyntaxException {
/*  907 */     return create(paramString1, (String)null, paramString2, -1, paramString3, (String)null, paramString4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri create(Encoded paramEncoded1, Encoded paramEncoded2, Encoded paramEncoded3, Encoded paramEncoded4) throws URISyntaxException {
/*  936 */     return create(paramEncoded1, (Encoded)null, paramEncoded2, -1, paramEncoded3, (Encoded)null, paramEncoded4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri create(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) throws URISyntaxException {
/*  963 */     if (emptyString(paramString1) && emptyString(paramString2) && emptyString(paramString3) && 
/*  964 */       emptyString(paramString4) && emptyString(paramString5)) {
/*  965 */       throw new URISyntaxException("", "all empty parts");
/*      */     }
/*  967 */     if (!emptyString(paramString1) && !emptyString(paramString3) && paramString3.length() > 0 && paramString3.charAt(0) != '/') {
/*  968 */       throw new URISyntaxException(paramString3, "path doesn't start with '/'");
/*      */     }
/*      */     
/*  971 */     StringBuilder stringBuilder = new StringBuilder();
/*  972 */     if (!emptyString(paramString1)) {
/*  973 */       stringBuilder.append(paramString1);
/*  974 */       stringBuilder.append(':');
/*      */     } 
/*  976 */     if (!emptyString(paramString2)) {
/*  977 */       stringBuilder.append("//");
/*      */       
/*  979 */       stringBuilder.append(encode(paramString2, "@[]_-.~,;:$&+="));
/*      */     } 
/*      */     
/*  982 */     if (!emptyString(paramString3))
/*      */     {
/*  984 */       stringBuilder.append(encode(paramString3, "/!_-.~"));
/*      */     }
/*  986 */     if (!emptyString(paramString4)) {
/*      */       
/*  988 */       stringBuilder.append('?');
/*  989 */       stringBuilder.append(encode(paramString4, "_-.~,;:$&+=!*'()@/?[]\\\""));
/*      */     } 
/*  991 */     if (!emptyString(paramString5)) {
/*      */       
/*  993 */       stringBuilder.append('#');
/*  994 */       stringBuilder.append(encode(paramString5, "_-.~,;:$&+=!*'()@/?#[]"));
/*      */     } 
/*  996 */     return new Uri(new Encoded(stringBuilder.toString()), false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri create(Encoded paramEncoded1, Encoded paramEncoded2, Encoded paramEncoded3, Encoded paramEncoded4, Encoded paramEncoded5) throws URISyntaxException {
/* 1027 */     if (emptyString(paramEncoded1) && emptyString(paramEncoded2) && emptyString(paramEncoded3) && 
/* 1028 */       emptyString(paramEncoded4) && emptyString(paramEncoded5)) {
/* 1029 */       throw new URISyntaxException("", "all empty parts");
/*      */     }
/* 1031 */     if (!emptyString(paramEncoded1) && !emptyString(paramEncoded3) && paramEncoded3.length() > 0 && paramEncoded3.charAt(0) != '/') {
/* 1032 */       throw new URISyntaxException(paramEncoded3.get(), "path doesn't start with '/'");
/*      */     }
/*      */     
/* 1035 */     StringBuilder stringBuilder = new StringBuilder();
/* 1036 */     if (!emptyString(paramEncoded1)) {
/* 1037 */       stringBuilder.append(paramEncoded1);
/* 1038 */       stringBuilder.append(':');
/*      */     } 
/* 1040 */     if (!emptyString(paramEncoded2)) {
/* 1041 */       stringBuilder.append("//");
/* 1042 */       stringBuilder.append(paramEncoded2.get());
/*      */     } 
/*      */     
/* 1045 */     if (!emptyString(paramEncoded3)) {
/* 1046 */       stringBuilder.append(paramEncoded3.get());
/*      */     }
/* 1048 */     if (!emptyString(paramEncoded4)) {
/* 1049 */       stringBuilder.append('?');
/* 1050 */       stringBuilder.append(paramEncoded4.get());
/*      */     } 
/* 1052 */     if (!emptyString(paramEncoded5)) {
/* 1053 */       stringBuilder.append('#');
/* 1054 */       stringBuilder.append(paramEncoded5.get());
/*      */     } 
/* 1056 */     return new Uri(new Encoded(stringBuilder.toString()), false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri cast(String paramString) throws URISyntaxException {
/* 1068 */     return new Uri(Encoded.cast(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri valueOfFilepath(String paramString) throws URISyntaxException {
/* 1087 */     if (emptyString(paramString)) {
/* 1088 */       throw new URISyntaxException("", "empty path");
/*      */     }
/* 1090 */     if (paramString.charAt(0) != '/') {
/* 1091 */       throw new URISyntaxException(paramString, "path doesn't start with '/'");
/*      */     }
/*      */     
/* 1094 */     StringBuilder stringBuilder = new StringBuilder();
/* 1095 */     stringBuilder.append("file");
/* 1096 */     stringBuilder.append(':');
/*      */ 
/*      */     
/* 1099 */     stringBuilder.append(encode(paramString, "/!_-.~"));
/*      */     
/* 1101 */     return new Uri(new Encoded(stringBuilder.toString()), false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri valueOf(File paramFile) throws URISyntaxException {
/* 1121 */     return valueOfFilepath(IOUtil.slashify(paramFile.getAbsolutePath(), true, paramFile.isDirectory()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri valueOf(URI paramURI) throws URISyntaxException {
/* 1139 */     if (paramURI.isOpaque())
/*      */     {
/*      */       
/* 1142 */       return new Uri(new Encoded(paramURI.toString()), false, 0);
/*      */     }
/*      */     
/* 1145 */     return create(paramURI.getScheme(), paramURI.getUserInfo(), paramURI.getHost(), paramURI.getPort(), paramURI
/* 1146 */         .getPath(), paramURI.getQuery(), paramURI.getFragment());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Uri valueOf(URL paramURL) throws URISyntaxException {
/* 1167 */     return valueOf(paramURL.toURI());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Uri(Encoded paramEncoded) throws URISyntaxException {
/* 1230 */     this(paramEncoded, false, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isFileScheme() {
/* 1235 */     return (null != this.scheme && "file".equals(this.scheme.get()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isJarScheme() {
/* 1243 */     return (null != this.scheme && "jar".equals(this.scheme.get()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Encoded getEncoded() {
/* 1250 */     return this.input;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String toString() {
/* 1258 */     return this.input.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASCIIEncoded toASCIIString() {
/* 1265 */     synchronized (this.lazyLock) {
/* 1266 */       if (null == this.inputASCII) {
/* 1267 */         this.inputASCII = new ASCIIEncoded(this.input.get());
/*      */       }
/* 1269 */       return this.inputASCII;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final URI toURI() {
/*      */     try {
/* 1281 */       return new URI(this.input.get());
/* 1282 */     } catch (URISyntaxException uRISyntaxException) {
/* 1283 */       throw new Error(uRISyntaxException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final URI toURIReencoded() throws URISyntaxException {
/*      */     URI uRI;
/* 1302 */     if (this.opaque) {
/*      */       
/* 1304 */       uRI = new URI(decode(this.scheme), decode(this.schemeSpecificPart), decode(this.fragment));
/* 1305 */     } else if (null != this.host) {
/*      */ 
/*      */       
/* 1308 */       uRI = new URI(decode(this.scheme), decode(this.userInfo), decode(this.host), this.port, decode(this.path), decode(this.query), decode(this.fragment));
/*      */     }
/*      */     else {
/*      */       
/* 1312 */       uRI = new URI(decode(this.scheme), decode(this.authority), decode(this.path), decode(this.query), decode(this.fragment));
/*      */     } 
/* 1314 */     return uRI;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final URL toURL() throws MalformedURLException {
/* 1326 */     if (!this.absolute) {
/* 1327 */       throw new IllegalArgumentException("Cannot convert relative Uri: " + this.input);
/*      */     }
/* 1329 */     return new URL(this.input.get());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final File toFile() {
/* 1347 */     if (isFileScheme() && !emptyString(this.path)) {
/*      */       String str1;
/* 1349 */       if (null == this.authority) {
/* 1350 */         str1 = "";
/*      */       } else {
/* 1352 */         str1 = "//" + this.authority.decode();
/*      */       } 
/* 1354 */       String str2 = str1 + this.path.decode();
/* 1355 */       if (File.separator.equals("\\")) {
/* 1356 */         String str = patternSingleFS.matcher(str2).replaceAll("\\\\");
/* 1357 */         if (str.startsWith("\\") && !str.startsWith("\\\\")) {
/* 1358 */           return new File(str.substring(1));
/*      */         }
/* 1360 */         return new File(str);
/*      */       } 
/*      */       
/* 1363 */       return new File(str2);
/*      */     } 
/* 1365 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Uri getContainedUri() throws URISyntaxException {
/* 1394 */     if (!emptyString(this.schemeSpecificPart)) {
/* 1395 */       StringBuilder stringBuilder = new StringBuilder();
/*      */       
/* 1397 */       if (isJarScheme()) {
/* 1398 */         int i = this.schemeSpecificPart.lastIndexOf(33);
/* 1399 */         if (0 > i) {
/* 1400 */           throw new URISyntaxException(this.input.get(), "missing jar separator");
/*      */         }
/* 1402 */         stringBuilder.append(this.schemeSpecificPart.get().substring(0, i));
/*      */       } else {
/* 1404 */         stringBuilder.append(this.schemeSpecificPart.get());
/*      */       } 
/* 1406 */       if (!emptyString(this.fragment)) {
/* 1407 */         stringBuilder.append('#');
/* 1408 */         stringBuilder.append(this.fragment);
/*      */       } 
/*      */       try {
/* 1411 */         boolean bool = this.opaque ? true : false;
/* 1412 */         Uri uri = new Uri(new Encoded(stringBuilder.toString()), false, bool);
/* 1413 */         if (null != uri.scheme) {
/* 1414 */           return uri;
/*      */         }
/* 1416 */       } catch (URISyntaxException uRISyntaxException) {
/*      */         
/* 1418 */         if (DEBUG) {
/* 1419 */           System.err.println("Caught " + uRISyntaxException.getClass().getSimpleName() + ": " + uRISyntaxException.getMessage());
/* 1420 */           uRISyntaxException.printStackTrace();
/*      */         } 
/*      */       } 
/*      */     } 
/* 1424 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean cutoffLastPathSegementImpl(StringBuilder paramStringBuilder, boolean paramBoolean1, boolean paramBoolean2, Encoded paramEncoded) throws URISyntaxException {
/* 1433 */     String str = paramStringBuilder.toString();
/* 1434 */     if (0 > str.indexOf("/") && emptyString(paramEncoded)) {
/* 1435 */       return false;
/*      */     }
/* 1437 */     paramStringBuilder.setLength(0);
/* 1438 */     paramStringBuilder.append(IOUtil.cleanPathString(str));
/* 1439 */     boolean bool1 = (paramStringBuilder.length() != str.length()) ? true : false;
/*      */ 
/*      */ 
/*      */     
/* 1443 */     str = paramStringBuilder.toString();
/* 1444 */     int i = str.lastIndexOf('!');
/* 1445 */     int j = str.lastIndexOf("/");
/* 1446 */     if (0 > i || j - 1 > i) {
/* 1447 */       if (paramBoolean1 && j < str.length() - 1) {
/*      */         
/* 1449 */         paramStringBuilder.setLength(0);
/* 1450 */         paramStringBuilder.append(str.substring(0, j + 1));
/* 1451 */       } else if (paramBoolean2) {
/*      */         
/* 1453 */         int k = str.lastIndexOf("/", j - 1);
/* 1454 */         if (k >= 0) {
/* 1455 */           paramStringBuilder.setLength(0);
/* 1456 */           paramStringBuilder.append(str.substring(0, k + 1));
/*      */         } 
/*      */       } 
/*      */     }
/* 1460 */     boolean bool2 = (paramStringBuilder.length() != str.length()) ? true : false;
/* 1461 */     if (!bool2 && (paramBoolean2 || !bool1) && emptyString(paramEncoded)) {
/* 1462 */       return false;
/*      */     }
/*      */     
/* 1465 */     if (!emptyString(paramEncoded)) {
/* 1466 */       paramStringBuilder.append(paramEncoded.get());
/*      */       
/* 1468 */       str = paramStringBuilder.toString();
/* 1469 */       paramStringBuilder.setLength(0);
/* 1470 */       paramStringBuilder.append(IOUtil.cleanPathString(str));
/*      */     } 
/* 1472 */     return true;
/*      */   }
/*      */   private final Uri cutoffLastPathSegementImpl(boolean paramBoolean1, boolean paramBoolean2, Encoded paramEncoded) throws URISyntaxException {
/* 1475 */     if (this.opaque) {
/* 1476 */       Encoded encoded; if (emptyString(this.schemeSpecificPart)) {
/*      */         
/* 1478 */         if (!emptyString(paramEncoded)) {
/* 1479 */           return create(this.scheme, paramEncoded, this.fragment);
/*      */         }
/* 1481 */         return null;
/*      */       } 
/*      */       
/* 1484 */       StringBuilder stringBuilder1 = new StringBuilder();
/*      */ 
/*      */ 
/*      */       
/* 1488 */       int i = this.schemeSpecificPart.lastIndexOf(63);
/* 1489 */       if (i >= 0) {
/* 1490 */         encoded = this.schemeSpecificPart.substring(i + 1);
/* 1491 */         stringBuilder1.append(this.schemeSpecificPart.substring(0, i).get());
/*      */       } else {
/* 1493 */         encoded = null;
/* 1494 */         stringBuilder1.append(this.schemeSpecificPart.get());
/*      */       } 
/*      */       
/* 1497 */       if (!cutoffLastPathSegementImpl(stringBuilder1, paramBoolean1, paramBoolean2, paramEncoded)) {
/* 1498 */         return null;
/*      */       }
/*      */       
/* 1501 */       if (!emptyString(encoded)) {
/* 1502 */         stringBuilder1.append('?');
/* 1503 */         stringBuilder1.append(encoded.get());
/*      */       } 
/*      */ 
/*      */       
/* 1507 */       return create(this.scheme, new Encoded(stringBuilder1.toString()), this.fragment);
/*      */     } 
/* 1509 */     if (emptyString(this.path)) {
/* 1510 */       return null;
/*      */     }
/* 1512 */     StringBuilder stringBuilder = new StringBuilder();
/* 1513 */     stringBuilder.append(this.path.get());
/*      */     
/* 1515 */     if (!cutoffLastPathSegementImpl(stringBuilder, paramBoolean1, paramBoolean2, paramEncoded)) {
/* 1516 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1520 */     return create(this.scheme, this.userInfo, this.host, this.port, new Encoded(stringBuilder.toString()), this.query, this.fragment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Uri getNormalized() {
/*      */     try {
/* 1541 */       Uri uri = cutoffLastPathSegementImpl(false, false, null);
/* 1542 */       return (null != uri) ? uri : this;
/* 1543 */     } catch (URISyntaxException uRISyntaxException) {
/* 1544 */       if (DEBUG) {
/* 1545 */         System.err.println("Caught " + uRISyntaxException.getClass().getSimpleName() + ": " + uRISyntaxException.getMessage());
/* 1546 */         uRISyntaxException.printStackTrace();
/*      */       } 
/* 1548 */       return this;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Uri getDirectory() {
/*      */     try {
/* 1580 */       Uri uri = cutoffLastPathSegementImpl(true, false, null);
/* 1581 */       return (null != uri) ? uri : this;
/* 1582 */     } catch (URISyntaxException uRISyntaxException) {
/* 1583 */       if (DEBUG) {
/* 1584 */         System.err.println("Caught " + uRISyntaxException.getClass().getSimpleName() + ": " + uRISyntaxException.getMessage());
/* 1585 */         uRISyntaxException.printStackTrace();
/*      */       } 
/* 1587 */       return this;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Uri getParent() {
/*      */     try {
/* 1622 */       return cutoffLastPathSegementImpl(true, true, null);
/* 1623 */     } catch (URISyntaxException uRISyntaxException) {
/* 1624 */       if (DEBUG) {
/* 1625 */         System.err.println("Caught " + uRISyntaxException.getClass().getSimpleName() + ": " + uRISyntaxException.getMessage());
/* 1626 */         uRISyntaxException.printStackTrace();
/*      */       } 
/* 1628 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Uri getRelativeOf(Encoded paramEncoded) throws URISyntaxException {
/* 1666 */     if (emptyString(paramEncoded)) {
/* 1667 */       return getNormalized();
/*      */     }
/* 1669 */     return cutoffLastPathSegementImpl(true, false, paramEncoded);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Uri concat(Encoded paramEncoded) throws URISyntaxException {
/* 1682 */     if (null == paramEncoded) {
/* 1683 */       return this;
/*      */     }
/* 1685 */     return new Uri(this.input.concat(paramEncoded));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Uri getNewQuery(Encoded paramEncoded) throws URISyntaxException {
/* 1697 */     if (this.opaque) {
/* 1698 */       throw new URISyntaxException(this.input.decode(), "Opaque Uri cannot permute by query");
/*      */     }
/*      */     
/* 1701 */     return create(this.scheme, this.userInfo, this.host, this.port, this.path, paramEncoded, this.fragment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean equals(Object paramObject) {
/* 1720 */     if (!(paramObject instanceof Uri)) {
/* 1721 */       return false;
/*      */     }
/* 1723 */     Uri uri = (Uri)paramObject;
/*      */     
/* 1725 */     if ((uri.fragment == null && this.fragment != null) || (uri.fragment != null && this.fragment == null))
/* 1726 */       return false; 
/* 1727 */     if (uri.fragment != null && this.fragment != null && 
/* 1728 */       !equalsHexCaseInsensitive(uri.fragment, this.fragment)) {
/* 1729 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1733 */     if ((uri.scheme == null && this.scheme != null) || (uri.scheme != null && this.scheme == null))
/* 1734 */       return false; 
/* 1735 */     if (uri.scheme != null && this.scheme != null && 
/* 1736 */       !uri.scheme.equalsIgnoreCase(this.scheme)) {
/* 1737 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1741 */     if (uri.opaque && this.opaque)
/* 1742 */       return equalsHexCaseInsensitive(uri.schemeSpecificPart, this.schemeSpecificPart); 
/* 1743 */     if (!uri.opaque && !this.opaque) {
/* 1744 */       if (!equalsHexCaseInsensitive(this.path, uri.path)) {
/* 1745 */         return false;
/*      */       }
/*      */       
/* 1748 */       if ((uri.query != null && this.query == null) || (uri.query == null && this.query != null))
/* 1749 */         return false; 
/* 1750 */       if (uri.query != null && this.query != null && 
/* 1751 */         !equalsHexCaseInsensitive(uri.query, this.query)) {
/* 1752 */         return false;
/*      */       }
/*      */ 
/*      */       
/* 1756 */       if ((uri.authority != null && this.authority == null) || (uri.authority == null && this.authority != null))
/* 1757 */         return false; 
/* 1758 */       if (uri.authority != null && this.authority != null) {
/* 1759 */         if ((uri.host != null && this.host == null) || (uri.host == null && this.host != null))
/* 1760 */           return false; 
/* 1761 */         if (uri.host == null && this.host == null)
/*      */         {
/* 1763 */           return equalsHexCaseInsensitive(uri.authority, this.authority);
/*      */         }
/* 1765 */         if (!this.host.equalsIgnoreCase(uri.host)) {
/* 1766 */           return false;
/*      */         }
/*      */         
/* 1769 */         if (this.port != uri.port) {
/* 1770 */           return false;
/*      */         }
/*      */         
/* 1773 */         if ((uri.userInfo != null && this.userInfo == null) || (uri.userInfo == null && this.userInfo != null))
/*      */         {
/*      */           
/* 1776 */           return false; } 
/* 1777 */         if (uri.userInfo != null && this.userInfo != null) {
/* 1778 */           return equalsHexCaseInsensitive(this.userInfo, uri.userInfo);
/*      */         }
/* 1780 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1785 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1790 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int hashCode() {
/* 1802 */     synchronized (this.lazyLock) {
/* 1803 */       if (this.hash == -1) {
/* 1804 */         this.hash = getHashString().hashCode();
/*      */       }
/* 1806 */       return this.hash;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String convertHexToLowerCase(String paramString) {
/* 1815 */     if (paramString.indexOf('%') == -1) {
/* 1816 */       return paramString;
/*      */     }
/* 1818 */     StringBuilder stringBuilder = new StringBuilder("");
/* 1819 */     int i = 0, j = 0;
/* 1820 */     while ((i = paramString.indexOf('%', j)) != -1) {
/* 1821 */       stringBuilder.append(paramString.substring(j, i + 1));
/* 1822 */       stringBuilder.append(paramString.substring(i + 1, i + 3).toLowerCase());
/* 1823 */       i += 3;
/* 1824 */       j = i;
/*      */     } 
/* 1826 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean equalsHexCaseInsensitive(Encoded paramEncoded1, Encoded paramEncoded2) {
/* 1835 */     if (paramEncoded1.indexOf(37) != paramEncoded2.indexOf(37)) {
/* 1836 */       return paramEncoded1.equals(paramEncoded2);
/*      */     }
/*      */     
/* 1839 */     int i = 0, j = 0;
/* 1840 */     while ((i = paramEncoded1.indexOf(37, j)) != -1 && paramEncoded2
/* 1841 */       .indexOf(37, j) == i) {
/*      */       
/* 1843 */       if (!paramEncoded1.get().substring(j, i).equals(paramEncoded2.get().substring(j, i))) {
/* 1844 */         return false;
/*      */       }
/* 1846 */       if (!paramEncoded1.get().substring(i + 1, i + 3).equalsIgnoreCase(paramEncoded2.get().substring(i + 1, i + 3))) {
/* 1847 */         return false;
/*      */       }
/* 1849 */       i += 3;
/* 1850 */       j = i;
/*      */     } 
/* 1852 */     return paramEncoded1.get().substring(j).equals(paramEncoded2.get().substring(j));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getHashString() {
/* 1861 */     StringBuilder stringBuilder = new StringBuilder();
/* 1862 */     if (this.scheme != null) {
/* 1863 */       stringBuilder.append(this.scheme.get().toLowerCase());
/* 1864 */       stringBuilder.append(':');
/*      */     } 
/* 1866 */     if (this.opaque) {
/* 1867 */       stringBuilder.append(this.schemeSpecificPart.get());
/*      */     } else {
/* 1869 */       if (this.authority != null) {
/* 1870 */         stringBuilder.append("//");
/* 1871 */         if (this.host == null) {
/* 1872 */           stringBuilder.append(this.authority.get());
/*      */         } else {
/* 1874 */           if (this.userInfo != null) {
/* 1875 */             stringBuilder.append(this.userInfo.get() + "@");
/*      */           }
/* 1877 */           stringBuilder.append(this.host.get().toLowerCase());
/* 1878 */           if (this.port != -1) {
/* 1879 */             stringBuilder.append(58 + this.port);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 1884 */       if (this.path != null) {
/* 1885 */         stringBuilder.append(this.path.get());
/*      */       }
/*      */       
/* 1888 */       if (this.query != null) {
/* 1889 */         stringBuilder.append('?');
/* 1890 */         stringBuilder.append(this.query.get());
/*      */       } 
/*      */     } 
/*      */     
/* 1894 */     if (this.fragment != null) {
/* 1895 */       stringBuilder.append('#');
/* 1896 */       stringBuilder.append(this.fragment.get());
/*      */     } 
/* 1898 */     return convertHexToLowerCase(stringBuilder.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Uri(Encoded paramEncoded, boolean paramBoolean, int paramInt) throws URISyntaxException {
/*      */     String str3;
/*      */     boolean bool;
/*      */     this.lazyLock = new Object();
/* 1909 */     if (emptyString(paramEncoded)) {
/* 1910 */       throw new URISyntaxException(paramEncoded.get(), "empty input");
/*      */     }
/* 1912 */     String str1 = paramEncoded.get();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1918 */     int i = str1.indexOf('#');
/* 1919 */     if (i != -1) {
/*      */       
/* 1921 */       this.fragment = new Encoded(str1.substring(i + 1));
/* 1922 */       validateFragment(paramEncoded, this.fragment, i + 1);
/* 1923 */       str1 = str1.substring(0, i);
/*      */     } else {
/* 1925 */       this.fragment = null;
/*      */     } 
/*      */     
/* 1928 */     String str2 = paramEncoded.get();
/*      */ 
/*      */     
/* 1931 */     int j = str1.indexOf(':');
/* 1932 */     i = j;
/* 1933 */     int k = str1.indexOf('/');
/* 1934 */     int m = str1.indexOf('?');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1940 */     if (j != -1 && (k >= j || k == -1) && (m >= j || m == -1)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1945 */       this.absolute = true;
/* 1946 */       this.scheme = new Encoded(str1.substring(0, j));
/* 1947 */       if (this.scheme.length() == 0) {
/* 1948 */         failExpecting(paramEncoded, "scheme", j);
/*      */       }
/* 1950 */       validateScheme(paramEncoded, this.scheme, 0);
/* 1951 */       str3 = str1.substring(j + 1);
/* 1952 */       if (str3.length() == 0) {
/* 1953 */         failExpecting(paramEncoded, "scheme-specific-part", j);
/*      */       }
/*      */     } else {
/* 1956 */       this.absolute = false;
/* 1957 */       this.scheme = null;
/* 1958 */       str3 = str1;
/*      */     } 
/*      */     
/* 1961 */     if (this.scheme == null || (str3.length() > 0 && str3.charAt(0) == '/')) {
/*      */       String str; byte b;
/* 1963 */       this.opaque = false;
/*      */ 
/*      */       
/* 1966 */       str1 = str3;
/* 1967 */       i = str1.indexOf('?');
/* 1968 */       if (i != -1) {
/* 1969 */         this.query = new Encoded(str1.substring(i + 1));
/* 1970 */         str1 = str1.substring(0, i);
/* 1971 */         validateQuery(paramEncoded, this.query, k + 1 + i);
/*      */       } else {
/* 1973 */         this.query = null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1980 */       if (str1.startsWith("//")) {
/* 1981 */         String str4; i = str1.indexOf('/', 2);
/*      */         
/* 1983 */         if (i != -1) {
/* 1984 */           str4 = str1.substring(2, i);
/* 1985 */           str = str1.substring(i);
/* 1986 */           b = i;
/*      */         } else {
/* 1988 */           str4 = str1.substring(2);
/* 1989 */           if (str4.length() == 0 && this.query == null && this.fragment == null) {
/* 1990 */             failExpecting(paramEncoded, "authority, path [, query, fragment]", i);
/*      */           }
/* 1992 */           str = "";
/* 1993 */           b = -1;
/*      */         } 
/*      */ 
/*      */         
/* 1997 */         if (emptyString(str4)) {
/* 1998 */           this.authority = null;
/*      */         } else {
/* 2000 */           this.authority = new Encoded(str4);
/* 2001 */           validateAuthority(paramEncoded, this.authority, j + 3);
/*      */         } 
/*      */       } else {
/* 2004 */         str = str1;
/* 2005 */         b = 0;
/* 2006 */         this.authority = null;
/*      */       } 
/*      */       
/* 2009 */       int i1 = 0;
/* 2010 */       if (k > -1) {
/* 2011 */         i1 += k;
/*      */       }
/* 2013 */       if (b > -1) {
/* 2014 */         i1 += b;
/*      */       }
/*      */       
/* 2017 */       bool = validateEncoded(str, "/!_-.~");
/* 2018 */       if (false <= bool)
/*      */       {
/* 2020 */         if (0 != (paramInt & 0x1)) {
/* 2021 */           if (DEBUG_SHOWFIX) {
/* 2022 */             System.err.println("Uri FIX_FILEPATH: input at index " + (i1 + bool) + ": " + str2);
/* 2023 */             System.err.println("Uri FIX_FILEPATH: ssp at index   " + (b + bool) + ": " + str3);
/* 2024 */             System.err.println("Uri FIX_FILEPATH: path  at index " + bool + ": " + str);
/*      */           } 
/* 2026 */           int i2 = str.length();
/* 2027 */           str = encode(decode(str), "/!_-.~");
/* 2028 */           validatePath(paramEncoded, str, i1);
/*      */ 
/*      */           
/* 2031 */           StringBuilder stringBuilder = new StringBuilder();
/* 2032 */           if (b > 0) {
/* 2033 */             stringBuilder.append(str3.substring(0, b));
/*      */           }
/* 2035 */           stringBuilder.append(str).append(str3.substring(b + i2));
/* 2036 */           str3 = stringBuilder.toString();
/*      */           
/* 2038 */           stringBuilder.setLength(0);
/* 2039 */           if (i1 > 0) {
/* 2040 */             stringBuilder.append(str2.substring(0, i1));
/*      */           }
/* 2042 */           stringBuilder.append(str).append(str2.substring(i1 + i2));
/* 2043 */           str2 = stringBuilder.toString();
/*      */           
/* 2045 */           if (DEBUG_SHOWFIX) {
/* 2046 */             System.err.println("Uri FIX_FILEPATH: result          : " + str);
/* 2047 */             System.err.println("Uri FIX_FILEPATH: ssp after       : " + str3);
/* 2048 */             System.err.println("Uri FIX_FILEPATH: input after     : " + str2);
/*      */           } 
/*      */         } else {
/* 2051 */           fail(paramEncoded, "invalid path", i1 + bool);
/*      */         } 
/*      */       }
/* 2054 */       this.path = new Encoded(str);
/*      */     } else {
/*      */       
/* 2057 */       this.opaque = true;
/* 2058 */       this.query = null;
/* 2059 */       this.path = null;
/* 2060 */       this.authority = null;
/* 2061 */       validateSsp(paramEncoded, str3, j + 1);
/*      */     } 
/* 2063 */     this.schemeSpecificPart = new Encoded(str3);
/* 2064 */     this.input = (str2 == paramEncoded.get()) ? paramEncoded : new Encoded(str2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2078 */     Encoded encoded1 = null, encoded2 = null;
/* 2079 */     int n = -1;
/*      */ 
/*      */     
/* 2082 */     if (null != this.authority) {
/* 2083 */       bool = true;
/* 2084 */       int i1 = 0;
/*      */       
/* 2086 */       str1 = this.authority.get();
/* 2087 */       i = str1.indexOf('@');
/* 2088 */       if (i != -1) {
/*      */         
/* 2090 */         encoded1 = new Encoded(str1.substring(0, i));
/* 2091 */         validateUserinfo(this.authority, encoded1, 0);
/* 2092 */         str1 = str1.substring(i + 1);
/* 2093 */         i1 = i + 1;
/*      */       } 
/*      */       
/* 2096 */       i = str1.lastIndexOf(':');
/* 2097 */       int i2 = str1.indexOf(']');
/*      */       
/* 2099 */       if (i != -1 && i2 < i) {
/*      */         
/* 2101 */         encoded2 = new Encoded(str1.substring(0, i));
/*      */         
/* 2103 */         if (i < str1.length() - 1) {
/*      */           try {
/* 2105 */             n = Integer.parseInt(str1.substring(i + 1));
/* 2106 */             if (n < 0) {
/* 2107 */               if (paramBoolean) {
/* 2108 */                 fail(this.authority, "invalid port <" + this.authority + ">", i1 + i + 1);
/*      */               }
/* 2110 */               bool = false;
/*      */             } 
/* 2112 */           } catch (NumberFormatException numberFormatException) {
/* 2113 */             if (paramBoolean) {
/* 2114 */               fail(this.authority, "invalid port <" + this.authority + ">, " + numberFormatException.getMessage(), i1 + i + 1);
/*      */             }
/* 2116 */             bool = false;
/*      */           } 
/*      */         }
/*      */       } else {
/* 2120 */         encoded2 = new Encoded(str1);
/*      */       } 
/*      */       
/* 2123 */       if (bool) {
/* 2124 */         if (emptyString(encoded2)) {
/* 2125 */           if (paramBoolean) {
/* 2126 */             fail(this.authority, "empty host <" + this.authority + ">", i1);
/*      */           }
/* 2128 */           bool = false;
/* 2129 */         } else if (!isValidHost(paramBoolean, encoded2)) {
/* 2130 */           if (paramBoolean) {
/* 2131 */             fail(this.authority, "invalid host <" + encoded2 + ">", i1);
/*      */           }
/* 2133 */           bool = false;
/*      */         } 
/*      */       }
/*      */     } else {
/* 2137 */       bool = false;
/*      */     } 
/*      */     
/* 2140 */     if (bool) {
/*      */ 
/*      */       
/* 2143 */       this.userInfo = encoded1;
/* 2144 */       this.host = encoded2;
/* 2145 */       this.port = n;
/* 2146 */       this.hasAuthority = true;
/*      */     } else {
/* 2148 */       this.userInfo = null;
/* 2149 */       this.host = null;
/* 2150 */       this.port = -1;
/* 2151 */       this.hasAuthority = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void validateScheme(Encoded paramEncoded1, Encoded paramEncoded2, int paramInt) throws URISyntaxException {
/* 2157 */     char c = paramEncoded2.charAt(0);
/* 2158 */     if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z')) {
/* 2159 */       fail(paramEncoded1, "invalid scheme", paramInt);
/*      */     }
/* 2161 */     int i = validateAlphaNum(paramEncoded2.get(), "+-.");
/* 2162 */     if (0 <= i) {
/* 2163 */       fail(paramEncoded1, "invalid scheme", paramInt + i);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void validateSsp(Encoded paramEncoded, String paramString, int paramInt) throws URISyntaxException {
/* 2168 */     int i = validateEncoded(paramString, "_-.~,;:$&+=!*'()@/?[]\\\"");
/* 2169 */     if (0 <= i) {
/* 2170 */       fail(paramEncoded, "invalid scheme-specific-part", paramInt + i);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void validateAuthority(Encoded paramEncoded1, Encoded paramEncoded2, int paramInt) throws URISyntaxException {
/* 2175 */     int i = validateEncoded(paramEncoded2.get(), "@[]_-.~,;:$&+=");
/* 2176 */     if (0 <= i) {
/* 2177 */       fail(paramEncoded1, "invalid authority", paramInt + i);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void validatePath(Encoded paramEncoded, String paramString, int paramInt) throws URISyntaxException {
/* 2182 */     int i = validateEncoded(paramString, "/!_-.~");
/* 2183 */     if (0 <= i) {
/* 2184 */       fail(paramEncoded, "invalid path", paramInt + i);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void validateQuery(Encoded paramEncoded1, Encoded paramEncoded2, int paramInt) throws URISyntaxException {
/* 2189 */     int i = validateEncoded(paramEncoded2.get(), "_-.~,;:$&+=!*'()@/?[]\\\"");
/* 2190 */     if (0 <= i) {
/* 2191 */       fail(paramEncoded1, "invalid query", paramInt + i);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void validateFragment(Encoded paramEncoded1, Encoded paramEncoded2, int paramInt) throws URISyntaxException {
/* 2196 */     int i = validateEncoded(paramEncoded2.get(), "_-.~,;:$&+=!*'()@/?#[]");
/* 2197 */     if (0 <= i) {
/* 2198 */       fail(paramEncoded1, "invalid fragment", paramInt + i);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void validateUserinfo(Encoded paramEncoded1, Encoded paramEncoded2, int paramInt) throws URISyntaxException {
/* 2203 */     for (byte b = 0; b < paramEncoded2.length(); b++) {
/* 2204 */       char c = paramEncoded2.charAt(b);
/* 2205 */       if (c == ']' || c == '[') {
/* 2206 */         fail(paramEncoded1, "invalid userinfo", paramInt + b);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isValidHost(boolean paramBoolean, Encoded paramEncoded) throws URISyntaxException {
/* 2216 */     if (paramEncoded.charAt(0) == '[') {
/*      */       
/* 2218 */       if (paramEncoded.charAt(paramEncoded.length() - 1) != ']') {
/* 2219 */         fail(this.input, "invalid host, missing closing ipv6: " + paramEncoded, 0);
/*      */       }
/* 2221 */       if (!isValidIP6Address(paramEncoded.get())) {
/* 2222 */         fail(this.input, "invalid ipv6: " + paramEncoded, 0);
/*      */       }
/* 2224 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2229 */     if (paramEncoded.indexOf(91) != -1 || paramEncoded.indexOf(93) != -1) {
/* 2230 */       fail(this.input, "invalid host: " + paramEncoded, 0);
/*      */     }
/*      */     
/* 2233 */     int i = paramEncoded.lastIndexOf(46);
/* 2234 */     if (i < 0 || i == paramEncoded.length() - 1 || 
/* 2235 */       !Character.isDigit(paramEncoded.charAt(i + 1))) {
/*      */ 
/*      */       
/* 2238 */       if (isValidDomainName(paramEncoded)) {
/* 2239 */         return true;
/*      */       }
/* 2241 */       if (paramBoolean) {
/* 2242 */         fail(this.input, "invalid host, invalid domain-name or ipv4: " + paramEncoded, 0);
/*      */       }
/* 2244 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 2248 */     if (isValidIPv4Address(paramEncoded.get())) {
/* 2249 */       return true;
/*      */     }
/* 2251 */     if (paramBoolean) {
/* 2252 */       fail(this.input, "invalid host, invalid ipv4: " + paramEncoded, 0);
/*      */     }
/* 2254 */     return false;
/*      */   }
/*      */   
/*      */   private static boolean isValidDomainName(Encoded paramEncoded) {
/* 2258 */     String str1 = paramEncoded.get();
/* 2259 */     if (0 <= validateAlphaNum(str1, "-.")) {
/* 2260 */       return false;
/*      */     }
/* 2262 */     String str2 = null;
/* 2263 */     StringTokenizer stringTokenizer = new StringTokenizer(str1, ".");
/* 2264 */     while (stringTokenizer.hasMoreTokens()) {
/* 2265 */       str2 = stringTokenizer.nextToken();
/* 2266 */       if (str2.startsWith("-") || str2.endsWith("-")) {
/* 2267 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 2271 */     if (!str2.equals(str1)) {
/* 2272 */       char c = str2.charAt(0);
/* 2273 */       if (c >= '0' && c <= '9') {
/* 2274 */         return false;
/*      */       }
/*      */     } 
/* 2277 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isValidIPv4Address(String paramString) {
/*      */     try {
/* 2285 */       int i = paramString.indexOf('.');
/* 2286 */       int k = Integer.parseInt(paramString.substring(0, i));
/* 2287 */       if (k < 0 || k > 255) {
/* 2288 */         return false;
/*      */       }
/* 2290 */       int j = paramString.indexOf('.', i + 1);
/* 2291 */       k = Integer.parseInt(paramString.substring(i + 1, j));
/* 2292 */       if (k < 0 || k > 255) {
/* 2293 */         return false;
/*      */       }
/* 2295 */       i = paramString.indexOf('.', j + 1);
/* 2296 */       k = Integer.parseInt(paramString.substring(j + 1, i));
/* 2297 */       if (k < 0 || k > 255) {
/* 2298 */         return false;
/*      */       }
/* 2300 */       k = Integer.parseInt(paramString.substring(i + 1));
/* 2301 */       if (k < 0 || k > 255) {
/* 2302 */         return false;
/*      */       }
/* 2304 */     } catch (Exception exception) {
/* 2305 */       return false;
/*      */     } 
/* 2307 */     return true;
/*      */   }
/*      */   
/*      */   private static boolean isValidIP6Address(String paramString) {
/* 2311 */     int i = paramString.length();
/* 2312 */     boolean bool = false;
/* 2313 */     byte b1 = 0;
/* 2314 */     byte b2 = 0;
/* 2315 */     String str = "";
/* 2316 */     char c1 = Character.MIN_VALUE;
/* 2317 */     char c2 = Character.MIN_VALUE;
/* 2318 */     byte b3 = 0;
/*      */     
/* 2320 */     if (i < 2) {
/* 2321 */       return false;
/*      */     }
/*      */     
/* 2324 */     for (byte b4 = 0; b4 < i; b4++) {
/* 2325 */       c2 = c1;
/* 2326 */       c1 = paramString.charAt(b4);
/* 2327 */       switch (c1) {
/*      */ 
/*      */         
/*      */         case '[':
/* 2331 */           if (b4 != 0) {
/* 2332 */             return false;
/*      */           }
/* 2334 */           if (paramString.charAt(i - 1) != ']') {
/* 2335 */             return false;
/*      */           }
/* 2337 */           if (paramString.charAt(1) == ':' && paramString
/* 2338 */             .charAt(2) != ':') {
/* 2339 */             return false;
/*      */           }
/* 2341 */           b3 = 1;
/* 2342 */           if (i < 4) {
/* 2343 */             return false;
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case ']':
/* 2349 */           if (b4 != i - 1) {
/* 2350 */             return false;
/*      */           }
/* 2352 */           if (paramString.charAt(0) != '[') {
/* 2353 */             return false;
/*      */           }
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case '.':
/* 2360 */           b2++;
/* 2361 */           if (b2 > 3) {
/* 2362 */             return false;
/*      */           }
/* 2364 */           if (!isValidIP4Word(str)) {
/* 2365 */             return false;
/*      */           }
/* 2367 */           if (b1 != 6 && !bool) {
/* 2368 */             return false;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 2373 */           if (b1 == 7 && paramString
/* 2374 */             .charAt(0 + b3) != ':' && paramString
/* 2375 */             .charAt(1 + b3) != ':') {
/* 2376 */             return false;
/*      */           }
/* 2378 */           str = "";
/*      */           break;
/*      */         
/*      */         case ':':
/* 2382 */           b1++;
/* 2383 */           if (b1 > 7) {
/* 2384 */             return false;
/*      */           }
/* 2386 */           if (b2 > 0) {
/* 2387 */             return false;
/*      */           }
/* 2389 */           if (c2 == ':') {
/* 2390 */             if (bool) {
/* 2391 */               return false;
/*      */             }
/* 2393 */             bool = true;
/*      */           } 
/* 2395 */           str = "";
/*      */           break;
/*      */         
/*      */         default:
/* 2399 */           if (str.length() > 3) {
/* 2400 */             return false;
/*      */           }
/* 2402 */           if (!isValidHexChar(c1)) {
/* 2403 */             return false;
/*      */           }
/* 2405 */           str = str + c1;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 2410 */     if (b2 > 0) {
/* 2411 */       if (b2 != 3 || !isValidIP4Word(str)) {
/* 2412 */         return false;
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 2417 */       if (b1 != 7 && !bool) {
/* 2418 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2424 */       if (str == "" && paramString.charAt(i - 1 - b3) != ':' && paramString
/* 2425 */         .charAt(i - 2 - b3) != ':') {
/* 2426 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 2430 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isValidIP4Word(String paramString) {
/* 2435 */     if (paramString.length() < 1 || paramString.length() > 3) {
/* 2436 */       return false;
/*      */     }
/* 2438 */     for (byte b = 0; b < paramString.length(); b++) {
/* 2439 */       char c = paramString.charAt(b);
/* 2440 */       if (c < '0' || c > '9') {
/* 2441 */         return false;
/*      */       }
/*      */     } 
/* 2444 */     if (Integer.parseInt(paramString) > 255) {
/* 2445 */       return false;
/*      */     }
/* 2447 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int validateEncoded(String paramString1, String paramString2) {
/*      */     byte b;
/* 2467 */     label31: for (b = 0; b < paramString1.length(); ) {
/* 2468 */       char c = paramString1.charAt(b);
/* 2469 */       if (c == '%')
/*      */         while (true) {
/* 2471 */           if (b + 2 >= paramString1.length()) {
/* 2472 */             throw new IllegalArgumentException("missing '%' hex-digits at index " + b);
/*      */           }
/* 2474 */           int i = Character.digit(paramString1.charAt(b + 1), 16);
/* 2475 */           int j = Character.digit(paramString1.charAt(b + 2), 16);
/* 2476 */           if (i == -1 || j == -1) {
/* 2477 */             throw new IllegalArgumentException("invalid hex-digits at index " + b + ": " + paramString1.substring(b, b + 3));
/*      */           }
/* 2479 */           b += 3;
/* 2480 */           if (b < paramString1.length()) { if (paramString1.charAt(b) != '%')
/*      */               continue label31;  continue; }
/*      */            continue label31;
/* 2483 */         }   if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && (c < '0' || c > '9') && paramString2
/* 2484 */         .indexOf(c) <= -1 && (c <= '' || 
/* 2485 */         Character.isSpaceChar(c) || Character.isISOControl(c)))
/*      */       {
/*      */         
/* 2488 */         return b;
/*      */       }
/* 2490 */       b++;
/*      */     } 
/* 2492 */     return -1;
/*      */   }
/*      */   private static int validateAlphaNum(String paramString1, String paramString2) {
/* 2495 */     for (byte b = 0; b < paramString1.length(); ) {
/* 2496 */       char c = paramString1.charAt(b);
/* 2497 */       if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && (c < '0' || c > '9') && paramString2
/* 2498 */         .indexOf(c) <= -1)
/*      */       {
/*      */         
/* 2501 */         return b;
/*      */       }
/* 2503 */       b++;
/*      */     } 
/* 2505 */     return -1;
/*      */   }
/*      */   
/*      */   private static boolean isValidHexChar(char paramChar) {
/* 2509 */     return ((paramChar >= '0' && paramChar <= '9') || (paramChar >= 'A' && paramChar <= 'F') || (paramChar >= 'a' && paramChar <= 'f'));
/*      */   }
/*      */   private static boolean emptyString(Encoded paramEncoded) {
/* 2512 */     return (null == paramEncoded || 0 == paramEncoded.length());
/*      */   }
/*      */   private static boolean emptyString(String paramString) {
/* 2515 */     return (null == paramString || 0 == paramString.length());
/*      */   }
/*      */   
/*      */   private static void fail(Encoded paramEncoded, String paramString, int paramInt) throws URISyntaxException {
/* 2519 */     throw new URISyntaxException(paramEncoded.get(), paramString, paramInt);
/*      */   }
/*      */   private static void failExpecting(Encoded paramEncoded, String paramString, int paramInt) throws URISyntaxException {
/* 2522 */     fail(paramEncoded, "Expecting " + paramString, paramInt);
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/Uri.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */