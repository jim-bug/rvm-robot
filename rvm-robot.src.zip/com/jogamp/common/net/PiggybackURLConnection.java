/*    */ package com.jogamp.common.net;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PiggybackURLConnection<I extends PiggybackURLContext>
/*    */   extends URLConnection
/*    */ {
/*    */   protected URL subUrl;
/*    */   protected URLConnection subConn;
/*    */   protected I context;
/*    */   
/*    */   protected PiggybackURLConnection(URL paramURL, I paramI) {
/* 28 */     super(paramURL);
/* 29 */     this.context = paramI;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void connect() throws IOException {
/* 42 */     if (!this.connected) {
/* 43 */       this.subConn = this.context.resolve(this.url.getPath());
/* 44 */       this.subUrl = this.subConn.getURL();
/* 45 */       this.connected = true;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getInputStream() throws IOException {
/* 51 */     if (!this.connected) {
/* 52 */       throw new IOException("not connected");
/*    */     }
/* 54 */     return this.subConn.getInputStream();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract String getEntryName() throws IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public URL getSubProtocol() throws IOException {
/* 79 */     if (!this.connected) {
/* 80 */       throw new IOException("not connected");
/*    */     }
/* 82 */     return this.subUrl;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/PiggybackURLConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */