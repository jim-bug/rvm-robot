/*    */ package com.jogamp.common.net;
/*    */ 
/*    */ import com.jogamp.common.util.SecurityUtil;
/*    */ import java.net.URL;
/*    */ import java.net.URLStreamHandler;
/*    */ import java.net.URLStreamHandlerFactory;
/*    */ import java.security.PrivilegedAction;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class GenericURLStreamHandlerFactory
/*    */   implements URLStreamHandlerFactory {
/* 13 */   private static GenericURLStreamHandlerFactory factory = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 18 */   private final Map<String, URLStreamHandler> protocolHandlers = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final synchronized URLStreamHandler setHandler(String paramString, URLStreamHandler paramURLStreamHandler) {
/* 27 */     return this.protocolHandlers.put(paramString, paramURLStreamHandler);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final synchronized URLStreamHandler getHandler(String paramString) {
/* 35 */     return this.protocolHandlers.get(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public final synchronized URLStreamHandler createURLStreamHandler(String paramString) {
/* 40 */     return getHandler(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized GenericURLStreamHandlerFactory register() {
/* 51 */     if (null == factory)
/* 52 */       factory = (GenericURLStreamHandlerFactory)SecurityUtil.doPrivileged(new PrivilegedAction<GenericURLStreamHandlerFactory>()
/*    */           {
/*    */             public GenericURLStreamHandlerFactory run() {
/* 55 */               boolean bool = false;
/* 56 */               GenericURLStreamHandlerFactory genericURLStreamHandlerFactory = new GenericURLStreamHandlerFactory();
/*    */               try {
/* 58 */                 URL.setURLStreamHandlerFactory(genericURLStreamHandlerFactory);
/* 59 */                 bool = true;
/* 60 */               } catch (Throwable throwable) {
/* 61 */                 System.err.println("GenericURLStreamHandlerFactory: Setting URLStreamHandlerFactory failed: " + throwable.getMessage());
/*    */               } 
/* 63 */               return bool ? genericURLStreamHandlerFactory : null;
/*    */             }
/*    */           }); 
/* 66 */     return factory;
/*    */   }
/*    */   
/*    */   private GenericURLStreamHandlerFactory() {}
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/GenericURLStreamHandlerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */