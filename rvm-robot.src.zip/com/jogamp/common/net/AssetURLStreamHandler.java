/*    */ package com.jogamp.common.net;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssetURLStreamHandler
/*    */   extends URLStreamHandler
/*    */ {
/*    */   AssetURLContext ctx;
/*    */   
/*    */   public AssetURLStreamHandler(AssetURLContext paramAssetURLContext) {
/* 26 */     this.ctx = paramAssetURLContext;
/*    */   }
/*    */ 
/*    */   
/*    */   protected URLConnection openConnection(URL paramURL) throws IOException {
/* 31 */     AssetURLConnection assetURLConnection = new AssetURLConnection(paramURL, this.ctx);
/* 32 */     assetURLConnection.connect();
/* 33 */     return assetURLConnection;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/AssetURLStreamHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */