/*    */ package com.jogamp.common.net.asset;
/*    */ 
/*    */ import com.jogamp.common.net.AssetURLConnection;
/*    */ import com.jogamp.common.net.AssetURLContext;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Handler
/*    */   extends URLStreamHandler
/*    */ {
/* 20 */   static final AssetURLContext localCL = new AssetURLContext()
/*    */     {
/*    */       public ClassLoader getClassLoader() {
/* 23 */         return Handler.class.getClassLoader();
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected URLConnection openConnection(URL paramURL) throws IOException {
/* 33 */     AssetURLConnection assetURLConnection = new AssetURLConnection(paramURL, localCL);
/* 34 */     assetURLConnection.connect();
/* 35 */     return (URLConnection)assetURLConnection;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/asset/Handler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */