/*     */ package com.jogamp.common.net;
/*     */ 
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriQueryProps
/*     */ {
/*     */   private static final String QMARK = "?";
/*     */   private static final char ASSIG = '=';
/*     */   private static final String EMPTY = "";
/*     */   private final String query_separator;
/*  57 */   private final HashMap<String, String> properties = new HashMap<>();
/*     */   
/*     */   private UriQueryProps(char paramChar) {
/*  60 */     this.query_separator = String.valueOf(paramChar);
/*     */   }
/*     */   
/*  63 */   public final Map<String, String> getProperties() { return this.properties; } public final char getQuerySeparator() {
/*  64 */     return this.query_separator.charAt(0);
/*     */   }
/*     */   public final Uri.Encoded appendQuery(Uri.Encoded paramEncoded) {
/*  67 */     boolean bool = false;
/*  68 */     StringBuilder stringBuilder = new StringBuilder();
/*  69 */     if (null != paramEncoded) {
/*  70 */       if (paramEncoded.startsWith("?")) {
/*  71 */         paramEncoded = paramEncoded.substring(1);
/*     */       }
/*  73 */       stringBuilder.append(paramEncoded.get());
/*  74 */       if (!paramEncoded.endsWith(this.query_separator)) {
/*  75 */         bool = true;
/*     */       }
/*     */     } 
/*  78 */     Iterator<Map.Entry> iterator = this.properties.entrySet().iterator();
/*  79 */     while (iterator.hasNext()) {
/*  80 */       if (bool) {
/*  81 */         stringBuilder.append(this.query_separator);
/*     */       }
/*  83 */       Map.Entry entry = iterator.next();
/*  84 */       stringBuilder.append((String)entry.getKey());
/*  85 */       if ("" != entry.getValue()) {
/*  86 */         stringBuilder.append('=').append((String)entry.getValue());
/*     */       }
/*  88 */       bool = true;
/*     */     } 
/*  90 */     return new Uri.Encoded(stringBuilder.toString(), "_-.~,;:$&+=!*'()@/?[]\\\"");
/*     */   }
/*     */   
/*     */   public final Uri appendQuery(Uri paramUri) throws URISyntaxException {
/*  94 */     return paramUri.getNewQuery(appendQuery(paramUri.query));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final UriQueryProps create(Uri paramUri, char paramChar) throws IllegalArgumentException {
/* 105 */     if (';' != paramChar && '&' != paramChar) {
/* 106 */       throw new IllegalArgumentException("querySeparator is invalid: " + paramChar);
/*     */     }
/* 108 */     UriQueryProps uriQueryProps = new UriQueryProps(paramChar);
/* 109 */     String str = Uri.decode(paramUri.query);
/* 110 */     byte b = (null != str) ? str.length() : -1;
/* 111 */     int i = -1;
/* 112 */     while (i < b) {
/* 113 */       int j = i + 1;
/* 114 */       i = str.indexOf(paramChar, j);
/* 115 */       if (0 == i) {
/*     */         continue;
/*     */       }
/*     */       
/* 119 */       if (0 > i)
/*     */       {
/* 121 */         i = b;
/*     */       }
/*     */       
/* 124 */       String str1 = str.substring(j, i);
/* 125 */       int k = str1.indexOf('=');
/* 126 */       if (0 < k) {
/*     */         
/* 128 */         String str2 = str1.substring(0, k);
/* 129 */         String str3 = str1.substring(k + 1);
/* 130 */         uriQueryProps.properties.put(str2, str3);
/*     */         continue;
/*     */       } 
/* 133 */       uriQueryProps.properties.put(str1, "");
/*     */     } 
/*     */     
/* 136 */     return uriQueryProps;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/UriQueryProps.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */