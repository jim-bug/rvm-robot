package com.jogamp.common.net;

import java.io.IOException;
import java.net.URLConnection;

public interface PiggybackURLContext {
  String getImplementedProtocol();
  
  URLConnection resolve(String paramString) throws IOException;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/net/PiggybackURLContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */