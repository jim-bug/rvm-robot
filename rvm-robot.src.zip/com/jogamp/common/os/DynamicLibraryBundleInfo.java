/*    */ package com.jogamp.common.os;
/*    */ 
/*    */ import com.jogamp.common.util.RunnableExecutor;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface DynamicLibraryBundleInfo
/*    */ {
/* 37 */   public static final boolean DEBUG = DynamicLibraryBundle.DEBUG;
/*    */   
/*    */   boolean searchToolLibInSystemPath();
/*    */   
/*    */   boolean searchToolLibSystemPathFirst();
/*    */   
/*    */   List<List<String>> getToolLibNames();
/*    */   
/*    */   List<String> getGlueLibNames();
/*    */   
/*    */   List<String> getToolGetProcAddressFuncNameList();
/*    */   
/*    */   long toolGetProcAddress(long paramLong, String paramString);
/*    */   
/*    */   boolean useToolGetProcAdressFirst(String paramString);
/*    */   
/*    */   boolean shallLinkGlobal();
/*    */   
/*    */   boolean shallLookupGlobal();
/*    */   
/*    */   RunnableExecutor getLibLoaderExecutor();
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/DynamicLibraryBundleInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */