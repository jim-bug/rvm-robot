/*     */ package com.jogamp.common.os;
/*     */ 
/*     */ import com.jogamp.common.util.IntObjectHashMap;
/*     */ import com.jogamp.common.util.ReflectionUtil;
/*     */ import java.lang.reflect.Field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndroidVersion
/*     */ {
/*     */   public static final boolean isAvailable;
/*     */   public static final String CPU_ABI;
/*     */   public static final Platform.CPUType CPU_TYPE;
/*     */   public static final Platform.ABIType ABI_TYPE;
/*     */   public static final String CPU_ABI2;
/*     */   public static final Platform.CPUType CPU_TYPE2;
/*     */   public static final Platform.ABIType ABI_TYPE2;
/*     */   public static final String CODENAME;
/*     */   public static final String INCREMENTAL;
/*     */   public static final String RELEASE;
/*     */   public static final int SDK_INT;
/*     */   public static final String SDK_NAME;
/*     */   private static final String androidBuild = "android.os.Build";
/*     */   private static final String androidBuildVersion = "android.os.Build$VERSION";
/*     */   private static final String androidBuildVersionCodes = "android.os.Build$VERSION_CODES";
/*     */   
/*     */   static {
/*  70 */     ClassLoader classLoader = AndroidVersion.class.getClassLoader();
/*  71 */     Class<Object> clazz1 = null;
/*  72 */     Object object1 = null;
/*  73 */     Class<Object> clazz2 = null;
/*  74 */     Object object2 = null;
/*  75 */     Class<Object> clazz3 = null;
/*  76 */     Object object3 = null;
/*     */     
/*  78 */     boolean bool = "Dalvik".equals(System.getProperty("java.vm.name"));
/*     */     
/*  80 */     if (bool) {
/*     */       try {
/*  82 */         clazz1 = ReflectionUtil.getClass("android.os.Build", true, classLoader);
/*  83 */         object1 = clazz1.newInstance();
/*  84 */         clazz2 = ReflectionUtil.getClass("android.os.Build$VERSION", true, classLoader);
/*  85 */         object2 = clazz2.newInstance();
/*  86 */         clazz3 = ReflectionUtil.getClass("android.os.Build$VERSION_CODES", true, classLoader);
/*  87 */         object3 = clazz3.newInstance();
/*  88 */       } catch (Exception exception) {}
/*     */     }
/*  90 */     isAvailable = (bool && null != object1 && null != object2);
/*  91 */     if (isAvailable) {
/*  92 */       String str; CPU_ABI = getString(clazz1, object1, "CPU_ABI", true);
/*  93 */       CPU_ABI2 = getString(clazz1, object1, "CPU_ABI2", true);
/*  94 */       CODENAME = getString(clazz2, object2, "CODENAME", false);
/*  95 */       INCREMENTAL = getString(clazz2, object2, "INCREMENTAL", false);
/*  96 */       RELEASE = getString(clazz2, object2, "RELEASE", false);
/*  97 */       SDK_INT = getInt(clazz2, object2, "SDK_INT");
/*     */       
/*  99 */       if (null != object3) {
/* 100 */         IntObjectHashMap intObjectHashMap = getVersionCodes(clazz3, object3);
/* 101 */         str = (String)intObjectHashMap.get(SDK_INT);
/*     */       } else {
/* 103 */         str = null;
/*     */       } 
/* 105 */       SDK_NAME = (null != str) ? str : ("SDK_" + SDK_INT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 120 */       CPU_TYPE = Platform.CPUType.query(CPU_ABI);
/* 121 */       ABI_TYPE = Platform.ABIType.query(CPU_TYPE, CPU_ABI);
/* 122 */       if (null != CPU_ABI2 && CPU_ABI2.length() > 0) {
/* 123 */         CPU_TYPE2 = Platform.CPUType.query(CPU_ABI2);
/* 124 */         ABI_TYPE2 = Platform.ABIType.query(CPU_TYPE2, CPU_ABI2);
/*     */       } else {
/* 126 */         CPU_TYPE2 = null;
/* 127 */         ABI_TYPE2 = null;
/*     */       } 
/*     */     } else {
/* 130 */       CPU_ABI = null;
/* 131 */       CPU_ABI2 = null;
/* 132 */       CODENAME = null;
/* 133 */       INCREMENTAL = null;
/* 134 */       RELEASE = null;
/* 135 */       SDK_INT = -1;
/* 136 */       SDK_NAME = null;
/* 137 */       CPU_TYPE = null;
/* 138 */       ABI_TYPE = null;
/* 139 */       CPU_TYPE2 = null;
/* 140 */       ABI_TYPE2 = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final IntObjectHashMap getVersionCodes(Class<?> paramClass, Object paramObject) {
/* 145 */     Field[] arrayOfField = paramClass.getFields();
/* 146 */     IntObjectHashMap intObjectHashMap = new IntObjectHashMap(3 * arrayOfField.length / 2, 0.75F);
/* 147 */     for (byte b = 0; b < arrayOfField.length; b++) {
/*     */       
/* 149 */       try { int i = arrayOfField[b].getInt(paramObject);
/* 150 */         String str = arrayOfField[b].getName();
/*     */         
/* 152 */         intObjectHashMap.put((new Integer(i)).intValue(), str); }
/* 153 */       catch (Exception exception) { exception.printStackTrace(); }
/*     */     
/* 155 */     }  return intObjectHashMap;
/*     */   }
/*     */   
/*     */   private static final String getString(Class<?> paramClass, Object paramObject, String paramString, boolean paramBoolean) {
/*     */     try {
/* 160 */       Field field = paramClass.getField(paramString);
/* 161 */       String str = (String)field.get(paramObject);
/* 162 */       if (paramBoolean && null != str) {
/* 163 */         return str.toLowerCase();
/*     */       }
/* 165 */       return str;
/*     */     } catch (Exception exception) {
/* 167 */       exception.printStackTrace();
/* 168 */       return null;
/*     */     } 
/*     */   }
/*     */   private static final int getInt(Class<?> paramClass, Object paramObject, String paramString) {
/*     */     
/* 173 */     try { Field field = paramClass.getField(paramString);
/* 174 */       return field.getInt(paramObject); }
/* 175 */     catch (Exception exception) { exception.printStackTrace();
/* 176 */       return -1; }
/*     */   
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/AndroidVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */