/*     */ package com.jogamp.common.os;
/*     */ 
/*     */ import com.jogamp.common.jvm.JNILibLoaderBase;
/*     */ import com.jogamp.common.net.Uri;
/*     */ import com.jogamp.common.util.JarUtil;
/*     */ import com.jogamp.common.util.PropertyAccess;
/*     */ import com.jogamp.common.util.ReflectionUtil;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import com.jogamp.common.util.VersionNumber;
/*     */ import com.jogamp.common.util.cache.TempJarCache;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import jogamp.common.Debug;
/*     */ import jogamp.common.jvm.JVMUtil;
/*     */ import jogamp.common.os.MachineDataInfoRuntime;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Platform
/*     */   extends PlatformPropsImpl
/*     */ {
/*     */   private static final String useTempJarCachePropName = "jogamp.gluegen.UseTempJarCache";
/*     */   private static final String libBaseName = "gluegen_rt";
/*     */   public static final boolean USE_TEMP_JAR_CACHE;
/*     */   private static final MachineDataInfo machineDescription;
/*     */   public static final boolean AWT_AVAILABLE;
/*     */   private static final boolean isRunningFromJarURL;
/*     */   
/*     */   public enum OSType
/*     */   {
/*  61 */     LINUX, FREEBSD, ANDROID, MACOS, SUNOS, HPUX, WINDOWS, OPENKODE, IOS;
/*     */   }
/*     */   
/*     */   public enum CPUFamily
/*     */   {
/*  66 */     X86,
/*     */     
/*  68 */     ARM,
/*     */     
/*  70 */     PPC,
/*     */     
/*  72 */     SPARC,
/*     */     
/*  74 */     MIPS,
/*     */     
/*  76 */     PA_RISC,
/*     */     
/*  78 */     IA64,
/*     */     
/*  80 */     SuperH;
/*     */   }
/*     */   
/*     */   public enum CPUType
/*     */   {
/*  85 */     ARM((String)Platform.CPUFamily.ARM, true),
/*     */     
/*  87 */     ARMv5((String)Platform.CPUFamily.ARM, true),
/*     */     
/*  89 */     ARMv6((String)Platform.CPUFamily.ARM, true),
/*     */     
/*  91 */     ARMv7((String)Platform.CPUFamily.ARM, true),
/*     */ 
/*     */ 
/*     */     
/*  95 */     X86_32((String)Platform.CPUFamily.X86, true),
/*     */     
/*  97 */     PPC((String)Platform.CPUFamily.PPC, true),
/*     */     
/*  99 */     MIPS_32((String)Platform.CPUFamily.MIPS, true),
/*     */     
/* 101 */     SuperH((String)Platform.CPUFamily.SuperH, true),
/*     */     
/* 103 */     SPARC_32((String)Platform.CPUFamily.SPARC, true),
/*     */ 
/*     */ 
/*     */     
/* 107 */     ARM64((String)Platform.CPUFamily.ARM, false),
/*     */     
/* 109 */     ARMv8_A((String)Platform.CPUFamily.ARM, false),
/*     */     
/* 111 */     X86_64((String)Platform.CPUFamily.X86, false),
/*     */     
/* 113 */     PPC64((String)Platform.CPUFamily.PPC, false),
/*     */     
/* 115 */     MIPS_64((String)Platform.CPUFamily.MIPS, false),
/*     */     
/* 117 */     IA64((String)Platform.CPUFamily.IA64, false),
/*     */     
/* 119 */     SPARCV9_64((String)Platform.CPUFamily.SPARC, false),
/*     */     
/* 121 */     PA_RISC2_0((String)Platform.CPUFamily.PA_RISC, false);
/*     */     
/*     */     public final Platform.CPUFamily family;
/*     */     
/*     */     public final boolean is32Bit;
/*     */     
/*     */     CPUType(Platform.CPUFamily param1CPUFamily, boolean param1Boolean) {
/* 128 */       this.family = param1CPUFamily;
/* 129 */       this.is32Bit = param1Boolean;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isCompatible(CPUType param1CPUType) {
/* 137 */       if (null == param1CPUType)
/* 138 */         return false; 
/* 139 */       if (param1CPUType == this) {
/* 140 */         return true;
/*     */       }
/* 142 */       return (this.family == param1CPUType.family && this.is32Bit == param1CPUType.is32Bit);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static final CPUType query(String param1String) {
/* 148 */       if (null == param1String) {
/* 149 */         throw new IllegalArgumentException("Null cpuABILower arg");
/*     */       }
/* 151 */       if (param1String.equals("x86") || param1String
/* 152 */         .equals("i386") || param1String
/* 153 */         .equals("i486") || param1String
/* 154 */         .equals("i586") || param1String
/* 155 */         .equals("i686"))
/* 156 */         return X86_32; 
/* 157 */       if (param1String.equals("x86_64") || param1String
/* 158 */         .equals("amd64"))
/* 159 */         return X86_64; 
/* 160 */       if (param1String.equals("ia64"))
/* 161 */         return IA64; 
/* 162 */       if (param1String.equals("aarch64"))
/* 163 */         return ARM64; 
/* 164 */       if (param1String.startsWith("arm")) {
/* 165 */         if (param1String.equals("armv8-a") || param1String
/* 166 */           .equals("arm-v8-a") || param1String
/* 167 */           .equals("arm-8-a") || param1String
/* 168 */           .equals("arm64-v8a"))
/* 169 */           return ARMv8_A; 
/* 170 */         if (param1String.startsWith("arm64"))
/* 171 */           return ARM64; 
/* 172 */         if (param1String.startsWith("armv7") || param1String
/* 173 */           .startsWith("arm-v7") || param1String
/* 174 */           .startsWith("arm-7") || param1String
/* 175 */           .startsWith("armeabi-v7"))
/* 176 */           return ARMv7; 
/* 177 */         if (param1String.startsWith("armv5") || param1String
/* 178 */           .startsWith("arm-v5") || param1String
/* 179 */           .startsWith("arm-5"))
/* 180 */           return ARMv5; 
/* 181 */         if (param1String.startsWith("armv6") || param1String
/* 182 */           .startsWith("arm-v6") || param1String
/* 183 */           .startsWith("arm-6")) {
/* 184 */           return ARMv6;
/*     */         }
/* 186 */         return ARM;
/*     */       } 
/* 188 */       if (param1String.equals("sparcv9"))
/* 189 */         return SPARCV9_64; 
/* 190 */       if (param1String.equals("sparc"))
/* 191 */         return SPARC_32; 
/* 192 */       if (param1String.equals("pa_risc2.0"))
/* 193 */         return PA_RISC2_0; 
/* 194 */       if (param1String.startsWith("ppc64"))
/* 195 */         return PPC64; 
/* 196 */       if (param1String.startsWith("ppc"))
/* 197 */         return PPC; 
/* 198 */       if (param1String.startsWith("mips64"))
/* 199 */         return MIPS_64; 
/* 200 */       if (param1String.startsWith("mips"))
/* 201 */         return MIPS_32; 
/* 202 */       if (param1String.startsWith("superh")) {
/* 203 */         return SuperH;
/*     */       }
/* 205 */       throw new RuntimeException("Please port CPUType detection to your platform (CPU_ABI string '" + param1String + "')");
/*     */     }
/*     */   }
/*     */   
/*     */   public enum ABIType
/*     */   {
/* 211 */     GENERIC_ABI(0),
/*     */     
/* 213 */     EABI_GNU_ARMEL(1),
/*     */     
/* 215 */     EABI_GNU_ARMHF(2),
/*     */     
/* 217 */     EABI_AARCH64(3);
/*     */     
/*     */     public final int id;
/*     */     
/*     */     ABIType(int param1Int1) {
/* 222 */       this.id = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isCompatible(ABIType param1ABIType) {
/* 230 */       if (null == param1ABIType) {
/* 231 */         return false;
/*     */       }
/* 233 */       return (param1ABIType == this);
/*     */     }
/*     */ 
/*     */     
/*     */     public static final ABIType query(Platform.CPUType param1CPUType, String param1String) {
/* 238 */       if (null == param1CPUType)
/* 239 */         throw new IllegalArgumentException("Null cpuType"); 
/* 240 */       if (null == param1String)
/* 241 */         throw new IllegalArgumentException("Null cpuABILower"); 
/* 242 */       if (Platform.CPUFamily.ARM == param1CPUType.family) {
/* 243 */         if (!param1CPUType.is32Bit)
/* 244 */           return EABI_AARCH64; 
/* 245 */         if (param1String.equals("armeabi-v7a-hard")) {
/* 246 */           return EABI_GNU_ARMHF;
/*     */         }
/* 248 */         return EABI_GNU_ARMEL;
/*     */       } 
/*     */       
/* 251 */       return GENERIC_ABI;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 286 */     final boolean[] _isRunningFromJarURL = { false };
/* 287 */     final boolean[] _USE_TEMP_JAR_CACHE = { false };
/* 288 */     final boolean[] _AWT_AVAILABLE = { false };
/*     */     
/* 290 */     SecurityUtil.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run()
/*     */           {
/* 294 */             PlatformPropsImpl.initSingleton();
/*     */             
/* 296 */             ClassLoader classLoader = Platform.class.getClassLoader();
/*     */ 
/*     */ 
/*     */             
/* 300 */             Uri uri2 = null;
/*     */             try {
/* 302 */               uri2 = JarUtil.getJarUri(Platform.class.getName(), classLoader);
/* 303 */             } catch (Exception exception) {}
/* 304 */             Uri uri1 = uri2;
/*     */             
/* 306 */             _isRunningFromJarURL[0] = (null != uri1);
/*     */             
/* 308 */             _USE_TEMP_JAR_CACHE[0] = (PlatformPropsImpl.OS_TYPE != Platform.OSType.ANDROID && PlatformPropsImpl.OS_TYPE != Platform.OSType.IOS && null != uri1 && 
/*     */               
/* 310 */               PropertyAccess.getBooleanProperty("jogamp.gluegen.UseTempJarCache", true, true));
/*     */ 
/*     */             
/* 313 */             if (_USE_TEMP_JAR_CACHE[0] && TempJarCache.initSingleton() && TempJarCache.isInitialized(true)) {
/*     */               try {
/* 315 */                 JNILibLoaderBase.addNativeJarLibs(new Class[] { Debug.class }, null);
/* 316 */               } catch (Exception exception) {
/*     */                 
/* 318 */                 System.err.println("Caught " + exception.getClass().getSimpleName() + ": " + exception.getMessage() + ", while JNILibLoaderBase.addNativeJarLibs(..)");
/*     */               } 
/*     */             }
/* 321 */             DynamicLibraryBundle.GlueJNILibLoader.loadLibrary("gluegen_rt", false, classLoader);
/*     */ 
/*     */             
/* 324 */             JVMUtil.initSingleton();
/*     */ 
/*     */             
/* 327 */             if (!PropertyAccess.getBooleanProperty("java.awt.headless", true) && 
/* 328 */               ReflectionUtil.isClassAvailable("java.awt.Component", classLoader) && 
/* 329 */               ReflectionUtil.isClassAvailable("java.awt.GraphicsEnvironment", classLoader)) {
/*     */               try {
/* 331 */                 _AWT_AVAILABLE[0] = (false == ((Boolean)ReflectionUtil.callStaticMethod("java.awt.GraphicsEnvironment", "isHeadless", null, null, classLoader)).booleanValue());
/* 332 */               } catch (Throwable throwable) {}
/*     */             }
/* 334 */             return null; }
/*     */         });
/* 336 */     isRunningFromJarURL = arrayOfBoolean1[0];
/* 337 */     USE_TEMP_JAR_CACHE = arrayOfBoolean2[0];
/* 338 */     AWT_AVAILABLE = arrayOfBoolean3[0];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 343 */     MachineDataInfoRuntime.initialize();
/* 344 */     machineDescription = MachineDataInfoRuntime.getRuntime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isRunningFromJarURL() {
/* 353 */     return isRunningFromJarURL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initSingleton() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLittleEndian() {
/* 365 */     return LITTLE_ENDIAN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getOSName() {
/* 373 */     return OS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getOSVersion() {
/* 380 */     return OS_VERSION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VersionNumber getOSVersionNumber() {
/* 387 */     return OS_VERSION_NUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getArchName() {
/* 394 */     return ARCH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OSType getOSType() {
/* 402 */     return OS_TYPE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CPUFamily getCPUFamily() {
/* 409 */     return CPU_ARCH.family;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CPUType getCPUType() {
/* 416 */     return CPU_ARCH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean is32Bit() {
/* 424 */     return CPU_ARCH.is32Bit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean is64Bit() {
/* 432 */     return !CPU_ARCH.is32Bit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ABIType getABIType() {
/* 445 */     return ABI_TYPE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getOSAndArch() {
/* 455 */     return os_and_arch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJavaVendor() {
/* 462 */     return JAVA_VENDOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJavaVMName() {
/* 469 */     return JAVA_VM_NAME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJavaRuntimeName() {
/* 476 */     return JAVA_RUNTIME_NAME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJavaVendorURL() {
/* 483 */     return JAVA_VENDOR_URL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJavaVersion() {
/* 490 */     return JAVA_VERSION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VersionNumber getJavaVersionNumber() {
/* 497 */     return JAVA_VERSION_NUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getNewline() {
/* 504 */     return NEWLINE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MachineDataInfo getMachineDataInfo() {
/* 511 */     return machineDescription;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isAWTAvailable() {
/* 516 */     return AWT_AVAILABLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long currentTimeMillis() {
/* 528 */     return Clock.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized long getCurrentSleepJitter() {
/* 538 */     getCurrentSleepJitterImpl(TimeUnit.MILLISECONDS.toNanos(10L), 10);
/* 539 */     return getCurrentSleepJitterImpl(TimeUnit.MILLISECONDS.toNanos(10L), 10);
/*     */   }
/*     */   private static long getCurrentSleepJitterImpl(long paramLong, int paramInt) {
/* 542 */     long l1 = paramLong / paramInt;
/* 543 */     long l2 = Clock.currentNanos();
/* 544 */     for (int i = paramInt; i > 0; i--) { 
/* 545 */       try { TimeUnit.NANOSECONDS.sleep(l1); } catch (InterruptedException interruptedException) {} }
/*     */     
/* 547 */     return (Clock.currentNanos() - l2 - paramLong) / paramInt;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/Platform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */