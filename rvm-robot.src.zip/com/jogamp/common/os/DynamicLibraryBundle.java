/*     */ package com.jogamp.common.os;
/*     */ 
/*     */ import com.jogamp.common.jvm.JNILibLoaderBase;
/*     */ import com.jogamp.common.util.RunnableExecutor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynamicLibraryBundle
/*     */   implements DynamicLookupHelper
/*     */ {
/*     */   private final DynamicLibraryBundleInfo info;
/*     */   protected final List<NativeLibrary> nativeLibraries;
/*     */   private final DynamicLinker dynLinkGlobal;
/*     */   private final List<List<String>> toolLibNames;
/*     */   private final List<String> glueLibNames;
/*     */   private final boolean[] toolLibLoaded;
/*     */   private int toolLibLoadedNumber;
/*     */   private final boolean[] glueLibLoaded;
/*     */   private int glueLibLoadedNumber;
/*     */   private long toolGetProcAddressHandle;
/*     */   private boolean toolGetProcAddressComplete;
/*     */   private HashSet<String> toolGetProcAddressFuncNameSet;
/*     */   private final List<String> toolGetProcAddressFuncNameList;
/*     */   
/*     */   public static RunnableExecutor getDefaultRunnableExecutor() {
/*  82 */     return RunnableExecutor.currentThreadExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicLibraryBundle(DynamicLibraryBundleInfo paramDynamicLibraryBundleInfo) {
/*  93 */     if (null == paramDynamicLibraryBundleInfo) {
/*  94 */       throw new RuntimeException("Null DynamicLibraryBundleInfo");
/*     */     }
/*  96 */     this.info = paramDynamicLibraryBundleInfo;
/*  97 */     if (DEBUG) {
/*  98 */       System.err.println(Thread.currentThread().getName() + " - DynamicLibraryBundle.init start with: " + paramDynamicLibraryBundleInfo.getClass().getName());
/*     */     }
/* 100 */     this.nativeLibraries = new ArrayList<>();
/* 101 */     this.toolLibNames = paramDynamicLibraryBundleInfo.getToolLibNames();
/* 102 */     this.glueLibNames = paramDynamicLibraryBundleInfo.getGlueLibNames();
/* 103 */     this.toolLibLoaded = new boolean[this.toolLibNames.size()];
/* 104 */     if (DEBUG) {
/* 105 */       if (this.toolLibNames.size() == 0) {
/* 106 */         System.err.println("No Tool native library names given");
/*     */       }
/*     */       
/* 109 */       if (this.glueLibNames.size() == 0) {
/* 110 */         System.err.println("No Glue native library names given");
/*     */       }
/*     */     } 
/*     */     int i;
/* 114 */     for (i = this.toolLibNames.size() - 1; i >= 0; i--) {
/* 115 */       this.toolLibLoaded[i] = false;
/*     */     }
/* 117 */     this.glueLibLoaded = new boolean[this.glueLibNames.size()];
/* 118 */     for (i = this.glueLibNames.size() - 1; i >= 0; i--) {
/* 119 */       this.glueLibLoaded[i] = false;
/*     */     }
/*     */ 
/*     */     
/* 123 */     final DynamicLinker[] _dynLinkGlobal = { null };
/* 124 */     paramDynamicLibraryBundleInfo.getLibLoaderExecutor().invoke(true, new Runnable()
/*     */         {
/*     */           public void run() {
/* 127 */             _dynLinkGlobal[0] = DynamicLibraryBundle.this.loadLibraries(); }
/*     */         });
/* 129 */     this.dynLinkGlobal = arrayOfDynamicLinker[0];
/*     */ 
/*     */     
/* 132 */     this.toolGetProcAddressFuncNameList = paramDynamicLibraryBundleInfo.getToolGetProcAddressFuncNameList();
/* 133 */     if (null != this.toolGetProcAddressFuncNameList) {
/* 134 */       this.toolGetProcAddressFuncNameSet = new HashSet<>(this.toolGetProcAddressFuncNameList);
/* 135 */       this.toolGetProcAddressHandle = getToolGetProcAddressHandle();
/* 136 */       this.toolGetProcAddressComplete = (0L != this.toolGetProcAddressHandle);
/*     */     } else {
/* 138 */       this.toolGetProcAddressFuncNameSet = new HashSet<>();
/* 139 */       this.toolGetProcAddressHandle = 0L;
/* 140 */       this.toolGetProcAddressComplete = true;
/*     */     } 
/* 142 */     if (DEBUG) {
/* 143 */       System.err.println("DynamicLibraryBundle.init Summary: " + paramDynamicLibraryBundleInfo.getClass().getName());
/* 144 */       System.err.println("     toolGetProcAddressFuncNameList: " + this.toolGetProcAddressFuncNameList + ", complete: " + this.toolGetProcAddressComplete + ", 0x" + Long.toHexString(this.toolGetProcAddressHandle));
/* 145 */       System.err.println("     Tool Lib Names : " + this.toolLibNames);
/* 146 */       System.err.println("     Tool Lib Loaded: " + getToolLibLoadedNumber() + "/" + getToolLibNumber() + " " + Arrays.toString(this.toolLibLoaded) + ", complete " + isToolLibComplete());
/* 147 */       System.err.println("     Glue Lib Names : " + this.glueLibNames);
/* 148 */       System.err.println("     Glue Lib Loaded: " + getGlueLibLoadedNumber() + "/" + getGlueLibNumber() + " " + Arrays.toString(this.glueLibLoaded) + ", complete " + isGlueLibComplete());
/* 149 */       System.err.println("     All Complete: " + isLibComplete());
/* 150 */       System.err.println("     LibLoaderExecutor: " + paramDynamicLibraryBundleInfo.getLibLoaderExecutor().getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void destroy() {
/* 156 */     if (DEBUG) {
/* 157 */       System.err.println(Thread.currentThread().getName() + " - DynamicLibraryBundle.destroy() START: " + this.info.getClass().getName());
/*     */     }
/* 159 */     this.toolGetProcAddressFuncNameSet = null;
/* 160 */     this.toolGetProcAddressHandle = 0L;
/* 161 */     this.toolGetProcAddressComplete = false;
/* 162 */     for (byte b = 0; b < this.nativeLibraries.size(); b++) {
/* 163 */       ((NativeLibrary)this.nativeLibraries.get(b)).close();
/*     */     }
/* 165 */     this.nativeLibraries.clear();
/* 166 */     this.toolLibNames.clear();
/* 167 */     this.glueLibNames.clear();
/* 168 */     if (DEBUG) {
/* 169 */       System.err.println(Thread.currentThread().getName() + " - DynamicLibraryBundle.destroy() END: " + this.info.getClass().getName());
/*     */     }
/*     */   }
/*     */   
/*     */   public final boolean isLibComplete() {
/* 174 */     return (isToolLibComplete() && isGlueLibComplete());
/*     */   }
/*     */   
/*     */   public final int getToolLibNumber() {
/* 178 */     return this.toolLibNames.size();
/*     */   }
/*     */   
/*     */   public final int getToolLibLoadedNumber() {
/* 182 */     return this.toolLibLoadedNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isToolLibComplete() {
/* 192 */     int i = getToolLibNumber();
/* 193 */     return (this.toolGetProcAddressComplete && (0 == i || null != this.dynLinkGlobal) && i == 
/*     */       
/* 195 */       getToolLibLoadedNumber());
/*     */   }
/*     */   
/*     */   public final boolean isToolLibLoaded() {
/* 199 */     return (0 < this.toolLibLoadedNumber);
/*     */   }
/*     */   
/*     */   public final boolean isToolLibLoaded(int paramInt) {
/* 203 */     if (0 <= paramInt && paramInt < this.toolLibLoaded.length) {
/* 204 */       return this.toolLibLoaded[paramInt];
/*     */     }
/* 206 */     return false;
/*     */   }
/*     */   
/*     */   public final int getGlueLibNumber() {
/* 210 */     return this.glueLibNames.size();
/*     */   }
/*     */   
/*     */   public final int getGlueLibLoadedNumber() {
/* 214 */     return this.glueLibLoadedNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isGlueLibComplete() {
/* 225 */     return (0 == getGlueLibNumber() || isGlueLibLoaded(getGlueLibNumber() - 1));
/*     */   }
/*     */   
/*     */   public final boolean isGlueLibLoaded(int paramInt) {
/* 229 */     if (0 <= paramInt && paramInt < this.glueLibLoaded.length) {
/* 230 */       return this.glueLibLoaded[paramInt];
/*     */     }
/* 232 */     return false;
/*     */   }
/*     */   public final DynamicLibraryBundleInfo getBundleInfo() {
/* 235 */     return this.info;
/*     */   }
/*     */   protected final long getToolGetProcAddressHandle() throws SecurityException {
/* 238 */     if (!isToolLibLoaded()) {
/* 239 */       return 0L;
/*     */     }
/* 241 */     long l = 0L;
/* 242 */     for (byte b = 0; b < this.toolGetProcAddressFuncNameList.size(); b++) {
/* 243 */       String str = this.toolGetProcAddressFuncNameList.get(b);
/* 244 */       l = dynamicLookupFunctionOnLibs(str);
/* 245 */       if (DEBUG) {
/* 246 */         System.err.println("getToolGetProcAddressHandle: " + str + " -> 0x" + Long.toHexString(l));
/*     */       }
/*     */     } 
/* 249 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final NativeLibrary loadFirstAvailable(List<String> paramList, boolean paramBoolean1, boolean paramBoolean2, ClassLoader paramClassLoader, boolean paramBoolean3) throws SecurityException {
/* 256 */     for (byte b = 0; b < paramList.size(); b++) {
/* 257 */       NativeLibrary nativeLibrary = NativeLibrary.open(paramList.get(b), paramBoolean1, paramBoolean2, paramClassLoader, paramBoolean3);
/* 258 */       if (nativeLibrary != null) {
/* 259 */         return nativeLibrary;
/*     */       }
/*     */     } 
/* 262 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   final DynamicLinker loadLibraries() throws SecurityException {
/* 267 */     this.toolLibLoadedNumber = 0;
/* 268 */     ClassLoader classLoader = this.info.getClass().getClassLoader();
/* 269 */     NativeLibrary nativeLibrary = null;
/* 270 */     DynamicLinker dynamicLinker = null;
/*     */     byte b;
/* 272 */     for (b = 0; b < this.toolLibNames.size(); b++) {
/* 273 */       List<String> list = this.toolLibNames.get(b);
/* 274 */       if (null != list && list.size() > 0) {
/* 275 */         nativeLibrary = loadFirstAvailable(list, this.info
/* 276 */             .searchToolLibInSystemPath(), this.info
/* 277 */             .searchToolLibSystemPathFirst(), classLoader, this.info
/* 278 */             .shallLinkGlobal());
/* 279 */         if (null == nativeLibrary) {
/* 280 */           if (DEBUG) {
/* 281 */             System.err.println("Unable to load any Tool library of: " + list);
/*     */           }
/*     */         } else {
/* 284 */           if (null == dynamicLinker) {
/* 285 */             dynamicLinker = nativeLibrary.dynamicLinker();
/*     */           }
/* 287 */           this.nativeLibraries.add(nativeLibrary);
/* 288 */           this.toolLibLoaded[b] = true;
/* 289 */           this.toolLibLoadedNumber++;
/* 290 */           if (DEBUG) {
/* 291 */             System.err.println("Loaded Tool library: " + nativeLibrary);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 296 */     if (this.toolLibNames.size() > 0 && !isToolLibLoaded()) {
/* 297 */       if (DEBUG) {
/* 298 */         System.err.println("No Tool libraries loaded");
/*     */       }
/* 300 */       return dynamicLinker;
/*     */     } 
/*     */     
/* 303 */     this.glueLibLoadedNumber = 0;
/* 304 */     for (b = 0; b < this.glueLibNames.size(); b++) {
/* 305 */       boolean bool; String str = this.glueLibNames.get(b);
/*     */ 
/*     */       
/*     */       try {
/* 309 */         bool = GlueJNILibLoader.loadLibrary(str, true, classLoader);
/* 310 */         if (DEBUG && !bool) {
/* 311 */           System.err.println("Info: Could not load JNI/Glue library: " + str);
/*     */         }
/* 313 */       } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 314 */         bool = false;
/* 315 */         if (DEBUG) {
/* 316 */           System.err.println("Unable to load JNI/Glue library: " + str);
/* 317 */           unsatisfiedLinkError.printStackTrace();
/*     */         } 
/*     */       } 
/* 320 */       this.glueLibLoaded[b] = bool;
/* 321 */       if (bool) {
/* 322 */         this.glueLibLoadedNumber++;
/*     */       }
/*     */     } 
/*     */     
/* 326 */     return dynamicLinker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final long dynamicLookupFunctionOnLibs(String paramString) throws SecurityException {
/* 335 */     if (!isToolLibLoaded() || null == paramString) {
/* 336 */       if (DEBUG_LOOKUP && !isToolLibLoaded()) {
/* 337 */         System.err.println("Lookup-Native: <" + paramString + "> ** FAILED ** Tool native library not loaded");
/*     */       }
/* 339 */       return 0L;
/*     */     } 
/* 341 */     long l = 0L;
/* 342 */     NativeLibrary nativeLibrary = null;
/*     */     
/* 344 */     if (this.info.shallLookupGlobal())
/*     */     {
/*     */       
/* 347 */       l = this.dynLinkGlobal.lookupSymbolGlobal(paramString);
/*     */     }
/*     */     
/* 350 */     for (byte b = 0; 0L == l && b < this.nativeLibraries.size(); b++) {
/* 351 */       nativeLibrary = this.nativeLibraries.get(b);
/* 352 */       l = nativeLibrary.dynamicLookupFunction(paramString);
/*     */     } 
/* 354 */     if (DEBUG_LOOKUP) {
/* 355 */       String str = (null == nativeLibrary) ? "GLOBAL" : nativeLibrary.toString();
/* 356 */       if (0L != l) {
/* 357 */         System.err.println("Lookup-Native: <" + paramString + "> 0x" + Long.toHexString(l) + " in lib " + str);
/*     */       } else {
/* 359 */         System.err.println("Lookup-Native: <" + paramString + "> ** FAILED ** in libs " + this.nativeLibraries);
/*     */       } 
/*     */     } 
/* 362 */     return l;
/*     */   }
/*     */   
/*     */   private final long toolDynamicLookupFunction(String paramString) {
/* 366 */     if (0L != this.toolGetProcAddressHandle) {
/* 367 */       long l = this.info.toolGetProcAddress(this.toolGetProcAddressHandle, paramString);
/* 368 */       if (DEBUG_LOOKUP && 
/* 369 */         0L != l) {
/* 370 */         System.err.println("Lookup-Tool: <" + paramString + "> 0x" + Long.toHexString(l) + ", via tool 0x" + Long.toHexString(this.toolGetProcAddressHandle));
/*     */       }
/*     */       
/* 373 */       return l;
/*     */     } 
/* 375 */     return 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void claimAllLinkPermission() throws SecurityException {
/* 380 */     for (byte b = 0; b < this.nativeLibraries.size(); b++) {
/* 381 */       ((NativeLibrary)this.nativeLibraries.get(b)).claimAllLinkPermission();
/*     */     }
/*     */   }
/*     */   
/*     */   public final void releaseAllLinkPermission() throws SecurityException {
/* 386 */     for (byte b = 0; b < this.nativeLibraries.size(); b++) {
/* 387 */       ((NativeLibrary)this.nativeLibraries.get(b)).releaseAllLinkPermission();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final long dynamicLookupFunction(String paramString) throws SecurityException {
/* 393 */     if (!isToolLibLoaded() || null == paramString) {
/* 394 */       if (DEBUG_LOOKUP && !isToolLibLoaded()) {
/* 395 */         System.err.println("Lookup: <" + paramString + "> ** FAILED ** Tool native library not loaded");
/*     */       }
/* 397 */       return 0L;
/*     */     } 
/*     */     
/* 400 */     if (this.toolGetProcAddressFuncNameSet.contains(paramString)) {
/* 401 */       return this.toolGetProcAddressHandle;
/*     */     }
/*     */     
/* 404 */     long l = 0L;
/* 405 */     boolean bool = this.info.useToolGetProcAdressFirst(paramString);
/*     */     
/* 407 */     if (bool) {
/* 408 */       l = toolDynamicLookupFunction(paramString);
/*     */     }
/* 410 */     if (0L == l) {
/* 411 */       l = dynamicLookupFunctionOnLibs(paramString);
/*     */     }
/* 413 */     if (0L == l && !bool) {
/* 414 */       l = toolDynamicLookupFunction(paramString);
/*     */     }
/* 416 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isFunctionAvailable(String paramString) throws SecurityException {
/* 421 */     return (0L != dynamicLookupFunction(paramString));
/*     */   }
/*     */   
/*     */   static final class GlueJNILibLoader
/*     */     extends JNILibLoaderBase {
/*     */     protected static synchronized boolean loadLibrary(String param1String, boolean param1Boolean, ClassLoader param1ClassLoader) {
/* 427 */       return JNILibLoaderBase.loadLibrary(param1String, param1Boolean, param1ClassLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/DynamicLibraryBundle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */