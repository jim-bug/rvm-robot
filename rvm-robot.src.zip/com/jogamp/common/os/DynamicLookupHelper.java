/*    */ package com.jogamp.common.os;
/*    */ 
/*    */ import jogamp.common.Debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface DynamicLookupHelper
/*    */ {
/* 50 */   public static final boolean DEBUG = Debug.debug("NativeLibrary");
/* 51 */   public static final boolean DEBUG_LOOKUP = Debug.debug("NativeLibrary.Lookup");
/*    */   
/*    */   void claimAllLinkPermission() throws SecurityException;
/*    */   
/*    */   void releaseAllLinkPermission() throws SecurityException;
/*    */   
/*    */   long dynamicLookupFunction(String paramString) throws SecurityException;
/*    */   
/*    */   boolean isFunctionAvailable(String paramString) throws SecurityException;
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/DynamicLookupHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */