/*     */ package com.jogamp.common.os;
/*     */ 
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MachineDataInfo
/*     */ {
/*  59 */   private static final int[] size_arm_mips_32 = new int[] { 4, 4, 4, 8, 8, 4, 4096 };
/*  60 */   private static final int[] size_x86_32_unix = new int[] { 4, 4, 4, 8, 12, 4, 4096 };
/*  61 */   private static final int[] size_x86_32_android = new int[] { 4, 4, 4, 8, 8, 4, 4096 };
/*  62 */   private static final int[] size_x86_32_macos = new int[] { 4, 4, 4, 8, 16, 4, 4096 };
/*  63 */   private static final int[] size_ppc_32_unix = new int[] { 4, 4, 4, 8, 16, 4, 4096 };
/*  64 */   private static final int[] size_sparc_32_sunos = new int[] { 4, 4, 4, 8, 16, 4, 8192 };
/*  65 */   private static final int[] size_x86_32_windows = new int[] { 4, 4, 4, 8, 12, 4, 4096 };
/*  66 */   private static final int[] size_lp64_unix = new int[] { 4, 8, 4, 8, 16, 8, 4096 };
/*  67 */   private static final int[] size_x86_64_windows = new int[] { 4, 4, 4, 8, 16, 8, 4096 };
/*  68 */   private static final int[] size_arm64_ios = new int[] { 4, 8, 4, 8, 8, 8, 8192 };
/*     */ 
/*     */   
/*  71 */   private static final int[] align_arm_mips_32 = new int[] { 1, 2, 4, 8, 4, 4, 4, 8, 8, 4 };
/*  72 */   private static final int[] align_x86_32_unix = new int[] { 1, 2, 4, 4, 4, 4, 4, 4, 4, 4 };
/*  73 */   private static final int[] align_x86_32_macos = new int[] { 1, 2, 4, 4, 4, 4, 4, 4, 16, 4 };
/*  74 */   private static final int[] align_ppc_32_unix = new int[] { 1, 2, 4, 8, 4, 4, 4, 8, 16, 4 };
/*  75 */   private static final int[] align_sparc_32_sunos = new int[] { 1, 2, 4, 8, 4, 4, 4, 8, 8, 4 };
/*  76 */   private static final int[] align_x86_32_windows = new int[] { 1, 2, 4, 8, 4, 4, 4, 8, 4, 4 };
/*  77 */   private static final int[] align_lp64_unix = new int[] { 1, 2, 4, 8, 4, 8, 4, 8, 16, 8 };
/*  78 */   private static final int[] align_x86_64_windows = new int[] { 1, 2, 4, 8, 4, 4, 4, 8, 16, 8 };
/*  79 */   private static final int[] align_arm64_ios = new int[] { 1, 2, 4, 8, 4, 8, 4, 8, 8, 8 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean runtimeValidated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum StaticConfig
/*     */   {
/* 101 */     ARM_MIPS_32((String)MachineDataInfo.size_arm_mips_32, MachineDataInfo.align_arm_mips_32),
/*     */     
/* 103 */     X86_32_UNIX((String)MachineDataInfo.size_x86_32_unix, MachineDataInfo.align_x86_32_unix),
/*     */     
/* 105 */     X86_32_ANDROID((String)MachineDataInfo.size_x86_32_android, MachineDataInfo.align_x86_32_unix),
/*     */     
/* 107 */     X86_32_MACOS((String)MachineDataInfo.size_x86_32_macos, MachineDataInfo.align_x86_32_macos),
/*     */     
/* 109 */     PPC_32_UNIX((String)MachineDataInfo.size_ppc_32_unix, MachineDataInfo.align_ppc_32_unix),
/*     */     
/* 111 */     SPARC_32_SUNOS((String)MachineDataInfo.size_sparc_32_sunos, MachineDataInfo.align_sparc_32_sunos),
/*     */     
/* 113 */     X86_32_WINDOWS((String)MachineDataInfo.size_x86_32_windows, MachineDataInfo.align_x86_32_windows),
/*     */     
/* 115 */     LP64_UNIX((String)MachineDataInfo.size_lp64_unix, MachineDataInfo.align_lp64_unix),
/*     */     
/* 117 */     X86_64_WINDOWS((String)MachineDataInfo.size_x86_64_windows, MachineDataInfo.align_x86_64_windows),
/*     */     
/* 119 */     ARM64_IOS((String)MachineDataInfo.size_arm64_ios, MachineDataInfo.align_arm64_ios);
/*     */     
/*     */     public final MachineDataInfo md;
/*     */ 
/*     */     
/*     */     StaticConfig(int[] param1ArrayOfint1, int[] param1ArrayOfint2) {
/* 125 */       byte b1 = 0, b2 = 0;
/* 126 */       this.md = new MachineDataInfo(false, param1ArrayOfint1[b1++], param1ArrayOfint1[b1++], param1ArrayOfint1[b1++], param1ArrayOfint1[b1++], param1ArrayOfint1[b1++], param1ArrayOfint1[b1++], param1ArrayOfint1[b1++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++], param1ArrayOfint2[b2++]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final StringBuilder toString(StringBuilder param1StringBuilder) {
/* 147 */       if (null == param1StringBuilder) {
/* 148 */         param1StringBuilder = new StringBuilder();
/*     */       }
/* 150 */       param1StringBuilder.append("MachineDataInfoStatic: ").append(name()).append("(").append(ordinal()).append("): ");
/* 151 */       this.md.toString(param1StringBuilder);
/* 152 */       return param1StringBuilder;
/*     */     }
/*     */     public final String toShortString() {
/* 155 */       return name() + "(" + ordinal() + ")";
/*     */     }
/*     */     
/*     */     public String toString() {
/* 159 */       return toString((StringBuilder)null).toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final void validateUniqueMachineDataInfo() {
/* 167 */       StaticConfig[] arrayOfStaticConfig = values();
/* 168 */       for (int i = arrayOfStaticConfig.length - 1; i >= 0; i--) {
/* 169 */         StaticConfig staticConfig = arrayOfStaticConfig[i];
/* 170 */         for (int j = arrayOfStaticConfig.length - 1; j >= 0; j--) {
/* 171 */           if (i != j) {
/* 172 */             StaticConfig staticConfig1 = arrayOfStaticConfig[j];
/* 173 */             if (staticConfig.md.compatible(staticConfig1.md)) {
/*     */               
/* 175 */               String str = "Duplicate/Compatible MachineDataInfo in StaticConfigs: Elements [" + i + ": " + staticConfig.toShortString() + "] and [" + j + ": " + staticConfig1.toShortString() + "]";
/* 176 */               System.err.println(str);
/* 177 */               System.err.println(staticConfig);
/* 178 */               System.err.println(staticConfig1);
/* 179 */               throw new InternalError(str);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     public static final StaticConfig findCompatible(MachineDataInfo param1MachineDataInfo) {
/* 186 */       StaticConfig[] arrayOfStaticConfig = values();
/* 187 */       for (int i = arrayOfStaticConfig.length - 1; i >= 0; i--) {
/* 188 */         StaticConfig staticConfig = arrayOfStaticConfig[i];
/* 189 */         if (staticConfig.md.compatible(param1MachineDataInfo)) {
/* 190 */           return staticConfig;
/*     */         }
/*     */       } 
/* 193 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 199 */   private final int int8SizeInBytes = 1;
/* 200 */   private final int int16SizeInBytes = 2;
/* 201 */   private final int int32SizeInBytes = 4;
/* 202 */   private final int int64SizeInBytes = 8;
/*     */ 
/*     */   
/*     */   private final int intSizeInBytes;
/*     */ 
/*     */   
/*     */   private final int longSizeInBytes;
/*     */ 
/*     */   
/*     */   private final int floatSizeInBytes;
/*     */   
/*     */   private final int doubleSizeInBytes;
/*     */   
/*     */   private final int ldoubleSizeInBytes;
/*     */   
/*     */   private final int pointerSizeInBytes;
/*     */   
/*     */   private final int pageSizeInBytes;
/*     */   
/*     */   private final int int8AlignmentInBytes;
/*     */   
/*     */   private final int int16AlignmentInBytes;
/*     */   
/*     */   private final int int32AlignmentInBytes;
/*     */   
/*     */   private final int int64AlignmentInBytes;
/*     */   
/*     */   private final int intAlignmentInBytes;
/*     */   
/*     */   private final int longAlignmentInBytes;
/*     */   
/*     */   private final int floatAlignmentInBytes;
/*     */   
/*     */   private final int doubleAlignmentInBytes;
/*     */   
/*     */   private final int ldoubleAlignmentInBytes;
/*     */   
/*     */   private final int pointerAlignmentInBytes;
/*     */ 
/*     */   
/*     */   public MachineDataInfo(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, int paramInt15, int paramInt16, int paramInt17) {
/* 243 */     this.runtimeValidated = paramBoolean;
/*     */     
/* 245 */     this.intSizeInBytes = paramInt1;
/* 246 */     this.longSizeInBytes = paramInt2;
/* 247 */     this.floatSizeInBytes = paramInt3;
/* 248 */     this.doubleSizeInBytes = paramInt4;
/* 249 */     this.ldoubleSizeInBytes = paramInt5;
/* 250 */     this.pointerSizeInBytes = paramInt6;
/* 251 */     this.pageSizeInBytes = paramInt7;
/*     */     
/* 253 */     this.int8AlignmentInBytes = paramInt8;
/* 254 */     this.int16AlignmentInBytes = paramInt9;
/* 255 */     this.int32AlignmentInBytes = paramInt10;
/* 256 */     this.int64AlignmentInBytes = paramInt11;
/* 257 */     this.intAlignmentInBytes = paramInt12;
/* 258 */     this.longAlignmentInBytes = paramInt13;
/* 259 */     this.floatAlignmentInBytes = paramInt14;
/* 260 */     this.doubleAlignmentInBytes = paramInt15;
/* 261 */     this.ldoubleAlignmentInBytes = paramInt16;
/* 262 */     this.pointerAlignmentInBytes = paramInt17;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isRuntimeValidated() {
/* 269 */     return this.runtimeValidated;
/*     */   }
/*     */   
/* 272 */   public final int intSizeInBytes() { return this.intSizeInBytes; }
/* 273 */   public final int longSizeInBytes() { return this.longSizeInBytes; }
/* 274 */   public final int int8SizeInBytes() { return 1; }
/* 275 */   public final int int16SizeInBytes() { return 2; }
/* 276 */   public final int int32SizeInBytes() { return 4; }
/* 277 */   public final int int64SizeInBytes() { return 8; }
/* 278 */   public final int floatSizeInBytes() { return this.floatSizeInBytes; }
/* 279 */   public final int doubleSizeInBytes() { return this.doubleSizeInBytes; }
/* 280 */   public final int ldoubleSizeInBytes() { return this.ldoubleSizeInBytes; }
/* 281 */   public final int pointerSizeInBytes() { return this.pointerSizeInBytes; } public final int pageSizeInBytes() {
/* 282 */     return this.pageSizeInBytes;
/*     */   }
/* 284 */   public final int intAlignmentInBytes() { return this.intAlignmentInBytes; }
/* 285 */   public final int longAlignmentInBytes() { return this.longAlignmentInBytes; }
/* 286 */   public final int int8AlignmentInBytes() { return this.int8AlignmentInBytes; }
/* 287 */   public final int int16AlignmentInBytes() { return this.int16AlignmentInBytes; }
/* 288 */   public final int int32AlignmentInBytes() { return this.int32AlignmentInBytes; }
/* 289 */   public final int int64AlignmentInBytes() { return this.int64AlignmentInBytes; }
/* 290 */   public final int floatAlignmentInBytes() { return this.floatAlignmentInBytes; }
/* 291 */   public final int doubleAlignmentInBytes() { return this.doubleAlignmentInBytes; }
/* 292 */   public final int ldoubleAlignmentInBytes() { return this.ldoubleAlignmentInBytes; } public final int pointerAlignmentInBytes() {
/* 293 */     return this.pointerAlignmentInBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int pageCount(int paramInt) {
/* 299 */     return (paramInt + this.pageSizeInBytes - 1) / this.pageSizeInBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int pageAlignedSize(int paramInt) {
/* 306 */     return pageCount(paramInt) * this.pageSizeInBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 318 */     if (this == paramObject) return true; 
/* 319 */     if (!(paramObject instanceof MachineDataInfo)) return false; 
/* 320 */     MachineDataInfo machineDataInfo = (MachineDataInfo)paramObject;
/*     */     
/* 322 */     return (this.pageSizeInBytes == machineDataInfo.pageSizeInBytes && 
/* 323 */       compatible(machineDataInfo));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean compatible(MachineDataInfo paramMachineDataInfo) {
/* 336 */     return (this.intSizeInBytes == paramMachineDataInfo.intSizeInBytes && this.longSizeInBytes == paramMachineDataInfo.longSizeInBytes && this.floatSizeInBytes == paramMachineDataInfo.floatSizeInBytes && this.doubleSizeInBytes == paramMachineDataInfo.doubleSizeInBytes && this.ldoubleSizeInBytes == paramMachineDataInfo.ldoubleSizeInBytes && this.pointerSizeInBytes == paramMachineDataInfo.pointerSizeInBytes && this.int8AlignmentInBytes == paramMachineDataInfo.int8AlignmentInBytes && this.int16AlignmentInBytes == paramMachineDataInfo.int16AlignmentInBytes && this.int32AlignmentInBytes == paramMachineDataInfo.int32AlignmentInBytes && this.int64AlignmentInBytes == paramMachineDataInfo.int64AlignmentInBytes && this.intAlignmentInBytes == paramMachineDataInfo.intAlignmentInBytes && this.longAlignmentInBytes == paramMachineDataInfo.longAlignmentInBytes && this.floatAlignmentInBytes == paramMachineDataInfo.floatAlignmentInBytes && this.doubleAlignmentInBytes == paramMachineDataInfo.doubleAlignmentInBytes && this.ldoubleAlignmentInBytes == paramMachineDataInfo.ldoubleAlignmentInBytes && this.pointerAlignmentInBytes == paramMachineDataInfo.pointerAlignmentInBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder toString(StringBuilder paramStringBuilder) {
/* 356 */     if (null == paramStringBuilder) {
/* 357 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 359 */     paramStringBuilder.append("MachineDataInfo: runtimeValidated ").append(isRuntimeValidated()).append(", 32Bit ").append((4 == this.pointerAlignmentInBytes)).append(", primitive size / alignment:").append(PlatformPropsImpl.NEWLINE);
/* 360 */     paramStringBuilder.append("  int8    ").append(1).append(" / ").append(this.int8AlignmentInBytes);
/* 361 */     paramStringBuilder.append(", int16   ").append(2).append(" / ").append(this.int16AlignmentInBytes).append(Platform.getNewline());
/* 362 */     paramStringBuilder.append("  int     ").append(this.intSizeInBytes).append(" / ").append(this.intAlignmentInBytes);
/* 363 */     paramStringBuilder.append(", long    ").append(this.longSizeInBytes).append(" / ").append(this.longAlignmentInBytes).append(Platform.getNewline());
/* 364 */     paramStringBuilder.append("  int32   ").append(4).append(" / ").append(this.int32AlignmentInBytes);
/* 365 */     paramStringBuilder.append(", int64   ").append(8).append(" / ").append(this.int64AlignmentInBytes).append(Platform.getNewline());
/* 366 */     paramStringBuilder.append("  float   ").append(this.floatSizeInBytes).append(" / ").append(this.floatAlignmentInBytes);
/* 367 */     paramStringBuilder.append(", double  ").append(this.doubleSizeInBytes).append(" / ").append(this.doubleAlignmentInBytes);
/* 368 */     paramStringBuilder.append(", ldouble ").append(this.ldoubleSizeInBytes).append(" / ").append(this.ldoubleAlignmentInBytes).append(Platform.getNewline());
/* 369 */     paramStringBuilder.append("  pointer ").append(this.pointerSizeInBytes).append(" / ").append(this.pointerAlignmentInBytes);
/* 370 */     paramStringBuilder.append(", page    ").append(this.pageSizeInBytes);
/* 371 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 376 */     return toString(null).toString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/MachineDataInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */