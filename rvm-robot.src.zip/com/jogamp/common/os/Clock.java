/*     */ package com.jogamp.common.os;
/*     */ 
/*     */ import java.time.Instant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Clock
/*     */ {
/*     */   private static final Instant t0;
/*     */   
/*     */   static {
/*  32 */     Platform.initSingleton();
/*     */     
/*  34 */     long[] arrayOfLong = { 0L, 0L };
/*  35 */     if (getMonotonicStartupTimeImpl(arrayOfLong)) {
/*  36 */       t0 = Instant.ofEpochSecond(arrayOfLong[0], arrayOfLong[1]);
/*     */     } else {
/*  38 */       t0 = Instant.EPOCH;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instant getMonotonicTime() {
/*  64 */     long[] arrayOfLong = { 0L, 0L };
/*  65 */     if (getMonotonicTimeImpl(arrayOfLong)) {
/*  66 */       return Instant.ofEpochSecond(arrayOfLong[0], arrayOfLong[1]);
/*     */     }
/*  68 */     return Instant.EPOCH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instant getWallClockTime() {
/*  88 */     long[] arrayOfLong = { 0L, 0L };
/*  89 */     if (getWallClockTimeImpl(arrayOfLong)) {
/*  90 */       return Instant.ofEpochSecond(arrayOfLong[0], arrayOfLong[1]);
/*     */     }
/*  92 */     return Instant.EPOCH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instant getMonotonicStartupTime() {
/* 102 */     return t0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instant getMonotonicNanos() {
/* 142 */     long l = currentNanos();
/* 143 */     return Instant.ofEpochSecond(l / 1000000000L, l % 1000000000L);
/*     */   }
/*     */   
/*     */   private static native boolean getMonotonicTimeImpl(long[] paramArrayOflong);
/*     */   
/*     */   private static native boolean getWallClockTimeImpl(long[] paramArrayOflong);
/*     */   
/*     */   private static native boolean getMonotonicStartupTimeImpl(long[] paramArrayOflong);
/*     */   
/*     */   public static native long currentNanos();
/*     */   
/*     */   public static native long currentTimeMillis();
/*     */   
/*     */   public static native long wallClockSeconds();
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/Clock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */