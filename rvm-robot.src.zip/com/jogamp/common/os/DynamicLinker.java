/*    */ package com.jogamp.common.os;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface DynamicLinker
/*    */ {
/* 33 */   public static final boolean DEBUG = NativeLibrary.DEBUG;
/* 34 */   public static final boolean DEBUG_LOOKUP = NativeLibrary.DEBUG_LOOKUP;
/*    */   
/*    */   void claimAllLinkPermission() throws SecurityException;
/*    */   
/*    */   void releaseAllLinkPermission() throws SecurityException;
/*    */   
/*    */   long openLibraryGlobal(String paramString, boolean paramBoolean) throws SecurityException;
/*    */   
/*    */   long openLibraryLocal(String paramString, boolean paramBoolean) throws SecurityException;
/*    */   
/*    */   long lookupSymbolGlobal(String paramString) throws SecurityException;
/*    */   
/*    */   long lookupSymbol(long paramLong, String paramString) throws SecurityException, IllegalArgumentException;
/*    */   
/*    */   void closeLibrary(long paramLong, boolean paramBoolean) throws SecurityException, IllegalArgumentException;
/*    */   
/*    */   String getLastError();
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/DynamicLinker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */