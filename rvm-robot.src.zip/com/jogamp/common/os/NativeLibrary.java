/*     */ package com.jogamp.common.os;
/*     */ 
/*     */ import com.jogamp.common.ExceptionUtils;
/*     */ import com.jogamp.common.util.IOUtil;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import com.jogamp.common.util.cache.TempJarCache;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import jogamp.common.os.BionicDynamicLinker32bitImpl;
/*     */ import jogamp.common.os.BionicDynamicLinker64BitImpl;
/*     */ import jogamp.common.os.MacOSXDynamicLinkerImpl;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ import jogamp.common.os.PosixDynamicLinkerImpl;
/*     */ import jogamp.common.os.WindowsDynamicLinkerImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeLibrary
/*     */   implements DynamicLookupHelper
/*     */ {
/*     */   private static final String[] prefixes;
/*     */   private static final String[] suffixes;
/*     */   private static final boolean isOSX;
/*     */   private static String sys_env_lib_path_varname;
/*     */   private final DynamicLinker dynLink;
/*     */   private long libraryHandle;
/*     */   private final String libraryPath;
/*     */   private final boolean global;
/*     */   
/*     */   static {
/*  87 */     switch (PlatformPropsImpl.OS_TYPE) {
/*     */       case WINDOWS:
/*  89 */         prefixes = new String[] { "" };
/*  90 */         suffixes = new String[] { ".dll" };
/*  91 */         sys_env_lib_path_varname = "PATH";
/*  92 */         isOSX = false;
/*     */         break;
/*     */       
/*     */       case MACOS:
/*     */       case IOS:
/*  97 */         prefixes = new String[] { "lib" };
/*  98 */         suffixes = new String[] { ".dylib" };
/*  99 */         sys_env_lib_path_varname = "DYLD_LIBRARY_PATH";
/* 100 */         isOSX = true;
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 111 */         prefixes = new String[] { "lib" };
/* 112 */         suffixes = new String[] { ".so" };
/* 113 */         sys_env_lib_path_varname = "LD_LIBRARY_PATH";
/* 114 */         isOSX = false;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NativeLibrary(DynamicLinker paramDynamicLinker, long paramLong, String paramString, boolean paramBoolean) {
/* 133 */     this.dynLink = paramDynamicLinker;
/* 134 */     this.libraryHandle = paramLong;
/* 135 */     this.libraryPath = paramString;
/* 136 */     this.global = paramBoolean;
/* 137 */     if (DEBUG) {
/* 138 */       System.err.println("NativeLibrary.open(): Successfully loaded: " + this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 144 */     return "NativeLibrary[" + this.dynLink.getClass().getSimpleName() + ", " + this.libraryPath + ", 0x" + Long.toHexString(this.libraryHandle) + ", global " + this.global + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getSystemEnvLibraryPathVarname() {
/* 153 */     return sys_env_lib_path_varname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<String> getSystemEnvLibraryPaths() {
/* 160 */     String str = (String)SecurityUtil.doPrivileged(new PrivilegedAction<String>()
/*     */         {
/*     */           public String run() {
/* 163 */             return System.getenv(NativeLibrary.getSystemEnvLibraryPathVarname());
/*     */           }
/*     */         });
/* 166 */     ArrayList<String> arrayList = new ArrayList();
/* 167 */     if (null != str && str.length() > 0) {
/* 168 */       StringTokenizer stringTokenizer = new StringTokenizer(str, File.pathSeparator);
/* 169 */       while (stringTokenizer.hasMoreTokens()) {
/* 170 */         arrayList.add(stringTokenizer.nextToken());
/*     */       }
/*     */     } 
/* 173 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final NativeLibrary open(String paramString, boolean paramBoolean1, boolean paramBoolean2, ClassLoader paramClassLoader, boolean paramBoolean3) throws SecurityException {
/* 201 */     return open(paramString, paramString, paramString, paramBoolean1, paramBoolean2, paramClassLoader, paramBoolean3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final NativeLibrary open(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2, ClassLoader paramClassLoader, boolean paramBoolean3) throws SecurityException {
/* 242 */     List<String> list = enumerateLibraryPaths(paramString1, paramString2, paramString3, paramBoolean1, paramBoolean2, paramClassLoader);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     Platform.initSingleton();
/*     */     
/* 249 */     DynamicLinker dynamicLinker = getDynamicLinker();
/*     */ 
/*     */     
/* 252 */     for (String str : list) {
/*     */       long l;
/* 254 */       if (DEBUG) {
/* 255 */         System.err.println("NativeLibrary.open(global " + paramBoolean3 + "): Trying to load " + str);
/*     */       }
/*     */       
/* 258 */       Throwable throwable = null;
/*     */       try {
/* 260 */         if (paramBoolean3) {
/* 261 */           l = dynamicLinker.openLibraryGlobal(str, DEBUG);
/*     */         } else {
/* 263 */           l = dynamicLinker.openLibraryLocal(str, DEBUG);
/*     */         } 
/* 265 */       } catch (Throwable throwable1) {
/* 266 */         throwable = throwable1;
/* 267 */         l = 0L;
/*     */       } 
/* 269 */       if (0L != l)
/* 270 */         return new NativeLibrary(dynamicLinker, l, str, paramBoolean3); 
/* 271 */       if (DEBUG) {
/* 272 */         String str1; if (null != throwable) {
/* 273 */           System.err.println("NativeLibrary.open: Caught " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
/*     */         }
/*     */ 
/*     */         
/* 277 */         try { str1 = dynamicLinker.getLastError(); }
/* 278 */         catch (Throwable throwable1) { str1 = null; }
/* 279 */          System.err.println("NativeLibrary.open: Last error " + str1);
/* 280 */         if (null != throwable) {
/* 281 */           throwable.printStackTrace();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 286 */     if (DEBUG) {
/* 287 */       System.err.println("NativeLibrary.open(global " + paramBoolean3 + "): Did not succeed in loading (" + paramString1 + ", " + paramString2 + ", " + paramString3 + ")");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 293 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void claimAllLinkPermission() throws SecurityException {
/* 298 */     this.dynLink.claimAllLinkPermission();
/*     */   }
/*     */   
/*     */   public final void releaseAllLinkPermission() throws SecurityException {
/* 302 */     this.dynLink.releaseAllLinkPermission();
/*     */   }
/*     */ 
/*     */   
/*     */   public final long dynamicLookupFunction(String paramString) throws SecurityException {
/* 307 */     if (0L == this.libraryHandle) {
/* 308 */       throw new RuntimeException("Library is not open");
/*     */     }
/* 310 */     return this.dynLink.lookupSymbol(this.libraryHandle, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isFunctionAvailable(String paramString) throws SecurityException {
/* 315 */     if (0L == this.libraryHandle) {
/* 316 */       throw new RuntimeException("Library is not open");
/*     */     }
/* 318 */     return (0L != this.dynLink.lookupSymbol(this.libraryHandle, paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long dynamicLookupFunctionGlobal(String paramString) throws SecurityException {
/* 325 */     return this.dynLink.lookupSymbolGlobal(paramString);
/*     */   }
/*     */   
/* 328 */   final DynamicLinker dynamicLinker() { return this.dynLink; } static DynamicLinker getDynamicLinker() {
/*     */     WindowsDynamicLinkerImpl windowsDynamicLinkerImpl;
/*     */     MacOSXDynamicLinkerImpl macOSXDynamicLinkerImpl;
/*     */     BionicDynamicLinker64BitImpl bionicDynamicLinker64BitImpl;
/* 332 */     switch (PlatformPropsImpl.OS_TYPE) {
/*     */       case WINDOWS:
/* 334 */         return (DynamicLinker)new WindowsDynamicLinkerImpl();
/*     */ 
/*     */       
/*     */       case MACOS:
/*     */       case IOS:
/* 339 */         return (DynamicLinker)new MacOSXDynamicLinkerImpl();
/*     */ 
/*     */       
/*     */       case ANDROID:
/* 343 */         if (PlatformPropsImpl.CPU_ARCH.is32Bit) {
/* 344 */           BionicDynamicLinker32bitImpl bionicDynamicLinker32bitImpl = new BionicDynamicLinker32bitImpl();
/*     */         } else {
/* 346 */           bionicDynamicLinker64BitImpl = new BionicDynamicLinker64BitImpl();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 354 */         return (DynamicLinker)bionicDynamicLinker64BitImpl;
/*     */     } 
/*     */     return (DynamicLinker)new PosixDynamicLinkerImpl();
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getLibraryHandle() {
/* 361 */     return this.libraryHandle;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getLibraryPath() {
/* 366 */     return this.libraryPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void close() throws SecurityException {
/* 374 */     if (DEBUG) {
/* 375 */       System.err.println("NativeLibrary.close(): closing " + this);
/*     */     }
/* 377 */     if (0L == this.libraryHandle) {
/* 378 */       throw new RuntimeException("Library already closed");
/*     */     }
/* 380 */     long l = this.libraryHandle;
/* 381 */     this.libraryHandle = 0L;
/* 382 */     this.dynLink.closeLibrary(l, DEBUG);
/* 383 */     if (DEBUG) {
/* 384 */       System.err.println("NativeLibrary.close(): Successfully closed " + this);
/* 385 */       ExceptionUtils.dumpStack(System.err);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String isValidNativeLibraryName(String paramString, boolean paramBoolean) {
/*     */     String str1;
/*     */     try {
/* 401 */       str1 = IOUtil.getBasename(paramString);
/* 402 */     } catch (URISyntaxException uRISyntaxException) {
/* 403 */       throw new IllegalArgumentException(uRISyntaxException);
/*     */     } 
/* 405 */     String str2 = paramBoolean ? str1 : str1.toLowerCase();
/* 406 */     byte b = -1; byte b1;
/* 407 */     for (b1 = 0; b1 < prefixes.length && 0 > b; b1++) {
/* 408 */       if (str2.startsWith(prefixes[b1])) {
/* 409 */         b = b1;
/*     */       }
/*     */     } 
/* 412 */     if (0 <= b) {
/* 413 */       for (b1 = 0; b1 < suffixes.length; b1++) {
/* 414 */         if (str2.endsWith(suffixes[b1])) {
/* 415 */           int i = prefixes[b].length();
/* 416 */           int j = suffixes[b1].length();
/* 417 */           return str1.substring(i, str1.length() - j);
/*     */         } 
/*     */       } 
/*     */     }
/* 421 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<String> enumerateLibraryPaths(String paramString1, String paramString2, String paramString3, ClassLoader paramClassLoader) {
/* 431 */     return enumerateLibraryPaths(paramString1, paramString2, paramString3, false, false, paramClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<String> enumerateLibraryPaths(String paramString1, String paramString2, String paramString3, boolean paramBoolean, ClassLoader paramClassLoader) {
/* 443 */     return enumerateLibraryPaths(paramString1, paramString2, paramString3, true, paramBoolean, paramClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List<String> enumerateLibraryPaths(String paramString1, String paramString2, String paramString3, final boolean searchSystemPath, final boolean searchSystemPathFirst, ClassLoader paramClassLoader) {
/* 453 */     ArrayList<String> arrayList = new ArrayList();
/* 454 */     String str1 = selectName(paramString1, paramString2, paramString3);
/* 455 */     if (str1 == null) {
/* 456 */       if (DEBUG) {
/* 457 */         System.err.println("NativeLibrary.enumerateLibraryPaths: empty, no libName selected");
/*     */       }
/* 459 */       return arrayList;
/*     */     } 
/* 461 */     if (DEBUG) {
/* 462 */       System.err.println("NativeLibrary.enumerateLibraryPaths: libName '" + str1 + "'");
/*     */     }
/*     */ 
/*     */     
/* 466 */     File file = new File(str1);
/* 467 */     if (file.isAbsolute()) {
/* 468 */       arrayList.add(str1);
/* 469 */       if (DEBUG) {
/* 470 */         System.err.println("NativeLibrary.enumerateLibraryPaths: done, absolute path found '" + str1 + "'");
/*     */       }
/* 472 */       return arrayList;
/*     */     } 
/*     */     
/* 475 */     String[] arrayOfString1 = buildNames(str1);
/* 476 */     if (DEBUG) {
/* 477 */       System.err.println("NativeLibrary.enumerateLibraryPaths: baseNames: " + Arrays.toString((Object[])arrayOfString1));
/*     */     }
/*     */     
/* 480 */     if (searchSystemPath && searchSystemPathFirst) {
/*     */       
/* 482 */       for (byte b = 0; b < arrayOfString1.length; b++) {
/* 483 */         if (DEBUG) {
/* 484 */           System.err.println("NativeLibrary.enumerateLibraryPaths: add.ssp_1st: " + arrayOfString1[b]);
/*     */         }
/* 486 */         arrayList.add(arrayOfString1[b]);
/*     */       } 
/*     */       
/* 489 */       if (isOSX) {
/*     */         
/* 491 */         addAbsPaths("add.ssp_1st_macos_old", "/Library/Frameworks/" + str1 + ".framework", arrayOfString1, arrayList);
/*     */         
/* 493 */         addAbsPaths("add.ssp_1st_macos_cur", "/System/Library/Frameworks/" + str1 + ".framework", arrayOfString1, arrayList);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 499 */     String str2 = findLibrary(str1, paramClassLoader);
/* 500 */     if (str2 != null) {
/* 501 */       if (DEBUG) {
/* 502 */         System.err.println("NativeLibrary.enumerateLibraryPaths: add.clp: " + str2);
/*     */       }
/* 504 */       arrayList.add(str2);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 509 */     String[] arrayOfString2 = (String[])SecurityUtil.doPrivileged(new PrivilegedAction<String[]>() {
/*     */           public String[] run() {
/*     */             String str2;
/* 512 */             byte b1 = 0;
/* 513 */             String str1 = System.getProperty("java.library.path");
/* 514 */             if (null != str1) {
/* 515 */               b1++;
/*     */             }
/*     */             
/* 518 */             if (searchSystemPath) {
/* 519 */               str2 = System.getProperty("sun.boot.library.path");
/* 520 */               if (null != str2) {
/* 521 */                 b1++;
/*     */               }
/*     */             } else {
/* 524 */               str2 = null;
/*     */             } 
/* 526 */             String[] arrayOfString = new String[b1];
/* 527 */             byte b2 = 0;
/* 528 */             if (null != str2 && searchSystemPathFirst) {
/* 529 */               arrayOfString[b2++] = str2;
/*     */             }
/* 531 */             if (null != str1) {
/* 532 */               arrayOfString[b2++] = str1;
/*     */             }
/* 534 */             if (null != str2 && !searchSystemPathFirst) {
/* 535 */               arrayOfString[b2++] = str2;
/*     */             }
/* 537 */             return arrayOfString;
/*     */           }
/*     */         });
/* 540 */     if (null != arrayOfString2) {
/* 541 */       for (byte b = 0; b < arrayOfString2.length; b++) {
/* 542 */         StringTokenizer stringTokenizer = new StringTokenizer(arrayOfString2[b], File.pathSeparator);
/* 543 */         while (stringTokenizer.hasMoreTokens()) {
/* 544 */           addRelPaths("add.java.library.path", stringTokenizer.nextToken(), arrayOfString1, arrayList);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 551 */     String str3 = (String)SecurityUtil.doPrivileged(new PrivilegedAction<String>()
/*     */         {
/*     */           public String run() {
/* 554 */             return System.getProperty("user.dir");
/*     */           }
/*     */         });
/* 557 */     addAbsPaths("add.user.dir.std", str3, arrayOfString1, arrayList);
/*     */ 
/*     */ 
/*     */     
/* 561 */     addAbsPaths("add.user.dir.fat", str3 + File.separator + "natives" + File.separator + PlatformPropsImpl.os_and_arch, arrayOfString1, arrayList);
/*     */     
/* 563 */     if (searchSystemPath && !searchSystemPathFirst) {
/*     */       
/* 565 */       for (byte b = 0; b < arrayOfString1.length; b++) {
/* 566 */         if (DEBUG) {
/* 567 */           System.err.println("NativeLibrary.enumerateLibraryPaths: add.ssp_lst: " + arrayOfString1[b]);
/*     */         }
/* 569 */         arrayList.add(arrayOfString1[b]);
/*     */       } 
/*     */       
/* 572 */       if (isOSX) {
/*     */         
/* 574 */         addAbsPaths("add.ssp_lst_macos_old", "/Library/Frameworks/" + str1 + ".Framework", arrayOfString1, arrayList);
/*     */         
/* 576 */         addAbsPaths("add.ssp_lst_macos_cur", "/System/Library/Frameworks/" + str1 + ".Framework", arrayOfString1, arrayList);
/*     */       } 
/*     */     } 
/* 579 */     if (DEBUG) {
/* 580 */       System.err.println("NativeLibrary.enumerateLibraryPaths: done: " + arrayList.toString());
/*     */     }
/* 582 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String selectName(String paramString1, String paramString2, String paramString3) {
/* 589 */     switch (PlatformPropsImpl.OS_TYPE) {
/*     */       case WINDOWS:
/* 591 */         return paramString1;
/*     */       
/*     */       case MACOS:
/*     */       case IOS:
/* 595 */         return paramString3;
/*     */     } 
/*     */     
/* 598 */     return paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String[] buildNames(String paramString) {
/*     */     String str;
/*     */     try {
/* 608 */       str = IOUtil.getBasename(paramString).toLowerCase();
/* 609 */     } catch (URISyntaxException uRISyntaxException) {
/* 610 */       throw new IllegalArgumentException(uRISyntaxException);
/*     */     } 
/*     */     
/* 613 */     int i = -1; int j;
/* 614 */     for (j = 0; j < prefixes.length && 0 > i; j++) {
/* 615 */       if (str.startsWith(prefixes[j])) {
/* 616 */         i = j;
/*     */       }
/*     */     } 
/* 619 */     if (0 <= i) {
/* 620 */       for (j = 0; j < suffixes.length; j++) {
/* 621 */         if (str.endsWith(suffixes[j])) {
/* 622 */           return new String[] { paramString };
/*     */         }
/*     */       } 
/* 625 */       j = -1; byte b;
/* 626 */       for (b = 0; b < suffixes.length && 0 > j; b++) {
/* 627 */         j = str.indexOf(suffixes[b]);
/*     */       }
/* 629 */       b = 1;
/* 630 */       if (j >= 0) {
/*     */         
/* 632 */         int k = j + suffixes[0].length();
/* 633 */         for (; k < paramString.length(); 
/* 634 */           k++) {
/* 635 */           char c = paramString.charAt(k);
/* 636 */           if (c != '.' && (c < '0' || c > '9')) {
/* 637 */             b = 0;
/*     */             break;
/*     */           } 
/*     */         } 
/* 641 */         if (b != 0) {
/* 642 */           return new String[] { paramString };
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 647 */     String[] arrayOfString = new String[prefixes.length * suffixes.length + (isOSX ? 1 : 0)];
/* 648 */     byte b1 = 0;
/* 649 */     for (byte b2 = 0; b2 < prefixes.length; b2++) {
/* 650 */       for (byte b = 0; b < suffixes.length; b++) {
/* 651 */         arrayOfString[b1++] = prefixes[b2] + paramString + suffixes[b];
/*     */       }
/*     */     } 
/* 654 */     if (isOSX)
/*     */     {
/* 656 */       arrayOfString[b1++] = paramString;
/*     */     }
/* 658 */     return arrayOfString;
/*     */   }
/*     */   
/*     */   private static final void addRelPaths(String paramString1, String paramString2, String[] paramArrayOfString, List<String> paramList) {
/*     */     String str;
/*     */     try {
/* 664 */       File file = new File(paramString2);
/* 665 */       str = file.getCanonicalPath();
/* 666 */     } catch (IOException iOException) {
/* 667 */       if (DEBUG) {
/* 668 */         System.err.println("NativeLibrary.enumerateLibraryPaths: " + paramString1 + ": Exception " + iOException.getMessage() + ", from path " + paramString2);
/*     */       }
/*     */       return;
/*     */     } 
/* 672 */     addAbsPaths(paramString1, str, paramArrayOfString, paramList);
/*     */   }
/*     */   private static final void addAbsPaths(String paramString1, String paramString2, String[] paramArrayOfString, List<String> paramList) {
/* 675 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 676 */       String str = paramString2 + File.separator + paramArrayOfString[b];
/* 677 */       if (DEBUG) {
/* 678 */         System.err.println("NativeLibrary.enumerateLibraryPaths: " + paramString1 + ": " + str + ", from path " + paramString2);
/*     */       }
/* 680 */       paramList.add(str);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean initializedFindLibraryMethod = false;
/* 685 */   private static Method findLibraryMethod = null;
/*     */   private static final String findLibraryImpl(final String libName, final ClassLoader loader) {
/* 687 */     if (PlatformPropsImpl.JAVA_9) {
/* 688 */       return null;
/*     */     }
/* 690 */     if (loader == null) {
/* 691 */       return null;
/*     */     }
/* 693 */     if (!initializedFindLibraryMethod) {
/* 694 */       SecurityUtil.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/*     */               try {
/* 698 */                 NativeLibrary.findLibraryMethod = ClassLoader.class.getDeclaredMethod("findLibrary", new Class[] { String.class });
/*     */                 
/* 700 */                 NativeLibrary.findLibraryMethod.setAccessible(true);
/* 701 */               } catch (Exception exception) {}
/*     */ 
/*     */               
/* 704 */               NativeLibrary.initializedFindLibraryMethod = true;
/* 705 */               return null;
/*     */             }
/*     */           });
/*     */     }
/* 709 */     if (findLibraryMethod != null) {
/*     */       try {
/* 711 */         return (String)SecurityUtil.doPrivileged(new PrivilegedAction<String>()
/*     */             {
/*     */               public String run() {
/*     */                 try {
/* 715 */                   return (String)NativeLibrary.findLibraryMethod.invoke(loader, new Object[] { this.val$libName });
/* 716 */                 } catch (Exception exception) {
/* 717 */                   throw new RuntimeException(exception);
/*     */                 } 
/*     */               }
/*     */             });
/* 721 */       } catch (Exception exception) {
/* 722 */         if (DEBUG) {
/* 723 */           exception.printStackTrace();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 728 */     return null;
/*     */   }
/*     */   public static final String findLibrary(String paramString, ClassLoader paramClassLoader) {
/* 731 */     String str = null;
/* 732 */     if (TempJarCache.isInitialized(true)) {
/* 733 */       str = TempJarCache.findLibrary(paramString);
/* 734 */       if (DEBUG) {
/* 735 */         System.err.println("NativeLibrary.findLibrary(<" + paramString + ">) (TempJarCache): " + str);
/*     */       }
/*     */     } 
/* 738 */     if (null == str) {
/* 739 */       str = findLibraryImpl(paramString, paramClassLoader);
/* 740 */       if (DEBUG) {
/* 741 */         System.err.println("NativeLibrary.findLibrary(<" + paramString + ">, " + paramClassLoader + ") (CL): " + str);
/*     */       }
/*     */     } 
/* 744 */     return str;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/os/NativeLibrary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */