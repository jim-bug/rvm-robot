/*    */ package com.jogamp.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JogampRuntimeException
/*    */   extends RuntimeException
/*    */ {
/*    */   public JogampRuntimeException() {}
/*    */   
/*    */   public JogampRuntimeException(String paramString) {
/* 45 */     super(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JogampRuntimeException(String paramString, Throwable paramThrowable) {
/* 51 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JogampRuntimeException(Throwable paramThrowable) {
/* 57 */     super(paramThrowable);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/JogampRuntimeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */