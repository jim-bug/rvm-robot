/*     */ package com.jogamp.common.jvm;
/*     */ 
/*     */ import com.jogamp.common.net.Uri;
/*     */ import com.jogamp.common.os.NativeLibrary;
/*     */ import com.jogamp.common.util.JarUtil;
/*     */ import com.jogamp.common.util.PropertyAccess;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import com.jogamp.common.util.cache.TempJarCache;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import jogamp.common.Debug;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JNILibLoaderBase
/*     */ {
/*     */   static {
/*  69 */     Debug.initSingleton();
/*  70 */   } public static final boolean DEBUG = Debug.debug("JNILibLoader");
/*  71 */   protected static final boolean PERF = (DEBUG || PropertyAccess.isPropertyDefined("jogamp.debug.JNILibLoader.Perf", true));
/*     */ 
/*     */   
/*  74 */   private static final Object perfSync = new Object();
/*  75 */   private static long perfTotal = 0L;
/*  76 */   private static long perfCount = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface LoaderAction
/*     */   {
/*     */     boolean loadLibrary(String param1String, boolean param1Boolean, ClassLoader param1ClassLoader);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void loadLibrary(String param1String, String[] param1ArrayOfString, boolean param1Boolean, ClassLoader param1ClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultAction
/*     */     implements LoaderAction
/*     */   {
/*     */     private DefaultAction() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean loadLibrary(String param1String, boolean param1Boolean, ClassLoader param1ClassLoader) {
/* 104 */       boolean bool = true;
/* 105 */       if (!JNILibLoaderBase.isLoaded(param1String)) {
/*     */         try {
/* 107 */           JNILibLoaderBase.loadLibraryInternal(param1String, param1ClassLoader);
/* 108 */           JNILibLoaderBase.addLoaded(param1String);
/* 109 */           if (JNILibLoaderBase.DEBUG) {
/* 110 */             System.err.println("JNILibLoaderBase: loaded " + param1String);
/*     */           }
/* 112 */         } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 113 */           bool = false;
/* 114 */           if (JNILibLoaderBase.DEBUG) {
/* 115 */             unsatisfiedLinkError.printStackTrace();
/*     */           }
/* 117 */           if (!param1Boolean && unsatisfiedLinkError.getMessage().indexOf("already loaded") < 0) {
/* 118 */             throw unsatisfiedLinkError;
/*     */           }
/*     */         } 
/*     */       }
/* 122 */       return bool;
/*     */     }
/*     */ 
/*     */     
/*     */     public void loadLibrary(String param1String, String[] param1ArrayOfString, boolean param1Boolean, ClassLoader param1ClassLoader) {
/* 127 */       if (!JNILibLoaderBase.isLoaded(param1String)) {
/* 128 */         if (null != param1ArrayOfString) {
/* 129 */           for (byte b = 0; b < param1ArrayOfString.length; b++) {
/* 130 */             loadLibrary(param1ArrayOfString[b], param1Boolean, param1ClassLoader);
/*     */           }
/*     */         }
/* 133 */         loadLibrary(param1String, false, param1ClassLoader);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/* 138 */   private static final HashSet<String> loaded = new HashSet<>();
/* 139 */   private static LoaderAction loaderAction = new DefaultAction(); private static final String nativeJarTagPackage = "jogamp.nativetag"; private static final Method customLoadLibraryMethod;
/*     */   
/*     */   public static boolean isLoaded(String paramString) {
/* 142 */     return loaded.contains(paramString);
/*     */   }
/*     */   
/*     */   public static void addLoaded(String paramString) {
/* 146 */     loaded.add(paramString);
/* 147 */     if (DEBUG) {
/* 148 */       System.err.println("JNILibLoaderBase: Loaded Native Library: " + paramString);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void disableLoading() {
/* 153 */     setLoadingAction(null);
/*     */   }
/*     */   
/*     */   public static void enableLoading() {
/* 157 */     setLoadingAction(new DefaultAction());
/*     */   }
/*     */   
/*     */   public static synchronized void setLoadingAction(LoaderAction paramLoaderAction) {
/* 161 */     loaderAction = paramLoaderAction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean addNativeJarLibsImpl(Class<?> paramClass, Uri paramUri, Uri.Encoded paramEncoded1, Uri.Encoded paramEncoded2) throws IOException, SecurityException, URISyntaxException {
/* 181 */     if (DEBUG) {
/* 182 */       StringBuilder stringBuilder = new StringBuilder();
/* 183 */       stringBuilder.append("JNILibLoaderBase: addNativeJarLibsImpl(").append(PlatformPropsImpl.NEWLINE);
/* 184 */       stringBuilder.append("  classFromJavaJar  = ").append(paramClass).append(PlatformPropsImpl.NEWLINE);
/* 185 */       stringBuilder.append("  classJarURI       = ").append(paramUri).append(PlatformPropsImpl.NEWLINE);
/* 186 */       stringBuilder.append("  jarBasename       = ").append((CharSequence)paramEncoded1).append(PlatformPropsImpl.NEWLINE);
/* 187 */       stringBuilder.append("  os.and.arch       = ").append(PlatformPropsImpl.os_and_arch).append(PlatformPropsImpl.NEWLINE);
/* 188 */       stringBuilder.append("  nativeJarBasename = ").append((CharSequence)paramEncoded2).append(PlatformPropsImpl.NEWLINE);
/* 189 */       stringBuilder.append(")");
/* 190 */       System.err.println(stringBuilder.toString());
/*     */     } 
/* 192 */     long l = PERF ? System.currentTimeMillis() : 0L;
/*     */     
/* 194 */     boolean bool = false;
/*     */     
/* 196 */     Uri uri1 = paramUri.getContainedUri();
/* 197 */     if (null == uri1) {
/* 198 */       throw new IllegalArgumentException("JarSubURI is null of: " + paramUri);
/*     */     }
/*     */     
/* 201 */     Uri uri2 = uri1.getDirectory();
/*     */     
/* 203 */     if (DEBUG) {
/* 204 */       System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: initial: %s -> %s%n", new Object[] { uri1, uri2 });
/*     */     }
/*     */     
/* 207 */     String str = String.format((Locale)null, "natives/%s/", new Object[] { PlatformPropsImpl.os_and_arch });
/* 208 */     if (DEBUG) {
/* 209 */       System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: nativeLibraryPath: %s%n", new Object[] { str });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 214 */     Uri uri3 = JarUtil.getJarFileUri(uri2.getEncoded().concat(paramEncoded2));
/*     */     
/* 216 */     if (DEBUG) {
/* 217 */       System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: module: %s -> %s%n", new Object[] { paramEncoded2, uri3 });
/*     */     }
/*     */     
/*     */     try {
/* 221 */       bool = TempJarCache.addNativeLibs(paramClass, uri3, str);
/* 222 */     } catch (Exception exception) {
/* 223 */       if (DEBUG) {
/* 224 */         System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: Caught %s%n", new Object[] { exception.getMessage() });
/* 225 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 229 */     if (!bool) {
/* 230 */       ClassLoader classLoader = paramClass.getClassLoader();
/*     */ 
/*     */ 
/*     */       
/* 234 */       URL uRL = classLoader.getResource(str);
/* 235 */       if (null != uRL) {
/* 236 */         Uri uri = JarUtil.getJarFileUri(uri2.getEncoded().concat(paramEncoded1));
/*     */         try {
/* 238 */           if (TempJarCache.addNativeLibs(paramClass, uri, str)) {
/* 239 */             bool = true;
/* 240 */             if (DEBUG) {
/* 241 */               System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: fat: %s -> %s%n", new Object[] { paramEncoded1, uri });
/*     */             }
/*     */           } 
/* 244 */         } catch (Exception exception) {
/* 245 */           if (DEBUG) {
/* 246 */             System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: Caught %s%n", new Object[] { exception.getMessage() });
/* 247 */             exception.printStackTrace();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 252 */       if (!bool) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 258 */         String str1, str2 = paramClass.getPackage().getName();
/* 259 */         int i = str2.lastIndexOf('.');
/* 260 */         if (0 <= i) {
/* 261 */           str1 = str2.substring(i + 1);
/*     */         } else {
/* 263 */           str1 = str2;
/*     */         } 
/*     */         
/* 266 */         str2 = PlatformPropsImpl.os_and_arch.replace('-', '.');
/* 267 */         String str3 = "jogamp.nativetag." + str1 + "." + str2 + ".TAG";
/*     */         try {
/* 269 */           if (DEBUG) {
/* 270 */             System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: ClassLoader/TAG: Locating module %s, os.and.arch %s: %s%n", new Object[] { str1, str2, str3 });
/*     */           }
/*     */           
/* 273 */           Uri uri = JarUtil.getJarUri(str3, classLoader);
/* 274 */           if (DEBUG) {
/* 275 */             System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: ClassLoader/TAG: %s -> %s%n", new Object[] { str3, uri });
/*     */           }
/* 277 */           bool = TempJarCache.addNativeLibs(paramClass, uri, str);
/* 278 */         } catch (Exception exception) {
/* 279 */           if (DEBUG) {
/* 280 */             System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl: Caught %s%n", new Object[] { exception.getMessage() });
/* 281 */             exception.printStackTrace();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 287 */     if (DEBUG || PERF) {
/* 288 */       long l2, l3, l1 = System.currentTimeMillis() - l;
/*     */       
/* 290 */       synchronized (perfSync) {
/* 291 */         l3 = perfCount + 1L;
/* 292 */         l2 = perfTotal + l1;
/* 293 */         perfTotal = l2;
/* 294 */         perfCount = l3;
/*     */       } 
/* 296 */       double d = l2 / l3;
/* 297 */       System.err.printf("JNILibLoaderBase: addNativeJarLibsImpl.X: %s / %s -> ok: %b; duration: now %d ms, total %d ms (count %d, avrg %.3f ms)%n", new Object[] { paramEncoded1, paramEncoded2, 
/* 298 */             Boolean.valueOf(bool), Long.valueOf(l1), Long.valueOf(l2), Long.valueOf(l3), Double.valueOf(d) });
/*     */     } 
/* 300 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean addNativeJarLibsJoglCfg(Class<?>[] paramArrayOfClass) {
/* 324 */     return addNativeJarLibs(paramArrayOfClass, "-all");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean addNativeJarLibs(Class<?>[] paramArrayOfClass, String paramString) {
/* 398 */     if (DEBUG) {
/* 399 */       StringBuilder stringBuilder = new StringBuilder();
/* 400 */       stringBuilder.append("JNILibLoaderBase: addNativeJarLibs(").append(PlatformPropsImpl.NEWLINE);
/* 401 */       stringBuilder.append("  classesFromJavaJars   = ").append(Arrays.asList(paramArrayOfClass)).append(PlatformPropsImpl.NEWLINE);
/* 402 */       stringBuilder.append("  singleJarMarker       = ").append(paramString).append(PlatformPropsImpl.NEWLINE);
/* 403 */       stringBuilder.append(")");
/* 404 */       System.err.println(stringBuilder.toString());
/*     */     } 
/*     */     
/* 407 */     boolean bool = false;
/* 408 */     if (TempJarCache.isInitialized(true)) {
/* 409 */       bool = addNativeJarLibsWithTempJarCache(paramArrayOfClass, paramString);
/* 410 */     } else if (DEBUG) {
/* 411 */       System.err.println("JNILibLoaderBase: addNativeJarLibs0: disabled due to uninitialized TempJarCache");
/*     */     } 
/* 413 */     return bool;
/*     */   }
/*     */   
/*     */   private static boolean addNativeJarLibsWithTempJarCache(Class<?>[] paramArrayOfClass, String paramString) {
/*     */     boolean bool;
/* 418 */     byte b = 0;
/*     */     try {
/* 420 */       boolean bool1 = false;
/* 421 */       bool = true;
/*     */       
/* 423 */       for (byte b1 = 0; b1 < paramArrayOfClass.length; b1++) {
/* 424 */         Class<?> clazz = paramArrayOfClass[b1];
/* 425 */         if (clazz != null) {
/*     */ 
/*     */ 
/*     */           
/* 429 */           ClassLoader classLoader = clazz.getClassLoader();
/* 430 */           Uri uri = JarUtil.getJarUri(clazz.getName(), classLoader);
/* 431 */           Uri.Encoded encoded = JarUtil.getJarBasename(uri);
/*     */           
/* 433 */           if (encoded != null)
/*     */           
/*     */           { 
/*     */             
/* 437 */             Uri.Encoded encoded1 = encoded.substring(0, encoded.indexOf(".jar"));
/*     */             
/* 439 */             if (DEBUG) {
/* 440 */               System.err.printf("JNILibLoaderBase: jarBasename: %s%n", new Object[] { encoded1 });
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 448 */             if (paramString != null && 
/* 449 */               encoded1.indexOf(paramString) >= 0) {
/* 450 */               bool1 = true;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 455 */             Uri.Encoded encoded2 = Uri.Encoded.cast(String.format((Locale)null, "%s-natives-%s.jar", new Object[] { encoded1.get(), PlatformPropsImpl.os_and_arch }));
/*     */             
/* 457 */             bool = addNativeJarLibsImpl(clazz, uri, encoded, encoded2);
/* 458 */             if (bool) {
/* 459 */               b++;
/*     */             }
/* 461 */             if (DEBUG && bool1)
/* 462 */               System.err.printf("JNILibLoaderBase: addNativeJarLibs0: done: %s%n", new Object[] { encoded1 });  } 
/*     */         } 
/*     */       } 
/* 465 */     } catch (Exception exception) {
/* 466 */       System.err.printf("JNILibLoaderBase: Caught %s: %s%n", new Object[] { exception.getClass().getSimpleName(), exception.getMessage() });
/* 467 */       if (DEBUG) {
/* 468 */         exception.printStackTrace();
/*     */       }
/* 470 */       bool = false;
/*     */     } 
/* 472 */     if (DEBUG) {
/* 473 */       System.err.printf("JNILibLoaderBase: addNativeJarLibsWhenInitialized: count %d, ok %b%n", new Object[] { Integer.valueOf(b), Boolean.valueOf(bool) });
/*     */     }
/* 475 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static synchronized boolean loadLibrary(String paramString, boolean paramBoolean, ClassLoader paramClassLoader) {
/* 487 */     if (loaderAction != null) {
/* 488 */       return loaderAction.loadLibrary(paramString, paramBoolean, paramClassLoader);
/*     */     }
/* 490 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static synchronized void loadLibrary(String paramString, String[] paramArrayOfString, boolean paramBoolean, ClassLoader paramClassLoader) {
/* 503 */     if (loaderAction != null) {
/* 504 */       loaderAction.loadLibrary(paramString, paramArrayOfString, paramBoolean, paramClassLoader);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 515 */     Method method = (Method)SecurityUtil.doPrivileged(new PrivilegedAction<Method>()
/*     */         {
/*     */           public Method run()
/*     */           {
/* 519 */             boolean bool = PropertyAccess.getBooleanProperty("sun.jnlp.applet.launcher", true);
/*     */             
/* 521 */             Class<?> clazz = null;
/* 522 */             Method method = null;
/*     */             
/* 524 */             if (bool) {
/*     */               try {
/* 526 */                 clazz = Class.forName("org.jdesktop.applet.util.JNLPAppletLauncher");
/* 527 */               } catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */                 
/* 530 */                 System.err.println("JNILibLoaderBase: <org.jdesktop.applet.util.JNLPAppletLauncher> not found, despite enabled property <sun.jnlp.applet.launcher>, JNLPAppletLauncher was probably used before");
/* 531 */                 System.setProperty("sun.jnlp.applet.launcher", Boolean.FALSE.toString());
/* 532 */               } catch (LinkageError linkageError) {
/* 533 */                 throw linkageError;
/*     */               } 
/* 535 */               if (null != clazz) {
/*     */                 try {
/* 537 */                   method = clazz.getDeclaredMethod("loadLibrary", new Class[] { String.class });
/* 538 */                 } catch (NoSuchMethodException noSuchMethodException) {
/* 539 */                   if (JNILibLoaderBase.DEBUG) {
/* 540 */                     noSuchMethodException.printStackTrace();
/*     */                   }
/* 542 */                   clazz = null;
/*     */                 } 
/*     */               }
/*     */             } 
/* 546 */             if (null == clazz) {
/* 547 */               String str = PropertyAccess.getProperty("jnlp.launcher.class", false);
/* 548 */               if (null != str) {
/*     */                 try {
/* 550 */                   clazz = Class.forName(str);
/* 551 */                   method = clazz.getDeclaredMethod("loadLibrary", new Class[] { String.class });
/* 552 */                 } catch (ClassNotFoundException classNotFoundException) {
/* 553 */                   if (JNILibLoaderBase.DEBUG) {
/* 554 */                     classNotFoundException.printStackTrace();
/*     */                   }
/* 556 */                 } catch (NoSuchMethodException noSuchMethodException) {
/* 557 */                   if (JNILibLoaderBase.DEBUG) {
/* 558 */                     noSuchMethodException.printStackTrace();
/*     */                   }
/* 560 */                   clazz = null;
/*     */                 } 
/*     */               }
/*     */             } 
/* 564 */             return method; }
/*     */         });
/* 566 */     customLoadLibraryMethod = method;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadLibraryInternal(String paramString, ClassLoader paramClassLoader) {
/* 571 */     byte b = 0;
/* 572 */     if (null != customLoadLibraryMethod && !paramString.equals("jawt")) {
/*     */       
/* 574 */       if (DEBUG) {
/* 575 */         System.err.println("JNILibLoaderBase: customLoad(" + paramString + ") - mode 1");
/*     */       }
/*     */       try {
/* 578 */         customLoadLibraryMethod.invoke(null, new Object[] { paramString });
/* 579 */         b = 1;
/* 580 */       } catch (Exception exception) {
/* 581 */         Throwable throwable = exception;
/* 582 */         if (throwable instanceof InvocationTargetException) {
/* 583 */           throwable = ((InvocationTargetException)throwable).getTargetException();
/*     */         }
/* 585 */         if (throwable instanceof Error) {
/* 586 */           throw (Error)throwable;
/*     */         }
/* 588 */         if (throwable instanceof RuntimeException) {
/* 589 */           throw (RuntimeException)throwable;
/*     */         }
/*     */         
/* 592 */         throw (UnsatisfiedLinkError)(new UnsatisfiedLinkError("can not load library " + paramString)).initCause(exception);
/*     */       } 
/*     */     } else {
/*     */       
/* 596 */       String str = NativeLibrary.findLibrary(paramString, paramClassLoader);
/* 597 */       if (DEBUG) {
/* 598 */         System.err.println("JNILibLoaderBase: loadLibraryInternal(" + paramString + "), TempJarCache: " + str);
/*     */       }
/* 600 */       if (null != str) {
/* 601 */         if (DEBUG) {
/* 602 */           System.err.println("JNILibLoaderBase: System.load(" + str + ") - mode 2");
/*     */         }
/* 604 */         System.load(str);
/* 605 */         b = 2;
/*     */       } else {
/* 607 */         if (DEBUG) {
/* 608 */           System.err.println("JNILibLoaderBase: System.loadLibrary(" + paramString + ") - mode 3: SystemEnvLibraryPaths: " + NativeLibrary.getSystemEnvLibraryPaths());
/*     */         }
/*     */         try {
/* 611 */           System.loadLibrary(paramString);
/* 612 */           b = 3;
/* 613 */         } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 614 */           if (DEBUG) {
/* 615 */             System.err.println("ERROR mode 3 - " + unsatisfiedLinkError.getMessage());
/*     */           }
/* 617 */           List list = NativeLibrary.enumerateLibraryPaths(paramString, paramString, paramString, paramClassLoader);
/*     */           
/* 619 */           for (Iterator<String> iterator = list.iterator(); 0 == b && iterator.hasNext(); ) {
/* 620 */             String str1 = iterator.next();
/* 621 */             if (DEBUG) {
/* 622 */               System.err.println("JNILibLoaderBase: System.load(" + str1 + ") - mode 4");
/*     */             }
/*     */             try {
/* 625 */               System.load(str1);
/* 626 */               b = 4;
/* 627 */             } catch (UnsatisfiedLinkError unsatisfiedLinkError1) {
/* 628 */               if (DEBUG) {
/* 629 */                 System.err.println("n/a - " + unsatisfiedLinkError1.getMessage());
/*     */               }
/* 631 */               if (!iterator.hasNext())
/*     */               {
/* 633 */                 throw new UnsatisfiedLinkError("Couldn't load library '" + paramString + "' generically including " + 
/* 634 */                     NativeLibrary.getSystemEnvLibraryPaths() + ", nor as " + list);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 642 */     if (DEBUG)
/* 643 */       System.err.println("JNILibLoaderBase: loadLibraryInternal(" + paramString + "): OK - mode " + b); 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/jvm/JNILibLoaderBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */