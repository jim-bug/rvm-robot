package com.jogamp.common.type;

public interface WriteCloneable {
  Object cloneMutable();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/type/WriteCloneable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */