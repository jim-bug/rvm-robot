/*     */ package com.jogamp.common;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionUtils
/*     */ {
/*     */   public static void dumpStack(PrintStream paramPrintStream) {
/*  37 */     dumpStack(paramPrintStream, 1, -1);
/*     */   }
/*     */   public static void dumpStack(PrintStream paramPrintStream, int paramInt1, int paramInt2) {
/*  40 */     dumpStack(paramPrintStream, new Exception(""), paramInt1 + 1, paramInt2);
/*     */   }
/*     */   public static void dumpStack(PrintStream paramPrintStream, Throwable paramThrowable, int paramInt1, int paramInt2) {
/*  43 */     dumpStack(paramPrintStream, paramThrowable.getStackTrace(), paramInt1, paramInt2);
/*     */   } public static void dumpStack(PrintStream paramPrintStream, StackTraceElement[] paramArrayOfStackTraceElement, int paramInt1, int paramInt2) {
/*     */     int i;
/*  46 */     if (null == paramArrayOfStackTraceElement) {
/*     */       return;
/*     */     }
/*     */     
/*  50 */     if (0 > paramInt2) {
/*  51 */       i = paramArrayOfStackTraceElement.length;
/*     */     } else {
/*  53 */       i = Math.min(paramInt2 + paramInt1, paramArrayOfStackTraceElement.length);
/*     */     } 
/*  55 */     for (int j = paramInt1; j < i; j++) {
/*  56 */       paramPrintStream.println("    [" + j + "]: " + paramArrayOfStackTraceElement[j]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int printCause(PrintStream paramPrintStream, String paramString, Throwable paramThrowable, int paramInt1, int paramInt2, int paramInt3) {
/*  95 */     int i = paramInt1;
/*  96 */     for (; null != paramThrowable && (-1 == paramInt2 || i < paramInt2); paramThrowable = paramThrowable.getCause()) {
/*  97 */       if (paramThrowable instanceof CustomStackTrace) {
/*  98 */         ((CustomStackTrace)paramThrowable).printCauseStack(paramPrintStream, paramString, i, paramInt3);
/*     */       } else {
/* 100 */         paramPrintStream.println(paramString + "[" + i + "] by " + paramThrowable.getClass().getSimpleName() + ": " + paramThrowable.getMessage() + " on thread " + Thread.currentThread().getName());
/* 101 */         dumpStack(paramPrintStream, paramThrowable.getStackTrace(), 0, paramInt3);
/*     */       } 
/* 103 */       i++;
/*     */     } 
/* 105 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printStackTrace(PrintStream paramPrintStream, Throwable paramThrowable, int paramInt1, int paramInt2) {
/* 117 */     if (paramThrowable instanceof CustomStackTrace) {
/* 118 */       ((CustomStackTrace)paramThrowable).printStackTrace(paramPrintStream, paramInt1, paramInt2);
/*     */     } else {
/* 120 */       paramPrintStream.println(paramThrowable.getClass().getSimpleName() + ": " + paramThrowable.getMessage() + " on thread " + Thread.currentThread().getName());
/* 121 */       dumpStack(paramPrintStream, paramThrowable.getStackTrace(), 0, paramInt2);
/* 122 */       printCause(paramPrintStream, "Caused", paramThrowable.getCause(), 0, paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dumpThrowable(String paramString, Throwable paramThrowable) {
/* 136 */     dumpThrowable(paramString, paramThrowable, -1, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dumpThrowable(String paramString, Throwable paramThrowable, int paramInt1, int paramInt2) {
/* 151 */     System.err.print("Caught " + paramString + " ");
/* 152 */     printStackTrace(System.err, paramThrowable, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public static interface CustomStackTrace {
/*     */     void printCauseStack(PrintStream param1PrintStream, String param1String, int param1Int1, int param1Int2);
/*     */     
/*     */     void printStackTrace(PrintStream param1PrintStream, int param1Int1, int param1Int2);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/ExceptionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */