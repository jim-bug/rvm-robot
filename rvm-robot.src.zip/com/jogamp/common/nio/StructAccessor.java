/*     */ package com.jogamp.common.nio;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructAccessor
/*     */ {
/*     */   private final ByteBuffer bb;
/*     */   
/*     */   public StructAccessor(ByteBuffer paramByteBuffer) {
/*  53 */     this.bb = paramByteBuffer.order(ByteOrder.nativeOrder());
/*  54 */     this.bb.rewind();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuffer getBuffer() {
/*  59 */     return this.bb;
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getDirectBufferAddress() {
/*  64 */     return Buffers.getDirectBufferAddressImpl(this.bb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBuffer slice(int paramInt1, int paramInt2) {
/*  74 */     this.bb.position(paramInt1);
/*  75 */     this.bb.limit(paramInt1 + paramInt2);
/*  76 */     ByteBuffer byteBuffer = this.bb.slice().order(this.bb.order());
/*  77 */     this.bb.position(0);
/*  78 */     this.bb.limit(this.bb.capacity());
/*  79 */     return byteBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public final byte getByteAt(int paramInt) {
/*  84 */     return this.bb.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setByteAt(int paramInt, byte paramByte) {
/*  89 */     this.bb.put(paramInt, paramByte);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean getBooleanAt(int paramInt) {
/*  94 */     return (0 != this.bb.get(paramInt));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setBooleanAt(int paramInt, boolean paramBoolean) {
/*  99 */     this.bb.put(paramInt, paramBoolean ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final char getCharAt(int paramInt) {
/* 104 */     return this.bb.getChar(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setCharAt(int paramInt, char paramChar) {
/* 109 */     this.bb.putChar(paramInt, paramChar);
/*     */   }
/*     */ 
/*     */   
/*     */   public final short getShortAt(int paramInt) {
/* 114 */     return this.bb.getShort(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setShortAt(int paramInt, short paramShort) {
/* 119 */     this.bb.putShort(paramInt, paramShort);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getIntAt(int paramInt) {
/* 124 */     return this.bb.getInt(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setIntAt(int paramInt1, int paramInt2) {
/* 129 */     this.bb.putInt(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getIntAt(int paramInt1, int paramInt2) {
/* 134 */     switch (paramInt2) {
/*     */       case 2:
/* 136 */         return this.bb.getShort(paramInt1) & 0xFFFF;
/*     */       case 4:
/* 138 */         return this.bb.getInt(paramInt1);
/*     */       case 8:
/* 140 */         return (int)(this.bb.getLong(paramInt1) & 0xFFFFFFFFL);
/*     */     } 
/* 142 */     throw new InternalError("invalid nativeSizeInBytes " + paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setIntAt(int paramInt1, int paramInt2, int paramInt3) {
/* 148 */     switch (paramInt3) {
/*     */       case 2:
/* 150 */         this.bb.putShort(paramInt1, (short)(paramInt2 & 0xFFFF));
/*     */         return;
/*     */       case 4:
/* 153 */         this.bb.putInt(paramInt1, paramInt2);
/*     */         return;
/*     */       case 8:
/* 156 */         this.bb.putLong(paramInt1, paramInt2 & 0xFFFFFFFFL);
/*     */         return;
/*     */     } 
/* 159 */     throw new InternalError("invalid nativeSizeInBytes " + paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final float getFloatAt(int paramInt) {
/* 165 */     return this.bb.getFloat(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setFloatAt(int paramInt, float paramFloat) {
/* 170 */     this.bb.putFloat(paramInt, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public final double getDoubleAt(int paramInt) {
/* 175 */     return this.bb.getDouble(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setDoubleAt(int paramInt, double paramDouble) {
/* 180 */     this.bb.putDouble(paramInt, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getLongAt(int paramInt) {
/* 185 */     return this.bb.getLong(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setLongAt(int paramInt, long paramLong) {
/* 190 */     this.bb.putLong(paramInt, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getLongAt(int paramInt1, int paramInt2) {
/* 195 */     switch (paramInt2) {
/*     */       case 4:
/* 197 */         return this.bb.getInt(paramInt1) & 0xFFFFFFFFL;
/*     */       case 8:
/* 199 */         return this.bb.getLong(paramInt1);
/*     */     } 
/* 201 */     throw new InternalError("invalid nativeSizeInBytes " + paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLongAt(int paramInt1, long paramLong, int paramInt2) {
/* 207 */     switch (paramInt2) {
/*     */       case 4:
/* 209 */         this.bb.putInt(paramInt1, (int)(paramLong & 0xFFFFFFFFL));
/*     */         return;
/*     */       case 8:
/* 212 */         this.bb.putLong(paramInt1, paramLong);
/*     */         return;
/*     */     } 
/* 215 */     throw new InternalError("invalid nativeSizeInBytes " + paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setBytesAt(int paramInt, byte[] paramArrayOfbyte) {
/* 220 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/* 221 */       this.bb.put(paramInt++, paramArrayOfbyte[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public final byte[] getBytesAt(int paramInt, byte[] paramArrayOfbyte) {
/* 226 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/* 227 */       paramArrayOfbyte[b] = this.bb.get(paramInt++);
/*     */     }
/* 229 */     return paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   public final void setBooleansAt(int paramInt, boolean[] paramArrayOfboolean) {
/* 233 */     for (byte b = 0; b < paramArrayOfboolean.length; b++) {
/* 234 */       this.bb.put(paramInt++, paramArrayOfboolean[b] ? 1 : 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public final boolean[] getBooleansAt(int paramInt, boolean[] paramArrayOfboolean) {
/* 239 */     for (byte b = 0; b < paramArrayOfboolean.length; b++) {
/* 240 */       paramArrayOfboolean[b] = (0 != this.bb.get(paramInt++));
/*     */     }
/* 242 */     return paramArrayOfboolean;
/*     */   }
/*     */   
/*     */   public final void setCharsAt(int paramInt, char[] paramArrayOfchar) {
/* 246 */     for (byte b = 0; b < paramArrayOfchar.length; b++, paramInt += 2) {
/* 247 */       this.bb.putChar(paramInt, paramArrayOfchar[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public final char[] getCharsAt(int paramInt, char[] paramArrayOfchar) {
/* 252 */     for (byte b = 0; b < paramArrayOfchar.length; b++, paramInt += 2) {
/* 253 */       paramArrayOfchar[b] = this.bb.getChar(paramInt);
/*     */     }
/* 255 */     return paramArrayOfchar;
/*     */   }
/*     */   
/*     */   public final void setShortsAt(int paramInt, short[] paramArrayOfshort) {
/* 259 */     for (byte b = 0; b < paramArrayOfshort.length; b++, paramInt += 2) {
/* 260 */       this.bb.putShort(paramInt, paramArrayOfshort[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public final short[] getShortsAt(int paramInt, short[] paramArrayOfshort) {
/* 265 */     for (byte b = 0; b < paramArrayOfshort.length; b++, paramInt += 2) {
/* 266 */       paramArrayOfshort[b] = this.bb.getShort(paramInt);
/*     */     }
/* 268 */     return paramArrayOfshort;
/*     */   }
/*     */   
/*     */   public final void setIntsAt(int paramInt, int[] paramArrayOfint) {
/* 272 */     for (byte b = 0; b < paramArrayOfint.length; b++, paramInt += 4) {
/* 273 */       this.bb.putInt(paramInt, paramArrayOfint[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public final int[] getIntsAt(int paramInt, int[] paramArrayOfint) {
/* 278 */     for (byte b = 0; b < paramArrayOfint.length; b++, paramInt += 4) {
/* 279 */       paramArrayOfint[b] = this.bb.getInt(paramInt);
/*     */     }
/* 281 */     return paramArrayOfint;
/*     */   }
/*     */   
/*     */   public final void setFloatsAt(int paramInt, float[] paramArrayOffloat) {
/* 285 */     for (byte b = 0; b < paramArrayOffloat.length; b++, paramInt += 4) {
/* 286 */       this.bb.putFloat(paramInt, paramArrayOffloat[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public final float[] getFloatsAt(int paramInt, float[] paramArrayOffloat) {
/* 291 */     for (byte b = 0; b < paramArrayOffloat.length; b++, paramInt += 4) {
/* 292 */       paramArrayOffloat[b] = this.bb.getFloat(paramInt);
/*     */     }
/* 294 */     return paramArrayOffloat;
/*     */   }
/*     */   
/*     */   public final void setDoublesAt(int paramInt, double[] paramArrayOfdouble) {
/* 298 */     for (byte b = 0; b < paramArrayOfdouble.length; b++, paramInt += 8) {
/* 299 */       this.bb.putDouble(paramInt, paramArrayOfdouble[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public final double[] getDoublesAt(int paramInt, double[] paramArrayOfdouble) {
/* 304 */     for (byte b = 0; b < paramArrayOfdouble.length; b++, paramInt += 8) {
/* 305 */       paramArrayOfdouble[b] = this.bb.getDouble(paramInt);
/*     */     }
/* 307 */     return paramArrayOfdouble;
/*     */   }
/*     */   
/*     */   public final void setLongsAt(int paramInt, long[] paramArrayOflong) {
/* 311 */     for (byte b = 0; b < paramArrayOflong.length; b++, paramInt += 8) {
/* 312 */       this.bb.putLong(paramInt, paramArrayOflong[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public final long[] getLongsAt(int paramInt, long[] paramArrayOflong) {
/* 317 */     for (byte b = 0; b < paramArrayOflong.length; b++, paramInt += 8) {
/* 318 */       paramArrayOflong[b] = this.bb.getLong(paramInt);
/*     */     }
/* 320 */     return paramArrayOflong;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/StructAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */