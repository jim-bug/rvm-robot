package com.jogamp.common.nio;

import java.nio.Buffer;
import java.nio.ByteBuffer;

public interface NativeBuffer<B extends NativeBuffer> {
  int elementSize();
  
  int limit();
  
  B limit(int paramInt);
  
  int capacity();
  
  int position();
  
  B position(int paramInt);
  
  int remaining();
  
  boolean hasRemaining();
  
  B clear();
  
  B flip();
  
  B rewind();
  
  boolean hasArray();
  
  int arrayOffset();
  
  Object array() throws UnsupportedOperationException;
  
  Buffer getBuffer();
  
  boolean isDirect();
  
  long getDirectBufferAddress();
  
  void storeDirectAddress(ByteBuffer paramByteBuffer);
  
  void storeDirectAddress(ByteBuffer paramByteBuffer, int paramInt);
  
  B put(B paramB);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/NativeBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */