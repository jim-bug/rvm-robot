/*     */ package com.jogamp.common.nio;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementBuffer
/*     */   extends AbstractBuffer<ElementBuffer>
/*     */ {
/*     */   ElementBuffer(int paramInt, ByteBuffer paramByteBuffer) {
/*  49 */     super(paramByteBuffer, paramInt, paramByteBuffer.capacity() / paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ElementBuffer allocate(int paramInt1, int paramInt2) {
/*  54 */     return new ElementBuffer(paramInt1, ByteBuffer.allocate(paramInt2 * paramInt1));
/*     */   }
/*     */ 
/*     */   
/*     */   public static ElementBuffer allocateDirect(int paramInt1, int paramInt2) {
/*  59 */     return new ElementBuffer(paramInt1, Buffers.newDirectByteBuffer(paramInt2 * paramInt1));
/*     */   }
/*     */   
/*     */   public static ElementBuffer wrap(int paramInt, ByteBuffer paramByteBuffer) {
/*  63 */     return new ElementBuffer(paramInt, paramByteBuffer);
/*     */   }
/*     */   public static ElementBuffer wrap(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3) {
/*  66 */     int i = paramByteBuffer.position();
/*  67 */     int j = paramByteBuffer.limit();
/*  68 */     paramByteBuffer.position(paramInt2);
/*  69 */     paramByteBuffer.limit(paramInt2 + paramInt1 * paramInt3);
/*  70 */     ElementBuffer elementBuffer = new ElementBuffer(paramInt1, paramByteBuffer.slice().order(paramByteBuffer.order()));
/*  71 */     paramByteBuffer.position(i);
/*  72 */     paramByteBuffer.limit(j);
/*  73 */     return elementBuffer;
/*     */   }
/*     */   public static ElementBuffer derefPointer(int paramInt1, long paramLong, int paramInt2) {
/*  76 */     if (0L == paramLong) {
/*  77 */       throw new NullPointerException("aptr is null");
/*     */     }
/*  79 */     ByteBuffer byteBuffer = Buffers.getDirectByteBuffer(paramLong, paramInt2 * paramInt1);
/*  80 */     if (null == byteBuffer) {
/*  81 */       throw new InternalError("Couldn't dereference aptr 0x" + Long.toHexString(paramLong) + ", size " + paramInt2 + " * " + paramInt1);
/*     */     }
/*  83 */     return new ElementBuffer(paramInt1, byteBuffer);
/*     */   }
/*     */   public static ElementBuffer derefPointer(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3) {
/*  86 */     return derefPointer(paramInt1, PointerBuffer.wrap(paramByteBuffer, paramInt2, 1).get(0), paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ElementBuffer put(ElementBuffer paramElementBuffer) {
/*  91 */     int i = paramElementBuffer.remaining();
/*  92 */     if (remaining() < i) {
/*  93 */       throw new IndexOutOfBoundsException("remaining[this " + remaining() + " < src " + i + "], this " + this + ", src " + paramElementBuffer);
/*     */     }
/*  95 */     if (elementSize() != paramElementBuffer.elementSize()) {
/*  96 */       throw new IllegalArgumentException("Element-Size mismatch source " + paramElementBuffer + ", dest " + this);
/*     */     }
/*  98 */     int j = paramElementBuffer.position();
/*  99 */     put(paramElementBuffer.getByteBuffer(), j, this.position, i);
/* 100 */     paramElementBuffer.position(j + i);
/* 101 */     this.position += i;
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuffer getByteBuffer() {
/* 107 */     return (ByteBuffer)this.buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBuffer slice(int paramInt1, int paramInt2) {
/* 117 */     if (0 > paramInt1 || paramInt1 + paramInt2 > limit()) {
/* 118 */       throw new IndexOutOfBoundsException("idx " + paramInt1 + " + elemCount " + paramInt2 + " not within [0.." + limit() + "), " + this);
/*     */     }
/* 120 */     ByteBuffer byteBuffer1 = getByteBuffer();
/* 121 */     int i = byteBuffer1.position();
/* 122 */     int j = byteBuffer1.limit();
/* 123 */     byteBuffer1.position(this.elementSize * paramInt1).limit(this.elementSize * (paramInt1 + paramInt2));
/* 124 */     ByteBuffer byteBuffer2 = byteBuffer1.slice().order(byteBuffer1.order());
/* 125 */     byteBuffer1.position(i).limit(j);
/* 126 */     return byteBuffer2;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuffer get(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3) {
/* 131 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || this.elementSize * (paramInt2 + paramInt3) > paramByteBuffer
/* 132 */       .limit()) {
/* 133 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 134 */           limit() + ", destLimit " + (paramByteBuffer.limit() / this.elementSize) + ", " + this);
/*     */     }
/* 136 */     ByteBuffer byteBuffer = getByteBuffer();
/* 137 */     int i = byteBuffer.limit();
/* 138 */     byteBuffer.position(paramInt1 * this.elementSize).limit((paramInt1 + paramInt3) * this.elementSize);
/* 139 */     int j = paramByteBuffer.position();
/* 140 */     paramByteBuffer.position(paramInt2 * this.elementSize);
/* 141 */     paramByteBuffer.put(byteBuffer).position(j);
/* 142 */     byteBuffer.limit(i).rewind();
/* 143 */     return paramByteBuffer;
/*     */   }
/*     */   
/*     */   public final ByteBuffer get(int paramInt, ByteBuffer paramByteBuffer) {
/* 147 */     return get(paramInt, paramByteBuffer, 0, 1);
/*     */   }
/*     */   
/*     */   public final ByteBuffer get(ByteBuffer paramByteBuffer) {
/* 151 */     ByteBuffer byteBuffer = get(this.position, paramByteBuffer, 0, 1);
/* 152 */     this.position++;
/* 153 */     return byteBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ElementBuffer get(ByteBuffer[] paramArrayOfByteBuffer, int paramInt1, int paramInt2) {
/* 160 */     if (paramArrayOfByteBuffer.length < paramInt1 + paramInt2) {
/* 161 */       throw new IndexOutOfBoundsException("dest.length " + paramArrayOfByteBuffer.length + " < (offset " + paramInt1 + " + length " + paramInt2 + ")");
/*     */     }
/* 163 */     if (remaining() < paramInt2) {
/* 164 */       throw new IndexOutOfBoundsException("remaining " + remaining() + " < length " + paramInt2 + ", this " + this);
/*     */     }
/* 166 */     while (paramInt2 > 0) {
/* 167 */       get(this.position++, paramArrayOfByteBuffer[paramInt1++]);
/* 168 */       paramInt2--;
/*     */     } 
/* 170 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ElementBuffer get(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) {
/* 175 */     if (1 != this.elementSize) throw new UnsupportedOperationException("'byte' type byte-size 1 != elementSize " + this.elementSize + ", " + this); 
/* 176 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || paramInt2 + paramInt3 > paramArrayOfbyte.length)
/*     */     {
/* 178 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 179 */           limit() + ", destLimit " + paramArrayOfbyte.length + ", " + this);
/*     */     }
/* 181 */     ByteBuffer byteBuffer = getByteBuffer();
/* 182 */     int i = byteBuffer.position();
/* 183 */     int j = byteBuffer.limit();
/* 184 */     byteBuffer.position(paramInt1).limit(paramInt1 + paramInt3);
/* 185 */     byteBuffer.get(paramArrayOfbyte, paramInt2, paramInt3);
/* 186 */     byteBuffer.position(i).limit(j);
/* 187 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer get(int paramInt1, short[] paramArrayOfshort, int paramInt2, int paramInt3) {
/* 191 */     if (2 != this.elementSize) throw new UnsupportedOperationException("'short' type byte-size 2 != elementSize " + this.elementSize + ", " + this); 
/* 192 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || paramInt2 + paramInt3 > paramArrayOfshort.length)
/*     */     {
/* 194 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 195 */           limit() + ", destLimit " + paramArrayOfshort.length + ", " + this);
/*     */     }
/* 197 */     ShortBuffer shortBuffer = getByteBuffer().asShortBuffer();
/* 198 */     shortBuffer.position(paramInt1).limit(paramInt1 + paramInt3);
/* 199 */     shortBuffer.get(paramArrayOfshort, paramInt2, paramInt3);
/* 200 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer get(int paramInt1, char[] paramArrayOfchar, int paramInt2, int paramInt3) {
/* 204 */     if (2 != this.elementSize) throw new UnsupportedOperationException("'char' type byte-size 2 != elementSize " + this.elementSize + ", " + this); 
/* 205 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || paramInt2 + paramInt3 > paramArrayOfchar.length)
/*     */     {
/* 207 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 208 */           limit() + ", destLimit " + paramArrayOfchar.length + ", " + this);
/*     */     }
/* 210 */     CharBuffer charBuffer = getByteBuffer().asCharBuffer();
/* 211 */     charBuffer.position(paramInt1).limit(paramInt1 + paramInt3);
/* 212 */     charBuffer.get(paramArrayOfchar, paramInt2, paramInt3);
/* 213 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer get(int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3) {
/* 217 */     if (4 != this.elementSize) throw new UnsupportedOperationException("'int' type byte-size 4 != elementSize " + this.elementSize + ", " + this); 
/* 218 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || paramInt2 + paramInt3 > paramArrayOfint.length)
/*     */     {
/* 220 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 221 */           limit() + ", destLimit " + paramArrayOfint.length + ", " + this);
/*     */     }
/* 223 */     IntBuffer intBuffer = getByteBuffer().asIntBuffer();
/* 224 */     intBuffer.position(paramInt1).limit(paramInt1 + paramInt3);
/* 225 */     intBuffer.get(paramArrayOfint, paramInt2, paramInt3);
/* 226 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer get(int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
/* 230 */     if (4 != this.elementSize) throw new UnsupportedOperationException("'float' type byte-size 4 != elementSize " + this.elementSize + ", " + this); 
/* 231 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || paramInt2 + paramInt3 > paramArrayOffloat.length)
/*     */     {
/* 233 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 234 */           limit() + ", destLimit " + paramArrayOffloat.length + ", " + this);
/*     */     }
/* 236 */     FloatBuffer floatBuffer = getByteBuffer().asFloatBuffer();
/* 237 */     floatBuffer.position(paramInt1).limit(paramInt1 + paramInt3);
/* 238 */     floatBuffer.get(paramArrayOffloat, paramInt2, paramInt3);
/* 239 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer get(int paramInt1, long[] paramArrayOflong, int paramInt2, int paramInt3) {
/* 243 */     if (8 != this.elementSize) throw new UnsupportedOperationException("'long' type byte-size 8 != elementSize " + this.elementSize + ", " + this); 
/* 244 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || paramInt2 + paramInt3 > paramArrayOflong.length)
/*     */     {
/* 246 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 247 */           limit() + ", destLimit " + paramArrayOflong.length + ", " + this);
/*     */     }
/* 249 */     LongBuffer longBuffer = getByteBuffer().asLongBuffer();
/* 250 */     longBuffer.position(paramInt1).limit(paramInt1 + paramInt3);
/* 251 */     longBuffer.get(paramArrayOflong, paramInt2, paramInt3);
/* 252 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer get(int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3) {
/* 256 */     if (8 != this.elementSize) throw new UnsupportedOperationException("'double' type byte-size 8 != elementSize " + this.elementSize + ", " + this); 
/* 257 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || paramInt2 + paramInt3 > paramArrayOfdouble.length)
/*     */     {
/* 259 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 260 */           limit() + ", destLimit " + paramArrayOfdouble.length + ", " + this);
/*     */     }
/* 262 */     DoubleBuffer doubleBuffer = getByteBuffer().asDoubleBuffer();
/* 263 */     doubleBuffer.position(paramInt1).limit(paramInt1 + paramInt3);
/* 264 */     doubleBuffer.get(paramArrayOfdouble, paramInt2, paramInt3);
/* 265 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ElementBuffer put(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3) {
/* 271 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || this.elementSize * (paramInt1 + paramInt3) > paramByteBuffer
/* 272 */       .limit()) {
/* 273 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 274 */           limit() + ", srcLimit " + (paramByteBuffer.limit() / this.elementSize) + ", " + this);
/*     */     }
/* 276 */     ByteBuffer byteBuffer = getByteBuffer();
/* 277 */     int i = paramByteBuffer.position();
/* 278 */     int j = paramByteBuffer.limit();
/* 279 */     paramByteBuffer.position(paramInt1 * this.elementSize).limit((paramInt1 + paramInt3) * this.elementSize);
/* 280 */     byteBuffer.position(this.elementSize * paramInt2);
/* 281 */     byteBuffer.put(paramByteBuffer).rewind();
/* 282 */     paramByteBuffer.limit(j).position(i);
/* 283 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer put(int paramInt, ByteBuffer paramByteBuffer) {
/* 287 */     return put(paramByteBuffer, 0, paramInt, 1);
/*     */   }
/*     */   
/*     */   public final ElementBuffer put(ByteBuffer paramByteBuffer) {
/* 291 */     put(this.position, paramByteBuffer);
/* 292 */     this.position++;
/* 293 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ElementBuffer put(ByteBuffer[] paramArrayOfByteBuffer, int paramInt1, int paramInt2) {
/* 299 */     if (paramArrayOfByteBuffer.length < paramInt1 + paramInt2) {
/* 300 */       throw new IndexOutOfBoundsException("src.length " + paramArrayOfByteBuffer.length + " < (offset " + paramInt1 + " + length " + paramInt2 + ")");
/*     */     }
/* 302 */     if (remaining() < paramInt2) {
/* 303 */       throw new IndexOutOfBoundsException("remaining " + remaining() + " < length " + paramInt2 + ", this " + this);
/*     */     }
/* 305 */     while (paramInt2 > 0) {
/* 306 */       put(this.position++, paramArrayOfByteBuffer[paramInt1++]);
/* 307 */       paramInt2--;
/*     */     } 
/* 309 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ElementBuffer put(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
/* 314 */     if (1 != this.elementSize) throw new UnsupportedOperationException("'byte' type byte-size 1 != elementSize " + this.elementSize + ", " + this); 
/* 315 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || paramInt1 + paramInt3 > paramArrayOfbyte.length)
/*     */     {
/* 317 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 318 */           limit() + ", srcLimit " + paramArrayOfbyte.length + ", " + this);
/*     */     }
/* 320 */     ByteBuffer byteBuffer = getByteBuffer();
/* 321 */     int i = byteBuffer.position();
/* 322 */     int j = byteBuffer.limit();
/* 323 */     byteBuffer.position(paramInt2).limit(paramInt2 + paramInt3);
/* 324 */     byteBuffer.put(paramArrayOfbyte, paramInt1, paramInt3);
/* 325 */     byteBuffer.position(i).limit(j);
/* 326 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer put(short[] paramArrayOfshort, int paramInt1, int paramInt2, int paramInt3) {
/* 330 */     if (2 != this.elementSize) throw new UnsupportedOperationException("'short' type byte-size 2 != elementSize " + this.elementSize + ", " + this); 
/* 331 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || paramInt1 + paramInt3 > paramArrayOfshort.length)
/*     */     {
/* 333 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 334 */           limit() + ", srcLimit " + paramArrayOfshort.length + ", " + this);
/*     */     }
/* 336 */     ShortBuffer shortBuffer = getByteBuffer().asShortBuffer();
/* 337 */     shortBuffer.position(paramInt2).limit(paramInt2 + paramInt3);
/* 338 */     shortBuffer.put(paramArrayOfshort, paramInt1, paramInt3);
/* 339 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer put(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3) {
/* 343 */     if (2 != this.elementSize) throw new UnsupportedOperationException("'char' type byte-size 2 != elementSize " + this.elementSize + ", " + this); 
/* 344 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || paramInt1 + paramInt3 > paramArrayOfchar.length)
/*     */     {
/* 346 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 347 */           limit() + ", srcLimit " + paramArrayOfchar.length + ", " + this);
/*     */     }
/* 349 */     CharBuffer charBuffer = getByteBuffer().asCharBuffer();
/* 350 */     charBuffer.position(paramInt2).limit(paramInt2 + paramInt3);
/* 351 */     charBuffer.put(paramArrayOfchar, paramInt1, paramInt3);
/* 352 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer put(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3) {
/* 356 */     if (4 != this.elementSize) throw new UnsupportedOperationException("'int' type byte-size 4 != elementSize " + this.elementSize + ", " + this); 
/* 357 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || paramInt1 + paramInt3 > paramArrayOfint.length)
/*     */     {
/* 359 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 360 */           limit() + ", srcLimit " + paramArrayOfint.length + ", " + this);
/*     */     }
/* 362 */     IntBuffer intBuffer = getByteBuffer().asIntBuffer();
/* 363 */     intBuffer.position(paramInt2).limit(paramInt2 + paramInt3);
/* 364 */     intBuffer.put(paramArrayOfint, paramInt1, paramInt3);
/* 365 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer put(float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3) {
/* 369 */     if (4 != this.elementSize) throw new UnsupportedOperationException("'float' type byte-size 4 != elementSize " + this.elementSize + ", " + this); 
/* 370 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || paramInt1 + paramInt3 > paramArrayOffloat.length)
/*     */     {
/* 372 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 373 */           limit() + ", srcLimit " + paramArrayOffloat.length + ", " + this);
/*     */     }
/* 375 */     FloatBuffer floatBuffer = getByteBuffer().asFloatBuffer();
/* 376 */     floatBuffer.position(paramInt2).limit(paramInt2 + paramInt3);
/* 377 */     floatBuffer.put(paramArrayOffloat, paramInt1, paramInt3);
/* 378 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer put(long[] paramArrayOflong, int paramInt1, int paramInt2, int paramInt3) {
/* 382 */     if (8 != this.elementSize) throw new UnsupportedOperationException("'long' type byte-size 8 != elementSize " + this.elementSize + ", " + this); 
/* 383 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || paramInt1 + paramInt3 > paramArrayOflong.length)
/*     */     {
/* 385 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 386 */           limit() + ", srcLimit " + paramArrayOflong.length + ", " + this);
/*     */     }
/* 388 */     LongBuffer longBuffer = getByteBuffer().asLongBuffer();
/* 389 */     longBuffer.position(paramInt2).limit(paramInt2 + paramInt3);
/* 390 */     longBuffer.put(paramArrayOflong, paramInt1, paramInt3);
/* 391 */     return this;
/*     */   }
/*     */   
/*     */   public final ElementBuffer put(double[] paramArrayOfdouble, int paramInt1, int paramInt2, int paramInt3) {
/* 395 */     if (8 != this.elementSize) throw new UnsupportedOperationException("'double' type byte-size 8 != elementSize " + this.elementSize + ", " + this); 
/* 396 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || paramInt1 + paramInt3 > paramArrayOfdouble.length)
/*     */     {
/* 398 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 399 */           limit() + ", srcLimit " + paramArrayOfdouble.length + ", " + this);
/*     */     }
/* 401 */     DoubleBuffer doubleBuffer = getByteBuffer().asDoubleBuffer();
/* 402 */     doubleBuffer.position(paramInt2).limit(paramInt2 + paramInt3);
/* 403 */     doubleBuffer.put(paramArrayOfdouble, paramInt1, paramInt3);
/* 404 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 409 */     return "ElementBuffer" + toSubString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/ElementBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */