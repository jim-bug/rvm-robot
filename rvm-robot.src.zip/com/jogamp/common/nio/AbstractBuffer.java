/*     */ package com.jogamp.common.nio;
/*     */ 
/*     */ import com.jogamp.common.os.Platform;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBuffer<B extends AbstractBuffer>
/*     */   implements NativeBuffer<B>
/*     */ {
/*     */   static {
/*  55 */     Platform.initSingleton();
/*  56 */   } public static final int POINTER_SIZE = Platform.is32Bit() ? 4 : 8;
/*     */   
/*     */   protected final Buffer buffer;
/*     */   
/*     */   protected final int elementSize;
/*     */   
/*     */   protected final int capacity;
/*     */   
/*     */   protected int limit;
/*     */   
/*     */   protected int position;
/*     */   
/*     */   protected AbstractBuffer(Buffer paramBuffer, int paramInt1, int paramInt2) {
/*  69 */     this.buffer = paramBuffer;
/*  70 */     this.elementSize = paramInt1;
/*  71 */     this.capacity = paramInt2;
/*  72 */     this.limit = paramInt2;
/*     */     
/*  74 */     this.position = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int elementSize() {
/*  79 */     return this.elementSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int limit() {
/*  84 */     return this.limit;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final B limit(int paramInt) {
/*  90 */     if (0 > paramInt || paramInt >= this.capacity) {
/*  91 */       throw new IllegalArgumentException("New limit " + paramInt + " out of bounds [0 .. capacity " + capacity() + "].");
/*     */     }
/*  93 */     this.limit = paramInt;
/*  94 */     return (B)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int capacity() {
/*  99 */     return this.capacity;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int position() {
/* 104 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final B position(int paramInt) {
/* 110 */     if (0 > paramInt || paramInt > this.limit) {
/* 111 */       throw new IllegalArgumentException("New position " + paramInt + " out of bounds [0 .. limit " + limit() + "].");
/*     */     }
/* 113 */     this.position = paramInt;
/* 114 */     return (B)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int remaining() {
/* 119 */     return this.limit - this.position;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasRemaining() {
/* 124 */     return (this.limit > this.position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final B clear() {
/* 130 */     this.limit = this.capacity;
/* 131 */     this.position = 0;
/* 132 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final B flip() {
/* 138 */     this.limit = this.position;
/* 139 */     this.position = 0;
/* 140 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final B rewind() {
/* 146 */     this.position = 0;
/* 147 */     return (B)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Buffer getBuffer() {
/* 152 */     return this.buffer;
/*     */   }
/*     */   
/*     */   public final boolean isDirect() {
/* 156 */     return this.buffer.isDirect();
/*     */   }
/*     */   
/*     */   public long getDirectBufferAddress() {
/* 160 */     if (isDirect()) {
/* 161 */       return Buffers.getDirectBufferAddressImpl(this.buffer);
/*     */     }
/* 163 */     return 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public void storeDirectAddress(ByteBuffer paramByteBuffer) {
/* 168 */     long l = getDirectBufferAddress();
/* 169 */     switch (POINTER_SIZE) {
/*     */       case 4:
/* 171 */         paramByteBuffer.putInt(0, (int)(l & 0xFFFFFFFFL));
/*     */         break;
/*     */       case 8:
/* 174 */         paramByteBuffer.putLong(0, l);
/*     */         break;
/*     */     } 
/* 177 */     paramByteBuffer.position(paramByteBuffer.position() + POINTER_SIZE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void storeDirectAddress(ByteBuffer paramByteBuffer, int paramInt) {
/* 182 */     long l = getDirectBufferAddress();
/* 183 */     switch (POINTER_SIZE) {
/*     */       case 4:
/* 185 */         paramByteBuffer.putInt(paramInt, (int)(l & 0xFFFFFFFFL));
/*     */         break;
/*     */       case 8:
/* 188 */         paramByteBuffer.putLong(paramInt, l);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasArray() {
/* 195 */     return this.buffer.hasArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int arrayOffset() {
/* 200 */     if (hasArray()) {
/* 201 */       return this.buffer.arrayOffset();
/*     */     }
/* 203 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object array() throws UnsupportedOperationException {
/* 209 */     return this.buffer.array();
/*     */   }
/*     */   
/*     */   protected String toSubString() {
/* 213 */     return "[direct[" + isDirect() + ", addr 0x" + Long.toHexString(getDirectBufferAddress()) + "], hasArray " + hasArray() + ", capacity " + this.capacity + ", position " + this.position + ", elementSize " + this.elementSize + ", buffer[capacity " + this.buffer.capacity() + ", lim " + this.buffer.limit() + ", pos " + this.buffer.position() + "]]";
/*     */   }
/*     */   
/*     */   public String toString() {
/* 217 */     return "AbstractBuffer" + toSubString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/AbstractBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */