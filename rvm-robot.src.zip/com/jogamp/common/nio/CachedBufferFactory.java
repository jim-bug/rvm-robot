/*     */ package com.jogamp.common.nio;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachedBufferFactory
/*     */ {
/*     */   public static final int DEFAULT_ALLOCATION_SIZE = 1048576;
/*     */   private final int ALLOCATION_SIZE;
/*     */   private ByteBuffer currentBuffer;
/*     */   
/*     */   private CachedBufferFactory() {
/*  75 */     this(1048576, 1048576);
/*     */   }
/*     */   
/*     */   private CachedBufferFactory(int paramInt1, int paramInt2) {
/*  79 */     this.currentBuffer = Buffers.newDirectByteBuffer(paramInt1);
/*  80 */     this.ALLOCATION_SIZE = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CachedBufferFactory create() {
/*  89 */     return new CachedBufferFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CachedBufferFactory create(int paramInt) {
/*  97 */     return new CachedBufferFactory(paramInt, 1048576);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CachedBufferFactory create(int paramInt, boolean paramBoolean) {
/* 107 */     return new CachedBufferFactory(paramInt, paramBoolean ? -1 : 1048576);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CachedBufferFactory create(int paramInt1, int paramInt2) {
/* 114 */     return new CachedBufferFactory(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CachedBufferFactory createSynchronized() {
/* 122 */     return new SynchronizedCachedBufferFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CachedBufferFactory createSynchronized(int paramInt) {
/* 129 */     return new SynchronizedCachedBufferFactory(paramInt, 1048576);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CachedBufferFactory createSynchronized(int paramInt, boolean paramBoolean) {
/* 136 */     return new SynchronizedCachedBufferFactory(paramInt, paramBoolean ? -1 : 1048576);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CachedBufferFactory createSynchronized(int paramInt1, int paramInt2) {
/* 143 */     return new CachedBufferFactory(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFixed() {
/* 151 */     return (this.ALLOCATION_SIZE == -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAllocationSize() {
/* 159 */     return this.ALLOCATION_SIZE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkIfFixed() {
/* 166 */     if (this.ALLOCATION_SIZE == 0) {
/* 167 */       throw new RuntimeException("fixed size buffer factory ran out ouf bounds.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 172 */     if (null != this.currentBuffer) {
/* 173 */       this.currentBuffer.clear();
/* 174 */       this.currentBuffer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuffer newDirectByteBuffer(int paramInt) {
/* 180 */     if (paramInt > this.currentBuffer.capacity()) {
/* 181 */       checkIfFixed();
/* 182 */       return Buffers.newDirectByteBuffer(paramInt);
/*     */     } 
/*     */ 
/*     */     
/* 186 */     if (paramInt > this.currentBuffer.remaining()) {
/* 187 */       checkIfFixed();
/* 188 */       this.currentBuffer = Buffers.newDirectByteBuffer(this.ALLOCATION_SIZE);
/*     */     } 
/*     */     
/* 191 */     this.currentBuffer.limit(this.currentBuffer.position() + paramInt);
/* 192 */     ByteBuffer byteBuffer = this.currentBuffer.slice().order(this.currentBuffer.order());
/* 193 */     this.currentBuffer.position(this.currentBuffer.limit());
/* 194 */     this.currentBuffer.limit(this.currentBuffer.capacity());
/* 195 */     return byteBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuffer newDirectByteBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 200 */     return (ByteBuffer)newDirectByteBuffer(paramInt2).put(paramArrayOfbyte, paramInt1, paramInt2).rewind();
/*     */   }
/*     */   
/*     */   public ByteBuffer newDirectByteBuffer(byte[] paramArrayOfbyte, int paramInt) {
/* 204 */     return newDirectByteBuffer(paramArrayOfbyte, paramInt, paramArrayOfbyte.length - paramInt);
/*     */   }
/*     */   
/*     */   public ByteBuffer newDirectByteBuffer(byte[] paramArrayOfbyte) {
/* 208 */     return newDirectByteBuffer(paramArrayOfbyte, 0);
/*     */   }
/*     */   
/*     */   public DoubleBuffer newDirectDoubleBuffer(int paramInt) {
/* 212 */     return newDirectByteBuffer(paramInt * 8).asDoubleBuffer();
/*     */   }
/*     */   
/*     */   public DoubleBuffer newDirectDoubleBuffer(double[] paramArrayOfdouble, int paramInt1, int paramInt2) {
/* 216 */     return (DoubleBuffer)newDirectDoubleBuffer(paramInt2).put(paramArrayOfdouble, paramInt1, paramInt2).rewind();
/*     */   }
/*     */   
/*     */   public DoubleBuffer newDirectDoubleBuffer(double[] paramArrayOfdouble, int paramInt) {
/* 220 */     return newDirectDoubleBuffer(paramArrayOfdouble, paramInt, paramArrayOfdouble.length - paramInt);
/*     */   }
/*     */   
/*     */   public DoubleBuffer newDirectDoubleBuffer(double[] paramArrayOfdouble) {
/* 224 */     return newDirectDoubleBuffer(paramArrayOfdouble, 0);
/*     */   }
/*     */   
/*     */   public FloatBuffer newDirectFloatBuffer(int paramInt) {
/* 228 */     return newDirectByteBuffer(paramInt * 4).asFloatBuffer();
/*     */   }
/*     */   
/*     */   public FloatBuffer newDirectFloatBuffer(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
/* 232 */     return (FloatBuffer)newDirectFloatBuffer(paramInt2).put(paramArrayOffloat, paramInt1, paramInt2).rewind();
/*     */   }
/*     */   
/*     */   public FloatBuffer newDirectFloatBuffer(float[] paramArrayOffloat, int paramInt) {
/* 236 */     return newDirectFloatBuffer(paramArrayOffloat, paramInt, paramArrayOffloat.length - paramInt);
/*     */   }
/*     */   
/*     */   public FloatBuffer newDirectFloatBuffer(float[] paramArrayOffloat) {
/* 240 */     return newDirectFloatBuffer(paramArrayOffloat, 0);
/*     */   }
/*     */   
/*     */   public IntBuffer newDirectIntBuffer(int paramInt) {
/* 244 */     return newDirectByteBuffer(paramInt * 4).asIntBuffer();
/*     */   }
/*     */   
/*     */   public IntBuffer newDirectIntBuffer(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 248 */     return (IntBuffer)newDirectIntBuffer(paramInt2).put(paramArrayOfint, paramInt1, paramInt2).rewind();
/*     */   }
/*     */   
/*     */   public IntBuffer newDirectIntBuffer(int[] paramArrayOfint, int paramInt) {
/* 252 */     return newDirectIntBuffer(paramArrayOfint, paramInt, paramArrayOfint.length - paramInt);
/*     */   }
/*     */   
/*     */   public IntBuffer newDirectIntBuffer(int[] paramArrayOfint) {
/* 256 */     return newDirectIntBuffer(paramArrayOfint, 0);
/*     */   }
/*     */   
/*     */   public LongBuffer newDirectLongBuffer(int paramInt) {
/* 260 */     return newDirectByteBuffer(paramInt * 8).asLongBuffer();
/*     */   }
/*     */   
/*     */   public LongBuffer newDirectLongBuffer(long[] paramArrayOflong, int paramInt1, int paramInt2) {
/* 264 */     return (LongBuffer)newDirectLongBuffer(paramInt2).put(paramArrayOflong, paramInt1, paramInt2).rewind();
/*     */   }
/*     */   
/*     */   public LongBuffer newDirectLongBuffer(long[] paramArrayOflong, int paramInt) {
/* 268 */     return newDirectLongBuffer(paramArrayOflong, paramInt, paramArrayOflong.length - paramInt);
/*     */   }
/*     */   
/*     */   public LongBuffer newDirectLongBuffer(long[] paramArrayOflong) {
/* 272 */     return newDirectLongBuffer(paramArrayOflong, 0);
/*     */   }
/*     */   
/*     */   public ShortBuffer newDirectShortBuffer(int paramInt) {
/* 276 */     return newDirectByteBuffer(paramInt * 2).asShortBuffer();
/*     */   }
/*     */   
/*     */   public ShortBuffer newDirectShortBuffer(short[] paramArrayOfshort, int paramInt1, int paramInt2) {
/* 280 */     return (ShortBuffer)newDirectShortBuffer(paramInt2).put(paramArrayOfshort, paramInt1, paramInt2).rewind();
/*     */   }
/*     */   
/*     */   public ShortBuffer newDirectShortBuffer(short[] paramArrayOfshort, int paramInt) {
/* 284 */     return newDirectShortBuffer(paramArrayOfshort, paramInt, paramArrayOfshort.length - paramInt);
/*     */   }
/*     */   
/*     */   public ShortBuffer newDirectShortBuffer(short[] paramArrayOfshort) {
/* 288 */     return newDirectShortBuffer(paramArrayOfshort, 0);
/*     */   }
/*     */   
/*     */   public CharBuffer newDirectCharBuffer(int paramInt) {
/* 292 */     return newDirectByteBuffer(paramInt * 2).asCharBuffer();
/*     */   }
/*     */   
/*     */   public CharBuffer newDirectCharBuffer(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
/* 296 */     return (CharBuffer)newDirectCharBuffer(paramInt2).put(paramArrayOfchar, paramInt1, paramInt2).rewind();
/*     */   }
/*     */   
/*     */   public CharBuffer newDirectCharBuffer(char[] paramArrayOfchar, int paramInt) {
/* 300 */     return newDirectCharBuffer(paramArrayOfchar, paramInt, paramArrayOfchar.length - paramInt);
/*     */   }
/*     */   
/*     */   public CharBuffer newDirectCharBuffer(char[] paramArrayOfchar) {
/* 304 */     return newDirectCharBuffer(paramArrayOfchar, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 309 */     if (paramObject == null) {
/* 310 */       return false;
/*     */     }
/* 312 */     if (getClass() != paramObject.getClass()) {
/* 313 */       return false;
/*     */     }
/* 315 */     CachedBufferFactory cachedBufferFactory = (CachedBufferFactory)paramObject;
/* 316 */     if (this.ALLOCATION_SIZE != cachedBufferFactory.ALLOCATION_SIZE) {
/* 317 */       return false;
/*     */     }
/* 319 */     if (this.currentBuffer != cachedBufferFactory.currentBuffer && (this.currentBuffer == null || !this.currentBuffer.equals(cachedBufferFactory.currentBuffer))) {
/* 320 */       return false;
/*     */     }
/* 322 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 327 */     return getClass().getName() + "[static:" + isFixed() + " alloc size:" + getAllocationSize() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SynchronizedCachedBufferFactory
/*     */     extends CachedBufferFactory
/*     */   {
/*     */     private SynchronizedCachedBufferFactory() {}
/*     */ 
/*     */     
/*     */     private SynchronizedCachedBufferFactory(int param1Int1, int param1Int2) {
/* 339 */       super(param1Int1, param1Int2);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized ByteBuffer newDirectByteBuffer(int param1Int) {
/* 344 */       return super.newDirectByteBuffer(param1Int);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/CachedBufferFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */