/*     */ package com.jogamp.common.nio;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappedByteBufferOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   private final MappedByteBufferInputStream parent;
/*     */   
/*     */   MappedByteBufferOutputStream(MappedByteBufferInputStream paramMappedByteBufferInputStream, MappedByteBufferInputStream.FileResizeOp paramFileResizeOp) throws IOException {
/*  55 */     if (FileChannel.MapMode.READ_ONLY == paramMappedByteBufferInputStream.getMapMode()) {
/*  56 */       throw new IOException("FileChannel map-mode is read-only");
/*     */     }
/*  58 */     this.parent = paramMappedByteBufferInputStream;
/*  59 */     this.parent.setFileResizeOp(paramFileResizeOp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedByteBufferOutputStream(FileChannel paramFileChannel, FileChannel.MapMode paramMapMode, MappedByteBufferInputStream.CacheMode paramCacheMode, int paramInt, MappedByteBufferInputStream.FileResizeOp paramFileResizeOp) throws IOException {
/*  78 */     this(new MappedByteBufferInputStream(paramFileChannel, paramMapMode, paramCacheMode, paramInt, paramFileChannel.size(), 0), paramFileResizeOp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void setSynchronous(boolean paramBoolean) {
/*  85 */     this.parent.setSynchronous(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized boolean getSynchronous() {
/*  91 */     return this.parent.getSynchronous();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void setLength(long paramLong) throws IOException {
/*  98 */     this.parent.setLength(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void notifyLengthChange(long paramLong) throws IOException {
/* 105 */     this.parent.notifyLengthChange(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized long length() {
/* 112 */     return this.parent.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized long remaining() throws IOException {
/* 119 */     return this.parent.remaining();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized long position() throws IOException {
/* 126 */     return this.parent.position();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized MappedByteBufferInputStream position(long paramLong) throws IOException {
/* 133 */     return this.parent.position(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized long skip(long paramLong) throws IOException {
/* 140 */     return this.parent.skip(paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized void flush() throws IOException {
/* 145 */     this.parent.flush(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void flush(boolean paramBoolean) throws IOException {
/* 153 */     this.parent.flush(paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized void close() throws IOException {
/* 158 */     this.parent.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized void write(int paramInt) throws IOException {
/* 163 */     this.parent.checkOpen();
/* 164 */     long l = this.parent.remaining();
/* 165 */     if (l < 1L) {
/* 166 */       this.parent.setLength(this.parent.length() + 1L);
/*     */     }
/* 168 */     ByteBuffer byteBuffer = this.parent.currentSlice();
/* 169 */     int i = byteBuffer.remaining();
/* 170 */     if (0 == i && 
/* 171 */       null == (byteBuffer = this.parent.nextSlice())) {
/* 172 */       if (MappedByteBufferInputStream.DEBUG) {
/* 173 */         System.err.println("EOT write: " + this.parent.currentSlice());
/* 174 */         this.parent.dbgDump("EOT write:", System.err);
/*     */       } 
/* 176 */       throw new IOException("EOT");
/*     */     } 
/*     */     
/* 179 */     byteBuffer.put((byte)(paramInt & 0xFF));
/*     */ 
/*     */     
/* 182 */     if (null != byteBuffer) {
/* 183 */       this.parent.syncSlice(byteBuffer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 189 */     this.parent.checkOpen();
/* 190 */     if (paramArrayOfbyte == null)
/* 191 */       throw new NullPointerException(); 
/* 192 */     if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 > paramArrayOfbyte.length || paramInt1 + paramInt2 > paramArrayOfbyte.length || paramInt1 + paramInt2 < 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 198 */       throw new IndexOutOfBoundsException("offset " + paramInt1 + ", length " + paramInt2 + ", b.length " + paramArrayOfbyte.length); } 
/* 199 */     if (0 == paramInt2) {
/*     */       return;
/*     */     }
/* 202 */     long l = this.parent.remaining();
/* 203 */     if (l < paramInt2) {
/* 204 */       this.parent.setLength(this.parent.length() + paramInt2 - l);
/*     */     }
/* 206 */     int i = 0;
/* 207 */     ByteBuffer byteBuffer = null;
/* 208 */     while (i < paramInt2) {
/* 209 */       byteBuffer = this.parent.currentSlice();
/* 210 */       int j = byteBuffer.remaining();
/* 211 */       if (0 == j) {
/* 212 */         if (null == (byteBuffer = this.parent.nextSlice())) {
/* 213 */           if (MappedByteBufferInputStream.DEBUG) {
/* 214 */             System.err.println("EOT write: offset " + paramInt1 + ", length " + paramInt2 + ", b.length " + paramArrayOfbyte.length);
/* 215 */             System.err.println("EOT write: written " + i + " / " + paramInt2 + ", currRem " + j);
/* 216 */             System.err.println("EOT write: " + this.parent.currentSlice());
/* 217 */             this.parent.dbgDump("EOT write:", System.err);
/*     */           } 
/* 219 */           throw new InternalError("EOT");
/*     */         } 
/* 221 */         j = byteBuffer.remaining();
/*     */       } 
/* 223 */       int k = Math.min(paramInt2 - i, j);
/* 224 */       byteBuffer.put(paramArrayOfbyte, paramInt1 + i, k);
/* 225 */       i += k;
/*     */     } 
/*     */     
/* 228 */     if (null != byteBuffer) {
/* 229 */       this.parent.syncSlice(byteBuffer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void write(ByteBuffer paramByteBuffer, int paramInt) throws IOException {
/* 242 */     this.parent.checkOpen();
/* 243 */     if (paramByteBuffer == null)
/* 244 */       throw new NullPointerException(); 
/* 245 */     if (paramInt < 0 || paramInt > paramByteBuffer.remaining())
/* 246 */       throw new IndexOutOfBoundsException("length " + paramInt + ", b " + paramByteBuffer); 
/* 247 */     if (0 == paramInt) {
/*     */       return;
/*     */     }
/* 250 */     long l = this.parent.remaining();
/* 251 */     if (l < paramInt) {
/* 252 */       this.parent.setLength(this.parent.length() + paramInt - l);
/*     */     }
/* 254 */     int i = 0;
/* 255 */     ByteBuffer byteBuffer = null;
/* 256 */     while (i < paramInt) {
/* 257 */       byteBuffer = this.parent.currentSlice();
/* 258 */       int j = byteBuffer.remaining();
/* 259 */       if (0 == j) {
/* 260 */         if (null == (byteBuffer = this.parent.nextSlice())) {
/* 261 */           if (MappedByteBufferInputStream.DEBUG) {
/* 262 */             System.err.println("EOT write: length " + paramInt + ", b " + paramByteBuffer);
/* 263 */             System.err.println("EOT write: written " + i + " / " + paramInt + ", currRem " + j);
/* 264 */             System.err.println("EOT write: " + this.parent.currentSlice());
/* 265 */             this.parent.dbgDump("EOT write:", System.err);
/*     */           } 
/* 267 */           throw new InternalError("EOT");
/*     */         } 
/* 269 */         j = byteBuffer.remaining();
/*     */       } 
/* 271 */       int k = Math.min(paramInt - i, j);
/*     */       
/* 273 */       if (byteBuffer.hasArray() && paramByteBuffer.hasArray()) {
/* 274 */         System.arraycopy(paramByteBuffer.array(), paramByteBuffer.arrayOffset() + paramByteBuffer.position(), byteBuffer
/* 275 */             .array(), byteBuffer.arrayOffset() + byteBuffer.position(), k);
/*     */         
/* 277 */         paramByteBuffer.position(paramByteBuffer.position() + k);
/* 278 */         byteBuffer.position(byteBuffer.position() + k);
/* 279 */       } else if (k == j) {
/* 280 */         byteBuffer.put(paramByteBuffer);
/*     */       } else {
/* 282 */         int m = paramByteBuffer.limit();
/* 283 */         paramByteBuffer.limit(k);
/*     */         try {
/* 285 */           byteBuffer.put(paramByteBuffer);
/*     */         } finally {
/* 287 */           paramByteBuffer.limit(m);
/*     */         } 
/*     */       } 
/* 290 */       i += k;
/*     */     } 
/*     */     
/* 293 */     if (null != byteBuffer) {
/* 294 */       this.parent.syncSlice(byteBuffer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void write(MappedByteBufferInputStream paramMappedByteBufferInputStream, long paramLong) throws IOException {
/* 311 */     this.parent.checkOpen();
/* 312 */     if (paramMappedByteBufferInputStream == null)
/* 313 */       throw new NullPointerException(); 
/* 314 */     if (paramLong < 0L || paramLong > paramMappedByteBufferInputStream.remaining())
/* 315 */       throw new IndexOutOfBoundsException("length " + paramLong + ", b " + paramMappedByteBufferInputStream); 
/* 316 */     if (0L == paramLong) {
/*     */       return;
/*     */     }
/* 319 */     long l1 = this.parent.remaining();
/* 320 */     if (l1 < paramLong) {
/* 321 */       this.parent.setLength(this.parent.length() + paramLong - l1);
/*     */     }
/* 323 */     long l2 = 0L;
/* 324 */     ByteBuffer byteBuffer = null;
/* 325 */     while (l2 < paramLong) {
/* 326 */       byteBuffer = this.parent.currentSlice();
/* 327 */       int i = byteBuffer.remaining();
/* 328 */       if (0 == i) {
/* 329 */         if (null == (byteBuffer = this.parent.nextSlice())) {
/* 330 */           if (MappedByteBufferInputStream.DEBUG) {
/* 331 */             System.err.println("EOT write: length " + paramLong + ", b " + paramMappedByteBufferInputStream);
/* 332 */             System.err.println("EOT write: written " + l2 + " / " + paramLong + ", currRem " + i);
/* 333 */             System.err.println("EOT write: " + this.parent.currentSlice());
/* 334 */             this.parent.dbgDump("EOT write:", System.err);
/*     */           } 
/* 336 */           throw new InternalError("EOT");
/*     */         } 
/* 338 */         i = byteBuffer.remaining();
/*     */       } 
/* 340 */       int j = paramMappedByteBufferInputStream.read(byteBuffer, (int)Math.min(paramLong - l2, i));
/* 341 */       if (0 > j) {
/* 342 */         throw new InternalError("Unexpected InputStream EOT");
/*     */       }
/* 344 */       l2 += j;
/*     */     } 
/*     */     
/* 347 */     if (null != byteBuffer)
/* 348 */       this.parent.syncSlice(byteBuffer); 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/MappedByteBufferOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */