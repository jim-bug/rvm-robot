/*      */ package com.jogamp.common.nio;
/*      */ 
/*      */ import com.jogamp.common.ExceptionUtils;
/*      */ import com.jogamp.common.util.ReflectionUtil;
/*      */ import com.jogamp.common.util.SecurityUtil;
/*      */ import com.jogamp.common.util.UnsafeUtil;
/*      */ import com.jogamp.common.util.ValueConv;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.DoubleBuffer;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import java.nio.LongBuffer;
/*      */ import java.nio.ShortBuffer;
/*      */ import java.security.PrivilegedAction;
/*      */ import jogamp.common.Debug;
/*      */ import jogamp.common.os.PlatformPropsImpl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Buffers
/*      */ {
/*   74 */   static final boolean DEBUG = Debug.debug("Buffers");
/*      */ 
/*      */   
/*      */   public static final int SIZEOF_BYTE = 1;
/*      */   
/*      */   public static final int SIZEOF_SHORT = 2;
/*      */   
/*      */   public static final int SIZEOF_CHAR = 2;
/*      */   
/*      */   public static final int SIZEOF_INT = 4;
/*      */   
/*      */   public static final int SIZEOF_FLOAT = 4;
/*      */   
/*      */   public static final int SIZEOF_LONG = 8;
/*      */   
/*      */   public static final int SIZEOF_DOUBLE = 8;
/*      */ 
/*      */   
/*      */   public static ByteBuffer newDirectByteBuffer(int paramInt) {
/*   93 */     return nativeOrder(ByteBuffer.allocateDirect(paramInt));
/*      */   }
/*      */   
/*      */   public static ByteBuffer newDirectByteBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*   97 */     return (ByteBuffer)newDirectByteBuffer(paramInt2).put(paramArrayOfbyte, paramInt1, paramInt2).rewind();
/*      */   }
/*      */   
/*      */   public static ByteBuffer newDirectByteBuffer(byte[] paramArrayOfbyte, int paramInt) {
/*  101 */     return newDirectByteBuffer(paramArrayOfbyte, paramInt, paramArrayOfbyte.length - paramInt);
/*      */   }
/*      */   
/*      */   public static ByteBuffer newDirectByteBuffer(byte[] paramArrayOfbyte) {
/*  105 */     return newDirectByteBuffer(paramArrayOfbyte, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBuffer newDirectDoubleBuffer(int paramInt) {
/*  114 */     return newDirectByteBuffer(paramInt * 8).asDoubleBuffer();
/*      */   }
/*      */   
/*      */   public static DoubleBuffer newDirectDoubleBuffer(double[] paramArrayOfdouble, int paramInt1, int paramInt2) {
/*  118 */     return (DoubleBuffer)newDirectDoubleBuffer(paramInt2).put(paramArrayOfdouble, paramInt1, paramInt2).rewind();
/*      */   }
/*      */   
/*      */   public static DoubleBuffer newDirectDoubleBuffer(double[] paramArrayOfdouble, int paramInt) {
/*  122 */     return newDirectDoubleBuffer(paramArrayOfdouble, paramInt, paramArrayOfdouble.length - paramInt);
/*      */   }
/*      */   
/*      */   public static DoubleBuffer newDirectDoubleBuffer(double[] paramArrayOfdouble) {
/*  126 */     return newDirectDoubleBuffer(paramArrayOfdouble, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBuffer newDirectFloatBuffer(int paramInt) {
/*  135 */     return newDirectByteBuffer(paramInt * 4).asFloatBuffer();
/*      */   }
/*      */   
/*      */   public static FloatBuffer newDirectFloatBuffer(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
/*  139 */     return (FloatBuffer)newDirectFloatBuffer(paramInt2).put(paramArrayOffloat, paramInt1, paramInt2).rewind();
/*      */   }
/*      */   
/*      */   public static FloatBuffer newDirectFloatBuffer(float[] paramArrayOffloat, int paramInt) {
/*  143 */     return newDirectFloatBuffer(paramArrayOffloat, paramInt, paramArrayOffloat.length - paramInt);
/*      */   }
/*      */   
/*      */   public static FloatBuffer newDirectFloatBuffer(float[] paramArrayOffloat) {
/*  147 */     return newDirectFloatBuffer(paramArrayOffloat, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntBuffer newDirectIntBuffer(int paramInt) {
/*  156 */     return newDirectByteBuffer(paramInt * 4).asIntBuffer();
/*      */   }
/*      */   
/*      */   public static IntBuffer newDirectIntBuffer(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/*  160 */     return (IntBuffer)newDirectIntBuffer(paramInt2).put(paramArrayOfint, paramInt1, paramInt2).rewind();
/*      */   }
/*      */   
/*      */   public static IntBuffer newDirectIntBuffer(int[] paramArrayOfint, int paramInt) {
/*  164 */     return newDirectIntBuffer(paramArrayOfint, paramInt, paramArrayOfint.length - paramInt);
/*      */   }
/*      */   
/*      */   public static IntBuffer newDirectIntBuffer(int[] paramArrayOfint) {
/*  168 */     return newDirectIntBuffer(paramArrayOfint, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LongBuffer newDirectLongBuffer(int paramInt) {
/*  177 */     return newDirectByteBuffer(paramInt * 8).asLongBuffer();
/*      */   }
/*      */   
/*      */   public static LongBuffer newDirectLongBuffer(long[] paramArrayOflong, int paramInt1, int paramInt2) {
/*  181 */     return (LongBuffer)newDirectLongBuffer(paramInt2).put(paramArrayOflong, paramInt1, paramInt2).rewind();
/*      */   }
/*      */   
/*      */   public static LongBuffer newDirectLongBuffer(long[] paramArrayOflong, int paramInt) {
/*  185 */     return newDirectLongBuffer(paramArrayOflong, paramInt, paramArrayOflong.length - paramInt);
/*      */   }
/*      */   
/*      */   public static LongBuffer newDirectLongBuffer(long[] paramArrayOflong) {
/*  189 */     return newDirectLongBuffer(paramArrayOflong, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ShortBuffer newDirectShortBuffer(int paramInt) {
/*  198 */     return newDirectByteBuffer(paramInt * 2).asShortBuffer();
/*      */   }
/*      */   
/*      */   public static ShortBuffer newDirectShortBuffer(short[] paramArrayOfshort, int paramInt1, int paramInt2) {
/*  202 */     return (ShortBuffer)newDirectShortBuffer(paramInt2).put(paramArrayOfshort, paramInt1, paramInt2).rewind();
/*      */   }
/*      */   
/*      */   public static ShortBuffer newDirectShortBuffer(short[] paramArrayOfshort, int paramInt) {
/*  206 */     return newDirectShortBuffer(paramArrayOfshort, paramInt, paramArrayOfshort.length - paramInt);
/*      */   }
/*      */   
/*      */   public static ShortBuffer newDirectShortBuffer(short[] paramArrayOfshort) {
/*  210 */     return newDirectShortBuffer(paramArrayOfshort, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CharBuffer newDirectCharBuffer(int paramInt) {
/*  219 */     return newDirectByteBuffer(paramInt * 2).asCharBuffer();
/*      */   }
/*      */   
/*      */   public static CharBuffer newDirectCharBuffer(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
/*  223 */     return (CharBuffer)newDirectCharBuffer(paramInt2).put(paramArrayOfchar, paramInt1, paramInt2).rewind();
/*      */   }
/*      */   
/*      */   public static CharBuffer newDirectCharBuffer(char[] paramArrayOfchar, int paramInt) {
/*  227 */     return newDirectCharBuffer(paramArrayOfchar, paramInt, paramArrayOfchar.length - paramInt);
/*      */   }
/*      */   
/*      */   public static CharBuffer newDirectCharBuffer(char[] paramArrayOfchar) {
/*  231 */     return newDirectCharBuffer(paramArrayOfchar, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer nativeOrder(ByteBuffer paramByteBuffer) {
/*  240 */     return paramByteBuffer.order(ByteOrder.nativeOrder());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Buffer> typeNameToBufferClass(String paramString) {
/*  250 */     if (paramString == null) {
/*  251 */       return null;
/*      */     }
/*  253 */     if ("byte".equals(paramString))
/*  254 */       return (Class)ByteBuffer.class; 
/*  255 */     if ("short".equals(paramString))
/*  256 */       return (Class)ShortBuffer.class; 
/*  257 */     if ("char".equals(paramString))
/*  258 */       return (Class)CharBuffer.class; 
/*  259 */     if ("int".equals(paramString))
/*  260 */       return (Class)IntBuffer.class; 
/*  261 */     if ("float".equals(paramString))
/*  262 */       return (Class)FloatBuffer.class; 
/*  263 */     if ("long".equals(paramString))
/*  264 */       return (Class)LongBuffer.class; 
/*  265 */     if ("double".equals(paramString)) {
/*  266 */       return (Class)DoubleBuffer.class;
/*      */     }
/*  268 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int sizeOfBufferElem(Class<? extends Buffer> paramClass) {
/*  278 */     if (paramClass == null) {
/*  279 */       return 0;
/*      */     }
/*  281 */     if (ByteBuffer.class.isAssignableFrom(paramClass))
/*  282 */       return 1; 
/*  283 */     if (ShortBuffer.class.isAssignableFrom(paramClass))
/*  284 */       return 2; 
/*  285 */     if (CharBuffer.class.isAssignableFrom(paramClass))
/*  286 */       return 2; 
/*  287 */     if (IntBuffer.class.isAssignableFrom(paramClass))
/*  288 */       return 4; 
/*  289 */     if (FloatBuffer.class.isAssignableFrom(paramClass))
/*  290 */       return 4; 
/*  291 */     if (LongBuffer.class.isAssignableFrom(paramClass))
/*  292 */       return 8; 
/*  293 */     if (DoubleBuffer.class.isAssignableFrom(paramClass)) {
/*  294 */       return 8;
/*      */     }
/*  296 */     throw new RuntimeException("Unexpected buffer type " + paramClass.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int sizeOfBufferElem(Object paramObject) {
/*  305 */     if (paramObject == null) {
/*  306 */       return 0;
/*      */     }
/*  308 */     if (paramObject instanceof ByteBuffer)
/*  309 */       return 1; 
/*  310 */     if (paramObject instanceof IntBuffer)
/*  311 */       return 4; 
/*  312 */     if (paramObject instanceof ShortBuffer)
/*  313 */       return 2; 
/*  314 */     if (paramObject instanceof FloatBuffer)
/*  315 */       return 4; 
/*  316 */     if (paramObject instanceof DoubleBuffer)
/*  317 */       return 8; 
/*  318 */     if (paramObject instanceof LongBuffer)
/*  319 */       return 8; 
/*  320 */     if (paramObject instanceof CharBuffer)
/*  321 */       return 2; 
/*  322 */     if (paramObject instanceof NativeBuffer) {
/*  323 */       return ((NativeBuffer)paramObject).elementSize();
/*      */     }
/*  325 */     throw new RuntimeException("Unexpected buffer type " + paramObject.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int remainingElem(Object paramObject) throws IllegalArgumentException {
/*  336 */     if (paramObject == null) {
/*  337 */       return 0;
/*      */     }
/*  339 */     if (paramObject instanceof Buffer)
/*  340 */       return ((Buffer)paramObject).remaining(); 
/*  341 */     if (paramObject instanceof NativeBuffer) {
/*  342 */       return ((NativeBuffer)paramObject).remaining();
/*      */     }
/*  344 */     throw new IllegalArgumentException("Unsupported anonymous buffer type: " + paramObject.getClass().getCanonicalName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int remainingBytes(Object paramObject) throws IllegalArgumentException {
/*      */     int i;
/*  356 */     if (paramObject == null) {
/*  357 */       return 0;
/*      */     }
/*      */     
/*  360 */     if (paramObject instanceof Buffer) {
/*  361 */       int j = ((Buffer)paramObject).remaining();
/*  362 */       if (paramObject instanceof ByteBuffer) {
/*  363 */         i = j;
/*  364 */       } else if (paramObject instanceof FloatBuffer) {
/*  365 */         i = j * 4;
/*  366 */       } else if (paramObject instanceof IntBuffer) {
/*  367 */         i = j * 4;
/*  368 */       } else if (paramObject instanceof ShortBuffer) {
/*  369 */         i = j * 2;
/*  370 */       } else if (paramObject instanceof DoubleBuffer) {
/*  371 */         i = j * 8;
/*  372 */       } else if (paramObject instanceof LongBuffer) {
/*  373 */         i = j * 8;
/*  374 */       } else if (paramObject instanceof CharBuffer) {
/*  375 */         i = j * 2;
/*      */       } else {
/*  377 */         throw new InternalError("Unsupported Buffer type: " + paramObject.getClass().getCanonicalName());
/*      */       } 
/*  379 */     } else if (paramObject instanceof NativeBuffer) {
/*  380 */       NativeBuffer nativeBuffer = (NativeBuffer)paramObject;
/*  381 */       i = nativeBuffer.remaining() * nativeBuffer.elementSize();
/*      */     } else {
/*  383 */       throw new IllegalArgumentException("Unsupported anonymous buffer type: " + paramObject.getClass().getCanonicalName());
/*      */     } 
/*  385 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDirect(Object paramObject) {
/*  393 */     if (paramObject == null) {
/*  394 */       return true;
/*      */     }
/*  396 */     if (paramObject instanceof Buffer)
/*  397 */       return ((Buffer)paramObject).isDirect(); 
/*  398 */     if (paramObject instanceof PointerBuffer) {
/*  399 */       return ((PointerBuffer)paramObject).isDirect();
/*      */     }
/*  401 */     throw new IllegalArgumentException("Unexpected buffer type " + paramObject.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getDirectBufferByteOffset(Object paramObject) {
/*  410 */     if (paramObject == null) {
/*  411 */       return 0;
/*      */     }
/*  413 */     if (paramObject instanceof Buffer) {
/*  414 */       int i = ((Buffer)paramObject).position();
/*  415 */       if (paramObject instanceof ByteBuffer)
/*  416 */         return i; 
/*  417 */       if (paramObject instanceof FloatBuffer)
/*  418 */         return i * 4; 
/*  419 */       if (paramObject instanceof IntBuffer)
/*  420 */         return i * 4; 
/*  421 */       if (paramObject instanceof ShortBuffer)
/*  422 */         return i * 2; 
/*  423 */       if (paramObject instanceof DoubleBuffer)
/*  424 */         return i * 8; 
/*  425 */       if (paramObject instanceof LongBuffer)
/*  426 */         return i * 8; 
/*  427 */       if (paramObject instanceof CharBuffer) {
/*  428 */         return i * 2;
/*      */       }
/*  430 */     } else if (paramObject instanceof NativeBuffer) {
/*  431 */       NativeBuffer nativeBuffer = (NativeBuffer)paramObject;
/*  432 */       return nativeBuffer.position() * nativeBuffer.elementSize();
/*      */     } 
/*      */     
/*  435 */     throw new IllegalArgumentException("Disallowed array backing store type in buffer " + paramObject.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getArray(Object paramObject) throws UnsupportedOperationException, IllegalArgumentException {
/*  445 */     if (paramObject == null) {
/*  446 */       return null;
/*      */     }
/*  448 */     if (paramObject instanceof Buffer)
/*  449 */       return ((Buffer)paramObject).array(); 
/*  450 */     if (paramObject instanceof NativeBuffer) {
/*  451 */       return ((NativeBuffer)paramObject).array();
/*      */     }
/*      */     
/*  454 */     throw new IllegalArgumentException("Disallowed array backing store type in buffer " + paramObject.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getIndirectBufferByteOffset(Object paramObject) {
/*  464 */     if (paramObject == null) {
/*  465 */       return 0;
/*      */     }
/*  467 */     if (paramObject instanceof Buffer) {
/*  468 */       int i = ((Buffer)paramObject).position();
/*  469 */       if (paramObject instanceof ByteBuffer)
/*  470 */         return ((ByteBuffer)paramObject).arrayOffset() + i; 
/*  471 */       if (paramObject instanceof FloatBuffer)
/*  472 */         return 4 * (((FloatBuffer)paramObject).arrayOffset() + i); 
/*  473 */       if (paramObject instanceof IntBuffer)
/*  474 */         return 4 * (((IntBuffer)paramObject).arrayOffset() + i); 
/*  475 */       if (paramObject instanceof ShortBuffer)
/*  476 */         return 2 * (((ShortBuffer)paramObject).arrayOffset() + i); 
/*  477 */       if (paramObject instanceof DoubleBuffer)
/*  478 */         return 8 * (((DoubleBuffer)paramObject).arrayOffset() + i); 
/*  479 */       if (paramObject instanceof LongBuffer)
/*  480 */         return 8 * (((LongBuffer)paramObject).arrayOffset() + i); 
/*  481 */       if (paramObject instanceof CharBuffer) {
/*  482 */         return 2 * (((CharBuffer)paramObject).arrayOffset() + i);
/*      */       }
/*  484 */     } else if (paramObject instanceof NativeBuffer) {
/*  485 */       NativeBuffer nativeBuffer = (NativeBuffer)paramObject;
/*  486 */       return nativeBuffer.elementSize() * (nativeBuffer.arrayOffset() + nativeBuffer.position());
/*      */     } 
/*      */     
/*  489 */     throw new IllegalArgumentException("Unknown buffer type " + paramObject.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B slice(B paramB) {
/*  502 */     if (paramB instanceof ByteBuffer) {
/*  503 */       ByteBuffer byteBuffer = (ByteBuffer)paramB;
/*  504 */       return (B)byteBuffer.slice().order(byteBuffer.order());
/*  505 */     }  if (paramB instanceof IntBuffer)
/*  506 */       return (B)((IntBuffer)paramB).slice(); 
/*  507 */     if (paramB instanceof ShortBuffer)
/*  508 */       return (B)((ShortBuffer)paramB).slice(); 
/*  509 */     if (paramB instanceof FloatBuffer)
/*  510 */       return (B)((FloatBuffer)paramB).slice(); 
/*  511 */     if (paramB instanceof DoubleBuffer)
/*  512 */       return (B)((DoubleBuffer)paramB).slice(); 
/*  513 */     if (paramB instanceof LongBuffer)
/*  514 */       return (B)((LongBuffer)paramB).slice(); 
/*  515 */     if (paramB instanceof CharBuffer) {
/*  516 */       return (B)((CharBuffer)paramB).slice();
/*      */     }
/*  518 */     throw new IllegalArgumentException("unexpected buffer type: " + paramB.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B slice(B paramB, int paramInt1, int paramInt2) {
/*  528 */     int i = paramB.position();
/*  529 */     int j = paramB.limit();
/*      */     
/*  531 */     B b = null;
/*      */     try {
/*  533 */       paramB.position(paramInt1).limit(paramInt1 + paramInt2);
/*  534 */       b = slice((Object)paramB);
/*      */     } finally {
/*  536 */       paramB.position(i).limit(j);
/*      */     } 
/*      */     
/*  539 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final FloatBuffer slice2Float(Buffer paramBuffer, int paramInt1, int paramInt2) {
/*      */     FloatBuffer floatBuffer;
/*  566 */     if (null == paramBuffer) {
/*  567 */       throw new IllegalArgumentException("Buffer is null");
/*      */     }
/*  569 */     int i = paramBuffer.position();
/*  570 */     int j = paramBuffer.limit();
/*      */     
/*      */     try {
/*  573 */       if (paramBuffer instanceof ByteBuffer) {
/*  574 */         ByteBuffer byteBuffer = (ByteBuffer)paramBuffer;
/*  575 */         byteBuffer.position(paramInt1 * 4);
/*  576 */         byteBuffer.limit((paramInt1 + paramInt2) * 4);
/*  577 */         floatBuffer = byteBuffer.slice().order(byteBuffer.order()).asFloatBuffer();
/*  578 */       } else if (paramBuffer instanceof FloatBuffer) {
/*  579 */         FloatBuffer floatBuffer1 = (FloatBuffer)paramBuffer;
/*  580 */         floatBuffer1.position(paramInt1);
/*  581 */         floatBuffer1.limit(paramInt1 + paramInt2);
/*  582 */         floatBuffer = floatBuffer1.slice();
/*      */       } else {
/*  584 */         throw new IllegalArgumentException("Buffer not ByteBuffer, nor FloarBuffer, nor backing array given");
/*      */       } 
/*      */     } finally {
/*  587 */       paramBuffer.position(i).limit(j);
/*      */     } 
/*  589 */     floatBuffer.mark();
/*  590 */     return floatBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final FloatBuffer slice2Float(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
/*  614 */     return (FloatBuffer)FloatBuffer.wrap(paramArrayOffloat, paramInt1, paramInt2).mark();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ShortBuffer slice2Short(Buffer paramBuffer, int paramInt1, int paramInt2) {
/*      */     ShortBuffer shortBuffer;
/*  635 */     if (null == paramBuffer) {
/*  636 */       throw new IllegalArgumentException("Buffer is null");
/*      */     }
/*  638 */     int i = paramBuffer.position();
/*  639 */     int j = paramBuffer.limit();
/*      */     
/*      */     try {
/*  642 */       if (paramBuffer instanceof ByteBuffer) {
/*  643 */         ByteBuffer byteBuffer = (ByteBuffer)paramBuffer;
/*  644 */         byteBuffer.position(paramInt1 * 2);
/*  645 */         byteBuffer.limit((paramInt1 + paramInt2) * 2);
/*  646 */         shortBuffer = byteBuffer.slice().order(byteBuffer.order()).asShortBuffer();
/*  647 */       } else if (paramBuffer instanceof ShortBuffer) {
/*  648 */         ShortBuffer shortBuffer1 = (ShortBuffer)paramBuffer;
/*  649 */         shortBuffer1.position(paramInt1);
/*  650 */         shortBuffer1.limit(paramInt1 + paramInt2);
/*  651 */         shortBuffer = shortBuffer1.slice();
/*      */       } else {
/*  653 */         throw new IllegalArgumentException("Buffer not ByteBuffer, nor ShortBuffer");
/*      */       } 
/*      */     } finally {
/*  656 */       paramBuffer.position(i).limit(j);
/*      */     } 
/*  658 */     shortBuffer.mark();
/*  659 */     return shortBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ShortBuffer slice2Short(short[] paramArrayOfshort, int paramInt1, int paramInt2) {
/*  674 */     return (ShortBuffer)ShortBuffer.wrap(paramArrayOfshort, paramInt1, paramInt2).mark();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final CharBuffer slice2Char(Buffer paramBuffer, int paramInt1, int paramInt2) {
/*      */     CharBuffer charBuffer;
/*  695 */     if (null == paramBuffer) {
/*  696 */       throw new IllegalArgumentException("Buffer is null");
/*      */     }
/*  698 */     int i = paramBuffer.position();
/*  699 */     int j = paramBuffer.limit();
/*      */     
/*      */     try {
/*  702 */       if (paramBuffer instanceof ByteBuffer) {
/*  703 */         ByteBuffer byteBuffer = (ByteBuffer)paramBuffer;
/*  704 */         byteBuffer.position(paramInt1 * 2);
/*  705 */         byteBuffer.limit((paramInt1 + paramInt2) * 2);
/*  706 */         charBuffer = byteBuffer.slice().order(byteBuffer.order()).asCharBuffer();
/*  707 */       } else if (paramBuffer instanceof CharBuffer) {
/*  708 */         CharBuffer charBuffer1 = (CharBuffer)paramBuffer;
/*  709 */         charBuffer1.position(paramInt1);
/*  710 */         charBuffer1.limit(paramInt1 + paramInt2);
/*  711 */         charBuffer = charBuffer1.slice();
/*      */       } else {
/*  713 */         throw new IllegalArgumentException("Buffer not ByteBuffer, nor CharBuffer");
/*      */       } 
/*      */     } finally {
/*  716 */       paramBuffer.position(i).limit(j);
/*      */     } 
/*  718 */     charBuffer.mark();
/*  719 */     return charBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final CharBuffer slice2Char(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
/*  734 */     return (CharBuffer)CharBuffer.wrap(paramArrayOfchar, paramInt1, paramInt2).mark();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final IntBuffer slice2Int(Buffer paramBuffer, int paramInt1, int paramInt2) {
/*      */     IntBuffer intBuffer;
/*  755 */     if (null == paramBuffer) {
/*  756 */       throw new IllegalArgumentException("Buffer is null");
/*      */     }
/*  758 */     int i = paramBuffer.position();
/*  759 */     int j = paramBuffer.limit();
/*      */     
/*      */     try {
/*  762 */       if (paramBuffer instanceof ByteBuffer) {
/*  763 */         ByteBuffer byteBuffer = (ByteBuffer)paramBuffer;
/*  764 */         byteBuffer.position(paramInt1 * 4);
/*  765 */         byteBuffer.limit((paramInt1 + paramInt2) * 4);
/*  766 */         intBuffer = byteBuffer.slice().order(byteBuffer.order()).asIntBuffer();
/*  767 */       } else if (paramBuffer instanceof IntBuffer) {
/*  768 */         IntBuffer intBuffer1 = (IntBuffer)paramBuffer;
/*  769 */         intBuffer1.position(paramInt1);
/*  770 */         intBuffer1.limit(paramInt1 + paramInt2);
/*  771 */         intBuffer = intBuffer1.slice();
/*      */       } else {
/*  773 */         throw new IllegalArgumentException("Buffer not ByteBuffer, nor IntBuffer");
/*      */       } 
/*      */     } finally {
/*  776 */       paramBuffer.position(i).limit(j);
/*      */     } 
/*  778 */     intBuffer.mark();
/*  779 */     return intBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final IntBuffer slice2Int(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/*  794 */     return (IntBuffer)IntBuffer.wrap(paramArrayOfint, paramInt1, paramInt2).mark();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final LongBuffer slice2Long(Buffer paramBuffer, int paramInt1, int paramInt2) {
/*      */     LongBuffer longBuffer;
/*  815 */     if (null == paramBuffer) {
/*  816 */       throw new IllegalArgumentException("Buffer is null");
/*      */     }
/*  818 */     int i = paramBuffer.position();
/*  819 */     int j = paramBuffer.limit();
/*      */     
/*      */     try {
/*  822 */       if (paramBuffer instanceof ByteBuffer) {
/*  823 */         ByteBuffer byteBuffer = (ByteBuffer)paramBuffer;
/*  824 */         byteBuffer.position(paramInt1 * 8);
/*  825 */         byteBuffer.limit((paramInt1 + paramInt2) * 8);
/*  826 */         longBuffer = byteBuffer.slice().order(byteBuffer.order()).asLongBuffer();
/*  827 */       } else if (paramBuffer instanceof LongBuffer) {
/*  828 */         LongBuffer longBuffer1 = (LongBuffer)paramBuffer;
/*  829 */         longBuffer1.position(paramInt1);
/*  830 */         longBuffer1.limit(paramInt1 + paramInt2);
/*  831 */         longBuffer = longBuffer1.slice();
/*      */       } else {
/*  833 */         throw new IllegalArgumentException("Buffer not ByteBuffer, nor LongBuffer");
/*      */       } 
/*      */     } finally {
/*  836 */       paramBuffer.position(i).limit(j);
/*      */     } 
/*  838 */     longBuffer.mark();
/*  839 */     return longBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final LongBuffer slice2Long(long[] paramArrayOflong, int paramInt1, int paramInt2) {
/*  854 */     return (LongBuffer)LongBuffer.wrap(paramArrayOflong, paramInt1, paramInt2).mark();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final DoubleBuffer slice2Double(Buffer paramBuffer, int paramInt1, int paramInt2) {
/*      */     DoubleBuffer doubleBuffer;
/*  875 */     if (null == paramBuffer) {
/*  876 */       throw new IllegalArgumentException("Buffer is null");
/*      */     }
/*  878 */     int i = paramBuffer.position();
/*  879 */     int j = paramBuffer.limit();
/*      */     
/*      */     try {
/*  882 */       if (paramBuffer instanceof ByteBuffer) {
/*  883 */         ByteBuffer byteBuffer = (ByteBuffer)paramBuffer;
/*  884 */         byteBuffer.position(paramInt1 * 8);
/*  885 */         byteBuffer.limit((paramInt1 + paramInt2) * 8);
/*  886 */         doubleBuffer = byteBuffer.slice().order(byteBuffer.order()).asDoubleBuffer();
/*  887 */       } else if (paramBuffer instanceof DoubleBuffer) {
/*  888 */         DoubleBuffer doubleBuffer1 = (DoubleBuffer)paramBuffer;
/*  889 */         doubleBuffer1.position(paramInt1);
/*  890 */         doubleBuffer1.limit(paramInt1 + paramInt2);
/*  891 */         doubleBuffer = doubleBuffer1.slice();
/*      */       } else {
/*  893 */         throw new IllegalArgumentException("Buffer not ByteBuffer, nor DoubleBuffer");
/*      */       } 
/*      */     } finally {
/*  896 */       paramBuffer.position(i).limit(j);
/*      */     } 
/*  898 */     doubleBuffer.mark();
/*  899 */     return doubleBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final DoubleBuffer slice2Double(double[] paramArrayOfdouble, int paramInt1, int paramInt2) {
/*  914 */     return (DoubleBuffer)DoubleBuffer.wrap(paramArrayOfdouble, paramInt1, paramInt2).mark();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer copyByteBuffer(ByteBuffer paramByteBuffer) {
/*  928 */     int i = paramByteBuffer.position();
/*  929 */     ByteBuffer byteBuffer = newDirectByteBuffer(paramByteBuffer.remaining());
/*  930 */     byteBuffer.put(paramByteBuffer);
/*  931 */     byteBuffer.rewind();
/*  932 */     paramByteBuffer.position(i);
/*  933 */     return byteBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBuffer copyFloatBuffer(FloatBuffer paramFloatBuffer) {
/*  945 */     return copyFloatBufferAsByteBuffer(paramFloatBuffer).asFloatBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntBuffer copyIntBuffer(IntBuffer paramIntBuffer) {
/*  957 */     return copyIntBufferAsByteBuffer(paramIntBuffer).asIntBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ShortBuffer copyShortBuffer(ShortBuffer paramShortBuffer) {
/*  969 */     return copyShortBufferAsByteBuffer(paramShortBuffer).asShortBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer copyFloatBufferAsByteBuffer(FloatBuffer paramFloatBuffer) {
/*  984 */     int i = paramFloatBuffer.position();
/*  985 */     ByteBuffer byteBuffer = newDirectByteBuffer(paramFloatBuffer.remaining() * 4);
/*  986 */     byteBuffer.asFloatBuffer().put(paramFloatBuffer);
/*  987 */     byteBuffer.rewind();
/*  988 */     paramFloatBuffer.position(i);
/*  989 */     return byteBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer copyIntBufferAsByteBuffer(IntBuffer paramIntBuffer) {
/* 1001 */     int i = paramIntBuffer.position();
/* 1002 */     ByteBuffer byteBuffer = newDirectByteBuffer(paramIntBuffer.remaining() * 4);
/* 1003 */     byteBuffer.asIntBuffer().put(paramIntBuffer);
/* 1004 */     byteBuffer.rewind();
/* 1005 */     paramIntBuffer.position(i);
/* 1006 */     return byteBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer copyShortBufferAsByteBuffer(ShortBuffer paramShortBuffer) {
/* 1018 */     int i = paramShortBuffer.position();
/* 1019 */     ByteBuffer byteBuffer = newDirectByteBuffer(paramShortBuffer.remaining() * 2);
/* 1020 */     byteBuffer.asShortBuffer().put(paramShortBuffer);
/* 1021 */     byteBuffer.rewind();
/* 1022 */     paramShortBuffer.position(i);
/* 1023 */     return byteBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] getFloatArray(double[] paramArrayOfdouble, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
/* 1039 */     if (0 > paramInt3) {
/* 1040 */       paramInt3 = paramArrayOfdouble.length - paramInt1;
/*      */     }
/* 1042 */     if (paramInt3 > paramArrayOfdouble.length - paramInt1) {
/* 1043 */       throw new IllegalArgumentException("payload (" + paramInt3 + ") greater than remaining source bytes [len " + paramArrayOfdouble.length + ", offset " + paramInt1 + "]");
/*      */     }
/* 1045 */     if (null == paramArrayOffloat) {
/* 1046 */       paramArrayOffloat = new float[paramInt3];
/* 1047 */       paramInt2 = 0;
/*      */     } 
/* 1049 */     if (paramInt3 > paramArrayOffloat.length - paramInt2) {
/* 1050 */       throw new IllegalArgumentException("payload (" + paramInt3 + ") greater than remaining dest bytes [len " + paramArrayOffloat.length + ", offset " + paramInt2 + "]");
/*      */     }
/* 1052 */     for (byte b = 0; b < paramInt3; b++) {
/* 1053 */       paramArrayOffloat[paramInt2 + b] = (float)paramArrayOfdouble[paramInt1 + b];
/*      */     }
/* 1055 */     return paramArrayOffloat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBuffer getFloatBuffer(DoubleBuffer paramDoubleBuffer, FloatBuffer paramFloatBuffer) {
/* 1065 */     if (null == paramFloatBuffer) {
/* 1066 */       paramFloatBuffer = newDirectFloatBuffer(paramDoubleBuffer.remaining());
/*      */     }
/* 1068 */     if (paramFloatBuffer.remaining() < paramDoubleBuffer.remaining()) {
/* 1069 */       throw new IllegalArgumentException("payload (" + paramDoubleBuffer.remaining() + ") is greater than remaining dest bytes: " + paramFloatBuffer.remaining());
/*      */     }
/* 1071 */     while (paramDoubleBuffer.hasRemaining()) {
/* 1072 */       paramFloatBuffer.put((float)paramDoubleBuffer.get());
/*      */     }
/* 1074 */     return paramFloatBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] getDoubleArray(float[] paramArrayOffloat, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3) {
/* 1086 */     if (0 > paramInt3) {
/* 1087 */       paramInt3 = paramArrayOffloat.length - paramInt1;
/*      */     }
/* 1089 */     if (paramInt3 > paramArrayOffloat.length - paramInt1) {
/* 1090 */       throw new IllegalArgumentException("payload (" + paramInt3 + ") greater than remaining source bytes [len " + paramArrayOffloat.length + ", offset " + paramInt1 + "]");
/*      */     }
/* 1092 */     if (null == paramArrayOfdouble) {
/* 1093 */       paramArrayOfdouble = new double[paramInt3];
/* 1094 */       paramInt2 = 0;
/*      */     } 
/* 1096 */     if (paramInt3 > paramArrayOfdouble.length - paramInt2) {
/* 1097 */       throw new IllegalArgumentException("payload (" + paramInt3 + ") greater than remaining dest bytes [len " + paramArrayOfdouble.length + ", offset " + paramInt2 + "]");
/*      */     }
/* 1099 */     for (byte b = 0; b < paramInt3; b++) {
/* 1100 */       paramArrayOfdouble[paramInt2 + b] = paramArrayOffloat[paramInt1 + b];
/*      */     }
/* 1102 */     return paramArrayOfdouble;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBuffer getDoubleBuffer(FloatBuffer paramFloatBuffer, DoubleBuffer paramDoubleBuffer) {
/* 1112 */     if (null == paramDoubleBuffer) {
/* 1113 */       paramDoubleBuffer = newDirectDoubleBuffer(paramFloatBuffer.remaining());
/*      */     }
/* 1115 */     if (paramDoubleBuffer.remaining() < paramFloatBuffer.remaining()) {
/* 1116 */       throw new IllegalArgumentException("payload (" + paramFloatBuffer.remaining() + ") is greater than remaining dest bytes: " + paramDoubleBuffer.remaining());
/*      */     }
/* 1118 */     while (paramFloatBuffer.hasRemaining()) {
/* 1119 */       paramDoubleBuffer.put(paramFloatBuffer.get());
/*      */     }
/* 1121 */     return paramDoubleBuffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put(B paramB, Buffer paramBuffer) {
/* 1131 */     if (paramB instanceof ByteBuffer && paramBuffer instanceof ByteBuffer)
/* 1132 */       return (B)((ByteBuffer)paramB).put((ByteBuffer)paramBuffer); 
/* 1133 */     if (paramB instanceof ShortBuffer && paramBuffer instanceof ShortBuffer)
/* 1134 */       return (B)((ShortBuffer)paramB).put((ShortBuffer)paramBuffer); 
/* 1135 */     if (paramB instanceof IntBuffer && paramBuffer instanceof IntBuffer)
/* 1136 */       return (B)((IntBuffer)paramB).put((IntBuffer)paramBuffer); 
/* 1137 */     if (paramB instanceof FloatBuffer && paramBuffer instanceof FloatBuffer)
/* 1138 */       return (B)((FloatBuffer)paramB).put((FloatBuffer)paramBuffer); 
/* 1139 */     if (paramB instanceof LongBuffer && paramBuffer instanceof LongBuffer)
/* 1140 */       return (B)((LongBuffer)paramB).put((LongBuffer)paramBuffer); 
/* 1141 */     if (paramB instanceof DoubleBuffer && paramBuffer instanceof DoubleBuffer)
/* 1142 */       return (B)((DoubleBuffer)paramB).put((DoubleBuffer)paramBuffer); 
/* 1143 */     if (paramB instanceof CharBuffer && paramBuffer instanceof CharBuffer) {
/* 1144 */       return (B)((CharBuffer)paramB).put((CharBuffer)paramBuffer);
/*      */     }
/* 1146 */     throw new IllegalArgumentException("Incompatible Buffer classes: dest = " + paramB.getClass().getName() + ", src = " + paramBuffer.getClass().getName());
/*      */   }
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putb(B paramB, byte paramByte) {
/* 1151 */     if (paramB instanceof ByteBuffer)
/* 1152 */       return (B)((ByteBuffer)paramB).put(paramByte); 
/* 1153 */     if (paramB instanceof ShortBuffer)
/* 1154 */       return (B)((ShortBuffer)paramB).put((short)paramByte); 
/* 1155 */     if (paramB instanceof IntBuffer)
/* 1156 */       return (B)((IntBuffer)paramB).put(paramByte); 
/* 1157 */     if (paramB instanceof FloatBuffer)
/* 1158 */       return (B)((FloatBuffer)paramB).put(paramByte); 
/* 1159 */     if (paramB instanceof LongBuffer)
/* 1160 */       return (B)((LongBuffer)paramB).put(paramByte); 
/* 1161 */     if (paramB instanceof DoubleBuffer)
/* 1162 */       return (B)((DoubleBuffer)paramB).put(paramByte); 
/* 1163 */     if (paramB instanceof CharBuffer) {
/* 1164 */       return (B)((CharBuffer)paramB).put((char)paramByte);
/*      */     }
/* 1166 */     throw new IllegalArgumentException("Byte doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put3b(B paramB, byte paramByte1, byte paramByte2, byte paramByte3) {
/* 1172 */     if (paramB instanceof ByteBuffer) {
/* 1173 */       ByteBuffer byteBuffer = (ByteBuffer)paramB;
/* 1174 */       byteBuffer.put(paramByte1);
/* 1175 */       byteBuffer.put(paramByte2);
/* 1176 */       byteBuffer.put(paramByte3);
/* 1177 */       return (B)byteBuffer;
/* 1178 */     }  if (paramB instanceof ShortBuffer) {
/* 1179 */       ShortBuffer shortBuffer = (ShortBuffer)paramB;
/* 1180 */       shortBuffer.put((short)paramByte1);
/* 1181 */       shortBuffer.put((short)paramByte2);
/* 1182 */       shortBuffer.put((short)paramByte3);
/* 1183 */       return (B)shortBuffer;
/* 1184 */     }  if (paramB instanceof IntBuffer) {
/* 1185 */       IntBuffer intBuffer = (IntBuffer)paramB;
/* 1186 */       intBuffer.put(paramByte1);
/* 1187 */       intBuffer.put(paramByte2);
/* 1188 */       intBuffer.put(paramByte3);
/* 1189 */       return (B)intBuffer;
/* 1190 */     }  if (paramB instanceof FloatBuffer) {
/* 1191 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1192 */       floatBuffer.put(paramByte1);
/* 1193 */       floatBuffer.put(paramByte2);
/* 1194 */       floatBuffer.put(paramByte3);
/* 1195 */       return (B)floatBuffer;
/* 1196 */     }  if (paramB instanceof LongBuffer) {
/* 1197 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1198 */       longBuffer.put(paramByte1);
/* 1199 */       longBuffer.put(paramByte2);
/* 1200 */       longBuffer.put(paramByte3);
/* 1201 */       return (B)longBuffer;
/* 1202 */     }  if (paramB instanceof DoubleBuffer) {
/* 1203 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1204 */       doubleBuffer.put(paramByte1);
/* 1205 */       doubleBuffer.put(paramByte2);
/* 1206 */       doubleBuffer.put(paramByte3);
/* 1207 */       return (B)doubleBuffer;
/* 1208 */     }  if (paramB instanceof CharBuffer) {
/* 1209 */       CharBuffer charBuffer = (CharBuffer)paramB;
/* 1210 */       charBuffer.put((char)paramByte1);
/* 1211 */       charBuffer.put((char)paramByte2);
/* 1212 */       charBuffer.put((char)paramByte3);
/* 1213 */       return (B)charBuffer;
/*      */     } 
/* 1215 */     throw new IllegalArgumentException("Byte doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put4b(B paramB, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4) {
/* 1221 */     if (paramB instanceof ByteBuffer) {
/* 1222 */       ByteBuffer byteBuffer = (ByteBuffer)paramB;
/* 1223 */       byteBuffer.put(paramByte1);
/* 1224 */       byteBuffer.put(paramByte2);
/* 1225 */       byteBuffer.put(paramByte3);
/* 1226 */       byteBuffer.put(paramByte4);
/* 1227 */       return (B)byteBuffer;
/* 1228 */     }  if (paramB instanceof ShortBuffer) {
/* 1229 */       ShortBuffer shortBuffer = (ShortBuffer)paramB;
/* 1230 */       shortBuffer.put((short)paramByte1);
/* 1231 */       shortBuffer.put((short)paramByte2);
/* 1232 */       shortBuffer.put((short)paramByte3);
/* 1233 */       shortBuffer.put((short)paramByte4);
/* 1234 */       return (B)shortBuffer;
/* 1235 */     }  if (paramB instanceof IntBuffer) {
/* 1236 */       IntBuffer intBuffer = (IntBuffer)paramB;
/* 1237 */       intBuffer.put(paramByte1);
/* 1238 */       intBuffer.put(paramByte2);
/* 1239 */       intBuffer.put(paramByte3);
/* 1240 */       intBuffer.put(paramByte4);
/* 1241 */       return (B)intBuffer;
/* 1242 */     }  if (paramB instanceof FloatBuffer) {
/* 1243 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1244 */       floatBuffer.put(paramByte1);
/* 1245 */       floatBuffer.put(paramByte2);
/* 1246 */       floatBuffer.put(paramByte3);
/* 1247 */       floatBuffer.put(paramByte4);
/* 1248 */       return (B)floatBuffer;
/* 1249 */     }  if (paramB instanceof LongBuffer) {
/* 1250 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1251 */       longBuffer.put(paramByte1);
/* 1252 */       longBuffer.put(paramByte2);
/* 1253 */       longBuffer.put(paramByte3);
/* 1254 */       longBuffer.put(paramByte4);
/* 1255 */       return (B)longBuffer;
/* 1256 */     }  if (paramB instanceof DoubleBuffer) {
/* 1257 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1258 */       doubleBuffer.put(paramByte1);
/* 1259 */       doubleBuffer.put(paramByte2);
/* 1260 */       doubleBuffer.put(paramByte3);
/* 1261 */       doubleBuffer.put(paramByte4);
/* 1262 */       return (B)doubleBuffer;
/* 1263 */     }  if (paramB instanceof CharBuffer) {
/* 1264 */       CharBuffer charBuffer = (CharBuffer)paramB;
/* 1265 */       charBuffer.put((char)paramByte1);
/* 1266 */       charBuffer.put((char)paramByte2);
/* 1267 */       charBuffer.put((char)paramByte3);
/* 1268 */       charBuffer.put((char)paramByte4);
/* 1269 */       return (B)charBuffer;
/*      */     } 
/* 1271 */     throw new IllegalArgumentException("Byte doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putb(B paramB, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 1277 */     if (paramB instanceof ByteBuffer)
/* 1278 */       return (B)((ByteBuffer)paramB).put(paramArrayOfbyte, paramInt1, paramInt2); 
/* 1279 */     if (paramB instanceof ShortBuffer) {
/* 1280 */       ShortBuffer shortBuffer = (ShortBuffer)paramB;
/* 1281 */       for (byte b = 0; b < paramInt2; b++) {
/* 1282 */         shortBuffer.put((short)paramArrayOfbyte[paramInt1 + b]);
/*      */       }
/* 1284 */       return (B)shortBuffer;
/* 1285 */     }  if (paramB instanceof IntBuffer) {
/* 1286 */       IntBuffer intBuffer = (IntBuffer)paramB;
/* 1287 */       for (byte b = 0; b < paramInt2; b++) {
/* 1288 */         intBuffer.put(paramArrayOfbyte[paramInt1 + b]);
/*      */       }
/* 1290 */       return (B)intBuffer;
/* 1291 */     }  if (paramB instanceof FloatBuffer) {
/* 1292 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1293 */       for (byte b = 0; b < paramInt2; b++) {
/* 1294 */         floatBuffer.put(paramArrayOfbyte[paramInt1 + b]);
/*      */       }
/* 1296 */       return (B)floatBuffer;
/* 1297 */     }  if (paramB instanceof LongBuffer) {
/* 1298 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1299 */       for (byte b = 0; b < paramInt2; b++) {
/* 1300 */         longBuffer.put(paramArrayOfbyte[paramInt1 + b]);
/*      */       }
/* 1302 */       return (B)longBuffer;
/* 1303 */     }  if (paramB instanceof DoubleBuffer) {
/* 1304 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1305 */       for (byte b = 0; b < paramInt2; b++) {
/* 1306 */         doubleBuffer.put(paramArrayOfbyte[paramInt1 + b]);
/*      */       }
/* 1308 */       return (B)doubleBuffer;
/* 1309 */     }  if (paramB instanceof CharBuffer) {
/* 1310 */       CharBuffer charBuffer = (CharBuffer)paramB;
/* 1311 */       for (byte b = 0; b < paramInt2; b++) {
/* 1312 */         charBuffer.put((char)paramArrayOfbyte[paramInt1 + b]);
/*      */       }
/* 1314 */       return (B)charBuffer;
/*      */     } 
/* 1316 */     throw new IllegalArgumentException("Byte doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B puts(B paramB, short paramShort) {
/* 1322 */     if (paramB instanceof ShortBuffer)
/* 1323 */       return (B)((ShortBuffer)paramB).put(paramShort); 
/* 1324 */     if (paramB instanceof IntBuffer)
/* 1325 */       return (B)((IntBuffer)paramB).put(paramShort); 
/* 1326 */     if (paramB instanceof FloatBuffer)
/* 1327 */       return (B)((FloatBuffer)paramB).put(paramShort); 
/* 1328 */     if (paramB instanceof LongBuffer)
/* 1329 */       return (B)((LongBuffer)paramB).put(paramShort); 
/* 1330 */     if (paramB instanceof DoubleBuffer) {
/* 1331 */       return (B)((DoubleBuffer)paramB).put(paramShort);
/*      */     }
/* 1333 */     throw new IllegalArgumentException("Short doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put3s(B paramB, short paramShort1, short paramShort2, short paramShort3) {
/* 1339 */     if (paramB instanceof ShortBuffer) {
/* 1340 */       ShortBuffer shortBuffer = (ShortBuffer)paramB;
/* 1341 */       shortBuffer.put(paramShort1);
/* 1342 */       shortBuffer.put(paramShort2);
/* 1343 */       shortBuffer.put(paramShort3);
/* 1344 */       return (B)shortBuffer;
/* 1345 */     }  if (paramB instanceof IntBuffer) {
/* 1346 */       IntBuffer intBuffer = (IntBuffer)paramB;
/* 1347 */       intBuffer.put(paramShort1);
/* 1348 */       intBuffer.put(paramShort2);
/* 1349 */       intBuffer.put(paramShort3);
/* 1350 */       return (B)intBuffer;
/* 1351 */     }  if (paramB instanceof FloatBuffer) {
/* 1352 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1353 */       floatBuffer.put(paramShort1);
/* 1354 */       floatBuffer.put(paramShort2);
/* 1355 */       floatBuffer.put(paramShort3);
/* 1356 */       return (B)floatBuffer;
/* 1357 */     }  if (paramB instanceof LongBuffer) {
/* 1358 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1359 */       longBuffer.put(paramShort1);
/* 1360 */       longBuffer.put(paramShort2);
/* 1361 */       longBuffer.put(paramShort3);
/* 1362 */       return (B)longBuffer;
/* 1363 */     }  if (paramB instanceof DoubleBuffer) {
/* 1364 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1365 */       doubleBuffer.put(paramShort1);
/* 1366 */       doubleBuffer.put(paramShort2);
/* 1367 */       doubleBuffer.put(paramShort3);
/* 1368 */       return (B)doubleBuffer;
/*      */     } 
/* 1370 */     throw new IllegalArgumentException("Short doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put4s(B paramB, short paramShort1, short paramShort2, short paramShort3, short paramShort4) {
/* 1376 */     if (paramB instanceof ShortBuffer) {
/* 1377 */       ShortBuffer shortBuffer = (ShortBuffer)paramB;
/* 1378 */       shortBuffer.put(paramShort1);
/* 1379 */       shortBuffer.put(paramShort2);
/* 1380 */       shortBuffer.put(paramShort3);
/* 1381 */       shortBuffer.put(paramShort4);
/* 1382 */       return (B)shortBuffer;
/* 1383 */     }  if (paramB instanceof IntBuffer) {
/* 1384 */       IntBuffer intBuffer = (IntBuffer)paramB;
/* 1385 */       intBuffer.put(paramShort1);
/* 1386 */       intBuffer.put(paramShort2);
/* 1387 */       intBuffer.put(paramShort3);
/* 1388 */       intBuffer.put(paramShort4);
/* 1389 */       return (B)intBuffer;
/* 1390 */     }  if (paramB instanceof FloatBuffer) {
/* 1391 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1392 */       floatBuffer.put(paramShort1);
/* 1393 */       floatBuffer.put(paramShort2);
/* 1394 */       floatBuffer.put(paramShort3);
/* 1395 */       floatBuffer.put(paramShort4);
/* 1396 */       return (B)floatBuffer;
/* 1397 */     }  if (paramB instanceof LongBuffer) {
/* 1398 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1399 */       longBuffer.put(paramShort1);
/* 1400 */       longBuffer.put(paramShort2);
/* 1401 */       longBuffer.put(paramShort3);
/* 1402 */       longBuffer.put(paramShort4);
/* 1403 */       return (B)longBuffer;
/* 1404 */     }  if (paramB instanceof DoubleBuffer) {
/* 1405 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1406 */       doubleBuffer.put(paramShort1);
/* 1407 */       doubleBuffer.put(paramShort2);
/* 1408 */       doubleBuffer.put(paramShort3);
/* 1409 */       doubleBuffer.put(paramShort4);
/* 1410 */       return (B)doubleBuffer;
/*      */     } 
/* 1412 */     throw new IllegalArgumentException("Short doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B puts(B paramB, short[] paramArrayOfshort, int paramInt1, int paramInt2) {
/* 1418 */     if (paramB instanceof ShortBuffer)
/* 1419 */       return (B)((ShortBuffer)paramB).put(paramArrayOfshort, paramInt1, paramInt2); 
/* 1420 */     if (paramB instanceof IntBuffer) {
/* 1421 */       IntBuffer intBuffer = (IntBuffer)paramB;
/* 1422 */       for (byte b = 0; b < paramInt2; b++) {
/* 1423 */         intBuffer.put(paramArrayOfshort[paramInt1 + b]);
/*      */       }
/* 1425 */       return (B)intBuffer;
/* 1426 */     }  if (paramB instanceof FloatBuffer) {
/* 1427 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1428 */       for (byte b = 0; b < paramInt2; b++) {
/* 1429 */         floatBuffer.put(paramArrayOfshort[paramInt1 + b]);
/*      */       }
/* 1431 */       return (B)floatBuffer;
/* 1432 */     }  if (paramB instanceof LongBuffer) {
/* 1433 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1434 */       for (byte b = 0; b < paramInt2; b++) {
/* 1435 */         longBuffer.put(paramArrayOfshort[paramInt1 + b]);
/*      */       }
/* 1437 */       return (B)longBuffer;
/* 1438 */     }  if (paramB instanceof DoubleBuffer) {
/* 1439 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1440 */       for (byte b = 0; b < paramInt2; b++) {
/* 1441 */         doubleBuffer.put(paramArrayOfshort[paramInt1 + b]);
/*      */       }
/* 1443 */       return (B)doubleBuffer;
/*      */     } 
/* 1445 */     throw new IllegalArgumentException("Short doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B puti(B paramB, int paramInt) {
/* 1451 */     if (paramB instanceof IntBuffer)
/* 1452 */       return (B)((IntBuffer)paramB).put(paramInt); 
/* 1453 */     if (paramB instanceof FloatBuffer)
/* 1454 */       return (B)((FloatBuffer)paramB).put(paramInt); 
/* 1455 */     if (paramB instanceof LongBuffer)
/* 1456 */       return (B)((LongBuffer)paramB).put(paramInt); 
/* 1457 */     if (paramB instanceof DoubleBuffer) {
/* 1458 */       return (B)((DoubleBuffer)paramB).put(paramInt);
/*      */     }
/* 1460 */     throw new IllegalArgumentException("Integer doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put3i(B paramB, int paramInt1, int paramInt2, int paramInt3) {
/* 1466 */     if (paramB instanceof IntBuffer) {
/* 1467 */       IntBuffer intBuffer = (IntBuffer)paramB;
/* 1468 */       intBuffer.put(paramInt1);
/* 1469 */       intBuffer.put(paramInt2);
/* 1470 */       intBuffer.put(paramInt3);
/* 1471 */       return (B)intBuffer;
/* 1472 */     }  if (paramB instanceof FloatBuffer) {
/* 1473 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1474 */       floatBuffer.put(paramInt1);
/* 1475 */       floatBuffer.put(paramInt2);
/* 1476 */       floatBuffer.put(paramInt3);
/* 1477 */       return (B)floatBuffer;
/* 1478 */     }  if (paramB instanceof LongBuffer) {
/* 1479 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1480 */       longBuffer.put(paramInt1);
/* 1481 */       longBuffer.put(paramInt2);
/* 1482 */       longBuffer.put(paramInt3);
/* 1483 */       return (B)longBuffer;
/* 1484 */     }  if (paramB instanceof DoubleBuffer) {
/* 1485 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1486 */       doubleBuffer.put(paramInt1);
/* 1487 */       doubleBuffer.put(paramInt2);
/* 1488 */       doubleBuffer.put(paramInt3);
/* 1489 */       return (B)doubleBuffer;
/*      */     } 
/* 1491 */     throw new IllegalArgumentException("Integer doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put4i(B paramB, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1497 */     if (paramB instanceof IntBuffer) {
/* 1498 */       IntBuffer intBuffer = (IntBuffer)paramB;
/* 1499 */       intBuffer.put(paramInt1);
/* 1500 */       intBuffer.put(paramInt2);
/* 1501 */       intBuffer.put(paramInt3);
/* 1502 */       intBuffer.put(paramInt4);
/* 1503 */       return (B)intBuffer;
/* 1504 */     }  if (paramB instanceof FloatBuffer) {
/* 1505 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1506 */       floatBuffer.put(paramInt1);
/* 1507 */       floatBuffer.put(paramInt2);
/* 1508 */       floatBuffer.put(paramInt3);
/* 1509 */       floatBuffer.put(paramInt4);
/* 1510 */       return (B)floatBuffer;
/* 1511 */     }  if (paramB instanceof LongBuffer) {
/* 1512 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1513 */       longBuffer.put(paramInt1);
/* 1514 */       longBuffer.put(paramInt2);
/* 1515 */       longBuffer.put(paramInt3);
/* 1516 */       longBuffer.put(paramInt4);
/* 1517 */       return (B)longBuffer;
/* 1518 */     }  if (paramB instanceof DoubleBuffer) {
/* 1519 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1520 */       doubleBuffer.put(paramInt1);
/* 1521 */       doubleBuffer.put(paramInt2);
/* 1522 */       doubleBuffer.put(paramInt3);
/* 1523 */       doubleBuffer.put(paramInt4);
/* 1524 */       return (B)doubleBuffer;
/*      */     } 
/* 1526 */     throw new IllegalArgumentException("Integer doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B puti(B paramB, int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 1532 */     if (paramB instanceof IntBuffer)
/* 1533 */       return (B)((IntBuffer)paramB).put(paramArrayOfint, paramInt1, paramInt2); 
/* 1534 */     if (paramB instanceof FloatBuffer) {
/* 1535 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1536 */       for (byte b = 0; b < paramInt2; b++) {
/* 1537 */         floatBuffer.put(paramArrayOfint[paramInt1 + b]);
/*      */       }
/* 1539 */       return (B)floatBuffer;
/* 1540 */     }  if (paramB instanceof LongBuffer) {
/* 1541 */       LongBuffer longBuffer = (LongBuffer)paramB;
/* 1542 */       for (byte b = 0; b < paramInt2; b++) {
/* 1543 */         longBuffer.put(paramArrayOfint[paramInt1 + b]);
/*      */       }
/* 1545 */       return (B)longBuffer;
/* 1546 */     }  if (paramB instanceof DoubleBuffer) {
/* 1547 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1548 */       for (byte b = 0; b < paramInt2; b++) {
/* 1549 */         doubleBuffer.put(paramArrayOfint[paramInt1 + b]);
/*      */       }
/* 1551 */       return (B)doubleBuffer;
/*      */     } 
/* 1553 */     throw new IllegalArgumentException("Integer doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putf(B paramB, float paramFloat) {
/* 1559 */     if (paramB instanceof FloatBuffer)
/* 1560 */       return (B)((FloatBuffer)paramB).put(paramFloat); 
/* 1561 */     if (paramB instanceof DoubleBuffer) {
/* 1562 */       return (B)((DoubleBuffer)paramB).put(paramFloat);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1568 */     throw new IllegalArgumentException("Float doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put3f(B paramB, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1574 */     if (paramB instanceof FloatBuffer) {
/* 1575 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1576 */       floatBuffer.put(paramFloat1);
/* 1577 */       floatBuffer.put(paramFloat2);
/* 1578 */       floatBuffer.put(paramFloat3);
/* 1579 */       return (B)floatBuffer;
/* 1580 */     }  if (paramB instanceof DoubleBuffer) {
/* 1581 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1582 */       doubleBuffer.put(paramFloat1);
/* 1583 */       doubleBuffer.put(paramFloat2);
/* 1584 */       doubleBuffer.put(paramFloat3);
/* 1585 */       return (B)doubleBuffer;
/*      */     } 
/* 1587 */     throw new IllegalArgumentException("Float doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put4f(B paramB, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 1593 */     if (paramB instanceof FloatBuffer) {
/* 1594 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1595 */       floatBuffer.put(paramFloat1);
/* 1596 */       floatBuffer.put(paramFloat2);
/* 1597 */       floatBuffer.put(paramFloat3);
/* 1598 */       floatBuffer.put(paramFloat4);
/* 1599 */       return (B)floatBuffer;
/* 1600 */     }  if (paramB instanceof DoubleBuffer) {
/* 1601 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1602 */       doubleBuffer.put(paramFloat1);
/* 1603 */       doubleBuffer.put(paramFloat2);
/* 1604 */       doubleBuffer.put(paramFloat3);
/* 1605 */       doubleBuffer.put(paramFloat4);
/* 1606 */       return (B)doubleBuffer;
/*      */     } 
/* 1608 */     throw new IllegalArgumentException("Float doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putf(B paramB, float[] paramArrayOffloat, int paramInt1, int paramInt2) {
/* 1614 */     if (paramB instanceof FloatBuffer)
/* 1615 */       return (B)((FloatBuffer)paramB).put(paramArrayOffloat, paramInt1, paramInt2); 
/* 1616 */     if (paramB instanceof DoubleBuffer) {
/* 1617 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1618 */       for (byte b = 0; b < paramInt2; b++) {
/* 1619 */         doubleBuffer.put(paramArrayOffloat[paramInt1 + b]);
/*      */       }
/* 1621 */       return (B)doubleBuffer;
/*      */     } 
/* 1623 */     throw new IllegalArgumentException("Float doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putd(B paramB, double paramDouble) {
/* 1629 */     if (paramB instanceof DoubleBuffer)
/* 1630 */       return (B)((DoubleBuffer)paramB).put(paramDouble); 
/* 1631 */     if (paramB instanceof FloatBuffer) {
/* 1632 */       return (B)((FloatBuffer)paramB).put((float)paramDouble);
/*      */     }
/* 1634 */     throw new IllegalArgumentException("Double doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put3d(B paramB, double paramDouble1, double paramDouble2, double paramDouble3) {
/* 1640 */     if (paramB instanceof DoubleBuffer) {
/* 1641 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1642 */       doubleBuffer.put(paramDouble1);
/* 1643 */       doubleBuffer.put(paramDouble2);
/* 1644 */       doubleBuffer.put(paramDouble3);
/* 1645 */       return (B)doubleBuffer;
/* 1646 */     }  if (paramB instanceof FloatBuffer) {
/* 1647 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1648 */       floatBuffer.put((float)paramDouble1);
/* 1649 */       floatBuffer.put((float)paramDouble2);
/* 1650 */       floatBuffer.put((float)paramDouble3);
/* 1651 */       return (B)floatBuffer;
/*      */     } 
/* 1653 */     throw new IllegalArgumentException("Double doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B put4d(B paramB, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 1659 */     if (paramB instanceof DoubleBuffer) {
/* 1660 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramB;
/* 1661 */       doubleBuffer.put(paramDouble1);
/* 1662 */       doubleBuffer.put(paramDouble2);
/* 1663 */       doubleBuffer.put(paramDouble3);
/* 1664 */       doubleBuffer.put(paramDouble4);
/* 1665 */       return (B)doubleBuffer;
/* 1666 */     }  if (paramB instanceof FloatBuffer) {
/* 1667 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1668 */       floatBuffer.put((float)paramDouble1);
/* 1669 */       floatBuffer.put((float)paramDouble2);
/* 1670 */       floatBuffer.put((float)paramDouble3);
/* 1671 */       floatBuffer.put((float)paramDouble4);
/* 1672 */       return (B)floatBuffer;
/*      */     } 
/* 1674 */     throw new IllegalArgumentException("Double doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putd(B paramB, double[] paramArrayOfdouble, int paramInt1, int paramInt2) {
/* 1680 */     if (paramB instanceof DoubleBuffer)
/* 1681 */       return (B)((DoubleBuffer)paramB).put(paramArrayOfdouble, paramInt1, paramInt2); 
/* 1682 */     if (paramB instanceof FloatBuffer) {
/* 1683 */       FloatBuffer floatBuffer = (FloatBuffer)paramB;
/* 1684 */       for (byte b = 0; b < paramInt2; b++) {
/* 1685 */         floatBuffer.put((float)paramArrayOfdouble[paramInt1 + b]);
/*      */       }
/* 1687 */       return (B)floatBuffer;
/*      */     } 
/* 1689 */     throw new IllegalArgumentException("Float doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putNb(B paramB, boolean paramBoolean1, byte paramByte, boolean paramBoolean2) {
/* 1708 */     if (paramB instanceof ByteBuffer)
/* 1709 */       return (B)((ByteBuffer)paramB).put(paramByte); 
/* 1710 */     if (paramB instanceof ShortBuffer)
/* 1711 */       return (B)((ShortBuffer)paramB).put(ValueConv.byte_to_short(paramByte, paramBoolean2, paramBoolean1)); 
/* 1712 */     if (paramB instanceof IntBuffer)
/* 1713 */       return (B)((IntBuffer)paramB).put(ValueConv.byte_to_int(paramByte, paramBoolean2, paramBoolean1)); 
/* 1714 */     if (paramB instanceof FloatBuffer) {
/* 1715 */       return (B)((FloatBuffer)paramB).put(ValueConv.byte_to_float(paramByte, paramBoolean2));
/*      */     }
/* 1717 */     throw new IllegalArgumentException("Byte doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putNs(B paramB, boolean paramBoolean1, short paramShort, boolean paramBoolean2) {
/* 1732 */     if (paramB instanceof ByteBuffer)
/* 1733 */       return (B)((ByteBuffer)paramB).put(ValueConv.short_to_byte(paramShort, paramBoolean2, paramBoolean1)); 
/* 1734 */     if (paramB instanceof ShortBuffer)
/* 1735 */       return (B)((ShortBuffer)paramB).put(paramShort); 
/* 1736 */     if (paramB instanceof IntBuffer)
/* 1737 */       return (B)((IntBuffer)paramB).put(ValueConv.short_to_int(paramShort, paramBoolean2, paramBoolean1)); 
/* 1738 */     if (paramB instanceof FloatBuffer) {
/* 1739 */       return (B)((FloatBuffer)paramB).put(ValueConv.short_to_float(paramShort, paramBoolean2));
/*      */     }
/* 1741 */     throw new IllegalArgumentException("Byte doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putNi(B paramB, boolean paramBoolean1, int paramInt, boolean paramBoolean2) {
/* 1756 */     if (paramB instanceof ByteBuffer)
/* 1757 */       return (B)((ByteBuffer)paramB).put(ValueConv.int_to_byte(paramInt, paramBoolean2, paramBoolean1)); 
/* 1758 */     if (paramB instanceof ShortBuffer)
/* 1759 */       return (B)((ShortBuffer)paramB).put(ValueConv.int_to_short(paramInt, paramBoolean2, paramBoolean1)); 
/* 1760 */     if (paramB instanceof IntBuffer)
/* 1761 */       return (B)((IntBuffer)paramB).put(paramInt); 
/* 1762 */     if (paramB instanceof FloatBuffer) {
/* 1763 */       return (B)((FloatBuffer)paramB).put(ValueConv.int_to_float(paramInt, paramBoolean2));
/*      */     }
/* 1765 */     throw new IllegalArgumentException("Byte doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <B extends Buffer> B putNf(B paramB, boolean paramBoolean, float paramFloat) {
/* 1779 */     if (paramB instanceof ByteBuffer)
/* 1780 */       return (B)((ByteBuffer)paramB).put(ValueConv.float_to_byte(paramFloat, paramBoolean)); 
/* 1781 */     if (paramB instanceof ShortBuffer)
/* 1782 */       return (B)((ShortBuffer)paramB).put(ValueConv.float_to_short(paramFloat, paramBoolean)); 
/* 1783 */     if (paramB instanceof IntBuffer)
/* 1784 */       return (B)((IntBuffer)paramB).put(ValueConv.float_to_int(paramFloat, paramBoolean)); 
/* 1785 */     if (paramB instanceof FloatBuffer) {
/* 1786 */       return (B)((FloatBuffer)paramB).put(paramFloat);
/*      */     }
/* 1788 */     throw new IllegalArgumentException("Byte doesn't match Buffer Class: " + paramB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rangeCheck(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 1797 */     if (paramArrayOfbyte == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1801 */     if (paramArrayOfbyte.length < paramInt1 + paramInt2) {
/* 1802 */       throw new ArrayIndexOutOfBoundsException("Required " + paramInt2 + " elements in array, only had " + (paramArrayOfbyte.length - paramInt1));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void rangeCheck(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
/* 1807 */     if (paramArrayOfchar == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1811 */     if (paramArrayOfchar.length < paramInt1 + paramInt2) {
/* 1812 */       throw new ArrayIndexOutOfBoundsException("Required " + paramInt2 + " elements in array, only had " + (paramArrayOfchar.length - paramInt1));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void rangeCheck(short[] paramArrayOfshort, int paramInt1, int paramInt2) {
/* 1817 */     if (paramArrayOfshort == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1821 */     if (paramArrayOfshort.length < paramInt1 + paramInt2) {
/* 1822 */       throw new ArrayIndexOutOfBoundsException("Required " + paramInt2 + " elements in array, only had " + (paramArrayOfshort.length - paramInt1));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void rangeCheck(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 1827 */     if (paramArrayOfint == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1831 */     if (paramArrayOfint.length < paramInt1 + paramInt2) {
/* 1832 */       throw new ArrayIndexOutOfBoundsException("Required " + paramInt2 + " elements in array, only had " + (paramArrayOfint.length - paramInt1));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void rangeCheck(long[] paramArrayOflong, int paramInt1, int paramInt2) {
/* 1837 */     if (paramArrayOflong == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1841 */     if (paramArrayOflong.length < paramInt1 + paramInt2) {
/* 1842 */       throw new ArrayIndexOutOfBoundsException("Required " + paramInt2 + " elements in array, only had " + (paramArrayOflong.length - paramInt1));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void rangeCheck(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
/* 1847 */     if (paramArrayOffloat == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1851 */     if (paramArrayOffloat.length < paramInt1 + paramInt2) {
/* 1852 */       throw new ArrayIndexOutOfBoundsException("Required " + paramInt2 + " elements in array, only had " + (paramArrayOffloat.length - paramInt1));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void rangeCheck(double[] paramArrayOfdouble, int paramInt1, int paramInt2) {
/* 1857 */     if (paramArrayOfdouble == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1861 */     if (paramArrayOfdouble.length < paramInt1 + paramInt2) {
/* 1862 */       throw new ArrayIndexOutOfBoundsException("Required " + paramInt2 + " elements in array, only had " + (paramArrayOfdouble.length - paramInt1));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void rangeCheck(Buffer paramBuffer, int paramInt) {
/* 1867 */     if (paramBuffer == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1871 */     if (paramBuffer.remaining() < paramInt) {
/* 1872 */       throw new IndexOutOfBoundsException("Required " + paramInt + " remaining elements in buffer, only had " + paramBuffer.remaining());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rangeCheckBytes(Object paramObject, int paramInt) throws IllegalArgumentException, IndexOutOfBoundsException {
/* 1883 */     if (paramObject == null) {
/*      */       return;
/*      */     }
/* 1886 */     int i = remainingBytes(paramObject);
/* 1887 */     if (i < paramInt) {
/* 1888 */       throw new IndexOutOfBoundsException("Required " + paramInt + " remaining bytes in buffer, only had " + i);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringBuilder toString(StringBuilder paramStringBuilder, String paramString, Buffer paramBuffer) {
/* 1902 */     if (null == paramStringBuilder) {
/* 1903 */       paramStringBuilder = new StringBuilder();
/*      */     }
/* 1905 */     paramStringBuilder.append(paramBuffer.getClass().getSimpleName());
/* 1906 */     paramStringBuilder.append("[pos ").append(paramBuffer.position()).append(", lim ").append(paramBuffer.limit()).append(", cap ").append(paramBuffer.capacity());
/* 1907 */     paramStringBuilder.append(", remaining ").append(paramBuffer.remaining());
/* 1908 */     paramStringBuilder.append("; array ").append(paramBuffer.hasArray()).append(", direct ").append(paramBuffer.isDirect());
/* 1909 */     paramStringBuilder.append(", r/w ").append(!paramBuffer.isReadOnly()).append(": ");
/* 1910 */     if (paramBuffer instanceof ByteBuffer) {
/* 1911 */       ByteBuffer byteBuffer = (ByteBuffer)paramBuffer;
/* 1912 */       for (byte b = 0; b < byteBuffer.limit(); b++) {
/* 1913 */         if (0 < b) paramStringBuilder.append(", "); 
/* 1914 */         if (null == paramString) {
/* 1915 */           paramStringBuilder.append(byteBuffer.get(b));
/*      */         } else {
/* 1917 */           paramStringBuilder.append(String.format(paramString, new Object[] { Byte.valueOf(byteBuffer.get(b)) }));
/*      */         } 
/*      */       } 
/* 1920 */     } else if (paramBuffer instanceof FloatBuffer) {
/* 1921 */       FloatBuffer floatBuffer = (FloatBuffer)paramBuffer;
/* 1922 */       for (byte b = 0; b < floatBuffer.limit(); b++) {
/* 1923 */         if (0 < b) paramStringBuilder.append(", "); 
/* 1924 */         if (null == paramString) {
/* 1925 */           paramStringBuilder.append(floatBuffer.get(b));
/*      */         } else {
/* 1927 */           paramStringBuilder.append(String.format(paramString, new Object[] { Float.valueOf(floatBuffer.get(b)) }));
/*      */         } 
/*      */       } 
/* 1930 */     } else if (paramBuffer instanceof IntBuffer) {
/* 1931 */       IntBuffer intBuffer = (IntBuffer)paramBuffer;
/* 1932 */       for (byte b = 0; b < intBuffer.limit(); b++) {
/* 1933 */         if (0 < b) paramStringBuilder.append(", "); 
/* 1934 */         if (null == paramString) {
/* 1935 */           paramStringBuilder.append(intBuffer.get(b));
/*      */         } else {
/* 1937 */           paramStringBuilder.append(String.format(paramString, new Object[] { Integer.valueOf(intBuffer.get(b)) }));
/*      */         } 
/*      */       } 
/* 1940 */     } else if (paramBuffer instanceof ShortBuffer) {
/* 1941 */       ShortBuffer shortBuffer = (ShortBuffer)paramBuffer;
/* 1942 */       for (byte b = 0; b < shortBuffer.limit(); b++) {
/* 1943 */         if (0 < b) paramStringBuilder.append(", "); 
/* 1944 */         if (null == paramString) {
/* 1945 */           paramStringBuilder.append(shortBuffer.get(b));
/*      */         } else {
/* 1947 */           paramStringBuilder.append(String.format(paramString, new Object[] { Short.valueOf(shortBuffer.get(b)) }));
/*      */         } 
/*      */       } 
/* 1950 */     } else if (paramBuffer instanceof DoubleBuffer) {
/* 1951 */       DoubleBuffer doubleBuffer = (DoubleBuffer)paramBuffer;
/* 1952 */       for (byte b = 0; b < doubleBuffer.limit(); b++) {
/* 1953 */         if (0 < b) paramStringBuilder.append(", "); 
/* 1954 */         if (null == paramString) {
/* 1955 */           paramStringBuilder.append(doubleBuffer.get(b));
/*      */         } else {
/* 1957 */           paramStringBuilder.append(String.format(paramString, new Object[] { Double.valueOf(doubleBuffer.get(b)) }));
/*      */         } 
/*      */       } 
/* 1960 */     } else if (paramBuffer instanceof LongBuffer) {
/* 1961 */       LongBuffer longBuffer = (LongBuffer)paramBuffer;
/* 1962 */       for (byte b = 0; b < longBuffer.limit(); b++) {
/* 1963 */         if (0 < b) paramStringBuilder.append(", "); 
/* 1964 */         if (null == paramString) {
/* 1965 */           paramStringBuilder.append(longBuffer.get(b));
/*      */         } else {
/* 1967 */           paramStringBuilder.append(String.format(paramString, new Object[] { Long.valueOf(longBuffer.get(b)) }));
/*      */         } 
/*      */       } 
/* 1970 */     } else if (paramBuffer instanceof CharBuffer) {
/* 1971 */       CharBuffer charBuffer = (CharBuffer)paramBuffer;
/* 1972 */       for (byte b = 0; b < charBuffer.limit(); b++) {
/* 1973 */         if (0 < b) paramStringBuilder.append(", "); 
/* 1974 */         if (null == paramString) {
/* 1975 */           paramStringBuilder.append(charBuffer.get(b));
/*      */         } else {
/* 1977 */           paramStringBuilder.append(String.format(paramString, new Object[] { Character.valueOf(charBuffer.get(b)) }));
/*      */         } 
/*      */       } 
/*      */     } 
/* 1981 */     paramStringBuilder.append("]");
/* 1982 */     return paramStringBuilder;
/*      */   }
/*      */ 
/*      */   
/*      */   public static class Cleaner
/*      */   {
/*      */     private static final Method mbbCleaner;
/*      */     private static final Method cClean;
/*      */     private static volatile boolean cleanerError;
/*      */     
/*      */     static {
/*      */       boolean bool;
/* 1994 */       final Method[] _mbbCleaner = { null };
/* 1995 */       final Method[] _cClean = { null };
/*      */       
/* 1997 */       if (((Boolean)SecurityUtil.doPrivileged(new PrivilegedAction<Boolean>()
/*      */           {
/*      */             public Boolean run() {
/*      */               try {
/* 2001 */                 if (PlatformPropsImpl.JAVA_9) {
/* 2002 */                   return Boolean.valueOf(UnsafeUtil.hasInvokeCleaner());
/*      */                 }
/* 2004 */                 _mbbCleaner[0] = ReflectionUtil.getMethod("sun.nio.ch.DirectBuffer", "cleaner", null, Buffers.class.getClassLoader());
/* 2005 */                 _mbbCleaner[0].setAccessible(true);
/* 2006 */                 Class<?> clazz = _mbbCleaner[0].getReturnType();
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 2011 */                 _cClean[0] = clazz.getMethod("clean", new Class[0]);
/* 2012 */                 _cClean[0].setAccessible(true);
/* 2013 */                 return Boolean.TRUE;
/*      */               }
/* 2015 */               catch (Throwable throwable) {
/* 2016 */                 if (Buffers.DEBUG) {
/* 2017 */                   ExceptionUtils.dumpThrowable("Buffers", throwable);
/*      */                 }
/* 2019 */                 return Boolean.FALSE;
/* 2020 */               }  } })).booleanValue()) {
/* 2021 */         mbbCleaner = arrayOfMethod1[0];
/* 2022 */         cClean = arrayOfMethod2[0];
/* 2023 */         bool = (PlatformPropsImpl.JAVA_9 || (null != mbbCleaner && null != cClean)) ? true : false;
/*      */       } else {
/* 2025 */         mbbCleaner = null;
/* 2026 */         cClean = null;
/* 2027 */         bool = false;
/*      */       } 
/* 2029 */       cleanerError = !bool;
/* 2030 */       if (Buffers.DEBUG) {
/* 2031 */         System.err.print("Buffers.Cleaner.init: hasCleaner: " + bool + ", cleanerError " + cleanerError);
/* 2032 */         if (null != mbbCleaner) {
/* 2033 */           System.err.print(", using Cleaner class: " + mbbCleaner.getReturnType().getName());
/*      */         }
/* 2035 */         System.err.println();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static boolean clean(ByteBuffer param1ByteBuffer) {
/* 2044 */       if (cleanerError || !param1ByteBuffer.isDirect()) {
/* 2045 */         return false;
/*      */       }
/*      */       try {
/* 2048 */         if (PlatformPropsImpl.JAVA_9) {
/* 2049 */           UnsafeUtil.invokeCleaner(param1ByteBuffer);
/*      */         } else {
/* 2051 */           cClean.invoke(mbbCleaner.invoke(param1ByteBuffer, new Object[0]), new Object[0]);
/*      */         } 
/* 2053 */         return true;
/* 2054 */       } catch (Throwable throwable) {
/* 2055 */         cleanerError = true;
/* 2056 */         if (Buffers.DEBUG) {
/* 2057 */           ExceptionUtils.dumpThrowable("Buffers", throwable);
/*      */         }
/* 2059 */         return false;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer copyNativeToDirectByteBuffer(long paramLong1, long paramLong2) {
/* 2071 */     if (2147483647L < paramLong2) {
/* 2072 */       throw new IllegalArgumentException("length " + paramLong2 + " > MAX_INT");
/*      */     }
/* 2074 */     int i = (int)paramLong2;
/* 2075 */     ByteBuffer byteBuffer = newDirectByteBuffer(i);
/* 2076 */     if (null == byteBuffer) {
/* 2077 */       throw new RuntimeException("New direct ByteBuffer is NULL");
/*      */     }
/* 2079 */     if (0 < i) {
/* 2080 */       long l = getDirectBufferAddressImpl(byteBuffer);
/* 2081 */       memcpyImpl(l, paramLong1, i);
/*      */     } 
/* 2083 */     return byteBuffer;
/*      */   }
/*      */   
/*      */   static ByteBuffer getDirectByteBuffer(long paramLong, int paramInt) {
/* 2087 */     ByteBuffer byteBuffer = getDirectByteBufferImpl(paramLong, paramInt);
/* 2088 */     return (null != byteBuffer) ? nativeOrder(byteBuffer) : null;
/*      */   }
/*      */   
/*      */   static void storeDirectAddress(long paramLong, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) {
/* 2092 */     switch (paramInt2) {
/*      */       case 4:
/* 2094 */         paramByteBuffer.putInt(paramInt1, (int)(paramLong & 0xFFFFFFFFL));
/*      */         return;
/*      */       case 8:
/* 2097 */         paramByteBuffer.putLong(paramInt1, paramLong);
/*      */         return;
/*      */     } 
/* 2100 */     throw new InternalError("invalid nativeSizeInBytes " + paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int strnlen(long paramLong, int paramInt) {
/* 2112 */     return strnlenImpl(paramLong, paramInt);
/*      */   }
/*      */   
/*      */   static native long getDirectBufferAddressImpl(Object paramObject);
/*      */   
/*      */   private static native ByteBuffer getDirectByteBufferImpl(long paramLong, int paramInt);
/*      */   
/*      */   private static native int strnlenImpl(long paramLong, int paramInt);
/*      */   
/*      */   private static native long memcpyImpl(long paramLong1, long paramLong2, long paramLong3);
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/Buffers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */