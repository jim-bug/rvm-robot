/*     */ package com.jogamp.common.nio;
/*     */ 
/*     */ import com.jogamp.common.os.Platform;
/*     */ import com.jogamp.common.util.LongObjectHashMap;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PointerBuffer
/*     */   extends AbstractBuffer<PointerBuffer>
/*     */ {
/*  56 */   protected LongObjectHashMap dataMap = null;
/*     */ 
/*     */   
/*     */   static PointerBuffer create(ByteBuffer paramByteBuffer) {
/*  60 */     return Platform.is32Bit() ? new PointerBuffer(paramByteBuffer.asIntBuffer()) : new PointerBuffer(paramByteBuffer.asLongBuffer());
/*     */   }
/*     */ 
/*     */   
/*     */   PointerBuffer(IntBuffer paramIntBuffer) {
/*  65 */     super(paramIntBuffer, POINTER_SIZE, paramIntBuffer.capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   PointerBuffer(LongBuffer paramLongBuffer) {
/*  70 */     super(paramLongBuffer, POINTER_SIZE, paramLongBuffer.capacity());
/*     */   }
/*     */   
/*     */   private final void validateDataMap() {
/*  74 */     if (null == this.dataMap) {
/*  75 */       this.dataMap = new LongObjectHashMap();
/*  76 */       this.dataMap.setKeyNotFoundValue(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static PointerBuffer allocate(int paramInt) {
/*  82 */     if (Platform.is32Bit()) {
/*  83 */       return new PointerBuffer(IntBuffer.wrap(new int[paramInt]));
/*     */     }
/*  85 */     return new PointerBuffer(LongBuffer.wrap(new long[paramInt]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static PointerBuffer allocateDirect(int paramInt) {
/*  91 */     return create(Buffers.newDirectByteBuffer(POINTER_SIZE * paramInt));
/*     */   }
/*     */ 
/*     */   
/*     */   public static PointerBuffer wrap(ByteBuffer paramByteBuffer) {
/*  96 */     return create(paramByteBuffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PointerBuffer wrap(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) {
/* 106 */     int i = paramByteBuffer.position();
/* 107 */     int j = paramByteBuffer.limit();
/* 108 */     paramByteBuffer.position(paramInt1);
/* 109 */     paramByteBuffer.limit(paramInt1 + POINTER_SIZE * paramInt2);
/* 110 */     ByteBuffer byteBuffer = paramByteBuffer.slice().order(paramByteBuffer.order());
/* 111 */     paramByteBuffer.position(i);
/* 112 */     paramByteBuffer.limit(j);
/* 113 */     return create(byteBuffer);
/*     */   }
/*     */   
/*     */   public static PointerBuffer derefPointer(long paramLong, int paramInt) {
/* 117 */     if (0L == paramLong) {
/* 118 */       throw new NullPointerException("aptr is null");
/*     */     }
/* 120 */     ByteBuffer byteBuffer = Buffers.getDirectByteBuffer(paramLong, paramInt * POINTER_SIZE);
/* 121 */     if (null == byteBuffer) {
/* 122 */       throw new InternalError("Couldn't dereference aptr 0x" + Long.toHexString(paramLong) + ", size " + paramInt + " * " + POINTER_SIZE);
/*     */     }
/* 124 */     return create(byteBuffer);
/*     */   }
/*     */   public static PointerBuffer derefPointer(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) {
/* 127 */     return derefPointer(wrap(paramByteBuffer, paramInt1, 1).get(0), paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PointerBuffer duplicate() {
/*     */     PointerBuffer pointerBuffer;
/* 136 */     if (Platform.is32Bit()) {
/* 137 */       pointerBuffer = new PointerBuffer((IntBuffer)this.buffer);
/*     */     } else {
/* 139 */       pointerBuffer = new PointerBuffer((LongBuffer)this.buffer);
/*     */     } 
/* 141 */     if (null != this.dataMap) {
/* 142 */       pointerBuffer.dataMap = (LongObjectHashMap)this.dataMap.clone();
/*     */     }
/* 144 */     pointerBuffer.position = this.position;
/* 145 */     return pointerBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public final PointerBuffer put(PointerBuffer paramPointerBuffer) {
/* 150 */     if (remaining() < paramPointerBuffer.remaining()) {
/* 151 */       throw new IndexOutOfBoundsException("remaining[this " + remaining() + " < src " + paramPointerBuffer.remaining() + "], this " + this + ", src " + paramPointerBuffer);
/*     */     }
/* 153 */     if (null == paramPointerBuffer.dataMap && null == this.dataMap) {
/*     */       
/* 155 */       while (paramPointerBuffer.hasRemaining()) {
/* 156 */         put(paramPointerBuffer.get());
/*     */       }
/*     */     } else {
/* 159 */       while (paramPointerBuffer.hasRemaining()) {
/* 160 */         long l = paramPointerBuffer.get();
/* 161 */         put(l);
/* 162 */         if (null != paramPointerBuffer.dataMap) {
/* 163 */           Buffer buffer = (Buffer)paramPointerBuffer.dataMap.get(l);
/* 164 */           if (null != buffer) {
/* 165 */             validateDataMap();
/* 166 */             this.dataMap.put(l, buffer); continue;
/* 167 */           }  if (null != this.dataMap)
/* 168 */             this.dataMap.remove(l);  continue;
/*     */         } 
/* 170 */         if (null != this.dataMap) {
/* 171 */           this.dataMap.remove(l);
/*     */         }
/*     */       } 
/*     */     } 
/* 175 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final long get(int paramInt) {
/* 180 */     if (0 > paramInt || paramInt >= limit()) {
/* 181 */       throw new IndexOutOfBoundsException("idx " + paramInt + " not within [0.." + limit() + "), " + this);
/*     */     }
/* 183 */     if (Platform.is32Bit()) {
/* 184 */       return ((IntBuffer)this.buffer).get(paramInt) & 0xFFFFFFFFL;
/*     */     }
/* 186 */     return ((LongBuffer)this.buffer).get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public final long get() {
/* 191 */     long l = get(this.position);
/* 192 */     this.position++;
/* 193 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   public final PointerBuffer get(int paramInt1, long[] paramArrayOflong, int paramInt2, int paramInt3) {
/* 198 */     if (0 > paramInt1 || paramInt1 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt2 || paramInt2 + paramInt3 > paramArrayOflong.length)
/*     */     {
/*     */       
/* 201 */       throw new IndexOutOfBoundsException("destElemPos " + paramInt2 + ", srcElemPos " + paramInt1 + ", elemCount " + paramInt3 + ", srcLimit " + 
/* 202 */           limit() + ", destLimit " + paramArrayOflong.length + ", " + this);
/*     */     }
/* 204 */     if (Platform.is32Bit()) {
/* 205 */       IntBuffer intBuffer = (IntBuffer)this.buffer;
/* 206 */       for (byte b = 0; b < paramInt3; b++) {
/* 207 */         paramArrayOflong[paramInt2 + b] = intBuffer.get(paramInt1 + b) & 0xFFFFFFFFL;
/*     */       }
/*     */     } else {
/* 210 */       LongBuffer longBuffer = (LongBuffer)this.buffer;
/* 211 */       int i = longBuffer.limit();
/* 212 */       int j = longBuffer.position();
/* 213 */       longBuffer.position(paramInt1).limit(paramInt1 + paramInt3);
/* 214 */       longBuffer.get(paramArrayOflong, paramInt2, paramInt3);
/* 215 */       longBuffer.limit(i).position(j);
/*     */     } 
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PointerBuffer get(long[] paramArrayOflong, int paramInt1, int paramInt2) {
/* 225 */     get(this.position, paramArrayOflong, paramInt1, paramInt2);
/* 226 */     this.position += paramInt2;
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final PointerBuffer put(int paramInt, long paramLong) {
/* 232 */     if (0 > paramInt || paramInt >= limit()) {
/* 233 */       throw new IndexOutOfBoundsException("idx " + paramInt + " not within [0.." + limit() + "), " + this);
/*     */     }
/* 235 */     if (Platform.is32Bit()) {
/* 236 */       ((IntBuffer)this.buffer).put(paramInt, (int)paramLong);
/*     */     } else {
/* 238 */       ((LongBuffer)this.buffer).put(paramInt, paramLong);
/*     */     } 
/* 240 */     return this;
/*     */   }
/*     */   
/*     */   public final PointerBuffer put(long paramLong) {
/* 244 */     put(this.position, paramLong);
/* 245 */     this.position++;
/* 246 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final PointerBuffer put(long[] paramArrayOflong, int paramInt1, int paramInt2, int paramInt3) {
/* 251 */     if (0 > paramInt2 || paramInt2 + paramInt3 > limit() || 0 > paramInt3 || 0 > paramInt1 || paramInt1 + paramInt3 > paramArrayOflong.length)
/*     */     {
/*     */       
/* 254 */       throw new IndexOutOfBoundsException("srcElemPos " + paramInt1 + ", destElemPos " + paramInt2 + ", elemCount " + paramInt3 + ", destLimit " + 
/* 255 */           limit() + ", srcLimit " + paramArrayOflong.length + ", " + this);
/*     */     }
/* 257 */     if (Platform.is32Bit()) {
/* 258 */       IntBuffer intBuffer = (IntBuffer)this.buffer;
/* 259 */       for (byte b = 0; b < paramInt3; b++) {
/* 260 */         intBuffer.put(paramInt2 + b, (int)paramArrayOflong[paramInt1 + b]);
/*     */       }
/*     */     } else {
/* 263 */       LongBuffer longBuffer = (LongBuffer)this.buffer;
/* 264 */       int i = longBuffer.limit();
/* 265 */       int j = longBuffer.position();
/* 266 */       longBuffer.position(paramInt2).limit(paramInt2 + paramInt3);
/* 267 */       longBuffer.put(paramArrayOflong, paramInt1, paramInt3);
/* 268 */       longBuffer.limit(i).position(j);
/*     */     } 
/* 270 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final PointerBuffer put(long[] paramArrayOflong, int paramInt1, int paramInt2) {
/* 276 */     put(paramArrayOflong, paramInt1, this.position, paramInt2);
/* 277 */     this.position += paramInt2;
/* 278 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PointerBuffer referenceBuffer(int paramInt, Buffer paramBuffer) {
/* 288 */     if (null == paramBuffer) {
/* 289 */       throw new IllegalArgumentException("Buffer is null");
/*     */     }
/* 291 */     if (!Buffers.isDirect(paramBuffer)) {
/* 292 */       throw new IllegalArgumentException("Buffer is not direct");
/*     */     }
/* 294 */     long l1 = Platform.is32Bit() ? 4294967295L : -1L;
/* 295 */     long l2 = Buffers.getDirectBufferAddressImpl(paramBuffer) & l1;
/* 296 */     if (0L == l2) {
/* 297 */       throw new RuntimeException("Couldn't determine native address of given Buffer: " + paramBuffer);
/*     */     }
/* 299 */     validateDataMap();
/* 300 */     put(paramInt, l2);
/* 301 */     this.dataMap.put(l2, paramBuffer);
/* 302 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PointerBuffer referenceBuffer(Buffer paramBuffer) {
/* 309 */     referenceBuffer(this.position, paramBuffer);
/* 310 */     this.position++;
/* 311 */     return this;
/*     */   }
/*     */   
/*     */   public final Buffer getReferencedBuffer(int paramInt) {
/* 315 */     if (null != this.dataMap) {
/* 316 */       long l = get(paramInt);
/* 317 */       return (Buffer)this.dataMap.get(l);
/*     */     } 
/* 319 */     return null;
/*     */   }
/*     */   
/*     */   public final Buffer getReferencedBuffer() {
/* 323 */     Buffer buffer = getReferencedBuffer(this.position);
/* 324 */     this.position++;
/* 325 */     return buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 330 */     return "PointerBuffer" + toSubString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/PointerBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */