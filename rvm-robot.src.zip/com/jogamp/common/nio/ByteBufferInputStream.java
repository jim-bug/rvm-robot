/*     */ package com.jogamp.common.nio;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteBufferInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private final ByteBuffer buf;
/*     */   private int mark;
/*     */   
/*     */   public ByteBufferInputStream(ByteBuffer paramByteBuffer) {
/*  60 */     this.buf = paramByteBuffer;
/*  61 */     this.mark = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int available() {
/*  66 */     return this.buf.remaining();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean markSupported() {
/*  77 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void mark(int paramInt) {
/*  89 */     this.mark = this.buf.position();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void reset() throws IOException {
/* 101 */     if (this.mark == -1) {
/* 102 */       throw new IOException();
/*     */     }
/* 104 */     this.buf.position(this.mark);
/*     */   }
/*     */ 
/*     */   
/*     */   public final long skip(long paramLong) throws IOException {
/* 109 */     if (0L > paramLong) {
/* 110 */       return 0L;
/*     */     }
/* 112 */     int i = (int)Math.min(this.buf.remaining(), paramLong);
/* 113 */     this.buf.position(this.buf.position() + i);
/* 114 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int read() {
/* 119 */     if (!this.buf.hasRemaining()) {
/* 120 */       return -1;
/*     */     }
/* 122 */     return this.buf.get() & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 127 */     if (paramArrayOfbyte == null)
/* 128 */       throw new NullPointerException(); 
/* 129 */     if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 > paramArrayOfbyte.length || paramInt1 + paramInt2 > paramArrayOfbyte.length || paramInt1 + paramInt2 < 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       throw new IndexOutOfBoundsException("offset " + paramInt1 + ", length " + paramInt2 + ", b.length " + paramArrayOfbyte.length); } 
/* 136 */     if (0 == paramInt2) {
/* 137 */       return 0;
/*     */     }
/* 139 */     int i = this.buf.remaining();
/* 140 */     if (0 == i) {
/* 141 */       return -1;
/*     */     }
/* 143 */     int j = Math.min(i, paramInt2);
/* 144 */     if (this.buf.hasArray()) {
/* 145 */       System.arraycopy(this.buf.array(), this.buf.arrayOffset() + this.buf.position(), paramArrayOfbyte, paramInt1, j);
/* 146 */       this.buf.position(this.buf.position() + j);
/*     */     } else {
/* 148 */       this.buf.get(paramArrayOfbyte, paramInt1, j);
/*     */     } 
/* 150 */     return j;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int read(ByteBuffer paramByteBuffer, int paramInt) {
/* 155 */     if (paramByteBuffer == null)
/* 156 */       throw new NullPointerException(); 
/* 157 */     if (paramInt < 0 || paramInt > paramByteBuffer.remaining())
/* 158 */       throw new IndexOutOfBoundsException("length " + paramInt + ", b " + paramByteBuffer); 
/* 159 */     if (0 == paramInt) {
/* 160 */       return 0;
/*     */     }
/* 162 */     int i = this.buf.remaining();
/* 163 */     if (0 == i) {
/* 164 */       return -1;
/*     */     }
/* 166 */     int j = Math.min(i, paramInt);
/* 167 */     if (this.buf.hasArray() && paramByteBuffer.hasArray()) {
/* 168 */       System.arraycopy(this.buf.array(), this.buf.arrayOffset() + this.buf.position(), paramByteBuffer.array(), paramByteBuffer.arrayOffset() + paramByteBuffer.position(), j);
/* 169 */       this.buf.position(this.buf.position() + j);
/* 170 */       paramByteBuffer.position(paramByteBuffer.position() + j);
/* 171 */     } else if (j == i) {
/* 172 */       paramByteBuffer.put(this.buf);
/*     */     } else {
/* 174 */       int k = this.buf.limit();
/* 175 */       this.buf.limit(j);
/*     */       try {
/* 177 */         paramByteBuffer.put(this.buf);
/*     */       } finally {
/* 179 */         this.buf.limit(k);
/*     */       } 
/*     */     } 
/* 182 */     return j;
/*     */   }
/*     */   public final ByteBuffer getBuffer() {
/* 185 */     return this.buf;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/ByteBufferInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */