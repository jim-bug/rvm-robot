/*     */ package com.jogamp.common.nio;
/*     */ 
/*     */ import com.jogamp.common.os.Platform;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.MappedByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import jogamp.common.Debug;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappedByteBufferInputStream
/*     */   extends InputStream
/*     */ {
/*     */   public enum CacheMode
/*     */   {
/*  73 */     FLUSH_NONE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     FLUSH_PRE_SOFT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     FLUSH_PRE_HARD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private static final FileResizeOp NoFileResize = new FileResizeOp()
/*     */     {
/*     */       public void setLength(long param1Long) throws IOException {
/* 115 */         throw new IOException("file size change not supported");
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_SLICE_SHIFT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface FileResizeOp
/*     */   {
/*     */     void setLength(long param1Long) throws IOException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 140 */     if (PlatformPropsImpl.CPU_ARCH.is32Bit) {
/* 141 */       DEFAULT_SLICE_SHIFT = 29;
/*     */     } else {
/* 143 */       DEFAULT_SLICE_SHIFT = 30;
/*     */     } 
/*     */   }
/* 146 */   static final boolean DEBUG = Debug.debug("ByteBufferInputStream");
/*     */   
/*     */   private final int sliceShift;
/*     */   
/*     */   private final FileChannel fc;
/*     */   private final FileChannel.MapMode mmode;
/* 152 */   private FileResizeOp fileResizeOp = NoFileResize;
/*     */   
/*     */   private int sliceCount;
/*     */   
/*     */   private ByteBuffer[] slices;
/*     */   
/*     */   private WeakReference<ByteBuffer>[] slices2GC;
/*     */   private long totalSize;
/*     */   private int slicesEntries;
/*     */   private int slices2GCEntries;
/*     */   private boolean synchronous;
/*     */   private int refCount;
/*     */   private CacheMode cmode;
/*     */   private int sliceIdx;
/*     */   private long mark;
/*     */   
/*     */   final void dbgDump(String paramString, PrintStream paramPrintStream) {
/* 169 */     byte b1 = 0; byte b2;
/* 170 */     for (b2 = 0; b2 < this.sliceCount; b2++) {
/* 171 */       if (null != this.slices[b2]) {
/* 172 */         b1++;
/*     */       }
/*     */     } 
/* 175 */     b2 = 0;
/* 176 */     byte b3 = 0;
/* 177 */     for (byte b4 = 0; b4 < this.sliceCount; b4++) {
/* 178 */       WeakReference<ByteBuffer> weakReference = this.slices2GC[b4];
/* 179 */       if (null != weakReference) {
/* 180 */         b2++;
/* 181 */         if (null != weakReference.get()) {
/* 182 */           b3++;
/*     */         }
/*     */       } 
/*     */     } 
/* 186 */     long l1 = 0L, l2 = 0L, l3 = 0L;
/* 187 */     if (this.fc.isOpen()) {
/*     */       try {
/* 189 */         l1 = this.fc.size();
/* 190 */       } catch (IOException iOException) {
/* 191 */         iOException.printStackTrace();
/*     */       } 
/*     */     }
/* 194 */     if (0 < this.refCount) {
/*     */       try {
/* 196 */         l2 = position();
/* 197 */         l3 = this.totalSize - l2;
/* 198 */       } catch (IOException iOException) {
/* 199 */         iOException.printStackTrace();
/*     */       } 
/*     */     }
/* 202 */     boolean bool = (null != this.slices) ? this.slices.length : false;
/* 203 */     paramPrintStream.println(paramString + " refCount " + this.refCount + ", fcSize " + l1 + ", totalSize " + this.totalSize);
/* 204 */     paramPrintStream.println(paramString + " position " + l2 + ", remaining " + l3);
/* 205 */     paramPrintStream.println(paramString + " mmode " + this.mmode + ", cmode " + this.cmode + ", fileResizeOp " + this.fileResizeOp);
/* 206 */     paramPrintStream.println(paramString + " slice " + this.sliceIdx + " / " + this.sliceCount + " (" + bool + "), synchronous " + this.synchronous);
/* 207 */     paramPrintStream.println(paramString + "   mapped   " + this.slicesEntries + " / " + b1);
/* 208 */     paramPrintStream.println(paramString + "   GC-queue " + this.slices2GCEntries + " / " + b2 + " (alive " + b3 + ")");
/* 209 */     paramPrintStream.println(paramString + " sliceShift " + this.sliceShift + " -> " + (1L << this.sliceShift));
/*     */   }
/*     */ 
/*     */   
/*     */   MappedByteBufferInputStream(FileChannel paramFileChannel, FileChannel.MapMode paramMapMode, CacheMode paramCacheMode, int paramInt1, long paramLong, int paramInt2) throws IOException {
/* 214 */     this.sliceShift = paramInt1;
/* 215 */     this.fc = paramFileChannel;
/* 216 */     this.mmode = paramMapMode;
/*     */     
/* 218 */     if (0L > paramLong) {
/* 219 */       throw new IllegalArgumentException("Negative size " + paramLong);
/*     */     }
/*     */     
/* 222 */     this.totalSize = -1L;
/* 223 */     this.sliceCount = 0;
/* 224 */     notifyLengthChange(paramLong);
/*     */     
/* 226 */     this.refCount = 1;
/* 227 */     this.cmode = paramCacheMode;
/*     */     
/* 229 */     this.sliceIdx = paramInt2;
/* 230 */     this.mark = -1L;
/*     */     
/* 232 */     currentSlice().position(0);
/*     */     
/* 234 */     if (DEBUG) {
/* 235 */       dbgDump("CTOR", System.err);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedByteBufferInputStream(FileChannel paramFileChannel, FileChannel.MapMode paramMapMode, CacheMode paramCacheMode, int paramInt) throws IOException {
/* 254 */     this(paramFileChannel, paramMapMode, paramCacheMode, paramInt, paramFileChannel.size(), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedByteBufferInputStream(FileChannel paramFileChannel, FileChannel.MapMode paramMapMode, CacheMode paramCacheMode) throws IOException {
/* 269 */     this(paramFileChannel, paramMapMode, paramCacheMode, DEFAULT_SLICE_SHIFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedByteBufferInputStream(FileChannel paramFileChannel) throws IOException {
/* 283 */     this(paramFileChannel, FileChannel.MapMode.READ_ONLY, CacheMode.FLUSH_PRE_HARD, DEFAULT_SLICE_SHIFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void setSynchronous(boolean paramBoolean) {
/* 299 */     this.synchronous = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized boolean getSynchronous() {
/* 305 */     return this.synchronous;
/*     */   }
/*     */   
/*     */   final synchronized void checkOpen() throws IOException {
/* 309 */     if (0 == this.refCount) {
/* 310 */       throw new IOException("stream closed");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized void close() throws IOException {
/* 316 */     if (0 < this.refCount) {
/* 317 */       this.refCount--;
/* 318 */       if (0 == this.refCount) {
/*     */         try {
/* 320 */           cleanAllSlices(true);
/*     */         } finally {
/* 322 */           flushImpl(true, false);
/* 323 */           this.fc.close();
/* 324 */           this.mark = -1L;
/* 325 */           this.sliceIdx = -1;
/* 326 */           super.close();
/*     */         } 
/*     */       }
/*     */     } 
/* 330 */     if (DEBUG)
/* 331 */       dbgDump("Close", System.err); 
/*     */   }
/*     */   
/*     */   final FileChannel.MapMode getMapMode() {
/* 335 */     return this.mmode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void setFileResizeOp(FileResizeOp paramFileResizeOp) throws IllegalStateException {
/* 342 */     if (NoFileResize != this.fileResizeOp && this.fileResizeOp != paramFileResizeOp) {
/* 343 */       throw new IllegalStateException("FileResizeOp already set, this value differs");
/*     */     }
/* 345 */     this.fileResizeOp = (null != paramFileResizeOp) ? paramFileResizeOp : NoFileResize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void setLength(long paramLong) throws IOException {
/*     */     long l;
/* 363 */     if (0L != paramLong && this.totalSize != paramLong) {
/* 364 */       l = position();
/*     */     } else {
/* 366 */       l = -1L;
/*     */     } 
/* 368 */     if (this.fc.size() != paramLong) {
/* 369 */       if (Platform.OSType.WINDOWS == PlatformPropsImpl.OS_TYPE)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 374 */         cleanAllSlices(this.synchronous);
/*     */       }
/* 376 */       this.fileResizeOp.setLength(paramLong);
/* 377 */       if (this.synchronous)
/*     */       {
/* 379 */         flushImpl(true, false);
/*     */       }
/*     */     } 
/* 382 */     notifyLengthChangeImpl(paramLong, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void notifyLengthChange(long paramLong) throws IOException {
/* 395 */     notifyLengthChangeImpl(paramLong, -1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final synchronized void notifyLengthChangeImpl(long paramLong1, long paramLong2) throws IOException {
/* 402 */     if (this.totalSize == paramLong1) {
/*     */       return;
/*     */     }
/* 405 */     if (0L == paramLong1) {
/*     */       
/* 407 */       cleanAllSlices(this.synchronous);
/*     */       
/* 409 */       WeakReference[] arrayOfWeakReference = new WeakReference[1];
/* 410 */       this.slices2GC = (WeakReference<ByteBuffer>[])arrayOfWeakReference;
/* 411 */       this.slices = new ByteBuffer[1];
/* 412 */       this.slices[0] = ByteBuffer.allocate(0);
/* 413 */       this.sliceCount = 0;
/* 414 */       this.totalSize = 0L;
/* 415 */       this.mark = -1L;
/* 416 */       this.sliceIdx = 0;
/*     */     } else {
/* 418 */       long l1 = (0L <= paramLong2) ? paramLong2 : position();
/*     */       
/* 420 */       long l2 = 1L << this.sliceShift;
/* 421 */       int i = (int)((paramLong1 + l2 - 1L) / l2);
/*     */       
/* 423 */       WeakReference[] arrayOfWeakReference = new WeakReference[i];
/* 424 */       ByteBuffer[] arrayOfByteBuffer = new ByteBuffer[i];
/* 425 */       int j = Math.min(i, this.sliceCount - 1);
/* 426 */       if (0 <= j) {
/* 427 */         if (0 < j) {
/* 428 */           System.arraycopy(this.slices2GC, 0, arrayOfWeakReference, 0, j);
/* 429 */           System.arraycopy(this.slices, 0, arrayOfByteBuffer, 0, j);
/*     */         } 
/* 431 */         for (int k = j; k < this.sliceCount; k++) {
/* 432 */           cleanSlice(k, this.synchronous);
/*     */         }
/*     */       } 
/* 435 */       this.slices2GC = (WeakReference<ByteBuffer>[])arrayOfWeakReference;
/* 436 */       this.slices = arrayOfByteBuffer;
/* 437 */       this.sliceCount = i;
/* 438 */       this.totalSize = paramLong1;
/* 439 */       if (paramLong1 < this.mark) {
/* 440 */         this.mark = -1L;
/*     */       }
/* 442 */       position2(Math.min(l1, paramLong1));
/*     */     } 
/* 444 */     if (DEBUG) {
/* 445 */       dbgDump("NotifyLengthChange", System.err);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void flush(boolean paramBoolean) throws IOException {
/* 457 */     checkOpen();
/* 458 */     flushImpl(paramBoolean, true);
/*     */   }
/*     */   private final synchronized void flushImpl(boolean paramBoolean1, boolean paramBoolean2) throws IOException {
/* 461 */     if (FileChannel.MapMode.READ_ONLY != this.mmode) {
/* 462 */       if (paramBoolean2 && FileChannel.MapMode.READ_WRITE == this.mmode) {
/* 463 */         byte b; for (b = 0; b < this.sliceCount; b++) {
/* 464 */           syncSlice(this.slices[b], true);
/*     */         }
/* 466 */         for (b = 0; b < this.sliceCount; b++) {
/* 467 */           WeakReference<ByteBuffer> weakReference = this.slices2GC[b];
/* 468 */           if (null != weakReference) {
/* 469 */             syncSlice(weakReference.get(), true);
/*     */           }
/*     */         } 
/*     */       } 
/* 473 */       this.fc.force(paramBoolean1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized MappedByteBufferOutputStream getOutputStream(FileResizeOp paramFileResizeOp) throws IllegalStateException, IOException {
/* 489 */     checkOpen();
/* 490 */     MappedByteBufferOutputStream mappedByteBufferOutputStream = new MappedByteBufferOutputStream(this, paramFileResizeOp);
/* 491 */     this.refCount++;
/* 492 */     return mappedByteBufferOutputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized ByteBuffer currentSlice() throws IOException {
/* 507 */     ByteBuffer byteBuffer = this.slices[this.sliceIdx];
/* 508 */     if (null != byteBuffer) {
/* 509 */       return byteBuffer;
/*     */     }
/* 511 */     if (CacheMode.FLUSH_PRE_SOFT == this.cmode) {
/* 512 */       WeakReference<ByteBuffer> weakReference = this.slices2GC[this.sliceIdx];
/* 513 */       if (null != weakReference) {
/* 514 */         ByteBuffer byteBuffer1 = weakReference.get();
/* 515 */         this.slices2GC[this.sliceIdx] = null;
/* 516 */         this.slices2GCEntries--;
/* 517 */         if (null != byteBuffer1) {
/* 518 */           this.slices[this.sliceIdx] = byteBuffer1;
/* 519 */           this.slicesEntries++;
/* 520 */           return byteBuffer1;
/*     */         } 
/*     */       } 
/*     */     } 
/* 524 */     long l = this.sliceIdx << this.sliceShift;
/* 525 */     MappedByteBuffer mappedByteBuffer = this.fc.map(this.mmode, l, Math.min(1L << this.sliceShift, this.totalSize - l));
/* 526 */     this.slices[this.sliceIdx] = mappedByteBuffer;
/* 527 */     this.slicesEntries++;
/* 528 */     return mappedByteBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized ByteBuffer nextSlice() throws IOException {
/* 542 */     if (this.sliceIdx < this.sliceCount - 1) {
/* 543 */       flushSlice(this.sliceIdx, this.synchronous);
/* 544 */       this.sliceIdx++;
/* 545 */       ByteBuffer byteBuffer = currentSlice();
/* 546 */       byteBuffer.position(0);
/* 547 */       return byteBuffer;
/*     */     } 
/* 549 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void flushSlices() throws IOException {
/* 558 */     if (null != this.slices) {
/* 559 */       for (byte b = 0; b < this.sliceCount; b++) {
/* 560 */         flushSlice(b, this.synchronous);
/*     */       }
/*     */     }
/* 563 */     if (DEBUG) {
/* 564 */       dbgDump("FlushSlices", System.err);
/*     */     }
/*     */   }
/*     */   
/*     */   synchronized void syncSlice(ByteBuffer paramByteBuffer) throws IOException {
/* 569 */     syncSlice(paramByteBuffer, this.synchronous);
/*     */   }
/*     */   synchronized void syncSlice(ByteBuffer paramByteBuffer, boolean paramBoolean) throws IOException {
/* 572 */     if (paramBoolean && null != paramByteBuffer && FileChannel.MapMode.READ_WRITE == this.mmode)
/*     */       try {
/* 574 */         ((MappedByteBuffer)paramByteBuffer).force();
/* 575 */       } catch (Throwable throwable) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 580 */         if (DEBUG) {
/* 581 */           System.err.println("Caught " + throwable.getMessage());
/* 582 */           throwable.printStackTrace();
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   private synchronized void flushSlice(int paramInt, boolean paramBoolean) throws IOException {
/* 588 */     ByteBuffer byteBuffer = this.slices[paramInt];
/* 589 */     if (null != byteBuffer)
/* 590 */       if (CacheMode.FLUSH_NONE != this.cmode) {
/* 591 */         this.slices[paramInt] = null;
/* 592 */         this.slicesEntries--;
/* 593 */         if (CacheMode.FLUSH_PRE_HARD == this.cmode) {
/* 594 */           if (!cleanBuffer(byteBuffer, paramBoolean)) {
/*     */             
/* 596 */             this.slices2GC[paramInt] = new WeakReference<>(byteBuffer);
/* 597 */             this.slices2GCEntries++;
/*     */           } 
/*     */         } else {
/* 600 */           syncSlice(byteBuffer, paramBoolean);
/* 601 */           this.slices2GC[paramInt] = new WeakReference<>(byteBuffer);
/* 602 */           this.slices2GCEntries++;
/*     */         } 
/*     */       } else {
/* 605 */         syncSlice(byteBuffer, paramBoolean);
/*     */       }  
/*     */   }
/*     */   
/*     */   private synchronized void cleanAllSlices(boolean paramBoolean) throws IOException {
/* 610 */     if (null != this.slices) {
/* 611 */       for (byte b = 0; b < this.sliceCount; b++) {
/* 612 */         cleanSlice(b, paramBoolean);
/*     */       }
/* 614 */       if (0 != this.slicesEntries || 0 != this.slices2GCEntries) {
/* 615 */         String str = "mappedSliceCount " + this.slicesEntries + ", slices2GCEntries " + this.slices2GCEntries;
/* 616 */         dbgDump(str + ": ", System.err);
/* 617 */         throw new InternalError(str);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private synchronized void cleanSlice(int paramInt, boolean paramBoolean) throws IOException {
/* 623 */     ByteBuffer byteBuffer2, byteBuffer1 = this.slices[paramInt];
/*     */ 
/*     */     
/* 626 */     WeakReference<ByteBuffer> weakReference = this.slices2GC[paramInt];
/* 627 */     this.slices2GC[paramInt] = null;
/* 628 */     if (null != weakReference) {
/* 629 */       this.slices2GCEntries--;
/* 630 */       byteBuffer2 = weakReference.get();
/*     */     } else {
/* 632 */       byteBuffer2 = null;
/*     */     } 
/*     */     
/* 635 */     if (null != byteBuffer1) {
/* 636 */       this.slices[paramInt] = null;
/* 637 */       this.slicesEntries--;
/* 638 */       cleanBuffer(byteBuffer1, paramBoolean);
/* 639 */       if (null != byteBuffer2) {
/* 640 */         throw new InternalError("XXX");
/*     */       }
/* 642 */     } else if (null != byteBuffer2) {
/* 643 */       cleanBuffer(byteBuffer2, paramBoolean);
/*     */     } 
/*     */   }
/*     */   private synchronized boolean cleanBuffer(ByteBuffer paramByteBuffer, boolean paramBoolean) throws IOException {
/* 647 */     syncSlice(paramByteBuffer, paramBoolean);
/* 648 */     if (!paramByteBuffer.isDirect()) {
/* 649 */       return false;
/*     */     }
/* 651 */     if (!Buffers.Cleaner.clean(paramByteBuffer) && CacheMode.FLUSH_PRE_HARD == this.cmode) {
/* 652 */       this.cmode = CacheMode.FLUSH_PRE_SOFT;
/* 653 */       return false;
/*     */     } 
/* 655 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized CacheMode getCacheMode() {
/* 668 */     return this.cmode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized long length() {
/* 678 */     return this.totalSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized long remaining() throws IOException {
/* 694 */     return (0 < this.refCount) ? (this.totalSize - position()) : 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized int available() throws IOException {
/* 706 */     long l = remaining();
/* 707 */     return (l <= 2147483647L) ? (int)l : Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized long position() throws IOException {
/* 719 */     if (0 < this.refCount) {
/* 720 */       return (this.sliceIdx << this.sliceShift) + currentSlice().position();
/*     */     }
/* 722 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized MappedByteBufferInputStream position(long paramLong) throws IOException {
/* 737 */     checkOpen();
/* 738 */     if (this.totalSize < paramLong || 0L > paramLong) {
/* 739 */       throw new IllegalArgumentException("new position " + paramLong + " not within [0.." + this.totalSize + "]");
/*     */     }
/* 741 */     int i = this.sliceIdx;
/*     */     
/* 743 */     if (this.totalSize == paramLong) {
/*     */       
/* 745 */       this.sliceIdx = Math.max(0, this.sliceCount - 1);
/* 746 */       if (i != this.sliceIdx) {
/* 747 */         flushSlice(i, this.synchronous);
/*     */       }
/* 749 */       ByteBuffer byteBuffer = currentSlice();
/* 750 */       byteBuffer.position(byteBuffer.capacity());
/*     */     } else {
/* 752 */       this.sliceIdx = (int)(paramLong >>> this.sliceShift);
/* 753 */       if (i != this.sliceIdx) {
/* 754 */         flushSlice(i, this.synchronous);
/*     */       }
/* 756 */       currentSlice().position((int)(paramLong - (this.sliceIdx << this.sliceShift)));
/*     */     } 
/* 758 */     return this;
/*     */   }
/*     */   private final synchronized void position2(long paramLong) throws IOException {
/* 761 */     if (this.totalSize == paramLong) {
/*     */       
/* 763 */       this.sliceIdx = Math.max(0, this.sliceCount - 1);
/* 764 */       ByteBuffer byteBuffer = currentSlice();
/* 765 */       byteBuffer.position(byteBuffer.capacity());
/*     */     } else {
/* 767 */       this.sliceIdx = (int)(paramLong >>> this.sliceShift);
/* 768 */       currentSlice().position((int)(paramLong - (this.sliceIdx << this.sliceShift)));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean markSupported() {
/* 774 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void mark(int paramInt) {
/* 786 */     if (0 < this.refCount) {
/*     */       try {
/* 788 */         this.mark = position();
/* 789 */       } catch (IOException iOException) {
/* 790 */         throw new RuntimeException(iOException);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void reset() throws IOException {
/* 802 */     checkOpen();
/* 803 */     if (this.mark == -1L) {
/* 804 */       throw new IOException("mark not set");
/*     */     }
/* 806 */     position(this.mark);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized long skip(long paramLong) throws IOException {
/* 815 */     checkOpen();
/* 816 */     if (0L > paramLong) {
/* 817 */       return 0L;
/*     */     }
/* 819 */     long l1 = position();
/* 820 */     long l2 = this.totalSize - l1;
/* 821 */     long l3 = Math.min(l2, paramLong);
/* 822 */     position(l1 + l3);
/* 823 */     return l3;
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized int read() throws IOException {
/* 828 */     checkOpen();
/* 829 */     ByteBuffer byteBuffer = currentSlice();
/* 830 */     if (!byteBuffer.hasRemaining() && 
/* 831 */       null == (byteBuffer = nextSlice())) {
/* 832 */       return -1;
/*     */     }
/*     */     
/* 835 */     return byteBuffer.get() & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 840 */     checkOpen();
/* 841 */     if (paramArrayOfbyte == null)
/* 842 */       throw new NullPointerException(); 
/* 843 */     if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 > paramArrayOfbyte.length || paramInt1 + paramInt2 > paramArrayOfbyte.length || paramInt1 + paramInt2 < 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 849 */       throw new IndexOutOfBoundsException("offset " + paramInt1 + ", length " + paramInt2 + ", b.length " + paramArrayOfbyte.length); } 
/* 850 */     if (0 == paramInt2) {
/* 851 */       return 0;
/*     */     }
/* 853 */     long l = remaining();
/* 854 */     if (0L == l) {
/* 855 */       return -1;
/*     */     }
/* 857 */     int i = (int)Math.min(l, paramInt2);
/* 858 */     int j = 0;
/* 859 */     while (j < i) {
/* 860 */       ByteBuffer byteBuffer = currentSlice();
/* 861 */       int k = byteBuffer.remaining();
/* 862 */       if (0 == k) {
/* 863 */         if (null == (byteBuffer = nextSlice())) {
/* 864 */           throw new InternalError("Unexpected EOT");
/*     */         }
/* 866 */         k = byteBuffer.remaining();
/*     */       } 
/* 868 */       int m = Math.min(i - j, k);
/* 869 */       byteBuffer.get(paramArrayOfbyte, paramInt1 + j, m);
/* 870 */       j += m;
/*     */     } 
/* 872 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized int read(ByteBuffer paramByteBuffer, int paramInt) throws IOException {
/* 885 */     checkOpen();
/* 886 */     if (paramByteBuffer == null)
/* 887 */       throw new NullPointerException(); 
/* 888 */     if (paramInt < 0 || paramInt > paramByteBuffer.remaining())
/* 889 */       throw new IndexOutOfBoundsException("length " + paramInt + ", b " + paramByteBuffer); 
/* 890 */     if (0 == paramInt) {
/* 891 */       return 0;
/*     */     }
/* 893 */     long l = remaining();
/* 894 */     if (0L == l) {
/* 895 */       return -1;
/*     */     }
/* 897 */     int i = (int)Math.min(l, paramInt);
/* 898 */     int j = 0;
/* 899 */     while (j < i) {
/* 900 */       ByteBuffer byteBuffer = currentSlice();
/* 901 */       int k = byteBuffer.remaining();
/* 902 */       if (0 == k) {
/* 903 */         if (null == (byteBuffer = nextSlice())) {
/* 904 */           throw new InternalError("Unexpected EOT");
/*     */         }
/* 906 */         k = byteBuffer.remaining();
/*     */       } 
/* 908 */       int m = Math.min(i - j, k);
/* 909 */       if (byteBuffer.hasArray() && paramByteBuffer.hasArray()) {
/* 910 */         System.arraycopy(byteBuffer.array(), byteBuffer.arrayOffset() + byteBuffer.position(), paramByteBuffer
/* 911 */             .array(), paramByteBuffer.arrayOffset() + paramByteBuffer.position(), m);
/*     */         
/* 913 */         byteBuffer.position(byteBuffer.position() + m);
/* 914 */         paramByteBuffer.position(paramByteBuffer.position() + m);
/* 915 */       } else if (m == k) {
/* 916 */         paramByteBuffer.put(byteBuffer);
/*     */       } else {
/* 918 */         int n = byteBuffer.limit();
/* 919 */         byteBuffer.limit(m);
/*     */         try {
/* 921 */           paramByteBuffer.put(byteBuffer);
/*     */         } finally {
/* 923 */           byteBuffer.limit(n);
/*     */         } 
/*     */       } 
/* 926 */       j += m;
/*     */     } 
/* 928 */     return i;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/nio/MappedByteBufferInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */