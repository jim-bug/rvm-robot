/*     */ package com.jogamp.common.av;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AudioSink
/*     */ {
/*     */   public static final int DefaultFrameDuration = 32;
/*     */   public static final int DefaultInitialQueueSize = 512;
/*     */   public static final int DefaultQueueGrowAmount = 512;
/*     */   public static final int DefaultQueueLimitWithVideo = 3072;
/*     */   public static final int DefaultQueueLimitAudioOnly = 1024;
/*     */   
/*     */   boolean makeCurrent(boolean paramBoolean);
/*     */   
/*     */   boolean release(boolean paramBoolean);
/*     */   
/*     */   boolean isAvailable();
/*     */   
/*     */   float getPlaySpeed();
/*     */   
/*     */   boolean setPlaySpeed(float paramFloat);
/*     */   
/*  35 */   public static final boolean DEBUG = Debug.debug("AudioSink"); float getVolume(); boolean setVolume(float paramFloat); int getSourceCount(); float getDefaultLatency();
/*     */   AudioFormat getNativeFormat();
/*     */   AudioFormat getPreferredFormat();
/*     */   void setChannelLimit(int paramInt);
/*     */   boolean isSupported(AudioFormat paramAudioFormat);
/*     */   boolean init(AudioFormat paramAudioFormat, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   AudioFormat getChosenFormat();
/*     */   float getLatency();
/*     */   boolean isPlaying();
/*     */   void play();
/*     */   void pause();
/*     */   void flush();
/*     */   void destroy();
/*     */   int getFrameCount();
/*     */   int getEnqueuedFrameCount();
/*  50 */   public static final AudioFormat DefaultFormat = new AudioFormat(44100, 16, 2, true, true, false, true);
/*     */ 
/*     */   
/*     */   int getQueuedFrameCount();
/*     */ 
/*     */   
/*     */   int getQueuedByteCount();
/*     */   
/*     */   float getQueuedTime();
/*     */   
/*     */   float getAvgFrameDuration();
/*     */   
/*     */   int getPTS();
/*     */   
/*     */   int getFreeFrameCount();
/*     */   
/*     */   AudioFrame enqueueData(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2);
/*     */   
/*     */   public static abstract class AudioFrame
/*     */     extends TimeFrameI
/*     */   {
/*     */     public AudioFrame() {
/*  72 */       this.byteSize = 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected int byteSize;
/*     */ 
/*     */     
/*     */     public AudioFrame(int param1Int1, int param1Int2, int param1Int3) {
/*  81 */       super(param1Int1, param1Int2);
/*  82 */       this.byteSize = param1Int3;
/*     */     }
/*     */     
/*     */     public final int getByteSize() {
/*  86 */       return this.byteSize;
/*     */     } public final void setByteSize(int param1Int) {
/*  88 */       this.byteSize = param1Int;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  92 */       return "AudioFrame[pts " + this.pts + " ms, l " + this.duration + " ms, " + this.byteSize + " bytes]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AudioDataFrame
/*     */     extends AudioFrame
/*     */   {
/*     */     protected final ByteBuffer data;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AudioDataFrame(int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer, int param1Int3) {
/* 109 */       super(param1Int1, param1Int2, param1Int3);
/* 110 */       if (param1Int3 > param1ByteBuffer.remaining()) {
/* 111 */         throw new IllegalArgumentException("Give size " + param1Int3 + " exceeds remaining bytes in ls " + param1ByteBuffer + ". " + this);
/*     */       }
/* 113 */       this.data = param1ByteBuffer;
/*     */     }
/*     */     
/*     */     public final ByteBuffer getData() {
/* 117 */       return this.data;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 121 */       return "AudioDataFrame[pts " + this.pts + " ms, l " + this.duration + " ms, " + this.byteSize + " bytes, " + this.data + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/av/AudioSink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */