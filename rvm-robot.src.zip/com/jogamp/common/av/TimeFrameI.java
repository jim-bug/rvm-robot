/*    */ package com.jogamp.common.av;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeFrameI
/*    */ {
/*    */   public static final int INVALID_PTS = -2147483648;
/*    */   public static final int END_OF_STREAM_PTS = 2147483647;
/*    */   protected int pts;
/*    */   protected int duration;
/*    */   
/*    */   public TimeFrameI() {
/* 63 */     this.pts = Integer.MIN_VALUE;
/* 64 */     this.duration = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TimeFrameI(int paramInt1, int paramInt2) {
/* 72 */     this.pts = paramInt1;
/* 73 */     this.duration = paramInt2;
/*    */   }
/*    */   
/*    */   public final int getPTS() {
/* 77 */     return this.pts;
/*    */   } public final void setPTS(int paramInt) {
/* 79 */     this.pts = paramInt;
/*    */   } public final int getDuration() {
/* 81 */     return this.duration;
/*    */   } public final void setDuration(int paramInt) {
/* 83 */     this.duration = paramInt;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 87 */     return "TimeFrame[pts " + this.pts + " ms, l " + this.duration + " ms]";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/av/TimeFrameI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */