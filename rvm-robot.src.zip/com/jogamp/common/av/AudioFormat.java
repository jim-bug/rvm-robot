/*     */ package com.jogamp.common.av;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioFormat
/*     */ {
/*     */   public final int sampleRate;
/*     */   public final int sampleSize;
/*     */   public final int channelCount;
/*     */   public final boolean signed;
/*     */   public final boolean fixedP;
/*     */   public final boolean planar;
/*     */   public final boolean littleEndian;
/*     */   
/*     */   public AudioFormat(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/*  44 */     this.sampleRate = paramInt1;
/*  45 */     this.sampleSize = paramInt2;
/*  46 */     this.channelCount = paramInt3;
/*  47 */     this.signed = paramBoolean1;
/*  48 */     this.fixedP = paramBoolean2;
/*  49 */     this.planar = paramBoolean3;
/*  50 */     this.littleEndian = paramBoolean4;
/*  51 */     if (!paramBoolean2) {
/*  52 */       if (paramInt2 != 32 && paramInt2 != 64) {
/*  53 */         throw new IllegalArgumentException("Floating point: sampleSize " + paramInt2 + " bits");
/*     */       }
/*  55 */       if (!paramBoolean1) {
/*  56 */         throw new IllegalArgumentException("Floating point: unsigned");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getDurationsByteSize(float paramFloat) {
/*  94 */     float f = (this.sampleSize >>> 3);
/*  95 */     return Math.round(paramFloat * this.channelCount * f * this.sampleRate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float getBytesDuration(int paramInt) {
/* 111 */     float f = (this.sampleSize >>> 3);
/* 112 */     return paramInt / this.channelCount * f * this.sampleRate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float getSamplesDuration(int paramInt) {
/* 127 */     return paramInt / this.sampleRate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getFrameCount(float paramFloat1, float paramFloat2) {
/* 148 */     return Math.max(1, Math.round(paramFloat1 / paramFloat2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getSamplesByteCount(int paramInt) {
/* 167 */     return paramInt * (this.sampleSize >>> 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getBytesSampleCount(int paramInt) {
/* 186 */     return (paramInt << 3) / this.sampleSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 191 */     return "AudioFormat[sampleRate " + this.sampleRate + ", sampleSize " + this.sampleSize + ", channelCount " + this.channelCount + ", signed " + this.signed + ", fixedP " + this.fixedP + ", " + (
/* 192 */       this.planar ? "planar" : "packed") + ", " + (this.littleEndian ? "little" : "big") + "-endian]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/av/AudioFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */