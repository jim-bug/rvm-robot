/*    */ package com.jogamp.common.av;
/*    */ 
/*    */ import com.jogamp.common.util.ReflectionUtil;
/*    */ import jogamp.common.av.NullAudioSink;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AudioSinkFactory
/*    */ {
/*    */   private static final String ALAudioSinkClazzName = "com.jogamp.openal.util.ALAudioSink";
/*    */   private static final String JavaAudioSinkClazzName = "jogamp.common.av.JavaSoundAudioSink";
/*    */   
/*    */   public static AudioSink createDefault(ClassLoader paramClassLoader) {
/* 39 */     AudioSink audioSink = create(paramClassLoader, "com.jogamp.openal.util.ALAudioSink");
/* 40 */     if (null == audioSink) {
/* 41 */       audioSink = create(paramClassLoader, "jogamp.common.av.JavaSoundAudioSink");
/*    */     }
/* 43 */     if (null == audioSink) {
/* 44 */       audioSink = createNull();
/*    */     }
/* 46 */     return audioSink;
/*    */   }
/*    */   public static AudioSink createNull() {
/* 49 */     return (AudioSink)new NullAudioSink();
/*    */   }
/*    */ 
/*    */   
/*    */   public static AudioSink create(ClassLoader paramClassLoader, String paramString) {
/* 54 */     if (ReflectionUtil.isClassAvailable(paramString, paramClassLoader))
/*    */       try {
/* 56 */         AudioSink audioSink = (AudioSink)ReflectionUtil.createInstance(paramString, paramClassLoader);
/* 57 */         if (audioSink.isAvailable())
/* 58 */           return audioSink; 
/* 59 */         if (AudioSink.DEBUG) {
/* 60 */           System.err.println("AudioSinkFactory: Couldn't instantiate AudioSink '" + paramString + "'");
/*    */         }
/* 62 */       } catch (Throwable throwable) {
/* 63 */         if (AudioSink.DEBUG) { System.err.println("Caught " + throwable.getClass().getName() + ": " + throwable.getMessage()); throwable.printStackTrace(); }
/*    */       
/*    */       }  
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/common/av/AudioSinkFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */