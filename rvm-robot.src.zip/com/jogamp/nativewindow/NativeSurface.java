package com.jogamp.nativewindow;

import com.jogamp.common.util.locks.RecursiveLock;

public interface NativeSurface extends SurfaceUpdatedListener {
  public static final int LOCK_SURFACE_UNLOCKED = 0;
  
  public static final int LOCK_SURFACE_NOT_READY = 1;
  
  public static final int LOCK_SURFACE_CHANGED = 2;
  
  public static final int LOCK_SUCCESS = 3;
  
  RecursiveLock getLock();
  
  int lockSurface() throws NativeWindowException, RuntimeException;
  
  void unlockSurface();
  
  boolean isSurfaceLockedByOtherThread();
  
  Thread getSurfaceLockOwner();
  
  boolean surfaceSwap();
  
  void addSurfaceUpdatedListener(SurfaceUpdatedListener paramSurfaceUpdatedListener);
  
  void addSurfaceUpdatedListener(int paramInt, SurfaceUpdatedListener paramSurfaceUpdatedListener) throws IndexOutOfBoundsException;
  
  void removeSurfaceUpdatedListener(SurfaceUpdatedListener paramSurfaceUpdatedListener);
  
  long getSurfaceHandle();
  
  int getSurfaceWidth();
  
  int getSurfaceHeight();
  
  int[] convertToWindowUnits(int[] paramArrayOfint);
  
  int[] convertToPixelUnits(int[] paramArrayOfint);
  
  AbstractGraphicsConfiguration getGraphicsConfiguration();
  
  long getDisplayHandle();
  
  int getScreenIndex();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/NativeSurface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */