package com.jogamp.nativewindow;

public interface AbstractGraphicsScreen extends Cloneable {
  Object clone();
  
  AbstractGraphicsDevice getDevice();
  
  int getIndex();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/AbstractGraphicsScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */