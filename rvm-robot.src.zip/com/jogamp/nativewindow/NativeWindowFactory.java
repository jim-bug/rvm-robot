/*     */ package com.jogamp.nativewindow;
/*     */ 
/*     */ import com.jogamp.common.os.Platform;
/*     */ import com.jogamp.common.util.InterruptSource;
/*     */ import com.jogamp.common.util.PropertyAccess;
/*     */ import com.jogamp.common.util.ReflectionUtil;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import com.jogamp.nativewindow.awt.AWTGraphicsDevice;
/*     */ import com.jogamp.nativewindow.awt.AWTGraphicsScreen;
/*     */ import com.jogamp.nativewindow.egl.EGLGraphicsDevice;
/*     */ import com.jogamp.nativewindow.ios.IOSGraphicsDevice;
/*     */ import com.jogamp.nativewindow.macosx.MacOSXGraphicsDevice;
/*     */ import com.jogamp.nativewindow.util.Point;
/*     */ import com.jogamp.nativewindow.windows.WindowsGraphicsDevice;
/*     */ import com.jogamp.nativewindow.x11.X11GraphicsDevice;
/*     */ import com.jogamp.nativewindow.x11.X11GraphicsScreen;
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ import jogamp.nativewindow.BcmVCArtifacts;
/*     */ import jogamp.nativewindow.Debug;
/*     */ import jogamp.nativewindow.NativeWindowFactoryImpl;
/*     */ import jogamp.nativewindow.ResourceToolkitLock;
/*     */ import jogamp.nativewindow.WrappedWindow;
/*     */ import jogamp.nativewindow.ios.IOSUtil;
/*     */ import jogamp.nativewindow.macosx.OSXUtil;
/*     */ import jogamp.nativewindow.windows.GDIUtil;
/*     */ import jogamp.nativewindow.x11.X11Lib;
/*     */ import jogamp.nativewindow.x11.X11Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NativeWindowFactory
/*     */ {
/*     */   protected static final boolean DEBUG;
/*     */   public static final String TYPE_WAYLAND = ".wayland";
/*     */   public static final String TYPE_DRM_GBM = ".egl.gbm";
/*     */   public static final String TYPE_EGL = ".egl";
/*     */   public static final String TYPE_WINDOWS = ".windows";
/*     */   public static final String TYPE_X11 = ".x11";
/*     */   public static final String TYPE_BCM_VC_IV = ".bcm.vc.iv";
/*     */   public static final String TYPE_ANDROID = ".android";
/*     */   public static final String TYPE_MACOSX = ".macosx";
/*     */   public static final String TYPE_IOS = ".ios";
/*     */   public static final String TYPE_AWT = ".awt";
/*     */   public static final String TYPE_DEFAULT = ".default";
/*     */   private static final String nativeWindowingTypeNative;
/*     */   private static final String nativeWindowingTypeCustom;
/*     */   private static NativeWindowFactory defaultFactory;
/*     */   private static Map<Class<?>, NativeWindowFactory> registeredFactories;
/*     */   private static Class<?> nativeWindowClass;
/*     */   private static boolean isAWTAvailable;
/*     */   private static final String JAWTUtilClassName = "jogamp.nativewindow.jawt.JAWTUtil";
/*     */   private static final String X11UtilClassName = "jogamp.nativewindow.x11.X11Util";
/*     */   private static final String DRMUtilClassName = "jogamp.nativewindow.drm.DRMUtil";
/*     */   private static final String OSXUtilClassName = "jogamp.nativewindow.macosx.OSXUtil";
/*     */   private static final String IOSUtilClassName = "jogamp.nativewindow.ios.IOSUtil";
/*     */   private static final String GDIClassName = "jogamp.nativewindow.windows.GDIUtil";
/*     */   private static ToolkitLock jawtUtilJAWTToolkitLock;
/*     */   private static boolean requiresToolkitLock;
/*     */   private static boolean desktopHasThreadingIssues;
/*     */   private static volatile boolean isJVMShuttingDown = false;
/* 134 */   private static final List<Runnable> customShutdownHooks = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private static boolean initialized;
/*     */ 
/*     */ 
/*     */   
/*     */   private static String _getNativeWindowingType(boolean paramBoolean) {
/* 142 */     switch (PlatformPropsImpl.OS_TYPE) {
/*     */       case ANDROID:
/* 144 */         return ".android";
/*     */       case MACOS:
/* 146 */         return ".macosx";
/*     */       case IOS:
/* 148 */         return ".ios";
/*     */       case WINDOWS:
/* 150 */         return ".windows";
/*     */       case OPENKODE:
/* 152 */         return ".egl";
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     if (paramBoolean) {
/* 159 */       guessX(true);
/* 160 */       guessWayland(true);
/* 161 */       guessGBM(true);
/* 162 */       BcmVCArtifacts.guessVCIVUsed(true);
/*     */     } 
/* 164 */     if (BcmVCArtifacts.guessVCIVUsed(false))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 176 */       return ".bcm.vc.iv";
/*     */     }
/* 178 */     if (guessX(false)) {
/* 179 */       return ".x11";
/*     */     }
/* 181 */     if (guessWayland(false))
/*     */     {
/* 183 */       return ".wayland";
/*     */     }
/* 185 */     if (guessGBM(false)) {
/* 186 */       return ".egl.gbm";
/*     */     }
/* 188 */     return ".x11";
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean guessX(boolean paramBoolean) {
/* 193 */     String str = System.getenv("DISPLAY");
/* 194 */     if (paramBoolean) {
/* 195 */       System.err.println("guessX: <" + str + "> isSet " + ((null != str) ? 1 : 0));
/*     */     }
/* 197 */     return (null != str);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean guessWayland(boolean paramBoolean) {
/* 202 */     String str = System.getenv("WAYLAND_DISPLAY");
/* 203 */     if (paramBoolean) {
/* 204 */       System.err.println("guessWayland: <" + str + "> isSet " + ((null != str) ? 1 : 0));
/*     */     }
/* 206 */     return (null != str);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean guessGBM(boolean paramBoolean) {
/* 211 */     File file = new File("/dev/dri/card0");
/* 212 */     if (paramBoolean) {
/* 213 */       System.err.println("guessGBM: <" + file.toString() + "> exists " + file.exists());
/*     */     }
/* 215 */     return file.exists();
/*     */   }
/*     */   
/*     */   static {
/* 219 */     final boolean[] _DEBUG = { false };
/* 220 */     final String[] _tmp = { null };
/* 221 */     final String[] _nativeWindowingTypeNative = { null };
/*     */     
/* 223 */     SecurityUtil.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 226 */             Platform.initSingleton();
/* 227 */             _DEBUG[0] = Debug.debug("NativeWindow");
/* 228 */             _tmp[0] = PropertyAccess.getProperty("nativewindow.ws.name", true);
/* 229 */             _nativeWindowingTypeNative[0] = NativeWindowFactory._getNativeWindowingType(_DEBUG[0]);
/* 230 */             Runtime.getRuntime().addShutdownHook((Thread)new InterruptSource.Thread(null, new Runnable()
/*     */                   {
/*     */                     public void run()
/*     */                     {
/* 234 */                       NativeWindowFactory.shutdown(true); }
/*     */                   },  "NativeWindowFactory_ShutdownHook"));
/* 236 */             return null;
/*     */           }
/*     */         });
/* 239 */     DEBUG = arrayOfBoolean[0];
/*     */     
/* 241 */     nativeWindowingTypeNative = arrayOfString2[0];
/* 242 */     if (null == arrayOfString1[0] || arrayOfString1[0].length() == 0) {
/* 243 */       nativeWindowingTypeCustom = nativeWindowingTypeNative;
/*     */     } else {
/* 245 */       nativeWindowingTypeCustom = arrayOfString1[0].intern();
/*     */     } 
/* 247 */     if (DEBUG) {
/* 248 */       System.err.println(Thread.currentThread().getName() + " - Info: NativeWindowFactory.<init>: Type " + nativeWindowingTypeCustom + " custom / " + nativeWindowingTypeNative + " native");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 253 */     initialized = false;
/*     */   }
/*     */   
/*     */   private static String getNativeWindowingTypeClassName() {
/* 257 */     switch (nativeWindowingTypeNative)
/*     */     { case ".x11":
/* 259 */         str = "jogamp.nativewindow.x11.X11Util";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 276 */         return str;case ".egl.gbm": str = "jogamp.nativewindow.drm.DRMUtil"; return str;case ".windows": str = "jogamp.nativewindow.windows.GDIUtil"; return str;case ".macosx": str = "jogamp.nativewindow.macosx.OSXUtil"; return str;case ".ios": str = "jogamp.nativewindow.ios.IOSUtil"; return str; }  String str = null; return str;
/*     */   }
/*     */   private static void initSingletonNativeImpl(ClassLoader paramClassLoader) {
/* 279 */     String str = getNativeWindowingTypeClassName();
/* 280 */     if (null != str) {
/* 281 */       ReflectionUtil.callStaticMethod(str, "initSingleton", null, null, paramClassLoader);
/*     */       
/* 283 */       Boolean bool1 = (Boolean)ReflectionUtil.callStaticMethod(str, "requiresToolkitLock", null, null, paramClassLoader);
/* 284 */       requiresToolkitLock = bool1.booleanValue();
/* 285 */       Boolean bool2 = (Boolean)ReflectionUtil.callStaticMethod(str, "hasThreadingIssues", null, null, paramClassLoader);
/* 286 */       desktopHasThreadingIssues = bool2.booleanValue();
/*     */     } else {
/* 288 */       requiresToolkitLock = false;
/* 289 */       desktopHasThreadingIssues = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final boolean isJVMShuttingDown() {
/* 294 */     return isJVMShuttingDown;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addCustomShutdownHook(boolean paramBoolean, Runnable paramRunnable) {
/* 303 */     synchronized (customShutdownHooks) {
/* 304 */       if (!customShutdownHooks.contains(paramRunnable)) {
/* 305 */         if (paramBoolean) {
/* 306 */           customShutdownHooks.add(0, paramRunnable);
/*     */         } else {
/* 308 */           customShutdownHooks.add(paramRunnable);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void shutdown(boolean paramBoolean) {
/* 318 */     isJVMShuttingDown = paramBoolean;
/* 319 */     if (DEBUG) {
/* 320 */       System.err.println("NativeWindowFactory.shutdown() START: JVM Shutdown " + isJVMShuttingDown + ", on thread " + Thread.currentThread().getName());
/*     */     }
/* 322 */     synchronized (customShutdownHooks) {
/* 323 */       int i = customShutdownHooks.size();
/* 324 */       for (byte b = 0; b < i; b++) {
/*     */         try {
/* 326 */           if (DEBUG) {
/* 327 */             System.err.println("NativeWindowFactory.shutdown - customShutdownHook #" + (b + 1) + "/" + i);
/*     */           }
/* 329 */           ((Runnable)customShutdownHooks.get(b)).run();
/* 330 */         } catch (Throwable throwable) {
/* 331 */           System.err.println("NativeWindowFactory.shutdown: Caught " + throwable.getClass().getName() + " during customShutdownHook #" + (b + 1) + "/" + i);
/* 332 */           if (DEBUG) {
/* 333 */             throwable.printStackTrace();
/*     */           }
/*     */         } 
/*     */       } 
/* 337 */       customShutdownHooks.clear();
/*     */     } 
/* 339 */     if (DEBUG) {
/* 340 */       System.err.println("NativeWindowFactory.shutdown(): Post customShutdownHook");
/*     */     }
/*     */     
/* 343 */     if (initialized) {
/* 344 */       initialized = false;
/* 345 */       if (null != registeredFactories) {
/* 346 */         registeredFactories.clear();
/* 347 */         registeredFactories = null;
/*     */       } 
/* 349 */       GraphicsConfigurationFactory.shutdown();
/*     */     } 
/*     */     
/* 352 */     shutdownNativeImpl(NativeWindowFactory.class.getClassLoader());
/*     */     
/* 354 */     if (DEBUG) {
/* 355 */       System.err.println(Thread.currentThread().getName() + " - NativeWindowFactory.shutdown() END JVM Shutdown " + isJVMShuttingDown);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void shutdownNativeImpl(ClassLoader paramClassLoader) {
/* 360 */     String str = getNativeWindowingTypeClassName();
/* 361 */     if (null != str) {
/* 362 */       ReflectionUtil.callStaticMethod(str, "shutdown", null, null, paramClassLoader);
/*     */     }
/*     */   }
/*     */   
/*     */   public static synchronized boolean isInitialized() {
/* 367 */     return initialized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void initSingleton() {
/* 374 */     if (!initialized) {
/* 375 */       initialized = true;
/*     */       
/* 377 */       if (DEBUG) {
/* 378 */         System.err.println(Thread.currentThread().getName() + " - NativeWindowFactory.initSingleton()");
/*     */       }
/*     */       
/* 381 */       ClassLoader classLoader = NativeWindowFactory.class.getClassLoader();
/*     */       
/* 383 */       isAWTAvailable = false;
/*     */       
/* 385 */       if (Platform.AWT_AVAILABLE && 
/* 386 */         ReflectionUtil.isClassAvailable("com.jogamp.nativewindow.awt.AWTGraphicsDevice", classLoader)) {
/*     */         
/* 388 */         Method[] arrayOfMethod = (Method[])SecurityUtil.doPrivileged(new PrivilegedAction<Method[]>()
/*     */             {
/*     */               public Method[] run() {
/*     */                 try {
/* 392 */                   Class<?> clazz = Class.forName("jogamp.nativewindow.jawt.JAWTUtil", true, NativeWindowFactory.class.getClassLoader());
/* 393 */                   Method method1 = clazz.getDeclaredMethod("isHeadlessMode", (Class[])null);
/* 394 */                   method1.setAccessible(true);
/* 395 */                   Method method2 = clazz.getDeclaredMethod("initSingleton", (Class[])null);
/* 396 */                   method2.setAccessible(true);
/* 397 */                   Method method3 = clazz.getDeclaredMethod("getJAWTToolkitLock", new Class[0]);
/* 398 */                   method3.setAccessible(true);
/* 399 */                   return new Method[] { method2, method1, method3 };
/* 400 */                 } catch (Exception exception) {
/* 401 */                   if (NativeWindowFactory.DEBUG) {
/* 402 */                     exception.printStackTrace();
/*     */                   }
/*     */                   
/* 405 */                   return null;
/*     */                 }  }
/*     */             });
/* 408 */         if (null != arrayOfMethod) {
/* 409 */           Method method1 = arrayOfMethod[0];
/* 410 */           Method method2 = arrayOfMethod[1];
/* 411 */           Method method3 = arrayOfMethod[2];
/*     */           
/* 413 */           ReflectionUtil.callMethod(null, method1, new Object[0]);
/*     */           
/* 415 */           Object object = ReflectionUtil.callMethod(null, method2, new Object[0]);
/* 416 */           if (object instanceof Boolean) {
/*     */ 
/*     */             
/* 419 */             isAWTAvailable = ((Boolean)object).equals(Boolean.FALSE);
/*     */           } else {
/* 421 */             throw new RuntimeException("JAWTUtil.isHeadlessMode() didn't return a Boolean");
/*     */           } 
/* 423 */           object = ReflectionUtil.callMethod(null, method3, new Object[0]);
/* 424 */           if (object instanceof ToolkitLock) {
/* 425 */             jawtUtilJAWTToolkitLock = (ToolkitLock)object;
/*     */           } else {
/* 427 */             throw new RuntimeException("JAWTUtil.getJAWTToolkitLock() didn't return a ToolkitLock");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 436 */       initSingletonNativeImpl(classLoader);
/*     */       
/* 438 */       registeredFactories = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */       
/* 441 */       NativeWindowFactoryImpl nativeWindowFactoryImpl = new NativeWindowFactoryImpl();
/* 442 */       nativeWindowClass = NativeWindow.class;
/* 443 */       registerFactory(nativeWindowClass, (NativeWindowFactory)nativeWindowFactoryImpl);
/* 444 */       defaultFactory = (NativeWindowFactory)nativeWindowFactoryImpl;
/*     */       
/* 446 */       if (isAWTAvailable)
/*     */       {
/* 448 */         registerFactory(ReflectionUtil.getClass("java.awt.Component", false, classLoader), (NativeWindowFactory)nativeWindowFactoryImpl);
/*     */       }
/*     */       
/* 451 */       if (DEBUG) {
/* 452 */         System.err.println("NativeWindowFactory requiresToolkitLock " + requiresToolkitLock + ", desktopHasThreadingIssues " + desktopHasThreadingIssues);
/* 453 */         System.err.println("NativeWindowFactory isAWTAvailable " + isAWTAvailable + ", defaultFactory " + nativeWindowFactoryImpl);
/*     */       } 
/*     */       
/* 456 */       GraphicsConfigurationFactory.initSingleton();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean requiresToolkitLock() {
/* 462 */     return requiresToolkitLock;
/*     */   }
/*     */   
/*     */   public static boolean isAWTAvailable() {
/* 466 */     return isAWTAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getNativeWindowType(boolean paramBoolean) {
/* 474 */     return paramBoolean ? nativeWindowingTypeCustom : nativeWindowingTypeNative;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultFactory(NativeWindowFactory paramNativeWindowFactory) {
/* 494 */     defaultFactory = paramNativeWindowFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public static NativeWindowFactory getDefaultFactory() {
/* 499 */     return defaultFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ToolkitLock getAWTToolkitLock() {
/* 510 */     return jawtUtilJAWTToolkitLock;
/*     */   }
/*     */   
/*     */   public static ToolkitLock getNullToolkitLock() {
/* 514 */     return NativeWindowFactoryImpl.getNullToolkitLock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ToolkitLock getDefaultToolkitLock() {
/* 523 */     return getDefaultToolkitLock(nativeWindowingTypeNative);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ToolkitLock getDefaultToolkitLock(String paramString) {
/* 535 */     if (requiresToolkitLock) {
/* 536 */       if (".awt" == paramString && isAWTAvailable()) {
/* 537 */         return getAWTToolkitLock();
/*     */       }
/* 539 */       return (ToolkitLock)ResourceToolkitLock.create();
/*     */     } 
/* 541 */     return NativeWindowFactoryImpl.getNullToolkitLock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractGraphicsScreen createScreen(AbstractGraphicsDevice paramAbstractGraphicsDevice, int paramInt) {
/* 550 */     String str = paramAbstractGraphicsDevice.getType();
/* 551 */     if (".x11" == str) {
/* 552 */       X11GraphicsDevice x11GraphicsDevice = (X11GraphicsDevice)paramAbstractGraphicsDevice;
/* 553 */       if (0 > paramInt) {
/* 554 */         paramInt = x11GraphicsDevice.getDefaultScreen();
/*     */       }
/* 556 */       return (AbstractGraphicsScreen)new X11GraphicsScreen(x11GraphicsDevice, paramInt);
/*     */     } 
/* 558 */     if (0 > paramInt) {
/* 559 */       paramInt = 0;
/*     */     }
/* 561 */     if (".awt" == str) {
/* 562 */       AWTGraphicsDevice aWTGraphicsDevice = (AWTGraphicsDevice)paramAbstractGraphicsDevice;
/* 563 */       return (AbstractGraphicsScreen)new AWTGraphicsScreen(aWTGraphicsDevice);
/*     */     } 
/* 565 */     return new DefaultGraphicsScreen(paramAbstractGraphicsDevice, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeWindowFactory getFactory(Class<?> paramClass) throws IllegalArgumentException {
/* 575 */     if (nativeWindowClass.isAssignableFrom(paramClass)) {
/* 576 */       return registeredFactories.get(nativeWindowClass);
/*     */     }
/* 578 */     Class<?> clazz = paramClass;
/* 579 */     while (clazz != null) {
/* 580 */       NativeWindowFactory nativeWindowFactory = registeredFactories.get(clazz);
/* 581 */       if (nativeWindowFactory != null) {
/* 582 */         return nativeWindowFactory;
/*     */       }
/* 584 */       clazz = clazz.getSuperclass();
/*     */     } 
/* 586 */     throw new IllegalArgumentException("No registered NativeWindowFactory for class " + paramClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void registerFactory(Class<?> paramClass, NativeWindowFactory paramNativeWindowFactory) {
/* 593 */     if (DEBUG) {
/* 594 */       System.err.println("NativeWindowFactory.registerFactory() " + paramClass + " -> " + paramNativeWindowFactory);
/*     */     }
/* 596 */     registeredFactories.put(paramClass, paramNativeWindowFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeWindow getNativeWindow(Object paramObject, AbstractGraphicsConfiguration paramAbstractGraphicsConfiguration) throws IllegalArgumentException, NativeWindowException {
/* 619 */     if (paramObject == null) {
/* 620 */       throw new IllegalArgumentException("Null window object");
/*     */     }
/*     */     
/* 623 */     return getFactory(paramObject.getClass()).getNativeWindowImpl(paramObject, paramAbstractGraphicsConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OffscreenLayerSurface getOffscreenLayerSurface(NativeSurface paramNativeSurface, boolean paramBoolean) {
/* 645 */     if (paramNativeSurface instanceof OffscreenLayerSurface && (!paramBoolean || paramNativeSurface instanceof OffscreenLayerOption)) {
/*     */       
/* 647 */       OffscreenLayerSurface offscreenLayerSurface = (OffscreenLayerSurface)paramNativeSurface;
/* 648 */       return (!paramBoolean || ((OffscreenLayerOption)offscreenLayerSurface).isOffscreenLayerSurfaceEnabled()) ? offscreenLayerSurface : null;
/*     */     } 
/* 650 */     if (paramNativeSurface instanceof NativeWindow) {
/* 651 */       NativeWindow nativeWindow = ((NativeWindow)paramNativeSurface).getParent();
/* 652 */       while (null != nativeWindow) {
/* 653 */         if (nativeWindow instanceof OffscreenLayerSurface && (!paramBoolean || nativeWindow instanceof OffscreenLayerOption)) {
/*     */           
/* 655 */           OffscreenLayerSurface offscreenLayerSurface = (OffscreenLayerSurface)nativeWindow;
/* 656 */           return (!paramBoolean || ((OffscreenLayerOption)offscreenLayerSurface).isOffscreenLayerSurfaceEnabled()) ? offscreenLayerSurface : null;
/*     */         } 
/* 658 */         nativeWindow = nativeWindow.getParent();
/*     */       } 
/*     */     } 
/* 661 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNativeVisualIDValidForProcessing(int paramInt) {
/* 679 */     return (".x11" != getNativeWindowType(false) || 0 != paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getDefaultDisplayConnection() {
/* 684 */     return getDefaultDisplayConnection(getNativeWindowType(true));
/*     */   }
/*     */   public static String getDefaultDisplayConnection(String paramString) {
/* 687 */     if (".x11" == paramString) {
/* 688 */       return X11Util.getNullDisplayName();
/*     */     }
/* 690 */     return "decon";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractGraphicsDevice createDevice(String paramString, boolean paramBoolean) {
/* 701 */     return createDevice(getNativeWindowType(true), paramString, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractGraphicsDevice createDevice(String paramString1, String paramString2, boolean paramBoolean) {
/* 714 */     if (".x11" == paramString1) {
/* 715 */       if (paramBoolean) {
/* 716 */         return (AbstractGraphicsDevice)new X11GraphicsDevice(paramString2, 0, null);
/*     */       }
/* 718 */       return (AbstractGraphicsDevice)new X11GraphicsDevice(paramString2, 0);
/*     */     } 
/* 720 */     if (".windows" == paramString1)
/* 721 */       return (AbstractGraphicsDevice)new WindowsGraphicsDevice(0); 
/* 722 */     if (".macosx" == paramString1)
/* 723 */       return (AbstractGraphicsDevice)new MacOSXGraphicsDevice(0); 
/* 724 */     if (".ios" == paramString1)
/* 725 */       return (AbstractGraphicsDevice)new IOSGraphicsDevice(0); 
/* 726 */     if (".egl" == paramString1) {
/*     */       EGLGraphicsDevice eGLGraphicsDevice;
/* 728 */       if (paramBoolean) {
/* 729 */         Object object = null;
/*     */         
/*     */         try {
/* 732 */           object = ReflectionUtil.callStaticMethod("jogamp.opengl.egl.EGLDisplayUtil", "eglCreateEGLGraphicsDevice", new Class[] { Long.class, String.class, Integer.class }, new Object[] {
/*     */                 
/* 734 */                 Long.valueOf(0L), DefaultGraphicsDevice.getDefaultDisplayConnection(paramString1), Integer.valueOf(0) }, NativeWindowFactory.class
/* 735 */               .getClassLoader());
/* 736 */         } catch (Exception exception) {
/* 737 */           throw new NativeWindowException("EGLDisplayUtil.eglCreateEGLGraphicsDevice failed", exception);
/*     */         } 
/* 739 */         if (object instanceof EGLGraphicsDevice) {
/* 740 */           eGLGraphicsDevice = (EGLGraphicsDevice)object;
/* 741 */           eGLGraphicsDevice.open();
/*     */         } else {
/* 743 */           throw new NativeWindowException("EGLDisplayUtil.eglCreateEGLGraphicsDevice failed");
/*     */         } 
/*     */       } else {
/* 746 */         eGLGraphicsDevice = new EGLGraphicsDevice(0L, paramString2, 0);
/*     */       } 
/* 748 */       return (AbstractGraphicsDevice)eGLGraphicsDevice;
/* 749 */     }  if (".awt" == paramString1) {
/* 750 */       throw new UnsupportedOperationException("n/a for windowing system: " + paramString1);
/*     */     }
/* 752 */     return new DefaultGraphicsDevice(paramString1, paramString2, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeWindow createWrappedWindow(AbstractGraphicsScreen paramAbstractGraphicsScreen, long paramLong1, long paramLong2, UpstreamWindowHookMutableSizePos paramUpstreamWindowHookMutableSizePos) {
/* 771 */     Capabilities capabilities = new Capabilities();
/* 772 */     DefaultGraphicsConfiguration defaultGraphicsConfiguration = new DefaultGraphicsConfiguration(paramAbstractGraphicsScreen, capabilities, capabilities);
/* 773 */     return (NativeWindow)new WrappedWindow(defaultGraphicsConfiguration, paramLong1, paramUpstreamWindowHookMutableSizePos, true, paramLong2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point getLocationOnScreen(NativeWindow paramNativeWindow) {
/* 784 */     String str = getNativeWindowType(true);
/* 785 */     if (".x11" == str)
/* 786 */       return X11Lib.GetRelativeLocation(paramNativeWindow.getDisplayHandle(), paramNativeWindow.getScreenIndex(), paramNativeWindow.getWindowHandle(), 0L, 0, 0); 
/* 787 */     if (".windows" == str)
/* 788 */       return GDIUtil.GetRelativeLocation(paramNativeWindow.getWindowHandle(), 0L, 0, 0); 
/* 789 */     if (".macosx" == str)
/* 790 */       return OSXUtil.GetLocationOnScreen(paramNativeWindow.getWindowHandle(), 0, 0); 
/* 791 */     if (".ios" == str) {
/* 792 */       return IOSUtil.GetLocationOnScreen(paramNativeWindow.getWindowHandle(), 0, 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 802 */     throw new UnsupportedOperationException("n/a for windowing system: " + str);
/*     */   }
/*     */   
/*     */   protected abstract NativeWindow getNativeWindowImpl(Object paramObject, AbstractGraphicsConfiguration paramAbstractGraphicsConfiguration) throws IllegalArgumentException;
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/NativeWindowFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */