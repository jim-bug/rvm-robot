/*    */ package com.jogamp.nativewindow.macosx;
/*    */ 
/*    */ import com.jogamp.nativewindow.DefaultGraphicsDevice;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacOSXGraphicsDevice
/*    */   extends DefaultGraphicsDevice
/*    */   implements Cloneable
/*    */ {
/*    */   public MacOSXGraphicsDevice(int paramInt) {
/* 43 */     super(".macosx", "decon", paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 48 */     return super.clone();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/macosx/MacOSXGraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */