/*    */ package com.jogamp.nativewindow.ios;
/*    */ 
/*    */ import com.jogamp.nativewindow.DefaultGraphicsDevice;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IOSGraphicsDevice
/*    */   extends DefaultGraphicsDevice
/*    */   implements Cloneable
/*    */ {
/*    */   public IOSGraphicsDevice(int paramInt) {
/* 38 */     super(".ios", "decon", paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 43 */     return super.clone();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/ios/IOSGraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */