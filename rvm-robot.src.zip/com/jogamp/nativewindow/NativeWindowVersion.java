/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ import com.jogamp.common.GlueGenVersion;
/*    */ import com.jogamp.common.util.JogampVersion;
/*    */ import com.jogamp.common.util.VersionUtil;
/*    */ import java.util.jar.Manifest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeWindowVersion
/*    */   extends JogampVersion
/*    */ {
/*    */   protected static volatile NativeWindowVersion jogampCommonVersionInfo;
/*    */   
/*    */   protected NativeWindowVersion(String paramString, Manifest paramManifest) {
/* 42 */     super(paramString, paramManifest);
/*    */   }
/*    */   
/*    */   public static NativeWindowVersion getInstance() {
/* 46 */     if (null == jogampCommonVersionInfo) {
/* 47 */       synchronized (NativeWindowVersion.class) {
/* 48 */         if (null == jogampCommonVersionInfo) {
/*    */ 
/*    */           
/* 51 */           Manifest manifest = VersionUtil.getManifest(NativeWindowVersion.class.getClassLoader(), new String[] { "com.jogamp.nativewindow", "com.jogamp.opengl" });
/* 52 */           jogampCommonVersionInfo = new NativeWindowVersion("com.jogamp.nativewindow", manifest);
/*    */         } 
/*    */       } 
/*    */     }
/* 56 */     return jogampCommonVersionInfo;
/*    */   }
/*    */   
/*    */   public static void main(String[] paramArrayOfString) {
/* 60 */     System.err.println(VersionUtil.getPlatformInfo());
/* 61 */     System.err.println(GlueGenVersion.getInstance());
/* 62 */     System.err.println(getInstance());
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/NativeWindowVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */