/*     */ package com.jogamp.nativewindow;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface VisualIDHolder
/*     */ {
/*     */   public static final int VID_UNDEFINED = 0;
/*     */   
/*     */   int getVisualID(VIDType paramVIDType) throws NativeWindowException;
/*     */   
/*     */   boolean isVisualIDSupported(VIDType paramVIDType);
/*     */   
/*     */   public enum VIDType
/*     */   {
/*  44 */     INTRINSIC(0), NATIVE(1),
/*     */     
/*  46 */     EGL_CONFIG(10),
/*     */     
/*  48 */     X11_XVISUAL(20), X11_FBCONFIG(21),
/*     */     
/*  50 */     WIN32_PFD(30);
/*     */     
/*     */     public final int id;
/*     */     
/*     */     VIDType(int param1Int1) {
/*  55 */       this.id = param1Int1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class VIDComparator
/*     */     implements Comparator<VisualIDHolder>
/*     */   {
/*     */     private final VisualIDHolder.VIDType type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public VIDComparator(VisualIDHolder.VIDType param1VIDType) {
/* 138 */       this.type = param1VIDType;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compare(VisualIDHolder param1VisualIDHolder1, VisualIDHolder param1VisualIDHolder2) {
/* 143 */       int i = param1VisualIDHolder1.getVisualID(this.type);
/* 144 */       int j = param1VisualIDHolder2.getVisualID(this.type);
/*     */       
/* 146 */       if (i > j)
/* 147 */         return 1; 
/* 148 */       if (i < j) {
/* 149 */         return -1;
/*     */       }
/* 151 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/VisualIDHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */