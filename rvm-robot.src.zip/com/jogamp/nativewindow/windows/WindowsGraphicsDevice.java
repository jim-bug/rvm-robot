/*    */ package com.jogamp.nativewindow.windows;
/*    */ 
/*    */ import com.jogamp.nativewindow.DefaultGraphicsDevice;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WindowsGraphicsDevice
/*    */   extends DefaultGraphicsDevice
/*    */   implements Cloneable
/*    */ {
/*    */   public WindowsGraphicsDevice(int paramInt) {
/* 43 */     this("decon", paramInt);
/*    */   }
/*    */   
/*    */   public WindowsGraphicsDevice(String paramString, int paramInt) {
/* 47 */     super(".windows", paramString, paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 52 */     return super.clone();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/windows/WindowsGraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */