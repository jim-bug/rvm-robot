/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ import jogamp.nativewindow.Debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AbstractGraphicsDevice
/*    */   extends Cloneable
/*    */ {
/* 49 */   public static final boolean DEBUG = Debug.debug("GraphicsDevice");
/*    */   public static final String DEFAULT_CONNECTION = "decon";
/*    */   public static final String EXTERNAL_CONNECTION = "excon";
/*    */   public static final int DEFAULT_UNIT = 0;
/*    */   
/*    */   Object clone();
/*    */   
/*    */   String getType();
/*    */   
/*    */   String getConnection();
/*    */   
/*    */   int getUnitID();
/*    */   
/*    */   String getUniqueID();
/*    */   
/*    */   long getHandle();
/*    */   
/*    */   void lock();
/*    */   
/*    */   void unlock();
/*    */   
/*    */   void validateLocked() throws RuntimeException;
/*    */   
/*    */   boolean open();
/*    */   
/*    */   boolean close();
/*    */   
/*    */   boolean isHandleOwner();
/*    */   
/*    */   void clearHandleOwner();
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/AbstractGraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */