/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ import jogamp.nativewindow.Debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ProxySurface
/*    */   extends MutableSurface
/*    */ {
/* 42 */   public static final boolean DEBUG = Debug.debug("ProxySurface");
/*    */   public static final int OPT_PROXY_OWNS_UPSTREAM_SURFACE = 64;
/*    */   public static final int OPT_PROXY_OWNS_UPSTREAM_DEVICE = 128;
/*    */   public static final int OPT_UPSTREAM_WINDOW_INVISIBLE = 256;
/*    */   public static final int OPT_UPSTREAM_SURFACELESS = 512;
/*    */   
/*    */   void setGraphicsConfiguration(AbstractGraphicsConfiguration paramAbstractGraphicsConfiguration);
/*    */   
/*    */   NativeSurface getUpstreamSurface();
/*    */   
/*    */   UpstreamSurfaceHook getUpstreamSurfaceHook();
/*    */   
/*    */   void setUpstreamSurfaceHook(UpstreamSurfaceHook paramUpstreamSurfaceHook);
/*    */   
/*    */   void enableUpstreamSurfaceHookLifecycle(boolean paramBoolean);
/*    */   
/*    */   void createNotify();
/*    */   
/*    */   void destroyNotify();
/*    */   
/*    */   StringBuilder getUpstreamOptionBits(StringBuilder paramStringBuilder);
/*    */   
/*    */   int getUpstreamOptionBits();
/*    */   
/*    */   boolean containsUpstreamOptionBits(int paramInt);
/*    */   
/*    */   void addUpstreamOptionBits(int paramInt);
/*    */   
/*    */   void clearUpstreamOptionBits(int paramInt);
/*    */   
/*    */   StringBuilder toString(StringBuilder paramStringBuilder);
/*    */   
/*    */   String toString();
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/ProxySurface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */