/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatedUpstreamSurfaceHookWithSurfaceSize
/*    */   implements UpstreamSurfaceHook
/*    */ {
/*    */   final UpstreamSurfaceHook upstream;
/*    */   final NativeSurface surface;
/*    */   
/*    */   public DelegatedUpstreamSurfaceHookWithSurfaceSize(UpstreamSurfaceHook paramUpstreamSurfaceHook, NativeSurface paramNativeSurface) {
/* 16 */     this.upstream = paramUpstreamSurfaceHook;
/* 17 */     this.surface = paramNativeSurface;
/* 18 */     if (null == paramNativeSurface) {
/* 19 */       throw new IllegalArgumentException("given surface is null");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final NativeSurface getUpstreamSurface() {
/* 31 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void create(ProxySurface paramProxySurface) {
/* 36 */     if (null != this.upstream) {
/* 37 */       this.upstream.create(paramProxySurface);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public final void destroy(ProxySurface paramProxySurface) {
/* 43 */     if (null != this.upstream) {
/* 44 */       this.upstream.destroy(paramProxySurface);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getSurfaceWidth(ProxySurface paramProxySurface) {
/* 50 */     return this.surface.getSurfaceWidth();
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getSurfaceHeight(ProxySurface paramProxySurface) {
/* 55 */     return this.surface.getSurfaceHeight();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     String str = (null != this.surface) ? (this.surface.getClass().getName() + ": 0x" + Long.toHexString(this.surface.getSurfaceHandle()) + " " + this.surface.getSurfaceWidth() + "x" + this.surface.getSurfaceHeight()) : "nil";
/* 61 */     return getClass().getSimpleName() + "[" + this.upstream + ", " + str + "]";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/DelegatedUpstreamSurfaceHookWithSurfaceSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */