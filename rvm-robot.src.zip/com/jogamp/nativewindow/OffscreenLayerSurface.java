package com.jogamp.nativewindow;

import com.jogamp.common.util.locks.RecursiveLock;
import com.jogamp.nativewindow.util.PixelRectangle;
import com.jogamp.nativewindow.util.PointImmutable;

public interface OffscreenLayerSurface {
  void attachSurfaceLayer(long paramLong) throws NativeWindowException;
  
  void detachSurfaceLayer() throws NativeWindowException;
  
  long getAttachedSurfaceLayer();
  
  boolean isSurfaceLayerAttached();
  
  void setChosenCapabilities(CapabilitiesImmutable paramCapabilitiesImmutable);
  
  RecursiveLock getLock();
  
  boolean setCursor(PixelRectangle paramPixelRectangle, PointImmutable paramPointImmutable);
  
  boolean hideCursor();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/OffscreenLayerSurface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */