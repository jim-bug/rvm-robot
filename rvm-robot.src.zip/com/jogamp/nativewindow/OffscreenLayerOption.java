package com.jogamp.nativewindow;

public interface OffscreenLayerOption {
  void setShallUseOffscreenLayer(boolean paramBoolean);
  
  boolean getShallUseOffscreenLayer();
  
  boolean isOffscreenLayerSurfaceEnabled();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/OffscreenLayerOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */