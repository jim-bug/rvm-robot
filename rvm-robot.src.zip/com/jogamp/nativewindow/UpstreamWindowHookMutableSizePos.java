/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpstreamWindowHookMutableSizePos
/*    */   extends UpstreamSurfaceHookMutableSize
/*    */ {
/*    */   int winX;
/*    */   int winY;
/*    */   int winWidth;
/*    */   int winHeight;
/*    */   
/*    */   public UpstreamWindowHookMutableSizePos(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 15 */     super(paramInt5, paramInt6);
/* 16 */     this.winX = paramInt1;
/* 17 */     this.winY = paramInt2;
/* 18 */     this.winWidth = paramInt3;
/* 19 */     this.winHeight = paramInt4;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void setWinPos(int paramInt1, int paramInt2) {
/* 24 */     this.winX = paramInt1;
/* 25 */     this.winY = paramInt2;
/*    */   }
/*    */   
/*    */   public final void setWinSize(int paramInt1, int paramInt2) {
/* 29 */     this.winWidth = paramInt1;
/* 30 */     this.winHeight = paramInt2;
/*    */ 
/*    */     
/* 33 */     setSurfaceSize(paramInt1, paramInt2);
/*    */   }
/*    */   
/*    */   public final int getX() {
/* 37 */     return this.winX;
/*    */   }
/*    */   
/*    */   public final int getY() {
/* 41 */     return this.winY;
/*    */   }
/*    */   public final int getWidth() {
/* 44 */     return this.winWidth;
/*    */   }
/*    */   public final int getHeight() {
/* 47 */     return this.winHeight;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     return getClass().getSimpleName() + "[window " + this.winX + "/" + this.winY + " " + this.winWidth + "x" + this.winHeight + ", pixel " + this.pixWidth + "x" + this.pixHeight + "]";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/UpstreamWindowHookMutableSizePos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */