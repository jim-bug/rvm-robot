/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpstreamSurfaceHookMutableSize
/*    */   implements UpstreamSurfaceHook.MutableSize
/*    */ {
/*    */   int pixWidth;
/*    */   int pixHeight;
/*    */   
/*    */   public UpstreamSurfaceHookMutableSize(int paramInt1, int paramInt2) {
/* 15 */     this.pixWidth = paramInt1;
/* 16 */     this.pixHeight = paramInt2;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void setSurfaceSize(int paramInt1, int paramInt2) {
/* 21 */     this.pixWidth = paramInt1;
/* 22 */     this.pixHeight = paramInt2;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getSurfaceWidth(ProxySurface paramProxySurface) {
/* 27 */     return this.pixWidth;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getSurfaceHeight(ProxySurface paramProxySurface) {
/* 32 */     return this.pixHeight;
/*    */   }
/*    */ 
/*    */   
/*    */   public void create(ProxySurface paramProxySurface) {}
/*    */ 
/*    */   
/*    */   public void destroy(ProxySurface paramProxySurface) {}
/*    */   
/*    */   public String toString() {
/* 42 */     return getClass().getSimpleName() + "[pixel " + this.pixWidth + "x" + this.pixHeight + "]";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final NativeSurface getUpstreamSurface() {
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/UpstreamSurfaceHookMutableSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */