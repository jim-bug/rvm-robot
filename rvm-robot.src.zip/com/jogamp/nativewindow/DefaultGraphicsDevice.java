/*     */ package com.jogamp.nativewindow;
/*     */ 
/*     */ import jogamp.nativewindow.NativeWindowFactoryImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultGraphicsDevice
/*     */   implements Cloneable, AbstractGraphicsDevice
/*     */ {
/*     */   private static final String separator = "_";
/*     */   private final String type;
/*     */   protected final String connection;
/*     */   protected final int unitID;
/*     */   protected final String uniqueID;
/*     */   protected long handle;
/*     */   protected ToolkitLock toolkitLock;
/*     */   
/*     */   public static String getDefaultDisplayConnection() {
/*  53 */     return NativeWindowFactory.getDefaultDisplayConnection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDefaultDisplayConnection(String paramString) {
/*  61 */     return NativeWindowFactory.getDefaultDisplayConnection(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultGraphicsDevice(String paramString1, String paramString2, int paramInt) {
/*  70 */     this(paramString1, paramString2, paramInt, 0L, NativeWindowFactory.getDefaultToolkitLock(paramString1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultGraphicsDevice(String paramString1, String paramString2, int paramInt, long paramLong) {
/*  80 */     this(paramString1, paramString2, paramInt, paramLong, NativeWindowFactory.getDefaultToolkitLock(paramString1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultGraphicsDevice(String paramString1, String paramString2, int paramInt, long paramLong, ToolkitLock paramToolkitLock) {
/*  90 */     this.type = paramString1;
/*  91 */     this.connection = paramString2;
/*  92 */     this.unitID = paramInt;
/*  93 */     this.uniqueID = getUniqueID(paramString1, paramString2, paramInt);
/*  94 */     this.handle = paramLong;
/*  95 */     this.toolkitLock = (null != paramToolkitLock) ? paramToolkitLock : NativeWindowFactoryImpl.getNullToolkitLock();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 101 */       return super.clone();
/* 102 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/* 103 */       throw new NativeWindowException(cloneNotSupportedException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getType() {
/* 109 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getConnection() {
/* 114 */     return this.connection;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getUnitID() {
/* 119 */     return this.unitID;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getUniqueID() {
/* 124 */     return this.uniqueID;
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getHandle() {
/* 129 */     return this.handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void lock() {
/* 143 */     this.toolkitLock.lock();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void validateLocked() throws RuntimeException {
/* 148 */     this.toolkitLock.validateLocked();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void unlock() {
/* 162 */     this.toolkitLock.unlock();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean open() {
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean close() {
/* 172 */     this.toolkitLock.dispose();
/* 173 */     if (0L != this.handle) {
/* 174 */       this.handle = 0L;
/* 175 */       return true;
/*     */     } 
/* 177 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHandleOwner() {
/* 182 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearHandleOwner() {}
/*     */ 
/*     */   
/*     */   public String toString() {
/* 191 */     return getClass().getSimpleName() + "[type " + getType() + ", connection " + getConnection() + ", unitID " + getUnitID() + ", handle 0x" + Long.toHexString(getHandle()) + ", owner " + isHandleOwner() + ", " + this.toolkitLock + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final long setHandle(long paramLong) {
/* 199 */     long l = this.handle;
/* 200 */     this.handle = paramLong;
/* 201 */     return l;
/*     */   }
/*     */   
/*     */   protected Object getHandleOwnership() {
/* 205 */     return null;
/*     */   }
/*     */   protected Object setHandleOwnership(Object paramObject) {
/* 208 */     return null;
/*     */   }
/*     */   
/*     */   public static final void swapDeviceHandleAndOwnership(DefaultGraphicsDevice paramDefaultGraphicsDevice1, DefaultGraphicsDevice paramDefaultGraphicsDevice2) {
/* 212 */     paramDefaultGraphicsDevice1.lock();
/*     */     try {
/* 214 */       paramDefaultGraphicsDevice2.lock();
/*     */       try {
/* 216 */         long l1 = paramDefaultGraphicsDevice1.getHandle();
/* 217 */         long l2 = paramDefaultGraphicsDevice2.setHandle(l1);
/* 218 */         paramDefaultGraphicsDevice1.setHandle(l2);
/* 219 */         Object object1 = paramDefaultGraphicsDevice1.getHandleOwnership();
/* 220 */         Object object2 = paramDefaultGraphicsDevice2.setHandleOwnership(object1);
/* 221 */         paramDefaultGraphicsDevice1.setHandleOwnership(object2);
/*     */       } finally {
/* 223 */         paramDefaultGraphicsDevice2.unlock();
/*     */       } 
/*     */     } finally {
/* 226 */       paramDefaultGraphicsDevice1.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ToolkitLock setToolkitLock(ToolkitLock paramToolkitLock) {
/* 243 */     ToolkitLock toolkitLock = this.toolkitLock;
/* 244 */     toolkitLock.lock();
/*     */     try {
/* 246 */       this.toolkitLock = (null == paramToolkitLock) ? NativeWindowFactoryImpl.getNullToolkitLock() : paramToolkitLock;
/*     */     } finally {
/* 248 */       toolkitLock.unlock();
/*     */     } 
/* 250 */     return toolkitLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ToolkitLock getToolkitLock() {
/* 260 */     return this.toolkitLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getUniqueID(String paramString1, String paramString2, int paramInt) {
/* 268 */     return (paramString1 + "_" + paramString2 + "_" + paramInt).intern();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/DefaultGraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */