package com.jogamp.nativewindow;

public interface AbstractGraphicsConfiguration extends VisualIDHolder, Cloneable {
  Object clone();
  
  AbstractGraphicsScreen getScreen();
  
  CapabilitiesImmutable getChosenCapabilities();
  
  CapabilitiesImmutable getRequestedCapabilities();
  
  AbstractGraphicsConfiguration getNativeGraphicsConfiguration();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/AbstractGraphicsConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */