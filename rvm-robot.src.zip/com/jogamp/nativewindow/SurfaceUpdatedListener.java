package com.jogamp.nativewindow;

public interface SurfaceUpdatedListener {
  void surfaceUpdated(Object paramObject, NativeSurface paramNativeSurface, long paramLong);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/SurfaceUpdatedListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */