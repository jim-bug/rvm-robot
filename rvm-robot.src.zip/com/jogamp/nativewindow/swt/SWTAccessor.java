/*     */ package com.jogamp.nativewindow.swt;
/*     */ 
/*     */ import com.jogamp.common.os.Platform;
/*     */ import com.jogamp.common.util.ReflectionUtil;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import com.jogamp.common.util.VersionNumber;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsDevice;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsScreen;
/*     */ import com.jogamp.nativewindow.NativeWindowException;
/*     */ import com.jogamp.nativewindow.NativeWindowFactory;
/*     */ import com.jogamp.nativewindow.macosx.MacOSXGraphicsDevice;
/*     */ import com.jogamp.nativewindow.util.Point;
/*     */ import com.jogamp.nativewindow.windows.WindowsGraphicsDevice;
/*     */ import com.jogamp.nativewindow.x11.X11GraphicsDevice;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.PrivilegedAction;
/*     */ import jogamp.nativewindow.Debug;
/*     */ import jogamp.nativewindow.macosx.OSXUtil;
/*     */ import jogamp.nativewindow.x11.X11Lib;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.GCData;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Scrollable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SWTAccessor
/*     */ {
/*     */   static {
/*     */     boolean bool;
/*     */   }
/*     */   
/*  63 */   private static final boolean DEBUG = Debug.debug("SWT");
/*     */   
/*     */   private static final Method swt_scrollable_clientAreaInPixels;
/*     */   
/*     */   private static final Method swt_control_locationInPixels;
/*     */   
/*     */   private static final Method swt_control_sizeInPixels;
/*     */   private static final Method swt_dpiutil_getScalingFactor;
/*     */   private static final Field swt_control_handle;
/*     */   private static final boolean swt_uses_long_handles;
/*  73 */   private static Object swt_osx_init = new Object();
/*  74 */   private static Field swt_osx_control_view = null;
/*  75 */   private static Field swt_osx_view_id = null;
/*     */   
/*     */   private static final String nwt;
/*     */   
/*     */   public static final boolean isOSX;
/*     */   
/*     */   public static final boolean isWindows;
/*     */   
/*     */   public static final boolean isX11;
/*     */   
/*     */   public static final boolean isX11GTK;
/*     */   
/*     */   private static final String str_handle = "handle";
/*     */   
/*     */   private static final String str_osx_view = "view";
/*     */   
/*     */   private static final String str_osx_id = "id";
/*     */   
/*     */   private static final Method swt_control_internal_new_GC;
/*     */   
/*     */   private static final Method swt_control_internal_dispose_GC;
/*     */   
/*     */   private static final String str_internal_new_GC = "internal_new_GC";
/*     */   private static final String str_internal_dispose_GC = "internal_dispose_GC";
/*     */   private static final String str_OS_gtk_class = "org.eclipse.swt.internal.gtk.OS";
/*     */   private static final String str_GTK_gtk_class = "org.eclipse.swt.internal.gtk.GTK";
/*     */   private static final String str_GTK3_gtk_class = "org.eclipse.swt.internal.gtk3.GTK3";
/*     */   private static final String str_GDK_gtk_class = "org.eclipse.swt.internal.gtk.GDK";
/*     */   public static final Class<?> OS_gtk_class;
/*     */   private static final String str_OS_gtk_version = "GTK_VERSION";
/*     */   public static final VersionNumber OS_gtk_version;
/*     */   private static final Method OS_gtk_widget_realize;
/*     */   private static final Method OS_gtk_widget_unrealize;
/*     */   private static final Method OS_GTK_WIDGET_WINDOW;
/*     */   private static final Method OS_gtk_widget_get_window;
/*     */   private static final Method OS_gdk_x11_drawable_get_xdisplay;
/*     */   private static final Method OS_gdk_x11_display_get_xdisplay;
/*     */   private static final Method OS_gdk_window_get_display;
/*     */   private static final Method OS_gdk_x11_drawable_get_xid;
/*     */   private static final Method OS_gdk_x11_window_get_xid;
/*     */   private static final String str_gtk_widget_realize = "gtk_widget_realize";
/*     */   private static final String str_gtk_widget_unrealize = "gtk_widget_unrealize";
/*     */   private static final String str_GTK_WIDGET_WINDOW = "GTK_WIDGET_WINDOW";
/*     */   private static final String str_gtk_widget_get_window = "gtk_widget_get_window";
/*     */   private static final String str_gdk_x11_drawable_get_xdisplay = "gdk_x11_drawable_get_xdisplay";
/*     */   private static final String str_gdk_x11_display_get_xdisplay = "gdk_x11_display_get_xdisplay";
/*     */   private static final String str_gdk_window_get_display = "gdk_window_get_display";
/*     */   private static final String str_gdk_x11_drawable_get_xid = "gdk_x11_drawable_get_xid";
/*     */   private static final String str_gdk_x11_window_get_xid = "gdk_x11_window_get_xid";
/* 124 */   private static final VersionNumber GTK_VERSION_2_14_0 = new VersionNumber(2, 14, 0);
/* 125 */   private static final VersionNumber GTK_VERSION_2_24_0 = new VersionNumber(2, 24, 0);
/* 126 */   private static final VersionNumber GTK_VERSION_2_90_0 = new VersionNumber(2, 90, 0);
/* 127 */   private static final VersionNumber GTK_VERSION_3_0_0 = new VersionNumber(3, 0, 0);
/*     */ 
/*     */ 
/*     */   
/*     */   private static VersionNumber GTK_VERSION(int paramInt) {
/* 132 */     int i = paramInt & 0xFF;
/* 133 */     int j = paramInt >> 8 & 0xFF;
/* 134 */     int k = paramInt >> 16 & 0xFF;
/* 135 */     return new VersionNumber(k, j, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 143 */     SecurityUtil.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 146 */             NativeWindowFactory.initSingleton();
/* 147 */             return null;
/*     */           }
/*     */         });
/* 150 */     nwt = NativeWindowFactory.getNativeWindowType(false);
/* 151 */     isOSX = (".macosx" == nwt);
/* 152 */     isWindows = (".windows" == nwt);
/* 153 */     isX11 = (".x11" == nwt);
/* 154 */     int i = SWT.getVersion();
/*     */     
/* 156 */     if (DEBUG) {
/* 157 */       System.err.println("SWT: Platform: " + SWT.getPlatform() + ", Version: " + i);
/*     */     }
/*     */     
/* 160 */     Method method1 = null;
/*     */     try {
/* 162 */       method1 = Control.class.getDeclaredMethod("getLocationInPixels", new Class[0]);
/* 163 */       method1.setAccessible(true);
/* 164 */     } catch (Exception exception) {
/* 165 */       method1 = null;
/* 166 */       if (DEBUG) {
/* 167 */         System.err.println("SWT: getLocationInPixels not implemented: " + exception.getMessage());
/*     */       }
/*     */     } 
/* 170 */     swt_control_locationInPixels = method1;
/*     */     
/* 172 */     method1 = null;
/*     */     try {
/* 174 */       method1 = Control.class.getDeclaredMethod("getSizeInPixels", new Class[0]);
/* 175 */       method1.setAccessible(true);
/* 176 */     } catch (Exception exception) {
/* 177 */       method1 = null;
/* 178 */       if (DEBUG) {
/* 179 */         System.err.println("SWT: getSizeInPixels not implemented: " + exception.getMessage());
/*     */       }
/*     */     } 
/* 182 */     swt_control_sizeInPixels = method1;
/*     */     
/* 184 */     method1 = null;
/*     */     try {
/* 186 */       method1 = Scrollable.class.getDeclaredMethod("getClientAreaInPixels", new Class[0]);
/* 187 */       method1.setAccessible(true);
/* 188 */     } catch (Exception exception) {
/* 189 */       method1 = null;
/* 190 */       if (DEBUG) {
/* 191 */         System.err.println("SWT: getClientAreaInPixels not implemented: " + exception.getMessage());
/*     */       }
/*     */     } 
/* 194 */     swt_scrollable_clientAreaInPixels = method1;
/*     */     
/* 196 */     method1 = null;
/*     */     try {
/* 198 */       method1 = DPIUtil.class.getDeclaredMethod("getScalingFactor", new Class[0]);
/* 199 */       method1.setAccessible(true);
/* 200 */     } catch (Exception exception) {
/* 201 */       method1 = null;
/* 202 */       if (DEBUG) {
/* 203 */         System.err.println("SWT: getScalingFactor not implemented: " + exception.getMessage());
/*     */       }
/*     */     } 
/* 206 */     swt_dpiutil_getScalingFactor = method1;
/*     */     
/* 208 */     Field field = null;
/* 209 */     if (!isOSX) {
/*     */       try {
/* 211 */         field = Control.class.getField("handle");
/* 212 */       } catch (Exception exception) {
/* 213 */         throw new NativeWindowException(exception);
/*     */       } 
/*     */     }
/* 216 */     swt_control_handle = field;
/*     */ 
/*     */     
/* 219 */     if (null != swt_control_handle) {
/* 220 */       bool = swt_control_handle.getGenericType().toString().equals(long.class.toString());
/*     */     } else {
/* 222 */       bool = Platform.is64Bit();
/*     */     } 
/* 224 */     swt_uses_long_handles = bool;
/*     */ 
/*     */ 
/*     */     
/* 228 */     method1 = null;
/*     */     try {
/* 230 */       method1 = ReflectionUtil.getMethod(Control.class, "internal_new_GC", new Class[] { GCData.class });
/* 231 */     } catch (Exception exception) {
/* 232 */       throw new NativeWindowException(exception);
/*     */     } 
/* 234 */     swt_control_internal_new_GC = method1;
/*     */     
/* 236 */     method1 = null;
/*     */     try {
/* 238 */       if (swt_uses_long_handles) {
/* 239 */         method1 = Control.class.getDeclaredMethod("internal_dispose_GC", new Class[] { long.class, GCData.class });
/*     */       } else {
/* 241 */         method1 = Control.class.getDeclaredMethod("internal_dispose_GC", new Class[] { int.class, GCData.class });
/*     */       } 
/* 243 */     } catch (NoSuchMethodException noSuchMethodException) {
/* 244 */       throw new NativeWindowException(noSuchMethodException);
/*     */     } 
/* 246 */     swt_control_internal_dispose_GC = method1;
/*     */     
/* 248 */     Class<?> clazz = null;
/* 249 */     VersionNumber versionNumber = new VersionNumber(0, 0, 0);
/* 250 */     Method method2 = null, method3 = null, method4 = null, method5 = null, method6 = null, method7 = null, method8 = null, method9 = null, method10 = null;
/* 251 */     Object object1 = null, object2 = null;
/* 252 */     Class clazz1 = (Class)(swt_uses_long_handles ? long.class : int.class);
/* 253 */     if (isX11) {
/*     */       
/*     */       try { Field field1;
/* 256 */         ClassLoader classLoader = SWTAccessor.class.getClassLoader();
/* 257 */         clazz = ReflectionUtil.getClass("org.eclipse.swt.internal.gtk.OS", false, classLoader);
/*     */         
/* 259 */         Class<?> clazz2 = clazz;
/*     */         try {
/* 261 */           field1 = clazz.getField("GTK_VERSION");
/* 262 */         } catch (NoSuchFieldException noSuchFieldException) {
/*     */ 
/*     */           
/* 265 */           clazz = ReflectionUtil.getClass("org.eclipse.swt.internal.gtk.GTK", false, classLoader);
/* 266 */           field1 = clazz.getField("GTK_VERSION");
/* 267 */           clazz2 = ReflectionUtil.getClass("org.eclipse.swt.internal.gtk.GDK", false, classLoader);
/*     */         } 
/* 269 */         versionNumber = GTK_VERSION(field1.getInt(null));
/* 270 */         if (DEBUG) {
/* 271 */           System.err.println("SWT: GTK Version: " + versionNumber.toString());
/*     */         }
/* 273 */         method2 = clazz.getDeclaredMethod("gtk_widget_realize", new Class[] { clazz1 });
/* 274 */         if (versionNumber.compareTo(GTK_VERSION_2_14_0) >= 0) {
/* 275 */           if (i < 4944) {
/* 276 */             method5 = clazz.getDeclaredMethod("gtk_widget_get_window", new Class[] { clazz1 });
/*     */           } else {
/* 278 */             Class clazz3 = ReflectionUtil.getClass("org.eclipse.swt.internal.gtk3.GTK3", false, classLoader);
/* 279 */             method5 = clazz3.getDeclaredMethod("gtk_widget_get_window", new Class[] { clazz1 });
/*     */           } 
/*     */         } else {
/* 282 */           method4 = clazz.getDeclaredMethod("GTK_WIDGET_WINDOW", new Class[] { clazz1 });
/*     */         } 
/* 284 */         if (versionNumber.compareTo(GTK_VERSION_2_24_0) >= 0) {
/* 285 */           method7 = clazz2.getDeclaredMethod("gdk_x11_display_get_xdisplay", new Class[] { clazz1 });
/* 286 */           method8 = clazz2.getDeclaredMethod("gdk_window_get_display", new Class[] { clazz1 });
/*     */         } else {
/* 288 */           method6 = clazz.getDeclaredMethod("gdk_x11_drawable_get_xdisplay", new Class[] { clazz1 });
/*     */         } 
/* 290 */         if (versionNumber.compareTo(GTK_VERSION_3_0_0) >= 0) {
/* 291 */           method10 = clazz2.getDeclaredMethod("gdk_x11_window_get_xid", new Class[] { clazz1 });
/*     */         } else {
/* 293 */           method9 = clazz.getDeclaredMethod("gdk_x11_drawable_get_xid", new Class[] { clazz1 });
/*     */         }  }
/* 295 */       catch (Exception exception) { throw new NativeWindowException(exception); }
/*     */       
/*     */       try {
/* 298 */         method3 = clazz.getDeclaredMethod("gtk_widget_unrealize", new Class[] { clazz1 });
/* 299 */       } catch (Exception exception) {}
/*     */     } 
/* 301 */     OS_gtk_class = clazz;
/* 302 */     OS_gtk_version = versionNumber;
/* 303 */     OS_gtk_widget_realize = method2;
/* 304 */     OS_gtk_widget_unrealize = method3;
/* 305 */     OS_GTK_WIDGET_WINDOW = method4;
/* 306 */     OS_gtk_widget_get_window = method5;
/* 307 */     OS_gdk_x11_drawable_get_xdisplay = method6;
/* 308 */     OS_gdk_x11_display_get_xdisplay = method7;
/* 309 */     OS_gdk_window_get_display = method8;
/* 310 */     OS_gdk_x11_drawable_get_xid = method9;
/* 311 */     OS_gdk_x11_window_get_xid = method10;
/*     */     
/* 313 */     isX11GTK = (isX11 && null != OS_gtk_class);
/*     */     
/* 315 */     if (DEBUG) {
/* 316 */       printInfo(System.err, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initSingleton() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Number getIntOrLong(long paramLong) {
/* 331 */     if (swt_uses_long_handles) {
/* 332 */       return Long.valueOf(paramLong);
/*     */     }
/* 334 */     return Integer.valueOf((int)paramLong);
/*     */   }
/*     */   
/*     */   private static void callStaticMethodL2V(Method paramMethod, long paramLong) {
/* 338 */     ReflectionUtil.callMethod(null, paramMethod, new Object[] { getIntOrLong(paramLong) });
/*     */   }
/*     */ 
/*     */   
/*     */   private static void callStaticMethodLL2V(Method paramMethod, long paramLong1, long paramLong2) {
/* 343 */     ReflectionUtil.callMethod(null, paramMethod, new Object[] { getIntOrLong(paramLong1), getIntOrLong(paramLong2) });
/*     */   }
/*     */ 
/*     */   
/*     */   private static void callStaticMethodLLZ2V(Method paramMethod, long paramLong1, long paramLong2, boolean paramBoolean) {
/* 348 */     ReflectionUtil.callMethod(null, paramMethod, new Object[] { getIntOrLong(paramLong1), getIntOrLong(paramLong2), Boolean.valueOf(paramBoolean) });
/*     */   }
/*     */   
/*     */   private static long callStaticMethodL2L(Method paramMethod, long paramLong) {
/* 352 */     Object object = ReflectionUtil.callMethod(null, paramMethod, new Object[] { getIntOrLong(paramLong) });
/* 353 */     if (object instanceof Number) {
/* 354 */       return ((Number)object).longValue();
/*     */     }
/* 356 */     throw new InternalError("SWT method " + paramMethod.getName() + " didn't return int or long but " + object.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUsingLongHandles() {
/* 365 */     return swt_uses_long_handles;
/*     */   }
/*     */   
/* 368 */   public static boolean useX11GTK() { return isX11GTK; } public static VersionNumber GTK_VERSION() {
/* 369 */     return OS_gtk_version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long gdk_widget_get_window(long paramLong) {
/*     */     long l;
/* 377 */     if (OS_gtk_version.compareTo(GTK_VERSION_2_14_0) >= 0) {
/* 378 */       l = callStaticMethodL2L(OS_gtk_widget_get_window, paramLong);
/*     */     } else {
/* 380 */       l = callStaticMethodL2L(OS_GTK_WIDGET_WINDOW, paramLong);
/*     */     } 
/* 382 */     if (0L == l) {
/* 383 */       throw new NativeWindowException("Null gtk-window-handle of SWT handle 0x" + Long.toHexString(paramLong));
/*     */     }
/* 385 */     return l;
/*     */   }
/*     */   
/*     */   public static long gdk_window_get_xdisplay(long paramLong) {
/*     */     long l;
/* 390 */     if (OS_gtk_version.compareTo(GTK_VERSION_2_24_0) >= 0) {
/* 391 */       long l1 = callStaticMethodL2L(OS_gdk_window_get_display, paramLong);
/* 392 */       if (0L == l1) {
/* 393 */         throw new NativeWindowException("Null display-handle of gtk-window-handle 0x" + Long.toHexString(paramLong));
/*     */       }
/* 395 */       l = callStaticMethodL2L(OS_gdk_x11_display_get_xdisplay, l1);
/*     */     } else {
/* 397 */       l = callStaticMethodL2L(OS_gdk_x11_drawable_get_xdisplay, paramLong);
/*     */     } 
/* 399 */     if (0L == l) {
/* 400 */       throw new NativeWindowException("Null x11-display-handle of gtk-window-handle 0x" + Long.toHexString(paramLong));
/*     */     }
/* 402 */     return l;
/*     */   }
/*     */   
/*     */   public static long gdk_window_get_xwindow(long paramLong) {
/*     */     long l;
/* 407 */     if (OS_gtk_version.compareTo(GTK_VERSION_3_0_0) >= 0) {
/* 408 */       l = callStaticMethodL2L(OS_gdk_x11_window_get_xid, paramLong);
/*     */     } else {
/* 410 */       l = callStaticMethodL2L(OS_gdk_x11_drawable_get_xid, paramLong);
/*     */     } 
/* 412 */     if (0L == l) {
/* 413 */       throw new NativeWindowException("Null x11-window-handle of gtk-window-handle 0x" + Long.toHexString(paramLong));
/*     */     }
/* 415 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printInfo(PrintStream paramPrintStream, Display paramDisplay) {
/* 422 */     paramPrintStream.println("SWT: Platform: " + SWT.getPlatform() + ", Version " + SWT.getVersion());
/* 423 */     paramPrintStream.println("SWT: isX11 " + isX11 + ", isX11GTK " + isX11GTK + " (GTK Version: " + OS_gtk_version + ")");
/* 424 */     paramPrintStream.println("SWT: isOSX " + isOSX + ", isWindows " + isWindows);
/* 425 */     paramPrintStream.println("SWT: DeviceZoom: " + DPIUtil.getDeviceZoom() + ", deviceZoomScalingFactor " + getDeviceZoomScalingFactor());
/* 426 */     Point point = (null != paramDisplay) ? paramDisplay.getDPI() : null;
/* 427 */     paramPrintStream.println("SWT: Display.DPI " + point + "; DPIUtil: autoScalingFactor " + 
/* 428 */         getAutoScalingFactor() + " (use-swt " + ((null != swt_dpiutil_getScalingFactor) ? 1 : 0) + "), useCairoAutoScale " + 
/* 429 */         DPIUtil.useCairoAutoScale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getAutoScalingFactor() throws NativeWindowException {
/* 442 */     if (null != swt_dpiutil_getScalingFactor) {
/*     */       try {
/* 444 */         return ((Float)swt_dpiutil_getScalingFactor.invoke(null, new Object[0])).floatValue();
/* 445 */       } catch (Throwable throwable) {
/* 446 */         throw new NativeWindowException(throwable);
/*     */       } 
/*     */     }
/*     */     
/* 450 */     int i = DPIUtil.getDeviceZoom();
/* 451 */     if (100 == i || DPIUtil.useCairoAutoScale()) {
/* 452 */       return 1.0F;
/*     */     }
/* 454 */     return i / 100.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int autoScaleUp(int paramInt) {
/* 463 */     int i = DPIUtil.getDeviceZoom();
/* 464 */     if (100 == i || DPIUtil.useCairoAutoScale()) {
/* 465 */       return paramInt;
/*     */     }
/* 467 */     float f = i / 100.0F;
/* 468 */     return Math.round(paramInt * f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int autoScaleDown(int paramInt) {
/* 477 */     int i = DPIUtil.getDeviceZoom();
/* 478 */     if (100 == i || DPIUtil.useCairoAutoScale()) {
/* 479 */       return paramInt;
/*     */     }
/* 481 */     float f = i / 100.0F;
/* 482 */     return Math.round(paramInt / f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getDeviceZoomScalingFactor() {
/* 501 */     int i = DPIUtil.getDeviceZoom();
/* 502 */     if (100 == i) {
/* 503 */       return 1.0F;
/*     */     }
/* 505 */     return i / 100.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int deviceZoomScaleUp(int paramInt) {
/* 519 */     int i = DPIUtil.getDeviceZoom();
/* 520 */     if (100 == i) {
/* 521 */       return paramInt;
/*     */     }
/* 523 */     float f = i / 100.0F;
/* 524 */     return Math.round(paramInt * f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int deviceZoomScaleDown(int paramInt) {
/* 538 */     int i = DPIUtil.getDeviceZoom();
/* 539 */     if (100 == i) {
/* 540 */       return paramInt;
/*     */     }
/* 542 */     float f = i / 100.0F;
/* 543 */     return Math.round(paramInt / f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point deviceZoomScaleUp(Point paramPoint) {
/* 557 */     int i = DPIUtil.getDeviceZoom();
/* 558 */     if (100 == i || null == paramPoint) {
/* 559 */       return paramPoint;
/*     */     }
/* 561 */     float f = i / 100.0F;
/* 562 */     return paramPoint.set(Math.round(paramPoint.getX() * f), Math.round(paramPoint.getY() * f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point deviceZoomScaleDown(Point paramPoint) {
/* 576 */     int i = DPIUtil.getDeviceZoom();
/* 577 */     if (100 == i || null == paramPoint) {
/* 578 */       return paramPoint;
/*     */     }
/* 580 */     float f = i / 100.0F;
/* 581 */     return paramPoint.set(Math.round(paramPoint.getX() / f), Math.round(paramPoint.getY() / f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rectangle getClientAreaInPixels(Scrollable paramScrollable) throws NativeWindowException {
/* 612 */     if (null == swt_scrollable_clientAreaInPixels) {
/* 613 */       return DPIUtil.autoScaleUp(paramScrollable.getClientArea());
/*     */     }
/*     */     try {
/* 616 */       return (Rectangle)swt_scrollable_clientAreaInPixels.invoke(paramScrollable, new Object[0]);
/* 617 */     } catch (Throwable throwable) {
/* 618 */       throw new NativeWindowException(throwable);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Point getLocationInPixels(Control paramControl) throws NativeWindowException {
/* 623 */     if (null == swt_control_locationInPixels) {
/* 624 */       return DPIUtil.autoScaleUp(paramControl.getLocation());
/*     */     }
/*     */     try {
/* 627 */       return (Point)swt_control_locationInPixels.invoke(paramControl, new Object[0]);
/* 628 */     } catch (Throwable throwable) {
/* 629 */       throw new NativeWindowException(throwable);
/*     */     } 
/*     */   }
/*     */   public static Point getSizeInPixels(Control paramControl) throws NativeWindowException {
/* 633 */     if (null == swt_control_sizeInPixels) {
/* 634 */       return DPIUtil.autoScaleUp(paramControl.getSize());
/*     */     }
/*     */     try {
/* 637 */       return (Point)swt_control_sizeInPixels.invoke(paramControl, new Object[0]);
/* 638 */     } catch (Throwable throwable) {
/* 639 */       throw new NativeWindowException(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getHandle(Control paramControl) throws NativeWindowException {
/* 649 */     long l = 0L;
/* 650 */     if (isOSX) {
/* 651 */       synchronized (swt_osx_init) {
/*     */         try {
/* 653 */           if (null == swt_osx_view_id) {
/* 654 */             swt_osx_control_view = Control.class.getField("view");
/* 655 */             Object object = swt_osx_control_view.get(paramControl);
/* 656 */             swt_osx_view_id = object.getClass().getField("id");
/* 657 */             l = swt_osx_view_id.getLong(object);
/*     */           } else {
/* 659 */             l = swt_osx_view_id.getLong(swt_osx_control_view.get(paramControl));
/*     */           } 
/* 661 */         } catch (Exception exception) {
/* 662 */           throw new NativeWindowException(exception);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       try {
/* 667 */         l = swt_control_handle.getLong(paramControl);
/* 668 */       } catch (Exception exception) {
/* 669 */         throw new NativeWindowException(exception);
/*     */       } 
/*     */     } 
/* 672 */     if (0L == l) {
/* 673 */       throw new NativeWindowException("Null widget-handle of SWT " + paramControl.getClass().getName() + ": " + paramControl.toString());
/*     */     }
/* 675 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setRealized(Control paramControl, final boolean realize) throws NativeWindowException {
/* 681 */     if (!realize && paramControl.isDisposed()) {
/*     */       return;
/*     */     }
/* 684 */     final long handle = getHandle(paramControl);
/*     */     
/* 686 */     if (null != OS_gtk_class) {
/* 687 */       invokeOnOSTKThread(true, new Runnable()
/*     */           {
/*     */             public void run() {
/* 690 */               if (realize) {
/* 691 */                 SWTAccessor.callStaticMethodL2V(SWTAccessor.OS_gtk_widget_realize, handle);
/* 692 */               } else if (null != SWTAccessor.OS_gtk_widget_unrealize) {
/* 693 */                 SWTAccessor.callStaticMethodL2V(SWTAccessor.OS_gtk_widget_unrealize, handle);
/*     */               } 
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractGraphicsDevice getDevice(Control paramControl) throws NativeWindowException, UnsupportedOperationException {
/* 707 */     long l = getHandle(paramControl);
/* 708 */     if (isX11GTK) {
/* 709 */       long l1 = gdk_window_get_xdisplay(gdk_widget_get_window(l));
/* 710 */       return (AbstractGraphicsDevice)new X11GraphicsDevice(l1, 0, false);
/*     */     } 
/* 712 */     if (isWindows) {
/* 713 */       return (AbstractGraphicsDevice)new WindowsGraphicsDevice(0);
/*     */     }
/* 715 */     if (isOSX) {
/* 716 */       return (AbstractGraphicsDevice)new MacOSXGraphicsDevice(0);
/*     */     }
/* 718 */     throw new UnsupportedOperationException("n/a for this windowing system: " + nwt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractGraphicsScreen getScreen(AbstractGraphicsDevice paramAbstractGraphicsDevice, int paramInt) {
/* 727 */     return NativeWindowFactory.createScreen(paramAbstractGraphicsDevice, paramInt);
/*     */   }
/*     */   
/*     */   public static int getNativeVisualID(AbstractGraphicsDevice paramAbstractGraphicsDevice, long paramLong) {
/* 731 */     if (isX11) {
/* 732 */       return X11Lib.GetVisualIDFromWindow(paramAbstractGraphicsDevice.getHandle(), paramLong);
/*     */     }
/* 734 */     if (isWindows || isOSX) {
/* 735 */       return 0;
/*     */     }
/* 737 */     throw new UnsupportedOperationException("n/a for this windowing system: " + nwt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getWindowHandle(Control paramControl) throws NativeWindowException, UnsupportedOperationException {
/* 747 */     long l = getHandle(paramControl);
/* 748 */     if (0L == l) {
/* 749 */       throw new NativeWindowException("Null SWT handle of SWT control " + paramControl);
/*     */     }
/* 751 */     if (isX11GTK) {
/* 752 */       return gdk_window_get_xwindow(gdk_widget_get_window(l));
/*     */     }
/* 754 */     if (isWindows || isOSX) {
/* 755 */       return l;
/*     */     }
/* 757 */     throw new UnsupportedOperationException("n/a for this windowing system: " + nwt);
/*     */   }
/*     */   
/*     */   public static long newGC(final Control swtControl, final GCData gcData) {
/* 761 */     final Object[] o = new Object[1];
/* 762 */     invokeOnOSTKThread(true, new Runnable()
/*     */         {
/*     */           public void run() {
/* 765 */             o[0] = ReflectionUtil.callMethod(swtControl, SWTAccessor.swt_control_internal_new_GC, new Object[] { this.val$gcData });
/*     */           }
/*     */         });
/* 768 */     if (arrayOfObject[0] instanceof Number) {
/* 769 */       return ((Number)arrayOfObject[0]).longValue();
/*     */     }
/* 771 */     throw new InternalError("SWT internal_new_GC did not return int or long but " + arrayOfObject[0].getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void disposeGC(final Control swtControl, final long gc, final GCData gcData) {
/* 776 */     invokeOnOSTKThread(true, new Runnable()
/*     */         {
/*     */           public void run() {
/* 779 */             if (SWTAccessor.swt_uses_long_handles) {
/* 780 */               ReflectionUtil.callMethod(swtControl, SWTAccessor.swt_control_internal_dispose_GC, new Object[] { Long.valueOf(this.val$gc), this.val$gcData });
/*     */             } else {
/* 782 */               ReflectionUtil.callMethod(swtControl, SWTAccessor.swt_control_internal_dispose_GC, new Object[] { Integer.valueOf((int)this.val$gc), this.val$gcData });
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeOnOSTKThread(boolean paramBoolean, Runnable paramRunnable) {
/* 804 */     if (isOSX) {
/*     */       
/* 806 */       OSXUtil.RunOnMainThread(paramBoolean, false, paramRunnable);
/*     */     } else {
/* 808 */       paramRunnable.run();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeOnSWTThread(Display paramDisplay, boolean paramBoolean, Runnable paramRunnable) {
/* 823 */     if (null == paramDisplay || paramDisplay.isDisposed() || Thread.currentThread() == paramDisplay.getThread()) {
/* 824 */       invokeOnOSTKThread(paramBoolean, paramRunnable);
/* 825 */     } else if (paramBoolean) {
/* 826 */       paramDisplay.syncExec(paramRunnable);
/*     */     } else {
/* 828 */       paramDisplay.asyncExec(paramRunnable);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isOnSWTThread(Display paramDisplay) {
/* 834 */     return (null != paramDisplay && Thread.currentThread() == paramDisplay.getThread());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long createCompatibleX11ChildWindow(AbstractGraphicsScreen paramAbstractGraphicsScreen, Control paramControl, int paramInt1, int paramInt2, int paramInt3) {
/* 842 */     long l1 = getHandle(paramControl);
/* 843 */     long l2 = gdk_widget_get_window(l1);
/*     */ 
/*     */     
/* 846 */     long l3 = gdk_window_get_xwindow(l2);
/* 847 */     return X11Lib.CreateWindow(l3, paramAbstractGraphicsScreen.getDevice().getHandle(), paramAbstractGraphicsScreen.getIndex(), paramInt1, paramInt2, paramInt3, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resizeX11Window(AbstractGraphicsDevice paramAbstractGraphicsDevice, Rectangle paramRectangle, long paramLong) {
/* 853 */     X11Lib.SetWindowPosSize(paramAbstractGraphicsDevice.getHandle(), paramLong, paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*     */   }
/*     */   public static void destroyX11Window(AbstractGraphicsDevice paramAbstractGraphicsDevice, long paramLong) {
/* 856 */     X11Lib.DestroyWindow(paramAbstractGraphicsDevice.getHandle(), paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long createCompatibleGDKChildWindow(Control paramControl, int paramInt1, int paramInt2, int paramInt3) {
/* 869 */     return 0L;
/*     */   }
/*     */   
/*     */   public static void showGDKWindow(long paramLong) {}
/*     */   
/*     */   public static void focusGDKWindow(long paramLong) {}
/*     */   
/*     */   public static void resizeGDKWindow(Rectangle paramRectangle, long paramLong) {}
/*     */   
/*     */   public static void destroyGDKWindow(long paramLong) {}
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/swt/SWTAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */