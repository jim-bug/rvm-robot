package com.jogamp.nativewindow;

import java.util.List;

public interface CapabilitiesChooser {
  int chooseCapabilities(CapabilitiesImmutable paramCapabilitiesImmutable, List<? extends CapabilitiesImmutable> paramList, int paramInt);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/CapabilitiesChooser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */