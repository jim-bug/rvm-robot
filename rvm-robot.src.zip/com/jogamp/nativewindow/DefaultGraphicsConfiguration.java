/*     */ package com.jogamp.nativewindow;
/*     */ 
/*     */ import jogamp.nativewindow.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultGraphicsConfiguration
/*     */   implements Cloneable, AbstractGraphicsConfiguration
/*     */ {
/*  40 */   protected static final boolean DEBUG = Debug.debug("GraphicsConfiguration");
/*     */   
/*     */   private AbstractGraphicsScreen screen;
/*     */   
/*     */   protected CapabilitiesImmutable capabilitiesChosen;
/*     */   protected CapabilitiesImmutable capabilitiesRequested;
/*     */   
/*     */   public DefaultGraphicsConfiguration(AbstractGraphicsScreen paramAbstractGraphicsScreen, CapabilitiesImmutable paramCapabilitiesImmutable1, CapabilitiesImmutable paramCapabilitiesImmutable2) {
/*  48 */     if (null == paramAbstractGraphicsScreen) {
/*  49 */       throw new IllegalArgumentException("Null screen");
/*     */     }
/*  51 */     if (null == paramCapabilitiesImmutable1) {
/*  52 */       throw new IllegalArgumentException("Null chosen caps");
/*     */     }
/*  54 */     if (null == paramCapabilitiesImmutable2) {
/*  55 */       throw new IllegalArgumentException("Null requested caps");
/*     */     }
/*  57 */     this.screen = paramAbstractGraphicsScreen;
/*  58 */     this.capabilitiesChosen = paramCapabilitiesImmutable1;
/*  59 */     this.capabilitiesRequested = paramCapabilitiesImmutable2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*  65 */       return super.clone();
/*  66 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*  67 */       throw new NativeWindowException(cloneNotSupportedException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final AbstractGraphicsScreen getScreen() {
/*  73 */     return this.screen;
/*     */   }
/*     */ 
/*     */   
/*     */   public final CapabilitiesImmutable getChosenCapabilities() {
/*  78 */     return this.capabilitiesChosen;
/*     */   }
/*     */ 
/*     */   
/*     */   public final CapabilitiesImmutable getRequestedCapabilities() {
/*  83 */     return this.capabilitiesRequested;
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractGraphicsConfiguration getNativeGraphicsConfiguration() {
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getVisualID(VisualIDHolder.VIDType paramVIDType) throws NativeWindowException {
/*  93 */     return this.capabilitiesChosen.getVisualID(paramVIDType);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isVisualIDSupported(VisualIDHolder.VIDType paramVIDType) {
/*  98 */     return this.capabilitiesChosen.isVisualIDSupported(paramVIDType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setChosenCapabilities(CapabilitiesImmutable paramCapabilitiesImmutable) {
/* 111 */     this.capabilitiesChosen = paramCapabilitiesImmutable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setScreen(AbstractGraphicsScreen paramAbstractGraphicsScreen) {
/* 123 */     this.screen = paramAbstractGraphicsScreen;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 128 */     return getClass().getSimpleName() + "[" + this.screen + ",\n\tchosen    " + this.capabilitiesChosen + ",\n\trequested " + this.capabilitiesRequested + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexString(int paramInt) {
/* 135 */     return "0x" + Integer.toHexString(paramInt);
/*     */   }
/*     */   
/*     */   public static String toHexString(long paramLong) {
/* 139 */     return "0x" + Long.toHexString(paramLong);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/DefaultGraphicsConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */