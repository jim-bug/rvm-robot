/*     */ package com.jogamp.nativewindow.javafx;
/*     */ 
/*     */ import com.jogamp.common.ExceptionUtils;
/*     */ import com.jogamp.common.util.InterruptedRuntimeException;
/*     */ import com.jogamp.common.util.ReflectionUtil;
/*     */ import com.jogamp.common.util.RunnableTask;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsDevice;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsScreen;
/*     */ import com.jogamp.nativewindow.NativeWindowException;
/*     */ import com.jogamp.nativewindow.NativeWindowFactory;
/*     */ import com.jogamp.nativewindow.macosx.MacOSXGraphicsDevice;
/*     */ import com.jogamp.nativewindow.windows.WindowsGraphicsDevice;
/*     */ import com.jogamp.nativewindow.x11.X11GraphicsDevice;
/*     */ import com.sun.javafx.tk.TKStage;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.PrivilegedAction;
/*     */ import javafx.application.Platform;
/*     */ import javafx.stage.Window;
/*     */ import jogamp.nativewindow.Debug;
/*     */ import jogamp.nativewindow.x11.X11Lib;
/*     */ import jogamp.nativewindow.x11.X11Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JFXAccessor
/*     */ {
/*     */   private static final boolean DEBUG;
/*     */   private static final boolean jfxAvailable;
/*     */   private static final Method fxUserThreadGetter;
/*     */   private static final Method tkStageGetter;
/*     */   private static final Method glassWindowGetter;
/*     */   private static final Method nativeWindowGetter;
/*     */   private static final String nwt;
/*     */   private static final boolean isOSX;
/*     */   private static final boolean isIOS;
/*     */   private static final boolean isWindows;
/*     */   private static final boolean isX11;
/*     */   
/*     */   static {
/*  70 */     final boolean[] _DEBUG = { true };
/*     */     
/*  72 */     Method[] arrayOfMethod = (Method[])SecurityUtil.doPrivileged(new PrivilegedAction<Method[]>()
/*     */         {
/*     */           public Method[] run() {
/*  75 */             NativeWindowFactory.initSingleton();
/*  76 */             Method[] arrayOfMethod = { null, null, null, null };
/*     */             try {
/*  78 */               byte b = 0;
/*  79 */               _DEBUG[0] = Debug.debug("JFX");
/*     */ 
/*     */ 
/*     */               
/*  83 */               Class clazz1 = ReflectionUtil.getClass("com.sun.javafx.tk.Toolkit", false, JFXAccessor.class.getClassLoader());
/*  84 */               arrayOfMethod[b] = clazz1.getDeclaredMethod("getFxUserThread", new Class[0]);
/*  85 */               arrayOfMethod[b++].setAccessible(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*  97 */               Class clazz2 = ReflectionUtil.getClass("javafx.stage.Window", false, JFXAccessor.class.getClassLoader());
/*     */               
/*  99 */               Class clazz3 = ReflectionUtil.getClass("com.sun.javafx.tk.quantum.WindowStage", false, JFXAccessor.class.getClassLoader());
/* 100 */               Class clazz4 = ReflectionUtil.getClass("com.sun.glass.ui.Window", false, JFXAccessor.class.getClassLoader());
/*     */ 
/*     */               
/*     */               try {
/* 104 */                 arrayOfMethod[b] = clazz2.getDeclaredMethod("getPeer", new Class[0]);
/* 105 */               } catch (NoSuchMethodException noSuchMethodException) {
/*     */                 
/* 107 */                 arrayOfMethod[b] = clazz2.getDeclaredMethod("impl_getPeer", new Class[0]);
/*     */               } 
/* 109 */               arrayOfMethod[b++].setAccessible(true);
/*     */               
/* 111 */               arrayOfMethod[b] = clazz3.getDeclaredMethod("getPlatformWindow", new Class[0]);
/* 112 */               arrayOfMethod[b++].setAccessible(true);
/* 113 */               arrayOfMethod[b] = clazz4.getDeclaredMethod("getNativeWindow", new Class[0]);
/* 114 */               arrayOfMethod[b++].setAccessible(true);
/* 115 */             } catch (Throwable throwable) {
/* 116 */               if (_DEBUG[0]) {
/* 117 */                 ExceptionUtils.dumpThrowable("jfx-init", throwable);
/*     */               }
/*     */             } 
/* 120 */             return arrayOfMethod;
/*     */           }
/*     */         });
/*     */     
/* 124 */     byte b = 0;
/* 125 */     fxUserThreadGetter = arrayOfMethod[b++];
/* 126 */     tkStageGetter = arrayOfMethod[b++];
/* 127 */     glassWindowGetter = arrayOfMethod[b++];
/* 128 */     nativeWindowGetter = arrayOfMethod[b++];
/*     */     
/* 130 */     jfxAvailable = (null != fxUserThreadGetter && null != tkStageGetter && null != glassWindowGetter && null != nativeWindowGetter);
/*     */     
/* 132 */     nwt = NativeWindowFactory.getNativeWindowType(false);
/* 133 */     isOSX = (".macosx" == nwt);
/* 134 */     isIOS = (".ios" == nwt);
/* 135 */     isWindows = (".windows" == nwt);
/* 136 */     isX11 = (".x11" == nwt);
/*     */     
/* 138 */     DEBUG = arrayOfBoolean[0];
/* 139 */     if (DEBUG) {
/* 140 */       System.err.println(Thread.currentThread().getName() + " - Info: JFXAccessor.<init> available " + jfxAvailable + ", nwt " + nwt + "( x11 " + isX11 + ", win " + isWindows + ", osx " + isOSX + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJFXAvailable() {
/* 148 */     return jfxAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runOnJFXThread(boolean paramBoolean, Runnable paramRunnable) {
/* 158 */     Object object = new Object();
/* 159 */     synchronized (object) {
/* 160 */       if (isJFXThreadOrHasJFXThreadStopped()) {
/* 161 */         paramRunnable.run();
/* 162 */       } else if (!paramBoolean) {
/* 163 */         Platform.runLater(paramRunnable);
/*     */       } else {
/* 165 */         RunnableTask runnableTask = new RunnableTask(paramRunnable, object, true, null);
/*     */ 
/*     */ 
/*     */         
/* 169 */         Platform.runLater((Runnable)runnableTask);
/*     */         try {
/* 171 */           while (runnableTask.isInQueue()) {
/* 172 */             object.wait();
/*     */           }
/* 174 */         } catch (InterruptedException interruptedException) {
/* 175 */           throw new InterruptedRuntimeException(interruptedException);
/*     */         } 
/* 177 */         Throwable throwable = runnableTask.getThrowable();
/* 178 */         if (null != throwable) {
/* 179 */           if (throwable instanceof NativeWindowException) {
/* 180 */             throw (NativeWindowException)throwable;
/*     */           }
/* 182 */           throw new RuntimeException(throwable);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Thread getJFXThread() throws NativeWindowException {
/*     */     try {
/* 190 */       return (Thread)fxUserThreadGetter.invoke(null, new Object[0]);
/* 191 */     } catch (Throwable throwable) {
/* 192 */       throw new NativeWindowException("Error getting JFX-Thread", throwable);
/*     */     } 
/*     */   }
/*     */   public static String getJFXThreadName() {
/* 196 */     Thread thread = getJFXThread();
/* 197 */     return (null != thread) ? thread.getName() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasJFXThreadStopped() {
/* 203 */     Thread thread = getJFXThread();
/* 204 */     return (null == thread || !thread.isAlive());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJFXThread() {
/* 210 */     Thread thread = getJFXThread();
/* 211 */     return (Thread.currentThread() == thread);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJFXThreadOrHasJFXThreadStopped() {
/* 217 */     Thread thread = getJFXThread();
/* 218 */     return (null == thread || !thread.isAlive() || Thread.currentThread() == thread);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractGraphicsDevice getDevice(Window paramWindow) throws NativeWindowException, UnsupportedOperationException {
/* 228 */     if (isX11) {
/*     */       
/* 230 */       String str = null;
/* 231 */       long l = X11Util.openDisplay(str);
/* 232 */       if (0L == l) {
/* 233 */         throw new NativeWindowException("Error creating display: " + str);
/*     */       }
/* 235 */       return (AbstractGraphicsDevice)new X11GraphicsDevice(l, 0, true);
/*     */     } 
/* 237 */     if (isWindows) {
/* 238 */       return (AbstractGraphicsDevice)new WindowsGraphicsDevice(0);
/*     */     }
/* 240 */     if (isOSX) {
/* 241 */       return (AbstractGraphicsDevice)new MacOSXGraphicsDevice(0);
/*     */     }
/* 243 */     throw new UnsupportedOperationException("n/a for this windowing system: " + nwt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractGraphicsScreen getScreen(AbstractGraphicsDevice paramAbstractGraphicsDevice, int paramInt) {
/* 252 */     return NativeWindowFactory.createScreen(paramAbstractGraphicsDevice, paramInt);
/*     */   }
/*     */   
/*     */   public static int getNativeVisualID(AbstractGraphicsDevice paramAbstractGraphicsDevice, long paramLong) {
/* 256 */     if (isX11) {
/* 257 */       return X11Lib.GetVisualIDFromWindow(paramAbstractGraphicsDevice.getHandle(), paramLong);
/*     */     }
/* 259 */     if (isWindows || isOSX) {
/* 260 */       return 0;
/*     */     }
/* 262 */     throw new UnsupportedOperationException("n/a for this windowing system: " + nwt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getWindowHandle(final Window stageWindow) throws NativeWindowException {
/* 271 */     final long[] h = { 0L };
/* 272 */     runOnJFXThread(true, new Runnable()
/*     */         {
/*     */           public void run() {
/*     */             try {
/* 276 */               TKStage tKStage = (TKStage)JFXAccessor.tkStageGetter.invoke(stageWindow, new Object[0]);
/* 277 */               if (null != tKStage) {
/* 278 */                 Object object = JFXAccessor.glassWindowGetter.invoke(tKStage, new Object[0]);
/* 279 */                 if (null != object) {
/* 280 */                   Object object1 = JFXAccessor.nativeWindowGetter.invoke(object, new Object[0]);
/* 281 */                   h[0] = ((Long)object1).longValue();
/* 282 */                 } else if (JFXAccessor.DEBUG) {
/* 283 */                   System.err.println(Thread.currentThread().getName() + " - Info: JFXAccessor null GlassWindow");
/*     */                 } 
/* 285 */               } else if (JFXAccessor.DEBUG) {
/* 286 */                 System.err.println(Thread.currentThread().getName() + " - Info: JFXAccessor null TKStage");
/*     */               } 
/* 288 */             } catch (Throwable throwable) {
/* 289 */               throw new NativeWindowException("Error getting Window handle", throwable);
/*     */             }  }
/*     */         });
/* 292 */     return arrayOfLong[0];
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/javafx/JFXAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */