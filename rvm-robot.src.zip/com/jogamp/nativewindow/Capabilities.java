/*     */ package com.jogamp.nativewindow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Capabilities
/*     */   implements CapabilitiesImmutable, Cloneable
/*     */ {
/*     */   protected static final String na_str = "----";
/*  50 */   private int redBits = 8;
/*  51 */   private int greenBits = 8;
/*  52 */   private int blueBits = 8;
/*  53 */   private int alphaBits = 0;
/*     */   
/*     */   private boolean backgroundOpaque = true;
/*     */   
/*  57 */   private int transparentValueRed = 0;
/*  58 */   private int transparentValueGreen = 0;
/*  59 */   private int transparentValueBlue = 0;
/*  60 */   private int transparentValueAlpha = 0;
/*     */ 
/*     */   
/*     */   private boolean onscreen = true;
/*     */ 
/*     */   
/*     */   private boolean isBitmap = false;
/*     */ 
/*     */   
/*     */   protected static final String ESEP = "/";
/*     */   
/*     */   protected static final String CSEP = ", ";
/*     */ 
/*     */   
/*     */   public Object cloneMutable() {
/*  75 */     return clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*  81 */       return super.clone();
/*  82 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*  83 */       throw new NativeWindowException(cloneNotSupportedException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Capabilities copyFrom(CapabilitiesImmutable paramCapabilitiesImmutable) {
/*  93 */     this.redBits = paramCapabilitiesImmutable.getRedBits();
/*  94 */     this.greenBits = paramCapabilitiesImmutable.getGreenBits();
/*  95 */     this.blueBits = paramCapabilitiesImmutable.getBlueBits();
/*  96 */     this.alphaBits = paramCapabilitiesImmutable.getAlphaBits();
/*  97 */     this.backgroundOpaque = paramCapabilitiesImmutable.isBackgroundOpaque();
/*  98 */     this.onscreen = paramCapabilitiesImmutable.isOnscreen();
/*  99 */     this.isBitmap = paramCapabilitiesImmutable.isBitmap();
/* 100 */     this.transparentValueRed = paramCapabilitiesImmutable.getTransparentRedValue();
/* 101 */     this.transparentValueGreen = paramCapabilitiesImmutable.getTransparentGreenValue();
/* 102 */     this.transparentValueBlue = paramCapabilitiesImmutable.getTransparentBlueValue();
/* 103 */     this.transparentValueAlpha = paramCapabilitiesImmutable.getTransparentAlphaValue();
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 110 */     int i = 31 + this.redBits;
/* 111 */     i = (i << 5) - i + (this.onscreen ? 1 : 0);
/* 112 */     i = (i << 5) - i + (this.isBitmap ? 1 : 0);
/* 113 */     i = (i << 5) - i + this.greenBits;
/* 114 */     i = (i << 5) - i + this.blueBits;
/* 115 */     i = (i << 5) - i + this.alphaBits;
/* 116 */     i = (i << 5) - i + (this.backgroundOpaque ? 1 : 0);
/* 117 */     i = (i << 5) - i + this.transparentValueRed;
/* 118 */     i = (i << 5) - i + this.transparentValueGreen;
/* 119 */     i = (i << 5) - i + this.transparentValueBlue;
/* 120 */     i = (i << 5) - i + this.transparentValueAlpha;
/* 121 */     return i;
/*     */   }
/*     */   
/*     */   private static boolean checkSameSuppSameValue(VisualIDHolder.VIDType paramVIDType, VisualIDHolder paramVisualIDHolder1, VisualIDHolder paramVisualIDHolder2) {
/* 125 */     boolean bool = paramVisualIDHolder1.isVisualIDSupported(paramVIDType);
/* 126 */     if (bool != paramVisualIDHolder2.isVisualIDSupported(paramVIDType))
/*     */     {
/* 128 */       return false;
/*     */     }
/* 130 */     return (!bool || paramVisualIDHolder1.getVisualID(paramVIDType) == paramVisualIDHolder2.getVisualID(paramVIDType));
/*     */   }
/*     */   private static boolean checkSameValueIfBothSupp(VisualIDHolder.VIDType paramVIDType, VisualIDHolder paramVisualIDHolder1, VisualIDHolder paramVisualIDHolder2) {
/* 133 */     boolean bool = paramVisualIDHolder1.isVisualIDSupported(paramVIDType);
/* 134 */     if (bool && bool == paramVisualIDHolder2.isVisualIDSupported(paramVIDType)) {
/* 135 */       return (paramVisualIDHolder1.getVisualID(paramVIDType) == paramVisualIDHolder2.getVisualID(paramVIDType));
/*     */     }
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 142 */     if (this == paramObject) return true; 
/* 143 */     if (!(paramObject instanceof CapabilitiesImmutable)) {
/* 144 */       return false;
/*     */     }
/* 146 */     CapabilitiesImmutable capabilitiesImmutable = (CapabilitiesImmutable)paramObject;
/*     */ 
/*     */     
/* 149 */     int i = getVisualID(VisualIDHolder.VIDType.NATIVE);
/* 150 */     int j = capabilitiesImmutable.getVisualID(VisualIDHolder.VIDType.NATIVE);
/* 151 */     if (i != j) {
/* 152 */       return false;
/*     */     }
/* 154 */     if (!checkSameSuppSameValue(VisualIDHolder.VIDType.X11_FBCONFIG, this, capabilitiesImmutable)) {
/* 155 */       return false;
/*     */     }
/* 157 */     if (!checkSameValueIfBothSupp(VisualIDHolder.VIDType.EGL_CONFIG, this, capabilitiesImmutable)) {
/* 158 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     i = (capabilitiesImmutable.getRedBits() == this.redBits && capabilitiesImmutable.getGreenBits() == this.greenBits && capabilitiesImmutable.getBlueBits() == this.blueBits && capabilitiesImmutable.getAlphaBits() == this.alphaBits && capabilitiesImmutable.isBackgroundOpaque() == this.backgroundOpaque && capabilitiesImmutable.isOnscreen() == this.onscreen && capabilitiesImmutable.isBitmap() == this.isBitmap) ? 1 : 0;
/* 168 */     if (i != 0 && !this.backgroundOpaque)
/*     */     {
/*     */ 
/*     */       
/* 172 */       i = (capabilitiesImmutable.getTransparentRedValue() == this.transparentValueRed && capabilitiesImmutable.getTransparentGreenValue() == this.transparentValueGreen && capabilitiesImmutable.getTransparentBlueValue() == this.transparentValueBlue && capabilitiesImmutable.getTransparentAlphaValue() == this.transparentValueAlpha) ? 1 : 0;
/*     */     }
/*     */     
/* 175 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(CapabilitiesImmutable paramCapabilitiesImmutable) {
/* 190 */     int i = this.redBits * this.greenBits * this.blueBits * (this.alphaBits + 1);
/*     */     
/* 192 */     int j = paramCapabilitiesImmutable.getRedBits() * paramCapabilitiesImmutable.getGreenBits() * paramCapabilitiesImmutable.getBlueBits() * (paramCapabilitiesImmutable.getAlphaBits() + 1);
/*     */     
/* 194 */     if (i > j)
/* 195 */       return 1; 
/* 196 */     if (i < j) {
/* 197 */       return -1;
/*     */     }
/*     */     
/* 200 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getVisualID(VisualIDHolder.VIDType paramVIDType) throws NativeWindowException {
/* 205 */     switch (paramVIDType) {
/*     */       case INTRINSIC:
/*     */       case NATIVE:
/* 208 */         return 0;
/*     */     } 
/* 210 */     throw new NativeWindowException("Invalid type <" + paramVIDType + ">");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisualIDSupported(VisualIDHolder.VIDType paramVIDType) {
/* 216 */     switch (paramVIDType) {
/*     */       case INTRINSIC:
/*     */       case NATIVE:
/* 219 */         return true;
/*     */     } 
/* 221 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRedBits() {
/* 227 */     return this.redBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRedBits(int paramInt) {
/* 234 */     this.redBits = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getGreenBits() {
/* 239 */     return this.greenBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGreenBits(int paramInt) {
/* 246 */     this.greenBits = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getBlueBits() {
/* 251 */     return this.blueBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlueBits(int paramInt) {
/* 258 */     this.blueBits = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getAlphaBits() {
/* 263 */     return this.alphaBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlphaBits(int paramInt) {
/* 279 */     this.alphaBits = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBackgroundOpaque(boolean paramBoolean) {
/* 298 */     this.backgroundOpaque = paramBoolean;
/* 299 */     if (!paramBoolean && getAlphaBits() == 0) {
/* 300 */       setAlphaBits(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isBackgroundOpaque() {
/* 306 */     return this.backgroundOpaque;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOnscreen(boolean paramBoolean) {
/* 322 */     this.onscreen = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isOnscreen() {
/* 327 */     return this.onscreen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBitmap(boolean paramBoolean) {
/* 343 */     if (paramBoolean) {
/* 344 */       setOnscreen(false);
/*     */     }
/* 346 */     this.isBitmap = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBitmap() {
/* 351 */     return this.isBitmap;
/*     */   }
/*     */   
/*     */   public final int getTransparentRedValue() {
/* 355 */     return this.transparentValueRed;
/*     */   }
/*     */   public final int getTransparentGreenValue() {
/* 358 */     return this.transparentValueGreen;
/*     */   }
/*     */   public final int getTransparentBlueValue() {
/* 361 */     return this.transparentValueBlue;
/*     */   }
/*     */   public final int getTransparentAlphaValue() {
/* 364 */     return this.transparentValueAlpha;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransparentRedValue(int paramInt) {
/* 371 */     this.transparentValueRed = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransparentGreenValue(int paramInt) {
/* 378 */     this.transparentValueGreen = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransparentBlueValue(int paramInt) {
/* 385 */     this.transparentValueBlue = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransparentAlphaValue(int paramInt) {
/* 392 */     this.transparentValueAlpha = paramInt;
/*     */   }
/*     */   
/*     */   public StringBuilder toString(StringBuilder paramStringBuilder) {
/* 396 */     return toString(paramStringBuilder, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 403 */     StringBuilder stringBuilder = new StringBuilder();
/* 404 */     stringBuilder.append("Caps[");
/* 405 */     toString(stringBuilder);
/* 406 */     stringBuilder.append("]");
/* 407 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringBuilder onoffScreenToString(StringBuilder paramStringBuilder) {
/* 412 */     if (null == paramStringBuilder) {
/* 413 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 415 */     if (this.onscreen) {
/* 416 */       paramStringBuilder.append("on-scr");
/*     */     } else {
/* 418 */       paramStringBuilder.append("offscr[");
/*     */     } 
/* 420 */     if (this.isBitmap) {
/* 421 */       paramStringBuilder.append("bitmap");
/* 422 */     } else if (this.onscreen) {
/* 423 */       paramStringBuilder.append(".");
/*     */     } else {
/* 425 */       paramStringBuilder.append("auto-cfg");
/*     */     } 
/* 427 */     paramStringBuilder.append("]");
/*     */     
/* 429 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringBuilder toString(StringBuilder paramStringBuilder, boolean paramBoolean) {
/* 438 */     if (null == paramStringBuilder) {
/* 439 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 441 */     paramStringBuilder.append("rgba ").append(this.redBits).append("/").append(this.greenBits).append("/").append(this.blueBits).append("/").append(this.alphaBits);
/* 442 */     if (this.backgroundOpaque) {
/* 443 */       paramStringBuilder.append(", opaque");
/*     */     } else {
/* 445 */       paramStringBuilder.append(", trans-rgba 0x").append(toHexString(this.transparentValueRed)).append("/").append(toHexString(this.transparentValueGreen)).append("/").append(toHexString(this.transparentValueBlue)).append("/").append(toHexString(this.transparentValueAlpha));
/*     */     } 
/* 447 */     if (paramBoolean) {
/* 448 */       paramStringBuilder.append(", ");
/* 449 */       onoffScreenToString(paramStringBuilder);
/*     */     } 
/* 451 */     return paramStringBuilder;
/*     */   }
/*     */   protected final String toHexString(int paramInt) {
/* 454 */     return Integer.toHexString(paramInt);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/Capabilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */