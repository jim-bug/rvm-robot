/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WindowClosingProtocol
/*    */ {
/*    */   WindowClosingMode getDefaultCloseOperation();
/*    */   
/*    */   WindowClosingMode setDefaultCloseOperation(WindowClosingMode paramWindowClosingMode);
/*    */   
/*    */   public enum WindowClosingMode
/*    */   {
/* 49 */     DO_NOTHING_ON_CLOSE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 55 */     DISPOSE_ON_CLOSE;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/WindowClosingProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */