/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatedUpstreamSurfaceHookMutableSize
/*    */   extends UpstreamSurfaceHookMutableSize
/*    */ {
/*    */   final UpstreamSurfaceHook upstream;
/*    */   
/*    */   public DelegatedUpstreamSurfaceHookMutableSize(UpstreamSurfaceHook paramUpstreamSurfaceHook, int paramInt1, int paramInt2) {
/* 15 */     super(paramInt1, paramInt2);
/* 16 */     this.upstream = paramUpstreamSurfaceHook;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void create(ProxySurface paramProxySurface) {
/* 21 */     if (null != this.upstream) {
/* 22 */       this.upstream.create(paramProxySurface);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public final void destroy(ProxySurface paramProxySurface) {
/* 28 */     if (null != this.upstream) {
/* 29 */       this.upstream.destroy(paramProxySurface);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return getClass().getSimpleName() + "[ " + this.pixWidth + "x" + this.pixHeight + ", " + this.upstream + "]";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/DelegatedUpstreamSurfaceHookMutableSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */