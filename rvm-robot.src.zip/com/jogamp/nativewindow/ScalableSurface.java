package com.jogamp.nativewindow;

public interface ScalableSurface {
  public static final float IDENTITY_PIXELSCALE = 1.0F;
  
  public static final float AUTOMAX_PIXELSCALE = 0.0F;
  
  boolean canSetSurfaceScale();
  
  boolean setSurfaceScale(float[] paramArrayOffloat);
  
  float[] getRequestedSurfaceScale(float[] paramArrayOffloat);
  
  float[] getCurrentSurfaceScale(float[] paramArrayOffloat);
  
  float[] getMinimumSurfaceScale(float[] paramArrayOffloat);
  
  float[] getMaximumSurfaceScale(float[] paramArrayOffloat);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/ScalableSurface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */