/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MutableGraphicsConfiguration
/*    */   extends DefaultGraphicsConfiguration
/*    */ {
/*    */   public MutableGraphicsConfiguration(AbstractGraphicsScreen paramAbstractGraphicsScreen, CapabilitiesImmutable paramCapabilitiesImmutable1, CapabilitiesImmutable paramCapabilitiesImmutable2) {
/* 37 */     super(paramAbstractGraphicsScreen, paramCapabilitiesImmutable1, paramCapabilitiesImmutable2);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setChosenCapabilities(CapabilitiesImmutable paramCapabilitiesImmutable) {
/* 42 */     super.setChosenCapabilities(paramCapabilitiesImmutable);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setScreen(AbstractGraphicsScreen paramAbstractGraphicsScreen) {
/* 47 */     super.setScreen(paramAbstractGraphicsScreen);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/MutableGraphicsConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */