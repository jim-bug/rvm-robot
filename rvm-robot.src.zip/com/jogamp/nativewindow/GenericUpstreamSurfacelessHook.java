/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericUpstreamSurfacelessHook
/*    */   extends UpstreamSurfaceHookMutableSize
/*    */ {
/*    */   public GenericUpstreamSurfacelessHook(int paramInt1, int paramInt2) {
/* 40 */     super(paramInt1, paramInt2);
/*    */   }
/*    */ 
/*    */   
/*    */   public final void create(ProxySurface paramProxySurface) {
/* 45 */     AbstractGraphicsDevice abstractGraphicsDevice = paramProxySurface.getGraphicsConfiguration().getScreen().getDevice();
/* 46 */     abstractGraphicsDevice.lock();
/*    */     try {
/* 48 */       if (0L == abstractGraphicsDevice.getHandle()) {
/* 49 */         abstractGraphicsDevice.open();
/* 50 */         paramProxySurface.addUpstreamOptionBits(128);
/*    */       } 
/* 52 */       if (0L != paramProxySurface.getSurfaceHandle()) {
/* 53 */         throw new InternalError("Upstream surface not null: " + paramProxySurface);
/*    */       }
/* 55 */       paramProxySurface.addUpstreamOptionBits(832);
/*    */     }
/*    */     finally {
/*    */       
/* 59 */       abstractGraphicsDevice.unlock();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public final void destroy(ProxySurface paramProxySurface) {
/* 65 */     if (paramProxySurface.containsUpstreamOptionBits(64)) {
/* 66 */       AbstractGraphicsDevice abstractGraphicsDevice = paramProxySurface.getGraphicsConfiguration().getScreen().getDevice();
/* 67 */       if (!paramProxySurface.containsUpstreamOptionBits(512)) {
/* 68 */         throw new InternalError("Owns upstream surface, but not a valid zero surface: " + paramProxySurface);
/*    */       }
/* 70 */       if (0L != paramProxySurface.getSurfaceHandle()) {
/* 71 */         throw new InternalError("Owns upstream valid zero surface, but non zero surface: " + paramProxySurface);
/*    */       }
/* 73 */       abstractGraphicsDevice.lock();
/*    */       try {
/* 75 */         paramProxySurface.clearUpstreamOptionBits(576);
/*    */       } finally {
/* 77 */         abstractGraphicsDevice.unlock();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/GenericUpstreamSurfacelessHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */