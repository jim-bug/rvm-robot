package com.jogamp.nativewindow;

public interface NativeSurfaceHolder {
  NativeSurface getNativeSurface();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/NativeSurfaceHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */