package com.jogamp.nativewindow;

public interface UpstreamSurfaceHook {
  void create(ProxySurface paramProxySurface);
  
  void destroy(ProxySurface paramProxySurface);
  
  NativeSurface getUpstreamSurface();
  
  int getSurfaceWidth(ProxySurface paramProxySurface);
  
  int getSurfaceHeight(ProxySurface paramProxySurface);
  
  public static interface MutableSize extends UpstreamSurfaceHook {
    void setSurfaceSize(int param1Int1, int param1Int2);
  }
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/UpstreamSurfaceHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */