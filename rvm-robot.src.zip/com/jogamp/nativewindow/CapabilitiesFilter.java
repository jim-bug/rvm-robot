/*     */ package com.jogamp.nativewindow;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CapabilitiesFilter
/*     */ {
/*     */   public static class TestLessColorCompBits<C extends CapabilitiesImmutable>
/*     */     implements Test<C>
/*     */   {
/*     */     final int minColorCompBits;
/*     */     
/*     */     public TestLessColorCompBits(int param1Int) {
/*  50 */       this.minColorCompBits = param1Int;
/*     */     }
/*     */     public final boolean match(C param1C) {
/*  53 */       return (param1C.getRedBits() < this.minColorCompBits || param1C
/*  54 */         .getGreenBits() < this.minColorCompBits || param1C
/*  55 */         .getBlueBits() < this.minColorCompBits || param1C
/*  56 */         .getAlphaBits() < this.minColorCompBits);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TestMoreColorCompBits<C extends CapabilitiesImmutable> implements Test<C> {
/*     */     public TestMoreColorCompBits(int param1Int) {
/*  62 */       this.maxColorCompBits = param1Int;
/*     */     } final int maxColorCompBits;
/*     */     public final boolean match(C param1C) {
/*  65 */       return (param1C.getRedBits() > this.maxColorCompBits || param1C
/*  66 */         .getGreenBits() > this.maxColorCompBits || param1C
/*  67 */         .getBlueBits() > this.maxColorCompBits || param1C
/*  68 */         .getAlphaBits() > this.maxColorCompBits);
/*     */     } }
/*     */   
/*     */   public static class TestUnmatchedNativeVisualID<C extends CapabilitiesImmutable> implements Test<C> { final int requiredNativeVisualID;
/*     */     
/*     */     public TestUnmatchedNativeVisualID(int param1Int) {
/*  74 */       this.requiredNativeVisualID = param1Int;
/*     */     }
/*     */     public final boolean match(C param1C) {
/*  77 */       return (param1C.getVisualID(VisualIDHolder.VIDType.NATIVE) != this.requiredNativeVisualID);
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <C extends CapabilitiesImmutable> ArrayList<C> removeMatching(ArrayList<C> paramArrayList, List<Test<C>> paramList) {
/*  88 */     ArrayList<CapabilitiesImmutable> arrayList = new ArrayList();
/*  89 */     for (byte b = 0; b < paramArrayList.size(); ) {
/*  90 */       CapabilitiesImmutable capabilitiesImmutable = (CapabilitiesImmutable)paramArrayList.get(b);
/*  91 */       boolean bool = false;
/*  92 */       for (byte b1 = 0; !bool && b1 < paramList.size(); b1++) {
/*  93 */         if (((Test<CapabilitiesImmutable>)paramList.get(b1)).match(capabilitiesImmutable)) {
/*  94 */           arrayList.add((CapabilitiesImmutable)paramArrayList.remove(b));
/*  95 */           bool = true;
/*     */         } 
/*     */       } 
/*  98 */       if (!bool) {
/*  99 */         b++;
/*     */       }
/*     */     } 
/* 102 */     return (ArrayList)arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <C extends CapabilitiesImmutable> ArrayList<C> removeUnmatchingNativeVisualID(ArrayList<C> paramArrayList, int paramInt) {
/* 117 */     if (0 == paramInt) {
/* 118 */       return new ArrayList<>();
/*     */     }
/* 120 */     ArrayList<Test<C>> arrayList = new ArrayList();
/* 121 */     arrayList.add(new TestUnmatchedNativeVisualID<>(paramInt));
/* 122 */     return removeMatching(paramArrayList, arrayList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <C extends CapabilitiesImmutable> ArrayList<C> removeMoreColorComps(ArrayList<C> paramArrayList, int paramInt) {
/* 133 */     ArrayList<Test<C>> arrayList = new ArrayList();
/* 134 */     arrayList.add(new TestMoreColorCompBits<>(paramInt));
/* 135 */     return removeMatching(paramArrayList, arrayList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <C extends CapabilitiesImmutable> ArrayList<C> removeMoreColorCompsAndUnmatchingNativeVisualID(ArrayList<C> paramArrayList, int paramInt1, int paramInt2) {
/* 153 */     ArrayList<Test<C>> arrayList = new ArrayList();
/* 154 */     arrayList.add(new TestMoreColorCompBits<>(paramInt1));
/* 155 */     if (0 != paramInt2) {
/* 156 */       arrayList.add(new TestUnmatchedNativeVisualID<>(paramInt2));
/*     */     }
/* 158 */     return removeMatching(paramArrayList, arrayList);
/*     */   }
/*     */   
/*     */   public static interface Test<C extends CapabilitiesImmutable> {
/*     */     boolean match(C param1C);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/CapabilitiesFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */