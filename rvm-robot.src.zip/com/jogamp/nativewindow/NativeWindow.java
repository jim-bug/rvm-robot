package com.jogamp.nativewindow;

import com.jogamp.nativewindow.util.InsetsImmutable;
import com.jogamp.nativewindow.util.Point;
import com.jogamp.nativewindow.util.Rectangle;

public interface NativeWindow extends NativeSurface, NativeSurfaceHolder {
  NativeSurface getNativeSurface();
  
  void destroy();
  
  NativeWindow getParent();
  
  long getWindowHandle();
  
  InsetsImmutable getInsets();
  
  int getX();
  
  int getY();
  
  int getWidth();
  
  int getHeight();
  
  Rectangle getBounds();
  
  Rectangle getSurfaceBounds();
  
  Point getLocationOnScreen(Point paramPoint);
  
  boolean hasFocus();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/NativeWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */