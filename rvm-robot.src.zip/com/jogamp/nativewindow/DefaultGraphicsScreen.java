/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultGraphicsScreen
/*    */   implements Cloneable, AbstractGraphicsScreen
/*    */ {
/*    */   private final AbstractGraphicsDevice device;
/*    */   private final int idx;
/*    */   
/*    */   public DefaultGraphicsScreen(AbstractGraphicsDevice paramAbstractGraphicsDevice, int paramInt) {
/* 40 */     this.device = paramAbstractGraphicsDevice;
/* 41 */     this.idx = paramInt;
/*    */   }
/*    */   
/*    */   public static AbstractGraphicsScreen createDefault(String paramString) {
/* 45 */     return new DefaultGraphicsScreen(new DefaultGraphicsDevice(paramString, DefaultGraphicsDevice.getDefaultDisplayConnection(paramString), 0), 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/*    */     try {
/* 51 */       return super.clone();
/* 52 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/* 53 */       throw new NativeWindowException(cloneNotSupportedException);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public AbstractGraphicsDevice getDevice() {
/* 59 */     return this.device;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getIndex() {
/* 64 */     return this.idx;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 69 */     return getClass().getSimpleName() + "[" + this.device + ", idx " + this.idx + "]";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/DefaultGraphicsScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */