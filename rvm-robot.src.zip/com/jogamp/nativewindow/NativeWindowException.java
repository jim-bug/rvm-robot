/*    */ package com.jogamp.nativewindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeWindowException
/*    */   extends RuntimeException
/*    */ {
/*    */   public NativeWindowException() {}
/*    */   
/*    */   public NativeWindowException(String paramString) {
/* 55 */     super(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public NativeWindowException(String paramString, Throwable paramThrowable) {
/* 61 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public NativeWindowException(Throwable paramThrowable) {
/* 67 */     super(paramThrowable);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/NativeWindowException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */