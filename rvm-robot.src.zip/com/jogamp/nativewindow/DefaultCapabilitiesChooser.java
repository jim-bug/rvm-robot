/*     */ package com.jogamp.nativewindow;
/*     */ 
/*     */ import com.jogamp.common.util.PropertyAccess;
/*     */ import java.util.List;
/*     */ import jogamp.nativewindow.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultCapabilitiesChooser
/*     */   implements CapabilitiesChooser
/*     */ {
/*     */   static {
/*  74 */     Debug.initSingleton();
/*  75 */   } private static final boolean DEBUG = PropertyAccess.isPropertyDefined("nativewindow.debug.CapabilitiesChooser", true);
/*     */ 
/*     */   
/*     */   private static final int NO_SCORE = -9999999;
/*     */ 
/*     */   
/*     */   private static final int COLOR_MISMATCH_PENALTY_SCALE = 36;
/*     */ 
/*     */   
/*     */   public int chooseCapabilities(CapabilitiesImmutable paramCapabilitiesImmutable, List<? extends CapabilitiesImmutable> paramList, int paramInt) {
/*  85 */     if (DEBUG) {
/*  86 */       System.err.println("Desired: " + paramCapabilitiesImmutable);
/*  87 */       for (byte b2 = 0; b2 < paramList.size(); b2++) {
/*  88 */         System.err.println("Available " + b2 + ": " + paramList.get(b2));
/*     */       }
/*  90 */       System.err.println("Window system's recommended choice: " + paramInt);
/*     */     } 
/*  92 */     int i = paramList.size();
/*     */     
/*  94 */     if (paramInt >= 0 && paramInt < i && null != paramList
/*     */       
/*  96 */       .get(paramInt)) {
/*  97 */       if (DEBUG) {
/*  98 */         System.err.println("Choosing window system's recommended choice of " + paramInt);
/*  99 */         System.err.println(paramList.get(paramInt));
/*     */       } 
/* 101 */       return paramInt;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     int[] arrayOfInt = new int[i]; int j;
/* 106 */     for (j = 0; j < i; j++) {
/* 107 */       arrayOfInt[j] = -9999999;
/*     */     }
/*     */     
/* 110 */     for (j = 0; j < i; j++) {
/* 111 */       CapabilitiesImmutable capabilitiesImmutable = paramList.get(j);
/* 112 */       if (capabilitiesImmutable != null)
/*     */       {
/*     */         
/* 115 */         if (!paramCapabilitiesImmutable.isOnscreen() || capabilitiesImmutable.isOnscreen()) {
/*     */ 
/*     */ 
/*     */           
/* 119 */           int k = 0;
/*     */           
/* 121 */           k += 36 * (capabilitiesImmutable
/* 122 */             .getRedBits() + capabilitiesImmutable.getGreenBits() + capabilitiesImmutable.getBlueBits() + capabilitiesImmutable.getAlphaBits() - paramCapabilitiesImmutable
/* 123 */             .getRedBits() + paramCapabilitiesImmutable.getGreenBits() + paramCapabilitiesImmutable.getBlueBits() + paramCapabilitiesImmutable.getAlphaBits());
/* 124 */           arrayOfInt[j] = k;
/*     */         }  } 
/*     */     } 
/* 127 */     if (DEBUG) {
/* 128 */       System.err.print("Scores: [");
/* 129 */       for (j = 0; j < i; j++) {
/* 130 */         if (j > 0) {
/* 131 */           System.err.print(",");
/*     */         }
/* 133 */         System.err.print(" " + arrayOfInt[j]);
/*     */       } 
/* 135 */       System.err.println(" ]");
/*     */     } 
/*     */ 
/*     */     
/* 139 */     j = -9999999;
/* 140 */     byte b = -1;
/* 141 */     for (byte b1 = 0; b1 < i; b1++) {
/* 142 */       int k = arrayOfInt[b1];
/* 143 */       if (k != -9999999)
/*     */       {
/*     */ 
/*     */         
/* 147 */         if (j == -9999999 || (
/* 148 */           Math.abs(k) < Math.abs(j) && (
/* 149 */           sign(j) < 0 || sign(k) > 0))) {
/* 150 */           j = k;
/* 151 */           b = b1;
/*     */         }  } 
/*     */     } 
/* 154 */     if (b < 0) {
/* 155 */       throw new NativeWindowException("Unable to select one of the provided Capabilities");
/*     */     }
/* 157 */     if (DEBUG) {
/* 158 */       System.err.println("Chosen index: " + b);
/* 159 */       System.err.println("Chosen capabilities:");
/* 160 */       System.err.println(paramList.get(b));
/*     */     } 
/*     */     
/* 163 */     return b;
/*     */   }
/*     */   
/*     */   private static int sign(int paramInt) {
/* 167 */     if (paramInt < 0) {
/* 168 */       return -1;
/*     */     }
/* 170 */     return 1;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/DefaultCapabilitiesChooser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */