/*     */ package com.jogamp.nativewindow.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dimension
/*     */   implements Cloneable, DimensionImmutable
/*     */ {
/*     */   int width;
/*     */   int height;
/*     */   
/*     */   public Dimension() {
/*  37 */     this(0, 0);
/*     */   }
/*     */   
/*     */   public Dimension(int[] paramArrayOfint) {
/*  41 */     this(paramArrayOfint[0], paramArrayOfint[1]);
/*     */   }
/*     */   
/*     */   public Dimension(int paramInt1, int paramInt2) {
/*  45 */     if (paramInt1 < 0 || paramInt2 < 0) {
/*  46 */       throw new IllegalArgumentException("width and height must be within: [0..2147483647]");
/*     */     }
/*  48 */     this.width = paramInt1;
/*  49 */     this.height = paramInt2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object cloneMutable() {
/*  54 */     return clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*  60 */       return super.clone();
/*  61 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*  62 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int getWidth() {
/*  67 */     return this.width;
/*     */   } public final int getHeight() {
/*  69 */     return this.height;
/*     */   }
/*     */   public final void set(int paramInt1, int paramInt2) {
/*  72 */     this.width = paramInt1;
/*  73 */     this.height = paramInt2;
/*     */   }
/*     */   public final void setWidth(int paramInt) {
/*  76 */     this.width = paramInt;
/*     */   }
/*     */   public final void setHeight(int paramInt) {
/*  79 */     this.height = paramInt;
/*     */   }
/*     */   public final Dimension scale(int paramInt) {
/*  82 */     this.width *= paramInt;
/*  83 */     this.height *= paramInt;
/*  84 */     return this;
/*     */   }
/*     */   public final Dimension add(Dimension paramDimension) {
/*  87 */     this.width += paramDimension.width;
/*  88 */     this.height += paramDimension.height;
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  94 */     return this.width + " x " + this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(DimensionImmutable paramDimensionImmutable) {
/*  99 */     int i = this.width * this.height;
/* 100 */     int j = paramDimensionImmutable.getWidth() * paramDimensionImmutable.getHeight();
/*     */     
/* 102 */     if (i > j)
/* 103 */       return 1; 
/* 104 */     if (i < j) {
/* 105 */       return -1;
/*     */     }
/* 107 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 112 */     if (this == paramObject) return true; 
/* 113 */     if (paramObject instanceof Dimension) {
/* 114 */       Dimension dimension = (Dimension)paramObject;
/* 115 */       return (this.height == dimension.height && this.width == dimension.width);
/*     */     } 
/*     */     
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     int i = 31 + this.width;
/* 125 */     return (i << 5) - i + this.height;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/Dimension.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */