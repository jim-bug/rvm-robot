package com.jogamp.nativewindow.util;

import com.jogamp.common.type.WriteCloneable;
import java.util.List;

public interface RectangleImmutable extends WriteCloneable, Comparable<RectangleImmutable> {
  int getHeight();
  
  int getWidth();
  
  int getX();
  
  int getY();
  
  Rectangle union(RectangleImmutable paramRectangleImmutable);
  
  Rectangle union(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  Rectangle union(List<RectangleImmutable> paramList);
  
  Rectangle intersection(RectangleImmutable paramRectangleImmutable);
  
  Rectangle intersection(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  float coverage(RectangleImmutable paramRectangleImmutable);
  
  boolean contains(RectangleImmutable paramRectangleImmutable);
  
  int compareTo(RectangleImmutable paramRectangleImmutable);
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/RectangleImmutable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */