/*     */ package com.jogamp.nativewindow.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Point
/*     */   implements Cloneable, PointImmutable
/*     */ {
/*     */   int x;
/*     */   int y;
/*     */   
/*     */   public Point(int paramInt1, int paramInt2) {
/*  37 */     this.x = paramInt1;
/*  38 */     this.y = paramInt2;
/*     */   }
/*     */   
/*     */   public Point() {
/*  42 */     this(0, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object cloneMutable() {
/*  47 */     return clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*  53 */       return super.clone();
/*  54 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*  55 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(PointImmutable paramPointImmutable) {
/*  61 */     int i = this.x * this.y;
/*  62 */     int j = paramPointImmutable.getX() * paramPointImmutable.getY();
/*     */     
/*  64 */     if (i > j)
/*  65 */       return 1; 
/*  66 */     if (i < j) {
/*  67 */       return -1;
/*     */     }
/*  69 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  74 */     if (this == paramObject) return true; 
/*  75 */     if (paramObject instanceof Point) {
/*  76 */       Point point = (Point)paramObject;
/*  77 */       return (this.y == point.y && this.x == point.x);
/*     */     } 
/*  79 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getX() {
/*  84 */     return this.x;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getY() {
/*  89 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  95 */     int i = 31 + this.x;
/*  96 */     i = (i << 5) - i + this.y;
/*  97 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 102 */     return this.x + " / " + this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point set(int paramInt1, int paramInt2) {
/* 111 */     this.x = paramInt1; this.y = paramInt2; return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point setX(int paramInt) {
/* 117 */     this.x = paramInt; return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point setY(int paramInt) {
/* 123 */     this.y = paramInt; return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point translate(Point paramPoint) {
/* 132 */     this.x += paramPoint.x;
/* 133 */     this.y += paramPoint.y;
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point translate(PointImmutable paramPointImmutable) {
/* 144 */     this.x += paramPointImmutable.getX();
/* 145 */     this.y += paramPointImmutable.getY();
/* 146 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point translate(int paramInt1, int paramInt2) {
/* 157 */     this.x += paramInt1;
/* 158 */     this.y += paramInt2;
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point scale(int paramInt1, int paramInt2) {
/* 170 */     this.x *= paramInt1;
/* 171 */     this.y *= paramInt2;
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point scale(float paramFloat1, float paramFloat2) {
/* 186 */     this.x = (int)(this.x * paramFloat1 + 0.5F);
/* 187 */     this.y = (int)(this.y * paramFloat2 + 0.5F);
/* 188 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point scaleInv(int paramInt1, int paramInt2) {
/* 199 */     this.x /= paramInt1;
/* 200 */     this.y /= paramInt2;
/* 201 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point scaleInv(float paramFloat1, float paramFloat2) {
/* 214 */     this.x = (int)(this.x / paramFloat1 + 0.5F);
/* 215 */     this.y = (int)(this.y / paramFloat2 + 0.5F);
/* 216 */     return this;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/Point.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */