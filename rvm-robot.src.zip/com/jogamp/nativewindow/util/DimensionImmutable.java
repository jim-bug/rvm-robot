package com.jogamp.nativewindow.util;

import com.jogamp.common.type.WriteCloneable;

public interface DimensionImmutable extends WriteCloneable, Comparable<DimensionImmutable> {
  int getHeight();
  
  int getWidth();
  
  int compareTo(DimensionImmutable paramDimensionImmutable);
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/DimensionImmutable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */