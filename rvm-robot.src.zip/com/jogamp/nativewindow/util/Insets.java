/*     */ package com.jogamp.nativewindow.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Insets
/*     */   implements Cloneable, InsetsImmutable
/*     */ {
/*  36 */   static final InsetsImmutable zeroInsets = new Insets(); private int l; private int r; public static final InsetsImmutable getZero() {
/*  37 */     return zeroInsets;
/*     */   }
/*     */   private int t; private int b;
/*     */   
/*     */   public Insets() {
/*  42 */     this(0, 0, 0, 0);
/*     */   }
/*     */   
/*     */   public Insets(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  46 */     this.l = paramInt1;
/*  47 */     this.r = paramInt2;
/*  48 */     this.t = paramInt3;
/*  49 */     this.b = paramInt4;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object cloneMutable() {
/*  54 */     return clone();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object clone() {
/*     */     try {
/*  60 */       return super.clone();
/*  61 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*  62 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int getLeftWidth() {
/*  67 */     return this.l;
/*     */   } public final int getRightWidth() {
/*  69 */     return this.r;
/*     */   } public final int getTotalWidth() {
/*  71 */     return this.l + this.r;
/*     */   } public final int getTopHeight() {
/*  73 */     return this.t;
/*     */   } public final int getBottomHeight() {
/*  75 */     return this.b;
/*     */   } public final int getTotalHeight() {
/*  77 */     return this.t + this.b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  87 */     this.l = paramInt1; this.r = paramInt2; this.t = paramInt3; this.b = paramInt4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLeftWidth(int paramInt) {
/*  93 */     this.l = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setRightWidth(int paramInt) {
/*  98 */     this.r = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setTopHeight(int paramInt) {
/* 103 */     this.t = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setBottomHeight(int paramInt) {
/* 108 */     this.b = paramInt;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 112 */     if (this == paramObject) return true; 
/* 113 */     if (paramObject instanceof Insets) {
/* 114 */       Insets insets = (Insets)paramObject;
/* 115 */       return (this.r == insets.r && this.l == insets.l && this.b == insets.b && this.t == insets.t);
/*     */     } 
/*     */     
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     int i = this.l + this.b;
/* 124 */     int j = this.t + this.r;
/* 125 */     int k = i * (i + 1) / 2 + this.l;
/* 126 */     int m = j * (j + 1) / 2 + this.r;
/* 127 */     int n = k + m;
/* 128 */     return n * (n + 1) / 2 + m;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 133 */     return "[ l " + this.l + ", r " + this.r + " - t " + this.t + ", b " + this.b + " - " + getTotalWidth() + "x" + getTotalHeight() + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/Insets.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */