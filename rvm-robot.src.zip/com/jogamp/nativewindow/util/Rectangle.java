/*     */ package com.jogamp.nativewindow.util;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rectangle
/*     */   implements Cloneable, RectangleImmutable
/*     */ {
/*     */   int x;
/*     */   int y;
/*     */   int width;
/*     */   int height;
/*     */   
/*     */   public Rectangle() {
/*  40 */     this(0, 0, 0, 0);
/*     */   }
/*     */   
/*     */   public Rectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  44 */     this.x = paramInt1;
/*  45 */     this.y = paramInt2;
/*  46 */     this.width = paramInt3;
/*  47 */     this.height = paramInt4;
/*     */   }
/*     */   public Rectangle(RectangleImmutable paramRectangleImmutable) {
/*  50 */     set(paramRectangleImmutable);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object cloneMutable() {
/*  55 */     return clone();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object clone() {
/*     */     try {
/*  61 */       return super.clone();
/*  62 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*  63 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int getX() {
/*  68 */     return this.x;
/*     */   } public final int getY() {
/*  70 */     return this.y;
/*     */   } public final int getWidth() {
/*  72 */     return this.width;
/*     */   } public final int getHeight() {
/*  74 */     return this.height;
/*     */   }
/*     */   public final Rectangle set(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  77 */     this.x = paramInt1;
/*  78 */     this.y = paramInt2;
/*  79 */     this.width = paramInt3;
/*  80 */     this.height = paramInt4;
/*  81 */     return this;
/*     */   }
/*     */   public final Rectangle set(RectangleImmutable paramRectangleImmutable) {
/*  84 */     this.x = paramRectangleImmutable.getX();
/*  85 */     this.y = paramRectangleImmutable.getY();
/*  86 */     this.width = paramRectangleImmutable.getWidth();
/*  87 */     this.height = paramRectangleImmutable.getHeight();
/*  88 */     return this;
/*     */   }
/*  90 */   public final Rectangle setX(int paramInt) { this.x = paramInt; return this; }
/*  91 */   public final Rectangle setY(int paramInt) { this.y = paramInt; return this; }
/*  92 */   public final Rectangle setWidth(int paramInt) { this.width = paramInt; return this; } public final Rectangle setHeight(int paramInt) {
/*  93 */     this.height = paramInt; return this;
/*     */   }
/*     */   
/*     */   public final Rectangle union(RectangleImmutable paramRectangleImmutable) {
/*  97 */     return union(paramRectangleImmutable.getX(), paramRectangleImmutable.getY(), paramRectangleImmutable.getX() + paramRectangleImmutable.getWidth() - 1, paramRectangleImmutable.getY() + paramRectangleImmutable.getHeight() - 1);
/*     */   }
/*     */   
/*     */   public final Rectangle union(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 101 */     int i = Math.min(this.x, paramInt1);
/* 102 */     int j = Math.min(this.y, paramInt2);
/* 103 */     int k = Math.max(this.x + this.width - 1, paramInt3);
/* 104 */     int m = Math.max(this.y + this.height - 1, paramInt4);
/* 105 */     return new Rectangle(i, j, k - i + 1, m - j + 1);
/*     */   }
/*     */   
/*     */   public final Rectangle union(List<RectangleImmutable> paramList) {
/* 109 */     int i = Integer.MAX_VALUE, j = Integer.MAX_VALUE;
/* 110 */     int k = Integer.MIN_VALUE, m = Integer.MIN_VALUE;
/* 111 */     for (int n = paramList.size() - 1; n >= 0; n--) {
/* 112 */       RectangleImmutable rectangleImmutable = paramList.get(n);
/* 113 */       i = Math.min(i, rectangleImmutable.getX());
/* 114 */       k = Math.max(k, rectangleImmutable.getX() + rectangleImmutable.getWidth());
/* 115 */       j = Math.min(j, rectangleImmutable.getY());
/* 116 */       m = Math.max(m, rectangleImmutable.getY() + rectangleImmutable.getHeight());
/*     */     } 
/* 118 */     return new Rectangle(i, j, k - i, m - j);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Rectangle intersection(RectangleImmutable paramRectangleImmutable) {
/* 123 */     return intersection(paramRectangleImmutable.getX(), paramRectangleImmutable.getY(), paramRectangleImmutable.getX() + paramRectangleImmutable.getWidth() - 1, paramRectangleImmutable.getY() + paramRectangleImmutable.getHeight() - 1);
/*     */   }
/*     */   
/*     */   public final Rectangle intersection(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 127 */     int n, i1, i2, i3, i = Math.max(this.x, paramInt1);
/* 128 */     int j = Math.max(this.y, paramInt2);
/* 129 */     int k = Math.min(this.x + this.width - 1, paramInt3);
/* 130 */     int m = Math.min(this.y + this.height - 1, paramInt4);
/*     */     
/* 132 */     if (k < i) {
/* 133 */       n = 0;
/* 134 */       i2 = 0;
/*     */     } else {
/* 136 */       n = i;
/* 137 */       i2 = k - i + 1;
/*     */     } 
/* 139 */     if (m < j) {
/* 140 */       i1 = 0;
/* 141 */       i3 = 0;
/*     */     } else {
/* 143 */       i1 = j;
/* 144 */       i3 = m - j + 1;
/*     */     } 
/* 146 */     return new Rectangle(n, i1, i2, i3);
/*     */   }
/*     */   
/*     */   public final float coverage(RectangleImmutable paramRectangleImmutable) {
/* 150 */     Rectangle rectangle = intersection(paramRectangleImmutable);
/* 151 */     float f1 = (rectangle.getWidth() * rectangle.getHeight());
/* 152 */     float f2 = (this.width * this.height);
/* 153 */     return f1 / f2;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean contains(RectangleImmutable paramRectangleImmutable) {
/* 158 */     int i = this.x + this.width - 1;
/* 159 */     int j = this.y + this.height - 1;
/* 160 */     int k = paramRectangleImmutable.getX();
/* 161 */     int m = paramRectangleImmutable.getY();
/* 162 */     int n = k + paramRectangleImmutable.getWidth() - 1;
/* 163 */     int i1 = m + paramRectangleImmutable.getHeight() - 1;
/* 164 */     if (k < this.x || m < this.y || n > i || i1 > j)
/*     */     {
/* 166 */       return false;
/*     */     }
/* 168 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Rectangle scale(int paramInt1, int paramInt2) {
/* 179 */     this.x *= paramInt1;
/* 180 */     this.y *= paramInt2;
/* 181 */     this.width *= paramInt1;
/* 182 */     this.height *= paramInt2;
/* 183 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Rectangle scale(float paramFloat1, float paramFloat2) {
/* 194 */     this.x = (int)(this.x * paramFloat1 + 0.5F);
/* 195 */     this.y = (int)(this.y * paramFloat2 + 0.5F);
/* 196 */     this.width = (int)(this.width * paramFloat1 + 0.5F);
/* 197 */     this.height = (int)(this.height * paramFloat2 + 0.5F);
/* 198 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Rectangle scaleInv(int paramInt1, int paramInt2) {
/* 209 */     this.x /= paramInt1;
/* 210 */     this.y /= paramInt2;
/* 211 */     this.width /= paramInt1;
/* 212 */     this.height /= paramInt2;
/* 213 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Rectangle scaleInv(float paramFloat1, float paramFloat2) {
/* 224 */     this.x = (int)(this.x / paramFloat1 + 0.5F);
/* 225 */     this.y = (int)(this.y / paramFloat2 + 0.5F);
/* 226 */     this.width = (int)(this.width / paramFloat1 + 0.5F);
/* 227 */     this.height = (int)(this.height / paramFloat2 + 0.5F);
/* 228 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(RectangleImmutable paramRectangleImmutable) {
/* 234 */     int i = this.width * this.height;
/* 235 */     int j = paramRectangleImmutable.getWidth() * paramRectangleImmutable.getHeight();
/*     */     
/* 237 */     if (i > j)
/* 238 */       return 1; 
/* 239 */     if (i < j) {
/* 240 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 245 */     i = this.x * this.y;
/* 246 */     j = paramRectangleImmutable.getX() * paramRectangleImmutable.getY();
/*     */     
/* 248 */     if (i > j)
/* 249 */       return 1; 
/* 250 */     if (i < j) {
/* 251 */       return -1;
/*     */     }
/*     */     
/* 254 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 259 */     if (this == paramObject) return true; 
/* 260 */     if (paramObject instanceof Rectangle) {
/* 261 */       Rectangle rectangle = (Rectangle)paramObject;
/* 262 */       return (this.y == rectangle.y && this.x == rectangle.x && this.height == rectangle.height && this.width == rectangle.width);
/*     */     } 
/*     */     
/* 265 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 270 */     int i = this.x + this.height;
/* 271 */     int j = this.width + this.y;
/* 272 */     int k = i * (i + 1) / 2 + this.x;
/* 273 */     int m = j * (j + 1) / 2 + this.y;
/* 274 */     int n = k + m;
/* 275 */     return n * (n + 1) / 2 + m;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 280 */     return "[ " + this.x + " / " + this.y + "  " + this.width + " x " + this.height + " ]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/Rectangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */