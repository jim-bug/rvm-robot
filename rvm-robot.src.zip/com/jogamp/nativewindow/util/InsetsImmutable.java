package com.jogamp.nativewindow.util;

import com.jogamp.common.type.WriteCloneable;

public interface InsetsImmutable extends WriteCloneable {
  int getLeftWidth();
  
  int getRightWidth();
  
  int getTotalWidth();
  
  int getTopHeight();
  
  int getBottomHeight();
  
  int getTotalHeight();
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/InsetsImmutable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */