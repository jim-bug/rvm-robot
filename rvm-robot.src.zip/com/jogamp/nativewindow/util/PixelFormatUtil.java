/*     */ package com.jogamp.nativewindow.util;
/*     */ 
/*     */ import com.jogamp.common.nio.Buffers;
/*     */ import com.jogamp.common.util.Bitstream;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PixelFormatUtil
/*     */ {
/*     */   private static boolean DEBUG = false;
/*     */   
/*     */   public static class ComponentMap
/*     */   {
/*     */     final int[] dst2src;
/*     */     final int[] src2dst;
/*     */     final int[] srcRGBA;
/*     */     final boolean hasSrcRGB;
/*     */     
/*     */     public ComponentMap(PixelFormat.Composition param1Composition1, PixelFormat.Composition param1Composition2) {
/*  65 */       int i = param1Composition1.componentCount();
/*  66 */       int j = param1Composition2.componentCount();
/*  67 */       PixelFormat.CType[] arrayOfCType1 = param1Composition1.componentOrder();
/*  68 */       PixelFormat.CType[] arrayOfCType2 = param1Composition2.componentOrder();
/*     */       
/*  70 */       this.dst2src = new int[j]; byte b;
/*  71 */       for (b = 0; b < j; b++) {
/*  72 */         this.dst2src[b] = PixelFormatUtil.find(arrayOfCType2[b], arrayOfCType1, true);
/*     */       }
/*  74 */       this.src2dst = new int[i];
/*  75 */       for (b = 0; b < i; b++) {
/*  76 */         this.src2dst[b] = PixelFormatUtil.find(arrayOfCType1[b], arrayOfCType2, true);
/*     */       }
/*  78 */       this.srcRGBA = new int[4];
/*  79 */       this.srcRGBA[0] = PixelFormatUtil.find(PixelFormat.CType.R, arrayOfCType1, false);
/*  80 */       this.srcRGBA[1] = PixelFormatUtil.find(PixelFormat.CType.G, arrayOfCType1, false);
/*  81 */       this.srcRGBA[2] = PixelFormatUtil.find(PixelFormat.CType.B, arrayOfCType1, false);
/*  82 */       this.srcRGBA[3] = PixelFormatUtil.find(PixelFormat.CType.A, arrayOfCType1, false);
/*  83 */       this.hasSrcRGB = (0 <= this.srcRGBA[0] && 0 <= this.srcRGBA[1] && 0 <= this.srcRGBA[2]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int find(PixelFormat.CType paramCType, PixelFormat.CType[] paramArrayOfCType, boolean paramBoolean) {
/*  89 */     int i = paramArrayOfCType.length - 1;
/*  90 */     for (; i >= 0 && paramArrayOfCType[i] != paramCType; i--);
/*     */     
/*  92 */     if (0 > i && paramBoolean && 1 == paramArrayOfCType.length && paramArrayOfCType[0] == PixelFormat.CType.Y && (PixelFormat.CType.R == paramCType || PixelFormat.CType.G == paramCType || PixelFormat.CType.B == paramCType))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  98 */       return 0;
/*     */     }
/* 100 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getShiftedI32(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 113 */     if (paramInt1 <= 4) {
/* 114 */       int i = 0;
/* 115 */       for (byte b = 0; b < paramInt1; b++) {
/* 116 */         i |= (0xFF & paramArrayOfbyte[paramInt2 + b]) << 8 * b;
/*     */       }
/* 118 */       return i;
/*     */     } 
/* 120 */     throw new UnsupportedOperationException(paramInt1 + " bytesPerPixel too big, i.e. > 4");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getShiftedI64(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 132 */     if (paramInt1 <= 8) {
/* 133 */       long l = 0L;
/* 134 */       for (byte b = 0; b < paramInt1; b++) {
/* 135 */         l |= ((0xFF & paramArrayOfbyte[paramInt2 + b]) << 8 * b);
/*     */       }
/* 137 */       return l;
/*     */     } 
/* 139 */     throw new UnsupportedOperationException(paramInt1 + " bytesPerPixel too big, i.e. > 8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getShiftedI32(int paramInt, ByteBuffer paramByteBuffer, boolean paramBoolean) {
/* 152 */     if (paramInt <= 4) {
/* 153 */       int i = 0;
/* 154 */       if (paramBoolean) {
/* 155 */         int j = paramByteBuffer.position();
/* 156 */         for (byte b = 0; b < paramInt; b++) {
/* 157 */           i |= (0xFF & paramByteBuffer.get(j + b)) << 8 * b;
/*     */         }
/*     */       } else {
/* 160 */         for (byte b = 0; b < paramInt; b++) {
/* 161 */           i |= (0xFF & paramByteBuffer.get()) << 8 * b;
/*     */         }
/*     */       } 
/* 164 */       return i;
/*     */     } 
/* 166 */     throw new UnsupportedOperationException(paramInt + " bytesPerPixel too big, i.e. > 4");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getShiftedI64(int paramInt, ByteBuffer paramByteBuffer, boolean paramBoolean) {
/* 179 */     if (paramInt <= 8) {
/* 180 */       long l = 0L;
/* 181 */       if (paramBoolean) {
/* 182 */         int i = paramByteBuffer.position();
/* 183 */         for (byte b = 0; b < paramInt; b++) {
/* 184 */           l |= ((0xFF & paramByteBuffer.get(i + b)) << 8 * b);
/*     */         }
/*     */       } else {
/* 187 */         for (byte b = 0; b < paramInt; b++) {
/* 188 */           l |= ((0xFF & paramByteBuffer.get()) << 8 * b);
/*     */         }
/*     */       } 
/* 191 */       return l;
/*     */     } 
/* 193 */     throw new UnsupportedOperationException(paramInt + " bytesPerPixel too big, i.e. > 8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PixelFormat getReversed(PixelFormat paramPixelFormat) {
/* 202 */     switch (paramPixelFormat) {
/*     */       case RGB565:
/* 204 */         return PixelFormat.BGR565;
/*     */       case BGR565:
/* 206 */         return PixelFormat.RGB565;
/*     */       case RGBA5551:
/* 208 */         return PixelFormat.ABGR1555;
/*     */       case ABGR1555:
/* 210 */         return PixelFormat.RGBA5551;
/*     */       case RGB888:
/* 212 */         return PixelFormat.BGR888;
/*     */       case BGR888:
/* 214 */         return PixelFormat.RGB888;
/*     */       case RGBA8888:
/* 216 */         return PixelFormat.ABGR8888;
/*     */       case ABGR8888:
/* 218 */         return PixelFormat.RGBA8888;
/*     */       case ARGB8888:
/* 220 */         return PixelFormat.BGRA8888;
/*     */       case BGRA8888:
/* 222 */         return PixelFormat.ABGR8888;
/*     */     } 
/* 224 */     return paramPixelFormat;
/*     */   }
/*     */   
/*     */   public static int convertToInt32(PixelFormat paramPixelFormat, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4) {
/*     */     byte b;
/* 229 */     switch (paramPixelFormat) {
/*     */       case LUMINANCE:
/* 231 */         b = (byte)(((0xFF & paramByte1) + (0xFF & paramByte2) + (0xFF & paramByte3)) / 3 * paramByte4);
/* 232 */         return 0xFF000000 | (0xFF & b) << 16 | (0xFF & b) << 8 | 0xFF & b;
/*     */       
/*     */       case RGB888:
/* 235 */         return 0xFF000000 | (0xFF & paramByte3) << 16 | (0xFF & paramByte2) << 8 | 0xFF & paramByte1;
/*     */       case BGR888:
/* 237 */         return 0xFF000000 | (0xFF & paramByte1) << 16 | (0xFF & paramByte2) << 8 | 0xFF & paramByte3;
/*     */       case RGBA8888:
/* 239 */         return (0xFF & paramByte4) << 24 | (0xFF & paramByte3) << 16 | (0xFF & paramByte2) << 8 | 0xFF & paramByte1;
/*     */       case ABGR8888:
/* 241 */         return (0xFF & paramByte1) << 24 | (0xFF & paramByte2) << 16 | (0xFF & paramByte3) << 8 | 0xFF & paramByte4;
/*     */       case ARGB8888:
/* 243 */         return (0xFF & paramByte3) << 24 | (0xFF & paramByte2) << 16 | (0xFF & paramByte1) << 8 | 0xFF & paramByte4;
/*     */       case BGRA8888:
/* 245 */         return (0xFF & paramByte4) << 24 | (0xFF & paramByte1) << 16 | (0xFF & paramByte2) << 8 | 0xFF & paramByte3;
/*     */     } 
/* 247 */     throw new InternalError("Unhandled format " + paramPixelFormat);
/*     */   }
/*     */   public static int convertToInt32(PixelFormat paramPixelFormat1, PixelFormat paramPixelFormat2, ByteBuffer paramByteBuffer, int paramInt) { byte b;
/*     */     byte b1;
/*     */     byte b2;
/*     */     byte b3;
/* 253 */     switch (paramPixelFormat2) {
/*     */       case LUMINANCE:
/* 255 */         b = paramByteBuffer.get(paramInt++);
/* 256 */         b1 = b;
/* 257 */         b2 = b;
/* 258 */         b3 = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 299 */         return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case RGB888: b = paramByteBuffer.get(paramInt++); b1 = paramByteBuffer.get(paramInt++); b2 = paramByteBuffer.get(paramInt++); b3 = -1; return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case BGR888: b2 = paramByteBuffer.get(paramInt++); b1 = paramByteBuffer.get(paramInt++); b = paramByteBuffer.get(paramInt++); b3 = -1; return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case RGBA8888: b = paramByteBuffer.get(paramInt++); b1 = paramByteBuffer.get(paramInt++); b2 = paramByteBuffer.get(paramInt++); b3 = paramByteBuffer.get(paramInt++); return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case ABGR8888: b3 = paramByteBuffer.get(paramInt++); b2 = paramByteBuffer.get(paramInt++); b1 = paramByteBuffer.get(paramInt++); b = paramByteBuffer.get(paramInt++); return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case ARGB8888: b3 = paramByteBuffer.get(paramInt++); b = paramByteBuffer.get(paramInt++); b1 = paramByteBuffer.get(paramInt++); b2 = paramByteBuffer.get(paramInt++); return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case BGRA8888: b2 = paramByteBuffer.get(paramInt++); b1 = paramByteBuffer.get(paramInt++); b = paramByteBuffer.get(paramInt++); b3 = paramByteBuffer.get(paramInt++); return convertToInt32(paramPixelFormat1, b, b1, b2, b3);
/*     */     }  throw new InternalError("Unhandled format " + paramPixelFormat2); } public static int convertToInt32(PixelFormat paramPixelFormat1, PixelFormat paramPixelFormat2, int paramInt) { byte b;
/*     */     byte b1;
/*     */     byte b2;
/*     */     byte b3;
/* 304 */     switch (paramPixelFormat2) {
/*     */       case LUMINANCE:
/* 306 */         b = (byte)paramInt;
/* 307 */         b1 = b;
/* 308 */         b2 = b;
/* 309 */         b3 = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 350 */         return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case RGB888: b = (byte)paramInt; b1 = (byte)(paramInt >>> 8); b2 = (byte)(paramInt >>> 16); b3 = -1; return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case BGR888: b2 = (byte)paramInt; b1 = (byte)(paramInt >>> 8); b = (byte)(paramInt >>> 16); b3 = -1; return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case RGBA8888: b = (byte)paramInt; b1 = (byte)(paramInt >>> 8); b2 = (byte)(paramInt >>> 16); b3 = (byte)(paramInt >>> 24); return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case ABGR8888: b3 = (byte)paramInt; b2 = (byte)(paramInt >>> 8); b1 = (byte)(paramInt >>> 16); b = (byte)(paramInt >>> 24); return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case ARGB8888: b3 = (byte)paramInt; b = (byte)(paramInt >>> 8); b1 = (byte)(paramInt >>> 16); b2 = (byte)(paramInt >>> 24); return convertToInt32(paramPixelFormat1, b, b1, b2, b3);case BGRA8888: b2 = (byte)paramInt; b1 = (byte)(paramInt >>> 8); b = (byte)(paramInt >>> 16); b3 = (byte)(paramInt >>> 24); return convertToInt32(paramPixelFormat1, b, b1, b2, b3);
/*     */     } 
/*     */     throw new InternalError("Unhandled format " + paramPixelFormat2); }
/*     */ 
/*     */   
/*     */   public static PixelRectangle convert(PixelRectangle paramPixelRectangle, PixelFormat paramPixelFormat, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/* 356 */     int m, i = paramPixelRectangle.getSize().getWidth();
/* 357 */     int j = paramPixelRectangle.getSize().getHeight();
/* 358 */     int k = paramPixelFormat.comp.bytesPerPixel();
/*     */     
/* 360 */     if (0 != paramInt) {
/* 361 */       m = paramInt;
/*     */     } else {
/* 363 */       m = k * i;
/*     */     } 
/* 365 */     int n = m * j;
/* 366 */     ByteBuffer byteBuffer = paramBoolean2 ? Buffers.newDirectByteBuffer(n) : ByteBuffer.allocate(n).order(paramPixelRectangle.getPixels().order());
/* 367 */     convert(paramPixelRectangle, byteBuffer, paramPixelFormat, paramBoolean1, m);
/* 368 */     return new PixelRectangle.GenericPixelRect(paramPixelFormat, paramPixelRectangle.getSize(), m, paramBoolean1, byteBuffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void convert(PixelRectangle paramPixelRectangle, ByteBuffer paramByteBuffer, PixelFormat paramPixelFormat, boolean paramBoolean, int paramInt) throws IllegalStateException {
/* 388 */     convert(paramPixelRectangle.getSize().getWidth(), paramPixelRectangle.getSize().getHeight(), paramPixelRectangle
/* 389 */         .getPixels(), paramPixelRectangle.getPixelformat(), paramPixelRectangle.isGLOriented(), paramPixelRectangle.getStride(), paramByteBuffer, paramPixelFormat, paramBoolean, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void convert(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer1, PixelFormat paramPixelFormat1, boolean paramBoolean1, int paramInt3, ByteBuffer paramByteBuffer2, PixelFormat paramPixelFormat2, boolean paramBoolean2, int paramInt4) throws IllegalStateException, IllegalArgumentException {
/* 419 */     PixelFormat.Composition composition1 = paramPixelFormat1.comp;
/* 420 */     PixelFormat.Composition composition2 = paramPixelFormat2.comp;
/* 421 */     int i = composition1.bytesPerPixel();
/* 422 */     int j = composition2.bytesPerPixel();
/*     */     
/* 424 */     if (0 != paramInt3) {
/* 425 */       if (paramInt3 < i * paramInt1) {
/* 426 */         throw new IllegalArgumentException(String.format("Invalid %s stride %d, must be greater than bytesPerPixel %d * width %d", new Object[] { "source", 
/* 427 */                 Integer.valueOf(paramInt3), Integer.valueOf(i), Integer.valueOf(paramInt1) }));
/*     */       }
/*     */     } else {
/* 430 */       paramInt3 = i * paramInt1;
/*     */     } 
/* 432 */     if (0 != paramInt4) {
/* 433 */       if (paramInt4 < j * paramInt1) {
/* 434 */         throw new IllegalArgumentException(String.format("Invalid %s stride %d, must be greater than bytesPerPixel %d * width %d", new Object[] { "destination", 
/* 435 */                 Integer.valueOf(paramInt4), Integer.valueOf(j), Integer.valueOf(paramInt1) }));
/*     */       }
/*     */     } else {
/* 438 */       paramInt4 = j * paramInt1;
/*     */     } 
/*     */ 
/*     */     
/* 442 */     int k = composition2.bitStride();
/* 443 */     boolean bool1 = (paramBoolean1 != paramBoolean2) ? true : false;
/* 444 */     boolean bool2 = (composition1.equals(composition2) && 0 == k % 8) ? true : false;
/* 445 */     if (DEBUG) {
/* 446 */       System.err.println("XXX: size " + paramInt1 + "x" + paramInt2 + ", fast_copy " + bool2);
/* 447 */       System.err.println("XXX: SRC fmt " + paramPixelFormat1 + ", " + composition1 + ", stride " + paramInt3 + ", isGLOrient " + paramBoolean1);
/* 448 */       System.err.println("XXX: DST fmt " + paramPixelFormat2 + ", " + composition2 + ", stride " + paramInt4 + ", isGLOrient " + paramBoolean2);
/*     */     } 
/*     */     
/* 451 */     if (bool2) {
/*     */       
/* 453 */       for (byte b = 0; b < paramInt2; b++) {
/* 454 */         int m = bool1 ? ((paramInt2 - 1 - b) * paramInt3) : (b * paramInt3);
/* 455 */         int n = paramInt4 * b;
/* 456 */         for (byte b1 = 0; b1 < paramInt1; b1++) {
/* 457 */           paramByteBuffer2.put(n + 0, paramByteBuffer1.get(m + 0));
/* 458 */           if (2 <= j) {
/* 459 */             paramByteBuffer2.put(n + 1, paramByteBuffer1.get(m + 1));
/* 460 */             if (3 <= j) {
/* 461 */               paramByteBuffer2.put(n + 2, paramByteBuffer1.get(m + 2));
/* 462 */               if (4 <= j) {
/* 463 */                 paramByteBuffer2.put(n + 3, paramByteBuffer1.get(m + 3));
/*     */               }
/*     */             } 
/*     */           } 
/* 467 */           m += i;
/* 468 */           n += j;
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 473 */       ComponentMap componentMap = new ComponentMap(paramPixelFormat1.comp, paramPixelFormat2.comp);
/*     */       
/* 475 */       Bitstream.ByteBufferStream byteBufferStream1 = new Bitstream.ByteBufferStream(paramByteBuffer1);
/* 476 */       Bitstream<ByteBuffer> bitstream1 = new Bitstream((Bitstream.ByteStream)byteBufferStream1, false);
/* 477 */       bitstream1.setThrowIOExceptionOnEOF(true);
/*     */       
/* 479 */       Bitstream.ByteBufferStream byteBufferStream2 = new Bitstream.ByteBufferStream(paramByteBuffer2);
/* 480 */       Bitstream<ByteBuffer> bitstream2 = new Bitstream((Bitstream.ByteStream)byteBufferStream2, true);
/* 481 */       bitstream2.setThrowIOExceptionOnEOF(true);
/*     */       
/* 483 */       if (DEBUG) {
/* 484 */         System.err.println("XXX: cmap.dst2src " + Arrays.toString(componentMap.dst2src));
/* 485 */         System.err.println("XXX: cmap.src2dst " + Arrays.toString(componentMap.src2dst));
/* 486 */         System.err.println("XXX: cmap.srcRGBA " + Arrays.toString(componentMap.srcRGBA));
/* 487 */         System.err.println("XXX: srcBitStream " + bitstream1);
/* 488 */         System.err.println("XXX: dstBitStream " + bitstream2);
/*     */       } 
/*     */       try {
/* 491 */         for (byte b = 0; b < paramInt2; b++) {
/* 492 */           int m = bool1 ? ((paramInt2 - 1 - b) * paramInt3 * 8) : (b * paramInt3 * 8);
/*     */           
/* 494 */           bitstream1.position(m);
/* 495 */           for (byte b1 = 0; b1 < paramInt1; b1++) {
/* 496 */             convert(componentMap, composition2, bitstream2, composition1, bitstream1);
/*     */           }
/*     */           
/* 499 */           bitstream2.skip((paramInt4 * 8 - k * paramInt1));
/*     */         } 
/* 501 */       } catch (IOException iOException) {
/* 502 */         throw new RuntimeException(iOException);
/*     */       } 
/* 504 */       if (DEBUG) {
/* 505 */         System.err.println("XXX: srcBitStream " + bitstream1);
/* 506 */         System.err.println("XXX: dstBitStream " + bitstream2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void convert(ComponentMap paramComponentMap, PixelFormat.Composition paramComposition1, Bitstream<ByteBuffer> paramBitstream1, PixelFormat.Composition paramComposition2, Bitstream<ByteBuffer> paramBitstream2) throws IllegalStateException, IOException {
/* 516 */     int i = paramComposition2.componentCount();
/* 517 */     int j = paramComposition1.componentCount();
/* 518 */     int[] arrayOfInt1 = new int[i];
/* 519 */     int[] arrayOfInt2 = new int[j];
/* 520 */     int[] arrayOfInt3 = paramComposition2.componentBitCount();
/* 521 */     int[] arrayOfInt4 = paramComposition2.componentBitMask();
/* 522 */     int[] arrayOfInt5 = paramComposition1.componentBitCount();
/*     */     
/*     */     int k;
/* 525 */     for (k = 0; k < i; k++) {
/* 526 */       arrayOfInt1[k] = paramBitstream2.readBits31(arrayOfInt3[k]) & arrayOfInt4[k];
/*     */     }
/* 528 */     paramBitstream2.skip((paramComposition2.bitStride() - paramComposition2.bitsPerPixel()));
/*     */ 
/*     */     
/* 531 */     for (k = 0; k < j; k++) {
/* 532 */       arrayOfInt2[k] = paramComposition1.defaultValue(k, false);
/*     */     }
/*     */     
/* 535 */     if (1 == j && PixelFormat.CType.Y == paramComposition1
/* 536 */       .componentOrder()[0] && paramComponentMap.hasSrcRGB) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 541 */       k = arrayOfInt1[paramComponentMap.srcRGBA[0]];
/* 542 */       int m = arrayOfInt1[paramComponentMap.srcRGBA[1]];
/* 543 */       int n = arrayOfInt1[paramComponentMap.srcRGBA[2]];
/* 544 */       float f1 = paramComposition2.toFloat(k, paramComponentMap.srcRGBA[0], false);
/* 545 */       float f2 = paramComposition2.toFloat(m, paramComponentMap.srcRGBA[1], false);
/* 546 */       float f3 = paramComposition2.toFloat(n, paramComponentMap.srcRGBA[2], false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 553 */       boolean bool = true;
/* 554 */       float f4 = 1.0F;
/*     */       
/* 556 */       float f5 = (f1 + f2 + f3) * f4 / 3.0F;
/* 557 */       int i1 = paramComposition1.fromFloat(f5, 0, false);
/*     */       
/* 559 */       paramBitstream1.writeBits31(arrayOfInt5[0], i1);
/* 560 */       paramBitstream1.skip((paramComposition1.bitStride() - paramComposition1.bitsPerPixel()));
/* 561 */       if (DEBUG && 
/* 562 */         paramBitstream2.position() <= 32L) {
/* 563 */         System.err.printf("convert: rgb[a] -> Y: rgb 0x%02X 0x%02X 0x%02X 0x%02X -> %f %f %f %f -> %f -> dstC 0 0x%08X (%d bits: %s)%n", new Object[] {
/*     */               
/* 565 */               Integer.valueOf(k), Integer.valueOf(m), Integer.valueOf(n), Integer.valueOf(bool), 
/* 566 */               Float.valueOf(f1), Float.valueOf(f2), Float.valueOf(f3), Float.valueOf(f4), 
/* 567 */               Float.valueOf(f5), Integer.valueOf(i1), Integer.valueOf(arrayOfInt5[0]), Bitstream.toBinString(true, i1, arrayOfInt5[0])
/*     */             });
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 574 */     for (k = 0; k < j; k++) {
/*     */       int m;
/* 576 */       if (0 <= (m = paramComponentMap.dst2src[k])) {
/* 577 */         float f = paramComposition2.toFloat(arrayOfInt1[m], m, false);
/* 578 */         int n = paramComposition1.fromFloat(f, k, false);
/* 579 */         paramBitstream1.writeBits31(arrayOfInt5[k], n);
/* 580 */         if (DEBUG && 
/* 581 */           paramBitstream2.position() <= 32L) {
/* 582 */           System.err.printf("convert: srcC %d: 0x%08X -> %f -> dstC %d 0x%08X (%d bits: %s)%n", new Object[] {
/* 583 */                 Integer.valueOf(m), Integer.valueOf(arrayOfInt1[m]), Float.valueOf(f), Integer.valueOf(k), Integer.valueOf(n), Integer.valueOf(arrayOfInt5[k]), Bitstream.toBinString(true, n, arrayOfInt5[k])
/*     */               });
/*     */         }
/*     */       } else {
/* 587 */         paramBitstream1.writeBits31(arrayOfInt5[k], arrayOfInt2[k]);
/* 588 */         if (DEBUG && 
/* 589 */           paramBitstream2.position() <= 32L) {
/* 590 */           System.err.printf("convert: srcC %d: undef -> dstC %d 0x%08X (%d bits: %s)%n", new Object[] {
/* 591 */                 Integer.valueOf(m), Integer.valueOf(k), Integer.valueOf(arrayOfInt2[k]), Integer.valueOf(arrayOfInt5[k]), Bitstream.toBinString(true, arrayOfInt2[k], arrayOfInt5[k])
/*     */               });
/*     */         }
/*     */       } 
/*     */     } 
/* 596 */     paramBitstream1.skip((paramComposition1.bitStride() - paramComposition1.bitsPerPixel()));
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/PixelFormatUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */