/*     */ package com.jogamp.nativewindow.util;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PixelRectangle
/*     */ {
/*     */   int hashCode();
/*     */   
/*     */   PixelFormat getPixelformat();
/*     */   
/*     */   DimensionImmutable getSize();
/*     */   
/*     */   int getStride();
/*     */   
/*     */   boolean isGLOriented();
/*     */   
/*     */   ByteBuffer getPixels();
/*     */   
/*     */   String toString();
/*     */   
/*     */   public static class GenericPixelRect
/*     */     implements PixelRectangle
/*     */   {
/*     */     protected final PixelFormat pixelformat;
/*     */     protected final DimensionImmutable size;
/*     */     protected final int strideInBytes;
/*     */     protected final boolean isGLOriented;
/*     */     protected final ByteBuffer pixels;
/*  97 */     private int hashCode = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private volatile boolean hashCodeComputed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPixelRect(PixelFormat param1PixelFormat, DimensionImmutable param1DimensionImmutable, int param1Int, boolean param1Boolean, ByteBuffer param1ByteBuffer) throws IllegalArgumentException, IndexOutOfBoundsException {
/* 115 */       if (0 != param1Int) {
/* 116 */         if (param1Int < param1PixelFormat.comp.bytesPerPixel() * param1DimensionImmutable.getWidth()) {
/* 117 */           throw new IllegalArgumentException("Invalid stride " + param1Int + ", must be greater than bytesPerPixel " + param1PixelFormat.comp.bytesPerPixel() + " * width " + param1DimensionImmutable.getWidth());
/*     */         }
/*     */       } else {
/* 120 */         param1Int = param1PixelFormat.comp.bytesPerPixel() * param1DimensionImmutable.getWidth();
/*     */       } 
/* 122 */       int i = param1Int * param1DimensionImmutable.getHeight();
/* 123 */       if (param1ByteBuffer.limit() < i) {
/* 124 */         throw new IndexOutOfBoundsException("Dest buffer has insufficient bytes left, needs " + i + ": " + param1ByteBuffer);
/*     */       }
/* 126 */       this.pixelformat = param1PixelFormat;
/* 127 */       this.size = param1DimensionImmutable;
/* 128 */       this.strideInBytes = param1Int;
/* 129 */       this.isGLOriented = param1Boolean;
/* 130 */       this.pixels = param1ByteBuffer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPixelRect(PixelRectangle param1PixelRectangle) throws IllegalArgumentException, IndexOutOfBoundsException {
/* 142 */       this(param1PixelRectangle.getPixelformat(), param1PixelRectangle.getSize(), param1PixelRectangle.getStride(), param1PixelRectangle.isGLOriented(), param1PixelRectangle.getPixels());
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 147 */       if (!this.hashCodeComputed) {
/* 148 */         synchronized (this) {
/* 149 */           if (!this.hashCodeComputed) {
/*     */             
/* 151 */             int i = this.pixelformat.comp.hashCode();
/* 152 */             i = (i << 5) - i + this.size.hashCode();
/* 153 */             i = (i << 5) - i + this.strideInBytes;
/* 154 */             i = (i << 5) - i + (this.isGLOriented ? 1 : 0);
/* 155 */             this.hashCode = (i << 5) - i + this.pixels.hashCode();
/* 156 */             this.hashCodeComputed = true;
/*     */           } 
/*     */         } 
/*     */       }
/* 160 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public PixelFormat getPixelformat() {
/* 165 */       return this.pixelformat;
/*     */     }
/*     */ 
/*     */     
/*     */     public DimensionImmutable getSize() {
/* 170 */       return this.size;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getStride() {
/* 175 */       return this.strideInBytes;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isGLOriented() {
/* 180 */       return this.isGLOriented;
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuffer getPixels() {
/* 185 */       return this.pixels;
/*     */     }
/*     */ 
/*     */     
/*     */     public final String toString() {
/* 190 */       return "PixelRect[obj 0x" + Integer.toHexString(super.hashCode()) + ", " + this.pixelformat + ", " + this.size + ", stride " + this.strideInBytes + ", isGLOrient " + this.isGLOriented + ", pixels " + this.pixels + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/PixelRectangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */