/*     */ package com.jogamp.nativewindow.util;
/*     */ 
/*     */ import com.jogamp.common.util.Bitfield;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PixelFormat
/*     */ {
/*  75 */   LUMINANCE(new CType[] { CType.Y }, 1, 8, 8),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   RGB565(new CType[] { CType.R, CType.G, CType.B }, new int[] { 31, 63, 31 }, new int[] { 0, 5, 11 }, 16),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   BGR565(new CType[] { CType.B, CType.G, CType.R }, new int[] { 31, 63, 31 }, new int[] { 0, 5, 11 }, 16),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   RGBA5551(new CType[] { CType.R, CType.G, CType.B, CType.A }, new int[] { 31, 31, 31, 1 }, new int[] { 0, 5, 10, 15 }, 16),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   ABGR1555(new CType[] { CType.A, CType.B, CType.G, CType.R }, new int[] { 1, 31, 31, 31 }, new int[] { 0, 1, 6, 11 }, 16),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   RGB888(new CType[] { CType.R, CType.G, CType.B }, 3, 8, 24),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   BGR888(new CType[] { CType.B, CType.G, CType.R }, 3, 8, 24),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   RGBx8888(new CType[] { CType.R, CType.G, CType.B }, 3, 8, 32),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   BGRx8888(new CType[] { CType.B, CType.G, CType.R }, 3, 8, 32),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   RGBA8888(new CType[] { CType.R, CType.G, CType.B, CType.A }, 4, 8, 32),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 304 */   ABGR8888(new CType[] { CType.A, CType.B, CType.G, CType.R }, 4, 8, 32),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 326 */   ARGB8888(new CType[] { CType.A, CType.R, CType.G, CType.B }, 4, 8, 32),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 350 */   BGRA8888(new CType[] { CType.B, CType.G, CType.R, CType.A }, 4, 8, 32);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Composition comp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PixelFormat(CType[] paramArrayOfCType, int paramInt1, int paramInt2, int paramInt3) {
/* 362 */     this.comp = new PackedComposition(paramArrayOfCType, paramInt1, paramInt2, paramInt3);
/*     */   } public static interface Composition {
/*     */     public static final int UNDEF = -1; boolean isUniform(); boolean isInterleaved(); int componentCount(); int bitsPerPixel(); int bitStride(); int bytesPerPixel(); PixelFormat.CType[] componentOrder(); int find(PixelFormat.CType param1CType); int[] componentBitMask(); int[] componentBitCount(); int[] componentBitShift(); int decodeSingleI32(int param1Int1, int param1Int2); int decodeSingleI64(long param1Long, int param1Int); int encodeSingleI32(int param1Int1, int param1Int2); long encodeSingleI64(int param1Int1, int param1Int2); int encode3CompI32(int param1Int1, int param1Int2, int param1Int3); int encode4CompI32(int param1Int1, int param1Int2, int param1Int3, int param1Int4); int encodeSingleI8(byte param1Byte, int param1Int); int encode3CompI8(byte param1Byte1, byte param1Byte2, byte param1Byte3); int encode4CompI8(byte param1Byte1, byte param1Byte2, byte param1Byte3, byte param1Byte4);
/*     */     float toFloat(int param1Int1, int param1Int2, boolean param1Boolean);
/*     */     int fromFloat(float param1Float, int param1Int, boolean param1Boolean);
/*     */     int defaultValue(int param1Int, boolean param1Boolean);
/*     */     int hashCode();
/*     */     boolean equals(Object param1Object);
/*     */     String toString(); }
/*     */   PixelFormat(CType[] paramArrayOfCType, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1) {
/* 372 */     this.comp = new PackedComposition(paramArrayOfCType, paramArrayOfint1, paramArrayOfint2, paramInt1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum CType
/*     */   {
/* 393 */     R,
/*     */     
/* 395 */     G,
/*     */     
/* 397 */     B,
/*     */     
/* 399 */     A,
/*     */     
/* 401 */     Y,
/*     */     
/* 403 */     U,
/*     */     
/* 405 */     V;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PackedComposition
/*     */     implements Composition
/*     */   {
/*     */     private final PixelFormat.CType[] compOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int[] compMask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int[] compBitCount;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int[] compBitShift;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int bitsPerPixel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int bitStride;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean uniform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int hashCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String toString() {
/* 532 */       return String.format("PackedComp[order %s, stride %d, bpp %d, uni %b, comp %d: %s]", new Object[] {
/* 533 */             Arrays.toString((Object[])this.compOrder), Integer.valueOf(this.bitStride), Integer.valueOf(this.bitsPerPixel), Boolean.valueOf(this.uniform), 
/* 534 */             Integer.valueOf(this.compMask.length), PixelFormat.access$000(this.compBitCount, this.compMask, this.compBitShift)
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PackedComposition(PixelFormat.CType[] param1ArrayOfCType, int param1Int1, int param1Int2, int param1Int3) {
/* 544 */       this.compOrder = param1ArrayOfCType;
/* 545 */       this.compMask = new int[param1Int1];
/* 546 */       this.compBitShift = new int[param1Int1];
/* 547 */       this.compBitCount = new int[param1Int1];
/* 548 */       int i = (1 << param1Int2) - 1;
/* 549 */       for (byte b = 0; b < param1Int1; b++) {
/* 550 */         this.compMask[b] = i;
/* 551 */         this.compBitShift[b] = param1Int2 * b;
/* 552 */         this.compBitCount[b] = param1Int2;
/*     */       } 
/* 554 */       this.uniform = true;
/* 555 */       this.bitsPerPixel = param1Int2 * param1Int1;
/* 556 */       this.bitStride = param1Int3;
/* 557 */       if (this.bitStride < this.bitsPerPixel) {
/* 558 */         throw new IllegalArgumentException(String.format("bit-stride %d < bitsPerPixel %d", new Object[] { Integer.valueOf(this.bitStride), Integer.valueOf(this.bitsPerPixel) }));
/*     */       }
/* 560 */       this.hashCode = hashCodeImpl();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PackedComposition(PixelFormat.CType[] param1ArrayOfCType, int[] param1ArrayOfint1, int[] param1ArrayOfint2, int param1Int) {
/* 570 */       this.compOrder = param1ArrayOfCType;
/* 571 */       this.compMask = param1ArrayOfint1;
/* 572 */       this.compBitShift = param1ArrayOfint2;
/* 573 */       this.compBitCount = new int[param1ArrayOfint1.length];
/* 574 */       int i = 0;
/* 575 */       boolean bool = true;
/* 576 */       for (int j = param1ArrayOfint1.length - 1; j >= 0; j--) {
/* 577 */         int k = param1ArrayOfint1[j];
/* 578 */         int m = Bitfield.Util.bitCount(k);
/* 579 */         i += m;
/* 580 */         this.compBitCount[j] = m;
/* 581 */         if (j > 0 && bool) {
/* 582 */           bool = (param1ArrayOfint1[j - 1] == k) ? true : false;
/*     */         }
/*     */       } 
/* 585 */       this.uniform = bool;
/* 586 */       this.bitsPerPixel = i;
/* 587 */       this.bitStride = param1Int;
/* 588 */       if (this.bitStride < this.bitsPerPixel) {
/* 589 */         throw new IllegalArgumentException(String.format("bit-stride %d < bitsPerPixel %d", new Object[] { Integer.valueOf(this.bitStride), Integer.valueOf(this.bitsPerPixel) }));
/*     */       }
/* 591 */       this.hashCode = hashCodeImpl();
/*     */     }
/*     */     
/*     */     public final boolean isUniform() {
/* 595 */       return this.uniform;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isInterleaved() {
/* 603 */       return true;
/*     */     } public final int componentCount() {
/* 605 */       return this.compMask.length;
/*     */     } public final int bitsPerPixel() {
/* 607 */       return this.bitsPerPixel;
/*     */     } public final int bitStride() {
/* 609 */       return this.bitStride;
/*     */     } public final int bytesPerPixel() {
/* 611 */       return (7 + this.bitStride) / 8;
/*     */     } public final PixelFormat.CType[] componentOrder() {
/* 613 */       return this.compOrder;
/*     */     } public final int find(PixelFormat.CType param1CType) {
/* 615 */       return PixelFormatUtil.find(param1CType, this.compOrder, false);
/*     */     } public final int[] componentBitMask() {
/* 617 */       return this.compMask;
/*     */     } public final int[] componentBitCount() {
/* 619 */       return this.compBitCount;
/*     */     } public final int[] componentBitShift() {
/* 621 */       return this.compBitShift;
/*     */     }
/*     */     
/*     */     public final int decodeSingleI32(int param1Int1, int param1Int2) {
/* 625 */       return param1Int1 >>> this.compBitShift[param1Int2] & this.compMask[param1Int2];
/*     */     }
/*     */     
/*     */     public final int decodeSingleI64(long param1Long, int param1Int) {
/* 629 */       return (int)(0xFFFFFFFFL & param1Long >>> this.compBitShift[param1Int]) & this.compMask[param1Int];
/*     */     }
/*     */     
/*     */     public final int encodeSingleI32(int param1Int1, int param1Int2) {
/* 633 */       return (param1Int1 & this.compMask[param1Int2]) << this.compBitShift[param1Int2];
/*     */     }
/*     */     
/*     */     public final long encodeSingleI64(int param1Int1, int param1Int2) {
/* 637 */       return (0xFFFFFFFFL & (param1Int1 & this.compMask[param1Int2])) << this.compBitShift[param1Int2];
/*     */     }
/*     */     
/*     */     public final int encode3CompI32(int param1Int1, int param1Int2, int param1Int3) {
/* 641 */       return (param1Int1 & this.compMask[0]) << this.compBitShift[0] | (param1Int2 & this.compMask[1]) << this.compBitShift[1] | (param1Int3 & this.compMask[2]) << this.compBitShift[2];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final int encode4CompI32(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 647 */       return (param1Int1 & this.compMask[0]) << this.compBitShift[0] | (param1Int2 & this.compMask[1]) << this.compBitShift[1] | (param1Int3 & this.compMask[2]) << this.compBitShift[2] | (param1Int4 & this.compMask[3]) << this.compBitShift[3];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int encodeSingleI8(byte param1Byte, int param1Int) {
/* 654 */       return (param1Byte & this.compMask[param1Int]) << this.compBitShift[param1Int];
/*     */     }
/*     */     
/*     */     public final int encode3CompI8(byte param1Byte1, byte param1Byte2, byte param1Byte3) {
/* 658 */       return (param1Byte1 & this.compMask[0]) << this.compBitShift[0] | (param1Byte2 & this.compMask[1]) << this.compBitShift[1] | (param1Byte3 & this.compMask[2]) << this.compBitShift[2];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final int encode4CompI8(byte param1Byte1, byte param1Byte2, byte param1Byte3, byte param1Byte4) {
/* 664 */       return (param1Byte1 & this.compMask[0]) << this.compBitShift[0] | (param1Byte2 & this.compMask[1]) << this.compBitShift[1] | (param1Byte3 & this.compMask[2]) << this.compBitShift[2] | (param1Byte4 & this.compMask[3]) << this.compBitShift[3];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final float toFloat(int param1Int1, int param1Int2, boolean param1Boolean) {
/* 672 */       if (param1Boolean) {
/* 673 */         return (param1Int1 >>> this.compBitShift[param1Int2] & this.compMask[param1Int2]) / this.compMask[param1Int2];
/*     */       }
/* 675 */       return (param1Int1 & this.compMask[param1Int2]) / this.compMask[param1Int2];
/*     */     }
/*     */ 
/*     */     
/*     */     public final int fromFloat(float param1Float, int param1Int, boolean param1Boolean) {
/* 680 */       int i = (int)(param1Float * this.compMask[param1Int] + 0.5F);
/* 681 */       return param1Boolean ? (i << this.compBitShift[param1Int]) : i;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final int defaultValue(int param1Int, boolean param1Boolean) {
/* 687 */       byte b = (PixelFormat.CType.A == this.compOrder[param1Int] || PixelFormat.CType.Y == this.compOrder[param1Int]) ? this.compMask[param1Int] : 0;
/* 688 */       return param1Boolean ? (b << this.compBitShift[param1Int]) : b;
/*     */     }
/*     */     
/*     */     public final int hashCode() {
/* 692 */       return this.hashCode;
/*     */     }
/*     */     private final int hashCodeImpl() {
/* 695 */       int i = 31 + this.bitStride;
/* 696 */       i = (i << 5) - i + this.bitsPerPixel;
/* 697 */       i = (i << 5) - i + this.compMask.length; int j;
/* 698 */       for (j = this.compOrder.length - 1; j >= 0; j--) {
/* 699 */         i = (i << 5) - i + this.compOrder[j].ordinal();
/*     */       }
/* 701 */       for (j = this.compMask.length - 1; j >= 0; j--) {
/* 702 */         i = (i << 5) - i + this.compMask[j];
/*     */       }
/* 704 */       for (j = this.compBitShift.length - 1; j >= 0; j--) {
/* 705 */         i = (i << 5) - i + this.compBitShift[j];
/*     */       }
/* 707 */       return i;
/*     */     }
/*     */ 
/*     */     
/*     */     public final boolean equals(Object param1Object) {
/* 712 */       if (this == param1Object) return true; 
/* 713 */       if (param1Object instanceof PackedComposition) {
/* 714 */         PackedComposition packedComposition = (PackedComposition)param1Object;
/* 715 */         return (this.bitStride == packedComposition.bitStride && this.bitsPerPixel == packedComposition.bitsPerPixel && 
/*     */           
/* 717 */           Arrays.equals((Object[])this.compOrder, (Object[])packedComposition.compOrder) && 
/* 718 */           Arrays.equals(this.compMask, packedComposition.compMask) && 
/* 719 */           Arrays.equals(this.compBitShift, packedComposition.compBitShift));
/*     */       } 
/* 721 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toHexString(int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3) {
/* 727 */     StringBuilder stringBuilder = new StringBuilder();
/* 728 */     stringBuilder.append("[");
/* 729 */     int i = paramArrayOfint2.length;
/* 730 */     for (byte b = 0; b < i; b++) {
/* 731 */       if (b > 0) {
/* 732 */         stringBuilder.append(", ");
/*     */       }
/* 734 */       stringBuilder.append(paramArrayOfint1[b]).append(": ")
/* 735 */         .append("0x").append(Integer.toHexString(paramArrayOfint2[b])).append(" << ").append(paramArrayOfint3[b]);
/*     */     } 
/* 737 */     return stringBuilder.append("]").toString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/PixelFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */