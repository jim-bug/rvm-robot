/*     */ package com.jogamp.nativewindow.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SurfaceSize
/*     */   implements Comparable<SurfaceSize>
/*     */ {
/*     */   final DimensionImmutable resolution;
/*     */   final int bitsPerPixel;
/*     */   
/*     */   public SurfaceSize(DimensionImmutable paramDimensionImmutable, int paramInt) {
/*  44 */     if (null == paramDimensionImmutable || paramInt <= 0) {
/*  45 */       throw new IllegalArgumentException("resolution must be set and bitsPerPixel greater 0");
/*     */     }
/*  47 */     this.resolution = paramDimensionImmutable;
/*  48 */     this.bitsPerPixel = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public final DimensionImmutable getResolution() {
/*  53 */     return this.resolution;
/*     */   }
/*     */   
/*     */   public final int getBitsPerPixel() {
/*  57 */     return this.bitsPerPixel;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/*  62 */     return "[ " + this.resolution + " pixels x " + this.bitsPerPixel + " bpp ]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(SurfaceSize paramSurfaceSize) {
/*  73 */     int i = this.resolution.compareTo(paramSurfaceSize.getResolution());
/*  74 */     if (0 != i) {
/*  75 */       return i;
/*     */     }
/*  77 */     int j = paramSurfaceSize.getBitsPerPixel();
/*  78 */     if (this.bitsPerPixel > j)
/*  79 */       return 1; 
/*  80 */     if (this.bitsPerPixel < j) {
/*  81 */       return -1;
/*     */     }
/*  83 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/*  96 */     if (this == paramObject) return true; 
/*  97 */     if (paramObject instanceof SurfaceSize) {
/*  98 */       SurfaceSize surfaceSize = (SurfaceSize)paramObject;
/*  99 */       return (getResolution().equals(surfaceSize.getResolution()) && 
/* 100 */         getBitsPerPixel() == surfaceSize.getBitsPerPixel());
/*     */     } 
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 108 */     int i = getResolution().hashCode();
/* 109 */     i = (i << 5) - i + getBitsPerPixel();
/* 110 */     return i;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/util/SurfaceSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */