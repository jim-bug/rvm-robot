/*     */ package com.jogamp.nativewindow.egl;
/*     */ 
/*     */ import com.jogamp.common.util.VersionNumber;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsDevice;
/*     */ import com.jogamp.nativewindow.DefaultGraphicsDevice;
/*     */ import com.jogamp.nativewindow.NativeWindowException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EGLGraphicsDevice
/*     */   extends DefaultGraphicsDevice
/*     */   implements Cloneable
/*     */ {
/*     */   public static final int EGL_DEFAULT_DISPLAY = 0;
/*     */   public static final int EGL_NO_DISPLAY = 0;
/*  51 */   private final long[] nativeDisplayID = new long[1];
/*     */   private EGLDisplayLifecycleCallback eglLifecycleCallback;
/*  53 */   private VersionNumber eglVersion = VersionNumber.zeroVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getNativeDisplayID(AbstractGraphicsDevice paramAbstractGraphicsDevice) {
/*  85 */     if (paramAbstractGraphicsDevice instanceof EGLGraphicsDevice) {
/*  86 */       return ((EGLGraphicsDevice)paramAbstractGraphicsDevice).getNativeDisplayID();
/*     */     }
/*  88 */     return paramAbstractGraphicsDevice.getHandle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EGLGraphicsDevice(long paramLong1, String paramString, int paramInt, long paramLong2, EGLDisplayLifecycleCallback paramEGLDisplayLifecycleCallback) {
/* 103 */     super(".egl", paramString, paramInt, paramLong2);
/* 104 */     this.nativeDisplayID[0] = paramLong1;
/* 105 */     this.eglLifecycleCallback = paramEGLDisplayLifecycleCallback;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EGLGraphicsDevice() {
/* 115 */     this(0L, DefaultGraphicsDevice.getDefaultDisplayConnection(), 0, 0L, (EGLDisplayLifecycleCallback)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EGLGraphicsDevice(long paramLong, String paramString, int paramInt) {
/* 130 */     this(paramLong, paramString, paramInt, 0L, (EGLDisplayLifecycleCallback)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EGLGraphicsDevice(long paramLong1, long paramLong2, String paramString, int paramInt) {
/* 144 */     this(paramLong1, paramString, paramInt, paramLong2, (EGLDisplayLifecycleCallback)null);
/* 145 */     if (0L == this.nativeDisplayID[0]) {
/* 146 */       throw new NativeWindowException("Invalid EGL_NO_DISPLAY display handle");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EGLGraphicsDevice(AbstractGraphicsDevice paramAbstractGraphicsDevice, EGLDisplayLifecycleCallback paramEGLDisplayLifecycleCallback) {
/* 160 */     this(getNativeDisplayID(paramAbstractGraphicsDevice), paramAbstractGraphicsDevice.getConnection(), paramAbstractGraphicsDevice.getUnitID(), 0L, paramEGLDisplayLifecycleCallback);
/* 161 */     if (null == paramEGLDisplayLifecycleCallback) {
/* 162 */       throw new NativeWindowException("Null EGLDisplayLifecycleCallback");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EGLGraphicsDevice(long paramLong, String paramString, int paramInt, EGLDisplayLifecycleCallback paramEGLDisplayLifecycleCallback) {
/* 178 */     this(paramLong, paramString, paramInt, 0L, paramEGLDisplayLifecycleCallback);
/* 179 */     if (null == paramEGLDisplayLifecycleCallback) {
/* 180 */       throw new NativeWindowException("Null EGLDisplayLifecycleCallback");
/*     */     }
/*     */   }
/*     */   
/*     */   public VersionNumber getEGLVersion() {
/* 185 */     return this.eglVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getNativeDisplayID() {
/* 195 */     return this.nativeDisplayID[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sameNativeDisplayID(AbstractGraphicsDevice paramAbstractGraphicsDevice) {
/* 206 */     return (getNativeDisplayID(paramAbstractGraphicsDevice) == getNativeDisplayID());
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 211 */     return super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean open() {
/* 222 */     if (null != this.eglLifecycleCallback && 0L == this.handle) {
/* 223 */       if (DEBUG) {
/* 224 */         System.err.println(Thread.currentThread().getName() + " - EGLGraphicsDevice.open(): " + this);
/*     */       }
/* 226 */       int[] arrayOfInt1 = { 0 };
/* 227 */       int[] arrayOfInt2 = { 0 };
/* 228 */       this.handle = this.eglLifecycleCallback.eglGetAndInitDisplay(this.nativeDisplayID, arrayOfInt1, arrayOfInt2);
/* 229 */       if (0L == this.handle) {
/* 230 */         this.eglVersion = VersionNumber.zeroVersion;
/* 231 */         throw new NativeWindowException("EGLGraphicsDevice.open() failed: " + this);
/*     */       } 
/* 233 */       this.eglVersion = new VersionNumber(arrayOfInt1[0], arrayOfInt2[0], 0);
/* 234 */       return true;
/*     */     } 
/*     */     
/* 237 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean close() {
/* 248 */     if (null != this.eglLifecycleCallback && 0L != this.handle) {
/* 249 */       if (DEBUG) {
/* 250 */         System.err.println(Thread.currentThread().getName() + " - EGLGraphicsDevice.close(): " + this);
/*     */       }
/* 252 */       this.eglLifecycleCallback.eglTerminate(this.handle);
/*     */     } 
/* 254 */     return super.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHandleOwner() {
/* 259 */     return (null != this.eglLifecycleCallback);
/*     */   }
/*     */   
/*     */   public void clearHandleOwner() {
/* 263 */     this.eglLifecycleCallback = null;
/*     */   }
/*     */   
/*     */   protected Object getHandleOwnership() {
/* 267 */     return this.eglLifecycleCallback;
/*     */   }
/*     */   
/*     */   protected Object setHandleOwnership(Object paramObject) {
/* 271 */     EGLDisplayLifecycleCallback eGLDisplayLifecycleCallback = this.eglLifecycleCallback;
/* 272 */     this.eglLifecycleCallback = (EGLDisplayLifecycleCallback)paramObject;
/* 273 */     return eGLDisplayLifecycleCallback;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 278 */     return getClass().getSimpleName() + "[type " + getType() + ", v" + this.eglVersion + ", nativeDisplayID 0x" + Long.toHexString(this.nativeDisplayID[0]) + ", connection " + getConnection() + ", unitID " + getUnitID() + ", handle 0x" + Long.toHexString(getHandle()) + ", owner " + isHandleOwner() + ", " + this.toolkitLock + "]";
/*     */   }
/*     */   
/*     */   public static interface EGLDisplayLifecycleCallback {
/*     */     long eglGetAndInitDisplay(long[] param1ArrayOflong, int[] param1ArrayOfint1, int[] param1ArrayOfint2);
/*     */     
/*     */     void eglTerminate(long param1Long);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/egl/EGLGraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */