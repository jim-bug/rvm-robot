/*     */ package com.jogamp.nativewindow.awt;
/*     */ 
/*     */ import com.jogamp.nativewindow.WindowClosingProtocol;
/*     */ import java.awt.Component;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ import jogamp.nativewindow.awt.AWTMisc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AWTWindowClosingProtocol
/*     */   implements WindowClosingProtocol
/*     */ {
/*     */   private final Component comp;
/*     */   private Window listenTo;
/*     */   private final Runnable closingOperationClose;
/*     */   private final Runnable closingOperationNOP;
/*  47 */   private final Object closingListenerLock = new Object();
/*  48 */   private WindowClosingProtocol.WindowClosingMode defaultCloseOperation = WindowClosingProtocol.WindowClosingMode.DISPOSE_ON_CLOSE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean defaultCloseOperationSetByUser = false;
/*     */ 
/*     */ 
/*     */   
/*     */   WindowListener windowClosingAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class WindowClosingAdapter
/*     */     extends WindowAdapter
/*     */   {
/*     */     public void windowClosing(WindowEvent param1WindowEvent) {
/*  66 */       WindowClosingProtocol.WindowClosingMode windowClosingMode = AWTWindowClosingProtocol.this.getDefaultCloseOperation();
/*     */       
/*  68 */       if (WindowClosingProtocol.WindowClosingMode.DISPOSE_ON_CLOSE == windowClosingMode) {
/*     */ 
/*     */         
/*  71 */         AWTWindowClosingProtocol.this.closingOperationClose.run();
/*  72 */       } else if (null != AWTWindowClosingProtocol.this.closingOperationNOP) {
/*  73 */         AWTWindowClosingProtocol.this.closingOperationNOP.run();
/*     */       } 
/*     */     } }
/*     */   public AWTWindowClosingProtocol(Component paramComponent, Runnable paramRunnable1, Runnable paramRunnable2) {
/*  77 */     this.windowClosingAdapter = new WindowClosingAdapter();
/*     */     this.comp = paramComponent;
/*     */     this.listenTo = null;
/*     */     this.closingOperationClose = paramRunnable1;
/*     */     this.closingOperationNOP = paramRunnable2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean addClosingListener() throws IllegalStateException {
/*  89 */     synchronized (this.closingListenerLock) {
/*  90 */       if (null != this.listenTo) {
/*  91 */         throw new IllegalStateException("WindowClosingListener already set");
/*     */       }
/*  93 */       this.listenTo = AWTMisc.getWindow(this.comp);
/*  94 */       if (null != this.listenTo) {
/*  95 */         this.listenTo.addWindowListener(this.windowClosingAdapter);
/*  96 */         return true;
/*     */       } 
/*     */     } 
/*  99 */     return false;
/*     */   }
/*     */   
/*     */   public final boolean removeClosingListener() {
/* 103 */     synchronized (this.closingListenerLock) {
/* 104 */       if (null != this.listenTo) {
/* 105 */         this.listenTo.removeWindowListener(this.windowClosingAdapter);
/* 106 */         this.listenTo = null;
/* 107 */         return true;
/*     */       } 
/*     */     } 
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WindowClosingProtocol.WindowClosingMode getDefaultCloseOperation() {
/* 121 */     synchronized (this.closingListenerLock) {
/* 122 */       if (this.defaultCloseOperationSetByUser) {
/* 123 */         return this.defaultCloseOperation;
/*     */       }
/*     */     } 
/*     */     
/* 127 */     return AWTMisc.getNWClosingOperation(this.comp);
/*     */   }
/*     */ 
/*     */   
/*     */   public final WindowClosingProtocol.WindowClosingMode setDefaultCloseOperation(WindowClosingProtocol.WindowClosingMode paramWindowClosingMode) {
/* 132 */     synchronized (this.closingListenerLock) {
/* 133 */       WindowClosingProtocol.WindowClosingMode windowClosingMode = this.defaultCloseOperation;
/* 134 */       this.defaultCloseOperation = paramWindowClosingMode;
/* 135 */       this.defaultCloseOperationSetByUser = true;
/* 136 */       return windowClosingMode;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/awt/AWTWindowClosingProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */