/*     */ package com.jogamp.nativewindow.awt;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import jogamp.nativewindow.awt.AWTMisc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AWTPrintLifecycle
/*     */ {
/*     */   public static final int DEFAULT_PRINT_TILE_SIZE = 1024;
/*     */   
/*     */   void setupPrint(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   void releasePrint();
/*     */   
/*     */   public static class Context
/*     */   {
/*     */     private final Container cont;
/*     */     private final double scaleMatX;
/*     */     private final double scaleMatY;
/*     */     private final int numSamples;
/*     */     private final int tileWidth;
/*     */     private final int tileHeight;
/*     */     private int count;
/*     */     
/*     */     public static Context setupPrint(Container param1Container, double param1Double1, double param1Double2, int param1Int1, int param1Int2, int param1Int3) {
/* 125 */       Context context = new Context(param1Container, param1Double1, param1Double2, param1Int1, param1Int2, param1Int3);
/* 126 */       context.setupPrint(param1Container);
/* 127 */       return context;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void releasePrint() {
/* 136 */       this.count = AWTMisc.performAction(this.cont, AWTPrintLifecycle.class, this.releaseAction);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getCount() {
/* 142 */       return this.count;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     private final AWTMisc.ComponentAction setupAction = new AWTMisc.ComponentAction()
/*     */       {
/*     */         public void run(Component param2Component) {
/* 155 */           ((AWTPrintLifecycle)param2Component).setupPrint(AWTPrintLifecycle.Context.this.scaleMatX, AWTPrintLifecycle.Context.this.scaleMatY, AWTPrintLifecycle.Context.this.numSamples, AWTPrintLifecycle.Context.this.tileWidth, AWTPrintLifecycle.Context.this.tileHeight);
/*     */         }
/* 157 */       }; private final AWTMisc.ComponentAction releaseAction = new AWTMisc.ComponentAction()
/*     */       {
/*     */         public void run(Component param2Component) {
/* 160 */           ((AWTPrintLifecycle)param2Component).releasePrint();
/*     */         }
/*     */       };
/*     */     private Context(Container param1Container, double param1Double1, double param1Double2, int param1Int1, int param1Int2, int param1Int3) {
/* 164 */       this.cont = param1Container;
/* 165 */       this.scaleMatX = param1Double1;
/* 166 */       this.scaleMatY = param1Double2;
/* 167 */       this.numSamples = param1Int1;
/* 168 */       this.tileWidth = param1Int2;
/* 169 */       this.tileHeight = param1Int3;
/* 170 */       this.count = 0;
/*     */     }
/*     */     private void setupPrint(Container param1Container) {
/* 173 */       this.count = AWTMisc.performAction(param1Container, AWTPrintLifecycle.class, this.setupAction);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/awt/AWTPrintLifecycle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */