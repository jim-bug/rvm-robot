/*    */ package com.jogamp.nativewindow.awt;
/*    */ 
/*    */ import com.jogamp.nativewindow.AbstractGraphicsDevice;
/*    */ import com.jogamp.nativewindow.AbstractGraphicsScreen;
/*    */ import com.jogamp.nativewindow.DefaultGraphicsScreen;
/*    */ import java.awt.GraphicsDevice;
/*    */ import java.awt.GraphicsEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AWTGraphicsScreen
/*    */   extends DefaultGraphicsScreen
/*    */   implements Cloneable
/*    */ {
/*    */   public AWTGraphicsScreen(AWTGraphicsDevice paramAWTGraphicsDevice) {
/* 55 */     super((AbstractGraphicsDevice)paramAWTGraphicsDevice, findScreenIndex(paramAWTGraphicsDevice.getGraphicsDevice()));
/*    */   }
/*    */   
/*    */   public static GraphicsDevice getScreenDevice(int paramInt) {
/* 59 */     if (paramInt < 0) return null; 
/* 60 */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 61 */     GraphicsDevice[] arrayOfGraphicsDevice = graphicsEnvironment.getScreenDevices();
/* 62 */     if (paramInt < arrayOfGraphicsDevice.length) {
/* 63 */       return arrayOfGraphicsDevice[paramInt];
/*    */     }
/* 65 */     return null;
/*    */   }
/*    */   
/*    */   public static int findScreenIndex(GraphicsDevice paramGraphicsDevice) {
/* 69 */     if (null == paramGraphicsDevice) return -1; 
/* 70 */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 71 */     GraphicsDevice[] arrayOfGraphicsDevice = graphicsEnvironment.getScreenDevices();
/* 72 */     for (byte b = 0; b < arrayOfGraphicsDevice.length; b++) {
/* 73 */       if (arrayOfGraphicsDevice[b] == paramGraphicsDevice) return b; 
/*    */     } 
/* 75 */     return -1;
/*    */   }
/*    */   
/*    */   public static AbstractGraphicsScreen createScreenDevice(GraphicsDevice paramGraphicsDevice, int paramInt) {
/* 79 */     return (AbstractGraphicsScreen)new AWTGraphicsScreen(new AWTGraphicsDevice(paramGraphicsDevice, paramInt));
/*    */   }
/*    */   
/*    */   public static AbstractGraphicsScreen createScreenDevice(int paramInt1, int paramInt2) {
/* 83 */     return createScreenDevice(getScreenDevice(paramInt1), paramInt2);
/*    */   }
/*    */   
/*    */   public static AbstractGraphicsScreen createDefault() {
/* 87 */     return (AbstractGraphicsScreen)new AWTGraphicsScreen(AWTGraphicsDevice.createDefault());
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 92 */     return super.clone();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/awt/AWTGraphicsScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */