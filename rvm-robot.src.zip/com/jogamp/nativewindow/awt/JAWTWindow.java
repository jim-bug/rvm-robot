/*     */ package com.jogamp.nativewindow.awt;
/*     */ 
/*     */ import com.jogamp.common.ExceptionUtils;
/*     */ import com.jogamp.common.os.Platform;
/*     */ import com.jogamp.common.util.awt.AWTEDTExecutor;
/*     */ import com.jogamp.common.util.locks.LockFactory;
/*     */ import com.jogamp.common.util.locks.RecursiveLock;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsConfiguration;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsDevice;
/*     */ import com.jogamp.nativewindow.CapabilitiesImmutable;
/*     */ import com.jogamp.nativewindow.MutableGraphicsConfiguration;
/*     */ import com.jogamp.nativewindow.NativeSurface;
/*     */ import com.jogamp.nativewindow.NativeWindow;
/*     */ import com.jogamp.nativewindow.NativeWindowException;
/*     */ import com.jogamp.nativewindow.OffscreenLayerOption;
/*     */ import com.jogamp.nativewindow.OffscreenLayerSurface;
/*     */ import com.jogamp.nativewindow.ScalableSurface;
/*     */ import com.jogamp.nativewindow.SurfaceUpdatedListener;
/*     */ import com.jogamp.nativewindow.util.Insets;
/*     */ import com.jogamp.nativewindow.util.InsetsImmutable;
/*     */ import com.jogamp.nativewindow.util.PixelRectangle;
/*     */ import com.jogamp.nativewindow.util.Point;
/*     */ import com.jogamp.nativewindow.util.PointImmutable;
/*     */ import com.jogamp.nativewindow.util.Rectangle;
/*     */ import com.jogamp.nativewindow.util.RectangleImmutable;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.HierarchyEvent;
/*     */ import java.awt.event.HierarchyListener;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ import jogamp.nativewindow.SurfaceScaleUtils;
/*     */ import jogamp.nativewindow.SurfaceUpdatedHelper;
/*     */ import jogamp.nativewindow.awt.AWTMisc;
/*     */ import jogamp.nativewindow.jawt.JAWT;
/*     */ import jogamp.nativewindow.jawt.JAWTUtil;
/*     */ import jogamp.nativewindow.jawt.JAWT_Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JAWTWindow
/*     */   implements NativeWindow, OffscreenLayerSurface, OffscreenLayerOption, ScalableSurface
/*     */ {
/*  84 */   protected static final boolean DEBUG = JAWTUtil.DEBUG;
/*     */   
/*     */   protected boolean shallUseOffscreenLayer = false;
/*     */   
/*     */   protected final Component component;
/*     */   
/*     */   private final AppContextInfo appContextInfo;
/*     */   
/*  92 */   private final SurfaceUpdatedHelper surfaceUpdatedHelper = new SurfaceUpdatedHelper();
/*  93 */   private final RecursiveLock surfaceLock = LockFactory.createRecursiveLock();
/*     */   
/*     */   private final JAWTComponentListener jawtComponentListener;
/*     */   
/*     */   private volatile AWTGraphicsConfiguration awtConfig;
/*     */   
/*     */   private JAWT jawt;
/*     */   private boolean isOffscreenLayerSurface;
/*     */   protected long drawable;
/*     */   protected Rectangle jawt_surface_bounds;
/*     */   protected Insets insets;
/*     */   private volatile long offscreenSurfaceLayer;
/* 105 */   private final float[] hasPixelScale = new float[] { 1.0F, 1.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean hasPixelScaleChanged = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long drawable_old;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Runnable repaintTask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String id(Object paramObject) {
/* 137 */     return (null != paramObject) ? toHexString(paramObject.hashCode()) : "nil";
/* 138 */   } private String jawtStr1() { return "JAWTWindow[" + id(this) + "]"; } private String jawtStr2(String paramString) {
/* 139 */     return jawtStr1() + "." + paramString + " @ Thread " + getThreadName();
/*     */   }
/*     */   
/*     */   private class JAWTComponentListener implements ComponentListener, HierarchyListener { private volatile boolean isShowing;
/*     */     
/*     */     private String str(Object param1Object) {
/* 145 */       if (null == param1Object)
/* 146 */         return "0xnil: null"; 
/* 147 */       if (param1Object instanceof Component) {
/* 148 */         Component component = (Component)param1Object;
/* 149 */         return JAWTWindow.id(param1Object) + ": " + component.getClass().getSimpleName() + "[visible " + component.isVisible() + ", showing " + component.isShowing() + ", valid " + component.isValid() + ", displayable " + component
/* 150 */           .isDisplayable() + ", " + component.getX() + "/" + component.getY() + " " + component.getWidth() + "x" + component.getHeight() + "]";
/*     */       } 
/* 152 */       return JAWTWindow.id(param1Object) + ": " + param1Object.getClass().getSimpleName() + "[..]";
/*     */     }
/*     */     
/*     */     private String s(ComponentEvent param1ComponentEvent) {
/* 156 */       return "visible[isShowing " + this.isShowing + "]," + Platform.getNewline() + "    ** COMP " + 
/* 157 */         str(param1ComponentEvent.getComponent()) + Platform.getNewline() + "    ** SOURCE " + 
/* 158 */         str(param1ComponentEvent.getSource()) + Platform.getNewline() + "    ** THIS " + 
/* 159 */         str(JAWTWindow.this.component) + Platform.getNewline() + "    ** THREAD " + JAWTWindow
/* 160 */         .getThreadName();
/*     */     }
/*     */     private String s(HierarchyEvent param1HierarchyEvent) {
/* 163 */       return "visible[isShowing " + this.isShowing + "], changeBits 0x" + Long.toHexString(param1HierarchyEvent.getChangeFlags()) + Platform.getNewline() + "    ** COMP " + 
/* 164 */         str(param1HierarchyEvent.getComponent()) + Platform.getNewline() + "    ** SOURCE " + 
/* 165 */         str(param1HierarchyEvent.getSource()) + Platform.getNewline() + "    ** CHANGED " + 
/* 166 */         str(param1HierarchyEvent.getChanged()) + Platform.getNewline() + "    ** CHANGEDPARENT " + 
/* 167 */         str(param1HierarchyEvent.getChangedParent()) + Platform.getNewline() + "    ** THIS " + 
/* 168 */         str(JAWTWindow.this.component) + Platform.getNewline() + "    ** THREAD " + JAWTWindow
/* 169 */         .getThreadName();
/*     */     }
/*     */     
/*     */     public final String toString() {
/* 173 */       return "visible[isShowing " + this.isShowing + "]," + Platform.getNewline() + "    ** THIS " + 
/* 174 */         str(JAWTWindow.this.component) + Platform.getNewline() + "    ** THREAD " + JAWTWindow
/* 175 */         .getThreadName();
/*     */     }
/*     */     
/*     */     private JAWTComponentListener() {
/* 179 */       this.isShowing = JAWTWindow.this.component.isShowing();
/* 180 */       AWTEDTExecutor.singleton.invoke(false, new Runnable()
/*     */           {
/*     */             public void run() {
/* 183 */               JAWTWindow.JAWTComponentListener.this.isShowing = JAWTWindow.this.component.isShowing();
/* 184 */               if (JAWTWindow.DEBUG) {
/* 185 */                 System.err.println(JAWTWindow.this.jawtStr2("attach") + ": " + JAWTWindow.JAWTComponentListener.this.toString());
/*     */               }
/* 187 */               JAWTWindow.this.component.addComponentListener(JAWTWindow.JAWTComponentListener.this);
/* 188 */               JAWTWindow.this.component.addHierarchyListener(JAWTWindow.JAWTComponentListener.this);
/*     */             }
/*     */           });
/*     */     }
/*     */     private final void detach() {
/* 193 */       AWTEDTExecutor.singleton.invoke(false, new Runnable()
/*     */           {
/*     */             public void run() {
/* 196 */               if (JAWTWindow.DEBUG) {
/* 197 */                 System.err.println(JAWTWindow.this.jawtStr2("detach") + ": " + JAWTWindow.JAWTComponentListener.this.toString());
/*     */               }
/* 199 */               JAWTWindow.this.component.removeComponentListener(JAWTWindow.JAWTComponentListener.this);
/* 200 */               JAWTWindow.this.component.removeHierarchyListener(JAWTWindow.JAWTComponentListener.this);
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*     */     public final void componentResized(ComponentEvent param1ComponentEvent) {
/* 206 */       if (JAWTWindow.DEBUG) {
/* 207 */         System.err.println(JAWTWindow.this.jawtStr2("componentResized") + ": " + s(param1ComponentEvent));
/*     */       }
/* 209 */       JAWTWindow.this.layoutSurfaceLayerIfEnabled(this.isShowing);
/*     */     }
/*     */ 
/*     */     
/*     */     public final void componentMoved(ComponentEvent param1ComponentEvent) {
/* 214 */       if (JAWTWindow.DEBUG) {
/* 215 */         System.err.println(JAWTWindow.this.jawtStr2("componentMoved") + ": " + s(param1ComponentEvent));
/*     */       }
/* 217 */       JAWTWindow.this.layoutSurfaceLayerIfEnabled(this.isShowing);
/*     */     }
/*     */ 
/*     */     
/*     */     public final void componentShown(ComponentEvent param1ComponentEvent) {
/* 222 */       if (JAWTWindow.DEBUG) {
/* 223 */         System.err.println(JAWTWindow.this.jawtStr2("componentShown") + ": " + s(param1ComponentEvent));
/*     */       }
/* 225 */       JAWTWindow.this.layoutSurfaceLayerIfEnabled(this.isShowing);
/*     */     }
/*     */ 
/*     */     
/*     */     public final void componentHidden(ComponentEvent param1ComponentEvent) {
/* 230 */       if (JAWTWindow.DEBUG) {
/* 231 */         System.err.println(JAWTWindow.this.jawtStr2("componentHidden") + ": " + s(param1ComponentEvent));
/*     */       }
/* 233 */       JAWTWindow.this.layoutSurfaceLayerIfEnabled(this.isShowing);
/*     */     }
/*     */ 
/*     */     
/*     */     public final void hierarchyChanged(HierarchyEvent param1HierarchyEvent) {
/* 238 */       boolean bool = this.isShowing;
/* 239 */       this.isShowing = JAWTWindow.this.component.isShowing();
/* 240 */       boolean bool1 = false;
/* 241 */       if (0L != (0x4L & param1HierarchyEvent.getChangeFlags()) && 
/* 242 */         param1HierarchyEvent.getChanged() != JAWTWindow.this.component && bool != this.isShowing) {
/*     */ 
/*     */         
/* 245 */         JAWTWindow.this.layoutSurfaceLayerIfEnabled(this.isShowing);
/* 246 */         bool1 = true;
/*     */       } 
/*     */       
/* 249 */       if (JAWTWindow.DEBUG) {
/* 250 */         Component component = param1HierarchyEvent.getChanged();
/* 251 */         boolean bool2 = component.isDisplayable();
/* 252 */         boolean bool3 = component.isShowing();
/* 253 */         System.err.println(JAWTWindow.this.jawtStr2("hierarchyChanged") + ": action " + bool1 + ", displayable " + bool2 + ", showing [changed " + bool3 + ", comp " + bool + " -> " + this.isShowing + "], " + s(param1HierarchyEvent));
/*     */       } 
/*     */     } }
/*     */   
/*     */   private static String getThreadName() {
/* 258 */     return Thread.currentThread().getName();
/*     */   }
/*     */   protected synchronized void invalidate() {
/* 261 */     if (DEBUG) {
/* 262 */       System.err.println(jawtStr2("invalidate") + " - " + this.jawtComponentListener.toString());
/* 263 */       if (isSurfaceLayerAttached()) {
/* 264 */         System.err.println("OffscreenSurfaceLayer still attached: 0x" + Long.toHexString(this.offscreenSurfaceLayer));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 269 */     long l = this.offscreenSurfaceLayer;
/* 270 */     this.offscreenSurfaceLayer = 0L;
/* 271 */     invalidateNative(l);
/*     */     
/* 273 */     this.jawt = null;
/* 274 */     this.awtConfig = null;
/* 275 */     this.offscreenSurfaceLayer = 0L;
/* 276 */     this.isOffscreenLayerSurface = false;
/* 277 */     this.drawable = 0L;
/* 278 */     this.drawable_old = 0L;
/* 279 */     this.jawt_surface_bounds = new Rectangle();
/* 280 */     this.insets = new Insets();
/* 281 */     this.hasPixelScale[0] = 1.0F;
/* 282 */     this.hasPixelScale[1] = 1.0F;
/* 283 */     this.hasPixelScaleChanged = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setAWTGraphicsConfiguration(AWTGraphicsConfiguration paramAWTGraphicsConfiguration) {
/* 300 */     if (DEBUG) {
/* 301 */       System.err.println(jawtStr2("setAWTGraphicsConfiguration") + ": " + this.awtConfig + " -> " + paramAWTGraphicsConfiguration);
/*     */     }
/*     */     
/* 304 */     if (null == this.awtConfig) {
/* 305 */       throw new IllegalArgumentException(jawtStr2("") + ": null config");
/*     */     }
/* 307 */     this.awtConfig = paramAWTGraphicsConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AWTGraphicsConfiguration getAWTGraphicsConfiguration() {
/* 315 */     return this.awtConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean canSetSurfaceScale() {
/* 325 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setSurfaceScale(float[] paramArrayOffloat) {
/* 335 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float[] getRequestedSurfaceScale(float[] paramArrayOffloat) {
/* 346 */     paramArrayOffloat[0] = 0.0F;
/* 347 */     paramArrayOffloat[1] = 0.0F;
/* 348 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */   
/*     */   public final float[] getCurrentSurfaceScale(float[] paramArrayOffloat) {
/* 353 */     System.arraycopy(this.hasPixelScale, 0, paramArrayOffloat, 0, 2);
/* 354 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getMinimumSurfaceScale(float[] paramArrayOffloat) {
/* 365 */     paramArrayOffloat[0] = 1.0F;
/* 366 */     paramArrayOffloat[1] = 1.0F;
/* 367 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float[] getMaximumSurfaceScale(float[] paramArrayOffloat) {
/* 378 */     System.arraycopy(this.hasPixelScale, 0, paramArrayOffloat, 0, 2);
/* 379 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean updateLockedData(JAWT_Rectangle paramJAWT_Rectangle, GraphicsConfiguration paramGraphicsConfiguration) {
/* 388 */     Rectangle rectangle = new Rectangle(paramJAWT_Rectangle.getX(), paramJAWT_Rectangle.getY(), paramJAWT_Rectangle.getWidth(), paramJAWT_Rectangle.getHeight());
/* 389 */     boolean bool = !this.jawt_surface_bounds.equals(rectangle) ? true : false;
/*     */     
/* 391 */     if (bool) {
/* 392 */       if (DEBUG) {
/* 393 */         System.err.println("JAWTWindow.updateBounds: " + this.jawt_surface_bounds + " -> " + rectangle);
/*     */       }
/* 395 */       this.jawt_surface_bounds.set(paramJAWT_Rectangle.getX(), paramJAWT_Rectangle.getY(), paramJAWT_Rectangle.getWidth(), paramJAWT_Rectangle.getHeight());
/*     */       
/* 397 */       if (this.component instanceof Container) {
/* 398 */         Insets insets = ((Container)this.component).getInsets();
/* 399 */         this.insets.set(insets.left, insets.right, insets.top, insets.bottom);
/*     */       } 
/*     */     } 
/*     */     
/* 403 */     updatePixelScale(paramGraphicsConfiguration, false);
/* 404 */     return (this.hasPixelScaleChanged || bool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean updatePixelScale(GraphicsConfiguration paramGraphicsConfiguration, boolean paramBoolean) {
/* 420 */     float[] arrayOfFloat1 = { 1.0F, 1.0F };
/* 421 */     float[] arrayOfFloat2 = { this.hasPixelScale[0], this.hasPixelScale[1] };
/* 422 */     if (JAWTUtil.getPixelScale(paramGraphicsConfiguration, arrayOfFloat1, arrayOfFloat2)) {
/*     */       
/* 424 */       if (DEBUG) {
/* 425 */         System.err.println("JAWTWindow.updatePixelScale: [" + this.hasPixelScale[0] + ", " + this.hasPixelScale[1] + "] -> [" + arrayOfFloat2[0] + ", " + arrayOfFloat2[1] + "]");
/*     */       }
/* 427 */       this.hasPixelScaleChanged = true;
/* 428 */       System.arraycopy(arrayOfFloat2, 0, this.hasPixelScale, 0, 2);
/*     */     } 
/* 430 */     if (paramBoolean) {
/* 431 */       boolean bool = this.hasPixelScaleChanged;
/* 432 */       this.hasPixelScaleChanged = false;
/* 433 */       return bool;
/*     */     } 
/* 435 */     return this.hasPixelScaleChanged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasPixelScaleChanged() {
/* 451 */     boolean bool = this.hasPixelScaleChanged;
/* 452 */     this.hasPixelScaleChanged = false;
/* 453 */     return bool;
/*     */   }
/*     */   
/*     */   public final RectangleImmutable getJAWTSurfaceBounds() {
/* 457 */     return (RectangleImmutable)this.jawt_surface_bounds;
/*     */   }
/*     */   protected final float getPixelScaleX() {
/* 460 */     return this.hasPixelScale[0];
/*     */   }
/*     */   protected final float getPixelScaleY() {
/* 463 */     return this.hasPixelScale[1];
/*     */   }
/*     */   public final InsetsImmutable getInsets() {
/* 466 */     return (InsetsImmutable)this.insets;
/*     */   }
/*     */   public final Component getAWTComponent() {
/* 469 */     return this.component;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isApplet() {
/* 480 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final JAWT getJAWT() {
/* 485 */     return this.jawt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShallUseOffscreenLayer(boolean paramBoolean) {
/* 494 */     this.shallUseOffscreenLayer = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean getShallUseOffscreenLayer() {
/* 499 */     return this.shallUseOffscreenLayer;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isOffscreenLayerSurfaceEnabled() {
/* 504 */     return this.isOffscreenLayerSurface;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void attachSurfaceLayer(long paramLong) throws NativeWindowException {
/* 513 */     if (null == this.appContextInfo) {
/* 514 */       throw new NativeWindowException("Offscreen layer not supported");
/*     */     }
/* 516 */     if (!isOffscreenLayerSurfaceEnabled()) {
/* 517 */       throw new NativeWindowException("Not an offscreen layer surface");
/*     */     }
/* 519 */     attachSurfaceLayerImpl(paramLong);
/* 520 */     this.offscreenSurfaceLayer = paramLong;
/* 521 */     this.appContextInfo.invokeOnAppContextThread(false, this.repaintTask, "Repaint");
/*     */   }
/* 523 */   protected JAWTWindow(Object paramObject, AbstractGraphicsConfiguration paramAbstractGraphicsConfiguration) { this.repaintTask = new Runnable()
/*     */       {
/*     */         public void run() {
/* 526 */           Component component = JAWTWindow.this.component;
/* 527 */           if (JAWTWindow.DEBUG) {
/* 528 */             System.err.println("Bug 1004: RepaintTask on " + Thread.currentThread() + ": Has Comp " + ((null != component) ? 1 : 0));
/*     */           }
/* 530 */           if (null != component)
/* 531 */             component.repaint();  } }; if (paramAbstractGraphicsConfiguration == null)
/*     */       throw new IllegalArgumentException("Error: AbstractGraphicsConfiguration is null");  if (!(paramAbstractGraphicsConfiguration instanceof AWTGraphicsConfiguration))
/*     */       throw new NativeWindowException("Error: AbstractGraphicsConfiguration is not an AWTGraphicsConfiguration: " + paramAbstractGraphicsConfiguration);  if (JAWTUtil.isOffscreenLayerSupported()) { this.appContextInfo = new AppContextInfo("<init>"); }
/*     */     else { this.appContextInfo = null; }
/*     */      this.component = (Component)paramObject; this.jawtComponentListener = new JAWTComponentListener(); this.offscreenSurfaceLayer = 0L; invalidate(); this.awtConfig = (AWTGraphicsConfiguration)paramAbstractGraphicsConfiguration; if (DEBUG)
/* 536 */       System.err.println(jawtStr2("ctor"));  } protected void attachSurfaceLayerImpl(long paramLong) { throw new UnsupportedOperationException("offscreen layer not supported"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutSurfaceLayerImpl(boolean paramBoolean) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void layoutSurfaceLayerIfEnabled(boolean paramBoolean) throws NativeWindowException {
/* 555 */     if (isOffscreenLayerSurfaceEnabled() && 0L != this.offscreenSurfaceLayer) {
/* 556 */       layoutSurfaceLayerImpl(paramBoolean);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void detachSurfaceLayer() throws NativeWindowException {
/* 563 */     if (0L == this.offscreenSurfaceLayer) {
/* 564 */       throw new NativeWindowException("No offscreen layer attached: " + this);
/*     */     }
/* 566 */     if (DEBUG) {
/* 567 */       System.err.println("JAWTWindow.detachSurfaceHandle(): osh " + toHexString(this.offscreenSurfaceLayer) + " - " + Thread.currentThread().getName());
/*     */     }
/*     */     
/* 570 */     long l = this.offscreenSurfaceLayer;
/* 571 */     this.offscreenSurfaceLayer = 0L;
/* 572 */     detachSurfaceLayerImpl(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void detachSurfaceLayerImpl(long paramLong) {
/* 580 */     throw new UnsupportedOperationException("offscreen layer not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getAttachedSurfaceLayer() {
/* 586 */     return this.offscreenSurfaceLayer;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isSurfaceLayerAttached() {
/* 591 */     return (0L != this.offscreenSurfaceLayer);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setChosenCapabilities(CapabilitiesImmutable paramCapabilitiesImmutable) {
/* 596 */     ((MutableGraphicsConfiguration)getGraphicsConfiguration()).setChosenCapabilities(paramCapabilitiesImmutable);
/* 597 */     this.awtConfig.setChosenCapabilities(paramCapabilitiesImmutable);
/*     */   }
/*     */ 
/*     */   
/*     */   public final RecursiveLock getLock() {
/* 602 */     return this.surfaceLock;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean setCursor(final PixelRectangle pixelrect, final PointImmutable hotSpot) {
/* 607 */     AWTEDTExecutor.singleton.invoke(false, new Runnable()
/*     */         {
/*     */           public void run() {
/* 610 */             Cursor cursor = null;
/* 611 */             if (null == pixelrect || null == hotSpot) {
/* 612 */               cursor = Cursor.getDefaultCursor();
/*     */             } else {
/* 614 */               Point point = new Point(hotSpot.getX(), hotSpot.getY());
/*     */               try {
/* 616 */                 cursor = AWTMisc.getCursor(pixelrect, point);
/* 617 */               } catch (Exception exception) {
/* 618 */                 exception.printStackTrace();
/*     */               } 
/*     */             } 
/* 621 */             if (null != cursor)
/* 622 */               JAWTWindow.this.component.setCursor(cursor); 
/*     */           }
/*     */         });
/* 625 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hideCursor() {
/* 630 */     AWTEDTExecutor.singleton.invoke(false, new Runnable()
/*     */         {
/*     */           public void run() {
/* 633 */             Cursor cursor = AWTMisc.getNullCursor();
/* 634 */             if (null != cursor)
/* 635 */               JAWTWindow.this.component.setCursor(cursor); 
/*     */           }
/*     */         });
/* 638 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dumpJAWTInfo() {
/* 668 */     System.err.println(jawt2String(null).toString());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int lockSurface() throws NativeWindowException, RuntimeException {
/* 674 */     this.surfaceLock.lock();
/* 675 */     int i = (this.surfaceLock.getHoldCount() == 1) ? 1 : 3;
/*     */     
/* 677 */     if (1 == i) {
/* 678 */       if (!this.component.isDisplayable()) {
/*     */         
/* 680 */         this.surfaceLock.unlock();
/* 681 */         if (DEBUG) {
/* 682 */           System.err.println("JAWTWindow: Can't lock surface, component peer n/a. Component displayable " + this.component.isDisplayable() + ", " + this.component);
/* 683 */           ExceptionUtils.dumpStack(System.err);
/*     */         } 
/*     */       } else {
/*     */         GraphicsConfiguration graphicsConfiguration;
/* 687 */         if (EventQueue.isDispatchThread() || Thread.holdsLock(this.component.getTreeLock())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 693 */           graphicsConfiguration = this.component.getGraphicsConfiguration();
/*     */         } else {
/*     */           
/* 696 */           graphicsConfiguration = this.awtConfig.getAWTGraphicsConfiguration();
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 701 */           AbstractGraphicsDevice abstractGraphicsDevice = getGraphicsConfiguration().getScreen().getDevice();
/* 702 */           abstractGraphicsDevice.lock();
/*     */           try {
/* 704 */             if (null == this.jawt) {
/* 705 */               this.jawt = fetchJAWTImpl();
/* 706 */               this.isOffscreenLayerSurface = JAWTUtil.isJAWTUsingOffscreenLayer(this.jawt);
/*     */             } 
/* 708 */             i = lockSurfaceImpl(graphicsConfiguration);
/* 709 */             if (3 == i && this.drawable_old != this.drawable) {
/* 710 */               i = 2;
/* 711 */               if (DEBUG) {
/* 712 */                 System.err.println("JAWTWindow: surface change " + toHexString(this.drawable_old) + " -> " + toHexString(this.drawable));
/*     */               }
/*     */             } 
/*     */           } finally {
/*     */             
/* 717 */             if (1 >= i) {
/* 718 */               abstractGraphicsDevice.unlock();
/*     */             }
/*     */           } 
/*     */         } finally {
/* 722 */           if (1 >= i) {
/* 723 */             this.surfaceLock.unlock();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/* 728 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void unlockSurface() {
/* 735 */     this.surfaceLock.validateLocked();
/* 736 */     this.drawable_old = this.drawable;
/*     */     
/* 738 */     if (this.surfaceLock.getHoldCount() == 1) {
/* 739 */       AbstractGraphicsDevice abstractGraphicsDevice = getGraphicsConfiguration().getScreen().getDevice();
/*     */       try {
/* 741 */         if (null != this.jawt) {
/* 742 */           unlockSurfaceImpl();
/*     */         }
/*     */       } finally {
/* 745 */         abstractGraphicsDevice.unlock();
/*     */       } 
/*     */     } 
/* 748 */     this.surfaceLock.unlock();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isSurfaceLockedByOtherThread() {
/* 753 */     return this.surfaceLock.isLockedByOtherThread();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Thread getSurfaceLockOwner() {
/* 758 */     return this.surfaceLock.getOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean surfaceSwap() {
/* 763 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSurfaceUpdatedListener(SurfaceUpdatedListener paramSurfaceUpdatedListener) {
/* 768 */     this.surfaceUpdatedHelper.addSurfaceUpdatedListener(paramSurfaceUpdatedListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSurfaceUpdatedListener(int paramInt, SurfaceUpdatedListener paramSurfaceUpdatedListener) throws IndexOutOfBoundsException {
/* 773 */     this.surfaceUpdatedHelper.addSurfaceUpdatedListener(paramInt, paramSurfaceUpdatedListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeSurfaceUpdatedListener(SurfaceUpdatedListener paramSurfaceUpdatedListener) {
/* 778 */     this.surfaceUpdatedHelper.removeSurfaceUpdatedListener(paramSurfaceUpdatedListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void surfaceUpdated(Object paramObject, NativeSurface paramNativeSurface, long paramLong) {
/* 783 */     this.surfaceUpdatedHelper.surfaceUpdated(paramObject, paramNativeSurface, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getSurfaceHandle() {
/* 788 */     return this.drawable;
/*     */   }
/*     */ 
/*     */   
/*     */   public final AbstractGraphicsConfiguration getGraphicsConfiguration() {
/* 793 */     if (null == this.awtConfig) {
/* 794 */       throw new NativeWindowException(jawtStr2("") + ": null awtConfig, invalidated");
/*     */     }
/* 796 */     return this.awtConfig.getNativeGraphicsConfiguration();
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getDisplayHandle() {
/* 801 */     return getGraphicsConfiguration().getScreen().getDevice().getHandle();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getScreenIndex() {
/* 806 */     return getGraphicsConfiguration().getScreen().getIndex();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getSurfaceWidth() {
/* 811 */     return SurfaceScaleUtils.scale(getWidth(), getPixelScaleX());
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getSurfaceHeight() {
/* 816 */     return SurfaceScaleUtils.scale(getHeight(), getPixelScaleY());
/*     */   }
/*     */ 
/*     */   
/*     */   public final int[] convertToWindowUnits(int[] paramArrayOfint) {
/* 821 */     return SurfaceScaleUtils.scaleInv(paramArrayOfint, paramArrayOfint, this.hasPixelScale);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int[] convertToPixelUnits(int[] paramArrayOfint) {
/* 826 */     return SurfaceScaleUtils.scale(paramArrayOfint, paramArrayOfint, this.hasPixelScale);
/*     */   }
/*     */   
/*     */   public final NativeSurface getNativeSurface() {
/* 830 */     return (NativeSurface)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getX() {
/* 838 */     return this.component.getX();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getY() {
/* 843 */     return this.component.getY();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getWidth() {
/* 848 */     return this.component.getWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getHeight() {
/* 853 */     return this.component.getHeight();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Rectangle getBounds() {
/* 858 */     return new Rectangle(getX(), getY(), getWidth(), getHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public final Rectangle getSurfaceBounds() {
/* 863 */     return new Rectangle(SurfaceScaleUtils.scale(getX(), getPixelScaleX()), 
/* 864 */         SurfaceScaleUtils.scale(getY(), getPixelScaleY()), 
/* 865 */         getSurfaceWidth(), getSurfaceHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 870 */     this.surfaceLock.lock();
/*     */     try {
/* 872 */       if (DEBUG) {
/* 873 */         System.err.println(jawtStr2("destroy"));
/*     */       }
/* 875 */       this.jawtComponentListener.detach();
/* 876 */       invalidate();
/*     */     } finally {
/* 878 */       this.surfaceLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final NativeWindow getParent() {
/* 884 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getWindowHandle() {
/* 889 */     return this.drawable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getLocationOnScreen(Point paramPoint) {
/* 908 */     Point point = getLocationOnScreenNative(paramPoint);
/* 909 */     if (null == point) {
/* 910 */       point = AWTMisc.getLocationOnScreenSafe(paramPoint, this.component, DEBUG);
/*     */     }
/* 912 */     return point;
/*     */   }
/*     */   
/*     */   protected Point getLocationOnScreenNative(Point paramPoint) {
/* 916 */     int i = lockSurface();
/* 917 */     if (1 == i) {
/* 918 */       if (DEBUG) {
/* 919 */         System.err.println("Warning: JAWT Lock couldn't be acquired: " + this);
/* 920 */         ExceptionUtils.dumpStack(System.err);
/*     */       } 
/* 922 */       return null;
/*     */     } 
/*     */     try {
/* 925 */       Point point = getLocationOnScreenNativeImpl(0, 0);
/* 926 */       if (null != point && 
/* 927 */         null != paramPoint) {
/* 928 */         paramPoint.translate(point.getX(), point.getY());
/* 929 */         return paramPoint;
/*     */       } 
/*     */       
/* 932 */       return point;
/*     */     } finally {
/* 934 */       unlockSurface();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 941 */     return this.component.hasFocus();
/*     */   }
/*     */   
/*     */   protected StringBuilder jawt2String(StringBuilder paramStringBuilder) {
/* 945 */     if (null == paramStringBuilder) {
/* 946 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 948 */     paramStringBuilder.append("JVM version: ").append(PlatformPropsImpl.JAVA_VERSION).append(" (")
/* 949 */       .append(PlatformPropsImpl.JAVA_VERSION_NUMBER)
/* 950 */       .append(" update ").append(PlatformPropsImpl.JAVA_VERSION_UPDATE).append(")").append(Platform.getNewline());
/* 951 */     if (null != this.jawt) {
/* 952 */       paramStringBuilder.append("JAWT version: ").append(toHexString(this.jawt.getCachedVersion()))
/* 953 */         .append(", CA_LAYER: ").append(JAWTUtil.isJAWTUsingOffscreenLayer(this.jawt))
/* 954 */         .append(", isLayeredSurface ").append(isOffscreenLayerSurfaceEnabled())
/* 955 */         .append(", bounds ").append(this.jawt_surface_bounds).append(", insets ").append(this.insets)
/* 956 */         .append(", pixelScale ").append(getPixelScaleX()).append("x").append(getPixelScaleY());
/*     */     } else {
/* 958 */       paramStringBuilder.append("JAWT n/a, bounds ").append(this.jawt_surface_bounds).append(", insets ").append(this.insets);
/*     */     } 
/* 960 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 965 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 967 */     stringBuilder.append(jawtStr1() + "[");
/* 968 */     jawt2String(stringBuilder);
/* 969 */     stringBuilder.append(", shallUseOffscreenLayer " + this.shallUseOffscreenLayer + ", isOffscreenLayerSurface " + this.isOffscreenLayerSurface + ", attachedSurfaceLayer " + 
/* 970 */         toHexString(getAttachedSurfaceLayer()) + ", windowHandle " + 
/* 971 */         toHexString(getWindowHandle()) + ", surfaceHandle " + 
/* 972 */         toHexString(getSurfaceHandle()) + ", bounds " + this.jawt_surface_bounds + ", insets " + this.insets);
/*     */ 
/*     */     
/* 975 */     stringBuilder.append(", window [" + getX() + "/" + getY() + " " + getWidth() + "x" + getHeight() + "], pixels[scale " + 
/* 976 */         getPixelScaleX() + ", " + getPixelScaleY() + " -> " + getSurfaceWidth() + "x" + getSurfaceHeight() + "], visible " + this.component
/* 977 */         .isVisible());
/* 978 */     stringBuilder.append(", lockedExt " + isSurfaceLockedByOtherThread() + ",\n\tconfig " + this.awtConfig + ",\n\tawtComponent " + 
/*     */         
/* 980 */         getAWTComponent() + ",\n\tsurfaceLock " + this.surfaceLock + "]");
/*     */ 
/*     */     
/* 983 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   protected static final String toHexString(long paramLong) {
/* 987 */     return "0x" + Long.toHexString(paramLong);
/*     */   }
/*     */   protected static final String toHexString(int paramInt) {
/* 990 */     return "0x" + Integer.toHexString(paramInt);
/*     */   }
/*     */   
/*     */   protected abstract void invalidateNative(long paramLong);
/*     */   
/*     */   protected abstract JAWT fetchJAWTImpl() throws NativeWindowException;
/*     */   
/*     */   protected abstract int lockSurfaceImpl(GraphicsConfiguration paramGraphicsConfiguration) throws NativeWindowException;
/*     */   
/*     */   protected abstract void unlockSurfaceImpl() throws NativeWindowException;
/*     */   
/*     */   protected abstract Point getLocationOnScreenNativeImpl(int paramInt1, int paramInt2);
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/awt/JAWTWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */