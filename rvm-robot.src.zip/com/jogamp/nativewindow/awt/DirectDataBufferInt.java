/*     */ package com.jogamp.nativewindow.awt;
/*     */ 
/*     */ import com.jogamp.common.nio.Buffers;
/*     */ import java.awt.Point;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.DataBuffer;
/*     */ import java.awt.image.DirectColorModel;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.SinglePixelPackedSampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DirectDataBufferInt
/*     */   extends DataBuffer
/*     */ {
/*     */   private final ByteBuffer dataBytes;
/*     */   private final IntBuffer dataInts;
/*     */   private final ByteBuffer[] bankdataBytes;
/*     */   private final IntBuffer[] bankdataInts;
/*     */   
/*     */   public static class DirectWritableRaster
/*     */     extends WritableRaster
/*     */   {
/*     */     protected DirectWritableRaster(SampleModel param1SampleModel, DirectDataBufferInt param1DirectDataBufferInt, Point param1Point) {
/*  52 */       super(param1SampleModel, param1DirectDataBufferInt, param1Point);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BufferedImageInt extends BufferedImage {
/*     */     final int customImageType;
/*     */     final DirectDataBufferInt dataBuffer;
/*     */     
/*     */     public BufferedImageInt(int param1Int, ColorModel param1ColorModel, DirectDataBufferInt param1DirectDataBufferInt, WritableRaster param1WritableRaster, Hashtable<?, ?> param1Hashtable) {
/*  61 */       super(param1ColorModel, param1WritableRaster, false, param1Hashtable);
/*  62 */       this.customImageType = param1Int;
/*  63 */       this.dataBuffer = param1DirectDataBufferInt;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getCustomType() {
/*  72 */       return this.customImageType;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public DirectDataBufferInt getDataBuffer() {
/*  78 */       return this.dataBuffer;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  82 */       return "BufferedImageInt@" + Integer.toHexString(hashCode()) + ": custom/internal type = " + this.customImageType + "/" + 
/*  83 */         getType() + " " + 
/*  84 */         getColorModel() + " " + getRaster();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImageInt createBufferedImage(int paramInt1, int paramInt2, int paramInt3, Point paramPoint, Hashtable<?, ?> paramHashtable) {
/*     */     byte b;
/*     */     int i;
/*     */     char c;
/*     */     int j, k;
/*     */     boolean bool;
/*     */     int[] arrayOfInt;
/* 110 */     ColorSpace colorSpace = ColorSpace.getInstance(1000);
/*     */ 
/*     */ 
/*     */     
/* 114 */     switch (paramInt3) {
/*     */       case 2:
/* 116 */         b = 32;
/* 117 */         i = 16711680;
/* 118 */         c = '＀';
/* 119 */         j = 255;
/* 120 */         k = -16777216;
/* 121 */         bool = false;
/*     */         break;
/*     */       case 3:
/* 124 */         b = 32;
/* 125 */         i = 16711680;
/* 126 */         c = '＀';
/* 127 */         j = 255;
/* 128 */         k = -16777216;
/* 129 */         bool = true;
/*     */         break;
/*     */       case 1:
/* 132 */         b = 24;
/* 133 */         i = 16711680;
/* 134 */         c = '＀';
/* 135 */         j = 255;
/* 136 */         k = 0;
/* 137 */         bool = false;
/*     */         break;
/*     */       case 4:
/* 140 */         b = 24;
/* 141 */         i = 255;
/* 142 */         c = '＀';
/* 143 */         j = 16711680;
/* 144 */         k = 0;
/* 145 */         bool = false;
/*     */         break;
/*     */       default:
/* 148 */         throw new IllegalArgumentException("Unsupported imageType, must be [INT_ARGB, INT_ARGB_PRE, INT_RGB, INT_BGR], has " + paramInt3);
/*     */     } 
/* 150 */     DirectColorModel directColorModel = new DirectColorModel(colorSpace, b, i, c, j, k, bool, 3);
/*     */     
/* 152 */     if (0 != k) {
/* 153 */       arrayOfInt = new int[4];
/* 154 */       arrayOfInt[3] = k;
/*     */     } else {
/*     */       
/* 157 */       arrayOfInt = new int[3];
/*     */     } 
/* 159 */     arrayOfInt[0] = i;
/* 160 */     arrayOfInt[1] = c;
/* 161 */     arrayOfInt[2] = j;
/*     */     
/* 163 */     DirectDataBufferInt directDataBufferInt = new DirectDataBufferInt(paramInt1 * paramInt2);
/* 164 */     if (null == paramPoint) {
/* 165 */       paramPoint = new Point(0, 0);
/*     */     }
/* 167 */     SinglePixelPackedSampleModel singlePixelPackedSampleModel = new SinglePixelPackedSampleModel(directDataBufferInt.getDataType(), paramInt1, paramInt2, paramInt1, arrayOfInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     DirectWritableRaster directWritableRaster = new DirectWritableRaster(singlePixelPackedSampleModel, directDataBufferInt, paramPoint);
/*     */     
/* 175 */     return new BufferedImageInt(paramInt3, directColorModel, directDataBufferInt, directWritableRaster, paramHashtable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectDataBufferInt(int paramInt) {
/* 195 */     super(3, paramInt);
/* 196 */     this.dataBytes = Buffers.newDirectByteBuffer(paramInt * 4);
/* 197 */     this.dataInts = this.dataBytes.asIntBuffer();
/* 198 */     this.bankdataBytes = new ByteBuffer[1];
/* 199 */     this.bankdataInts = new IntBuffer[1];
/* 200 */     this.bankdataBytes[0] = this.dataBytes;
/* 201 */     this.bankdataInts[0] = this.dataInts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectDataBufferInt(int paramInt1, int paramInt2) {
/* 212 */     super(3, paramInt1, paramInt2);
/* 213 */     this.bankdataBytes = new ByteBuffer[paramInt2];
/* 214 */     this.bankdataInts = new IntBuffer[paramInt2];
/* 215 */     for (byte b = 0; b < paramInt2; b++) {
/* 216 */       this.bankdataBytes[b] = Buffers.newDirectByteBuffer(paramInt1 * 4);
/* 217 */       this.bankdataInts[b] = this.bankdataBytes[b].asIntBuffer();
/*     */     } 
/* 219 */     this.dataBytes = this.bankdataBytes[0];
/* 220 */     this.dataInts = this.bankdataInts[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectDataBufferInt(ByteBuffer paramByteBuffer, int paramInt) {
/* 236 */     super(3, paramInt);
/* 237 */     this.dataBytes = Buffers.nativeOrder(paramByteBuffer);
/* 238 */     this.dataInts = this.dataBytes.asIntBuffer();
/* 239 */     this.bankdataBytes = new ByteBuffer[1];
/* 240 */     this.bankdataInts = new IntBuffer[1];
/* 241 */     this.bankdataBytes[0] = this.dataBytes;
/* 242 */     this.bankdataInts[0] = this.dataInts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntBuffer getData() {
/* 252 */     return this.dataInts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getDataBytes() {
/* 261 */     return this.dataBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntBuffer getData(int paramInt) {
/* 272 */     return this.bankdataInts[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getDataBytes(int paramInt) {
/* 282 */     return this.bankdataBytes[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getElem(int paramInt) {
/* 295 */     return this.dataInts.get(paramInt + this.offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getElem(int paramInt1, int paramInt2) {
/* 309 */     return this.bankdataInts[paramInt1].get(paramInt2 + this.offsets[paramInt1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElem(int paramInt1, int paramInt2) {
/* 323 */     this.dataInts.put(paramInt1 + this.offset, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElem(int paramInt1, int paramInt2, int paramInt3) {
/* 337 */     this.bankdataInts[paramInt1].put(paramInt2 + this.offsets[paramInt1], paramInt3);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/awt/DirectDataBufferInt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */