/*    */ package com.jogamp.nativewindow.awt;
/*    */ 
/*    */ import com.jogamp.nativewindow.DefaultGraphicsDevice;
/*    */ import java.awt.GraphicsDevice;
/*    */ import java.awt.GraphicsEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AWTGraphicsDevice
/*    */   extends DefaultGraphicsDevice
/*    */   implements Cloneable
/*    */ {
/*    */   private final GraphicsDevice device;
/*    */   
/*    */   public AWTGraphicsDevice(GraphicsDevice paramGraphicsDevice, int paramInt) {
/* 54 */     super(".awt", paramGraphicsDevice.getIDstring(), paramInt);
/* 55 */     this.device = paramGraphicsDevice;
/*    */   }
/*    */   
/*    */   public static AWTGraphicsDevice createDefault() {
/* 59 */     GraphicsDevice graphicsDevice = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
/* 60 */     return new AWTGraphicsDevice(graphicsDevice, 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 65 */     return super.clone();
/*    */   }
/*    */   
/*    */   public GraphicsDevice getGraphicsDevice() {
/* 69 */     return this.device;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return getClass().getSimpleName() + "[type " + getType() + ", connection " + getConnection() + ", unitID " + getUnitID() + ", awtDevice " + this.device + ", handle 0x" + Long.toHexString(getHandle()) + "]";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/awt/AWTGraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */