/*     */ package com.jogamp.nativewindow.awt;
/*     */ 
/*     */ import com.jogamp.nativewindow.AbstractGraphicsConfiguration;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsDevice;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsScreen;
/*     */ import com.jogamp.nativewindow.Capabilities;
/*     */ import com.jogamp.nativewindow.CapabilitiesImmutable;
/*     */ import com.jogamp.nativewindow.DefaultGraphicsConfiguration;
/*     */ import com.jogamp.nativewindow.GraphicsConfigurationFactory;
/*     */ import com.jogamp.nativewindow.NativeWindowException;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.image.ColorModel;
/*     */ import jogamp.nativewindow.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AWTGraphicsConfiguration
/*     */   extends DefaultGraphicsConfiguration
/*     */   implements Cloneable
/*     */ {
/*     */   private final GraphicsConfiguration config;
/*     */   AbstractGraphicsConfiguration encapsulated;
/*     */   
/*     */   public AWTGraphicsConfiguration(AWTGraphicsScreen paramAWTGraphicsScreen, CapabilitiesImmutable paramCapabilitiesImmutable1, CapabilitiesImmutable paramCapabilitiesImmutable2, GraphicsConfiguration paramGraphicsConfiguration, AbstractGraphicsConfiguration paramAbstractGraphicsConfiguration) {
/*  63 */     super((AbstractGraphicsScreen)paramAWTGraphicsScreen, paramCapabilitiesImmutable1, paramCapabilitiesImmutable2);
/*  64 */     this.config = paramGraphicsConfiguration;
/*  65 */     this.encapsulated = paramAbstractGraphicsConfiguration;
/*     */   }
/*     */ 
/*     */   
/*     */   private AWTGraphicsConfiguration(AWTGraphicsScreen paramAWTGraphicsScreen, CapabilitiesImmutable paramCapabilitiesImmutable1, CapabilitiesImmutable paramCapabilitiesImmutable2, GraphicsConfiguration paramGraphicsConfiguration) {
/*  70 */     super((AbstractGraphicsScreen)paramAWTGraphicsScreen, paramCapabilitiesImmutable1, paramCapabilitiesImmutable2);
/*  71 */     this.config = paramGraphicsConfiguration;
/*  72 */     this.encapsulated = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AWTGraphicsConfiguration create(GraphicsConfiguration paramGraphicsConfiguration, CapabilitiesImmutable paramCapabilitiesImmutable1, CapabilitiesImmutable paramCapabilitiesImmutable2) {
/*     */     Capabilities capabilities;
/*  85 */     if (null == paramGraphicsConfiguration) {
/*  86 */       throw new IllegalArgumentException("Null AWT GraphicsConfiguration");
/*     */     }
/*  88 */     GraphicsDevice graphicsDevice = paramGraphicsConfiguration.getDevice();
/*  89 */     if (null == graphicsDevice) {
/*  90 */       throw new NativeWindowException("Null AWT GraphicsDevice @ " + paramGraphicsConfiguration);
/*     */     }
/*     */ 
/*     */     
/*  94 */     AWTGraphicsDevice aWTGraphicsDevice = new AWTGraphicsDevice(graphicsDevice, 0);
/*  95 */     AWTGraphicsScreen aWTGraphicsScreen = new AWTGraphicsScreen(aWTGraphicsDevice);
/*     */     
/*  97 */     if (null == paramCapabilitiesImmutable2) {
/*  98 */       capabilities = new Capabilities();
/*     */     }
/* 100 */     if (null == paramCapabilitiesImmutable1) {
/* 101 */       paramCapabilitiesImmutable1 = setupCapabilitiesRGBABits((CapabilitiesImmutable)capabilities, paramGraphicsConfiguration);
/*     */     }
/* 103 */     GraphicsConfigurationFactory graphicsConfigurationFactory = GraphicsConfigurationFactory.getFactory((AbstractGraphicsDevice)aWTGraphicsDevice, paramCapabilitiesImmutable1);
/* 104 */     AbstractGraphicsConfiguration abstractGraphicsConfiguration = graphicsConfigurationFactory.chooseGraphicsConfiguration(paramCapabilitiesImmutable1, (CapabilitiesImmutable)capabilities, null, (AbstractGraphicsScreen)aWTGraphicsScreen, 0);
/* 105 */     if (abstractGraphicsConfiguration instanceof AWTGraphicsConfiguration) {
/* 106 */       return (AWTGraphicsConfiguration)abstractGraphicsConfiguration;
/*     */     }
/*     */     
/* 109 */     return new AWTGraphicsConfiguration(aWTGraphicsScreen, paramCapabilitiesImmutable1, (CapabilitiesImmutable)capabilities, paramGraphicsConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChosenCapabilities(CapabilitiesImmutable paramCapabilitiesImmutable) {
/* 115 */     super.setChosenCapabilities(paramCapabilitiesImmutable);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 120 */     return super.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public GraphicsConfiguration getAWTGraphicsConfiguration() {
/* 125 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractGraphicsConfiguration getNativeGraphicsConfiguration() {
/* 130 */     return (null != this.encapsulated) ? this.encapsulated : (AbstractGraphicsConfiguration)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CapabilitiesImmutable setupCapabilitiesRGBABits(CapabilitiesImmutable paramCapabilitiesImmutable, GraphicsConfiguration paramGraphicsConfiguration) {
/* 141 */     Capabilities capabilities = (Capabilities)paramCapabilitiesImmutable.cloneMutable();
/*     */     
/* 143 */     ColorModel colorModel = paramGraphicsConfiguration.getColorModel();
/* 144 */     if (null == colorModel) {
/* 145 */       throw new NativeWindowException("Could not determine AWT ColorModel");
/*     */     }
/* 147 */     int i = colorModel.getPixelSize();
/* 148 */     int j = 0;
/* 149 */     int[] arrayOfInt = colorModel.getComponentSize();
/* 150 */     if (arrayOfInt.length >= 3) {
/* 151 */       capabilities.setRedBits(arrayOfInt[0]);
/* 152 */       j += arrayOfInt[0];
/* 153 */       capabilities.setGreenBits(arrayOfInt[1]);
/* 154 */       j += arrayOfInt[1];
/* 155 */       capabilities.setBlueBits(arrayOfInt[2]);
/* 156 */       j += arrayOfInt[2];
/*     */     } 
/* 158 */     if (arrayOfInt.length >= 4) {
/* 159 */       capabilities.setAlphaBits(arrayOfInt[3]);
/* 160 */       j += arrayOfInt[3];
/*     */     } else {
/* 162 */       capabilities.setAlphaBits(0);
/*     */     } 
/* 164 */     if (Debug.debugAll() && 
/* 165 */       i != j) {
/* 166 */       System.err.println("AWT Colormodel bits per components/pixel mismatch: " + j + " != " + i);
/*     */     }
/*     */     
/* 169 */     return (CapabilitiesImmutable)capabilities;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 174 */     return getClass().getSimpleName() + "[" + getScreen() + ",\n\tchosen    " + this.capabilitiesChosen + ",\n\trequested " + this.capabilitiesRequested + ",\n\t" + this.config + ",\n\tencapsulated " + this.encapsulated + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/awt/AWTGraphicsConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */