/*     */ package com.jogamp.nativewindow.awt;
/*     */ 
/*     */ import com.jogamp.common.ExceptionUtils;
/*     */ import com.jogamp.common.util.RunnableTask;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import com.jogamp.common.util.UnsafeUtil;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.PrivilegedAction;
/*     */ import jogamp.nativewindow.jawt.JAWTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AppContextInfo
/*     */ {
/*     */   private static final boolean DEBUG;
/*     */   private static final Method getAppContextMethod;
/*  24 */   private static final Object mainThreadAppContextLock = new Object();
/*  25 */   private volatile WeakReference<Object> mainThreadAppContextWR = null;
/*  26 */   private volatile WeakReference<ThreadGroup> mainThreadGroupWR = null;
/*     */   
/*     */   static {
/*  29 */     DEBUG = JAWTUtil.DEBUG;
/*  30 */     final Method[] _getAppContextMethod = { null };
/*  31 */     SecurityUtil.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/*  34 */             return UnsafeUtil.doWithoutIllegalAccessLogger(new PrivilegedAction()
/*     */                 {
/*     */                   public Object run() {
/*     */                     try {
/*  38 */                       Class<?> clazz = Class.forName("sun.awt.AppContext");
/*  39 */                       _getAppContextMethod[0] = clazz.getMethod("getAppContext", new Class[0]);
/*  40 */                       _getAppContextMethod[0].setAccessible(true);
/*  41 */                     } catch (Throwable throwable) {
/*  42 */                       ExceptionUtils.dumpThrowable("AppContextInfo(Bug 1004)", throwable);
/*     */                     } 
/*  44 */                     return null; } }); }
/*     */         });
/*  46 */     getAppContextMethod = arrayOfMethod[0];
/*     */   }
/*     */   
/*     */   public AppContextInfo(String paramString) {
/*  50 */     update(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isValid() {
/*  58 */     return (null != getCachedThreadGroup());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ThreadGroup getCachedThreadGroup() {
/*  80 */     WeakReference<ThreadGroup> weakReference = this.mainThreadGroupWR;
/*  81 */     return (null != weakReference) ? weakReference.get() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RunnableTask invokeOnAppContextThread(boolean paramBoolean, Runnable paramRunnable, String paramString) {
/*     */     RunnableTask runnableTask;
/* 107 */     if (update("invoke")) {
/* 108 */       runnableTask = RunnableTask.invokeOnCurrentThread(paramRunnable);
/* 109 */       if (DEBUG) {
/* 110 */         System.err.println("Bug 1004: Invoke.0 on current AppContext: " + runnableTask);
/*     */       }
/*     */     } else {
/* 113 */       ThreadGroup threadGroup = getCachedThreadGroup();
/* 114 */       String str = paramString + ((null != threadGroup) ? "-OnAppContextTG" : "-OnSystemTG");
/* 115 */       runnableTask = RunnableTask.invokeOnNewThread(threadGroup, str, paramBoolean, paramRunnable);
/* 116 */       if (DEBUG) {
/* 117 */         boolean bool = (null != threadGroup) ? threadGroup.hashCode() : false;
/* 118 */         System.err.println("Bug 1004: Invoke.1 on new AppContext: " + runnableTask + ", tg " + threadGroup + " " + toHexString(bool));
/*     */       } 
/*     */     } 
/* 121 */     return runnableTask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean update(String paramString) {
/* 133 */     if (null != getAppContextMethod) {
/*     */       
/* 135 */       Object object = fetchAppContext();
/* 136 */       boolean bool = (null != object) ? true : false;
/*     */       
/* 138 */       Thread thread = Thread.currentThread();
/* 139 */       ThreadGroup threadGroup = thread.getThreadGroup();
/*     */ 
/*     */       
/* 142 */       WeakReference<Object> weakReference = this.mainThreadAppContextWR;
/* 143 */       T t = (null != weakReference) ? (T)weakReference.get() : null;
/*     */ 
/*     */       
/* 146 */       if (bool) {
/*     */         
/* 148 */         if (null == t || t != object) {
/*     */           int i;
/*     */           
/* 151 */           boolean bool1 = (null != t) ? t.hashCode() : false;
/*     */           
/* 153 */           synchronized (mainThreadAppContextLock) {
/* 154 */             this.mainThreadGroupWR = new WeakReference<>(threadGroup);
/* 155 */             this.mainThreadAppContextWR = new WeakReference(object);
/* 156 */             i = object.hashCode();
/*     */           } 
/* 158 */           if (DEBUG) {
/* 159 */             System.err.println("Bug 1004[TGMapped " + bool + "]: Init AppContext @ " + paramString + " on thread " + thread.getName() + " " + toHexString(thread.hashCode()) + ": tg " + threadGroup
/* 160 */                 .getName() + " " + toHexString(threadGroup.hashCode()) + " -> appCtx [ main " + t + " " + 
/* 161 */                 toHexString(bool1) + " -> this " + object + " " + 
/* 162 */                 toHexString(i) + " ] ");
/*     */           
/*     */           }
/*     */         }
/* 166 */         else if (DEBUG) {
/* 167 */           int i = t.hashCode();
/* 168 */           int j = object.hashCode();
/* 169 */           System.err.println("Bug 1004[TGMapped " + bool + "]: OK AppContext @ " + paramString + " on thread " + thread.getName() + " " + toHexString(thread.hashCode()) + ": tg " + threadGroup
/* 170 */               .getName() + " " + toHexString(threadGroup.hashCode()) + "  : appCtx [ this " + object + " " + 
/* 171 */               toHexString(j) + "  , main " + t + " " + 
/* 172 */               toHexString(i) + " ] ");
/*     */         } 
/*     */         
/* 175 */         return true;
/*     */       } 
/* 177 */       if (DEBUG) {
/* 178 */         boolean bool1 = (null != t) ? t.hashCode() : false;
/* 179 */         boolean bool2 = (null != object) ? object.hashCode() : false;
/* 180 */         System.err.println("Bug 1004[TGMapped " + bool + "]: No AppContext @ " + paramString + " on thread " + thread.getName() + " " + toHexString(thread.hashCode()) + ": tg " + threadGroup
/* 181 */             .getName() + " " + toHexString(threadGroup.hashCode()) + " -> appCtx [ this " + object + " " + 
/* 182 */             toHexString(bool2) + " -> main " + t + " " + 
/* 183 */             toHexString(bool1) + " ] ");
/*     */       } 
/*     */     } 
/*     */     
/* 187 */     return false;
/*     */   }
/*     */   private static Object fetchAppContext() {
/*     */     try {
/* 191 */       return getAppContextMethod.invoke(null, new Object[0]);
/* 192 */     } catch (Exception exception) {
/* 193 */       ExceptionUtils.dumpThrowable("AppContextInfo(Bug 1004)", exception);
/* 194 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String toHexString(int paramInt) {
/* 199 */     return "0x" + Integer.toHexString(paramInt);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/awt/AppContextInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */