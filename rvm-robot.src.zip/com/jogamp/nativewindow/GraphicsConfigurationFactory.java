/*     */ package com.jogamp.nativewindow;
/*     */ 
/*     */ import com.jogamp.common.ExceptionUtils;
/*     */ import com.jogamp.common.util.ReflectionUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import jogamp.nativewindow.Debug;
/*     */ import jogamp.nativewindow.DefaultGraphicsConfigurationFactoryImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GraphicsConfigurationFactory
/*     */ {
/*     */   protected static final boolean DEBUG;
/*     */   private static final Map<DeviceCapsType, GraphicsConfigurationFactory> registeredFactories;
/*     */   private static final DeviceCapsType defaultDeviceCapsType;
/*     */   
/*     */   private static class DeviceCapsType
/*     */   {
/*     */     public final Class<?> deviceType;
/*     */     public final Class<?> capsType;
/*     */     private final int hash32;
/*     */     
/*     */     public DeviceCapsType(Class<?> param1Class1, Class<?> param1Class2) {
/*  76 */       this.deviceType = param1Class1;
/*  77 */       this.capsType = param1Class2;
/*     */ 
/*     */       
/*  80 */       int i = 31 + param1Class1.hashCode();
/*  81 */       i = (i << 5) - i + param1Class2.hashCode();
/*  82 */       this.hash32 = i;
/*     */     }
/*     */ 
/*     */     
/*     */     public final int hashCode() {
/*  87 */       return this.hash32;
/*     */     }
/*     */ 
/*     */     
/*     */     public final boolean equals(Object param1Object) {
/*  92 */       if (this == param1Object) return true; 
/*  93 */       if (param1Object instanceof DeviceCapsType) {
/*  94 */         DeviceCapsType deviceCapsType = (DeviceCapsType)param1Object;
/*  95 */         return (this.deviceType == deviceCapsType.deviceType && this.capsType == deviceCapsType.capsType);
/*     */       } 
/*  97 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public final String toString() {
/* 102 */       return "DeviceCapsType[" + this.deviceType.getName() + ", " + this.capsType.getName() + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean initialized = false;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 112 */     DEBUG = Debug.debug("GraphicsConfiguration");
/* 113 */     if (DEBUG) {
/* 114 */       System.err.println(Thread.currentThread().getName() + " - Info: GraphicsConfigurationFactory.<init>");
/*     */     }
/*     */     
/* 117 */     registeredFactories = Collections.synchronizedMap(new HashMap<>());
/* 118 */     defaultDeviceCapsType = new DeviceCapsType(AbstractGraphicsDevice.class, CapabilitiesImmutable.class);
/*     */   }
/*     */   
/*     */   public static synchronized void initSingleton() {
/* 122 */     if (!initialized) {
/* 123 */       initialized = true;
/*     */       
/* 125 */       if (DEBUG) {
/* 126 */         System.err.println(Thread.currentThread().getName() + " - GraphicsConfigurationFactory.initSingleton()");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       registerFactory(defaultDeviceCapsType.deviceType, defaultDeviceCapsType.capsType, (GraphicsConfigurationFactory)new DefaultGraphicsConfigurationFactoryImpl());
/*     */       
/* 136 */       if (".x11" == NativeWindowFactory.getNativeWindowType(true)) {
/*     */         try {
/* 138 */           ReflectionUtil.callStaticMethod("jogamp.nativewindow.x11.X11GraphicsConfigurationFactory", "registerFactory", null, null, GraphicsConfigurationFactory.class
/* 139 */               .getClassLoader());
/* 140 */         } catch (Exception exception) {
/* 141 */           throw new RuntimeException(exception);
/*     */         } 
/* 143 */         if (NativeWindowFactory.isAWTAvailable()) {
/*     */           try {
/* 145 */             ReflectionUtil.callStaticMethod("jogamp.nativewindow.x11.awt.X11AWTGraphicsConfigurationFactory", "registerFactory", null, null, GraphicsConfigurationFactory.class
/* 146 */                 .getClassLoader());
/* 147 */           } catch (Exception exception) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static synchronized void shutdown() {
/* 154 */     if (initialized) {
/* 155 */       initialized = false;
/* 156 */       if (DEBUG) {
/* 157 */         System.err.println(Thread.currentThread().getName() + " - GraphicsConfigurationFactory.shutdown()");
/*     */       }
/* 159 */       registeredFactories.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected static String getThreadName() {
/* 164 */     return Thread.currentThread().getName();
/*     */   }
/*     */   
/*     */   protected static String toHexString(int paramInt) {
/* 168 */     return "0x" + Integer.toHexString(paramInt);
/*     */   }
/*     */   
/*     */   protected static String toHexString(long paramLong) {
/* 172 */     return "0x" + Long.toHexString(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GraphicsConfigurationFactory getFactory(AbstractGraphicsDevice paramAbstractGraphicsDevice, CapabilitiesImmutable paramCapabilitiesImmutable) {
/* 187 */     if (paramAbstractGraphicsDevice == null) {
/* 188 */       throw new IllegalArgumentException("null device");
/*     */     }
/* 190 */     if (paramCapabilitiesImmutable == null) {
/* 191 */       throw new IllegalArgumentException("null caps");
/*     */     }
/* 193 */     return getFactory(paramAbstractGraphicsDevice.getClass(), paramCapabilitiesImmutable.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GraphicsConfigurationFactory getFactory(Class<?> paramClass1, Class<?> paramClass2) throws IllegalArgumentException, NativeWindowException {
/* 224 */     if (!defaultDeviceCapsType.deviceType.isAssignableFrom(paramClass1)) {
/* 225 */       throw new IllegalArgumentException("Given class must implement AbstractGraphicsDevice");
/*     */     }
/* 227 */     if (!defaultDeviceCapsType.capsType.isAssignableFrom(paramClass2)) {
/* 228 */       throw new IllegalArgumentException("Given capabilities class must implement CapabilitiesImmutable");
/*     */     }
/* 230 */     if (DEBUG) {
/* 231 */       ExceptionUtils.dumpStack(System.err);
/* 232 */       System.err.println("GraphicsConfigurationFactory.getFactory: " + paramClass1.getName() + ", " + paramClass2.getName());
/* 233 */       dumpFactories();
/*     */     } 
/*     */     
/* 236 */     ArrayList<Class<?>> arrayList1 = getAllAssignableClassesFrom(defaultDeviceCapsType.deviceType, paramClass1, false);
/* 237 */     if (DEBUG) {
/* 238 */       System.err.println("GraphicsConfigurationFactory.getFactory() deviceTypes: " + arrayList1);
/*     */     }
/* 240 */     ArrayList<Class<?>> arrayList2 = getAllAssignableClassesFrom(defaultDeviceCapsType.capsType, paramClass2, true);
/* 241 */     if (DEBUG) {
/* 242 */       System.err.println("GraphicsConfigurationFactory.getFactory() capabilitiesTypes: " + arrayList2);
/*     */     }
/* 244 */     for (byte b = 0; b < arrayList1.size(); b++) {
/* 245 */       Class<?> clazz = arrayList1.get(b);
/* 246 */       for (byte b1 = 0; b1 < arrayList2.size(); b1++) {
/* 247 */         Class<?> clazz1 = arrayList2.get(b1);
/* 248 */         DeviceCapsType deviceCapsType = new DeviceCapsType(clazz, clazz1);
/* 249 */         GraphicsConfigurationFactory graphicsConfigurationFactory1 = registeredFactories.get(deviceCapsType);
/* 250 */         if (graphicsConfigurationFactory1 != null) {
/* 251 */           if (DEBUG) {
/* 252 */             System.err.println("GraphicsConfigurationFactory.getFactory() found " + deviceCapsType + " -> " + graphicsConfigurationFactory1);
/*     */           }
/* 254 */           return graphicsConfigurationFactory1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 259 */     GraphicsConfigurationFactory graphicsConfigurationFactory = registeredFactories.get(defaultDeviceCapsType);
/* 260 */     if (DEBUG) {
/* 261 */       System.err.println("GraphicsConfigurationFactory.getFactory() DEFAULT " + defaultDeviceCapsType + " -> " + graphicsConfigurationFactory);
/*     */     }
/* 263 */     return graphicsConfigurationFactory;
/*     */   }
/*     */   
/*     */   private static ArrayList<Class<?>> getAllAssignableClassesFrom(Class<?> paramClass1, Class<?> paramClass2, boolean paramBoolean) {
/* 267 */     ArrayList<Class<?>> arrayList1 = new ArrayList();
/* 268 */     ArrayList<Class<?>> arrayList2 = new ArrayList();
/* 269 */     arrayList1.add(paramClass2);
/* 270 */     for (byte b = 0; b < arrayList1.size(); b++) {
/* 271 */       Class<?> clazz = arrayList1.get(b);
/* 272 */       getAllAssignableClassesFrom(paramClass1, clazz, paramBoolean, arrayList2, arrayList1);
/*     */     } 
/* 274 */     return arrayList2;
/*     */   }
/*     */   private static void getAllAssignableClassesFrom(Class<?> paramClass1, Class<?> paramClass2, boolean paramBoolean, List<Class<?>> paramList1, List<Class<?>> paramList2) {
/* 277 */     ArrayList<Class<?>> arrayList = new ArrayList();
/* 278 */     if (paramClass1.isAssignableFrom(paramClass2) && !paramList1.contains(paramClass2) && (
/* 279 */       !paramBoolean || paramClass2.isInterface())) {
/* 280 */       arrayList.add(paramClass2);
/*     */     }
/*     */     
/* 283 */     arrayList.addAll(Arrays.asList(paramClass2.getInterfaces()));
/*     */     
/* 285 */     for (byte b = 0; b < arrayList.size(); b++) {
/* 286 */       Class<?> clazz1 = arrayList.get(b);
/* 287 */       if (paramClass1.isAssignableFrom(clazz1) && !paramList1.contains(clazz1)) {
/* 288 */         paramList1.add(clazz1);
/* 289 */         if (!paramClass1.equals(clazz1) && !paramList2.contains(clazz1)) {
/* 290 */           paramList2.add(clazz1);
/*     */         }
/*     */       } 
/*     */     } 
/* 294 */     Class<?> clazz = paramClass2.getSuperclass();
/* 295 */     if (null != clazz && paramClass1.isAssignableFrom(clazz) && !paramList2.contains(clazz))
/* 296 */       paramList2.add(clazz); 
/*     */   }
/*     */   
/*     */   private static void dumpFactories() {
/* 300 */     Set<DeviceCapsType> set = registeredFactories.keySet();
/* 301 */     byte b = 0;
/* 302 */     for (DeviceCapsType deviceCapsType : set) {
/*     */       
/* 304 */       System.err.println("Factory #" + b + ": " + deviceCapsType + " -> " + registeredFactories.get(deviceCapsType));
/* 305 */       b++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static GraphicsConfigurationFactory registerFactory(Class<?> paramClass1, Class<?> paramClass2, GraphicsConfigurationFactory paramGraphicsConfigurationFactory) throws IllegalArgumentException {
/*     */     GraphicsConfigurationFactory graphicsConfigurationFactory;
/* 331 */     if (!defaultDeviceCapsType.deviceType.isAssignableFrom(paramClass1)) {
/* 332 */       throw new IllegalArgumentException("Given device class must implement AbstractGraphicsDevice");
/*     */     }
/* 334 */     if (!defaultDeviceCapsType.capsType.isAssignableFrom(paramClass2)) {
/* 335 */       throw new IllegalArgumentException("Given capabilities class must implement CapabilitiesImmutable");
/*     */     }
/* 337 */     DeviceCapsType deviceCapsType = new DeviceCapsType(paramClass1, paramClass2);
/*     */     
/* 339 */     if (null == paramGraphicsConfigurationFactory) {
/* 340 */       graphicsConfigurationFactory = registeredFactories.remove(deviceCapsType);
/* 341 */       if (DEBUG) {
/* 342 */         System.err.println("GraphicsConfigurationFactory.registerFactory() remove " + deviceCapsType + ", deleting: " + graphicsConfigurationFactory);
/*     */       }
/*     */     } else {
/*     */       
/* 346 */       graphicsConfigurationFactory = registeredFactories.put(deviceCapsType, paramGraphicsConfigurationFactory);
/* 347 */       if (DEBUG) {
/* 348 */         System.err.println("GraphicsConfigurationFactory.registerFactory() put " + deviceCapsType + " -> " + paramGraphicsConfigurationFactory + ", overridding: " + graphicsConfigurationFactory);
/*     */       }
/*     */     } 
/*     */     
/* 352 */     return graphicsConfigurationFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AbstractGraphicsConfiguration chooseGraphicsConfiguration(CapabilitiesImmutable paramCapabilitiesImmutable1, CapabilitiesImmutable paramCapabilitiesImmutable2, CapabilitiesChooser paramCapabilitiesChooser, AbstractGraphicsScreen paramAbstractGraphicsScreen, int paramInt) throws IllegalArgumentException, NativeWindowException {
/* 409 */     if (null == paramCapabilitiesImmutable1) {
/* 410 */       throw new NativeWindowException("Chosen Capabilities are null");
/*     */     }
/* 412 */     if (null == paramCapabilitiesImmutable2) {
/* 413 */       throw new NativeWindowException("Requested Capabilities are null");
/*     */     }
/* 415 */     if (null == paramAbstractGraphicsScreen) {
/* 416 */       throw new NativeWindowException("Screen is null");
/*     */     }
/* 418 */     AbstractGraphicsDevice abstractGraphicsDevice = paramAbstractGraphicsScreen.getDevice();
/* 419 */     if (null == abstractGraphicsDevice) {
/* 420 */       throw new NativeWindowException("Screen's Device is null");
/*     */     }
/* 422 */     abstractGraphicsDevice.lock();
/*     */     try {
/* 424 */       return chooseGraphicsConfigurationImpl(paramCapabilitiesImmutable1, paramCapabilitiesImmutable2, paramCapabilitiesChooser, paramAbstractGraphicsScreen, paramInt);
/*     */     } finally {
/* 426 */       abstractGraphicsDevice.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract AbstractGraphicsConfiguration chooseGraphicsConfigurationImpl(CapabilitiesImmutable paramCapabilitiesImmutable1, CapabilitiesImmutable paramCapabilitiesImmutable2, CapabilitiesChooser paramCapabilitiesChooser, AbstractGraphicsScreen paramAbstractGraphicsScreen, int paramInt) throws IllegalArgumentException, NativeWindowException;
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/GraphicsConfigurationFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */