/*     */ package com.jogamp.nativewindow.x11;
/*     */ 
/*     */ import com.jogamp.common.util.Bitfield;
/*     */ import com.jogamp.nativewindow.AbstractGraphicsScreen;
/*     */ import com.jogamp.nativewindow.CapabilitiesImmutable;
/*     */ import com.jogamp.nativewindow.MutableGraphicsConfiguration;
/*     */ import jogamp.nativewindow.x11.X11Capabilities;
/*     */ import jogamp.nativewindow.x11.X11Lib;
/*     */ import jogamp.nativewindow.x11.XRenderDirectFormat;
/*     */ import jogamp.nativewindow.x11.XRenderPictFormat;
/*     */ import jogamp.nativewindow.x11.XVisualInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X11GraphicsConfiguration
/*     */   extends MutableGraphicsConfiguration
/*     */   implements Cloneable
/*     */ {
/*     */   private XVisualInfo info;
/*     */   
/*     */   protected static XRenderDirectFormat XVisual2XRenderMask(long paramLong1, long paramLong2) {
/*  59 */     XRenderPictFormat xRenderPictFormat = XRenderPictFormat.create();
/*  60 */     return XVisual2XRenderMask(paramLong1, paramLong2, xRenderPictFormat);
/*     */   }
/*     */   protected static XRenderDirectFormat XVisual2XRenderMask(long paramLong1, long paramLong2, XRenderPictFormat paramXRenderPictFormat) {
/*  63 */     if (!X11Lib.XRenderFindVisualFormat(paramLong1, paramLong2, paramXRenderPictFormat)) {
/*  64 */       return null;
/*     */     }
/*  66 */     return paramXRenderPictFormat.getDirect();
/*     */   }
/*     */ 
/*     */   
/*     */   public static X11Capabilities XVisualInfo2X11Capabilities(X11GraphicsDevice paramX11GraphicsDevice, XVisualInfo paramXVisualInfo) {
/*  71 */     long l = paramX11GraphicsDevice.getHandle();
/*  72 */     X11Capabilities x11Capabilities = new X11Capabilities(paramXVisualInfo);
/*     */     
/*  74 */     XRenderDirectFormat xRenderDirectFormat = (null != paramXVisualInfo) ? XVisual2XRenderMask(l, paramXVisualInfo.getVisual()) : null;
/*  75 */     byte b = (null != xRenderDirectFormat) ? xRenderDirectFormat.getAlphaMask() : 0;
/*  76 */     if (0 < b) {
/*  77 */       x11Capabilities.setBackgroundOpaque(false);
/*  78 */       x11Capabilities.setTransparentRedValue(xRenderDirectFormat.getRedMask());
/*  79 */       x11Capabilities.setTransparentGreenValue(xRenderDirectFormat.getGreenMask());
/*  80 */       x11Capabilities.setTransparentBlueValue(xRenderDirectFormat.getBlueMask());
/*  81 */       x11Capabilities.setTransparentAlphaValue(b);
/*     */     } else {
/*  83 */       x11Capabilities.setBackgroundOpaque(true);
/*     */     } 
/*     */     
/*  86 */     x11Capabilities.setRedBits(Bitfield.Util.bitCount((int)paramXVisualInfo.getRed_mask()));
/*  87 */     x11Capabilities.setGreenBits(Bitfield.Util.bitCount((int)paramXVisualInfo.getGreen_mask()));
/*  88 */     x11Capabilities.setBlueBits(Bitfield.Util.bitCount((int)paramXVisualInfo.getBlue_mask()));
/*  89 */     x11Capabilities.setAlphaBits(Bitfield.Util.bitCount(b));
/*     */     
/*  91 */     return x11Capabilities;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public X11GraphicsConfiguration(X11GraphicsScreen paramX11GraphicsScreen, CapabilitiesImmutable paramCapabilitiesImmutable1, CapabilitiesImmutable paramCapabilitiesImmutable2, XVisualInfo paramXVisualInfo) {
/*  97 */     super((AbstractGraphicsScreen)paramX11GraphicsScreen, paramCapabilitiesImmutable1, paramCapabilitiesImmutable2);
/*  98 */     this.info = paramXVisualInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 103 */     return super.clone();
/*     */   }
/*     */   
/*     */   public final XVisualInfo getXVisualInfo() {
/* 107 */     return this.info;
/*     */   }
/*     */   
/*     */   protected final void setXVisualInfo(XVisualInfo paramXVisualInfo) {
/* 111 */     this.info = paramXVisualInfo;
/*     */   }
/*     */   
/*     */   public final int getXVisualID() {
/* 115 */     return (null != this.info) ? (int)this.info.getVisualid() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     return getClass().getSimpleName() + "[" + getScreen() + ", visualID 0x" + Long.toHexString(getXVisualID()) + ",\n\tchosen    " + this.capabilitiesChosen + ",\n\trequested " + this.capabilitiesRequested + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/x11/X11GraphicsConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */