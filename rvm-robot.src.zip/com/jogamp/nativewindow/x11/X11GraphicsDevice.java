/*     */ package com.jogamp.nativewindow.x11;
/*     */ 
/*     */ import com.jogamp.nativewindow.DefaultGraphicsDevice;
/*     */ import com.jogamp.nativewindow.NativeWindowException;
/*     */ import com.jogamp.nativewindow.NativeWindowFactory;
/*     */ import com.jogamp.nativewindow.ToolkitLock;
/*     */ import jogamp.nativewindow.x11.X11Lib;
/*     */ import jogamp.nativewindow.x11.X11Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X11GraphicsDevice
/*     */   extends DefaultGraphicsDevice
/*     */   implements Cloneable
/*     */ {
/*     */   boolean handleOwner;
/*     */   final boolean isXineramaEnabled;
/*     */   
/*     */   public X11GraphicsDevice(String paramString, int paramInt) {
/*  58 */     super(".x11", paramString, paramInt);
/*  59 */     this.handleOwner = false;
/*  60 */     this.isXineramaEnabled = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X11GraphicsDevice(long paramLong, int paramInt, boolean paramBoolean) {
/*  68 */     this(paramLong, paramInt, NativeWindowFactory.getDefaultToolkitLock(".x11"), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X11GraphicsDevice(long paramLong, int paramInt, ToolkitLock paramToolkitLock, boolean paramBoolean) {
/*  77 */     super(".x11", X11Lib.XDisplayString(paramLong), paramInt, paramLong, paramToolkitLock);
/*  78 */     if (0L == paramLong) {
/*  79 */       throw new NativeWindowException("null display");
/*     */     }
/*  81 */     this.handleOwner = paramBoolean;
/*  82 */     this.isXineramaEnabled = X11Util.XineramaIsEnabled(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X11GraphicsDevice(String paramString, int paramInt, ToolkitLock paramToolkitLock) {
/*  95 */     super(".x11", paramString, paramInt, 0L, paramToolkitLock);
/*  96 */     this.handleOwner = true;
/*  97 */     open();
/*  98 */     this.isXineramaEnabled = X11Util.XineramaIsEnabled(this);
/*     */   }
/*     */   
/*     */   private static int getDefaultScreenImpl(long paramLong) {
/* 102 */     return X11Lib.DefaultScreen(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultScreen() {
/* 112 */     long l = getHandle();
/* 113 */     if (0L == l) {
/* 114 */       throw new NativeWindowException("null display");
/*     */     }
/* 116 */     int i = getDefaultScreenImpl(l);
/* 117 */     if (DEBUG) {
/* 118 */       System.err.println(Thread.currentThread().getName() + " - X11GraphicsDevice.getDefaultDisplay() of " + this + ": " + i + ", count " + X11Lib.ScreenCount(l));
/*     */     }
/* 120 */     return i;
/*     */   }
/*     */   
/*     */   public int getDefaultVisualID() {
/* 124 */     long l = getHandle();
/* 125 */     if (0L == l) {
/* 126 */       throw new NativeWindowException("null display");
/*     */     }
/* 128 */     return X11Lib.DefaultVisualID(l, getDefaultScreenImpl(l));
/*     */   }
/*     */   
/*     */   public final boolean isXineramaEnabled() {
/* 132 */     return this.isXineramaEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 137 */     return super.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean open() {
/* 142 */     if (this.handleOwner && 0L == this.handle) {
/* 143 */       if (DEBUG) {
/* 144 */         System.err.println(Thread.currentThread().getName() + " - X11GraphicsDevice.open(): " + this);
/*     */       }
/* 146 */       this.handle = X11Util.openDisplay(this.connection);
/* 147 */       if (0L == this.handle) {
/* 148 */         throw new NativeWindowException("X11GraphicsDevice.open() failed: " + this);
/*     */       }
/* 150 */       return true;
/*     */     } 
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean close() {
/* 157 */     if (this.handleOwner && 0L != this.handle) {
/* 158 */       if (DEBUG) {
/* 159 */         System.err.println(Thread.currentThread().getName() + " - X11GraphicsDevice.close(): " + this);
/*     */       }
/* 161 */       X11Util.closeDisplay(this.handle);
/*     */     } 
/* 163 */     return super.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHandleOwner() {
/* 168 */     return this.handleOwner;
/*     */   }
/*     */   
/*     */   public void clearHandleOwner() {
/* 172 */     this.handleOwner = false;
/*     */   }
/*     */   
/*     */   protected Object getHandleOwnership() {
/* 176 */     return Boolean.valueOf(this.handleOwner);
/*     */   }
/*     */   
/*     */   protected Object setHandleOwnership(Object paramObject) {
/* 180 */     Boolean bool = Boolean.valueOf(this.handleOwner);
/* 181 */     this.handleOwner = ((Boolean)paramObject).booleanValue();
/* 182 */     return bool;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/x11/X11GraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */