/*    */ package com.jogamp.nativewindow.x11;
/*    */ 
/*    */ import com.jogamp.nativewindow.AbstractGraphicsDevice;
/*    */ import com.jogamp.nativewindow.AbstractGraphicsScreen;
/*    */ import com.jogamp.nativewindow.DefaultGraphicsScreen;
/*    */ import com.jogamp.nativewindow.NativeWindowException;
/*    */ import jogamp.nativewindow.x11.X11Lib;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class X11GraphicsScreen
/*    */   extends DefaultGraphicsScreen
/*    */   implements Cloneable
/*    */ {
/*    */   public X11GraphicsScreen(X11GraphicsDevice paramX11GraphicsDevice, int paramInt) {
/* 53 */     super((AbstractGraphicsDevice)paramX11GraphicsDevice, paramX11GraphicsDevice.isXineramaEnabled() ? 0 : paramInt);
/*    */   }
/*    */   
/*    */   public static AbstractGraphicsScreen createScreenDevice(long paramLong, int paramInt, boolean paramBoolean) {
/* 57 */     if (0L == paramLong) throw new NativeWindowException("display is null"); 
/* 58 */     return (AbstractGraphicsScreen)new X11GraphicsScreen(new X11GraphicsDevice(paramLong, 0, paramBoolean), paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getVisualID() {
/* 63 */     return X11Lib.DefaultVisualID(getDevice().getHandle(), getIndex());
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 68 */     return super.clone();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/x11/X11GraphicsScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */