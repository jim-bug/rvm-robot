package com.jogamp.nativewindow;

import com.jogamp.common.type.WriteCloneable;

public interface CapabilitiesImmutable extends VisualIDHolder, WriteCloneable, Comparable<CapabilitiesImmutable> {
  int getRedBits();
  
  int getGreenBits();
  
  int getBlueBits();
  
  int getAlphaBits();
  
  boolean isBackgroundOpaque();
  
  boolean isOnscreen();
  
  boolean isBitmap();
  
  int getTransparentRedValue();
  
  int getTransparentGreenValue();
  
  int getTransparentBlueValue();
  
  int getTransparentAlphaValue();
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  StringBuilder toString(StringBuilder paramStringBuilder);
  
  String toString();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/nativewindow/CapabilitiesImmutable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */