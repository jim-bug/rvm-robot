/*      */ package com.jogamp.newt.awt;
/*      */ 
/*      */ import com.jogamp.common.ExceptionUtils;
/*      */ import com.jogamp.common.util.awt.AWTEDTExecutor;
/*      */ import com.jogamp.nativewindow.CapabilitiesImmutable;
/*      */ import com.jogamp.nativewindow.NativeSurface;
/*      */ import com.jogamp.nativewindow.NativeWindow;
/*      */ import com.jogamp.nativewindow.NativeWindowHolder;
/*      */ import com.jogamp.nativewindow.OffscreenLayerOption;
/*      */ import com.jogamp.nativewindow.SurfaceUpdatedListener;
/*      */ import com.jogamp.nativewindow.WindowClosingProtocol;
/*      */ import com.jogamp.nativewindow.awt.AWTGraphicsConfiguration;
/*      */ import com.jogamp.nativewindow.awt.AWTPrintLifecycle;
/*      */ import com.jogamp.nativewindow.awt.AWTWindowClosingProtocol;
/*      */ import com.jogamp.nativewindow.awt.JAWTWindow;
/*      */ import com.jogamp.newt.Display;
/*      */ import com.jogamp.newt.Window;
/*      */ import com.jogamp.newt.event.KeyEvent;
/*      */ import com.jogamp.newt.event.KeyListener;
/*      */ import com.jogamp.newt.event.WindowAdapter;
/*      */ import com.jogamp.newt.event.WindowEvent;
/*      */ import com.jogamp.newt.event.WindowListener;
/*      */ import com.jogamp.newt.event.awt.AWTAdapter;
/*      */ import com.jogamp.newt.event.awt.AWTKeyAdapter;
/*      */ import com.jogamp.newt.event.awt.AWTMouseAdapter;
/*      */ import com.jogamp.opengl.GLAnimatorControl;
/*      */ import com.jogamp.opengl.GLAutoDrawable;
/*      */ import com.jogamp.opengl.GLCapabilities;
/*      */ import com.jogamp.opengl.GLCapabilitiesImmutable;
/*      */ import com.jogamp.opengl.GLDrawable;
/*      */ import com.jogamp.opengl.GLDrawableFactory;
/*      */ import com.jogamp.opengl.GLException;
/*      */ import com.jogamp.opengl.GLOffscreenAutoDrawable;
/*      */ import com.jogamp.opengl.util.GLDrawableUtil;
/*      */ import com.jogamp.opengl.util.TileRenderer;
/*      */ import java.awt.AWTKeyStroke;
/*      */ import java.awt.Canvas;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.EventQueue;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.KeyboardFocusManager;
/*      */ import java.awt.geom.NoninvertibleTransformException;
/*      */ import java.beans.Beans;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.util.Set;
/*      */ import javax.swing.MenuSelectionManager;
/*      */ import jogamp.nativewindow.awt.AWTMisc;
/*      */ import jogamp.nativewindow.jawt.JAWTUtil;
/*      */ import jogamp.newt.Debug;
/*      */ import jogamp.newt.WindowImpl;
/*      */ import jogamp.newt.awt.NewtFactoryAWT;
/*      */ import jogamp.newt.awt.event.AWTParentWindowAdapter;
/*      */ import jogamp.newt.driver.DriverClearFocus;
/*      */ import jogamp.opengl.awt.AWTTilePainter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NewtCanvasAWT
/*      */   extends Canvas
/*      */   implements NativeWindowHolder, WindowClosingProtocol, OffscreenLayerOption, AWTPrintLifecycle
/*      */ {
/*  101 */   public static final boolean DEBUG = Debug.debug("Window");
/*      */   
/*  103 */   private final Object sync = new Object();
/*  104 */   private volatile JAWTWindow jawtWindow = null;
/*      */   private boolean isApplet = false;
/*      */   private boolean shallUseOffscreenLayer = false;
/*  107 */   private Window newtChild = null;
/*      */   private boolean newtChildAttached = false;
/*      */   private boolean isOnscreen = true;
/*  110 */   private WindowClosingProtocol.WindowClosingMode newtChildCloseOp = WindowClosingProtocol.WindowClosingMode.DISPOSE_ON_CLOSE;
/*      */   
/*      */   private final AWTParentWindowAdapter awtWinAdapter;
/*      */   
/*      */   private final AWTAdapter awtMouseAdapter;
/*      */   
/*      */   private final AWTAdapter awtKeyAdapter;
/*      */   
/*      */   private volatile AWTGraphicsConfiguration awtConfig;
/*      */   
/*      */   private boolean destroyJAWTPending = false;
/*      */   
/*      */   private boolean skipJAWTDestroy = false;
/*      */   private volatile boolean componentAdded = false;
/*      */   
/*  125 */   private final AWTWindowClosingProtocol awtWindowClosingProtocol = new AWTWindowClosingProtocol(this, new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  129 */           if (NewtCanvasAWT.this.componentAdded) {
/*  130 */             NewtCanvasAWT.this.destroyImpl(false, true);
/*      */           }
/*      */         }
/*      */       }new Runnable()
/*      */       {
/*      */         public void run() {
/*  136 */           if (NewtCanvasAWT.this.componentAdded && NewtCanvasAWT.this.newtChild != null) {
/*  137 */             NewtCanvasAWT.this.newtChild.sendWindowEvent(102);
/*      */           }
/*      */         }
/*      */       });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final FocusAction focusAction;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NewtCanvasAWT(GraphicsConfiguration paramGraphicsConfiguration)
/*      */   {
/*  157 */     super(paramGraphicsConfiguration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  243 */     this.focusAction = new FocusAction();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  254 */     this.awtClearSelectedMenuPath = new Runnable()
/*      */       {
/*      */         public void run() {
/*  257 */           MenuSelectionManager.defaultManager().clearSelectedPath();
/*      */         }
/*      */       };
/*  260 */     this.clearAWTMenusOnNewtFocus = (WindowListener)new WindowAdapter()
/*      */       {
/*      */         public void windowResized(WindowEvent param1WindowEvent) {
/*  263 */           NewtCanvasAWT.this.updateLayoutSize();
/*      */         }
/*      */         
/*      */         public void windowGainedFocus(WindowEvent param1WindowEvent) {
/*  267 */           if (NewtCanvasAWT.this.isParent() && !NewtCanvasAWT.this.isFullscreen()) {
/*  268 */             AWTEDTExecutor.singleton.invoke(false, NewtCanvasAWT.this.awtClearSelectedMenuPath);
/*      */           }
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  322 */     this.newtFocusTraversalKeyListener = new FocusTraversalKeyListener();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  357 */     this.focusPropertyChangeListener = new FocusPropertyChangeListener();
/*  358 */     this.keyboardFocusManager = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  767 */     this.printActive = false;
/*  768 */     this.printAnimator = null;
/*  769 */     this.printGLAD = null;
/*  770 */     this.printAWTTiles = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  787 */     this.setupPrintOnEDT = new Runnable()
/*      */       {
/*      */         public void run() {
/*  790 */           synchronized (NewtCanvasAWT.this.sync) {
/*  791 */             if (!NewtCanvasAWT.this.validateComponent(true)) {
/*  792 */               if (NewtCanvasAWT.DEBUG) {
/*  793 */                 System.err.println(NewtCanvasAWT.currentThreadName() + ": Info: NewtCanvasAWT setupPrint - skipped GL render, drawable not valid yet");
/*      */               }
/*  795 */               NewtCanvasAWT.this.printActive = false;
/*      */               return;
/*      */             } 
/*  798 */             if (!NewtCanvasAWT.this.isVisible()) {
/*  799 */               if (NewtCanvasAWT.DEBUG) {
/*  800 */                 System.err.println(NewtCanvasAWT.currentThreadName() + ": Info: NewtCanvasAWT setupPrint - skipped GL render, canvas not visible");
/*      */               }
/*  802 */               NewtCanvasAWT.this.printActive = false;
/*      */               return;
/*      */             } 
/*  805 */             GLAutoDrawable gLAutoDrawable = NewtCanvasAWT.this.getGLAD();
/*  806 */             if (null == gLAutoDrawable) {
/*  807 */               if (NewtCanvasAWT.DEBUG) {
/*  808 */                 System.err.println("AWT print.setup exit, newtChild not a GLAutoDrawable: " + NewtCanvasAWT.this.newtChild);
/*      */               }
/*  810 */               NewtCanvasAWT.this.printActive = false;
/*      */               return;
/*      */             } 
/*  813 */             NewtCanvasAWT.this.printAnimator = gLAutoDrawable.getAnimator();
/*  814 */             if (null != NewtCanvasAWT.this.printAnimator) {
/*  815 */               NewtCanvasAWT.this.printAnimator.remove(gLAutoDrawable);
/*      */             }
/*  817 */             NewtCanvasAWT.this.printGLAD = gLAutoDrawable;
/*  818 */             GLCapabilitiesImmutable gLCapabilitiesImmutable = gLAutoDrawable.getChosenGLCapabilities();
/*  819 */             int i = NewtCanvasAWT.this.printAWTTiles.getNumSamples(gLCapabilitiesImmutable);
/*  820 */             GLDrawable gLDrawable = NewtCanvasAWT.this.printGLAD.getDelegatedDrawable();
/*  821 */             boolean bool1 = (i != gLCapabilitiesImmutable.getNumSamples()) ? true : false;
/*      */             
/*  823 */             boolean bool2 = ((NewtCanvasAWT.this.printAWTTiles.customTileWidth != -1 && NewtCanvasAWT.this.printAWTTiles.customTileWidth != gLDrawable.getSurfaceWidth()) || (NewtCanvasAWT.this.printAWTTiles.customTileHeight != -1 && NewtCanvasAWT.this.printAWTTiles.customTileHeight != gLDrawable.getSurfaceHeight())) ? true : false;
/*  824 */             boolean bool3 = gLCapabilitiesImmutable.isOnscreen();
/*      */             
/*  826 */             GLCapabilities gLCapabilities = (GLCapabilities)gLCapabilitiesImmutable.cloneMutable();
/*  827 */             gLCapabilities.setDoubleBuffered(false);
/*  828 */             gLCapabilities.setOnscreen(false);
/*  829 */             if (i != gLCapabilities.getNumSamples()) {
/*  830 */               gLCapabilities.setSampleBuffers((0 < i));
/*  831 */               gLCapabilities.setNumSamples(i);
/*      */             } 
/*  833 */             boolean bool4 = GLDrawableUtil.isSwapGLContextSafe(gLAutoDrawable.getRequestedGLCapabilities(), gLCapabilitiesImmutable, (GLCapabilitiesImmutable)gLCapabilities);
/*      */             
/*  835 */             boolean bool5 = ((bool3 || bool1 || bool2) && bool4) ? true : false;
/*      */             
/*  837 */             if (NewtCanvasAWT.DEBUG) {
/*  838 */               System.err.println("AWT print.setup: reqNewGLAD " + bool5 + "[ onscreen " + bool3 + ", samples " + bool1 + ", size " + bool2 + ", safe " + bool4 + "], , drawableSize " + gLDrawable
/*  839 */                   .getSurfaceWidth() + "x" + gLDrawable.getSurfaceHeight() + ", customTileSize " + 
/*  840 */                   NewtCanvasAWT.this.printAWTTiles.customTileWidth + "x" + NewtCanvasAWT.this.printAWTTiles.customTileHeight + ", scaleMat " + 
/*  841 */                   NewtCanvasAWT.this.printAWTTiles.scaleMatX + " x " + NewtCanvasAWT.this.printAWTTiles.scaleMatY + ", numSamples " + 
/*  842 */                   NewtCanvasAWT.this.printAWTTiles.customNumSamples + " -> " + i + ", printAnimator " + NewtCanvasAWT.this.printAnimator);
/*      */             }
/*  844 */             if (bool5) {
/*  845 */               GLDrawableFactory gLDrawableFactory = GLDrawableFactory.getFactory(gLCapabilities.getGLProfile());
/*  846 */               GLOffscreenAutoDrawable gLOffscreenAutoDrawable = null;
/*      */               try {
/*  848 */                 gLOffscreenAutoDrawable = gLDrawableFactory.createOffscreenAutoDrawable(null, (GLCapabilitiesImmutable)gLCapabilities, null, 
/*  849 */                     (NewtCanvasAWT.this.printAWTTiles.customTileWidth != -1) ? NewtCanvasAWT.this.printAWTTiles.customTileWidth : 1024, 
/*  850 */                     (NewtCanvasAWT.this.printAWTTiles.customTileHeight != -1) ? NewtCanvasAWT.this.printAWTTiles.customTileHeight : 1024);
/*  851 */               } catch (GLException gLException) {
/*  852 */                 if (NewtCanvasAWT.DEBUG) {
/*  853 */                   System.err.println("Caught: " + gLException.getMessage());
/*  854 */                   gLException.printStackTrace();
/*      */                 } 
/*      */               } 
/*  857 */               if (null != gLOffscreenAutoDrawable) {
/*  858 */                 NewtCanvasAWT.this.printGLAD = (GLAutoDrawable)gLOffscreenAutoDrawable;
/*  859 */                 GLDrawableUtil.swapGLContextAndAllGLEventListener(gLAutoDrawable, NewtCanvasAWT.this.printGLAD);
/*  860 */                 gLDrawable = NewtCanvasAWT.this.printGLAD.getDelegatedDrawable();
/*      */               } 
/*      */             } 
/*  863 */             NewtCanvasAWT.this.printAWTTiles.setGLOrientation(NewtCanvasAWT.this.printGLAD.isGLOriented(), NewtCanvasAWT.this.printGLAD.isGLOriented());
/*  864 */             NewtCanvasAWT.this.printAWTTiles.renderer.setTileSize(gLDrawable.getSurfaceWidth(), gLDrawable.getSurfaceHeight(), 0);
/*  865 */             NewtCanvasAWT.this.printAWTTiles.renderer.attachAutoDrawable(NewtCanvasAWT.this.printGLAD);
/*  866 */             if (NewtCanvasAWT.DEBUG) {
/*  867 */               System.err.println("AWT print.setup " + NewtCanvasAWT.this.printAWTTiles);
/*  868 */               System.err.println("AWT print.setup AA " + i + ", " + gLCapabilities);
/*  869 */               System.err.println("AWT print.setup printGLAD: " + NewtCanvasAWT.this.printGLAD.getSurfaceWidth() + "x" + NewtCanvasAWT.this.printGLAD.getSurfaceHeight() + ", " + NewtCanvasAWT.this.printGLAD);
/*  870 */               System.err.println("AWT print.setup printDraw: " + gLDrawable.getSurfaceWidth() + "x" + gLDrawable.getSurfaceHeight() + ", " + gLDrawable);
/*      */             } 
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  885 */     this.releasePrintOnEDT = new Runnable()
/*      */       {
/*      */         public void run() {
/*  888 */           synchronized (NewtCanvasAWT.this.sync) {
/*  889 */             if (NewtCanvasAWT.DEBUG) {
/*  890 */               System.err.println("AWT print.release " + NewtCanvasAWT.this.printAWTTiles);
/*      */             }
/*  892 */             GLAutoDrawable gLAutoDrawable = NewtCanvasAWT.this.getGLAD();
/*  893 */             NewtCanvasAWT.this.printAWTTiles.dispose();
/*  894 */             NewtCanvasAWT.this.printAWTTiles = null;
/*  895 */             if (NewtCanvasAWT.this.printGLAD != gLAutoDrawable) {
/*  896 */               GLDrawableUtil.swapGLContextAndAllGLEventListener(NewtCanvasAWT.this.printGLAD, gLAutoDrawable);
/*  897 */               NewtCanvasAWT.this.printGLAD.destroy();
/*      */             } 
/*  899 */             NewtCanvasAWT.this.printGLAD = null;
/*  900 */             if (null != NewtCanvasAWT.this.printAnimator) {
/*  901 */               NewtCanvasAWT.this.printAnimator.add(gLAutoDrawable);
/*  902 */               NewtCanvasAWT.this.printAnimator = null;
/*      */             } 
/*  904 */             NewtCanvasAWT.this.printActive = false;
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1070 */     this.forceRelayout = new Runnable()
/*      */       {
/*      */         public void run() {
/* 1073 */           if (NewtCanvasAWT.DEBUG) {
/* 1074 */             System.err.println("NewtCanvasAWT.forceRelayout.0");
/*      */           }
/*      */           
/* 1077 */           NewtCanvasAWT newtCanvasAWT = NewtCanvasAWT.this;
/* 1078 */           int i = newtCanvasAWT.getWidth();
/* 1079 */           int j = newtCanvasAWT.getHeight();
/* 1080 */           newtCanvasAWT.setSize(i + 1, j + 1);
/* 1081 */           newtCanvasAWT.setSize(i, j);
/* 1082 */           if (NewtCanvasAWT.DEBUG)
/* 1083 */             System.err.println("NewtCanvasAWT.forceRelayout.X");  } }; this.awtMouseAdapter = (new AWTMouseAdapter()).addTo(this); this.awtKeyAdapter = (new AWTKeyAdapter()).addTo(this); this.awtWinAdapter = (AWTParentWindowAdapter)(new AWTParentWindowAdapter()).addTo(this); this.awtWinAdapter.removeWindowClosingFrom(this); } public NewtCanvasAWT(GraphicsConfiguration paramGraphicsConfiguration, Window paramWindow) { super(paramGraphicsConfiguration); this.focusAction = new FocusAction(); this.awtClearSelectedMenuPath = new Runnable() { public void run() { MenuSelectionManager.defaultManager().clearSelectedPath(); } }; this.clearAWTMenusOnNewtFocus = (WindowListener)new WindowAdapter() { public void windowResized(WindowEvent param1WindowEvent) { NewtCanvasAWT.this.updateLayoutSize(); } public void windowGainedFocus(WindowEvent param1WindowEvent) { if (NewtCanvasAWT.this.isParent() && !NewtCanvasAWT.this.isFullscreen()) AWTEDTExecutor.singleton.invoke(false, NewtCanvasAWT.this.awtClearSelectedMenuPath);  } }; this.newtFocusTraversalKeyListener = new FocusTraversalKeyListener(); this.focusPropertyChangeListener = new FocusPropertyChangeListener(); this.keyboardFocusManager = null; this.printActive = false; this.printAnimator = null; this.printGLAD = null; this.printAWTTiles = null; this.setupPrintOnEDT = new Runnable() { public void run() { synchronized (NewtCanvasAWT.this.sync) { if (!NewtCanvasAWT.this.validateComponent(true)) { if (NewtCanvasAWT.DEBUG) System.err.println(NewtCanvasAWT.currentThreadName() + ": Info: NewtCanvasAWT setupPrint - skipped GL render, drawable not valid yet");  NewtCanvasAWT.this.printActive = false; return; }  if (!NewtCanvasAWT.this.isVisible()) { if (NewtCanvasAWT.DEBUG) System.err.println(NewtCanvasAWT.currentThreadName() + ": Info: NewtCanvasAWT setupPrint - skipped GL render, canvas not visible");  NewtCanvasAWT.this.printActive = false; return; }  GLAutoDrawable gLAutoDrawable = NewtCanvasAWT.this.getGLAD(); if (null == gLAutoDrawable) { if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.setup exit, newtChild not a GLAutoDrawable: " + NewtCanvasAWT.this.newtChild);  NewtCanvasAWT.this.printActive = false; return; }  NewtCanvasAWT.this.printAnimator = gLAutoDrawable.getAnimator(); if (null != NewtCanvasAWT.this.printAnimator) NewtCanvasAWT.this.printAnimator.remove(gLAutoDrawable);  NewtCanvasAWT.this.printGLAD = gLAutoDrawable; GLCapabilitiesImmutable gLCapabilitiesImmutable = gLAutoDrawable.getChosenGLCapabilities(); int i = NewtCanvasAWT.this.printAWTTiles.getNumSamples(gLCapabilitiesImmutable); GLDrawable gLDrawable = NewtCanvasAWT.this.printGLAD.getDelegatedDrawable(); boolean bool1 = (i != gLCapabilitiesImmutable.getNumSamples()) ? true : false; boolean bool2 = ((NewtCanvasAWT.this.printAWTTiles.customTileWidth != -1 && NewtCanvasAWT.this.printAWTTiles.customTileWidth != gLDrawable.getSurfaceWidth()) || (NewtCanvasAWT.this.printAWTTiles.customTileHeight != -1 && NewtCanvasAWT.this.printAWTTiles.customTileHeight != gLDrawable.getSurfaceHeight())) ? true : false; boolean bool3 = gLCapabilitiesImmutable.isOnscreen(); GLCapabilities gLCapabilities = (GLCapabilities)gLCapabilitiesImmutable.cloneMutable(); gLCapabilities.setDoubleBuffered(false); gLCapabilities.setOnscreen(false); if (i != gLCapabilities.getNumSamples()) { gLCapabilities.setSampleBuffers((0 < i)); gLCapabilities.setNumSamples(i); }  boolean bool4 = GLDrawableUtil.isSwapGLContextSafe(gLAutoDrawable.getRequestedGLCapabilities(), gLCapabilitiesImmutable, (GLCapabilitiesImmutable)gLCapabilities); boolean bool5 = ((bool3 || bool1 || bool2) && bool4) ? true : false; if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.setup: reqNewGLAD " + bool5 + "[ onscreen " + bool3 + ", samples " + bool1 + ", size " + bool2 + ", safe " + bool4 + "], , drawableSize " + gLDrawable.getSurfaceWidth() + "x" + gLDrawable.getSurfaceHeight() + ", customTileSize " + NewtCanvasAWT.this.printAWTTiles.customTileWidth + "x" + NewtCanvasAWT.this.printAWTTiles.customTileHeight + ", scaleMat " + NewtCanvasAWT.this.printAWTTiles.scaleMatX + " x " + NewtCanvasAWT.this.printAWTTiles.scaleMatY + ", numSamples " + NewtCanvasAWT.this.printAWTTiles.customNumSamples + " -> " + i + ", printAnimator " + NewtCanvasAWT.this.printAnimator);  if (bool5) { GLDrawableFactory gLDrawableFactory = GLDrawableFactory.getFactory(gLCapabilities.getGLProfile()); GLOffscreenAutoDrawable gLOffscreenAutoDrawable = null; try { gLOffscreenAutoDrawable = gLDrawableFactory.createOffscreenAutoDrawable(null, (GLCapabilitiesImmutable)gLCapabilities, null, (NewtCanvasAWT.this.printAWTTiles.customTileWidth != -1) ? NewtCanvasAWT.this.printAWTTiles.customTileWidth : 1024, (NewtCanvasAWT.this.printAWTTiles.customTileHeight != -1) ? NewtCanvasAWT.this.printAWTTiles.customTileHeight : 1024); } catch (GLException gLException) { if (NewtCanvasAWT.DEBUG) { System.err.println("Caught: " + gLException.getMessage()); gLException.printStackTrace(); }  }  if (null != gLOffscreenAutoDrawable) { NewtCanvasAWT.this.printGLAD = (GLAutoDrawable)gLOffscreenAutoDrawable; GLDrawableUtil.swapGLContextAndAllGLEventListener(gLAutoDrawable, NewtCanvasAWT.this.printGLAD); gLDrawable = NewtCanvasAWT.this.printGLAD.getDelegatedDrawable(); }  }  NewtCanvasAWT.this.printAWTTiles.setGLOrientation(NewtCanvasAWT.this.printGLAD.isGLOriented(), NewtCanvasAWT.this.printGLAD.isGLOriented()); NewtCanvasAWT.this.printAWTTiles.renderer.setTileSize(gLDrawable.getSurfaceWidth(), gLDrawable.getSurfaceHeight(), 0); NewtCanvasAWT.this.printAWTTiles.renderer.attachAutoDrawable(NewtCanvasAWT.this.printGLAD); if (NewtCanvasAWT.DEBUG) { System.err.println("AWT print.setup " + NewtCanvasAWT.this.printAWTTiles); System.err.println("AWT print.setup AA " + i + ", " + gLCapabilities); System.err.println("AWT print.setup printGLAD: " + NewtCanvasAWT.this.printGLAD.getSurfaceWidth() + "x" + NewtCanvasAWT.this.printGLAD.getSurfaceHeight() + ", " + NewtCanvasAWT.this.printGLAD); System.err.println("AWT print.setup printDraw: " + gLDrawable.getSurfaceWidth() + "x" + gLDrawable.getSurfaceHeight() + ", " + gLDrawable); }  }  } }; this.releasePrintOnEDT = new Runnable() { public void run() { synchronized (NewtCanvasAWT.this.sync) { if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.release " + NewtCanvasAWT.this.printAWTTiles);  GLAutoDrawable gLAutoDrawable = NewtCanvasAWT.this.getGLAD(); NewtCanvasAWT.this.printAWTTiles.dispose(); NewtCanvasAWT.this.printAWTTiles = null; if (NewtCanvasAWT.this.printGLAD != gLAutoDrawable) { GLDrawableUtil.swapGLContextAndAllGLEventListener(NewtCanvasAWT.this.printGLAD, gLAutoDrawable); NewtCanvasAWT.this.printGLAD.destroy(); }  NewtCanvasAWT.this.printGLAD = null; if (null != NewtCanvasAWT.this.printAnimator) { NewtCanvasAWT.this.printAnimator.add(gLAutoDrawable); NewtCanvasAWT.this.printAnimator = null; }  NewtCanvasAWT.this.printActive = false; }  } }; this.forceRelayout = new Runnable() { public void run() { if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.forceRelayout.0");  NewtCanvasAWT newtCanvasAWT = NewtCanvasAWT.this; int i = newtCanvasAWT.getWidth(); int j = newtCanvasAWT.getHeight(); newtCanvasAWT.setSize(i + 1, j + 1); newtCanvasAWT.setSize(i, j); if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.forceRelayout.X");  } }; this.awtMouseAdapter = (new AWTMouseAdapter()).addTo(this); this.awtKeyAdapter = (new AWTKeyAdapter()).addTo(this); this.awtWinAdapter = (AWTParentWindowAdapter)(new AWTParentWindowAdapter()).addTo(this); this.awtWinAdapter.removeWindowClosingFrom(this); setNEWTChild(paramWindow); } public void setShallUseOffscreenLayer(boolean paramBoolean) { this.shallUseOffscreenLayer = paramBoolean; } public final boolean getShallUseOffscreenLayer() { return this.shallUseOffscreenLayer; } public final boolean isOffscreenLayerSurfaceEnabled() { JAWTWindow jAWTWindow = this.jawtWindow; return (null != jAWTWindow && jAWTWindow.isOffscreenLayerSurfaceEnabled()); } public final boolean isApplet() { return this.isApplet; } private final boolean isParent() { Window window = this.newtChild; return (null != window && this.jawtWindow == window.getParent()); } private final boolean isFullscreen() { Window window = this.newtChild; return (null != window && window.isFullscreen()); } class FocusAction implements Window.FocusRunnable { public boolean run() { boolean bool1 = NewtCanvasAWT.this.isParent(); boolean bool2 = NewtCanvasAWT.this.isFullscreen(); if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.FocusAction: " + Display.getThreadName() + ", isOnscreen " + NewtCanvasAWT.this.isOnscreen + ", hasFocus " + NewtCanvasAWT.this.hasFocus() + ", isParent " + bool1 + ", isFS " + bool2);  if (bool1 && !bool2) if (NewtCanvasAWT.this.isOnscreen) { AWTEDTExecutor.singleton.invoke(false, NewtCanvasAWT.awtClearGlobalFocusOwner); } else if (!NewtCanvasAWT.this.hasFocus()) { NewtCanvasAWT.this.requestFocus(); }   return false; } } public NewtCanvasAWT() { this.focusAction = new FocusAction(); this.awtClearSelectedMenuPath = new Runnable() { public void run() { MenuSelectionManager.defaultManager().clearSelectedPath(); } }; this.clearAWTMenusOnNewtFocus = (WindowListener)new WindowAdapter() { public void windowResized(WindowEvent param1WindowEvent) { NewtCanvasAWT.this.updateLayoutSize(); } public void windowGainedFocus(WindowEvent param1WindowEvent) { if (NewtCanvasAWT.this.isParent() && !NewtCanvasAWT.this.isFullscreen()) AWTEDTExecutor.singleton.invoke(false, NewtCanvasAWT.this.awtClearSelectedMenuPath);  } }; this.newtFocusTraversalKeyListener = new FocusTraversalKeyListener(); this.focusPropertyChangeListener = new FocusPropertyChangeListener(); this.keyboardFocusManager = null; this.printActive = false; this.printAnimator = null; this.printGLAD = null; this.printAWTTiles = null; this.setupPrintOnEDT = new Runnable() { public void run() { synchronized (NewtCanvasAWT.this.sync) { if (!NewtCanvasAWT.this.validateComponent(true)) { if (NewtCanvasAWT.DEBUG) System.err.println(NewtCanvasAWT.currentThreadName() + ": Info: NewtCanvasAWT setupPrint - skipped GL render, drawable not valid yet");  NewtCanvasAWT.this.printActive = false; return; }  if (!NewtCanvasAWT.this.isVisible()) { if (NewtCanvasAWT.DEBUG) System.err.println(NewtCanvasAWT.currentThreadName() + ": Info: NewtCanvasAWT setupPrint - skipped GL render, canvas not visible");  NewtCanvasAWT.this.printActive = false; return; }  GLAutoDrawable gLAutoDrawable = NewtCanvasAWT.this.getGLAD(); if (null == gLAutoDrawable) { if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.setup exit, newtChild not a GLAutoDrawable: " + NewtCanvasAWT.this.newtChild);  NewtCanvasAWT.this.printActive = false; return; }  NewtCanvasAWT.this.printAnimator = gLAutoDrawable.getAnimator(); if (null != NewtCanvasAWT.this.printAnimator) NewtCanvasAWT.this.printAnimator.remove(gLAutoDrawable);  NewtCanvasAWT.this.printGLAD = gLAutoDrawable; GLCapabilitiesImmutable gLCapabilitiesImmutable = gLAutoDrawable.getChosenGLCapabilities(); int i = NewtCanvasAWT.this.printAWTTiles.getNumSamples(gLCapabilitiesImmutable); GLDrawable gLDrawable = NewtCanvasAWT.this.printGLAD.getDelegatedDrawable(); boolean bool1 = (i != gLCapabilitiesImmutable.getNumSamples()) ? true : false; boolean bool2 = ((NewtCanvasAWT.this.printAWTTiles.customTileWidth != -1 && NewtCanvasAWT.this.printAWTTiles.customTileWidth != gLDrawable.getSurfaceWidth()) || (NewtCanvasAWT.this.printAWTTiles.customTileHeight != -1 && NewtCanvasAWT.this.printAWTTiles.customTileHeight != gLDrawable.getSurfaceHeight())) ? true : false; boolean bool3 = gLCapabilitiesImmutable.isOnscreen(); GLCapabilities gLCapabilities = (GLCapabilities)gLCapabilitiesImmutable.cloneMutable(); gLCapabilities.setDoubleBuffered(false); gLCapabilities.setOnscreen(false); if (i != gLCapabilities.getNumSamples()) { gLCapabilities.setSampleBuffers((0 < i)); gLCapabilities.setNumSamples(i); }  boolean bool4 = GLDrawableUtil.isSwapGLContextSafe(gLAutoDrawable.getRequestedGLCapabilities(), gLCapabilitiesImmutable, (GLCapabilitiesImmutable)gLCapabilities); boolean bool5 = ((bool3 || bool1 || bool2) && bool4) ? true : false; if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.setup: reqNewGLAD " + bool5 + "[ onscreen " + bool3 + ", samples " + bool1 + ", size " + bool2 + ", safe " + bool4 + "], , drawableSize " + gLDrawable.getSurfaceWidth() + "x" + gLDrawable.getSurfaceHeight() + ", customTileSize " + NewtCanvasAWT.this.printAWTTiles.customTileWidth + "x" + NewtCanvasAWT.this.printAWTTiles.customTileHeight + ", scaleMat " + NewtCanvasAWT.this.printAWTTiles.scaleMatX + " x " + NewtCanvasAWT.this.printAWTTiles.scaleMatY + ", numSamples " + NewtCanvasAWT.this.printAWTTiles.customNumSamples + " -> " + i + ", printAnimator " + NewtCanvasAWT.this.printAnimator);  if (bool5) { GLDrawableFactory gLDrawableFactory = GLDrawableFactory.getFactory(gLCapabilities.getGLProfile()); GLOffscreenAutoDrawable gLOffscreenAutoDrawable = null; try { gLOffscreenAutoDrawable = gLDrawableFactory.createOffscreenAutoDrawable(null, (GLCapabilitiesImmutable)gLCapabilities, null, (NewtCanvasAWT.this.printAWTTiles.customTileWidth != -1) ? NewtCanvasAWT.this.printAWTTiles.customTileWidth : 1024, (NewtCanvasAWT.this.printAWTTiles.customTileHeight != -1) ? NewtCanvasAWT.this.printAWTTiles.customTileHeight : 1024); } catch (GLException gLException) { if (NewtCanvasAWT.DEBUG) { System.err.println("Caught: " + gLException.getMessage()); gLException.printStackTrace(); }  }  if (null != gLOffscreenAutoDrawable) { NewtCanvasAWT.this.printGLAD = (GLAutoDrawable)gLOffscreenAutoDrawable; GLDrawableUtil.swapGLContextAndAllGLEventListener(gLAutoDrawable, NewtCanvasAWT.this.printGLAD); gLDrawable = NewtCanvasAWT.this.printGLAD.getDelegatedDrawable(); }  }  NewtCanvasAWT.this.printAWTTiles.setGLOrientation(NewtCanvasAWT.this.printGLAD.isGLOriented(), NewtCanvasAWT.this.printGLAD.isGLOriented()); NewtCanvasAWT.this.printAWTTiles.renderer.setTileSize(gLDrawable.getSurfaceWidth(), gLDrawable.getSurfaceHeight(), 0); NewtCanvasAWT.this.printAWTTiles.renderer.attachAutoDrawable(NewtCanvasAWT.this.printGLAD); if (NewtCanvasAWT.DEBUG) { System.err.println("AWT print.setup " + NewtCanvasAWT.this.printAWTTiles); System.err.println("AWT print.setup AA " + i + ", " + gLCapabilities); System.err.println("AWT print.setup printGLAD: " + NewtCanvasAWT.this.printGLAD.getSurfaceWidth() + "x" + NewtCanvasAWT.this.printGLAD.getSurfaceHeight() + ", " + NewtCanvasAWT.this.printGLAD); System.err.println("AWT print.setup printDraw: " + gLDrawable.getSurfaceWidth() + "x" + gLDrawable.getSurfaceHeight() + ", " + gLDrawable); }  }  } }; this.releasePrintOnEDT = new Runnable() { public void run() { synchronized (NewtCanvasAWT.this.sync) { if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.release " + NewtCanvasAWT.this.printAWTTiles);  GLAutoDrawable gLAutoDrawable = NewtCanvasAWT.this.getGLAD(); NewtCanvasAWT.this.printAWTTiles.dispose(); NewtCanvasAWT.this.printAWTTiles = null; if (NewtCanvasAWT.this.printGLAD != gLAutoDrawable) { GLDrawableUtil.swapGLContextAndAllGLEventListener(NewtCanvasAWT.this.printGLAD, gLAutoDrawable); NewtCanvasAWT.this.printGLAD.destroy(); }  NewtCanvasAWT.this.printGLAD = null; if (null != NewtCanvasAWT.this.printAnimator) { NewtCanvasAWT.this.printAnimator.add(gLAutoDrawable); NewtCanvasAWT.this.printAnimator = null; }  NewtCanvasAWT.this.printActive = false; }  } }; this.forceRelayout = new Runnable() { public void run() { if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.forceRelayout.0");  NewtCanvasAWT newtCanvasAWT = NewtCanvasAWT.this; int i = newtCanvasAWT.getWidth(); int j = newtCanvasAWT.getHeight(); newtCanvasAWT.setSize(i + 1, j + 1); newtCanvasAWT.setSize(i, j); if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.forceRelayout.X");  } }; this.awtMouseAdapter = (new AWTMouseAdapter()).addTo(this); this.awtKeyAdapter = (new AWTKeyAdapter()).addTo(this); this.awtWinAdapter = (AWTParentWindowAdapter)(new AWTParentWindowAdapter()).addTo(this); this.awtWinAdapter.removeWindowClosingFrom(this); } public NewtCanvasAWT(Window paramWindow) { this.focusAction = new FocusAction(); this.awtClearSelectedMenuPath = new Runnable() { public void run() { MenuSelectionManager.defaultManager().clearSelectedPath(); } }; this.clearAWTMenusOnNewtFocus = (WindowListener)new WindowAdapter() { public void windowResized(WindowEvent param1WindowEvent) { NewtCanvasAWT.this.updateLayoutSize(); } public void windowGainedFocus(WindowEvent param1WindowEvent) { if (NewtCanvasAWT.this.isParent() && !NewtCanvasAWT.this.isFullscreen()) AWTEDTExecutor.singleton.invoke(false, NewtCanvasAWT.this.awtClearSelectedMenuPath);  } }; this.newtFocusTraversalKeyListener = new FocusTraversalKeyListener(); this.focusPropertyChangeListener = new FocusPropertyChangeListener(); this.keyboardFocusManager = null; this.printActive = false; this.printAnimator = null; this.printGLAD = null; this.printAWTTiles = null; this.setupPrintOnEDT = new Runnable() { public void run() { synchronized (NewtCanvasAWT.this.sync) { if (!NewtCanvasAWT.this.validateComponent(true)) { if (NewtCanvasAWT.DEBUG) System.err.println(NewtCanvasAWT.currentThreadName() + ": Info: NewtCanvasAWT setupPrint - skipped GL render, drawable not valid yet");  NewtCanvasAWT.this.printActive = false; return; }  if (!NewtCanvasAWT.this.isVisible()) { if (NewtCanvasAWT.DEBUG) System.err.println(NewtCanvasAWT.currentThreadName() + ": Info: NewtCanvasAWT setupPrint - skipped GL render, canvas not visible");  NewtCanvasAWT.this.printActive = false; return; }  GLAutoDrawable gLAutoDrawable = NewtCanvasAWT.this.getGLAD(); if (null == gLAutoDrawable) { if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.setup exit, newtChild not a GLAutoDrawable: " + NewtCanvasAWT.this.newtChild);  NewtCanvasAWT.this.printActive = false; return; }  NewtCanvasAWT.this.printAnimator = gLAutoDrawable.getAnimator(); if (null != NewtCanvasAWT.this.printAnimator) NewtCanvasAWT.this.printAnimator.remove(gLAutoDrawable);  NewtCanvasAWT.this.printGLAD = gLAutoDrawable; GLCapabilitiesImmutable gLCapabilitiesImmutable = gLAutoDrawable.getChosenGLCapabilities(); int i = NewtCanvasAWT.this.printAWTTiles.getNumSamples(gLCapabilitiesImmutable); GLDrawable gLDrawable = NewtCanvasAWT.this.printGLAD.getDelegatedDrawable(); boolean bool1 = (i != gLCapabilitiesImmutable.getNumSamples()) ? true : false; boolean bool2 = ((NewtCanvasAWT.this.printAWTTiles.customTileWidth != -1 && NewtCanvasAWT.this.printAWTTiles.customTileWidth != gLDrawable.getSurfaceWidth()) || (NewtCanvasAWT.this.printAWTTiles.customTileHeight != -1 && NewtCanvasAWT.this.printAWTTiles.customTileHeight != gLDrawable.getSurfaceHeight())) ? true : false; boolean bool3 = gLCapabilitiesImmutable.isOnscreen(); GLCapabilities gLCapabilities = (GLCapabilities)gLCapabilitiesImmutable.cloneMutable(); gLCapabilities.setDoubleBuffered(false); gLCapabilities.setOnscreen(false); if (i != gLCapabilities.getNumSamples()) { gLCapabilities.setSampleBuffers((0 < i)); gLCapabilities.setNumSamples(i); }  boolean bool4 = GLDrawableUtil.isSwapGLContextSafe(gLAutoDrawable.getRequestedGLCapabilities(), gLCapabilitiesImmutable, (GLCapabilitiesImmutable)gLCapabilities); boolean bool5 = ((bool3 || bool1 || bool2) && bool4) ? true : false; if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.setup: reqNewGLAD " + bool5 + "[ onscreen " + bool3 + ", samples " + bool1 + ", size " + bool2 + ", safe " + bool4 + "], , drawableSize " + gLDrawable.getSurfaceWidth() + "x" + gLDrawable.getSurfaceHeight() + ", customTileSize " + NewtCanvasAWT.this.printAWTTiles.customTileWidth + "x" + NewtCanvasAWT.this.printAWTTiles.customTileHeight + ", scaleMat " + NewtCanvasAWT.this.printAWTTiles.scaleMatX + " x " + NewtCanvasAWT.this.printAWTTiles.scaleMatY + ", numSamples " + NewtCanvasAWT.this.printAWTTiles.customNumSamples + " -> " + i + ", printAnimator " + NewtCanvasAWT.this.printAnimator);  if (bool5) { GLDrawableFactory gLDrawableFactory = GLDrawableFactory.getFactory(gLCapabilities.getGLProfile()); GLOffscreenAutoDrawable gLOffscreenAutoDrawable = null; try { gLOffscreenAutoDrawable = gLDrawableFactory.createOffscreenAutoDrawable(null, (GLCapabilitiesImmutable)gLCapabilities, null, (NewtCanvasAWT.this.printAWTTiles.customTileWidth != -1) ? NewtCanvasAWT.this.printAWTTiles.customTileWidth : 1024, (NewtCanvasAWT.this.printAWTTiles.customTileHeight != -1) ? NewtCanvasAWT.this.printAWTTiles.customTileHeight : 1024); } catch (GLException gLException) { if (NewtCanvasAWT.DEBUG) { System.err.println("Caught: " + gLException.getMessage()); gLException.printStackTrace(); }  }  if (null != gLOffscreenAutoDrawable) { NewtCanvasAWT.this.printGLAD = (GLAutoDrawable)gLOffscreenAutoDrawable; GLDrawableUtil.swapGLContextAndAllGLEventListener(gLAutoDrawable, NewtCanvasAWT.this.printGLAD); gLDrawable = NewtCanvasAWT.this.printGLAD.getDelegatedDrawable(); }  }  NewtCanvasAWT.this.printAWTTiles.setGLOrientation(NewtCanvasAWT.this.printGLAD.isGLOriented(), NewtCanvasAWT.this.printGLAD.isGLOriented()); NewtCanvasAWT.this.printAWTTiles.renderer.setTileSize(gLDrawable.getSurfaceWidth(), gLDrawable.getSurfaceHeight(), 0); NewtCanvasAWT.this.printAWTTiles.renderer.attachAutoDrawable(NewtCanvasAWT.this.printGLAD); if (NewtCanvasAWT.DEBUG) { System.err.println("AWT print.setup " + NewtCanvasAWT.this.printAWTTiles); System.err.println("AWT print.setup AA " + i + ", " + gLCapabilities); System.err.println("AWT print.setup printGLAD: " + NewtCanvasAWT.this.printGLAD.getSurfaceWidth() + "x" + NewtCanvasAWT.this.printGLAD.getSurfaceHeight() + ", " + NewtCanvasAWT.this.printGLAD); System.err.println("AWT print.setup printDraw: " + gLDrawable.getSurfaceWidth() + "x" + gLDrawable.getSurfaceHeight() + ", " + gLDrawable); }  }  } }; this.releasePrintOnEDT = new Runnable() { public void run() { synchronized (NewtCanvasAWT.this.sync) { if (NewtCanvasAWT.DEBUG) System.err.println("AWT print.release " + NewtCanvasAWT.this.printAWTTiles);  GLAutoDrawable gLAutoDrawable = NewtCanvasAWT.this.getGLAD(); NewtCanvasAWT.this.printAWTTiles.dispose(); NewtCanvasAWT.this.printAWTTiles = null; if (NewtCanvasAWT.this.printGLAD != gLAutoDrawable) { GLDrawableUtil.swapGLContextAndAllGLEventListener(NewtCanvasAWT.this.printGLAD, gLAutoDrawable); NewtCanvasAWT.this.printGLAD.destroy(); }  NewtCanvasAWT.this.printGLAD = null; if (null != NewtCanvasAWT.this.printAnimator) { NewtCanvasAWT.this.printAnimator.add(gLAutoDrawable); NewtCanvasAWT.this.printAnimator = null; }  NewtCanvasAWT.this.printActive = false; }  } }; this.forceRelayout = new Runnable() { public void run() { if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.forceRelayout.0");  NewtCanvasAWT newtCanvasAWT = NewtCanvasAWT.this; int i = newtCanvasAWT.getWidth(); int j = newtCanvasAWT.getHeight(); newtCanvasAWT.setSize(i + 1, j + 1); newtCanvasAWT.setSize(i, j); if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.forceRelayout.X");  } }; this.awtMouseAdapter = (new AWTMouseAdapter()).addTo(this); this.awtKeyAdapter = (new AWTKeyAdapter()).addTo(this); this.awtWinAdapter = (AWTParentWindowAdapter)(new AWTParentWindowAdapter()).addTo(this); this.awtWinAdapter.removeWindowClosingFrom(this); setNEWTChild(paramWindow); } private static class ClearFocusOwner implements Runnable {
/*      */     private ClearFocusOwner() {} public void run() { KeyboardFocusManager.getCurrentKeyboardFocusManager().clearGlobalFocusOwner(); } } private static final Runnable awtClearGlobalFocusOwner = new ClearFocusOwner(); private final Runnable awtClearSelectedMenuPath; private final WindowListener clearAWTMenusOnNewtFocus; private final FocusTraversalKeyListener newtFocusTraversalKeyListener; private final FocusPropertyChangeListener focusPropertyChangeListener; private volatile KeyboardFocusManager keyboardFocusManager; private volatile boolean printActive; private GLAnimatorControl printAnimator; private GLAutoDrawable printGLAD; private AWTTilePainter printAWTTiles; private final Runnable setupPrintOnEDT; private final Runnable releasePrintOnEDT; private final Runnable forceRelayout; class FocusTraversalKeyListener implements KeyListener {
/*      */     public void keyPressed(KeyEvent param1KeyEvent) { if (NewtCanvasAWT.this.isParent() && !NewtCanvasAWT.this.isFullscreen()) handleKey(param1KeyEvent, false);  } public void keyReleased(KeyEvent param1KeyEvent) { if (NewtCanvasAWT.this.isParent() && !NewtCanvasAWT.this.isFullscreen()) handleKey(param1KeyEvent, true);  } void handleKey(KeyEvent param1KeyEvent, boolean param1Boolean) { if (null == NewtCanvasAWT.this.keyboardFocusManager) throw new InternalError("XXX");  AWTKeyStroke aWTKeyStroke = AWTKeyStroke.getAWTKeyStroke(param1KeyEvent.getKeyCode(), param1KeyEvent.getModifiers(), param1Boolean); boolean bool = false; if (null != aWTKeyStroke) { Set<AWTKeyStroke> set1 = NewtCanvasAWT.this.keyboardFocusManager.getDefaultFocusTraversalKeys(0); Set<AWTKeyStroke> set2 = NewtCanvasAWT.this.keyboardFocusManager.getDefaultFocusTraversalKeys(1); if (set1.contains(aWTKeyStroke)) { Component component = AWTMisc.getNextFocus(NewtCanvasAWT.this, true); if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.focusKey (fwd): " + aWTKeyStroke + ", current focusOwner " + NewtCanvasAWT.this.keyboardFocusManager.getFocusOwner() + ", hasFocus: " + NewtCanvasAWT.this.hasFocus() + ", nextFocus " + component);  component.requestFocus(); bool = true; } else if (set2.contains(aWTKeyStroke)) { Component component = AWTMisc.getNextFocus(NewtCanvasAWT.this, false); if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.focusKey (bwd): " + aWTKeyStroke + ", current focusOwner " + NewtCanvasAWT.this.keyboardFocusManager.getFocusOwner() + ", hasFocus: " + NewtCanvasAWT.this.hasFocus() + ", prevFocus " + component);  component.requestFocus(); bool = true; }  }  if (bool) param1KeyEvent.setConsumed(true);  if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.focusKey: XXX: " + aWTKeyStroke);  } } class FocusPropertyChangeListener implements PropertyChangeListener {
/*      */     public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) { Object object1 = param1PropertyChangeEvent.getOldValue(); Object object2 = param1PropertyChangeEvent.getNewValue(); boolean bool1 = NewtCanvasAWT.this.isParent(); boolean bool2 = NewtCanvasAWT.this.isFullscreen(); if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.FocusProperty: " + param1PropertyChangeEvent.getPropertyName() + ", src " + param1PropertyChangeEvent.getSource() + ", " + object1 + " -> " + object2 + ", isParent " + bool1 + ", isFS " + bool2);  if (bool1 && !bool2) if (object2 == NewtCanvasAWT.this) { if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.FocusProperty: AWT focus -> NEWT focus traversal");  NewtCanvasAWT.this.requestFocusNEWTChild(); } else if (object1 == NewtCanvasAWT.this && object2 == null) { if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.FocusProperty: NEWT focus");  } else if (null != object2 && object2 != NewtCanvasAWT.this) { if (NewtCanvasAWT.DEBUG) System.err.println("NewtCanvasAWT.FocusProperty: lost focus - clear focus");  if (NewtCanvasAWT.this.newtChild.getDelegatedWindow() instanceof DriverClearFocus) ((DriverClearFocus)NewtCanvasAWT.this.newtChild.getDelegatedWindow()).clearFocus();  }   } } private final void requestFocusNEWTChild() { if (null != this.newtChild) { this.newtChild.setFocusAction(null); if (this.isOnscreen) AWTEDTExecutor.singleton.invoke(false, awtClearGlobalFocusOwner);  this.newtChild.requestFocus(); this.newtChild.setFocusAction(this.focusAction); }  } public Window setNEWTChild(Window paramWindow) { synchronized (this.sync) { Window window = this.newtChild; if (DEBUG) System.err.println("NewtCanvasAWT.setNEWTChild.0: win " + newtWinHandleToHexString(window) + " -> " + newtWinHandleToHexString(paramWindow));  Container container = AWTMisc.getContainer(this); if (null != this.newtChild) { detachNewtChild(container); this.newtChild = null; }  this.newtChild = paramWindow; updateLayoutSize(); return window; }  } private final void updateLayoutSize() { Window window = this.newtChild; if (null != window) { Dimension dimension = new Dimension(window.getWidth(), window.getHeight()); setMinimumSize(dimension); setPreferredSize(dimension); }  } public Window getNEWTChild() { return this.newtChild; } public NativeWindow getNativeWindow() { return (NativeWindow)this.jawtWindow; } public NativeSurface getNativeSurface() { return (NativeSurface)this.jawtWindow; }
/*      */   public WindowClosingProtocol.WindowClosingMode getDefaultCloseOperation() { return this.awtWindowClosingProtocol.getDefaultCloseOperation(); }
/* 1088 */   private final void detachNewtChild(Container paramContainer) { if (null == this.newtChild || null == this.jawtWindow || !this.newtChildAttached) {
/*      */       return;
/*      */     }
/* 1091 */     if (DEBUG)
/*      */     {
/*      */       
/* 1094 */       System.err.println("NewtCanvasAWT.detachNewtChild.0: win " + newtWinHandleToHexString(this.newtChild) + ", EDTUtil: cur " + this.newtChild
/* 1095 */           .getScreen().getDisplay().getEDTUtil() + ", comp " + this + ", visible " + 
/* 1096 */           isVisible() + ", showing " + isShowing() + ", displayable " + isDisplayable() + ", cont " + paramContainer);
/*      */     }
/*      */ 
/*      */     
/* 1100 */     this.newtChild.removeSurfaceUpdatedListener((SurfaceUpdatedListener)this.jawtWindow);
/* 1101 */     this.newtChildAttached = false;
/* 1102 */     this.newtChild.setFocusAction(null);
/* 1103 */     configureNewtChild(false);
/* 1104 */     this.newtChild.setVisible(false);
/*      */     
/* 1106 */     this.newtChild.reparentWindow(null, -1, -1, 0);
/*      */     
/* 1108 */     if (DEBUG)
/* 1109 */       System.err.println("NewtCanvasAWT.detachNewtChild.X: win " + newtWinHandleToHexString(this.newtChild) + ", EDTUtil: cur " + this.newtChild.getScreen().getDisplay().getEDTUtil() + ", comp " + this);  }
/*      */   public WindowClosingProtocol.WindowClosingMode setDefaultCloseOperation(WindowClosingProtocol.WindowClosingMode paramWindowClosingMode) { return this.awtWindowClosingProtocol.setDefaultCloseOperation(paramWindowClosingMode); }
/*      */   public final void setSkipJAWTDestroy(boolean paramBoolean) { this.skipJAWTDestroy = paramBoolean; } public final boolean getSkipJAWTDestroy() { return this.skipJAWTDestroy; } private final void determineIfApplet() { this.isApplet = false; NewtCanvasAWT newtCanvasAWT = this; while (!this.isApplet && null != newtCanvasAWT) { this.isApplet = newtCanvasAWT instanceof java.applet.Applet; Container container = newtCanvasAWT.getParent(); }  } private void setAWTGraphicsConfiguration(AWTGraphicsConfiguration paramAWTGraphicsConfiguration) { this.awtConfig = paramAWTGraphicsConfiguration; if (null != this.jawtWindow) this.jawtWindow.setAWTGraphicsConfiguration(paramAWTGraphicsConfiguration);  } public GraphicsConfiguration getGraphicsConfiguration() { GraphicsConfiguration graphicsConfiguration1 = super.getGraphicsConfiguration(); if (Beans.isDesignTime()) return graphicsConfiguration1;  GraphicsConfiguration graphicsConfiguration2 = (null != this.awtConfig) ? this.awtConfig.getAWTGraphicsConfiguration() : null; if (null != graphicsConfiguration1 && null != graphicsConfiguration2 && !graphicsConfiguration2.equals(graphicsConfiguration1)) { if (!graphicsConfiguration2.getDevice().getIDstring().equals(graphicsConfiguration1.getDevice().getIDstring())) { AWTGraphicsConfiguration aWTGraphicsConfiguration = AWTGraphicsConfiguration.create(graphicsConfiguration1, this.awtConfig.getChosenCapabilities(), this.awtConfig.getRequestedCapabilities()); GraphicsConfiguration graphicsConfiguration = aWTGraphicsConfiguration.getAWTGraphicsConfiguration(); boolean bool = aWTGraphicsConfiguration.getChosenCapabilities().equals(this.awtConfig.getChosenCapabilities()); if (DEBUG) { System.err.println(getThreadName() + ": getGraphicsConfiguration() Info: Changed GC and GD"); System.err.println("Created Config (n): Old     GC " + graphicsConfiguration2); System.err.println("Created Config (n): Old     GD " + graphicsConfiguration2.getDevice().getIDstring()); System.err.println("Created Config (n): Parent  GC " + graphicsConfiguration1); System.err.println("Created Config (n): Parent  GD " + graphicsConfiguration1.getDevice().getIDstring()); System.err.println("Created Config (n): New     GC " + graphicsConfiguration); System.err.println("Created Config (n): Old     CF " + this.awtConfig); System.err.println("Created Config (n): New     CF " + aWTGraphicsConfiguration); System.err.println("Created Config (n): EQUALS CAPS " + bool); }  if (null != graphicsConfiguration) { setAWTGraphicsConfiguration(aWTGraphicsConfiguration); if (DEBUG) System.err.println(getThreadName() + ": Info: getGraphicsConfiguration - end.01: newGC " + graphicsConfiguration);  return graphicsConfiguration; }  if (DEBUG) System.err.println(getThreadName() + ": Info: getGraphicsConfiguration - end.00: oldGC " + graphicsConfiguration2);  }  return graphicsConfiguration2; }  if (null == graphicsConfiguration1) return graphicsConfiguration2;  return graphicsConfiguration1; } private static String getThreadName() { return Thread.currentThread().getName(); } public void addNotify() { if (Beans.isDesignTime()) { super.addNotify(); } else { JAWTUtil.disableBackgroundErase(this); GraphicsConfiguration graphicsConfiguration = super.getGraphicsConfiguration(); if (null == graphicsConfiguration) throw new GLException("Error: NULL AWT GraphicsConfiguration");  CapabilitiesImmutable capabilitiesImmutable = (null != this.newtChild) ? this.newtChild.getRequestedCapabilities() : null; AWTGraphicsConfiguration aWTGraphicsConfiguration = AWTGraphicsConfiguration.create(graphicsConfiguration, null, capabilitiesImmutable); if (null == aWTGraphicsConfiguration) throw new GLException("Error: NULL AWTGraphicsConfiguration");  setAWTGraphicsConfiguration(aWTGraphicsConfiguration); super.addNotify(); JAWTUtil.disableBackgroundErase(this); synchronized (this.sync) { determineIfApplet(); if (DEBUG) { System.err.println("NewtCanvasAWT.addNotify.0 - isApplet " + this.isApplet + ", addedOnAWTEDT " + EventQueue.isDispatchThread() + " @ " + currentThreadName()); ExceptionUtils.dumpStack(System.err); }  this.jawtWindow = NewtFactoryAWT.getNativeWindow(this, aWTGraphicsConfiguration); this.jawtWindow.setShallUseOffscreenLayer(this.shallUseOffscreenLayer); this.jawtWindow.lockSurface(); this.jawtWindow.unlockSurface(); this.awtWindowClosingProtocol.addClosingListener(); this.componentAdded = true; if (DEBUG) System.err.println("NewtCanvasAWT.addNotify.X: twin " + newtWinHandleToHexString(this.newtChild) + ", comp " + this + ", visible " + isVisible() + ", showing " + isShowing() + ", displayable " + isDisplayable() + ", cont " + AWTMisc.getContainer(this));  }  }  } private final boolean updatePixelScale(GraphicsConfiguration paramGraphicsConfiguration, boolean paramBoolean) { if (this.jawtWindow.updatePixelScale(paramGraphicsConfiguration, false) || this.jawtWindow.hasPixelScaleChanged() || paramBoolean) { this.jawtWindow.hasPixelScaleChanged(); float[] arrayOfFloat = this.jawtWindow.getCurrentSurfaceScale(new float[2]); Window window1 = this.newtChild; Window window2 = window1.getDelegatedWindow(); if (window2 instanceof WindowImpl) ((WindowImpl)window2).setSurfaceScale(arrayOfFloat);  return true; }  return false; } public void removeNotify() { if (Beans.isDesignTime()) { super.removeNotify(); } else { if (DEBUG) { System.err.println("NewtCanvasAWT.removeNotify.0 - isApplet " + this.isApplet + " @ " + currentThreadName()); ExceptionUtils.dumpStack(System.err); }  this.componentAdded = false; this.awtWindowClosingProtocol.removeClosingListener(); destroyImpl(true, false); super.removeNotify(); if (DEBUG) System.err.println("NewtCanvasAWT.removeNotify.X @ " + currentThreadName());  }  } public final void destroy() { if (DEBUG) { System.err.println("NewtCanvasAWT.destroy() @ " + currentThreadName()); ExceptionUtils.dumpStack(System.err); }  AWTEDTExecutor.singleton.invoke(true, new Runnable() {
/*      */           public void run() { NewtCanvasAWT.this.destroyImpl(false, false); }
/* 1113 */         }); } protected static String currentThreadName() { return "[" + Thread.currentThread().getName() + ", isAWT-EDT " + EventQueue.isDispatchThread() + "]"; }
/*      */   private final void destroyImpl(boolean paramBoolean1, boolean paramBoolean2) { synchronized (this.sync) { Container container = AWTMisc.getContainer(this); if (DEBUG) { System.err.println("NewtCanvasAWT.destroyImpl @ " + currentThreadName()); System.err.println("NewtCanvasAWT.destroyImpl.0 - isApplet " + this.isApplet + ", isOnAWTEDT " + EventQueue.isDispatchThread() + ", skipJAWTDestroy " + this.skipJAWTDestroy + "; removeNotify " + paramBoolean1 + ", windowClosing " + paramBoolean2 + ", destroyJAWTPending " + this.destroyJAWTPending + ", hasJAWT " + ((null != this.jawtWindow) ? 1 : 0) + ", hasNEWT " + ((null != this.newtChild) ? 1 : 0) + "): nw " + newtWinHandleToHexString(this.newtChild) + ", from " + container); }  if (null != this.newtChild) { detachNewtChild(container); if (!paramBoolean1) { Window window1 = this.newtChild; Window window2 = window1.getDelegatedWindow(); this.newtChild = null; if (paramBoolean2 && window2 instanceof WindowImpl) { ((WindowImpl)window2).windowDestroyNotify(true); } else { window1.destroy(); }  }  }  if ((this.destroyJAWTPending || paramBoolean1 || paramBoolean2) && null != this.jawtWindow) if (this.skipJAWTDestroy) { this.destroyJAWTPending = true; } else { NewtFactoryAWT.destroyNativeWindow(this.jawtWindow); this.jawtWindow = null; this.awtConfig = null; this.destroyJAWTPending = false; }   }  }
/*      */   public void paint(Graphics paramGraphics) { synchronized (this.sync) { if (validateComponent(true) && !this.printActive) this.newtChild.windowRepaint(0, 0, getWidth(), getHeight());  }  }
/* 1116 */   public void update(Graphics paramGraphics) { paint(paramGraphics); } public void reshape(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { synchronized (getTreeLock()) { synchronized (this.sync) { super.reshape(paramInt1, paramInt2, paramInt3, paramInt4); if (DEBUG) System.err.println("NewtCanvasAWT.reshape: " + paramInt1 + "/" + paramInt2 + " " + paramInt3 + "x" + paramInt4);  if (!validateComponent(true) || this.printActive || updatePixelScale(getGraphicsConfiguration(), false)); }  }  } private final GLAutoDrawable getGLAD() { if (null != this.newtChild && this.newtChild instanceof GLAutoDrawable) return (GLAutoDrawable)this.newtChild;  return null; } public void setupPrint(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, int paramInt3) { this.printActive = true; byte b = isOpaque() ? 3 : 4; TileRenderer tileRenderer = new TileRenderer(); this.printAWTTiles = new AWTTilePainter(tileRenderer, b, paramDouble1, paramDouble2, paramInt1, paramInt2, paramInt3, DEBUG); AWTEDTExecutor.singleton.invoke(getTreeLock(), true, true, this.setupPrintOnEDT); } public void releasePrint() { if (!this.printActive || null == this.printGLAD) throw new IllegalStateException("setupPrint() not called");  AWTEDTExecutor.singleton.invoke(getTreeLock(), true, true, this.releasePrintOnEDT); this.newtChild.sendWindowEvent(100); } public void print(Graphics paramGraphics) { synchronized (this.sync) { if (!this.printActive || null == this.printGLAD) throw new IllegalStateException("setupPrint() not called");  if (DEBUG && !EventQueue.isDispatchThread()) System.err.println(currentThreadName() + ": Warning: GLCanvas print - not called from AWT-EDT");  Graphics2D graphics2D = (Graphics2D)paramGraphics; try { this.printAWTTiles.setupGraphics2DAndClipBounds(graphics2D, getWidth(), getHeight()); TileRenderer tileRenderer = this.printAWTTiles.renderer; if (DEBUG) System.err.println("AWT print.0: " + tileRenderer);  if (!tileRenderer.eot()) try { while (true) { tileRenderer.display(); if (tileRenderer.eot()) { if (DEBUG) System.err.println("AWT print.1: " + this.printAWTTiles);  tileRenderer.reset(); this.printAWTTiles.resetGraphics2D(); break; }  }  } finally { this.printAWTTiles.resetGraphics2D(); }   } catch (NoninvertibleTransformException noninvertibleTransformException) { System.err.println("Caught: Inversion failed of: " + graphics2D.getTransform()); noninvertibleTransformException.printStackTrace(); }  if (DEBUG) System.err.println("AWT print.X: " + this.printAWTTiles);  }  } private final boolean validateComponent(boolean paramBoolean) { if (Beans.isDesignTime() || !isDisplayable()) return false;  if (null == this.newtChild || null == this.jawtWindow) return false;  if (0 >= getWidth() || 0 >= getHeight()) return false;  if (paramBoolean && !this.newtChildAttached && null != this.newtChild) attachNewtChild();  return true; } private final void configureNewtChild(boolean paramBoolean) { this.awtWinAdapter.clear(); this.awtKeyAdapter.clear(); this.awtMouseAdapter.clear(); if (null != this.keyboardFocusManager) { this.keyboardFocusManager.removePropertyChangeListener("focusOwner", this.focusPropertyChangeListener); this.keyboardFocusManager = null; }  if (null != this.newtChild) { this.newtChild.setKeyboardFocusHandler(null); if (paramBoolean) { if (null == this.jawtWindow.getGraphicsConfiguration()) throw new InternalError("XXX");  this.isOnscreen = this.jawtWindow.getGraphicsConfiguration().getChosenCapabilities().isOnscreen(); this.awtWinAdapter.setDownstream((NativeWindow)this.jawtWindow, this.newtChild); this.newtChild.addWindowListener(this.clearAWTMenusOnNewtFocus); this.newtChild.setFocusAction(this.focusAction); this.newtChildCloseOp = this.newtChild.setDefaultCloseOperation(WindowClosingProtocol.WindowClosingMode.DO_NOTHING_ON_CLOSE); this.keyboardFocusManager = KeyboardFocusManager.getCurrentKeyboardFocusManager(); this.keyboardFocusManager.addPropertyChangeListener("focusOwner", this.focusPropertyChangeListener); setFocusable(true); if (this.isOnscreen) { this.newtChild.setKeyboardFocusHandler(this.newtFocusTraversalKeyListener); } else { this.awtMouseAdapter.setDownstream(this.newtChild); this.awtKeyAdapter.setDownstream(this.newtChild); this.awtKeyAdapter.setConsumeAWTEvent(true); }  } else { this.newtChild.removeWindowListener(this.clearAWTMenusOnNewtFocus); this.newtChild.setFocusAction(null); this.newtChild.setDefaultCloseOperation(this.newtChildCloseOp); setFocusable(false); }  }  } public final boolean isAWTEventPassThrough() { return !this.isOnscreen; } private final void attachNewtChild() { if (null == this.newtChild || null == this.jawtWindow || this.newtChildAttached) return;  if (DEBUG) { System.err.println("NewtCanvasAWT.attachNewtChild.0 @ " + currentThreadName()); System.err.println("\twin " + newtWinHandleToHexString(this.newtChild) + ", EDTUtil: cur " + this.newtChild.getScreen().getDisplay().getEDTUtil() + ", comp " + this + ", visible " + isVisible() + ", showing " + isShowing() + ", displayable " + isDisplayable() + ", cont " + AWTMisc.getContainer(this)); }  this.newtChildAttached = true; this.newtChild.setFocusAction(null); if (DEBUG) System.err.println("NewtCanvasAWT.attachNewtChild.1: newtChild: " + this.newtChild);  int i = getWidth(); int j = getHeight(); if (DEBUG) System.err.println("NewtCanvasAWT.attachNewtChild.2: size " + i + "x" + j + ", isNValid " + this.newtChild.isNativeValid());  this.newtChild.setVisible(false); this.newtChild.setSize(i, j); updatePixelScale(getGraphicsConfiguration(), true); this.newtChild.reparentWindow((NativeWindow)this.jawtWindow, -1, -1, 2); this.newtChild.addSurfaceUpdatedListener((SurfaceUpdatedListener)this.jawtWindow); if (this.jawtWindow.isOffscreenLayerSurfaceEnabled() && 0 != (0x2 & JAWTUtil.getOSXCALayerQuirks())) AWTEDTExecutor.singleton.invoke(false, this.forceRelayout);  this.newtChild.setVisible(true); configureNewtChild(true); this.newtChild.sendWindowEvent(100); if (DEBUG) System.err.println("NewtCanvasAWT.attachNewtChild.X: win " + newtWinHandleToHexString(this.newtChild) + ", EDTUtil: cur " + this.newtChild.getScreen().getDisplay().getEDTUtil() + ", comp " + this);  } static String newtWinHandleToHexString(Window paramWindow) { return (null != paramWindow) ? toHexString(paramWindow.getWindowHandle()) : "nil"; }
/*      */   
/*      */   static String toHexString(long paramLong) {
/* 1119 */     return "0x" + Long.toHexString(paramLong);
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/newt/awt/NewtCanvasAWT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */