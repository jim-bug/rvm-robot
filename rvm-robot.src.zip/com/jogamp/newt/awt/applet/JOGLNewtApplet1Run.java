/*     */ package com.jogamp.newt.awt.applet;
/*     */ 
/*     */ import com.jogamp.common.util.awt.AWTEDTExecutor;
/*     */ import com.jogamp.nativewindow.WindowClosingProtocol;
/*     */ import com.jogamp.newt.Window;
/*     */ import com.jogamp.newt.awt.NewtCanvasAWT;
/*     */ import com.jogamp.newt.opengl.GLWindow;
/*     */ import com.jogamp.newt.util.applet.JOGLNewtAppletBase;
/*     */ import com.jogamp.opengl.GLCapabilities;
/*     */ import com.jogamp.opengl.GLCapabilitiesImmutable;
/*     */ import com.jogamp.opengl.GLEventListener;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ import java.applet.Applet;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Button;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.util.Arrays;
/*     */ import jogamp.nativewindow.jawt.JAWTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JOGLNewtApplet1Run
/*     */   extends Applet
/*     */ {
/* 101 */   public static final boolean DEBUG = JOGLNewtAppletBase.DEBUG;
/*     */   
/* 103 */   GLWindow glWindow = null;
/* 104 */   NewtCanvasAWT newtCanvasAWT = null;
/* 105 */   JOGLNewtAppletBase base = null;
/*     */   
/* 107 */   int glXd = Integer.MAX_VALUE, glYd = Integer.MAX_VALUE, glWidth = Integer.MAX_VALUE, glHeight = Integer.MAX_VALUE;
/*     */ 
/*     */   
/*     */   public void init() {
/* 111 */     if (DEBUG) {
/* 112 */       System.err.println("JOGLNewtApplet1Run.init() START - " + currentThreadName());
/*     */     }
/* 114 */     final JOGLNewtApplet1Run container = this;
/*     */     
/* 116 */     String str1 = null;
/* 117 */     String str2 = null;
/* 118 */     int i = 1;
/* 119 */     boolean bool1 = false;
/* 120 */     boolean bool2 = false;
/* 121 */     boolean bool3 = false;
/* 122 */     boolean bool4 = false;
/* 123 */     boolean bool5 = false;
/* 124 */     boolean bool6 = true;
/* 125 */     int j = 0;
/* 126 */     int k = 0;
/* 127 */     boolean bool7 = false;
/* 128 */     boolean bool8 = false;
/*     */     try {
/* 130 */       str1 = getParameter("gl_event_listener_class");
/* 131 */       str2 = getParameter("gl_profile");
/* 132 */       i = JOGLNewtAppletBase.str2Int(getParameter("gl_swap_interval"), i);
/* 133 */       bool1 = JOGLNewtAppletBase.str2Bool(getParameter("gl_debug"), bool1);
/* 134 */       bool2 = JOGLNewtAppletBase.str2Bool(getParameter("gl_trace"), bool2);
/* 135 */       bool3 = JOGLNewtAppletBase.str2Bool(getParameter("gl_undecorated"), bool3);
/* 136 */       bool4 = JOGLNewtAppletBase.str2Bool(getParameter("gl_alwaysontop"), bool4);
/* 137 */       bool5 = JOGLNewtAppletBase.str2Bool(getParameter("gl_closeable"), bool5);
/* 138 */       bool6 = JOGLNewtAppletBase.str2Bool(getParameter("gl_opaque"), bool6);
/* 139 */       j = JOGLNewtAppletBase.str2Int(getParameter("gl_alpha"), j);
/* 140 */       k = JOGLNewtAppletBase.str2Int(getParameter("gl_multisamplebuffer"), k);
/* 141 */       this.glXd = JOGLNewtAppletBase.str2Int(getParameter("gl_dx"), this.glXd);
/* 142 */       this.glYd = JOGLNewtAppletBase.str2Int(getParameter("gl_dy"), this.glYd);
/* 143 */       this.glWidth = JOGLNewtAppletBase.str2Int(getParameter("gl_width"), this.glWidth);
/* 144 */       this.glHeight = JOGLNewtAppletBase.str2Int(getParameter("gl_height"), this.glHeight);
/* 145 */       bool7 = JOGLNewtAppletBase.str2Bool(getParameter("gl_nodefaultkeyListener"), bool7);
/* 146 */       bool8 = JOGLNewtAppletBase.str2Bool(getParameter("appletDebugTestBorder"), bool8);
/* 147 */     } catch (Exception exception) {
/* 148 */       exception.printStackTrace();
/*     */     } 
/* 150 */     if (null == str1) {
/* 151 */       throw new RuntimeException("No applet parameter 'gl_event_listener_class'");
/*     */     }
/* 153 */     boolean bool = (Integer.MAX_VALUE > this.glXd && Integer.MAX_VALUE > this.glYd && Integer.MAX_VALUE > this.glWidth && Integer.MAX_VALUE > this.glHeight) ? true : false;
/* 154 */     if (DEBUG) {
/* 155 */       System.err.println("JOGLNewtApplet1Run Configuration:");
/* 156 */       System.err.println("glStandalone: " + bool);
/* 157 */       if (bool) {
/* 158 */         System.err.println("pos-size: " + this.glXd + "/" + this.glYd + " " + this.glWidth + "x" + this.glHeight);
/*     */       }
/* 160 */       System.err.println("glEventListenerClazzName: " + str1);
/* 161 */       System.err.println("glProfileName: " + str2);
/* 162 */       System.err.println("glSwapInterval: " + i);
/* 163 */       System.err.println("glDebug: " + bool1);
/* 164 */       System.err.println("glTrace: " + bool2);
/* 165 */       System.err.println("glUndecorated: " + bool3);
/* 166 */       System.err.println("glAlwaysOnTop: " + bool4);
/* 167 */       System.err.println("glCloseable: " + bool5);
/* 168 */       System.err.println("glOpaque: " + bool6);
/* 169 */       System.err.println("glAlphaBits: " + j);
/* 170 */       System.err.println("glNumMultisampleBuffer: " + k);
/* 171 */       System.err.println("glNoDefaultKeyListener: " + bool7);
/*     */     } 
/*     */     
/* 174 */     this.base = new JOGLNewtAppletBase(str1, i, bool7, bool5, bool1, bool2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 182 */       GLCapabilities gLCapabilities = new GLCapabilities(GLProfile.get(str2));
/* 183 */       gLCapabilities.setAlphaBits(j);
/* 184 */       if (0 < k) {
/* 185 */         gLCapabilities.setSampleBuffers(true);
/* 186 */         gLCapabilities.setNumSamples(k);
/*     */       } 
/* 188 */       gLCapabilities.setBackgroundOpaque(bool6);
/* 189 */       this.glWindow = GLWindow.create((GLCapabilitiesImmutable)gLCapabilities);
/* 190 */       this.glWindow.setUpdateFPSFrames(300, System.err);
/* 191 */       this.glWindow.setUndecorated(bool3);
/* 192 */       this.glWindow.setAlwaysOnTop(bool4);
/* 193 */       this.glWindow.setDefaultCloseOperation(bool5 ? WindowClosingProtocol.WindowClosingMode.DISPOSE_ON_CLOSE : WindowClosingProtocol.WindowClosingMode.DO_NOTHING_ON_CLOSE);
/* 194 */       jOGLNewtApplet1Run.setLayout(new BorderLayout());
/* 195 */       if (bool8)
/* 196 */         AWTEDTExecutor.singleton.invoke(true, new Runnable() {
/*     */               public void run() {
/* 198 */                 container.add(new Button("North"), "North");
/* 199 */                 container.add(new Button("South"), "South");
/* 200 */                 container.add(new Button("East"), "East");
/* 201 */                 container.add(new Button("West"), "West");
/*     */               }
/*     */             }); 
/* 204 */       this.base.init(this.glWindow);
/* 205 */       if (this.base.isValid()) {
/* 206 */         GLEventListener gLEventListener = this.base.getGLEventListener();
/*     */         
/* 208 */         if (gLEventListener instanceof MouseListener) {
/* 209 */           addMouseListener((MouseListener)gLEventListener);
/*     */         }
/* 211 */         if (gLEventListener instanceof MouseMotionListener) {
/* 212 */           addMouseMotionListener((MouseMotionListener)gLEventListener);
/*     */         }
/* 214 */         if (gLEventListener instanceof KeyListener) {
/* 215 */           addKeyListener((KeyListener)gLEventListener);
/*     */         }
/*     */       } 
/* 218 */       if (!bool)
/* 219 */         AWTEDTExecutor.singleton.invoke(true, new Runnable() {
/*     */               public void run() {
/* 221 */                 JOGLNewtApplet1Run.this.newtCanvasAWT = new NewtCanvasAWT((Window)JOGLNewtApplet1Run.this.glWindow);
/* 222 */                 JOGLNewtApplet1Run.this.newtCanvasAWT.setSkipJAWTDestroy(true);
/* 223 */                 container.add((Component)JOGLNewtApplet1Run.this.newtCanvasAWT, "Center");
/* 224 */                 container.validate();
/*     */               }
/*     */             }); 
/* 227 */     } catch (Throwable throwable) {
/* 228 */       throw new RuntimeException(throwable);
/*     */     } 
/* 230 */     if (DEBUG)
/* 231 */       System.err.println("JOGLNewtApplet1Run.init() END - " + currentThreadName()); 
/*     */   }
/*     */   
/*     */   private static String currentThreadName() {
/* 235 */     return "[" + Thread.currentThread().getName() + ", isAWT-EDT " + EventQueue.isDispatchThread() + "]";
/*     */   }
/*     */   
/*     */   public void start() {
/* 239 */     if (DEBUG) {
/* 240 */       System.err.println("JOGLNewtApplet1Run.start() START (isVisible " + isVisible() + ", isDisplayable " + isDisplayable() + ") - " + currentThreadName());
/*     */     }
/* 242 */     final Point[] p0 = { null };
/* 243 */     AWTEDTExecutor.singleton.invoke(true, new Runnable() {
/*     */           public void run() {
/* 245 */             JOGLNewtApplet1Run.this.setVisible(true);
/* 246 */             p0[0] = JOGLNewtApplet1Run.this.getLocationOnScreen();
/* 247 */             if (null != JOGLNewtApplet1Run.this.newtCanvasAWT) {
/* 248 */               JOGLNewtApplet1Run.this.newtCanvasAWT.setFocusable(true);
/* 249 */               JOGLNewtApplet1Run.this.newtCanvasAWT.requestFocus();
/*     */             } 
/*     */           }
/*     */         });
/* 253 */     if (null == this.newtCanvasAWT) {
/* 254 */       this.glWindow.requestFocus();
/* 255 */       this.glWindow.setSize(this.glWidth, this.glHeight);
/* 256 */       this.glWindow.setPosition((arrayOfPoint[0]).x + this.glXd, (arrayOfPoint[0]).y + this.glYd);
/*     */     } 
/* 258 */     if (DEBUG) {
/* 259 */       Container container = this;
/* 260 */       while (null != container.getParent()) {
/* 261 */         container = container.getParent();
/*     */       }
/* 263 */       System.err.println("JOGLNewtApplet1Run start:");
/* 264 */       System.err.println("TopComponent: " + container.getLocation() + " rel, " + container.getLocationOnScreen() + " screen, visible " + container.isVisible() + ", " + container);
/* 265 */       System.err.println("Applet Pos: " + getLocation() + " rel, " + Arrays.toString((Object[])arrayOfPoint) + " screen, visible " + isVisible() + ", " + this);
/* 266 */       if (null != this.newtCanvasAWT) {
/* 267 */         System.err.println("NewtCanvasAWT Pos: " + this.newtCanvasAWT.getLocation() + " rel, " + this.newtCanvasAWT.getLocationOnScreen() + " screen, visible " + this.newtCanvasAWT.isVisible() + ", " + this.newtCanvasAWT);
/*     */       }
/* 269 */       System.err.println("GLWindow Pos: " + this.glWindow.getX() + "/" + this.glWindow.getY() + " rel, " + this.glWindow.getLocationOnScreen(null) + " screen");
/* 270 */       System.err.println("GLWindow: " + this.glWindow);
/*     */     } 
/* 272 */     this.base.start();
/* 273 */     if (null != this.newtCanvasAWT && this.newtCanvasAWT
/* 274 */       .isOffscreenLayerSurfaceEnabled() && 0 != (0x2 & 
/* 275 */       JAWTUtil.getOSXCALayerQuirks()))
/*     */     {
/* 277 */       AWTEDTExecutor.singleton.invoke(true, new Runnable() {
/*     */             public void run() {
/* 279 */               int i = JOGLNewtApplet1Run.this.newtCanvasAWT.getWidth();
/* 280 */               int j = JOGLNewtApplet1Run.this.newtCanvasAWT.getHeight();
/* 281 */               JOGLNewtApplet1Run.this.newtCanvasAWT.setSize(i + 1, j + 1);
/* 282 */               JOGLNewtApplet1Run.this.newtCanvasAWT.setSize(i, j);
/*     */             }
/*     */           }); } 
/* 285 */     if (DEBUG) {
/* 286 */       System.err.println("JOGLNewtApplet1Run.start() END - " + currentThreadName());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 292 */     if (DEBUG) {
/* 293 */       System.err.println("JOGLNewtApplet1Run.stop() START - " + currentThreadName());
/*     */     }
/* 295 */     this.base.stop();
/* 296 */     if (DEBUG) {
/* 297 */       System.err.println("JOGLNewtApplet1Run.stop() END - " + currentThreadName());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 303 */     if (DEBUG) {
/* 304 */       System.err.println("JOGLNewtApplet1Run.destroy() START - " + currentThreadName());
/*     */     }
/* 306 */     AWTEDTExecutor.singleton.invoke(true, new Runnable() {
/*     */           public void run() {
/* 308 */             JOGLNewtApplet1Run.this.glWindow.setVisible(false);
/* 309 */             if (null != JOGLNewtApplet1Run.this.newtCanvasAWT) {
/* 310 */               JOGLNewtApplet1Run.this.newtCanvasAWT.setSkipJAWTDestroy(false);
/* 311 */               JOGLNewtApplet1Run.this.remove((Component)JOGLNewtApplet1Run.this.newtCanvasAWT);
/* 312 */               JOGLNewtApplet1Run.this.newtCanvasAWT.destroy();
/*     */             }  }
/*     */         });
/* 315 */     this.base.destroy();
/* 316 */     this.base = null;
/* 317 */     this.glWindow = null;
/* 318 */     this.newtCanvasAWT = null;
/* 319 */     if (DEBUG)
/* 320 */       System.err.println("JOGLNewtApplet1Run.destroy() END - " + currentThreadName()); 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/newt/awt/applet/JOGLNewtApplet1Run.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */