/*     */ package com.jogamp.graph.geom;
/*     */ 
/*     */ import com.jogamp.opengl.math.Vec2f;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.Vert3fImmutable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Vertex
/*     */   implements Vert3fImmutable, Cloneable
/*     */ {
/*     */   private int id;
/*     */   private boolean onCurve;
/*  40 */   private final Vec3f coord = new Vec3f();
/*  41 */   private final Vec3f texCoord = new Vec3f();
/*     */   
/*     */   public Vertex() {
/*  44 */     this.id = Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   public Vertex(Vertex paramVertex) {
/*  48 */     this.id = Integer.MAX_VALUE;
/*  49 */     this.coord.set(paramVertex.getCoord());
/*  50 */     this.texCoord.set(paramVertex.getTexCoord());
/*  51 */     setOnCurve(paramVertex.isOnCurve());
/*     */   }
/*     */   
/*     */   public Vertex(int paramInt, boolean paramBoolean, Vec3f paramVec3f) {
/*  55 */     this.id = paramInt;
/*  56 */     this.onCurve = paramBoolean;
/*  57 */     this.texCoord.set(paramVec3f);
/*     */   }
/*     */   
/*     */   public Vertex(int paramInt, boolean paramBoolean, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  61 */     this.id = paramInt;
/*  62 */     this.onCurve = paramBoolean;
/*  63 */     this.texCoord.set(paramFloat1, paramFloat2, paramFloat3);
/*     */   }
/*     */   
/*     */   public Vertex(Vec3f paramVec3f, boolean paramBoolean) {
/*  67 */     this.id = Integer.MAX_VALUE;
/*  68 */     this.coord.set(paramVec3f);
/*  69 */     setOnCurve(paramBoolean);
/*     */   }
/*     */   
/*     */   public Vertex(Vec2f paramVec2f, boolean paramBoolean) {
/*  73 */     this.id = Integer.MAX_VALUE;
/*  74 */     this.coord.set(paramVec2f, 0.0F);
/*  75 */     setOnCurve(paramBoolean);
/*     */   }
/*     */   
/*     */   public Vertex(float paramFloat1, float paramFloat2, boolean paramBoolean) {
/*  79 */     this(paramFloat1, paramFloat2, 0.0F, paramBoolean);
/*     */   }
/*     */   
/*     */   public Vertex(float[] paramArrayOffloat, int paramInt1, int paramInt2, boolean paramBoolean) {
/*  83 */     this(paramArrayOffloat[paramInt1 + 0], paramArrayOffloat[paramInt1 + 1], (2 < paramInt2) ? paramArrayOffloat[paramInt1 + 2] : 0.0F, paramBoolean);
/*     */   }
/*     */   
/*     */   public Vertex(float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean) {
/*  87 */     this.id = Integer.MAX_VALUE;
/*  88 */     this.coord.set(paramFloat1, paramFloat2, paramFloat3);
/*  89 */     setOnCurve(paramBoolean);
/*     */   }
/*     */   
/*     */   public final void setCoord(Vec3f paramVec3f) {
/*  93 */     this.coord.set(paramVec3f);
/*     */   }
/*     */   
/*     */   public void setCoord(Vec2f paramVec2f) {
/*  97 */     this.coord.set(paramVec2f, 0.0F);
/*     */   }
/*     */   
/*     */   public final void setCoord(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 101 */     this.coord.set(paramFloat1, paramFloat2, paramFloat3);
/*     */   }
/*     */   
/*     */   public final void setCoord(float paramFloat1, float paramFloat2) {
/* 105 */     this.coord.set(paramFloat1, paramFloat2, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCoordCount() {
/* 110 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Vec3f getCoord() {
/* 115 */     return this.coord;
/*     */   }
/*     */   
/*     */   public final void setX(float paramFloat) {
/* 119 */     this.coord.setX(paramFloat);
/*     */   }
/*     */   
/*     */   public final void setY(float paramFloat) {
/* 123 */     this.coord.setY(paramFloat);
/*     */   }
/*     */   
/*     */   public final void setZ(float paramFloat) {
/* 127 */     this.coord.setZ(paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public final float x() {
/* 132 */     return this.coord.x();
/*     */   }
/*     */ 
/*     */   
/*     */   public final float y() {
/* 137 */     return this.coord.y();
/*     */   }
/*     */ 
/*     */   
/*     */   public final float z() {
/* 142 */     return this.coord.z();
/*     */   }
/*     */   
/*     */   public final boolean isOnCurve() {
/* 146 */     return this.onCurve;
/*     */   }
/*     */   
/*     */   public final void setOnCurve(boolean paramBoolean) {
/* 150 */     this.onCurve = paramBoolean;
/*     */   }
/*     */   
/*     */   public final int getId() {
/* 154 */     return this.id;
/*     */   }
/*     */   
/*     */   public final void setId(int paramInt) {
/* 158 */     this.id = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 167 */     if (paramObject == this) {
/* 168 */       return true;
/*     */     }
/* 170 */     if (null == paramObject || !(paramObject instanceof Vertex)) {
/* 171 */       return false;
/*     */     }
/* 173 */     Vertex vertex = (Vertex)paramObject;
/* 174 */     return (this == vertex || (
/* 175 */       isOnCurve() == vertex.isOnCurve() && 
/* 176 */       getTexCoord().isEqual(vertex.getTexCoord()) && 
/* 177 */       getCoord().isEqual(vertex.getCoord())));
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 182 */     throw new InternalError("hashCode not designed");
/*     */   }
/*     */   
/*     */   public final Vec3f getTexCoord() {
/* 186 */     return this.texCoord;
/*     */   }
/*     */   
/*     */   public final void setTexCoord(Vec3f paramVec3f) {
/* 190 */     this.texCoord.set(paramVec3f);
/*     */   }
/*     */   
/*     */   public final void setTexCoord(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 194 */     this.texCoord.set(paramFloat1, paramFloat2, paramFloat3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vertex clone() {
/* 202 */     return new Vertex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 207 */     return "[ID: " + this.id + ", onCurve: " + this.onCurve + ": p " + this.coord + ", t " + this.texCoord + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/Vertex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */