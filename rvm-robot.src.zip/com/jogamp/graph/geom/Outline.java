/*     */ package com.jogamp.graph.geom;
/*     */ 
/*     */ import com.jogamp.graph.geom.plane.AffineTransform;
/*     */ import com.jogamp.graph.geom.plane.Winding;
/*     */ import com.jogamp.opengl.math.FloatUtil;
/*     */ import com.jogamp.opengl.math.VectorUtil;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Outline
/*     */   implements Comparable<Outline>
/*     */ {
/*     */   private ArrayList<Vertex> vertices;
/*     */   private boolean closed;
/*     */   private final AABBox bbox;
/*     */   private boolean dirtyBBox;
/*     */   private Winding winding;
/*     */   private boolean dirtyWinding;
/*     */   
/*     */   public Outline() {
/*  66 */     this.vertices = new ArrayList<>(3);
/*  67 */     this.closed = false;
/*  68 */     this.bbox = new AABBox();
/*  69 */     this.dirtyBBox = false;
/*  70 */     this.winding = Winding.CCW;
/*  71 */     this.dirtyWinding = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Outline(Outline paramOutline) {
/*  78 */     int i = paramOutline.vertices.size();
/*  79 */     this.vertices = new ArrayList<>(i);
/*  80 */     this.winding = paramOutline.getWinding();
/*  81 */     this.dirtyWinding = false;
/*  82 */     for (byte b = 0; b < i; b++) {
/*  83 */       this.vertices.add(((Vertex)paramOutline.vertices.get(b)).clone());
/*     */     }
/*  85 */     this.closed = paramOutline.closed;
/*  86 */     this.bbox = new AABBox(paramOutline.bbox);
/*  87 */     this.dirtyBBox = paramOutline.dirtyBBox;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Outline(Outline paramOutline, Winding paramWinding) {
/*  99 */     int i = paramOutline.vertices.size();
/* 100 */     this.vertices = new ArrayList<>(i);
/* 101 */     Winding winding = paramOutline.getWinding();
/* 102 */     this.winding = winding;
/* 103 */     this.dirtyWinding = false;
/* 104 */     if (paramWinding != winding) {
/* 105 */       for (int j = i - 1; j >= 0; j--) {
/* 106 */         this.vertices.add(((Vertex)paramOutline.vertices.get(j)).clone());
/*     */       }
/* 108 */       this.winding = paramWinding;
/*     */     } else {
/* 110 */       for (byte b = 0; b < i; b++) {
/* 111 */         this.vertices.add(((Vertex)paramOutline.vertices.get(b)).clone());
/*     */       }
/*     */     } 
/* 114 */     this.closed = paramOutline.closed;
/* 115 */     this.bbox = new AABBox(paramOutline.bbox);
/* 116 */     this.dirtyBBox = paramOutline.dirtyBBox;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setWinding(Winding paramWinding) {
/* 127 */     Winding winding = getWinding();
/* 128 */     if (paramWinding != winding) {
/* 129 */       int i = this.vertices.size();
/* 130 */       ArrayList<Vertex> arrayList = new ArrayList(i);
/* 131 */       for (int j = i - 1; j >= 0; j--) {
/* 132 */         arrayList.add(this.vertices.get(j));
/*     */       }
/* 134 */       this.vertices = arrayList;
/* 135 */       this.winding = paramWinding;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Winding getWinding() {
/* 144 */     if (!this.dirtyWinding) {
/* 145 */       return this.winding;
/*     */     }
/* 147 */     int i = getVertexCount();
/* 148 */     if (3 > i) {
/* 149 */       this.winding = Winding.CCW;
/*     */     } else {
/* 151 */       this.winding = VectorUtil.getWinding(getVertices());
/*     */     } 
/* 153 */     this.dirtyWinding = false;
/* 154 */     return this.winding;
/*     */   }
/*     */   
/*     */   public final int getVertexCount() {
/* 158 */     return this.vertices.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addVertex(Vertex paramVertex) throws NullPointerException {
/* 167 */     addVertex(this.vertices.size(), paramVertex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addVertex(int paramInt, Vertex paramVertex) throws NullPointerException, IndexOutOfBoundsException {
/* 178 */     if (null == paramVertex) {
/* 179 */       throw new NullPointerException("vertex is null");
/*     */     }
/* 181 */     this.vertices.add(paramInt, paramVertex);
/* 182 */     if (!this.dirtyBBox) {
/* 183 */       this.bbox.resize(paramVertex.getCoord());
/*     */     }
/* 185 */     this.dirtyWinding = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVertex(int paramInt, Vertex paramVertex) throws NullPointerException, IndexOutOfBoundsException {
/* 197 */     if (null == paramVertex) {
/* 198 */       throw new NullPointerException("vertex is null");
/*     */     }
/* 200 */     this.vertices.set(paramInt, paramVertex);
/* 201 */     this.dirtyBBox = true;
/* 202 */     this.dirtyWinding = true;
/*     */   }
/*     */   
/*     */   public final Vertex getVertex(int paramInt) {
/* 206 */     return this.vertices.get(paramInt);
/*     */   }
/*     */   
/*     */   public int getVertexIndex(Vertex paramVertex) {
/* 210 */     return this.vertices.indexOf(paramVertex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Vertex removeVertex(int paramInt) throws IndexOutOfBoundsException {
/* 220 */     this.dirtyBBox = true;
/* 221 */     this.dirtyWinding = true;
/* 222 */     return this.vertices.remove(paramInt);
/*     */   }
/*     */   
/*     */   public final boolean isEmpty() {
/* 226 */     return (this.vertices.size() == 0);
/*     */   }
/*     */   
/*     */   public final Vertex getLastVertex() {
/* 230 */     if (isEmpty()) {
/* 231 */       return null;
/*     */     }
/* 233 */     return this.vertices.get(this.vertices.size() - 1);
/*     */   }
/*     */   
/*     */   public final ArrayList<Vertex> getVertices() {
/* 237 */     return this.vertices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVertices(ArrayList<Vertex> paramArrayList) {
/* 247 */     this.vertices = paramArrayList;
/* 248 */     validateBoundingBox();
/*     */   }
/*     */   
/*     */   public final boolean isClosed() {
/* 252 */     return this.closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean setClosed(boolean paramBoolean) {
/* 267 */     this.closed = true;
/* 268 */     if (!isEmpty()) {
/* 269 */       Vertex vertex1 = this.vertices.get(0);
/* 270 */       Vertex vertex2 = getLastVertex();
/* 271 */       if (!vertex1.getCoord().isEqual(vertex2.getCoord())) {
/* 272 */         if (paramBoolean) {
/* 273 */           this.vertices.add(vertex1.clone());
/*     */         } else {
/* 275 */           this.vertices.add(0, vertex2.clone());
/*     */         } 
/* 277 */         return true;
/*     */       } 
/*     */     } 
/* 280 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Outline transform(AffineTransform paramAffineTransform) {
/* 287 */     Outline outline = new Outline();
/* 288 */     int i = this.vertices.size();
/* 289 */     for (byte b = 0; b < i; b++) {
/* 290 */       Vertex vertex = this.vertices.get(b);
/* 291 */       outline.addVertex(paramAffineTransform.transform(vertex, new Vertex()));
/*     */     } 
/* 293 */     outline.closed = this.closed;
/* 294 */     return outline;
/*     */   }
/*     */   
/*     */   private final void validateBoundingBox() {
/* 298 */     this.dirtyBBox = false;
/* 299 */     this.bbox.reset();
/* 300 */     for (byte b = 0; b < this.vertices.size(); b++) {
/* 301 */       this.bbox.resize(((Vertex)this.vertices.get(b)).getCoord());
/*     */     }
/*     */   }
/*     */   
/*     */   public final AABBox getBounds() {
/* 306 */     if (this.dirtyBBox) {
/* 307 */       validateBoundingBox();
/*     */     }
/* 309 */     return this.bbox;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int compareTo(Outline paramOutline) {
/* 319 */     float f1 = getBounds().getSize();
/* 320 */     float f2 = paramOutline.getBounds().getSize();
/* 321 */     if (FloatUtil.isEqual(f1, f2, 1.1920929E-7F))
/* 322 */       return 0; 
/* 323 */     if (f1 < f2) {
/* 324 */       return -1;
/*     */     }
/* 326 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 336 */     if (paramObject == this) {
/* 337 */       return true;
/*     */     }
/* 339 */     if (null == paramObject || !(paramObject instanceof Outline)) {
/* 340 */       return false;
/*     */     }
/* 342 */     Outline outline = (Outline)paramObject;
/* 343 */     if (getVertexCount() != outline.getVertexCount()) {
/* 344 */       return false;
/*     */     }
/* 346 */     if (!getBounds().equals(outline.getBounds())) {
/* 347 */       return false;
/*     */     }
/* 349 */     for (int i = getVertexCount() - 1; i >= 0; i--) {
/* 350 */       if (!getVertex(i).equals(outline.getVertex(i))) {
/* 351 */         return false;
/*     */       }
/*     */     } 
/* 354 */     return true;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/* 358 */     throw new InternalError("hashCode not designed");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 363 */     return getClass().getName() + "@" + Integer.toHexString(super.hashCode());
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/Outline.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */