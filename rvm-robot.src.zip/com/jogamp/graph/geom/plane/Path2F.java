/*     */ package com.jogamp.graph.geom.plane;
/*     */ 
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import java.io.PrintStream;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Path2F
/*     */   implements Cloneable
/*     */ {
/*     */   static final String invalidWindingRuleValue = "Invalid winding rule value";
/*     */   static final String iteratorOutOfBounds = "Iterator out of bounds";
/*     */   private static final int BUFFER_SIZE = 10;
/*     */   private static final int BUFFER_CAPACITY = 10;
/*     */   private byte[] m_types;
/*     */   private float[] m_points;
/*     */   private int m_typeSize;
/*     */   private int m_pointSize;
/*     */   private WindingRule m_rule;
/*     */   
/*     */   public enum SegmentType
/*     */   {
/*  37 */     MOVETO(1),
/*  38 */     LINETO(1),
/*  39 */     QUADTO(2),
/*  40 */     CUBICTO(3),
/*  41 */     CLOSE(0);
/*     */ 
/*     */     
/*     */     public final int point_count;
/*     */ 
/*     */     
/*     */     public byte integer() {
/*  48 */       return (byte)ordinal();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static int getPointCount(int param1Int) {
/*  66 */       switch (param1Int) { case 0:
/*  67 */           return MOVETO.point_count;
/*  68 */         case 1: return LINETO.point_count;
/*  69 */         case 2: return QUADTO.point_count;
/*  70 */         case 3: return CUBICTO.point_count;
/*  71 */         case 4: return CLOSE.point_count; }
/*     */       
/*  73 */       throw new IllegalArgumentException("Unhandled Segment Type: " + param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     SegmentType(int param1Int1) {
/*  78 */       this.point_count = param1Int1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Iterator
/*     */   {
/*     */     private final Path2F p;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final AffineTransform t;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int typeIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int pointIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Iterator(Path2F param1Path2F) {
/* 147 */       this(param1Path2F, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator(Path2F param1Path2F, AffineTransform param1AffineTransform) {
/* 156 */       this.p = param1Path2F;
/* 157 */       this.t = param1AffineTransform;
/* 158 */       reset();
/*     */     }
/*     */     
/*     */     private void reset() {
/* 162 */       this.typeIndex = 0;
/* 163 */       this.pointIndex = 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public WindingRule getWindingRule() {
/* 168 */       return this.p.getWindingRule();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Winding getWinding() {
/* 176 */       return (area() >= 0.0F) ? Winding.CCW : Winding.CW;
/*     */     }
/*     */     
/*     */     public float[] points() {
/* 180 */       return this.p.m_points;
/*     */     }
/*     */     public int index() {
/* 183 */       return this.pointIndex;
/*     */     }
/*     */     public Path2F.SegmentType getType() {
/* 186 */       return Path2F.SegmentType.valueOf(this.p.m_types[this.typeIndex]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Path2F.SegmentType currentSegment(float[] param1ArrayOffloat) {
/* 199 */       if (!hasNext()) {
/* 200 */         throw new NoSuchElementException("Iterator out of bounds");
/*     */       }
/* 202 */       Path2F.SegmentType segmentType = getType();
/* 203 */       int i = segmentType.point_count;
/* 204 */       System.arraycopy(this.p.m_points, this.pointIndex, param1ArrayOffloat, 0, i * 2);
/* 205 */       if (this.t != null) {
/* 206 */         this.t.transform(param1ArrayOffloat, 0, param1ArrayOffloat, 0, i);
/*     */       }
/* 208 */       return segmentType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 213 */       return (this.typeIndex < this.p.m_typeSize);
/*     */     }
/*     */ 
/*     */     
/*     */     public Path2F.SegmentType next() {
/* 218 */       Path2F.SegmentType segmentType = getType();
/* 219 */       this.pointIndex += 2 * segmentType.point_count;
/* 220 */       this.typeIndex++;
/* 221 */       return segmentType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private float area() {
/*     */       // Byte code:
/*     */       //   0: fconst_0
/*     */       //   1: fstore_1
/*     */       //   2: aload_0
/*     */       //   3: invokevirtual points : ()[F
/*     */       //   6: astore_2
/*     */       //   7: iconst_2
/*     */       //   8: newarray float
/*     */       //   10: astore_3
/*     */       //   11: aload_0
/*     */       //   12: invokevirtual hasNext : ()Z
/*     */       //   15: ifeq -> 321
/*     */       //   18: aload_0
/*     */       //   19: invokevirtual index : ()I
/*     */       //   22: istore #4
/*     */       //   24: aload_0
/*     */       //   25: invokevirtual next : ()Lcom/jogamp/graph/geom/plane/Path2F$SegmentType;
/*     */       //   28: astore #5
/*     */       //   30: getstatic com/jogamp/graph/geom/plane/Path2F$1.$SwitchMap$com$jogamp$graph$geom$plane$Path2F$SegmentType : [I
/*     */       //   33: aload #5
/*     */       //   35: invokevirtual ordinal : ()I
/*     */       //   38: iaload
/*     */       //   39: tableswitch default -> 318, 1 -> 72, 2 -> 93, 3 -> 138, 4 -> 213, 5 -> 318
/*     */       //   72: aload_3
/*     */       //   73: iconst_0
/*     */       //   74: aload_2
/*     */       //   75: iload #4
/*     */       //   77: iconst_0
/*     */       //   78: iadd
/*     */       //   79: faload
/*     */       //   80: fastore
/*     */       //   81: aload_3
/*     */       //   82: iconst_1
/*     */       //   83: aload_2
/*     */       //   84: iload #4
/*     */       //   86: iconst_1
/*     */       //   87: iadd
/*     */       //   88: faload
/*     */       //   89: fastore
/*     */       //   90: goto -> 318
/*     */       //   93: fload_1
/*     */       //   94: aload_3
/*     */       //   95: iconst_0
/*     */       //   96: faload
/*     */       //   97: aload_2
/*     */       //   98: iload #4
/*     */       //   100: iconst_1
/*     */       //   101: iadd
/*     */       //   102: faload
/*     */       //   103: fmul
/*     */       //   104: aload_2
/*     */       //   105: iload #4
/*     */       //   107: iconst_0
/*     */       //   108: iadd
/*     */       //   109: faload
/*     */       //   110: aload_3
/*     */       //   111: iconst_1
/*     */       //   112: faload
/*     */       //   113: fmul
/*     */       //   114: fsub
/*     */       //   115: fadd
/*     */       //   116: fstore_1
/*     */       //   117: aload_3
/*     */       //   118: iconst_0
/*     */       //   119: aload_2
/*     */       //   120: iload #4
/*     */       //   122: iconst_0
/*     */       //   123: iadd
/*     */       //   124: faload
/*     */       //   125: fastore
/*     */       //   126: aload_3
/*     */       //   127: iconst_1
/*     */       //   128: aload_2
/*     */       //   129: iload #4
/*     */       //   131: iconst_1
/*     */       //   132: iadd
/*     */       //   133: faload
/*     */       //   134: fastore
/*     */       //   135: goto -> 318
/*     */       //   138: fload_1
/*     */       //   139: aload_3
/*     */       //   140: iconst_0
/*     */       //   141: faload
/*     */       //   142: aload_2
/*     */       //   143: iload #4
/*     */       //   145: iconst_1
/*     */       //   146: iadd
/*     */       //   147: faload
/*     */       //   148: fmul
/*     */       //   149: aload_2
/*     */       //   150: iload #4
/*     */       //   152: iconst_0
/*     */       //   153: iadd
/*     */       //   154: faload
/*     */       //   155: aload_3
/*     */       //   156: iconst_1
/*     */       //   157: faload
/*     */       //   158: fmul
/*     */       //   159: fsub
/*     */       //   160: fadd
/*     */       //   161: fstore_1
/*     */       //   162: fload_1
/*     */       //   163: aload_2
/*     */       //   164: iload #4
/*     */       //   166: iconst_0
/*     */       //   167: iadd
/*     */       //   168: faload
/*     */       //   169: aload_2
/*     */       //   170: iload #4
/*     */       //   172: iconst_3
/*     */       //   173: iadd
/*     */       //   174: faload
/*     */       //   175: fmul
/*     */       //   176: aload_2
/*     */       //   177: iload #4
/*     */       //   179: iconst_2
/*     */       //   180: iadd
/*     */       //   181: faload
/*     */       //   182: aload_2
/*     */       //   183: iload #4
/*     */       //   185: iconst_1
/*     */       //   186: iadd
/*     */       //   187: faload
/*     */       //   188: fmul
/*     */       //   189: fsub
/*     */       //   190: fadd
/*     */       //   191: fstore_1
/*     */       //   192: aload_3
/*     */       //   193: iconst_0
/*     */       //   194: aload_2
/*     */       //   195: iload #4
/*     */       //   197: iconst_2
/*     */       //   198: iadd
/*     */       //   199: faload
/*     */       //   200: fastore
/*     */       //   201: aload_3
/*     */       //   202: iconst_1
/*     */       //   203: aload_2
/*     */       //   204: iload #4
/*     */       //   206: iconst_3
/*     */       //   207: iadd
/*     */       //   208: faload
/*     */       //   209: fastore
/*     */       //   210: goto -> 318
/*     */       //   213: fload_1
/*     */       //   214: aload_3
/*     */       //   215: iconst_0
/*     */       //   216: faload
/*     */       //   217: aload_2
/*     */       //   218: iload #4
/*     */       //   220: iconst_1
/*     */       //   221: iadd
/*     */       //   222: faload
/*     */       //   223: fmul
/*     */       //   224: aload_2
/*     */       //   225: iload #4
/*     */       //   227: iconst_0
/*     */       //   228: iadd
/*     */       //   229: faload
/*     */       //   230: aload_3
/*     */       //   231: iconst_1
/*     */       //   232: faload
/*     */       //   233: fmul
/*     */       //   234: fsub
/*     */       //   235: fadd
/*     */       //   236: fstore_1
/*     */       //   237: fload_1
/*     */       //   238: aload_2
/*     */       //   239: iload #4
/*     */       //   241: iconst_0
/*     */       //   242: iadd
/*     */       //   243: faload
/*     */       //   244: aload_2
/*     */       //   245: iload #4
/*     */       //   247: iconst_3
/*     */       //   248: iadd
/*     */       //   249: faload
/*     */       //   250: fmul
/*     */       //   251: aload_2
/*     */       //   252: iload #4
/*     */       //   254: iconst_2
/*     */       //   255: iadd
/*     */       //   256: faload
/*     */       //   257: aload_2
/*     */       //   258: iload #4
/*     */       //   260: iconst_1
/*     */       //   261: iadd
/*     */       //   262: faload
/*     */       //   263: fmul
/*     */       //   264: fsub
/*     */       //   265: fadd
/*     */       //   266: fstore_1
/*     */       //   267: fload_1
/*     */       //   268: aload_2
/*     */       //   269: iload #4
/*     */       //   271: iconst_2
/*     */       //   272: iadd
/*     */       //   273: faload
/*     */       //   274: aload_2
/*     */       //   275: iload #4
/*     */       //   277: iconst_5
/*     */       //   278: iadd
/*     */       //   279: faload
/*     */       //   280: fmul
/*     */       //   281: aload_2
/*     */       //   282: iload #4
/*     */       //   284: iconst_4
/*     */       //   285: iadd
/*     */       //   286: faload
/*     */       //   287: aload_2
/*     */       //   288: iload #4
/*     */       //   290: iconst_3
/*     */       //   291: iadd
/*     */       //   292: faload
/*     */       //   293: fmul
/*     */       //   294: fsub
/*     */       //   295: fadd
/*     */       //   296: fstore_1
/*     */       //   297: aload_3
/*     */       //   298: iconst_0
/*     */       //   299: aload_2
/*     */       //   300: iload #4
/*     */       //   302: iconst_4
/*     */       //   303: iadd
/*     */       //   304: faload
/*     */       //   305: fastore
/*     */       //   306: aload_3
/*     */       //   307: iconst_1
/*     */       //   308: aload_2
/*     */       //   309: iload #4
/*     */       //   311: iconst_5
/*     */       //   312: iadd
/*     */       //   313: faload
/*     */       //   314: fastore
/*     */       //   315: goto -> 318
/*     */       //   318: goto -> 11
/*     */       //   321: aload_0
/*     */       //   322: invokespecial reset : ()V
/*     */       //   325: fload_1
/*     */       //   326: freturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #229	-> 0
/*     */       //   #230	-> 2
/*     */       //   #231	-> 7
/*     */       //   #232	-> 11
/*     */       //   #233	-> 18
/*     */       //   #234	-> 24
/*     */       //   #235	-> 30
/*     */       //   #237	-> 72
/*     */       //   #238	-> 81
/*     */       //   #239	-> 90
/*     */       //   #241	-> 93
/*     */       //   #242	-> 117
/*     */       //   #243	-> 126
/*     */       //   #244	-> 135
/*     */       //   #246	-> 138
/*     */       //   #247	-> 162
/*     */       //   #248	-> 192
/*     */       //   #249	-> 201
/*     */       //   #250	-> 210
/*     */       //   #252	-> 213
/*     */       //   #253	-> 237
/*     */       //   #254	-> 267
/*     */       //   #255	-> 297
/*     */       //   #256	-> 306
/*     */       //   #257	-> 315
/*     */       //   #261	-> 318
/*     */       //   #262	-> 321
/*     */       //   #263	-> 325
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path2F() {
/* 268 */     this(WindingRule.NON_ZERO, 10, 10);
/*     */   }
/*     */   
/*     */   public Path2F(WindingRule paramWindingRule) {
/* 272 */     this(paramWindingRule, 10, 10);
/*     */   }
/*     */   
/*     */   public Path2F(WindingRule paramWindingRule, int paramInt) {
/* 276 */     this(paramWindingRule, paramInt, paramInt);
/*     */   }
/*     */   
/*     */   public Path2F(WindingRule paramWindingRule, int paramInt1, int paramInt2) {
/* 280 */     setWindingRule(paramWindingRule);
/* 281 */     this.m_types = new byte[paramInt1];
/* 282 */     this.m_points = new float[paramInt2 * 2];
/*     */   }
/*     */   
/*     */   public Path2F(Path2F paramPath2F) {
/* 286 */     this(WindingRule.NON_ZERO, 10);
/* 287 */     Iterator iterator = paramPath2F.iterator(null);
/* 288 */     setWindingRule(iterator.getWindingRule());
/* 289 */     append(iterator, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWindingRule(WindingRule paramWindingRule) {
/* 294 */     this.m_rule = paramWindingRule;
/*     */   }
/*     */ 
/*     */   
/*     */   public WindingRule getWindingRule() {
/* 299 */     return this.m_rule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkBuf(int paramInt, boolean paramBoolean) {
/* 307 */     if (paramBoolean && this.m_typeSize == 0) {
/* 308 */       throw new IllegalPathStateException("First segment should be SEG_MOVETO type");
/*     */     }
/* 310 */     if (this.m_typeSize == this.m_types.length) {
/* 311 */       byte[] arrayOfByte = new byte[this.m_typeSize + 10];
/* 312 */       System.arraycopy(this.m_types, 0, arrayOfByte, 0, this.m_typeSize);
/* 313 */       this.m_types = arrayOfByte;
/*     */     } 
/* 315 */     if (this.m_pointSize + paramInt > this.m_points.length) {
/* 316 */       float[] arrayOfFloat = new float[this.m_pointSize + Math.max(20, paramInt)];
/* 317 */       System.arraycopy(this.m_points, 0, arrayOfFloat, 0, this.m_pointSize);
/* 318 */       this.m_points = arrayOfFloat;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void moveTo(float paramFloat1, float paramFloat2) {
/* 328 */     if (this.m_typeSize > 0 && this.m_types[this.m_typeSize - 1] == SegmentType.MOVETO.integer()) {
/* 329 */       this.m_points[this.m_pointSize - 2] = paramFloat1;
/* 330 */       this.m_points[this.m_pointSize - 1] = paramFloat2;
/*     */     } else {
/* 332 */       checkBuf(2, false);
/* 333 */       this.m_types[this.m_typeSize++] = SegmentType.MOVETO.integer();
/* 334 */       this.m_points[this.m_pointSize++] = paramFloat1;
/* 335 */       this.m_points[this.m_pointSize++] = paramFloat2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lineTo(float paramFloat1, float paramFloat2) {
/* 345 */     checkBuf(2, true);
/* 346 */     this.m_types[this.m_typeSize++] = SegmentType.LINETO.integer();
/* 347 */     this.m_points[this.m_pointSize++] = paramFloat1;
/* 348 */     this.m_points[this.m_pointSize++] = paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quadTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 359 */     checkBuf(4, true);
/* 360 */     this.m_types[this.m_typeSize++] = SegmentType.QUADTO.integer();
/* 361 */     this.m_points[this.m_pointSize++] = paramFloat1;
/* 362 */     this.m_points[this.m_pointSize++] = paramFloat2;
/* 363 */     this.m_points[this.m_pointSize++] = paramFloat3;
/* 364 */     this.m_points[this.m_pointSize++] = paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cubicTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 377 */     checkBuf(6, true);
/* 378 */     this.m_types[this.m_typeSize++] = SegmentType.CUBICTO.integer();
/* 379 */     this.m_points[this.m_pointSize++] = paramFloat1;
/* 380 */     this.m_points[this.m_pointSize++] = paramFloat2;
/* 381 */     this.m_points[this.m_pointSize++] = paramFloat3;
/* 382 */     this.m_points[this.m_pointSize++] = paramFloat4;
/* 383 */     this.m_points[this.m_pointSize++] = paramFloat5;
/* 384 */     this.m_points[this.m_pointSize++] = paramFloat6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closePath() {
/* 391 */     if (!isClosed()) {
/* 392 */       checkBuf(0, true);
/* 393 */       this.m_types[this.m_typeSize++] = SegmentType.CLOSE.integer();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int size() {
/* 398 */     return this.m_typeSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isClosed() {
/* 405 */     return (this.m_typeSize > 0 && this.m_types[this.m_typeSize - 1] == SegmentType.CLOSE.integer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Winding getWinding() {
/* 414 */     return iterator(null).getWinding();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 419 */     return "[size " + size() + ", closed " + isClosed() + ", winding[rule " + getWindingRule() + ", " + getWinding() + "]]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(Path2F paramPath2F, boolean paramBoolean) {
/* 428 */     append(paramPath2F.iterator(null), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(Iterator paramIterator, boolean paramBoolean) {
/* 437 */     float[] arrayOfFloat = paramIterator.points();
/* 438 */     while (paramIterator.hasNext()) {
/* 439 */       int i = paramIterator.index();
/* 440 */       SegmentType segmentType = paramIterator.next();
/* 441 */       switch (segmentType) {
/*     */         case MOVETO:
/* 443 */           if (!paramBoolean || 0 == this.m_typeSize) {
/* 444 */             moveTo(arrayOfFloat[i + 0], arrayOfFloat[i + 1]);
/*     */             break;
/*     */           } 
/* 447 */           if (this.m_types[this.m_typeSize - 1] != SegmentType.CLOSE.integer() && this.m_points[this.m_pointSize - 2] == arrayOfFloat[i + 0] && this.m_points[this.m_pointSize - 1] == arrayOfFloat[i + 1]) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case LINETO:
/* 456 */           lineTo(arrayOfFloat[i + 0], arrayOfFloat[i + 1]);
/*     */           break;
/*     */         case QUADTO:
/* 459 */           quadTo(arrayOfFloat[i + 0], arrayOfFloat[i + 1], arrayOfFloat[i + 2], arrayOfFloat[i + 3]);
/*     */           break;
/*     */         case CUBICTO:
/* 462 */           cubicTo(arrayOfFloat[i + 0], arrayOfFloat[i + 1], arrayOfFloat[i + 2], arrayOfFloat[i + 3], arrayOfFloat[i + 4], arrayOfFloat[i + 5]);
/*     */           break;
/*     */         case CLOSE:
/* 465 */           closePath();
/*     */           break;
/*     */       } 
/* 468 */       paramBoolean = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void printSegments(PrintStream paramPrintStream) {
/* 473 */     Iterator iterator = iterator();
/* 474 */     float[] arrayOfFloat = iterator.points();
/* 475 */     byte b = 0;
/* 476 */     while (iterator.hasNext()) {
/* 477 */       int i = iterator.index();
/* 478 */       SegmentType segmentType = iterator.next();
/* 479 */       switch (segmentType) {
/*     */         case MOVETO:
/* 481 */           paramPrintStream.printf("%2d: moveTo(%.4f/%.4f)%n", new Object[] { Integer.valueOf(b), Float.valueOf(arrayOfFloat[i + 0]), Float.valueOf(arrayOfFloat[i + 1]) });
/*     */           break;
/*     */         case LINETO:
/* 484 */           paramPrintStream.printf("%2d: lineTo(%.4f/%.4f)%n", new Object[] { Integer.valueOf(b), Float.valueOf(arrayOfFloat[i + 0]), Float.valueOf(arrayOfFloat[i + 1]) });
/*     */           break;
/*     */         case QUADTO:
/* 487 */           paramPrintStream.printf("%2d: quadTo(%.4f/%.4f, %.4f/%.4f)%n", new Object[] { Integer.valueOf(b), Float.valueOf(arrayOfFloat[i + 0]), Float.valueOf(arrayOfFloat[i + 1]), Float.valueOf(arrayOfFloat[i + 2]), Float.valueOf(arrayOfFloat[i + 3]) });
/*     */           break;
/*     */         case CUBICTO:
/* 490 */           paramPrintStream.printf("%2d: cubicTo(%.4f/%.4f, %.4f/%.4f, %.4f/%.4f)%n", new Object[] { Integer.valueOf(b), Float.valueOf(arrayOfFloat[i + 0]), Float.valueOf(arrayOfFloat[i + 1]), Float.valueOf(arrayOfFloat[i + 2]), Float.valueOf(arrayOfFloat[i + 3]), Float.valueOf(arrayOfFloat[i + 4]), Float.valueOf(arrayOfFloat[i + 5]) });
/*     */           break;
/*     */         case CLOSE:
/* 493 */           paramPrintStream.printf("%2d: closePath()%n", new Object[] { Integer.valueOf(b) });
/*     */           break;
/*     */       } 
/* 496 */       b++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reset() {
/* 501 */     this.m_typeSize = 0;
/* 502 */     this.m_pointSize = 0;
/*     */   }
/*     */   
/*     */   public void transform(AffineTransform paramAffineTransform) {
/* 506 */     paramAffineTransform.transform(this.m_points, 0, this.m_points, 0, this.m_pointSize / 2);
/*     */   }
/*     */   
/*     */   public Path2F createTransformedShape(AffineTransform paramAffineTransform) {
/* 510 */     Path2F path2F = (Path2F)clone();
/* 511 */     if (paramAffineTransform != null) {
/* 512 */       path2F.transform(paramAffineTransform);
/*     */     }
/* 514 */     return path2F; } public final synchronized AABBox getBounds2D() {
/*     */     float f1;
/*     */     float f2;
/*     */     float f3;
/*     */     float f4;
/* 519 */     if (this.m_pointSize == 0) {
/* 520 */       f1 = f2 = f3 = f4 = 0.0F;
/*     */     } else {
/* 522 */       int i = this.m_pointSize - 1;
/* 523 */       f2 = f4 = this.m_points[i--];
/* 524 */       f1 = f3 = this.m_points[i--];
/* 525 */       while (i > 0) {
/* 526 */         float f5 = this.m_points[i--];
/* 527 */         float f6 = this.m_points[i--];
/* 528 */         if (f6 < f1) {
/* 529 */           f1 = f6;
/*     */         }
/* 531 */         else if (f6 > f3) {
/* 532 */           f3 = f6;
/*     */         } 
/* 534 */         if (f5 < f2) {
/* 535 */           f2 = f5; continue;
/*     */         } 
/* 537 */         if (f5 > f4) {
/* 538 */           f4 = f5;
/*     */         }
/*     */       } 
/*     */     } 
/* 542 */     return new AABBox(f1, f2, 0.0F, f3, f4, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isInside(int paramInt) {
/* 551 */     if (this.m_rule == WindingRule.NON_ZERO) {
/* 552 */       return Crossing2F.isInsideNonZero(paramInt);
/*     */     }
/* 554 */     return Crossing2F.isInsideEvenOdd(paramInt);
/*     */   }
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 558 */     return isInside(Crossing2F.crossShape(this, paramFloat1, paramFloat2));
/*     */   }
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 562 */     int i = Crossing2F.intersectShape(this, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 563 */     return (i != 255 && isInside(i));
/*     */   }
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 567 */     int i = Crossing2F.intersectShape(this, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 568 */     return (i == 255 || isInside(i));
/*     */   }
/*     */   
/*     */   public boolean contains(AABBox paramAABBox) {
/* 572 */     return contains(paramAABBox.getMinX(), paramAABBox.getMinY(), paramAABBox.getWidth(), paramAABBox.getHeight());
/*     */   }
/*     */   
/*     */   public boolean intersects(AABBox paramAABBox) {
/* 576 */     return intersects(paramAABBox.getMinX(), paramAABBox.getMinY(), paramAABBox.getWidth(), paramAABBox.getHeight());
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/* 580 */     return new Iterator(this);
/*     */   }
/*     */   
/*     */   public Iterator iterator(AffineTransform paramAffineTransform) {
/* 584 */     return new Iterator(this, paramAffineTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 594 */       Path2F path2F = (Path2F)super.clone();
/* 595 */       path2F.m_types = (byte[])this.m_types.clone();
/* 596 */       path2F.m_points = (float[])this.m_points.clone();
/* 597 */       return path2F;
/* 598 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/* 599 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/plane/Path2F.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */