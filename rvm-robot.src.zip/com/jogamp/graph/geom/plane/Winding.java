/*    */ package com.jogamp.graph.geom.plane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Winding
/*    */ {
/*  8 */   CW(-1),
/*    */   
/* 10 */   CCW(1);
/*    */   
/*    */   public final int dir;
/*    */ 
/*    */   
/*    */   Winding(int paramInt1) {
/* 16 */     this.dir = paramInt1;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/plane/Winding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */