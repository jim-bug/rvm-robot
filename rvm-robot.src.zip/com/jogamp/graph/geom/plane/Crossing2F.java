/*     */ package com.jogamp.graph.geom.plane;
/*     */ 
/*     */ import com.jogamp.opengl.math.FloatUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Crossing2F
/*     */ {
/*     */   static final float DELTA = 1.0E-5F;
/*     */   static final float ROOT_DELTA = 1.0E-10F;
/*     */   public static final int CROSSING = 255;
/*     */   static final int UNKNOWN = 254;
/*     */   
/*     */   public static int solveQuad(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/*  53 */     float f1 = paramArrayOffloat1[2];
/*  54 */     float f2 = paramArrayOffloat1[1];
/*  55 */     float f3 = paramArrayOffloat1[0];
/*  56 */     byte b = 0;
/*  57 */     if (f1 == 0.0D) {
/*  58 */       if (f2 == 0.0D) {
/*  59 */         return -1;
/*     */       }
/*  61 */       paramArrayOffloat2[b++] = -f3 / f2;
/*     */     } else {
/*  63 */       float f = f2 * f2 - 4.0F * f1 * f3;
/*     */       
/*  65 */       if (f < 0.0D) {
/*  66 */         return 0;
/*     */       }
/*  68 */       f = FloatUtil.sqrt(f);
/*  69 */       paramArrayOffloat2[b++] = (-f2 + f) / f1 * 2.0F;
/*     */       
/*  71 */       if (f != 0.0D) {
/*  72 */         paramArrayOffloat2[b++] = (-f2 - f) / f1 * 2.0F;
/*     */       }
/*     */     } 
/*  75 */     return fixRoots(paramArrayOffloat2, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int solveCubic(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/*  85 */     float f1 = paramArrayOffloat1[3];
/*  86 */     if (f1 == 0.0F) {
/*  87 */       return solveQuad(paramArrayOffloat1, paramArrayOffloat2);
/*     */     }
/*  89 */     float f2 = paramArrayOffloat1[2] / f1;
/*  90 */     float f3 = paramArrayOffloat1[1] / f1;
/*  91 */     float f4 = paramArrayOffloat1[0] / f1;
/*  92 */     byte b = 0;
/*     */     
/*  94 */     float f5 = (f2 * f2 - 3.0F * f3) / 9.0F;
/*  95 */     float f6 = (2.0F * f2 * f2 * f2 - 9.0F * f2 * f3 + 27.0F * f4) / 54.0F;
/*  96 */     float f7 = f5 * f5 * f5;
/*  97 */     float f8 = f6 * f6;
/*  98 */     float f9 = -f2 / 3.0F;
/*     */     
/* 100 */     if (f8 < f7) {
/* 101 */       float f10 = FloatUtil.acos(f6 / FloatUtil.sqrt(f7)) / 3.0F;
/*     */       
/* 103 */       float f11 = -2.0F * FloatUtil.sqrt(f5);
/* 104 */       paramArrayOffloat2[b++] = f11 * FloatUtil.cos(f10) + f9;
/* 105 */       paramArrayOffloat2[b++] = f11 * FloatUtil.cos(f10 + 2.0943952F) + f9;
/* 106 */       paramArrayOffloat2[b++] = f11 * FloatUtil.cos(f10 - 2.0943952F) + f9;
/*     */     } else {
/*     */       
/* 109 */       float f = FloatUtil.pow(FloatUtil.abs(f6) + FloatUtil.sqrt(f8 - f7), 0.33333334F);
/* 110 */       if (f6 > 0.0D) {
/* 111 */         f = -f;
/*     */       }
/*     */       
/* 114 */       if (-1.0E-10F < f && f < 1.0E-10F) {
/* 115 */         paramArrayOffloat2[b++] = f9;
/*     */       } else {
/* 117 */         float f10 = f5 / f;
/* 118 */         paramArrayOffloat2[b++] = f + f10 + f9;
/*     */         
/* 120 */         float f11 = f8 - f7;
/* 121 */         if (-1.0E-10F < f11 && f11 < 1.0E-10F) {
/* 122 */           paramArrayOffloat2[b++] = -(f + f10) / 2.0F + f9;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     return fixRoots(paramArrayOffloat2, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int fixRoots(float[] paramArrayOffloat, int paramInt) {
/* 137 */     byte b1 = 0;
/* 138 */     for (byte b2 = 0; b2 < paramInt; b2++) {
/*     */       
/* 140 */       int i = b2 + 1; while (true) { if (i < paramInt) {
/* 141 */           if (isZero(paramArrayOffloat[b2] - paramArrayOffloat[i]))
/*     */             break;  i++;
/*     */           continue;
/*     */         } 
/* 145 */         paramArrayOffloat[b1++] = paramArrayOffloat[b2]; break; }
/*     */     
/*     */     } 
/* 148 */     return b1;
/*     */   }
/*     */   public static class QuadCurve { float ax;
/*     */     float ay;
/*     */     float bx;
/*     */     float by;
/*     */     float Ax;
/*     */     float Ay;
/*     */     float Bx;
/*     */     float By;
/*     */     
/*     */     public QuadCurve(float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
/* 160 */       this.ax = param1Float5 - param1Float1;
/* 161 */       this.ay = param1Float6 - param1Float2;
/* 162 */       this.bx = param1Float3 - param1Float1;
/* 163 */       this.by = param1Float4 - param1Float2;
/*     */       
/* 165 */       this.Bx = this.bx + this.bx;
/* 166 */       this.Ax = this.ax - this.Bx;
/*     */       
/* 168 */       this.By = this.by + this.by;
/* 169 */       this.Ay = this.ay - this.By;
/*     */     }
/*     */     
/*     */     int cross(float[] param1ArrayOffloat, int param1Int, float param1Float1, float param1Float2) {
/* 173 */       int i = 0;
/*     */       
/* 175 */       for (byte b = 0; b < param1Int; b++) {
/* 176 */         float f = param1ArrayOffloat[b];
/*     */ 
/*     */         
/* 179 */         if (f >= -1.0E-5F && f <= 1.00001F)
/*     */         {
/*     */ 
/*     */           
/* 183 */           if (f < 1.0E-5F) {
/* 184 */             if (param1Float1 < 0.0D && ((this.bx != 0.0D) ? this.bx : (this.ax - this.bx)) < 0.0D) {
/* 185 */               i--;
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 190 */           else if (f > 0.99999F) {
/*     */             
/* 192 */             if (param1Float1 < this.ay && ((this.ax != this.bx) ? (this.ax - this.bx) : this.bx) > 0.0D) {
/* 193 */               i++;
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/* 198 */             float f1 = f * (f * this.Ay + this.By);
/*     */             
/* 200 */             if (f1 > param1Float2) {
/* 201 */               float f2 = f * this.Ax + this.bx;
/*     */               
/* 203 */               if (f2 <= -1.0E-5F || f2 >= 1.0E-5F)
/*     */               {
/*     */                 
/* 206 */                 i += (f2 > 0.0D) ? 1 : -1; } 
/*     */             } 
/*     */           }  } 
/*     */       } 
/* 210 */       return i;
/*     */     }
/*     */     
/*     */     int solvePoint(float[] param1ArrayOffloat, float param1Float) {
/* 214 */       float[] arrayOfFloat = { -param1Float, this.Bx, this.Ax };
/* 215 */       return Crossing2F.solveQuad(arrayOfFloat, param1ArrayOffloat);
/*     */     }
/*     */     
/*     */     int solveExtrem(float[] param1ArrayOffloat) {
/* 219 */       byte b = 0;
/* 220 */       if (this.Ax != 0.0D) {
/* 221 */         param1ArrayOffloat[b++] = -this.Bx / (this.Ax + this.Ax);
/*     */       }
/* 223 */       if (this.Ay != 0.0D) {
/* 224 */         param1ArrayOffloat[b++] = -this.By / (this.Ay + this.Ay);
/*     */       }
/* 226 */       return b;
/*     */     }
/*     */     
/*     */     int addBound(float[] param1ArrayOffloat1, int param1Int1, float[] param1ArrayOffloat2, int param1Int2, float param1Float1, float param1Float2, boolean param1Boolean, int param1Int3) {
/* 230 */       for (byte b = 0; b < param1Int2; b++) {
/* 231 */         float f = param1ArrayOffloat2[b];
/* 232 */         if (f > -1.0E-5F && f < 1.00001F) {
/* 233 */           float f1 = f * (f * this.Ax + this.Bx);
/* 234 */           if (param1Float1 <= f1 && f1 <= param1Float2) {
/* 235 */             param1ArrayOffloat1[param1Int1++] = f;
/* 236 */             param1ArrayOffloat1[param1Int1++] = f1;
/* 237 */             param1ArrayOffloat1[param1Int1++] = f * (f * this.Ay + this.By);
/* 238 */             param1ArrayOffloat1[param1Int1++] = param1Int3;
/* 239 */             if (param1Boolean) {
/* 240 */               param1Int3++;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 245 */       return param1Int1;
/*     */     } }
/*     */ 
/*     */   
/*     */   public static class CubicCurve
/*     */   {
/*     */     float ax;
/*     */     float ay;
/*     */     float bx;
/*     */     float by;
/*     */     float cx;
/*     */     float cy;
/*     */     float Ax;
/*     */     
/*     */     public CubicCurve(float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, float param1Float8) {
/* 260 */       this.ax = param1Float7 - param1Float1;
/* 261 */       this.ay = param1Float8 - param1Float2;
/* 262 */       this.bx = param1Float3 - param1Float1;
/* 263 */       this.by = param1Float4 - param1Float2;
/* 264 */       this.cx = param1Float5 - param1Float1;
/* 265 */       this.cy = param1Float6 - param1Float2;
/*     */       
/* 267 */       this.Cx = this.bx + this.bx + this.bx;
/* 268 */       this.Bx = this.cx + this.cx + this.cx - this.Cx - this.Cx;
/* 269 */       this.Ax = this.ax - this.Bx - this.Cx;
/*     */       
/* 271 */       this.Cy = this.by + this.by + this.by;
/* 272 */       this.By = this.cy + this.cy + this.cy - this.Cy - this.Cy;
/* 273 */       this.Ay = this.ay - this.By - this.Cy;
/*     */       
/* 275 */       this.Ax3 = this.Ax + this.Ax + this.Ax;
/* 276 */       this.Bx2 = this.Bx + this.Bx;
/*     */     }
/*     */     float Ay; float Bx; float By; float Cx; float Cy; float Ax3; float Bx2;
/*     */     int cross(float[] param1ArrayOffloat, int param1Int, float param1Float1, float param1Float2) {
/* 280 */       int i = 0;
/* 281 */       for (byte b = 0; b < param1Int; b++) {
/* 282 */         float f1 = param1ArrayOffloat[b];
/*     */ 
/*     */         
/* 285 */         if (f1 < -1.0E-5F || f1 > 1.00001F) {
/*     */           continue;
/*     */         }
/*     */         
/* 289 */         if (f1 < 1.0E-5F) {
/*     */           
/* 291 */           if (param1Float1 < 0.0D) if (((this.bx != 0.0D) ? this.bx : ((this.cx != this.bx) ? (this.cx - this.bx) : (this.ax - this.cx))) < 0.0D) {
/* 292 */               i--;
/*     */             }
/*     */           
/*     */           continue;
/*     */         } 
/* 297 */         if (f1 > 0.99999F) {
/* 298 */           if (param1Float1 < this.ay) if (((this.ax != this.cx) ? (this.ax - this.cx) : ((this.cx != this.bx) ? (this.cx - this.bx) : this.bx)) > 0.0D) {
/* 299 */               i++;
/*     */             }
/*     */           
/*     */           continue;
/*     */         } 
/* 304 */         float f2 = f1 * (f1 * (f1 * this.Ay + this.By) + this.Cy);
/*     */         
/* 306 */         if (f2 > param1Float2) {
/* 307 */           float f = f1 * (f1 * this.Ax3 + this.Bx2) + this.Cx;
/*     */           
/* 309 */           if (f > -1.0E-5F && f < 1.0E-5F) {
/* 310 */             f = f1 * (this.Ax3 + this.Ax3) + this.Bx2;
/*     */             
/* 312 */             if (f < -1.0E-5F || f > 1.0E-5F) {
/*     */               continue;
/*     */             }
/*     */             
/* 316 */             f = this.ax;
/*     */           } 
/* 318 */           i += (f > 0.0D) ? 1 : -1;
/*     */         } 
/*     */         continue;
/*     */       } 
/* 322 */       return i;
/*     */     }
/*     */     
/*     */     int solvePoint(float[] param1ArrayOffloat, float param1Float) {
/* 326 */       float[] arrayOfFloat = { -param1Float, this.Cx, this.Bx, this.Ax };
/* 327 */       return Crossing2F.solveCubic(arrayOfFloat, param1ArrayOffloat);
/*     */     }
/*     */     
/*     */     int solveExtremX(float[] param1ArrayOffloat) {
/* 331 */       float[] arrayOfFloat = { this.Cx, this.Bx2, this.Ax3 };
/* 332 */       return Crossing2F.solveQuad(arrayOfFloat, param1ArrayOffloat);
/*     */     }
/*     */     
/*     */     int solveExtremY(float[] param1ArrayOffloat) {
/* 336 */       float[] arrayOfFloat = { this.Cy, this.By + this.By, this.Ay + this.Ay + this.Ay };
/* 337 */       return Crossing2F.solveQuad(arrayOfFloat, param1ArrayOffloat);
/*     */     }
/*     */     
/*     */     int addBound(float[] param1ArrayOffloat1, int param1Int1, float[] param1ArrayOffloat2, int param1Int2, float param1Float1, float param1Float2, boolean param1Boolean, int param1Int3) {
/* 341 */       for (byte b = 0; b < param1Int2; b++) {
/* 342 */         float f = param1ArrayOffloat2[b];
/* 343 */         if (f > -1.0E-5F && f < 1.00001F) {
/* 344 */           float f1 = f * (f * (f * this.Ax + this.Bx) + this.Cx);
/* 345 */           if (param1Float1 <= f1 && f1 <= param1Float2) {
/* 346 */             param1ArrayOffloat1[param1Int1++] = f;
/* 347 */             param1ArrayOffloat1[param1Int1++] = f1;
/* 348 */             param1ArrayOffloat1[param1Int1++] = f * (f * (f * this.Ay + this.By) + this.Cy);
/* 349 */             param1ArrayOffloat1[param1Int1++] = param1Int3;
/* 350 */             if (param1Boolean) {
/* 351 */               param1Int3++;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 356 */       return param1Int1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int crossLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 367 */     if ((paramFloat5 < paramFloat1 && paramFloat5 < paramFloat3) || (paramFloat5 > paramFloat1 && paramFloat5 > paramFloat3) || (paramFloat6 > paramFloat2 && paramFloat6 > paramFloat4) || paramFloat1 == paramFloat3)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 372 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 376 */     if (paramFloat6 >= paramFloat2 || paramFloat6 >= paramFloat4)
/*     */     {
/*     */       
/* 379 */       if ((paramFloat4 - paramFloat2) * (paramFloat5 - paramFloat1) / (paramFloat3 - paramFloat1) <= paramFloat6 - paramFloat2)
/*     */       {
/* 381 */         return 0;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 386 */     if (paramFloat5 == paramFloat1) {
/* 387 */       return (paramFloat1 < paramFloat3) ? 0 : -1;
/*     */     }
/*     */ 
/*     */     
/* 391 */     if (paramFloat5 == paramFloat3) {
/* 392 */       return (paramFloat1 < paramFloat3) ? 1 : 0;
/*     */     }
/*     */ 
/*     */     
/* 396 */     return (paramFloat1 < paramFloat3) ? 1 : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int crossQuad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/* 405 */     if ((paramFloat7 < paramFloat1 && paramFloat7 < paramFloat3 && paramFloat7 < paramFloat5) || (paramFloat7 > paramFloat1 && paramFloat7 > paramFloat3 && paramFloat7 > paramFloat5) || (paramFloat8 > paramFloat2 && paramFloat8 > paramFloat4 && paramFloat8 > paramFloat6) || (paramFloat1 == paramFloat3 && paramFloat3 == paramFloat5))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 410 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 414 */     if (paramFloat8 < paramFloat2 && paramFloat8 < paramFloat4 && paramFloat8 < paramFloat6 && paramFloat7 != paramFloat1 && paramFloat7 != paramFloat5) {
/* 415 */       if (paramFloat1 < paramFloat5) {
/* 416 */         return (paramFloat1 < paramFloat7 && paramFloat7 < paramFloat5) ? 1 : 0;
/*     */       }
/* 418 */       return (paramFloat5 < paramFloat7 && paramFloat7 < paramFloat1) ? -1 : 0;
/*     */     } 
/*     */ 
/*     */     
/* 422 */     QuadCurve quadCurve = new QuadCurve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 423 */     float f1 = paramFloat7 - paramFloat1;
/* 424 */     float f2 = paramFloat8 - paramFloat2;
/* 425 */     float[] arrayOfFloat = new float[3];
/* 426 */     int i = quadCurve.solvePoint(arrayOfFloat, f1);
/*     */     
/* 428 */     return quadCurve.cross(arrayOfFloat, i, f2, f2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int crossCubic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10) {
/* 437 */     if ((paramFloat9 < paramFloat1 && paramFloat9 < paramFloat3 && paramFloat9 < paramFloat5 && paramFloat9 < paramFloat7) || (paramFloat9 > paramFloat1 && paramFloat9 > paramFloat3 && paramFloat9 > paramFloat5 && paramFloat9 > paramFloat7) || (paramFloat10 > paramFloat2 && paramFloat10 > paramFloat4 && paramFloat10 > paramFloat6 && paramFloat10 > paramFloat8) || (paramFloat1 == paramFloat3 && paramFloat3 == paramFloat5 && paramFloat5 == paramFloat7))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 442 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 446 */     if (paramFloat10 < paramFloat2 && paramFloat10 < paramFloat4 && paramFloat10 < paramFloat6 && paramFloat10 < paramFloat8 && paramFloat9 != paramFloat1 && paramFloat9 != paramFloat7) {
/* 447 */       if (paramFloat1 < paramFloat7) {
/* 448 */         return (paramFloat1 < paramFloat9 && paramFloat9 < paramFloat7) ? 1 : 0;
/*     */       }
/* 450 */       return (paramFloat7 < paramFloat9 && paramFloat9 < paramFloat1) ? -1 : 0;
/*     */     } 
/*     */ 
/*     */     
/* 454 */     CubicCurve cubicCurve = new CubicCurve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/* 455 */     float f1 = paramFloat9 - paramFloat1;
/* 456 */     float f2 = paramFloat10 - paramFloat2;
/* 457 */     float[] arrayOfFloat = new float[3];
/* 458 */     int i = cubicCurve.solvePoint(arrayOfFloat, f1);
/* 459 */     return cubicCurve.cross(arrayOfFloat, i, f2, f2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int crossPath(Path2F.Iterator paramIterator, float paramFloat1, float paramFloat2) {
/* 466 */     int i = 0;
/*     */     
/* 468 */     float f4 = 0.0F, f3 = f4, f2 = f3, f1 = f2;
/* 469 */     float[] arrayOfFloat = paramIterator.points();
/* 470 */     while (paramIterator.hasNext()) {
/* 471 */       int j = paramIterator.index();
/* 472 */       Path2F.SegmentType segmentType = paramIterator.next();
/* 473 */       switch (segmentType) {
/*     */         case MOVETO:
/* 475 */           if (f3 != f1 || f4 != f2) {
/* 476 */             i += crossLine(f3, f4, f1, f2, paramFloat1, paramFloat2);
/*     */           }
/* 478 */           f1 = f3 = arrayOfFloat[j + 0];
/* 479 */           f2 = f4 = arrayOfFloat[j + 1];
/*     */           break;
/*     */         case LINETO:
/* 482 */           i += crossLine(f3, f4, f3 = arrayOfFloat[j + 0], f4 = arrayOfFloat[j + 1], paramFloat1, paramFloat2);
/*     */           break;
/*     */         case QUADTO:
/* 485 */           i += crossQuad(f3, f4, arrayOfFloat[j + 0], arrayOfFloat[j + 1], f3 = arrayOfFloat[j + 2], f4 = arrayOfFloat[j + 3], paramFloat1, paramFloat2);
/*     */           break;
/*     */         case CUBICTO:
/* 488 */           i += crossCubic(f3, f4, arrayOfFloat[j + 0], arrayOfFloat[j + 1], arrayOfFloat[j + 2], arrayOfFloat[j + 3], f3 = arrayOfFloat[j + 4], f4 = arrayOfFloat[j + 5], paramFloat1, paramFloat2);
/*     */           break;
/*     */         case CLOSE:
/* 491 */           if (f4 != f2 || f3 != f1) {
/* 492 */             i += crossLine(f3, f4, f3 = f1, f4 = f2, paramFloat1, paramFloat2);
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 498 */       if (paramFloat1 == f3 && paramFloat2 == f4) {
/* 499 */         i = 0;
/* 500 */         f4 = f2;
/*     */         break;
/*     */       } 
/*     */     } 
/* 504 */     if (f4 != f2) {
/* 505 */       i += crossLine(f3, f4, f1, f2, paramFloat1, paramFloat2);
/*     */     }
/* 507 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int crossShape(Path2F paramPath2F, float paramFloat1, float paramFloat2) {
/* 514 */     if (!paramPath2F.getBounds2D().contains(paramFloat1, paramFloat2)) {
/* 515 */       return 0;
/*     */     }
/* 517 */     return crossPath(paramPath2F.iterator(null), paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isZero(float paramFloat) {
/* 524 */     return (-1.0E-5F < paramFloat && paramFloat < 1.0E-5F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void sortBound(float[] paramArrayOffloat, int paramInt) {
/* 531 */     for (byte b = 0; b < paramInt - 4; b += 4) {
/* 532 */       int i = b;
/* 533 */       for (int j = b + 4; j < paramInt; j += 4) {
/* 534 */         if (paramArrayOffloat[i] > paramArrayOffloat[j]) {
/* 535 */           i = j;
/*     */         }
/*     */       } 
/* 538 */       if (i != b) {
/* 539 */         float f = paramArrayOffloat[b];
/* 540 */         paramArrayOffloat[b] = paramArrayOffloat[i];
/* 541 */         paramArrayOffloat[i] = f;
/* 542 */         f = paramArrayOffloat[b + 1];
/* 543 */         paramArrayOffloat[b + 1] = paramArrayOffloat[i + 1];
/* 544 */         paramArrayOffloat[i + 1] = f;
/* 545 */         f = paramArrayOffloat[b + 2];
/* 546 */         paramArrayOffloat[b + 2] = paramArrayOffloat[i + 2];
/* 547 */         paramArrayOffloat[i + 2] = f;
/* 548 */         f = paramArrayOffloat[b + 3];
/* 549 */         paramArrayOffloat[b + 3] = paramArrayOffloat[i + 3];
/* 550 */         paramArrayOffloat[i + 3] = f;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int crossBound(float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2) {
/* 561 */     if (paramInt == 0) {
/* 562 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 566 */     byte b1 = 0;
/* 567 */     byte b2 = 0; byte b3;
/* 568 */     for (b3 = 2; b3 < paramInt; b3 += 4) {
/* 569 */       if (paramArrayOffloat[b3] < paramFloat1) {
/* 570 */         b1++;
/*     */       
/*     */       }
/* 573 */       else if (paramArrayOffloat[b3] > paramFloat2) {
/* 574 */         b2++;
/*     */       } else {
/*     */         
/* 577 */         return 255;
/*     */       } 
/*     */     } 
/*     */     
/* 581 */     if (b2 == 0) {
/* 582 */       return 0;
/*     */     }
/*     */     
/* 585 */     if (b1 != 0) {
/*     */       
/* 587 */       sortBound(paramArrayOffloat, paramInt);
/* 588 */       b3 = (paramArrayOffloat[2] > paramFloat2) ? 1 : 0;
/* 589 */       for (byte b = 6; b < paramInt; b += 4) {
/* 590 */         byte b4 = (paramArrayOffloat[b] > paramFloat2) ? 1 : 0;
/* 591 */         if (b3 != b4 && paramArrayOffloat[b + 1] != paramArrayOffloat[b - 3]) {
/* 592 */           return 255;
/*     */         }
/* 594 */         b3 = b4;
/*     */       } 
/*     */     } 
/* 597 */     return 254;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intersectLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/* 606 */     if ((paramFloat7 < paramFloat1 && paramFloat7 < paramFloat3) || (paramFloat5 > paramFloat1 && paramFloat5 > paramFloat3) || (paramFloat6 > paramFloat2 && paramFloat6 > paramFloat4))
/*     */     {
/*     */ 
/*     */       
/* 610 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 614 */     if (paramFloat8 >= paramFloat2 || paramFloat8 >= paramFloat4) {
/*     */       float f1, f2;
/*     */ 
/*     */       
/* 618 */       if (paramFloat1 == paramFloat3) {
/* 619 */         return 255;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 624 */       if (paramFloat1 < paramFloat3) {
/* 625 */         f1 = (paramFloat1 < paramFloat5) ? paramFloat5 : paramFloat1;
/* 626 */         f2 = (paramFloat3 < paramFloat7) ? paramFloat3 : paramFloat7;
/*     */       } else {
/* 628 */         f1 = (paramFloat3 < paramFloat5) ? paramFloat5 : paramFloat3;
/* 629 */         f2 = (paramFloat1 < paramFloat7) ? paramFloat1 : paramFloat7;
/*     */       } 
/* 631 */       float f3 = (paramFloat4 - paramFloat2) / (paramFloat3 - paramFloat1);
/* 632 */       float f4 = f3 * (f1 - paramFloat1) + paramFloat2;
/* 633 */       float f5 = f3 * (f2 - paramFloat1) + paramFloat2;
/*     */ 
/*     */       
/* 636 */       if (f4 < paramFloat6 && f5 < paramFloat6) {
/* 637 */         return 0;
/*     */       }
/*     */ 
/*     */       
/* 641 */       if (f4 <= paramFloat8 || f5 <= paramFloat8)
/*     */       {
/* 643 */         return 255;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 648 */     if (paramFloat1 == paramFloat3) {
/* 649 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 653 */     if (paramFloat5 == paramFloat1) {
/* 654 */       return (paramFloat1 < paramFloat3) ? 0 : -1;
/*     */     }
/*     */ 
/*     */     
/* 658 */     if (paramFloat5 == paramFloat3) {
/* 659 */       return (paramFloat1 < paramFloat3) ? 1 : 0;
/*     */     }
/*     */     
/* 662 */     if (paramFloat1 < paramFloat3) {
/* 663 */       return (paramFloat1 < paramFloat5 && paramFloat5 < paramFloat3) ? 1 : 0;
/*     */     }
/* 665 */     return (paramFloat3 < paramFloat5 && paramFloat5 < paramFloat1) ? -1 : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intersectQuad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10) {
/* 675 */     if ((paramFloat9 < paramFloat1 && paramFloat9 < paramFloat3 && paramFloat9 < paramFloat5) || (paramFloat7 > paramFloat1 && paramFloat7 > paramFloat3 && paramFloat7 > paramFloat5) || (paramFloat8 > paramFloat2 && paramFloat8 > paramFloat4 && paramFloat8 > paramFloat6))
/*     */     {
/*     */ 
/*     */       
/* 679 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 683 */     if (paramFloat10 < paramFloat2 && paramFloat10 < paramFloat4 && paramFloat10 < paramFloat6 && paramFloat7 != paramFloat1 && paramFloat7 != paramFloat5) {
/* 684 */       if (paramFloat1 < paramFloat5) {
/* 685 */         return (paramFloat1 < paramFloat7 && paramFloat7 < paramFloat5) ? 1 : 0;
/*     */       }
/* 687 */       return (paramFloat5 < paramFloat7 && paramFloat7 < paramFloat1) ? -1 : 0;
/*     */     } 
/*     */ 
/*     */     
/* 691 */     QuadCurve quadCurve = new QuadCurve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 692 */     float f1 = paramFloat7 - paramFloat1;
/* 693 */     float f2 = paramFloat8 - paramFloat2;
/* 694 */     float f3 = paramFloat9 - paramFloat1;
/* 695 */     float f4 = paramFloat10 - paramFloat2;
/*     */     
/* 697 */     float[] arrayOfFloat1 = new float[3];
/* 698 */     float[] arrayOfFloat2 = new float[3];
/* 699 */     int i = quadCurve.solvePoint(arrayOfFloat1, f1);
/* 700 */     int j = quadCurve.solvePoint(arrayOfFloat2, f3);
/*     */ 
/*     */     
/* 703 */     if (i == 0 && j == 0) {
/* 704 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 708 */     float f5 = f1 - 1.0E-5F;
/* 709 */     float f6 = f3 + 1.0E-5F;
/* 710 */     float[] arrayOfFloat3 = new float[28];
/* 711 */     int k = 0;
/*     */     
/* 713 */     k = quadCurve.addBound(arrayOfFloat3, k, arrayOfFloat1, i, f5, f6, false, 0);
/* 714 */     k = quadCurve.addBound(arrayOfFloat3, k, arrayOfFloat2, j, f5, f6, false, 1);
/*     */     
/* 716 */     j = quadCurve.solveExtrem(arrayOfFloat2);
/* 717 */     k = quadCurve.addBound(arrayOfFloat3, k, arrayOfFloat2, j, f5, f6, true, 2);
/*     */     
/* 719 */     if (paramFloat7 < paramFloat1 && paramFloat1 < paramFloat9) {
/* 720 */       arrayOfFloat3[k++] = 0.0F;
/* 721 */       arrayOfFloat3[k++] = 0.0F;
/* 722 */       arrayOfFloat3[k++] = 0.0F;
/* 723 */       arrayOfFloat3[k++] = 4.0F;
/*     */     } 
/* 725 */     if (paramFloat7 < paramFloat5 && paramFloat5 < paramFloat9) {
/* 726 */       arrayOfFloat3[k++] = 1.0F;
/* 727 */       arrayOfFloat3[k++] = quadCurve.ax;
/* 728 */       arrayOfFloat3[k++] = quadCurve.ay;
/* 729 */       arrayOfFloat3[k++] = 5.0F;
/*     */     } 
/*     */ 
/*     */     
/* 733 */     int m = crossBound(arrayOfFloat3, k, f2, f4);
/* 734 */     if (m != 254) {
/* 735 */       return m;
/*     */     }
/* 737 */     return quadCurve.cross(arrayOfFloat1, i, f2, f4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intersectCubic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
/* 746 */     if ((paramFloat11 < paramFloat1 && paramFloat11 < paramFloat3 && paramFloat11 < paramFloat5 && paramFloat11 < paramFloat7) || (paramFloat9 > paramFloat1 && paramFloat9 > paramFloat3 && paramFloat9 > paramFloat5 && paramFloat9 > paramFloat7) || (paramFloat10 > paramFloat2 && paramFloat10 > paramFloat4 && paramFloat10 > paramFloat6 && paramFloat10 > paramFloat8))
/*     */     {
/*     */ 
/*     */       
/* 750 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 754 */     if (paramFloat12 < paramFloat2 && paramFloat12 < paramFloat4 && paramFloat12 < paramFloat6 && paramFloat12 < paramFloat8 && paramFloat9 != paramFloat1 && paramFloat9 != paramFloat7) {
/* 755 */       if (paramFloat1 < paramFloat7) {
/* 756 */         return (paramFloat1 < paramFloat9 && paramFloat9 < paramFloat7) ? 1 : 0;
/*     */       }
/* 758 */       return (paramFloat7 < paramFloat9 && paramFloat9 < paramFloat1) ? -1 : 0;
/*     */     } 
/*     */ 
/*     */     
/* 762 */     CubicCurve cubicCurve = new CubicCurve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/* 763 */     float f1 = paramFloat9 - paramFloat1;
/* 764 */     float f2 = paramFloat10 - paramFloat2;
/* 765 */     float f3 = paramFloat11 - paramFloat1;
/* 766 */     float f4 = paramFloat12 - paramFloat2;
/*     */     
/* 768 */     float[] arrayOfFloat1 = new float[3];
/* 769 */     float[] arrayOfFloat2 = new float[3];
/* 770 */     int i = cubicCurve.solvePoint(arrayOfFloat1, f1);
/* 771 */     int j = cubicCurve.solvePoint(arrayOfFloat2, f3);
/*     */ 
/*     */     
/* 774 */     if (i == 0 && j == 0) {
/* 775 */       return 0;
/*     */     }
/*     */     
/* 778 */     float f5 = f1 - 1.0E-5F;
/* 779 */     float f6 = f3 + 1.0E-5F;
/*     */ 
/*     */     
/* 782 */     float[] arrayOfFloat3 = new float[40];
/* 783 */     int k = 0;
/*     */     
/* 785 */     k = cubicCurve.addBound(arrayOfFloat3, k, arrayOfFloat1, i, f5, f6, false, 0);
/* 786 */     k = cubicCurve.addBound(arrayOfFloat3, k, arrayOfFloat2, j, f5, f6, false, 1);
/*     */     
/* 788 */     j = cubicCurve.solveExtremX(arrayOfFloat2);
/* 789 */     k = cubicCurve.addBound(arrayOfFloat3, k, arrayOfFloat2, j, f5, f6, true, 2);
/* 790 */     j = cubicCurve.solveExtremY(arrayOfFloat2);
/* 791 */     k = cubicCurve.addBound(arrayOfFloat3, k, arrayOfFloat2, j, f5, f6, true, 4);
/*     */     
/* 793 */     if (paramFloat9 < paramFloat1 && paramFloat1 < paramFloat11) {
/* 794 */       arrayOfFloat3[k++] = 0.0F;
/* 795 */       arrayOfFloat3[k++] = 0.0F;
/* 796 */       arrayOfFloat3[k++] = 0.0F;
/* 797 */       arrayOfFloat3[k++] = 6.0F;
/*     */     } 
/* 799 */     if (paramFloat9 < paramFloat7 && paramFloat7 < paramFloat11) {
/* 800 */       arrayOfFloat3[k++] = 1.0F;
/* 801 */       arrayOfFloat3[k++] = cubicCurve.ax;
/* 802 */       arrayOfFloat3[k++] = cubicCurve.ay;
/* 803 */       arrayOfFloat3[k++] = 7.0F;
/*     */     } 
/*     */ 
/*     */     
/* 807 */     int m = crossBound(arrayOfFloat3, k, f2, f4);
/* 808 */     if (m != 254) {
/* 809 */       return m;
/*     */     }
/* 811 */     return cubicCurve.cross(arrayOfFloat1, i, f2, f4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intersectPath(Path2F.Iterator paramIterator, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 819 */     int i = 0;
/*     */ 
/*     */     
/* 822 */     float f4 = 0.0F, f3 = f4, f2 = f3, f1 = f2;
/*     */     
/* 824 */     float f5 = paramFloat1;
/* 825 */     float f6 = paramFloat2;
/* 826 */     float f7 = paramFloat1 + paramFloat3;
/* 827 */     float f8 = paramFloat2 + paramFloat4;
/*     */     
/* 829 */     float[] arrayOfFloat = paramIterator.points();
/*     */     
/* 831 */     while (paramIterator.hasNext()) {
/* 832 */       int k = paramIterator.index();
/* 833 */       Path2F.SegmentType segmentType = paramIterator.next();
/* 834 */       int j = 0;
/* 835 */       switch (segmentType) {
/*     */         case MOVETO:
/* 837 */           if (f3 != f1 || f4 != f2) {
/* 838 */             j = intersectLine(f3, f4, f1, f2, f5, f6, f7, f8);
/*     */           }
/* 840 */           f1 = f3 = arrayOfFloat[k + 0];
/* 841 */           f2 = f4 = arrayOfFloat[k + 1];
/*     */           break;
/*     */         case LINETO:
/* 844 */           j = intersectLine(f3, f4, f3 = arrayOfFloat[k + 0], f4 = arrayOfFloat[k + 1], f5, f6, f7, f8);
/*     */           break;
/*     */         case QUADTO:
/* 847 */           j = intersectQuad(f3, f4, arrayOfFloat[k + 0], arrayOfFloat[k + 1], f3 = arrayOfFloat[k + 2], f4 = arrayOfFloat[k + 3], f5, f6, f7, f8);
/*     */           break;
/*     */         case CUBICTO:
/* 850 */           j = intersectCubic(f3, f4, arrayOfFloat[k + 0], arrayOfFloat[k + 1], arrayOfFloat[k + 2], arrayOfFloat[k + 3], f3 = arrayOfFloat[k + 4], f4 = arrayOfFloat[k + 5], f5, f6, f7, f8);
/*     */           break;
/*     */         case CLOSE:
/* 853 */           if (f4 != f2 || f3 != f1) {
/* 854 */             j = intersectLine(f3, f4, f1, f2, f5, f6, f7, f8);
/*     */           }
/* 856 */           f3 = f1;
/* 857 */           f4 = f2;
/*     */           break;
/*     */       } 
/* 860 */       if (j == 255) {
/* 861 */         return 255;
/*     */       }
/* 863 */       i += j;
/*     */     } 
/* 865 */     if (f4 != f2) {
/* 866 */       int j = intersectLine(f3, f4, f1, f2, f5, f6, f7, f8);
/* 867 */       if (j == 255) {
/* 868 */         return 255;
/*     */       }
/* 870 */       i += j;
/*     */     } 
/* 872 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intersectShape(Path2F paramPath2F, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 879 */     if (!paramPath2F.getBounds2D().intersects2DRegion(paramFloat1, paramFloat2, paramFloat3, paramFloat4)) {
/* 880 */       return 0;
/*     */     }
/* 882 */     return intersectPath(paramPath2F.iterator(null), paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInsideNonZero(int paramInt) {
/* 889 */     return (paramInt != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInsideEvenOdd(int paramInt) {
/* 896 */     return ((paramInt & 0x1) != 0);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/plane/Crossing2F.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */