/*    */ package com.jogamp.graph.geom.plane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum WindingRule
/*    */ {
/* 12 */   EVEN_ODD(0),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 21 */   NON_ZERO(1);
/*    */   
/*    */   public final int value;
/*    */   
/*    */   WindingRule(int paramInt1) {
/* 26 */     this.value = paramInt1;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/plane/WindingRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */