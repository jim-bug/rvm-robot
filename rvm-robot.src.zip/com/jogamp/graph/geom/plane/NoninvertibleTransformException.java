/*    */ package com.jogamp.graph.geom.plane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoninvertibleTransformException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 6137225240503990466L;
/*    */   
/*    */   public NoninvertibleTransformException(String paramString) {
/* 27 */     super(paramString);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/plane/NoninvertibleTransformException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */