/*     */ package com.jogamp.graph.geom.plane;
/*     */ 
/*     */ import com.jogamp.graph.geom.Vertex;
/*     */ import com.jogamp.opengl.math.FloatUtil;
/*     */ import com.jogamp.opengl.math.Vec2f;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AffineTransform
/*     */   implements Cloneable
/*     */ {
/*     */   static final String determinantIsZero = "Determinant is zero";
/*     */   public static final int TYPE_IDENTITY = 0;
/*     */   public static final int TYPE_TRANSLATION = 1;
/*     */   public static final int TYPE_UNIFORM_SCALE = 2;
/*     */   public static final int TYPE_GENERAL_SCALE = 4;
/*     */   public static final int TYPE_QUADRANT_ROTATION = 8;
/*     */   public static final int TYPE_GENERAL_ROTATION = 16;
/*     */   public static final int TYPE_GENERAL_TRANSFORM = 32;
/*     */   public static final int TYPE_FLIP = 64;
/*     */   public static final int TYPE_MASK_SCALE = 6;
/*     */   public static final int TYPE_MASK_ROTATION = 24;
/*     */   static final int TYPE_UNKNOWN = -1;
/*     */   static final float ZERO = 1.0E-10F;
/*     */   private float m00;
/*     */   private float m10;
/*     */   private float m01;
/*     */   private float m11;
/*     */   private float m02;
/*     */   private float m12;
/*     */   private transient int type;
/*     */   
/*     */   public AffineTransform() {
/*  72 */     setToIdentity();
/*     */   }
/*     */   
/*     */   public AffineTransform(AffineTransform paramAffineTransform) {
/*  76 */     this.type = paramAffineTransform.type;
/*  77 */     this.m00 = paramAffineTransform.m00;
/*  78 */     this.m10 = paramAffineTransform.m10;
/*  79 */     this.m01 = paramAffineTransform.m01;
/*  80 */     this.m11 = paramAffineTransform.m11;
/*  81 */     this.m02 = paramAffineTransform.m02;
/*  82 */     this.m12 = paramAffineTransform.m12;
/*     */   }
/*     */   
/*     */   public AffineTransform(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  86 */     this.type = -1;
/*  87 */     this.m00 = paramFloat1;
/*  88 */     this.m10 = paramFloat2;
/*  89 */     this.m01 = paramFloat3;
/*  90 */     this.m11 = paramFloat4;
/*  91 */     this.m02 = paramFloat5;
/*  92 */     this.m12 = paramFloat6;
/*     */   }
/*     */   
/*     */   public AffineTransform(float[] paramArrayOffloat) {
/*  96 */     this.type = -1;
/*  97 */     this.m00 = paramArrayOffloat[0];
/*  98 */     this.m10 = paramArrayOffloat[1];
/*  99 */     this.m01 = paramArrayOffloat[2];
/* 100 */     this.m11 = paramArrayOffloat[3];
/* 101 */     if (paramArrayOffloat.length > 4) {
/* 102 */       this.m02 = paramArrayOffloat[4];
/* 103 */       this.m12 = paramArrayOffloat[5];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 127 */     if (this.type != -1) {
/* 128 */       return this.type;
/*     */     }
/*     */     
/* 131 */     int i = 0;
/*     */     
/* 133 */     if ((this.m00 * this.m01 + this.m10 * this.m11) != 0.0D) {
/* 134 */       i |= 0x20;
/* 135 */       return i;
/*     */     } 
/*     */     
/* 138 */     if (this.m02 != 0.0D || this.m12 != 0.0D) {
/* 139 */       i |= 0x1;
/*     */     }
/* 141 */     else if (this.m00 == 1.0D && this.m11 == 1.0D && this.m01 == 0.0D && this.m10 == 0.0D) {
/* 142 */       i = 0;
/* 143 */       return i;
/*     */     } 
/*     */     
/* 146 */     if ((this.m00 * this.m11 - this.m01 * this.m10) < 0.0D) {
/* 147 */       i |= 0x40;
/*     */     }
/*     */     
/* 150 */     float f1 = this.m00 * this.m00 + this.m10 * this.m10;
/* 151 */     float f2 = this.m01 * this.m01 + this.m11 * this.m11;
/* 152 */     if (f1 != f2) {
/* 153 */       i |= 0x4;
/*     */     }
/* 155 */     else if (f1 != 1.0D) {
/* 156 */       i |= 0x2;
/*     */     } 
/*     */     
/* 159 */     if ((this.m00 == 0.0D && this.m11 == 0.0D) || (this.m10 == 0.0D && this.m01 == 0.0D && (this.m00 < 0.0D || this.m11 < 0.0D))) {
/*     */ 
/*     */       
/* 162 */       i |= 0x8;
/*     */     }
/* 164 */     else if (this.m01 != 0.0D || this.m10 != 0.0D) {
/* 165 */       i |= 0x10;
/*     */     } 
/*     */     
/* 168 */     return i;
/*     */   }
/*     */   
/*     */   public final float getScaleX() {
/* 172 */     return this.m00;
/*     */   }
/*     */   
/*     */   public final float getScaleY() {
/* 176 */     return this.m11;
/*     */   }
/*     */   
/*     */   public final float getShearX() {
/* 180 */     return this.m01;
/*     */   }
/*     */   
/*     */   public final float getShearY() {
/* 184 */     return this.m10;
/*     */   }
/*     */   
/*     */   public final float getTranslateX() {
/* 188 */     return this.m02;
/*     */   }
/*     */   
/*     */   public final float getTranslateY() {
/* 192 */     return this.m12;
/*     */   }
/*     */   
/*     */   public final boolean isIdentity() {
/* 196 */     return (getType() == 0);
/*     */   }
/*     */   
/*     */   public final void getMatrix(float[] paramArrayOffloat) {
/* 200 */     paramArrayOffloat[0] = this.m00;
/* 201 */     paramArrayOffloat[1] = this.m10;
/* 202 */     paramArrayOffloat[2] = this.m01;
/* 203 */     paramArrayOffloat[3] = this.m11;
/* 204 */     if (paramArrayOffloat.length > 4) {
/* 205 */       paramArrayOffloat[4] = this.m02;
/* 206 */       paramArrayOffloat[5] = this.m12;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final float getDeterminant() {
/* 211 */     return this.m00 * this.m11 - this.m01 * this.m10;
/*     */   }
/*     */   
/*     */   public final AffineTransform setTransform(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 215 */     this.type = -1;
/* 216 */     this.m00 = paramFloat1;
/* 217 */     this.m10 = paramFloat2;
/* 218 */     this.m01 = paramFloat3;
/* 219 */     this.m11 = paramFloat4;
/* 220 */     this.m02 = paramFloat5;
/* 221 */     this.m12 = paramFloat6;
/* 222 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform setTransform(AffineTransform paramAffineTransform) {
/* 226 */     this.type = paramAffineTransform.type;
/* 227 */     setTransform(paramAffineTransform.m00, paramAffineTransform.m10, paramAffineTransform.m01, paramAffineTransform.m11, paramAffineTransform.m02, paramAffineTransform.m12);
/* 228 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform setToIdentity() {
/* 232 */     this.type = 0;
/* 233 */     this.m00 = this.m11 = 1.0F;
/* 234 */     this.m10 = this.m01 = this.m02 = this.m12 = 0.0F;
/* 235 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform setToTranslation(float paramFloat1, float paramFloat2) {
/* 239 */     this.m00 = this.m11 = 1.0F;
/* 240 */     this.m01 = this.m10 = 0.0F;
/* 241 */     this.m02 = paramFloat1;
/* 242 */     this.m12 = paramFloat2;
/* 243 */     if (paramFloat1 == 0.0F && paramFloat2 == 0.0F) {
/* 244 */       this.type = 0;
/*     */     } else {
/* 246 */       this.type = 1;
/*     */     } 
/* 248 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform setToScale(float paramFloat1, float paramFloat2) {
/* 252 */     this.m00 = paramFloat1;
/* 253 */     this.m11 = paramFloat2;
/* 254 */     this.m10 = this.m01 = this.m02 = this.m12 = 0.0F;
/* 255 */     if (paramFloat1 != 1.0F || paramFloat2 != 1.0F) {
/* 256 */       this.type = -1;
/*     */     } else {
/* 258 */       this.type = 0;
/*     */     } 
/* 260 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform setToShear(float paramFloat1, float paramFloat2) {
/* 264 */     this.m00 = this.m11 = 1.0F;
/* 265 */     this.m02 = this.m12 = 0.0F;
/* 266 */     this.m01 = paramFloat1;
/* 267 */     this.m10 = paramFloat2;
/* 268 */     if (paramFloat1 != 0.0F || paramFloat2 != 0.0F) {
/* 269 */       this.type = -1;
/*     */     } else {
/* 271 */       this.type = 0;
/*     */     } 
/* 273 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform setToRotation(float paramFloat) {
/* 277 */     float f1 = FloatUtil.sin(paramFloat);
/* 278 */     float f2 = FloatUtil.cos(paramFloat);
/* 279 */     if (FloatUtil.abs(f2) < 1.0E-10F) {
/* 280 */       f2 = 0.0F;
/* 281 */       f1 = (f1 > 0.0F) ? 1.0F : -1.0F;
/*     */     }
/* 283 */     else if (FloatUtil.abs(f1) < 1.0E-10F) {
/* 284 */       f1 = 0.0F;
/* 285 */       f2 = (f2 > 0.0F) ? 1.0F : -1.0F;
/*     */     } 
/* 287 */     this.m00 = this.m11 = f2;
/* 288 */     this.m01 = -f1;
/* 289 */     this.m10 = f1;
/* 290 */     this.m02 = this.m12 = 0.0F;
/* 291 */     this.type = -1;
/* 292 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform setToRotation(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 296 */     setToRotation(paramFloat1);
/* 297 */     this.m02 = paramFloat2 * (1.0F - this.m00) + paramFloat3 * this.m10;
/* 298 */     this.m12 = paramFloat3 * (1.0F - this.m00) - paramFloat2 * this.m10;
/* 299 */     this.type = -1;
/* 300 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform translate(float paramFloat1, float paramFloat2, AffineTransform paramAffineTransform) {
/* 304 */     return concatenate(paramAffineTransform.setToTranslation(paramFloat1, paramFloat2));
/*     */   }
/*     */   
/*     */   public final AffineTransform scale(float paramFloat1, float paramFloat2, AffineTransform paramAffineTransform) {
/* 308 */     return concatenate(paramAffineTransform.setToScale(paramFloat1, paramFloat2));
/*     */   }
/*     */   
/*     */   public final AffineTransform shear(float paramFloat1, float paramFloat2, AffineTransform paramAffineTransform) {
/* 312 */     return concatenate(paramAffineTransform.setToShear(paramFloat1, paramFloat2));
/*     */   }
/*     */   
/*     */   public final AffineTransform rotate(float paramFloat, AffineTransform paramAffineTransform) {
/* 316 */     return concatenate(paramAffineTransform.setToRotation(paramFloat));
/*     */   }
/*     */   
/*     */   public final AffineTransform rotate(float paramFloat1, float paramFloat2, float paramFloat3, AffineTransform paramAffineTransform) {
/* 320 */     return concatenate(paramAffineTransform.setToRotation(paramFloat1, paramFloat2, paramFloat3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final AffineTransform multiply(AffineTransform paramAffineTransform1, AffineTransform paramAffineTransform2) {
/* 331 */     return new AffineTransform(paramAffineTransform2.m00 * paramAffineTransform1.m00 + paramAffineTransform2.m10 * paramAffineTransform1.m01, paramAffineTransform2.m00 * paramAffineTransform1.m10 + paramAffineTransform2.m10 * paramAffineTransform1.m11, paramAffineTransform2.m01 * paramAffineTransform1.m00 + paramAffineTransform2.m11 * paramAffineTransform1.m01, paramAffineTransform2.m01 * paramAffineTransform1.m10 + paramAffineTransform2.m11 * paramAffineTransform1.m11, paramAffineTransform2.m02 * paramAffineTransform1.m00 + paramAffineTransform2.m12 * paramAffineTransform1.m01 + paramAffineTransform1.m02, paramAffineTransform2.m02 * paramAffineTransform1.m10 + paramAffineTransform2.m12 * paramAffineTransform1.m11 + paramAffineTransform1.m12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AffineTransform concatenate(AffineTransform paramAffineTransform) {
/* 353 */     this.type = -1;
/* 354 */     setTransform(paramAffineTransform.m00 * this.m00 + paramAffineTransform.m10 * this.m01, paramAffineTransform.m00 * this.m10 + paramAffineTransform.m10 * this.m11, paramAffineTransform.m01 * this.m00 + paramAffineTransform.m11 * this.m01, paramAffineTransform.m01 * this.m10 + paramAffineTransform.m11 * this.m11, paramAffineTransform.m02 * this.m00 + paramAffineTransform.m12 * this.m01 + this.m02, paramAffineTransform.m02 * this.m10 + paramAffineTransform.m12 * this.m11 + this.m12);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 361 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AffineTransform preConcatenate(AffineTransform paramAffineTransform) {
/* 377 */     this.type = -1;
/* 378 */     setTransform(this.m00 * paramAffineTransform.m00 + this.m10 * paramAffineTransform.m01, this.m00 * paramAffineTransform.m10 + this.m10 * paramAffineTransform.m11, this.m01 * paramAffineTransform.m00 + this.m11 * paramAffineTransform.m01, this.m01 * paramAffineTransform.m10 + this.m11 * paramAffineTransform.m11, this.m02 * paramAffineTransform.m00 + this.m12 * paramAffineTransform.m01 + paramAffineTransform.m02, this.m02 * paramAffineTransform.m10 + this.m12 * paramAffineTransform.m11 + paramAffineTransform.m12);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 385 */     return this;
/*     */   }
/*     */   
/*     */   public final AffineTransform createInverse() throws NoninvertibleTransformException {
/* 389 */     float f = getDeterminant();
/* 390 */     if (FloatUtil.abs(f) < 1.0E-10F) {
/* 391 */       throw new NoninvertibleTransformException("Determinant is zero");
/*     */     }
/* 393 */     return new AffineTransform(this.m11 / f, -this.m10 / f, -this.m01 / f, this.m00 / f, (this.m01 * this.m12 - this.m11 * this.m02) / f, (this.m10 * this.m02 - this.m00 * this.m12) / f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AABBox transform(AABBox paramAABBox1, AABBox paramAABBox2) {
/* 410 */     Vec3f vec3f1 = paramAABBox1.getLow();
/* 411 */     Vec3f vec3f2 = paramAABBox1.getHigh();
/* 412 */     paramAABBox2.setSize(vec3f1.x() * this.m00 + vec3f1.y() * this.m01 + this.m02, vec3f1.x() * this.m10 + vec3f1.y() * this.m11 + this.m12, vec3f1.z(), vec3f2
/* 413 */         .x() * this.m00 + vec3f2.y() * this.m01 + this.m02, vec3f2.x() * this.m10 + vec3f2.y() * this.m11 + this.m12, vec3f2.z());
/* 414 */     return paramAABBox2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Vertex transform(Vertex paramVertex1, Vertex paramVertex2) {
/* 423 */     float f1 = paramVertex1.x();
/* 424 */     float f2 = paramVertex1.y();
/* 425 */     paramVertex2.setCoord(f1 * this.m00 + f2 * this.m01 + this.m02, f1 * this.m10 + f2 * this.m11 + this.m12, paramVertex1.z());
/* 426 */     return paramVertex2;
/*     */   }
/*     */   
/*     */   public final void transform(Vertex[] paramArrayOfVertex1, int paramInt1, Vertex[] paramArrayOfVertex2, int paramInt2, int paramInt3) {
/* 430 */     while (--paramInt3 >= 0) {
/* 431 */       Vertex vertex1 = paramArrayOfVertex1[paramInt1++];
/* 432 */       Vertex vertex2 = paramArrayOfVertex2[paramInt2];
/* 433 */       if (vertex2 == null) {
/* 434 */         throw new IllegalArgumentException("dst[" + paramInt2 + "] is null");
/*     */       }
/* 436 */       float f1 = vertex1.x();
/* 437 */       float f2 = vertex1.y();
/* 438 */       vertex2.setCoord(f1 * this.m00 + f2 * this.m01 + this.m02, f1 * this.m10 + f2 * this.m11 + this.m12, vertex1.z());
/* 439 */       paramArrayOfVertex2[paramInt2++] = vertex2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float[] transform(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/* 449 */     float f1 = paramArrayOffloat1[0];
/* 450 */     float f2 = paramArrayOffloat1[1];
/* 451 */     paramArrayOffloat2[0] = f1 * this.m00 + f2 * this.m01 + this.m02;
/* 452 */     paramArrayOffloat2[1] = f1 * this.m10 + f2 * this.m11 + this.m12;
/* 453 */     return paramArrayOffloat2;
/*     */   }
/*     */   
/*     */   public final void transform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2) {
/* 457 */     float f1 = paramArrayOffloat1[paramInt1 + 0];
/* 458 */     float f2 = paramArrayOffloat1[paramInt1 + 1];
/* 459 */     paramArrayOffloat2[paramInt2 + 0] = f1 * this.m00 + f2 * this.m01 + this.m02;
/* 460 */     paramArrayOffloat2[paramInt2 + 1] = f1 * this.m10 + f2 * this.m11 + this.m12;
/*     */   }
/*     */   
/*     */   public final void transform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 464 */     byte b = 2;
/* 465 */     if (paramArrayOffloat1 == paramArrayOffloat2 && paramInt1 < paramInt2 && paramInt2 < paramInt1 + paramInt3 * 2) {
/* 466 */       paramInt1 = paramInt1 + paramInt3 * 2 - 2;
/* 467 */       paramInt2 = paramInt2 + paramInt3 * 2 - 2;
/* 468 */       b = -2;
/*     */     } 
/* 470 */     while (--paramInt3 >= 0) {
/* 471 */       float f1 = paramArrayOffloat1[paramInt1 + 0];
/* 472 */       float f2 = paramArrayOffloat1[paramInt1 + 1];
/* 473 */       paramArrayOffloat2[paramInt2 + 0] = f1 * this.m00 + f2 * this.m01 + this.m02;
/* 474 */       paramArrayOffloat2[paramInt2 + 1] = f1 * this.m10 + f2 * this.m11 + this.m12;
/* 475 */       paramInt1 += b;
/* 476 */       paramInt2 += b;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Vec2f transform(Vec2f paramVec2f1, Vec2f paramVec2f2) {
/* 486 */     float f1 = paramVec2f1.x();
/* 487 */     float f2 = paramVec2f1.y();
/* 488 */     paramVec2f2.setX(f1 * this.m00 + f2 * this.m01 + this.m02);
/* 489 */     paramVec2f2.setY(f1 * this.m10 + f2 * this.m11 + this.m12);
/* 490 */     return paramVec2f2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Vec3f transform(Vec3f paramVec3f1, Vec3f paramVec3f2) {
/* 499 */     float f1 = paramVec3f1.x();
/* 500 */     float f2 = paramVec3f1.y();
/* 501 */     paramVec3f2.setX(f1 * this.m00 + f2 * this.m01 + this.m02);
/* 502 */     paramVec3f2.setY(f1 * this.m10 + f2 * this.m11 + this.m12);
/* 503 */     paramVec3f2.setZ(paramVec3f1.z());
/* 504 */     return paramVec3f2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Vertex deltaTransform(Vertex paramVertex1, Vertex paramVertex2) {
/* 514 */     float f1 = paramVertex1.x();
/* 515 */     float f2 = paramVertex1.y();
/* 516 */     paramVertex2.setCoord(f1 * this.m00 + f2 * this.m01, f1 * this.m10 + f2 * this.m11, paramVertex1.z());
/* 517 */     return paramVertex2;
/*     */   }
/*     */   
/*     */   public final void deltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 521 */     while (--paramInt3 >= 0) {
/* 522 */       float f1 = paramArrayOffloat1[paramInt1++];
/* 523 */       float f2 = paramArrayOffloat1[paramInt1++];
/* 524 */       paramArrayOffloat2[paramInt2++] = f1 * this.m00 + f2 * this.m01;
/* 525 */       paramArrayOffloat2[paramInt2++] = f1 * this.m10 + f2 * this.m11;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Vertex inverseTransform(Vertex paramVertex1, Vertex paramVertex2) throws NoninvertibleTransformException {
/* 537 */     float f1 = getDeterminant();
/* 538 */     if (FloatUtil.abs(f1) < 1.0E-10F) {
/* 539 */       throw new NoninvertibleTransformException("Determinant is zero");
/*     */     }
/* 541 */     float f2 = paramVertex1.x() - this.m02;
/* 542 */     float f3 = paramVertex1.y() - this.m12;
/* 543 */     paramVertex2.setCoord((f2 * this.m11 - f3 * this.m01) / f1, (f3 * this.m00 - f2 * this.m10) / f1, paramVertex1.z());
/* 544 */     return paramVertex2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void inverseTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) throws NoninvertibleTransformException {
/* 550 */     float f = getDeterminant();
/* 551 */     if (FloatUtil.abs(f) < 1.0E-10F) {
/* 552 */       throw new NoninvertibleTransformException("Determinant is zero");
/*     */     }
/*     */     
/* 555 */     while (--paramInt3 >= 0) {
/* 556 */       float f1 = paramArrayOffloat1[paramInt1++] - this.m02;
/* 557 */       float f2 = paramArrayOffloat1[paramInt1++] - this.m12;
/* 558 */       paramArrayOffloat2[paramInt2++] = (f1 * this.m11 - f2 * this.m01) / f;
/* 559 */       paramArrayOffloat2[paramInt2++] = (f2 * this.m00 - f1 * this.m10) / f;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final Path2F createTransformedShape(Path2F paramPath2F) {
/* 564 */     if (paramPath2F == null) {
/* 565 */       return null;
/*     */     }
/* 567 */     return paramPath2F.createTransformedShape(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 579 */     return 
/* 580 */       getClass().getName() + "[[" + this.m00 + ", " + this.m01 + ", " + this.m02 + "], [" + this.m10 + ", " + this.m11 + ", " + this.m12 + "]]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AffineTransform clone() {
/*     */     try {
/* 588 */       return (AffineTransform)super.clone();
/* 589 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/* 590 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 608 */     if (paramObject == this) {
/* 609 */       return true;
/*     */     }
/* 611 */     if (paramObject instanceof AffineTransform) {
/* 612 */       AffineTransform affineTransform = (AffineTransform)paramObject;
/* 613 */       return (this.m00 == affineTransform.m00 && this.m01 == affineTransform.m01 && this.m02 == affineTransform.m02 && this.m10 == affineTransform.m10 && this.m11 == affineTransform.m11 && this.m12 == affineTransform.m12);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 618 */     return false;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/* 622 */     throw new InternalError("hashCode not designed");
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/plane/AffineTransform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */