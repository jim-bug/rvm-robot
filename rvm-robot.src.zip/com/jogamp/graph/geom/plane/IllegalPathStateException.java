/*    */ package com.jogamp.graph.geom.plane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalPathStateException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -5158084205220481094L;
/*    */   
/*    */   public IllegalPathStateException() {}
/*    */   
/*    */   public IllegalPathStateException(String paramString) {
/* 30 */     super(paramString);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/plane/IllegalPathStateException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */