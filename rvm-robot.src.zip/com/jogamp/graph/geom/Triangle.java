/*     */ package com.jogamp.graph.geom;
/*     */ 
/*     */ import com.jogamp.graph.geom.plane.AffineTransform;
/*     */ import com.jogamp.opengl.math.VectorUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Triangle
/*     */ {
/*  34 */   private final Vertex[] vertices = new Vertex[3];
/*  35 */   private final boolean[] boundaryEdges = new boolean[3];
/*  36 */   private boolean[] boundaryVertices = null;
/*     */   private int id;
/*     */   
/*     */   public Triangle(Vertex paramVertex1, Vertex paramVertex2, Vertex paramVertex3, boolean[] paramArrayOfboolean) {
/*  40 */     this.id = Integer.MAX_VALUE;
/*  41 */     this.vertices[0] = paramVertex1;
/*  42 */     this.vertices[1] = paramVertex2;
/*  43 */     this.vertices[2] = paramVertex3;
/*  44 */     this.boundaryVertices = paramArrayOfboolean;
/*     */   }
/*     */   
/*     */   public Triangle(Triangle paramTriangle) {
/*  48 */     this.id = paramTriangle.id;
/*  49 */     this.vertices[0] = paramTriangle.vertices[0].clone();
/*  50 */     this.vertices[1] = paramTriangle.vertices[1].clone();
/*  51 */     this.vertices[2] = paramTriangle.vertices[2].clone();
/*  52 */     System.arraycopy(paramTriangle.boundaryEdges, 0, this.boundaryEdges, 0, 3);
/*  53 */     this.boundaryVertices = new boolean[3];
/*  54 */     System.arraycopy(paramTriangle.boundaryVertices, 0, this.boundaryVertices, 0, 3);
/*     */   }
/*     */   
/*     */   private Triangle(int paramInt, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2) {
/*  58 */     this.id = paramInt;
/*  59 */     System.arraycopy(paramArrayOfboolean1, 0, this.boundaryEdges, 0, 3);
/*  60 */     this.boundaryVertices = new boolean[3];
/*  61 */     System.arraycopy(paramArrayOfboolean2, 0, this.boundaryVertices, 0, 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Triangle transform(AffineTransform paramAffineTransform) {
/*  68 */     Triangle triangle = new Triangle(this.id, this.boundaryEdges, this.boundaryVertices);
/*  69 */     triangle.vertices[0] = paramAffineTransform.transform(this.vertices[0], new Vertex());
/*  70 */     triangle.vertices[1] = paramAffineTransform.transform(this.vertices[1], new Vertex());
/*  71 */     triangle.vertices[2] = paramAffineTransform.transform(this.vertices[2], new Vertex());
/*  72 */     return triangle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isOnCurve() {
/*  79 */     return (this.vertices[0].isOnCurve() && this.vertices[1].isOnCurve() && this.vertices[2].isOnCurve());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isLine() {
/*  86 */     return (VectorUtil.isVec2Zero(this.vertices[0].getTexCoord()) && 
/*  87 */       VectorUtil.isVec2Zero(this.vertices[1].getTexCoord()) && 
/*  88 */       VectorUtil.isVec2Zero(this.vertices[2].getTexCoord()));
/*     */   }
/*     */   
/*     */   public int getId() {
/*  92 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int paramInt) {
/*  96 */     this.id = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vertex[] getVertices() {
/* 101 */     return this.vertices;
/*     */   }
/*     */   
/*     */   public boolean isEdgesBoundary() {
/* 105 */     return (this.boundaryEdges[0] || this.boundaryEdges[1] || this.boundaryEdges[2]);
/*     */   }
/*     */   
/*     */   public boolean isVerticesBoundary() {
/* 109 */     return (this.boundaryVertices[0] || this.boundaryVertices[1] || this.boundaryVertices[2]);
/*     */   }
/*     */   
/*     */   public boolean[] getEdgeBoundary() {
/* 113 */     return this.boundaryEdges;
/*     */   }
/*     */   
/*     */   public boolean[] getVerticesBoundary() {
/* 117 */     return this.boundaryVertices;
/*     */   }
/*     */   
/*     */   public void setVerticesBoundary(boolean[] paramArrayOfboolean) {
/* 121 */     this.boundaryVertices = paramArrayOfboolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return "Tri ID: " + this.id + ", onCurve " + isOnCurve() + "\n\t" + this.vertices[0] + ", bound " + this.boundaryVertices[0] + "\n\t" + this.vertices[1] + ", bound " + this.boundaryVertices[1] + "\n\t" + this.vertices[2] + ", bound " + this.boundaryVertices[2];
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/geom/Triangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */