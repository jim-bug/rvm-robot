/*     */ package com.jogamp.graph.font;
/*     */ 
/*     */ import com.jogamp.common.net.Uri;
/*     */ import com.jogamp.common.util.IOUtil;
/*     */ import com.jogamp.common.util.PropertyAccess;
/*     */ import com.jogamp.common.util.ReflectionUtil;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import com.jogamp.common.util.cache.TempJarCache;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.PrivilegedAction;
/*     */ import jogamp.graph.font.FontConstructor;
/*     */ import jogamp.graph.font.JavaFontLoader;
/*     */ import jogamp.graph.font.UbuntuFontLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontFactory
/*     */ {
/*     */   private static final String FontConstructorPropKey = "jogamp.graph.font.ctor";
/*     */   private static final String DefaultFontConstructor = "jogamp.graph.font.typecast.TypecastFontConstructor";
/*     */   public static final int UBUNTU = 0;
/*     */   public static final int JAVA = 1;
/*     */   private static final FontConstructor fontConstr;
/*     */   
/*     */   static {
/*  74 */     String str = PropertyAccess.getProperty("jogamp.graph.font.ctor", true);
/*  75 */     if (null == str) {
/*  76 */       str = "jogamp.graph.font.typecast.TypecastFontConstructor";
/*     */     }
/*  78 */     fontConstr = (FontConstructor)ReflectionUtil.createInstance(str, FontFactory.class.getClassLoader());
/*     */   }
/*     */   
/*     */   public static final FontSet getDefault() {
/*  82 */     return get(0);
/*     */   }
/*     */   
/*     */   public static final FontSet get(int paramInt) {
/*  86 */     switch (paramInt) {
/*     */       case 1:
/*  88 */         return JavaFontLoader.get();
/*     */     } 
/*  90 */     return UbuntuFontLoader.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Font get(File paramFile) throws IOException {
/* 101 */     return fontConstr.create(paramFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Font get(InputStream paramInputStream, int paramInt, boolean paramBoolean) throws IOException {
/*     */     try {
/* 119 */       return fontConstr.create(paramInputStream, paramInt);
/*     */     } finally {
/* 121 */       if (paramBoolean) {
/* 122 */         paramInputStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Font get(final InputStream stream, final boolean closeStream) throws IOException {
/* 140 */     final IOException[] ioe = { null };
/* 141 */     final int[] streamLen = { 0 };
/* 142 */     final File[] tempFile = { null };
/*     */     
/* 144 */     InputStream inputStream = (InputStream)SecurityUtil.doPrivileged(new PrivilegedAction<InputStream>()
/*     */         {
/*     */           public InputStream run() {
/* 147 */             BufferedInputStream bufferedInputStream = null;
/*     */             try {
/* 149 */               tempFile[0] = IOUtil.createTempFile("jogl.font", ".ttf", false);
/* 150 */               streamLen[0] = IOUtil.copyStream2File(stream, tempFile[0]);
/* 151 */               if (0 == streamLen[0]) {
/* 152 */                 throw new IOException("Font stream has zero bytes");
/*     */               }
/* 154 */               bufferedInputStream = new BufferedInputStream(new FileInputStream(tempFile[0]), streamLen[0]);
/* 155 */             } catch (IOException iOException) {
/* 156 */               ioe[0] = iOException;
/* 157 */               if (null != tempFile[0]) {
/* 158 */                 tempFile[0].delete();
/* 159 */                 tempFile[0] = null;
/*     */               } 
/* 161 */               streamLen[0] = 0;
/*     */             } finally {
/* 163 */               if (closeStream) {
/* 164 */                 IOUtil.close(stream, ioe, System.err);
/*     */               }
/*     */             } 
/* 167 */             return bufferedInputStream; }
/*     */         });
/* 169 */     if (null != arrayOfIOException[0]) {
/* 170 */       throw arrayOfIOException[0];
/*     */     }
/* 172 */     if (null == inputStream) {
/* 173 */       throw new IOException("Could not cache font stream");
/*     */     }
/*     */     try {
/* 176 */       return fontConstr.create(inputStream, arrayOfInt[0]);
/*     */     } finally {
/* 178 */       if (null != inputStream) {
/* 179 */         inputStream.close();
/*     */       }
/* 181 */       if (null != arrayOfFile[0])
/* 182 */         SecurityUtil.doPrivileged(new PrivilegedAction()
/*     */             {
/*     */               public Object run() {
/* 185 */                 tempFile[0].delete();
/* 186 */                 return null;
/*     */               }
/*     */             }); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final Font get(Class<?> paramClass, String paramString, boolean paramBoolean) throws IOException {
/* 193 */     InputStream inputStream = null;
/* 194 */     if (paramBoolean) {
/*     */       try {
/* 196 */         Uri uri = TempJarCache.getResourceUri(paramString);
/* 197 */         inputStream = (null != uri) ? uri.toURL().openConnection().getInputStream() : null;
/* 198 */       } catch (Exception exception) {
/* 199 */         throw new IOException(exception);
/*     */       } 
/*     */     } else {
/* 202 */       inputStream = IOUtil.getResource(paramString, paramClass.getClassLoader(), paramClass).getInputStream();
/*     */     } 
/* 204 */     if (null != inputStream) {
/* 205 */       return get(inputStream, true);
/*     */     }
/* 207 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean isPrintableChar(char paramChar) {
/* 211 */     if (Character.isWhitespace(paramChar)) {
/* 212 */       return true;
/*     */     }
/* 214 */     if (Character.MIN_VALUE == paramChar || Character.isISOControl(paramChar)) {
/* 215 */       return false;
/*     */     }
/* 217 */     Character.UnicodeBlock unicodeBlock = Character.UnicodeBlock.of(paramChar);
/* 218 */     return (unicodeBlock != null && unicodeBlock != Character.UnicodeBlock.SPECIALS);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/font/FontFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */