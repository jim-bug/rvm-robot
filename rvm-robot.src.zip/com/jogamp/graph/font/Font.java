package com.jogamp.graph.font;

import com.jogamp.graph.curve.OutlineShape;
import com.jogamp.graph.geom.plane.AffineTransform;
import com.jogamp.opengl.math.geom.AABBox;

public interface Font {
  public static final int NAME_COPYRIGHT = 0;
  
  public static final int NAME_FAMILY = 1;
  
  public static final int NAME_SUBFAMILY = 2;
  
  public static final int NAME_UNIQUNAME = 3;
  
  public static final int NAME_FULLNAME = 4;
  
  public static final int NAME_VERSION = 5;
  
  public static final int NAME_MANUFACTURER = 8;
  
  public static final int NAME_DESIGNER = 9;
  
  String getName(int paramInt);
  
  String getFullFamilyName();
  
  StringBuilder getAllNames(StringBuilder paramStringBuilder, String paramString);
  
  int hashCode();
  
  boolean equals(Object paramObject);
  
  int getAdvanceWidthFU(int paramInt);
  
  float getAdvanceWidth(int paramInt);
  
  Metrics getMetrics();
  
  int getGlyphID(char paramChar);
  
  int getGlyphCount();
  
  Glyph getGlyph(int paramInt);
  
  int getNumGlyphs();
  
  int getLineHeightFU();
  
  float getLineHeight();
  
  AABBox getMetricBoundsFU(CharSequence paramCharSequence);
  
  AABBox getMetricBounds(CharSequence paramCharSequence);
  
  AABBox getGlyphBounds(CharSequence paramCharSequence);
  
  AABBox getGlyphBounds(CharSequence paramCharSequence, AffineTransform paramAffineTransform1, AffineTransform paramAffineTransform2);
  
  AABBox getGlyphBoundsFU(CharSequence paramCharSequence);
  
  AABBox getGlyphBoundsFU(CharSequence paramCharSequence, AffineTransform paramAffineTransform1, AffineTransform paramAffineTransform2);
  
  AABBox getGlyphShapeBounds(AffineTransform paramAffineTransform, CharSequence paramCharSequence);
  
  AABBox getGlyphShapeBounds(AffineTransform paramAffineTransform1, CharSequence paramCharSequence, AffineTransform paramAffineTransform2, AffineTransform paramAffineTransform3);
  
  boolean isPrintableChar(char paramChar);
  
  AABBox processString(GlyphVisitor paramGlyphVisitor, AffineTransform paramAffineTransform, CharSequence paramCharSequence);
  
  AABBox processString(GlyphVisitor paramGlyphVisitor, AffineTransform paramAffineTransform1, CharSequence paramCharSequence, AffineTransform paramAffineTransform2, AffineTransform paramAffineTransform3);
  
  void processString(GlyphVisitor2 paramGlyphVisitor2, CharSequence paramCharSequence);
  
  String toString();
  
  String fullString();
  
  public static interface GlyphVisitor2 {
    void visit(char param1Char, Font.Glyph param1Glyph);
  }
  
  public static interface GlyphVisitor {
    void visit(char param1Char, Font.Glyph param1Glyph, AffineTransform param1AffineTransform);
  }
  
  public static interface Glyph {
    public static final int ID_UNKNOWN = 0;
    
    Font getFont();
    
    int getID();
    
    String getName();
    
    boolean isWhiteSpace();
    
    boolean isUndefined();
    
    AABBox getBoundsFU();
    
    AABBox getBoundsFU(AABBox param1AABBox);
    
    AABBox getBounds(AABBox param1AABBox);
    
    AABBox getBounds();
    
    int getAdvanceFU();
    
    float getAdvance();
    
    int getLeftSideBearingsFU();
    
    float getLeftSideBearings();
    
    boolean isKerningHorizontal();
    
    boolean isKerningCrossstream();
    
    int getKerningPairCount();
    
    int getKerningFU(int param1Int);
    
    float getKerning(int param1Int);
    
    OutlineShape getShape();
    
    int hashCode();
    
    String toString();
    
    String fullString();
  }
  
  public static interface Metrics {
    int getAscentFU();
    
    float getAscent();
    
    int getDescentFU();
    
    float getDescent();
    
    int getLineGapFU();
    
    float getLineGap();
    
    int getMaxExtendFU();
    
    float getMaxExtend();
    
    int getUnitsPerEM();
    
    float getScale(int param1Int);
    
    AABBox getBoundsFU(AABBox param1AABBox);
    
    AABBox getBounds(AABBox param1AABBox);
  }
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/font/Font.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */