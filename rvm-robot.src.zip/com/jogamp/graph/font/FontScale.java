/*     */ package com.jogamp.graph.font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontScale
/*     */ {
/*     */   public static float ptToInch(float paramFloat) {
/*  46 */     return paramFloat / 72.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float ptToMM(float paramFloat) {
/*  59 */     return paramFloat / 72.0F * 25.4F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float toPixels(float paramFloat1, float paramFloat2) {
/*  77 */     return ptToInch(paramFloat1) * paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float toPixels2(float paramFloat1, float paramFloat2) {
/*  97 */     return ptToMM(paramFloat1) * paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] ppmmToPPI(float[] paramArrayOffloat) {
/* 106 */     paramArrayOffloat[0] = paramArrayOffloat[0] * 25.4F;
/* 107 */     paramArrayOffloat[1] = paramArrayOffloat[1] * 25.4F;
/* 108 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] ppmmToPPI(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/* 118 */     paramArrayOffloat2[0] = paramArrayOffloat1[0] * 25.4F;
/* 119 */     paramArrayOffloat2[1] = paramArrayOffloat1[1] * 25.4F;
/* 120 */     return paramArrayOffloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] ppiToPPMM(float[] paramArrayOffloat) {
/* 129 */     paramArrayOffloat[0] = paramArrayOffloat[0] / 25.4F;
/* 130 */     paramArrayOffloat[1] = paramArrayOffloat[1] / 25.4F;
/* 131 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] ppiToPPMM(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/* 141 */     paramArrayOffloat2[0] = paramArrayOffloat1[0] / 25.4F;
/* 142 */     paramArrayOffloat2[1] = paramArrayOffloat1[1] / 25.4F;
/* 143 */     return paramArrayOffloat2;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/font/FontScale.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */