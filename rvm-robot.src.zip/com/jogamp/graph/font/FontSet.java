package com.jogamp.graph.font;

import java.io.IOException;

public interface FontSet {
  public static final int FAMILY_REGULAR = 0;
  
  public static final int FAMILY_LIGHT = 1;
  
  public static final int FAMILY_MEDIUM = 2;
  
  public static final int FAMILY_CONDENSED = 3;
  
  public static final int FAMILY_MONOSPACED = 4;
  
  public static final int STYLE_NONE = 0;
  
  public static final int STYLE_SERIF = 2;
  
  public static final int STYLE_BOLD = 4;
  
  public static final int STYLE_ITALIC = 8;
  
  Font getDefault() throws IOException;
  
  Font get(int paramInt1, int paramInt2) throws IOException;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/font/FontSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */