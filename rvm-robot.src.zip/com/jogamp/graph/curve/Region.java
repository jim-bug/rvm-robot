/*     */ package com.jogamp.graph.curve;
/*     */ 
/*     */ import com.jogamp.common.os.Clock;
/*     */ import com.jogamp.common.util.PerfCounterCtrl;
/*     */ import com.jogamp.graph.geom.Triangle;
/*     */ import com.jogamp.graph.geom.Vertex;
/*     */ import com.jogamp.graph.geom.plane.AffineTransform;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import com.jogamp.opengl.math.geom.Frustum;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import jogamp.opengl.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Region
/*     */ {
/*  65 */   public static final boolean DEBUG = Debug.debug("graph.curve");
/*  66 */   public static final boolean DEBUG_INSTANCE = Debug.debug("graph.curve.Instance");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NORM_RENDERING_BIT = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MSAA_RENDERING_BIT = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int VBAA_RENDERING_BIT = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int VARWEIGHT_RENDERING_BIT = 256;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int COLORCHANNEL_RENDERING_BIT = 512;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int COLORTEXTURE_RENDERING_BIT = 1024;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MAX_QUALITY = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_TWO_PASS_TEXTURE_UNIT = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int DIRTY_SHAPE = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int DIRTY_STATE = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int renderModes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean use_int32_idx;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int max_indices;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int quality;
/*     */ 
/*     */ 
/*     */   
/* 140 */   private int dirty = 3;
/* 141 */   private int numVertices = 0;
/* 142 */   protected final AABBox box = new AABBox();
/* 143 */   protected Frustum frustum = null; private final AABBox tmpBox; protected static final int GL_UINT16_MAX = 65535; protected static final int GL_INT32_MAX = 2147483647; private Perf perf; private final PerfCounterCtrl perfCounterCtrl;
/*     */   
/*     */   public static boolean isVBAA(int paramInt) {
/* 146 */     return (0 != (paramInt & 0x2));
/*     */   }
/*     */   
/*     */   public static boolean isMSAA(int paramInt) {
/* 150 */     return (0 != (paramInt & 0x1));
/*     */   }
/*     */   
/*     */   public static boolean isTwoPass(int paramInt) {
/* 154 */     return (0 != (paramInt & 0x3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasVariableWeight(int paramInt) {
/* 163 */     return (0 != (paramInt & 0x100));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasColorChannel(int paramInt) {
/* 172 */     return (0 != (paramInt & 0x200));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasColorTexture(int paramInt) {
/* 181 */     return (0 != (paramInt & 0x400));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getRenderModeString(int paramInt) {
/* 192 */     String str1 = hasVariableWeight(paramInt) ? "-curve" : "";
/* 193 */     String str2 = hasColorChannel(paramInt) ? "-cols" : "";
/* 194 */     String str3 = hasColorTexture(paramInt) ? "-ctex" : "";
/* 195 */     if (isVBAA(paramInt))
/* 196 */       return "vbaa" + str1 + str2 + str3; 
/* 197 */     if (isMSAA(paramInt)) {
/* 198 */       return "msaa" + str1 + str2 + str3;
/*     */     }
/* 200 */     return "norm" + str1 + str2 + str3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getRenderModeString(int paramInt1, int paramInt2, int paramInt3) {
/* 215 */     return String.format((Locale)null, "%s-s%02d-fsaa%d", new Object[] { getRenderModeString(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean usesI32Idx() {
/* 236 */     return this.use_int32_idx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRenderModes() {
/* 275 */     return this.renderModes;
/*     */   }
/*     */   public final int getQuality() {
/* 278 */     return this.quality;
/*     */   }
/*     */   public final void setQuality(int paramInt) {
/* 281 */     this.quality = paramInt;
/*     */   }
/*     */   protected final void clearImpl() {
/* 284 */     this.dirty = 3;
/* 285 */     this.numVertices = 0;
/* 286 */     this.box.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isVBAA() {
/* 294 */     return isVBAA(this.renderModes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isMSAA() {
/* 302 */     return isMSAA(this.renderModes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasVariableWeight() {
/* 310 */     return hasVariableWeight(this.renderModes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasColorChannel() {
/* 322 */     return hasColorChannel(this.renderModes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasColorTexture() {
/* 332 */     return hasColorTexture(this.renderModes);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Frustum getFrustum() {
/* 337 */     return this.frustum;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setFrustum(Frustum paramFrustum) {
/* 343 */     this.frustum = paramFrustum;
/*     */   }
/*     */   
/*     */   private void pushNewVertexImpl(Vertex paramVertex, AffineTransform paramAffineTransform, Vec4f paramVec4f) {
/* 347 */     if (null != paramAffineTransform) {
/* 348 */       Vec3f vec3f = paramAffineTransform.transform(paramVertex.getCoord(), new Vec3f());
/* 349 */       this.box.resize(vec3f);
/* 350 */       pushVertex(vec3f, paramVertex.getTexCoord(), paramVec4f);
/*     */     } else {
/* 352 */       this.box.resize(paramVertex.getCoord());
/* 353 */       pushVertex(paramVertex.getCoord(), paramVertex.getTexCoord(), paramVec4f);
/*     */     } 
/* 355 */     this.numVertices++;
/*     */   }
/*     */   
/*     */   private void pushNewVerticesImpl(Vertex paramVertex1, Vertex paramVertex2, Vertex paramVertex3, AffineTransform paramAffineTransform, Vec4f paramVec4f) {
/* 359 */     if (null != paramAffineTransform) {
/* 360 */       Vec3f vec3f1 = paramAffineTransform.transform(paramVertex1.getCoord(), new Vec3f());
/* 361 */       Vec3f vec3f2 = paramAffineTransform.transform(paramVertex2.getCoord(), new Vec3f());
/* 362 */       Vec3f vec3f3 = paramAffineTransform.transform(paramVertex3.getCoord(), new Vec3f());
/* 363 */       this.box.resize(vec3f1);
/* 364 */       this.box.resize(vec3f2);
/* 365 */       this.box.resize(vec3f3);
/* 366 */       pushVertices(vec3f1, vec3f2, vec3f3, paramVertex1
/* 367 */           .getTexCoord(), paramVertex2.getTexCoord(), paramVertex3.getTexCoord(), paramVec4f);
/*     */     } else {
/* 369 */       this.box.resize(paramVertex1.getCoord());
/* 370 */       this.box.resize(paramVertex2.getCoord());
/* 371 */       this.box.resize(paramVertex3.getCoord());
/* 372 */       pushVertices(paramVertex1.getCoord(), paramVertex2.getCoord(), paramVertex3.getCoord(), paramVertex1
/* 373 */           .getTexCoord(), paramVertex2.getTexCoord(), paramVertex3.getTexCoord(), paramVec4f);
/*     */     } 
/* 375 */     this.numVertices += 3;
/*     */   }
/*     */ 
/*     */   
/*     */   private void pushNewVertexIdxImpl(Vertex paramVertex, AffineTransform paramAffineTransform, Vec4f paramVec4f) {
/* 380 */     pushIndex(this.numVertices);
/* 381 */     pushNewVertexImpl(paramVertex, paramAffineTransform, paramVec4f);
/*     */   }
/*     */   private void pushNewVerticesIdxImpl(Vertex paramVertex1, Vertex paramVertex2, Vertex paramVertex3, AffineTransform paramAffineTransform, Vec4f paramVec4f) {
/* 384 */     pushIndices(this.numVertices, this.numVertices + 1, this.numVertices + 2);
/* 385 */     pushNewVerticesImpl(paramVertex1, paramVertex2, paramVertex3, paramAffineTransform, paramVec4f);
/*     */   }
/*     */   
/*     */   protected static void put3i(IntBuffer paramIntBuffer, int paramInt1, int paramInt2, int paramInt3) {
/* 389 */     paramIntBuffer.put(paramInt1); paramIntBuffer.put(paramInt2); paramIntBuffer.put(paramInt3);
/*     */   }
/*     */   protected static void put3s(ShortBuffer paramShortBuffer, short paramShort1, short paramShort2, short paramShort3) {
/* 392 */     paramShortBuffer.put(paramShort1); paramShortBuffer.put(paramShort2); paramShortBuffer.put(paramShort3);
/*     */   }
/*     */   protected static void put3f(FloatBuffer paramFloatBuffer, Vec3f paramVec3f) {
/* 395 */     paramFloatBuffer.put(paramVec3f.x()); paramFloatBuffer.put(paramVec3f.y()); paramFloatBuffer.put(paramVec3f.z());
/*     */   }
/*     */   protected static void put4f(FloatBuffer paramFloatBuffer, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 398 */     paramFloatBuffer.put(paramFloat1); paramFloatBuffer.put(paramFloat2); paramFloatBuffer.put(paramFloat3); paramFloatBuffer.put(paramFloat4);
/*     */   }
/*     */   protected static void put4f(FloatBuffer paramFloatBuffer, Vec4f paramVec4f) {
/* 401 */     paramFloatBuffer.put(paramVec4f.x()); paramFloatBuffer.put(paramVec4f.y()); paramFloatBuffer.put(paramVec4f.z()); paramFloatBuffer.put(paramVec4f.w());
/*     */   }
/*     */   
/* 404 */   protected Region(int paramInt, boolean paramBoolean) { this.tmpBox = new AABBox();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 442 */     this.perf = null;
/*     */     
/* 444 */     this.perfCounterCtrl = new PerfCounterCtrl()
/*     */       {
/*     */         public void enable(boolean param1Boolean) {
/* 447 */           if (param1Boolean) {
/* 448 */             if (null != Region.this.perf) {
/* 449 */               Region.this.perf.clear();
/*     */             } else {
/* 451 */               Region.this.perf = new Region.Perf();
/*     */             } 
/*     */           } else {
/* 454 */             Region.this.perf = null;
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void clear() {
/* 460 */           if (null != Region.this.perf) {
/* 461 */             Region.this.perf.clear();
/*     */           }
/*     */         }
/*     */ 
/*     */         
/*     */         public long getTotalDuration() {
/* 467 */           if (null != Region.this.perf) {
/* 468 */             return Region.this.perf.td_total;
/*     */           }
/* 470 */           return 0L;
/*     */         }
/*     */ 
/*     */         
/*     */         public void print(PrintStream param1PrintStream)
/*     */         {
/* 476 */           if (null != Region.this.perf)
/* 477 */             Region.this.perf.print(param1PrintStream);  } }; this.renderModes = paramInt; this.use_int32_idx = paramBoolean; if (paramBoolean) { this.max_indices = 536870911; }
/*     */     else
/*     */     { this.max_indices = 65535; }
/* 480 */      this.quality = 1; } public PerfCounterCtrl perfCounter() { return this.perfCounterCtrl; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int[] countOutlineShape(OutlineShape paramOutlineShape, int[] paramArrayOfint) {
/* 500 */     if (null == paramOutlineShape) {
/* 501 */       return paramArrayOfint;
/*     */     }
/* 503 */     ArrayList<Triangle> arrayList = paramOutlineShape.getTriangles(OutlineShape.VerticesState.QUADRATIC_NURBS);
/* 504 */     ArrayList<Vertex> arrayList1 = paramOutlineShape.getVertices();
/*     */     
/* 506 */     paramArrayOfint[0] = paramArrayOfint[0] + arrayList1.size() + paramOutlineShape.getAddedVerticeCount();
/* 507 */     paramArrayOfint[1] = paramArrayOfint[1] + arrayList.size() * 3;
/*     */     
/* 509 */     return paramArrayOfint;
/*     */   }
/*     */   static class Perf {
/*     */     long td_vertices = 0L; long td_tri_push_idx = 0L; long td_tri_push_vertidx = 0L; long td_tri_misc = 0L; long td_tri_total = 0L; long td_total = 0L; long count = 0L; public void print(PrintStream param1PrintStream) { long l1 = this.td_tri_total - this.td_tri_push_vertidx - this.td_tri_push_idx - this.td_tri_misc; long l2 = this.td_total - this.td_tri_total - this.td_vertices;
/*     */       param1PrintStream.printf("Region.add(): count %,3d, total %,5d [ms], per-add %,4.2f [ns]%n", new Object[] { Long.valueOf(this.count), Long.valueOf(TimeUnit.NANOSECONDS.toMillis(this.td_total)), Double.valueOf(this.td_total / this.count) });
/*     */       param1PrintStream.printf("                total self %,5d [ms], per-add %,4.2f [ns]%n", new Object[] { Long.valueOf(TimeUnit.NANOSECONDS.toMillis(l2)), Double.valueOf(l2 / this.count) });
/*     */       param1PrintStream.printf("                  vertices %,5d [ms], per-add %,4.2f [ns]%n", new Object[] { Long.valueOf(TimeUnit.NANOSECONDS.toMillis(this.td_vertices)), Double.valueOf(this.td_vertices / this.count) });
/*     */       param1PrintStream.printf("           triangles total %,5d [ms], per-add %,4.2f [ns]%n", new Object[] { Long.valueOf(TimeUnit.NANOSECONDS.toMillis(this.td_tri_total)), Double.valueOf(this.td_tri_total / this.count) });
/*     */       param1PrintStream.printf("            triangles self %,5d [ms], per-add %,4.2f [ns]%n", new Object[] { Long.valueOf(TimeUnit.NANOSECONDS.toMillis(l1)), Double.valueOf(l1 / this.count) });
/*     */       param1PrintStream.printf("                  tri misc %,5d [ms], per-add %,4.2f [ns]%n", new Object[] { Long.valueOf(TimeUnit.NANOSECONDS.toMillis(this.td_tri_misc)), Double.valueOf(this.td_tri_misc / this.count) });
/*     */       param1PrintStream.printf("                 tri p-idx %,5d [ms], per-add %,4.2f [ns]%n", new Object[] { Long.valueOf(TimeUnit.NANOSECONDS.toMillis(this.td_tri_push_idx)), Double.valueOf(this.td_tri_push_idx / this.count) });
/*     */       param1PrintStream.printf("             tri p-vertidx %,5d [ms], per-add %,4.2f [ns]%n", new Object[] { Long.valueOf(TimeUnit.NANOSECONDS.toMillis(this.td_tri_push_vertidx)), Double.valueOf(this.td_tri_push_vertidx / this.count) }); } public void clear() { this.td_vertices = 0L;
/*     */       this.td_tri_push_idx = 0L;
/*     */       this.td_tri_push_vertidx = 0L;
/*     */       this.td_tri_misc = 0L;
/*     */       this.td_tri_total = 0L;
/*     */       this.td_total = 0L;
/* 526 */       this.count = 0L; } } public static final int[] countOutlineShapes(List<OutlineShape> paramList, int[] paramArrayOfint) { for (byte b = 0; b < paramList.size(); b++) {
/* 527 */       countOutlineShape(paramList.get(b), paramArrayOfint);
/*     */     }
/* 529 */     return paramArrayOfint; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addOutlineShape(OutlineShape paramOutlineShape, AffineTransform paramAffineTransform, Vec4f paramVec4f) {
/* 544 */     if (null != this.frustum) {
/* 545 */       AABBox aABBox2, aABBox1 = paramOutlineShape.getBounds();
/*     */       
/* 547 */       if (null != paramAffineTransform) {
/* 548 */         paramAffineTransform.transform(aABBox1, this.tmpBox);
/* 549 */         aABBox2 = this.tmpBox;
/*     */       } else {
/* 551 */         aABBox2 = aABBox1;
/*     */       } 
/* 553 */       if (this.frustum.isAABBoxOutside(aABBox2)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 557 */     if (null == this.perf && !DEBUG_INSTANCE) {
/* 558 */       addOutlineShape0(paramOutlineShape, paramAffineTransform, paramVec4f);
/*     */     } else {
/* 560 */       if (null == this.perf) {
/* 561 */         perfCounter().enable(true);
/*     */       }
/* 563 */       addOutlineShape1(paramOutlineShape, paramAffineTransform, paramVec4f);
/*     */     } 
/* 565 */     markShapeDirty();
/*     */   }
/*     */   private final void addOutlineShape0(OutlineShape paramOutlineShape, AffineTransform paramAffineTransform, Vec4f paramVec4f) {
/* 568 */     ArrayList<Triangle> arrayList = paramOutlineShape.getTriangles(OutlineShape.VerticesState.QUADRATIC_NURBS);
/* 569 */     ArrayList<Vertex> arrayList1 = paramOutlineShape.getVertices();
/*     */     
/* 571 */     int i = arrayList1.size() + paramOutlineShape.getAddedVerticeCount();
/* 572 */     int j = arrayList.size() * 3;
/* 573 */     growBuffer(i, j);
/*     */ 
/*     */     
/* 576 */     i = this.numVertices;
/* 577 */     if (arrayList1.size() >= 3) {
/*     */ 
/*     */ 
/*     */       
/* 581 */       for (j = 0; j < arrayList1.size(); j++) {
/* 582 */         pushNewVertexImpl(arrayList1.get(j), paramAffineTransform, paramVec4f);
/*     */       }
/* 584 */       j = arrayList.size();
/* 585 */       for (byte b = 0; b < j; b++) {
/* 586 */         Triangle triangle = arrayList.get(b);
/*     */ 
/*     */         
/* 589 */         Vertex[] arrayOfVertex = triangle.getVertices();
/* 590 */         int k = arrayOfVertex[0].getId();
/*     */         
/* 592 */         if (this.max_indices - i > k) {
/*     */           
/* 594 */           pushIndices(k + i, arrayOfVertex[1]
/* 595 */               .getId() + i, arrayOfVertex[2]
/* 596 */               .getId() + i);
/*     */         } else {
/*     */           
/* 599 */           pushNewVerticesIdxImpl(arrayOfVertex[0], arrayOfVertex[1], arrayOfVertex[2], paramAffineTransform, paramVec4f);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private final void addOutlineShape1(OutlineShape paramOutlineShape, AffineTransform paramAffineTransform, Vec4f paramVec4f) {
/* 605 */     this.perf.count++;
/* 606 */     long l = Clock.currentNanos();
/* 607 */     ArrayList<Triangle> arrayList = paramOutlineShape.getTriangles(OutlineShape.VerticesState.QUADRATIC_NURBS);
/* 608 */     ArrayList<Vertex> arrayList1 = paramOutlineShape.getVertices();
/*     */     
/* 610 */     int i = paramOutlineShape.getAddedVerticeCount();
/* 611 */     int j = arrayList1.size() + i;
/* 612 */     int k = arrayList.size() * 3;
/* 613 */     if (DEBUG_INSTANCE) {
/* 614 */       System.err.println("Region.addOutlineShape().0: tris: " + arrayList.size() + ", verts " + arrayList1.size() + ", transform " + paramAffineTransform);
/* 615 */       System.err.println("Region.addOutlineShape().0: VerticeCount " + arrayList1.size() + " + " + i + " = " + j);
/* 616 */       System.err.println("Region.addOutlineShape().0: IndexCount " + k);
/*     */     } 
/* 618 */     growBuffer(j, k);
/*     */ 
/*     */     
/* 621 */     i = this.numVertices;
/* 622 */     j = 0; k = 0; byte b1 = 0, b2 = 0;
/*     */     
/* 624 */     if (arrayList1.size() >= 3) {
/*     */ 
/*     */ 
/*     */       
/* 628 */       for (byte b3 = 0; b3 < arrayList1.size(); b3++) {
/* 629 */         pushNewVertexImpl(arrayList1.get(b3), paramAffineTransform, paramVec4f);
/* 630 */         j++;
/*     */       } 
/* 632 */       long l1 = Clock.currentNanos();
/* 633 */       this.perf.td_vertices += l1 - l;
/*     */ 
/*     */ 
/*     */       
/* 637 */       int m = arrayList.size();
/* 638 */       for (byte b4 = 0; b4 < m; b4++) {
/* 639 */         Triangle triangle = arrayList.get(b4);
/* 640 */         long l3 = Clock.currentNanos();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 646 */         Vertex[] arrayOfVertex = triangle.getVertices();
/* 647 */         int n = arrayOfVertex[0].getId();
/*     */         
/* 649 */         this.perf.td_tri_misc += Clock.currentNanos() - l3;
/* 650 */         if (this.max_indices - i > n) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 655 */           long l4 = Clock.currentNanos();
/* 656 */           pushIndices(n + i, arrayOfVertex[1]
/* 657 */               .getId() + i, arrayOfVertex[2]
/* 658 */               .getId() + i);
/* 659 */           this.perf.td_tri_push_idx += Clock.currentNanos() - l4;
/* 660 */           k += 3;
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 666 */           long l4 = Clock.currentNanos();
/* 667 */           pushNewVerticesIdxImpl(arrayOfVertex[0], arrayOfVertex[1], arrayOfVertex[2], paramAffineTransform, paramVec4f);
/* 668 */           this.perf.td_tri_push_vertidx += Clock.currentNanos() - l4;
/* 669 */           b1 += true;
/*     */         } 
/* 671 */         b2++;
/*     */       } 
/* 673 */       long l2 = Clock.currentNanos();
/* 674 */       this.perf.td_tri_total += l2 - l1;
/* 675 */       this.perf.td_total += l2 - l;
/*     */     } 
/* 677 */     if (DEBUG_INSTANCE) {
/* 678 */       System.err.println("Region.addOutlineShape().X: idx[ui32 " + usesI32Idx() + ", offset " + i + "], tris: " + b2 + ", verts [idx " + b1 + ", add " + b1 + " = " + (j + b1) + "]");
/* 679 */       System.err.println("Region.addOutlineShape().X: verts: idx[v-new " + j + ", t-new " + b1 + " = " + (j + b1) + "]");
/* 680 */       System.err.println("Region.addOutlineShape().X: verts: idx t-moved " + k + ", numVertices " + this.numVertices);
/* 681 */       System.err.println("Region.addOutlineShape().X: verts: v-dups 0, t-dups 0, t-known 0");
/*     */       
/* 683 */       System.err.println("Region.addOutlineShape().X: box " + this.box);
/* 684 */       printBufferStats(System.err);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addOutlineShapes(List<OutlineShape> paramList, AffineTransform paramAffineTransform, Vec4f paramVec4f) {
/* 700 */     for (byte b = 0; b < paramList.size(); b++) {
/* 701 */       addOutlineShape(paramList.get(b), paramAffineTransform, paramVec4f);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final AABBox getBounds() {
/* 707 */     return this.box;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void markShapeDirty() {
/* 721 */     this.dirty |= 0x1;
/*     */   }
/*     */   
/*     */   public final boolean isShapeDirty() {
/* 725 */     return (0 != (this.dirty & 0x1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void markStateDirty() {
/* 735 */     this.dirty |= 0x2;
/*     */   }
/*     */   
/*     */   public final boolean isStateDirty() {
/* 739 */     return (0 != (this.dirty & 0x2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void clearDirtyBits(int paramInt) {
/* 746 */     this.dirty &= paramInt ^ 0xFFFFFFFF;
/*     */   } protected final int getDirtyBits() {
/* 748 */     return this.dirty;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 752 */     return "Region[0x" + Integer.toHexString(hashCode()) + ", " + getRenderModeString(this.renderModes) + ", q " + this.quality + ", dirty " + this.dirty + ", vertices " + this.numVertices + ", box " + this.box + "]";
/*     */   }
/*     */   
/*     */   public abstract void printBufferStats(PrintStream paramPrintStream);
/*     */   
/*     */   public abstract boolean growBuffer(int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract boolean setBufferCapacity(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract void pushVertex(Vec3f paramVec3f1, Vec3f paramVec3f2, Vec4f paramVec4f);
/*     */   
/*     */   protected abstract void pushVertices(Vec3f paramVec3f1, Vec3f paramVec3f2, Vec3f paramVec3f3, Vec3f paramVec3f4, Vec3f paramVec3f5, Vec3f paramVec3f6, Vec4f paramVec4f);
/*     */   
/*     */   protected abstract void pushIndex(int paramInt);
/*     */   
/*     */   protected abstract void pushIndices(int paramInt1, int paramInt2, int paramInt3);
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/Region.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */