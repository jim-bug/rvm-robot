/*    */ package com.jogamp.graph.curve;
/*    */ 
/*    */ import com.jogamp.graph.geom.plane.AffineTransform;
/*    */ 
/*    */ public class OutlineShapeXForm {
/*    */   public final OutlineShape shape;
/*    */   private AffineTransform t;
/*    */   
/*    */   public OutlineShapeXForm(OutlineShape paramOutlineShape, AffineTransform paramAffineTransform) {
/* 10 */     this.shape = paramOutlineShape;
/* 11 */     this.t = paramAffineTransform;
/*    */   }
/*    */   
/* 14 */   public final AffineTransform getTransform() { return this.t; } public final void setTransform(AffineTransform paramAffineTransform) {
/* 15 */     this.t = paramAffineTransform;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/OutlineShapeXForm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */