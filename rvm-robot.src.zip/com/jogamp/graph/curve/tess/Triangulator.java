package com.jogamp.graph.curve.tess;

import com.jogamp.graph.geom.Outline;
import com.jogamp.graph.geom.Triangle;
import java.util.List;

public interface Triangulator {
  void addCurve(List<Triangle> paramList, Outline paramOutline, float paramFloat);
  
  void generate(List<Triangle> paramList);
  
  void reset();
  
  int getAddedVerticeCount();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/tess/Triangulator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */