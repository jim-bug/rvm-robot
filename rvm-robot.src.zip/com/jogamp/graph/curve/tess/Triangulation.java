/*    */ package com.jogamp.graph.curve.tess;
/*    */ 
/*    */ import jogamp.graph.curve.tess.CDTriangulator2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Triangulation
/*    */ {
/*    */   public static Triangulator create() {
/* 42 */     return (Triangulator)new CDTriangulator2D();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/tess/Triangulation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */