/*     */ package com.jogamp.graph.curve.opengl;
/*     */ 
/*     */ import com.jogamp.graph.curve.Region;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLException;
/*     */ import com.jogamp.opengl.GLUniformData;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.util.GLArrayDataWrapper;
/*     */ import com.jogamp.opengl.util.PMVMatrix;
/*     */ import com.jogamp.opengl.util.SyncBuffer;
/*     */ import com.jogamp.opengl.util.glsl.ShaderProgram;
/*     */ import java.nio.FloatBuffer;
/*     */ import jogamp.common.os.PlatformPropsImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderState
/*     */ {
/*     */   private static final String thisKey = "jogamp.graph.curve.RenderState";
/*     */   public static final int BITHINT_BLENDING_ENABLED = 1;
/*     */   public static final int BITHINT_GLOBAL_DEPTH_TEST_ENABLED = 2;
/*     */   private final PMVMatrix pmvMatrix;
/*     */   private final float[] weight;
/*     */   private final FloatBuffer weightBuffer;
/*     */   private final float[] colorStatic;
/*     */   private final FloatBuffer colorStaticBuffer;
/*     */   private ShaderProgram sp;
/*     */   private int hintBitfield;
/*     */   private final int id;
/*     */   
/*     */   public static final RenderState getRenderState(GL2ES2 paramGL2ES2) {
/*  91 */     return (RenderState)paramGL2ES2.getContext().getAttachedObject("jogamp.graph.curve.RenderState");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized int getNextID() {
/* 104 */     return nextID++;
/*     */   }
/* 106 */   private static int nextID = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ProgramLocal
/*     */   {
/*     */     public final GLUniformData gcu_PMVMatrix01;
/*     */ 
/*     */     
/*     */     public final GLUniformData gcu_Weight;
/*     */     
/*     */     public final GLUniformData gcu_ColorStatic;
/*     */     
/* 119 */     private int rsId = -1;
/*     */     
/*     */     public ProgramLocal() {
/* 122 */       this.gcu_PMVMatrix01 = GLUniformData.creatEmptyMatrix("gcu_PMVMatrix01", 4, 4);
/* 123 */       this.gcu_Weight = GLUniformData.creatEmptyVector("gcu_Weight", 1);
/* 124 */       this.gcu_ColorStatic = GLUniformData.creatEmptyVector("gcu_ColorStatic", 4);
/*     */     }
/*     */     public final int getRenderStateId() {
/* 127 */       return this.rsId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean update(GL2ES2 param1GL2ES2, RenderState param1RenderState, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3) {
/* 141 */       if (param1RenderState.id() != this.rsId) {
/*     */         
/* 143 */         this.gcu_PMVMatrix01.setData((SyncBuffer)param1RenderState.pmvMatrix.getSyncPMvMat());
/* 144 */         this.gcu_Weight.setData(param1RenderState.weightBuffer);
/* 145 */         this.gcu_ColorStatic.setData(param1RenderState.colorStaticBuffer);
/* 146 */         this.rsId = param1RenderState.id();
/*     */       } 
/* 148 */       boolean bool = true;
/* 149 */       if (null != param1RenderState.sp && param1RenderState.sp.inUse()) {
/* 150 */         if (!Region.isTwoPass(param1Int) || !param1Boolean2) {
/* 151 */           boolean bool1 = param1RenderState.updateUniformDataLoc(param1GL2ES2, param1Boolean1, true, this.gcu_PMVMatrix01, param1Boolean3);
/* 152 */           bool = (bool && bool1) ? true : false;
/*     */         } 
/* 154 */         if (param1Boolean2) {
/* 155 */           if (Region.hasVariableWeight(param1Int)) {
/* 156 */             boolean bool2 = param1RenderState.updateUniformDataLoc(param1GL2ES2, param1Boolean1, true, this.gcu_Weight, param1Boolean3);
/* 157 */             bool = (bool && bool2) ? true : false;
/*     */           } 
/*     */           
/* 160 */           boolean bool1 = param1RenderState.updateUniformDataLoc(param1GL2ES2, param1Boolean1, true, this.gcu_ColorStatic, param1Boolean3);
/* 161 */           bool = (bool && bool1) ? true : false;
/*     */         } 
/*     */       } 
/*     */       
/* 165 */       return bool;
/*     */     }
/*     */     
/*     */     public StringBuilder toString(StringBuilder param1StringBuilder, boolean param1Boolean) {
/* 169 */       if (null == param1StringBuilder) {
/* 170 */         param1StringBuilder = new StringBuilder();
/*     */       }
/* 172 */       param1StringBuilder.append("ProgramLocal[rsID ").append(this.rsId).append(PlatformPropsImpl.NEWLINE);
/*     */       
/* 174 */       param1StringBuilder.append(this.gcu_PMVMatrix01).append(", ").append(PlatformPropsImpl.NEWLINE);
/* 175 */       param1StringBuilder.append(this.gcu_ColorStatic).append(", ");
/* 176 */       param1StringBuilder.append(this.gcu_Weight).append("]");
/* 177 */       return param1StringBuilder;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 182 */       return toString(null, false).toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RenderState(PMVMatrix paramPMVMatrix) {
/* 191 */     this.id = getNextID();
/* 192 */     this.sp = null;
/* 193 */     this.pmvMatrix = (null != paramPMVMatrix) ? paramPMVMatrix : new PMVMatrix();
/* 194 */     this.weight = new float[1];
/* 195 */     this.weightBuffer = FloatBuffer.wrap(this.weight);
/* 196 */     this.colorStatic = new float[] { 1.0F, 1.0F, 1.0F, 1.0F };
/* 197 */     this.colorStaticBuffer = FloatBuffer.wrap(this.colorStatic);
/* 198 */     this.hintBitfield = 0;
/*     */   }
/*     */   public final int id() {
/* 201 */     return this.id;
/*     */   }
/*     */   public final ShaderProgram getShaderProgram() {
/* 204 */     return this.sp;
/*     */   }
/*     */   public final boolean isShaderProgramInUse() {
/* 207 */     return (null != this.sp) ? this.sp.inUse() : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean setShaderProgram(GL2ES2 paramGL2ES2, ShaderProgram paramShaderProgram) {
/* 220 */     if (paramShaderProgram.equals(this.sp)) {
/* 221 */       paramShaderProgram.useProgram(paramGL2ES2, true);
/* 222 */       return false;
/*     */     } 
/* 224 */     if (null != this.sp) {
/* 225 */       this.sp.notifyNotInUse();
/*     */     }
/* 227 */     this.sp = paramShaderProgram;
/* 228 */     paramShaderProgram.useProgram(paramGL2ES2, true);
/* 229 */     return true;
/*     */   }
/*     */   public final PMVMatrix getMatrix() {
/* 232 */     return this.pmvMatrix;
/*     */   }
/*     */   public static boolean isWeightValid(float paramFloat) {
/* 235 */     return (0.0F <= paramFloat && paramFloat <= 1.9F);
/*     */   } public final float getWeight() {
/* 237 */     return this.weight[0];
/*     */   } public final void setWeight(float paramFloat) {
/* 239 */     if (!isWeightValid(paramFloat)) {
/* 240 */       throw new IllegalArgumentException("Weight out of range");
/*     */     }
/* 242 */     this.weight[0] = paramFloat;
/*     */   }
/*     */   
/*     */   public final Vec4f getColorStatic(Vec4f paramVec4f) {
/* 246 */     return paramVec4f.set(this.colorStatic);
/*     */   }
/*     */   public final void setColorStatic(Vec4f paramVec4f) {
/* 249 */     this.colorStatic[0] = paramVec4f.x();
/* 250 */     this.colorStatic[1] = paramVec4f.y();
/* 251 */     this.colorStatic[2] = paramVec4f.z();
/* 252 */     this.colorStatic[3] = paramVec4f.w();
/*     */   }
/*     */   public final void setColorStatic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 255 */     this.colorStatic[0] = paramFloat1;
/* 256 */     this.colorStatic[1] = paramFloat2;
/* 257 */     this.colorStatic[2] = paramFloat3;
/* 258 */     this.colorStatic[3] = paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean updateUniformLoc(GL2ES2 paramGL2ES2, boolean paramBoolean1, GLUniformData paramGLUniformData, boolean paramBoolean2) {
/* 271 */     if (paramBoolean1 || 0 > paramGLUniformData.getLocation()) {
/* 272 */       boolean bool = (0 <= paramGLUniformData.setLocation(paramGL2ES2, this.sp.program())) ? true : false;
/* 273 */       if (paramBoolean2 && !bool) {
/* 274 */         this.sp.dumpSource(System.err);
/* 275 */         throw new GLException("Could not locate " + paramGLUniformData.getName() + " in " + this.sp + ", " + paramGLUniformData);
/*     */       } 
/* 277 */       return bool;
/*     */     } 
/* 279 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean updateUniformDataLoc(GL2ES2 paramGL2ES2, boolean paramBoolean1, boolean paramBoolean2, GLUniformData paramGLUniformData, boolean paramBoolean3) {
/* 293 */     paramBoolean1 = (paramBoolean1 || 0 > paramGLUniformData.getLocation());
/* 294 */     if (paramBoolean1) {
/* 295 */       paramBoolean2 = (0 <= paramGLUniformData.setLocation(paramGL2ES2, this.sp.program()));
/* 296 */       if (paramBoolean3 && !paramBoolean2) {
/* 297 */         this.sp.dumpSource(System.err);
/* 298 */         throw new GLException("Could not locate " + paramGLUniformData.getName() + " in " + this.sp + ", " + paramGLUniformData);
/*     */       } 
/*     */     } 
/* 301 */     if (paramBoolean2) {
/* 302 */       paramGL2ES2.glUniform(paramGLUniformData);
/* 303 */       return true;
/*     */     } 
/* 305 */     return !paramBoolean1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean updateAttributeLoc(GL2ES2 paramGL2ES2, boolean paramBoolean1, GLArrayDataWrapper paramGLArrayDataWrapper, boolean paramBoolean2) {
/* 316 */     if (paramBoolean1 || 0 > paramGLArrayDataWrapper.getLocation()) {
/* 317 */       boolean bool = (0 <= paramGLArrayDataWrapper.setLocation(paramGL2ES2, this.sp.program())) ? true : false;
/* 318 */       if (paramBoolean2 && !bool) {
/* 319 */         this.sp.dumpSource(System.err);
/* 320 */         throw new GLException("Could not locate " + paramGLArrayDataWrapper.getName() + " in " + this.sp + ", " + paramGLArrayDataWrapper);
/*     */       } 
/* 322 */       return bool;
/*     */     } 
/* 324 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isHintMaskSet(int paramInt) {
/* 330 */     return (paramInt == (this.hintBitfield & paramInt));
/*     */   }
/*     */   public final void setHintMask(int paramInt) {
/* 333 */     this.hintBitfield |= paramInt;
/*     */   }
/*     */   public final void clearHintMask(int paramInt) {
/* 336 */     this.hintBitfield &= paramInt ^ 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void destroy() {
/* 343 */     this.sp = null;
/*     */   }
/*     */   
/*     */   public final RenderState attachTo(GL2ES2 paramGL2ES2) {
/* 347 */     return (RenderState)paramGL2ES2.getContext().attachObject("jogamp.graph.curve.RenderState", this);
/*     */   }
/*     */   
/*     */   public final boolean detachFrom(GL2ES2 paramGL2ES2) {
/* 351 */     RenderState renderState = (RenderState)paramGL2ES2.getContext().getAttachedObject("jogamp.graph.curve.RenderState");
/* 352 */     if (renderState == this) {
/* 353 */       paramGL2ES2.getContext().detachObject("jogamp.graph.curve.RenderState");
/* 354 */       return true;
/*     */     } 
/* 356 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 361 */     return "RenderState[" + this.sp + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/opengl/RenderState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */