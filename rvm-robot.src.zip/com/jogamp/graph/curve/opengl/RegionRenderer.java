/*     */ package com.jogamp.graph.curve.opengl;
/*     */ 
/*     */ import com.jogamp.common.os.Platform;
/*     */ import com.jogamp.common.util.IntObjectHashMap;
/*     */ import com.jogamp.graph.curve.Region;
/*     */ import com.jogamp.opengl.GL;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLException;
/*     */ import com.jogamp.opengl.math.Recti;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.util.PMVMatrix;
/*     */ import com.jogamp.opengl.util.glsl.ShaderCode;
/*     */ import com.jogamp.opengl.util.glsl.ShaderProgram;
/*     */ import com.jogamp.opengl.util.texture.TextureSequence;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import jogamp.graph.curve.opengl.shader.AttributeNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RegionRenderer
/*     */ {
/*  67 */   protected static final boolean DEBUG = Region.DEBUG;
/*  68 */   protected static final boolean DEBUG_INSTANCE = Region.DEBUG_INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public static final GLCallback defaultBlendEnable = new GLCallback()
/*     */     {
/*     */       public void run(GL param1GL, RegionRenderer param1RegionRenderer) {
/* 103 */         if (param1RegionRenderer.isHintMaskSet(2)) {
/* 104 */           param1GL.glDepthMask(false);
/*     */         }
/*     */ 
/*     */         
/* 108 */         param1GL.glEnable(3042);
/* 109 */         param1GL.glBlendEquation(32774);
/* 110 */         param1RegionRenderer.setHintMask(1);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public static final GLCallback defaultBlendDisable = new GLCallback()
/*     */     {
/*     */       public void run(GL param1GL, RegionRenderer param1RegionRenderer) {
/* 127 */         param1RegionRenderer.clearHintMask(1);
/* 128 */         param1GL.glDisable(3042);
/* 129 */         if (param1RegionRenderer.isHintMaskSet(2))
/*     */         {
/*     */           
/* 132 */           param1GL.glDepthMask(true);
/*     */         }
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private final RenderState rs;
/*     */ 
/*     */   
/*     */   private final GLCallback enableCallback;
/*     */ 
/*     */   
/*     */   private final GLCallback disableCallback;
/*     */ 
/*     */   
/*     */   public static RegionRenderer create() {
/* 149 */     return new RegionRenderer(null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegionRenderer create(GLCallback paramGLCallback1, GLCallback paramGLCallback2) {
/* 168 */     return new RegionRenderer(paramGLCallback1, paramGLCallback2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegionRenderer create(PMVMatrix paramPMVMatrix, GLCallback paramGLCallback1, GLCallback paramGLCallback2) {
/* 189 */     return new RegionRenderer(paramPMVMatrix, paramGLCallback1, paramGLCallback2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   private final Recti viewport = new Recti(); private boolean initialized; private boolean vboSupported = false; private static final String SHADER_SRC_SUB = ""; private static final String SHADER_BIN_SUB = "bin"; private static final String GLSL_USE_COLOR_CHANNEL = "#define USE_COLOR_CHANNEL 1\n"; private static final String GLSL_USE_COLOR_TEXTURE = "#define USE_COLOR_TEXTURE 1\n";
/*     */   private static final String GLSL_DEF_SAMPLE_COUNT = "#define SAMPLE_COUNT ";
/*     */   
/*     */   public final boolean isInitialized() {
/* 201 */     return this.initialized;
/*     */   }
/*     */   private static final String GLSL_CONST_SAMPLE_COUNT = "const float sample_count = "; private static final String GLSL_MAIN_BEGIN = "void main (void)\n{\n"; private static final String gcuTexture2D = "gcuTexture2D"; private static final String GLSL_USE_DISCARD = "#define USE_DISCARD 1\n"; private static final String es2_precision_fp = "\nprecision mediump float;\nprecision mediump int;\nprecision mediump sampler2D;\n"; private final IntObjectHashMap shaderPrograms; private static final int HIGH_MASK = 1536; private static final int TWO_PASS_BIT = -2147483648;
/*     */   public final Recti getViewport(Recti paramRecti) {
/* 205 */     paramRecti.set(this.viewport);
/* 206 */     return paramRecti;
/*     */   }
/*     */   
/*     */   public final Recti getViewport() {
/* 210 */     return this.viewport;
/*     */   }
/*     */   public final int getWidth() {
/* 213 */     return this.viewport.width();
/*     */   } public final int getHeight() {
/* 215 */     return this.viewport.height();
/*     */   }
/*     */ 
/*     */   
/*     */   protected RegionRenderer(GLCallback paramGLCallback1, GLCallback paramGLCallback2) {
/* 220 */     this(null, paramGLCallback1, paramGLCallback2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isVBOSupported() {
/* 231 */     return this.vboSupported;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void init(GL2ES2 paramGL2ES2) throws GLException {
/* 243 */     if (this.initialized) {
/*     */       return;
/*     */     }
/* 246 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 251 */       .vboSupported = (paramGL2ES2.isFunctionAvailable("glGenBuffers") && paramGL2ES2.isFunctionAvailable("glBindBuffer") && paramGL2ES2.isFunctionAvailable("glBufferData") && paramGL2ES2.isFunctionAvailable("glDrawElements") && paramGL2ES2.isFunctionAvailable("glVertexAttribPointer") && paramGL2ES2.isFunctionAvailable("glDeleteBuffers"));
/*     */     
/* 253 */     if (DEBUG) {
/* 254 */       System.err.println("TextRendererImpl01: VBO Supported = " + isVBOSupported());
/*     */     }
/*     */     
/* 257 */     if (!this.vboSupported) {
/* 258 */       throw new GLException("VBO not supported");
/*     */     }
/*     */     
/* 261 */     this.rs.attachTo(paramGL2ES2);
/*     */     
/* 263 */     this.initialized = true;
/* 264 */     enable(paramGL2ES2, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void destroy(GL2ES2 paramGL2ES2) {
/* 269 */     if (!this.initialized) {
/* 270 */       if (DEBUG_INSTANCE) {
/* 271 */         System.err.println("TextRenderer: Not initialized!");
/*     */       }
/*     */       return;
/*     */     } 
/* 275 */     for (Iterator<IntObjectHashMap.Entry> iterator = this.shaderPrograms.iterator(); iterator.hasNext(); ) {
/* 276 */       ShaderProgram shaderProgram = (ShaderProgram)((IntObjectHashMap.Entry)iterator.next()).getValue();
/* 277 */       shaderProgram.destroy(paramGL2ES2);
/*     */     } 
/* 279 */     this.shaderPrograms.clear();
/* 280 */     this.rs.detachFrom(paramGL2ES2);
/* 281 */     this.rs.destroy();
/* 282 */     this.initialized = false;
/*     */   }
/*     */   
/*     */   public final RenderState getRenderState() {
/* 286 */     return this.rs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PMVMatrix getMatrix() {
/* 293 */     return this.rs.getMatrix();
/*     */   } public final float getWeight() {
/* 295 */     return this.rs.getWeight();
/*     */   } public final void setWeight(float paramFloat) {
/* 297 */     this.rs.setWeight(paramFloat);
/*     */   } public final Vec4f getColorStatic(Vec4f paramVec4f) {
/* 299 */     return this.rs.getColorStatic(paramVec4f);
/*     */   } public final void setColorStatic(Vec4f paramVec4f) {
/* 301 */     this.rs.setColorStatic(paramVec4f);
/*     */   } public final void setColorStatic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 303 */     this.rs.setColorStatic(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   } public final boolean isHintMaskSet(int paramInt) {
/* 305 */     return this.rs.isHintMaskSet(paramInt);
/*     */   } public final void setHintMask(int paramInt) {
/* 307 */     this.rs.setHintMask(paramInt);
/*     */   } public final void clearHintMask(int paramInt) {
/* 309 */     this.rs.clearHintMask(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void enable(GL2ES2 paramGL2ES2, boolean paramBoolean) {
/* 331 */     enable(paramGL2ES2, paramBoolean, this.enableCallback, this.disableCallback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void enable(GL2ES2 paramGL2ES2, boolean paramBoolean, GLCallback paramGLCallback1, GLCallback paramGLCallback2) {
/* 343 */     if (paramBoolean) {
/* 344 */       if (null != paramGLCallback1) {
/* 345 */         paramGLCallback1.run((GL)paramGL2ES2, this);
/*     */       }
/*     */     } else {
/* 348 */       if (null != paramGLCallback2) {
/* 349 */         paramGLCallback2.run((GL)paramGL2ES2, this);
/*     */       }
/* 351 */       ShaderProgram shaderProgram = this.rs.getShaderProgram();
/* 352 */       if (null != shaderProgram) {
/* 353 */         shaderProgram.useProgram(paramGL2ES2, false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void reshapeNotify(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 362 */     this.viewport.set(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public final void reshapePerspective(float paramFloat1, int paramInt1, int paramInt2, float paramFloat2, float paramFloat3) {
/* 366 */     reshapeNotify(0, 0, paramInt1, paramInt2);
/* 367 */     float f = paramInt1 / paramInt2;
/* 368 */     PMVMatrix pMVMatrix = getMatrix();
/* 369 */     pMVMatrix.glMatrixMode(5889);
/* 370 */     pMVMatrix.glLoadIdentity();
/* 371 */     pMVMatrix.gluPerspective(paramFloat1, f, paramFloat2, paramFloat3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void reshapeOrtho(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
/* 378 */     reshapeNotify(0, 0, paramInt1, paramInt2);
/* 379 */     PMVMatrix pMVMatrix = getMatrix();
/* 380 */     pMVMatrix.glMatrixMode(5889);
/* 381 */     pMVMatrix.glLoadIdentity();
/* 382 */     pMVMatrix.glOrthof(0.0F, paramInt1, 0.0F, paramInt2, paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getVersionedShaderName() {
/* 401 */     return "curverenderer01";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getFragmentShaderPrecision(GL2ES2 paramGL2ES2) {
/* 408 */     if (paramGL2ES2.isGLES()) {
/* 409 */       return "\nprecision mediump float;\nprecision mediump int;\nprecision mediump sampler2D;\n";
/*     */     }
/* 411 */     if (ShaderCode.requiresGL3DefaultPrecision(paramGL2ES2)) {
/* 412 */       return "\nprecision highp float;\nprecision mediump int;\n/*precision mediump sampler2D;*/\n";
/*     */     }
/* 414 */     return null;
/*     */   }
/*     */   
/*     */   private enum ShaderModeSelector1
/*     */   {
/* 419 */     PASS1_SIMPLE("curve", "_simple", 0),
/*     */     
/* 421 */     PASS1_WEIGHT("curve", "_weight", 0),
/*     */     
/* 423 */     PASS2_MSAA("msaa", "", 0),
/*     */     
/* 425 */     PASS2_VBAA_QUAL0_SAMPLES1("vbaa", "_flipquad3", 1),
/*     */     
/* 427 */     PASS2_VBAA_QUAL0_SAMPLES2("vbaa", "_flipquad3", 2),
/*     */     
/* 429 */     PASS2_VBAA_QUAL0_SAMPLES4("vbaa", "_flipquad3", 4),
/*     */     
/* 431 */     PASS2_VBAA_QUAL0_SAMPLES8("vbaa", "_flipquad3", 8),
/*     */ 
/*     */     
/* 434 */     PASS2_VBAA_QUAL1_SAMPLES1("vbaa", "_bforce_odd", 1),
/*     */     
/* 436 */     PASS2_VBAA_QUAL1_SAMPLES2("vbaa", "_bforce_even", 2),
/*     */     
/* 438 */     PASS2_VBAA_QUAL1_SAMPLES3("vbaa", "_bforce_odd", 3),
/*     */     
/* 440 */     PASS2_VBAA_QUAL1_SAMPLES4("vbaa", "_bforce_even", 4),
/*     */     
/* 442 */     PASS2_VBAA_QUAL1_SAMPLES5("vbaa", "_bforce_odd", 5),
/*     */     
/* 444 */     PASS2_VBAA_QUAL1_SAMPLES6("vbaa", "_bforce_even", 6),
/*     */     
/* 446 */     PASS2_VBAA_QUAL1_SAMPLES7("vbaa", "_bforce_odd", 7),
/*     */     
/* 448 */     PASS2_VBAA_QUAL1_SAMPLES8("vbaa", "_bforce_even", 8);
/*     */     
/*     */     public final String tech;
/*     */     public final String sub;
/*     */     public final int sampleCount;
/*     */     
/*     */     ShaderModeSelector1(String param1String1, String param1String2, int param1Int1) {
/* 455 */       this.tech = param1String1;
/* 456 */       this.sub = param1String2;
/* 457 */       this.sampleCount = param1Int1;
/*     */     }
/*     */     
/*     */     public static ShaderModeSelector1 selectPass1(int param1Int) {
/* 461 */       return Region.hasVariableWeight(param1Int) ? PASS1_WEIGHT : PASS1_SIMPLE;
/*     */     }
/*     */     
/*     */     public static ShaderModeSelector1 selectPass2(int param1Int1, int param1Int2, int param1Int3) {
/* 465 */       if (Region.isMSAA(param1Int1))
/* 466 */         return PASS2_MSAA; 
/* 467 */       if (Region.isVBAA(param1Int1)) {
/* 468 */         if (0 == param1Int2) {
/* 469 */           if (param1Int3 < 2)
/* 470 */             return PASS2_VBAA_QUAL0_SAMPLES1; 
/* 471 */           if (param1Int3 < 4)
/* 472 */             return PASS2_VBAA_QUAL0_SAMPLES2; 
/* 473 */           if (param1Int3 < 8) {
/* 474 */             return PASS2_VBAA_QUAL0_SAMPLES4;
/*     */           }
/* 476 */           return PASS2_VBAA_QUAL0_SAMPLES8;
/*     */         } 
/*     */         
/* 479 */         switch (param1Int3) { case 0:
/*     */           case 1:
/* 481 */             return PASS2_VBAA_QUAL1_SAMPLES1;
/* 482 */           case 2: return PASS2_VBAA_QUAL1_SAMPLES2;
/* 483 */           case 3: return PASS2_VBAA_QUAL1_SAMPLES3;
/* 484 */           case 4: return PASS2_VBAA_QUAL1_SAMPLES4;
/* 485 */           case 5: return PASS2_VBAA_QUAL1_SAMPLES5;
/* 486 */           case 6: return PASS2_VBAA_QUAL1_SAMPLES6;
/* 487 */           case 7: return PASS2_VBAA_QUAL1_SAMPLES7; }
/* 488 */          return PASS2_VBAA_QUAL1_SAMPLES8;
/*     */       } 
/*     */ 
/*     */       
/* 492 */       return null;
/*     */     } }
/*     */   
/*     */   protected RegionRenderer(PMVMatrix paramPMVMatrix, GLCallback paramGLCallback1, GLCallback paramGLCallback2) {
/* 496 */     this.shaderPrograms = new IntObjectHashMap();
/*     */     this.rs = new RenderState(paramPMVMatrix);
/*     */     this.enableCallback = paramGLCallback1;
/*     */     this.disableCallback = paramGLCallback2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean useShaderProgram(GL2ES2 paramGL2ES2, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, TextureSequence paramTextureSequence) {
/*     */     byte b;
/*     */     String str1, str3;
/* 522 */     ShaderModeSelector1 shaderModeSelector1 = paramBoolean ? ShaderModeSelector1.selectPass1(paramInt1) : ShaderModeSelector1.selectPass2(paramInt1, paramInt2, paramInt3);
/* 523 */     boolean bool1 = Region.isTwoPass(paramInt1);
/* 524 */     boolean bool2 = Region.hasColorChannel(paramInt1);
/* 525 */     boolean bool3 = (Region.hasColorTexture(paramInt1) && null != paramTextureSequence) ? true : false;
/* 526 */     boolean bool4 = (paramBoolean && bool3) ? true : false;
/*     */ 
/*     */     
/* 529 */     if (bool4) {
/* 530 */       str1 = paramTextureSequence.setTextureLookupFunctionName("gcuTexture2D");
/* 531 */       b = paramTextureSequence.getTextureFragmentShaderHashCode();
/*     */     } else {
/* 533 */       str1 = null;
/* 534 */       b = 0;
/*     */     } 
/*     */     
/* 537 */     int i = (b << 5) - b + (shaderModeSelector1.ordinal() | 0x600 & paramInt1 | (bool1 ? Integer.MIN_VALUE : 0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 545 */     ShaderProgram shaderProgram = (ShaderProgram)this.shaderPrograms.get(i);
/* 546 */     if (null != shaderProgram) {
/* 547 */       boolean bool = this.rs.setShaderProgram(paramGL2ES2, shaderProgram);
/* 548 */       if (DEBUG) {
/* 549 */         if (bool) {
/* 550 */           System.err.printf("RegionRendererImpl01.useShaderProgram.X1: GOT renderModes %s, sel1 %s, key 0x%X -> sp %d / %d (changed)%n", new Object[] { Region.getRenderModeString(paramInt1), shaderModeSelector1, Integer.valueOf(i), Integer.valueOf(shaderProgram.program()), Integer.valueOf(shaderProgram.id()) });
/*     */         } else {
/* 552 */           System.err.printf("RegionRendererImpl01.useShaderProgram.X1: GOT renderModes %s, sel1 %s, key 0x%X -> sp %d / %d (keep)%n", new Object[] { Region.getRenderModeString(paramInt1), shaderModeSelector1, Integer.valueOf(i), Integer.valueOf(shaderProgram.program()), Integer.valueOf(shaderProgram.id()) });
/*     */         } 
/*     */       }
/* 555 */       return bool;
/*     */     } 
/* 557 */     String str2 = getVersionedShaderName();
/*     */     
/* 559 */     if (bool1) {
/* 560 */       str3 = str2 + "-pass" + (paramBoolean ? 1 : 2);
/*     */     } else {
/* 562 */       str3 = str2 + "-single";
/*     */     } 
/* 564 */     ShaderCode shaderCode1 = ShaderCode.create(paramGL2ES2, 35633, AttributeNames.class, "", "bin", str3, true);
/* 565 */     ShaderCode shaderCode2 = ShaderCode.create(paramGL2ES2, 35632, AttributeNames.class, "", "bin", str2 + "-segment-head", true);
/*     */     
/* 567 */     if (bool4 && 36197 == paramTextureSequence.getTextureTarget() && 
/* 568 */       !paramGL2ES2.isExtensionAvailable("GL_OES_EGL_image_external")) {
/* 569 */       throw new GLException("GL_OES_EGL_image_external requested but not available");
/*     */     }
/*     */     
/* 572 */     boolean bool5 = false;
/* 573 */     if (bool4 && 36197 == paramTextureSequence.getTextureTarget() && 
/* 574 */       Platform.OSType.ANDROID == Platform.getOSType() && paramGL2ES2.isGLES3())
/*     */     {
/*     */ 
/*     */       
/* 578 */       bool5 = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 584 */     int j = shaderCode1.defaultShaderCustomization(paramGL2ES2, !bool5, true);
/*     */     
/* 586 */     int k = bool5 ? 0 : shaderCode2.addGLSLVersion(paramGL2ES2);
/* 587 */     if (bool4) {
/* 588 */       k = shaderCode2.insertShaderSource(0, k, paramTextureSequence.getRequiredExtensionsShaderStub());
/*     */     }
/* 590 */     if ((paramBoolean && bool5) || (paramGL2ES2.isGLES2() && !paramGL2ES2.isGLES3())) {
/* 591 */       k = shaderCode2.insertShaderSource(0, k, ShaderCode.createExtensionDirective("GL_OES_standard_derivatives", "enable"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 599 */     k = shaderCode2.addDefaultShaderPrecision(paramGL2ES2, k);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 604 */     k = -1;
/*     */     
/* 606 */     if (!paramGL2ES2.getContext().hasRendererQuirk(5)) {
/* 607 */       k = shaderCode2.insertShaderSource(0, k, "#define USE_DISCARD 1\n");
/*     */     }
/*     */     
/* 610 */     if (bool2) {
/* 611 */       j = shaderCode1.insertShaderSource(0, j, "#define USE_COLOR_CHANNEL 1\n");
/* 612 */       k = shaderCode2.insertShaderSource(0, k, "#define USE_COLOR_CHANNEL 1\n");
/*     */     } 
/* 614 */     if (bool4) {
/* 615 */       shaderCode1.insertShaderSource(0, j, "#define USE_COLOR_TEXTURE 1\n");
/* 616 */       k = shaderCode2.insertShaderSource(0, k, "#define USE_COLOR_TEXTURE 1\n");
/*     */     } 
/* 618 */     if (!paramBoolean) {
/* 619 */       k = shaderCode2.insertShaderSource(0, k, "#define SAMPLE_COUNT " + shaderModeSelector1.sampleCount + "\n");
/* 620 */       k = shaderCode2.insertShaderSource(0, k, "const float sample_count = " + shaderModeSelector1.sampleCount + ".0;\n");
/*     */     } 
/*     */     
/*     */     try {
/* 624 */       k = shaderCode2.insertShaderSource(0, k, AttributeNames.class, "uniforms.glsl");
/* 625 */       k = shaderCode2.insertShaderSource(0, k, AttributeNames.class, "varyings.glsl");
/* 626 */     } catch (IOException iOException) {
/* 627 */       throw new RuntimeException("Failed to read: includes", iOException);
/*     */     } 
/* 629 */     if (0 > k) {
/* 630 */       throw new RuntimeException("Failed to read: includes");
/*     */     }
/*     */     
/* 633 */     if (bool4) {
/* 634 */       k = shaderCode2.insertShaderSource(0, k, "uniform " + paramTextureSequence.getTextureSampler2DType() + " " + "gcu_ColorTexUnit" + ";\n");
/* 635 */       k = shaderCode2.insertShaderSource(0, k, paramTextureSequence.getTextureLookupFragmentShaderImpl());
/*     */     } 
/*     */     
/* 638 */     k = shaderCode2.insertShaderSource(0, k, "void main (void)\n{\n");
/*     */     
/* 640 */     String str4 = paramBoolean ? "-pass1-" : "-pass2-";
/* 641 */     String str5 = str2 + str4 + shaderModeSelector1.tech + shaderModeSelector1.sub + ".glsl";
/* 642 */     if (DEBUG) {
/* 643 */       System.err.printf("RegionRendererImpl01.useShaderProgram.1: segment %s%n", new Object[] { str5 });
/*     */     }
/*     */     try {
/* 646 */       k = shaderCode2.insertShaderSource(0, k, AttributeNames.class, str5);
/* 647 */     } catch (IOException iOException) {
/* 648 */       throw new RuntimeException("Failed to read: " + str5, iOException);
/*     */     } 
/* 650 */     if (0 > k) {
/* 651 */       throw new RuntimeException("Failed to read: " + str5);
/*     */     }
/* 653 */     k = shaderCode2.insertShaderSource(0, k, "}\n");
/*     */     
/* 655 */     if (bool4) {
/* 656 */       shaderCode2.replaceInShaderSource("gcuTexture2D", str1);
/*     */     }
/*     */     
/* 659 */     shaderProgram = new ShaderProgram();
/* 660 */     shaderProgram.add(shaderCode1);
/* 661 */     shaderProgram.add(shaderCode2);
/*     */     
/* 663 */     if (!shaderProgram.init(paramGL2ES2)) {
/* 664 */       throw new GLException("RegionRenderer: Couldn't init program: " + shaderProgram);
/*     */     }
/*     */     
/* 667 */     if (!shaderProgram.link(paramGL2ES2, System.err)) {
/* 668 */       throw new GLException("could not link program: " + shaderProgram);
/*     */     }
/* 670 */     this.rs.setShaderProgram(paramGL2ES2, shaderProgram);
/*     */     
/* 672 */     this.shaderPrograms.put(i, shaderProgram);
/* 673 */     if (DEBUG) {
/* 674 */       System.err.printf("RegionRendererImpl01.useShaderProgram.X1: PUT renderModes %s, sel1 %s, key 0x%X -> sp %d / %d (changed, new)%n", new Object[] {
/* 675 */             Region.getRenderModeString(paramInt1), shaderModeSelector1, Integer.valueOf(i), Integer.valueOf(shaderProgram.program()), Integer.valueOf(shaderProgram.id())
/*     */           });
/*     */     }
/* 678 */     return true;
/*     */   }
/*     */   
/*     */   public static interface GLCallback {
/*     */     void run(GL param1GL, RegionRenderer param1RegionRenderer);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/opengl/RegionRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */