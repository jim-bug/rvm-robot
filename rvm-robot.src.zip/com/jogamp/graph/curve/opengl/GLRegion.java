/*     */ package com.jogamp.graph.curve.opengl;
/*     */ 
/*     */ import com.jogamp.graph.curve.OutlineShape;
/*     */ import com.jogamp.graph.curve.Region;
/*     */ import com.jogamp.graph.font.Font;
/*     */ import com.jogamp.opengl.GL;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLArrayData;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.util.GLArrayDataServer;
/*     */ import com.jogamp.opengl.util.GLArrayDataWrapper;
/*     */ import com.jogamp.opengl.util.texture.TextureSequence;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ import jogamp.graph.curve.opengl.VBORegion2PMSAAES2;
/*     */ import jogamp.graph.curve.opengl.VBORegion2PVBAAES2;
/*     */ import jogamp.graph.curve.opengl.VBORegionSPES2;
/*     */ import jogamp.opengl.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GLRegion
/*     */   extends Region
/*     */ {
/*     */   public static final int defaultVerticesCount = 64;
/*     */   public static final int defaultIndicesCount = 64;
/*     */   protected static final float growthFactor = 1.618F;
/*  98 */   private static final boolean DEBUG_BUFFER = Debug.debug("graph.curve.Buffer");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int gl_idx_type;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TextureSequence colorTexSeq;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GLRegion create(GLProfile paramGLProfile, int paramInt1, TextureSequence paramTextureSequence, int paramInt2, int paramInt3, int paramInt4) {
/* 113 */     if (null != paramTextureSequence) {
/* 114 */       paramInt1 |= 0x400;
/* 115 */     } else if (Region.hasColorTexture(paramInt1)) {
/* 116 */       throw new IllegalArgumentException("COLORTEXTURE_RENDERING_BIT set but null TextureSequence");
/*     */     } 
/* 118 */     if (isVBAA(paramInt1))
/* 119 */       return (GLRegion)new VBORegion2PVBAAES2(paramGLProfile, paramInt1, paramTextureSequence, paramInt2, paramInt3, paramInt4); 
/* 120 */     if (isMSAA(paramInt1)) {
/* 121 */       return (GLRegion)new VBORegion2PMSAAES2(paramGLProfile, paramInt1, paramTextureSequence, paramInt2, paramInt3, paramInt4);
/*     */     }
/* 123 */     return (GLRegion)new VBORegionSPES2(paramGLProfile, paramInt1, paramTextureSequence, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GLRegion create(GLProfile paramGLProfile, int paramInt1, TextureSequence paramTextureSequence, int paramInt2, int paramInt3) {
/* 141 */     return create(paramGLProfile, paramInt1, paramTextureSequence, 0, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GLRegion create(GLProfile paramGLProfile, int paramInt, TextureSequence paramTextureSequence) {
/* 154 */     return create(paramGLProfile, paramInt, paramTextureSequence, 64, 64);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GLRegion create(GLProfile paramGLProfile, int paramInt, TextureSequence paramTextureSequence, OutlineShape paramOutlineShape) {
/* 169 */     int[] arrayOfInt = Region.countOutlineShape(paramOutlineShape, new int[2]);
/* 170 */     return create(paramGLProfile, paramInt, paramTextureSequence, arrayOfInt[0], arrayOfInt[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GLRegion create(GLProfile paramGLProfile, int paramInt, TextureSequence paramTextureSequence, Font paramFont, CharSequence paramCharSequence) {
/* 187 */     final int[] vertIndexCount = { 0, 0 };
/* 188 */     Font.GlyphVisitor2 glyphVisitor2 = new Font.GlyphVisitor2()
/*     */       {
/*     */         public final void visit(char param1Char, Font.Glyph param1Glyph) {
/* 191 */           Region.countOutlineShape(param1Glyph.getShape(), vertIndexCount); }
/*     */       };
/* 193 */     paramFont.processString(glyphVisitor2, paramCharSequence);
/* 194 */     return create(paramGLProfile, paramInt, paramTextureSequence, arrayOfInt[0], arrayOfInt[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   protected int curVerticesCap = 0;
/* 202 */   protected int curIndicesCap = 0;
/* 203 */   protected int growCount = 0;
/*     */ 
/*     */   
/* 206 */   protected GLArrayDataServer vpc_ileave = null;
/* 207 */   protected GLArrayDataWrapper gca_VerticesAttr = null;
/* 208 */   protected GLArrayDataWrapper gca_CurveParamsAttr = null;
/* 209 */   protected GLArrayDataWrapper gca_ColorsAttr = null;
/* 210 */   protected GLArrayDataServer indicesBuffer = null; private int lastRenderModes;
/*     */   
/*     */   protected GLRegion(GLProfile paramGLProfile, int paramInt, TextureSequence paramTextureSequence) {
/* 213 */     super(paramInt, paramGLProfile.isGL2ES3());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 539 */     this.lastRenderModes = 0;
/*     */     this.gl_idx_type = usesI32Idx() ? 5125 : 5123;
/*     */     this.colorTexSeq = paramTextureSequence;
/*     */   }
/*     */   
/*     */   protected final int glIdxType() {
/*     */     return this.gl_idx_type;
/*     */   }
/*     */   
/*     */   public GLArrayDataServer createInterleaved(boolean paramBoolean1, int paramInt1, int paramInt2, boolean paramBoolean2, int paramInt3, int paramInt4) {
/*     */     if (paramBoolean1)
/*     */       return GLArrayDataServer.createGLSLInterleavedMapped(paramInt1, paramInt2, paramBoolean2, paramInt3, paramInt4); 
/*     */     return GLArrayDataServer.createGLSLInterleaved(paramInt1, paramInt2, paramBoolean2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void addInterleavedVertexAndNormalArrays(GLArrayDataServer paramGLArrayDataServer, int paramInt) {
/*     */     paramGLArrayDataServer.addGLSLSubArray("vertices", paramInt, 34962);
/*     */     paramGLArrayDataServer.addGLSLSubArray("normals", paramInt, 34962);
/*     */   }
/*     */   
/*     */   protected final void initBuffer(int paramInt1, int paramInt2) {
/*     */     this.indicesBuffer = GLArrayDataServer.createData(3, glIdxType(), paramInt2, 35044, 34963);
/*     */     this.indicesBuffer.setGrowthFactor(1.618F);
/*     */     this.curIndicesCap = this.indicesBuffer.getElemCapacity();
/*     */     boolean bool = hasColorChannel();
/*     */     int i = 6 + (bool ? 4 : 0);
/*     */     this.vpc_ileave = GLArrayDataServer.createGLSLInterleaved(i, 5126, false, paramInt1, 35044);
/*     */     this.vpc_ileave.setGrowthFactor(1.618F);
/*     */     this.gca_VerticesAttr = this.vpc_ileave.addGLSLSubArray("gca_Vertices", 3, 34962);
/*     */     this.gca_CurveParamsAttr = this.vpc_ileave.addGLSLSubArray("gca_CurveParams", 3, 34962);
/*     */     if (bool)
/*     */       this.gca_ColorsAttr = this.vpc_ileave.addGLSLSubArray("gca_Colors", 4, 34962); 
/*     */     this.curVerticesCap = this.vpc_ileave.getElemCapacity();
/*     */     this.growCount = 0;
/*     */   }
/*     */   
/*     */   public final boolean growBuffer(int paramInt1, int paramInt2) {
/*     */     boolean bool = false;
/*     */     if (!DEBUG_BUFFER) {
/*     */       if (this.curIndicesCap < this.indicesBuffer.elemPosition() + paramInt2) {
/*     */         this.indicesBuffer.growIfNeeded(paramInt2 * this.indicesBuffer.getCompsPerElem());
/*     */         this.curIndicesCap = this.indicesBuffer.getElemCapacity();
/*     */         bool = true;
/*     */       } 
/*     */       if (this.curVerticesCap < this.vpc_ileave.elemPosition() + paramInt1) {
/*     */         this.vpc_ileave.growIfNeeded(paramInt1 * this.vpc_ileave.getCompsPerElem());
/*     */         this.curVerticesCap = this.vpc_ileave.getElemCapacity();
/*     */         bool = true;
/*     */       } 
/*     */     } else {
/*     */       if (this.curIndicesCap < this.indicesBuffer.elemPosition() + paramInt2) {
/*     */         System.err.printf("GLRegion: Buffer grow - Indices: %d < ( %d = %d + %d ); Status: %s%n", new Object[] { Integer.valueOf(this.curIndicesCap), Integer.valueOf(this.indicesBuffer.elemPosition() + paramInt2), Integer.valueOf(this.indicesBuffer.elemPosition()), Integer.valueOf(paramInt2), this.indicesBuffer.elemStatsToString() });
/*     */         this.indicesBuffer.growIfNeeded(paramInt2 * this.indicesBuffer.getCompsPerElem());
/*     */         System.err.println("GLRegion: Grew Indices 0x" + Integer.toHexString(hashCode()) + ": " + this.curIndicesCap + " -> " + this.indicesBuffer.getElemCapacity() + ", " + this.indicesBuffer.elemStatsToString());
/*     */         Thread.dumpStack();
/*     */         this.curIndicesCap = this.indicesBuffer.getElemCapacity();
/*     */         bool = true;
/*     */       } 
/*     */       if (this.curVerticesCap < this.vpc_ileave.elemPosition() + paramInt1) {
/*     */         System.err.printf("GLRegion: Buffer grow - Vertices: %d < ( %d = %d + %d ); Status: %s%n", new Object[] { Integer.valueOf(this.curVerticesCap), Integer.valueOf(this.gca_VerticesAttr.elemPosition() + paramInt1), Integer.valueOf(this.gca_VerticesAttr.elemPosition()), Integer.valueOf(paramInt1), this.gca_VerticesAttr.elemStatsToString() });
/*     */         this.vpc_ileave.growIfNeeded(paramInt1 * this.vpc_ileave.getCompsPerElem());
/*     */         System.err.println("GLRegion: Grew Vertices 0x" + Integer.toHexString(hashCode()) + ": " + this.curVerticesCap + " -> " + this.gca_VerticesAttr.getElemCapacity() + ", " + this.gca_VerticesAttr.elemStatsToString());
/*     */         this.curVerticesCap = this.vpc_ileave.getElemCapacity();
/*     */         bool = true;
/*     */       } 
/*     */     } 
/*     */     if (bool) {
/*     */       this.growCount++;
/*     */       return true;
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   public final boolean setBufferCapacity(int paramInt1, int paramInt2) {
/*     */     boolean bool = false;
/*     */     if (this.curIndicesCap < paramInt2) {
/*     */       this.indicesBuffer.reserve(paramInt2);
/*     */       this.curIndicesCap = this.indicesBuffer.getElemCapacity();
/*     */       bool = true;
/*     */     } 
/*     */     if (this.curVerticesCap < paramInt1) {
/*     */       this.vpc_ileave.reserve(paramInt1);
/*     */       this.curVerticesCap = this.vpc_ileave.getElemCapacity();
/*     */       bool = true;
/*     */     } 
/*     */     return bool;
/*     */   }
/*     */   
/*     */   public final void printBufferStats(PrintStream paramPrintStream) {
/*     */     int[] arrayOfInt1 = { 0 }, arrayOfInt2 = { 0 };
/*     */     paramPrintStream.println("GLRegion: idx32 " + usesI32Idx() + ", obj 0x" + Integer.toHexString(hashCode()));
/*     */     printAndCount(paramPrintStream, "  indices ", (GLArrayData)this.indicesBuffer, arrayOfInt1, arrayOfInt2);
/*     */     paramPrintStream.println();
/*     */     printAndCount(paramPrintStream, "  ileave ", (GLArrayData)this.vpc_ileave, arrayOfInt1, arrayOfInt2);
/*     */     paramPrintStream.println();
/*     */     print(paramPrintStream, "  - vertices ", (GLArrayData)this.gca_VerticesAttr);
/*     */     paramPrintStream.println();
/*     */     print(paramPrintStream, "  - params ", (GLArrayData)this.gca_CurveParamsAttr);
/*     */     paramPrintStream.println();
/*     */     print(paramPrintStream, "  - color ", (GLArrayData)this.gca_ColorsAttr);
/*     */     paramPrintStream.println();
/*     */     float f = arrayOfInt1[0] / arrayOfInt2[0];
/*     */     paramPrintStream.printf("  total [bytes %,d / %,d], filled[%.1f%%, left %.1f%%], grow-cnt %d, obj 0x%x%n", new Object[] { Integer.valueOf(arrayOfInt1[0]), Integer.valueOf(arrayOfInt2[0]), Float.valueOf(f * 100.0F), Float.valueOf((1.0F - f) * 100.0F), Integer.valueOf(this.growCount), Integer.valueOf(hashCode()) });
/*     */   }
/*     */   
/*     */   private static void printAndCount(PrintStream paramPrintStream, String paramString, GLArrayData paramGLArrayData, int[] paramArrayOfint1, int[] paramArrayOfint2) {
/*     */     paramPrintStream.print(paramString + "[");
/*     */     if (null != paramGLArrayData) {
/*     */       paramPrintStream.print(paramGLArrayData.fillStatsToString());
/*     */       paramArrayOfint1[0] = paramArrayOfint1[0] + paramGLArrayData.getByteCount();
/*     */       paramArrayOfint2[0] = paramArrayOfint2[0] + paramGLArrayData.getByteCapacity();
/*     */       paramPrintStream.print("]");
/*     */     } else {
/*     */       paramPrintStream.print("null]");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void print(PrintStream paramPrintStream, String paramString, GLArrayData paramGLArrayData) {
/*     */     paramPrintStream.print(paramString + "[");
/*     */     if (null != paramGLArrayData) {
/*     */       paramPrintStream.print(paramGLArrayData.fillStatsToString());
/*     */       paramPrintStream.print("]");
/*     */     } else {
/*     */       paramPrintStream.print("null]");
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract void setTextureUnit(int paramInt);
/*     */   
/*     */   protected final void pushVertex(Vec3f paramVec3f1, Vec3f paramVec3f2, Vec4f paramVec4f) {
/*     */     put3f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec3f1);
/*     */     put3f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec3f2);
/*     */     if (hasColorChannel())
/*     */       if (null != paramVec4f) {
/*     */         put4f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec4f);
/*     */       } else {
/*     */         throw new IllegalArgumentException("Null color given for COLOR_CHANNEL rendering mode");
/*     */       }  
/*     */   }
/*     */   
/*     */   protected final void pushVertices(Vec3f paramVec3f1, Vec3f paramVec3f2, Vec3f paramVec3f3, Vec3f paramVec3f4, Vec3f paramVec3f5, Vec3f paramVec3f6, Vec4f paramVec4f) {
/*     */     boolean bool = hasColorChannel();
/*     */     if (bool && null == paramVec4f)
/*     */       throw new IllegalArgumentException("Null color given for COLOR_CHANNEL rendering mode"); 
/*     */     put3f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec3f1);
/*     */     put3f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec3f4);
/*     */     if (bool)
/*     */       put4f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec4f); 
/*     */     put3f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec3f2);
/*     */     put3f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec3f5);
/*     */     if (bool)
/*     */       put4f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec4f); 
/*     */     put3f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec3f3);
/*     */     put3f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec3f6);
/*     */     if (bool)
/*     */       put4f((FloatBuffer)this.vpc_ileave.getBuffer(), paramVec4f); 
/*     */   }
/*     */   
/*     */   protected final void pushIndex(int paramInt) {
/*     */     if (usesI32Idx()) {
/*     */       this.indicesBuffer.puti(paramInt);
/*     */     } else {
/*     */       this.indicesBuffer.puts((short)paramInt);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void pushIndices(int paramInt1, int paramInt2, int paramInt3) {
/*     */     if (usesI32Idx()) {
/*     */       put3i((IntBuffer)this.indicesBuffer.getBuffer(), paramInt1, paramInt2, paramInt3);
/*     */     } else {
/*     */       put3s((ShortBuffer)this.indicesBuffer.getBuffer(), (short)paramInt1, (short)paramInt2, (short)paramInt3);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final GLRegion clear(GL2ES2 paramGL2ES2) {
/*     */     this.lastRenderModes = 0;
/*     */     if (DEBUG_INSTANCE)
/*     */       System.err.println("GLRegion Clear: " + this); 
/*     */     if (null != this.indicesBuffer)
/*     */       this.indicesBuffer.clear((GL)paramGL2ES2); 
/*     */     if (null != this.vpc_ileave)
/*     */       this.vpc_ileave.clear((GL)paramGL2ES2); 
/*     */     clearImpl(paramGL2ES2);
/*     */     clearImpl();
/*     */     return this;
/*     */   }
/*     */   
/*     */   protected abstract void clearImpl(GL2ES2 paramGL2ES2);
/*     */   
/*     */   public final void destroy(GL2ES2 paramGL2ES2) {
/*     */     clear(paramGL2ES2);
/*     */     if (null != this.vpc_ileave) {
/*     */       this.vpc_ileave.destroy((GL)paramGL2ES2);
/*     */       this.vpc_ileave = null;
/*     */     } 
/*     */     if (null != this.gca_VerticesAttr) {
/*     */       this.gca_VerticesAttr.destroy((GL)paramGL2ES2);
/*     */       this.gca_VerticesAttr = null;
/*     */     } 
/*     */     if (null != this.gca_CurveParamsAttr) {
/*     */       this.gca_CurveParamsAttr.destroy((GL)paramGL2ES2);
/*     */       this.gca_CurveParamsAttr = null;
/*     */     } 
/*     */     if (null != this.gca_ColorsAttr) {
/*     */       this.gca_ColorsAttr.destroy((GL)paramGL2ES2);
/*     */       this.gca_ColorsAttr = null;
/*     */     } 
/*     */     if (null != this.indicesBuffer) {
/*     */       this.indicesBuffer.destroy((GL)paramGL2ES2);
/*     */       this.indicesBuffer = null;
/*     */     } 
/*     */     this.curVerticesCap = 0;
/*     */     this.curIndicesCap = 0;
/*     */     this.growCount = 0;
/*     */     destroyImpl(paramGL2ES2);
/*     */   }
/*     */   
/*     */   protected abstract void destroyImpl(GL2ES2 paramGL2ES2);
/*     */   
/*     */   public final void draw(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint) {
/*     */     int i;
/*     */     if (null == paramArrayOfint || 0 == paramArrayOfint[0]) {
/*     */       i = getRenderModes() & 0xFFFFFFFC;
/*     */     } else if (0 > paramArrayOfint[0]) {
/*     */       i = getRenderModes() & 0xFFFFF9FC;
/*     */     } else {
/*     */       i = getRenderModes();
/*     */     } 
/*     */     if (this.lastRenderModes != i) {
/*     */       markShapeDirty();
/*     */       markStateDirty();
/*     */     } 
/*     */     if (isShapeDirty())
/*     */       updateImpl(paramGL2ES2, i); 
/*     */     drawImpl(paramGL2ES2, paramRegionRenderer, i, paramArrayOfint);
/*     */     clearDirtyBits(3);
/*     */     this.lastRenderModes = i;
/*     */   }
/*     */   
/*     */   protected abstract void updateImpl(GL2ES2 paramGL2ES2, int paramInt);
/*     */   
/*     */   protected abstract void drawImpl(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int paramInt, int[] paramArrayOfint);
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/opengl/GLRegion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */