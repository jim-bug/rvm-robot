/*     */ package com.jogamp.graph.curve.opengl;
/*     */ 
/*     */ import com.jogamp.graph.curve.Region;
/*     */ import com.jogamp.graph.font.Font;
/*     */ import com.jogamp.graph.geom.plane.AffineTransform;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLException;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import com.jogamp.opengl.util.texture.TextureSequence;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextRegionUtil
/*     */ {
/*     */   public final int renderModes;
/*     */   public static final int DEFAULT_CACHE_LIMIT = 256;
/*     */   public final AffineTransform tempT1;
/*     */   public final AffineTransform tempT2;
/*     */   private final HashMap<Key, GLRegion> stringCacheMap;
/*     */   private final ArrayList<Key> stringCacheArray;
/*     */   private int stringCacheLimit;
/*     */   
/*     */   public TextRegionUtil(int paramInt) {
/* 478 */     this.tempT1 = new AffineTransform();
/* 479 */     this.tempT2 = new AffineTransform();
/* 480 */     this.stringCacheMap = new HashMap<>(256);
/* 481 */     this.stringCacheArray = new ArrayList<>(256);
/* 482 */     this.stringCacheLimit = 256;
/*     */     this.renderModes = paramInt;
/*     */   }
/*     */   
/*     */   public static int getCharCount(String paramString, char paramChar) {
/*     */     int i = paramString.length();
/*     */     byte b1 = 0;
/*     */     for (byte b2 = 0; b2 < i; b2++) {
/*     */       if (paramString.charAt(b2) == paramChar)
/*     */         b1++; 
/*     */     } 
/*     */     return b1;
/*     */   }
/*     */   
/*     */   public static AABBox addStringToRegion(Region paramRegion, Font paramFont, AffineTransform paramAffineTransform, CharSequence paramCharSequence, Vec4f paramVec4f) {
/*     */     return addStringToRegion(true, paramRegion, paramFont, paramAffineTransform, paramCharSequence, paramVec4f, new AffineTransform(), new AffineTransform());
/*     */   }
/*     */   
/*     */   public static AABBox addStringToRegion(Region paramRegion, Font paramFont, AffineTransform paramAffineTransform1, CharSequence paramCharSequence, Vec4f paramVec4f, AffineTransform paramAffineTransform2, AffineTransform paramAffineTransform3) {
/*     */     return addStringToRegion(true, paramRegion, paramFont, paramAffineTransform1, paramCharSequence, paramVec4f, paramAffineTransform2, paramAffineTransform3);
/*     */   }
/*     */   
/*     */   public static AABBox addStringToRegion(boolean paramBoolean, final Region region, Font paramFont, AffineTransform paramAffineTransform1, CharSequence paramCharSequence, final Vec4f rgbaColor, AffineTransform paramAffineTransform2, AffineTransform paramAffineTransform3) {
/*     */     Font.GlyphVisitor glyphVisitor = new Font.GlyphVisitor() {
/*     */         public void visit(char param1Char, Font.Glyph param1Glyph, AffineTransform param1AffineTransform) {
/*     */           if (param1Glyph.isWhiteSpace())
/*     */             return; 
/*     */           region.addOutlineShape(param1Glyph.getShape(), param1AffineTransform, rgbaColor);
/*     */         }
/*     */       };
/*     */     if (paramBoolean) {
/*     */       int[] arrayOfInt = countStringRegion(paramFont, paramCharSequence, new int[2]);
/*     */       region.growBuffer(arrayOfInt[0], arrayOfInt[1]);
/*     */     } 
/*     */     return paramFont.processString(glyphVisitor, paramAffineTransform1, paramCharSequence, paramAffineTransform2, paramAffineTransform3);
/*     */   }
/*     */   
/*     */   public static int[] countStringRegion(Font paramFont, CharSequence paramCharSequence, final int[] vertIndexCount) {
/*     */     Font.GlyphVisitor2 glyphVisitor2 = new Font.GlyphVisitor2() {
/*     */         public final void visit(char param1Char, Font.Glyph param1Glyph) {
/*     */           Region.countOutlineShape(param1Glyph.getShape(), vertIndexCount);
/*     */         }
/*     */       };
/*     */     paramFont.processString(glyphVisitor2, paramCharSequence);
/*     */     return vertIndexCount;
/*     */   }
/*     */   
/*     */   public AABBox drawString3D(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, Font paramFont, CharSequence paramCharSequence, Vec4f paramVec4f, int[] paramArrayOfint) {
/*     */     AABBox aABBox;
/*     */     if (!paramRegionRenderer.isInitialized())
/*     */       throw new GLException("TextRendererImpl01: not initialized!"); 
/*     */     GLRegion gLRegion = getCachedRegion(paramFont, paramCharSequence);
/*     */     if (null == gLRegion) {
/*     */       gLRegion = GLRegion.create(paramGL2ES2.getGLProfile(), this.renderModes, (TextureSequence)null, paramFont, paramCharSequence);
/*     */       aABBox = addStringToRegion(false, gLRegion, paramFont, null, paramCharSequence, paramVec4f, this.tempT1, this.tempT2);
/*     */       addCachedRegion(paramGL2ES2, paramFont, paramCharSequence, gLRegion);
/*     */     } else {
/*     */       aABBox = new AABBox();
/*     */       aABBox.copy(gLRegion.getBounds());
/*     */     } 
/*     */     if (!gLRegion.hasColorChannel()) {
/*     */       if (null != paramVec4f)
/*     */         paramRegionRenderer.setColorStatic(paramVec4f); 
/*     */     } else {
/*     */       paramRegionRenderer.setColorStatic(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */     gLRegion.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */     return aABBox;
/*     */   }
/*     */   
/*     */   public static AABBox drawString3D(GL2ES2 paramGL2ES2, int paramInt, RegionRenderer paramRegionRenderer, Font paramFont, CharSequence paramCharSequence, Vec4f paramVec4f, int[] paramArrayOfint) {
/*     */     return drawString3D(paramGL2ES2, paramInt, paramRegionRenderer, paramFont, paramCharSequence, paramVec4f, paramArrayOfint, new AffineTransform(), new AffineTransform());
/*     */   }
/*     */   
/*     */   public static AABBox drawString3D(GL2ES2 paramGL2ES2, int paramInt, RegionRenderer paramRegionRenderer, Font paramFont, CharSequence paramCharSequence, Vec4f paramVec4f, int[] paramArrayOfint, AffineTransform paramAffineTransform1, AffineTransform paramAffineTransform2) {
/*     */     if (!paramRegionRenderer.isInitialized())
/*     */       throw new GLException("TextRendererImpl01: not initialized!"); 
/*     */     GLRegion gLRegion = GLRegion.create(paramGL2ES2.getGLProfile(), paramInt, (TextureSequence)null, paramFont, paramCharSequence);
/*     */     AABBox aABBox = addStringToRegion(false, gLRegion, paramFont, null, paramCharSequence, paramVec4f, paramAffineTransform1, paramAffineTransform2);
/*     */     if (!gLRegion.hasColorChannel()) {
/*     */       if (null != paramVec4f)
/*     */         paramRegionRenderer.setColorStatic(paramVec4f); 
/*     */     } else {
/*     */       paramRegionRenderer.setColorStatic(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */     gLRegion.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */     gLRegion.destroy(paramGL2ES2);
/*     */     return aABBox;
/*     */   }
/*     */   
/*     */   public static AABBox drawString3D(GL2ES2 paramGL2ES2, GLRegion paramGLRegion, RegionRenderer paramRegionRenderer, Font paramFont, CharSequence paramCharSequence, Vec4f paramVec4f, int[] paramArrayOfint) {
/*     */     return drawString3D(paramGL2ES2, paramGLRegion, paramRegionRenderer, paramFont, paramCharSequence, paramVec4f, paramArrayOfint, new AffineTransform(), new AffineTransform());
/*     */   }
/*     */   
/*     */   public static AABBox drawString3D(GL2ES2 paramGL2ES2, GLRegion paramGLRegion, RegionRenderer paramRegionRenderer, Font paramFont, CharSequence paramCharSequence, Vec4f paramVec4f, int[] paramArrayOfint, AffineTransform paramAffineTransform1, AffineTransform paramAffineTransform2) {
/*     */     if (!paramRegionRenderer.isInitialized())
/*     */       throw new GLException("TextRendererImpl01: not initialized!"); 
/*     */     AABBox aABBox = addStringToRegion(true, paramGLRegion, paramFont, null, paramCharSequence, paramVec4f, paramAffineTransform1, paramAffineTransform2);
/*     */     if (!paramGLRegion.hasColorChannel()) {
/*     */       if (null != paramVec4f)
/*     */         paramRegionRenderer.setColorStatic(paramVec4f); 
/*     */     } else {
/*     */       paramRegionRenderer.setColorStatic(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */     paramGLRegion.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */     return aABBox;
/*     */   }
/*     */   
/*     */   public void clear(GL2ES2 paramGL2ES2) {
/*     */     Iterator<GLRegion> iterator = this.stringCacheMap.values().iterator();
/*     */     while (iterator.hasNext()) {
/*     */       GLRegion gLRegion = iterator.next();
/*     */       gLRegion.destroy(paramGL2ES2);
/*     */     } 
/*     */     this.stringCacheMap.clear();
/*     */     this.stringCacheArray.clear();
/*     */   }
/*     */   
/*     */   public final void setCacheLimit(int paramInt) {
/*     */     this.stringCacheLimit = paramInt;
/*     */   }
/*     */   
/*     */   public final void setCacheLimit(GL2ES2 paramGL2ES2, int paramInt) {
/*     */     this.stringCacheLimit = paramInt;
/*     */     validateCache(paramGL2ES2, 0);
/*     */   }
/*     */   
/*     */   public final int getCacheLimit() {
/*     */     return this.stringCacheLimit;
/*     */   }
/*     */   
/*     */   public final int getCacheSize() {
/*     */     return this.stringCacheArray.size();
/*     */   }
/*     */   
/*     */   private final void validateCache(GL2ES2 paramGL2ES2, int paramInt) {
/*     */     if (getCacheLimit() > 0)
/*     */       while (getCacheSize() + paramInt > getCacheLimit())
/*     */         removeCachedRegion(paramGL2ES2, 0);  
/*     */   }
/*     */   
/*     */   private final GLRegion getCachedRegion(Font paramFont, CharSequence paramCharSequence) {
/*     */     return this.stringCacheMap.get(new Key(paramFont, paramCharSequence));
/*     */   }
/*     */   
/*     */   private final void addCachedRegion(GL2ES2 paramGL2ES2, Font paramFont, CharSequence paramCharSequence, GLRegion paramGLRegion) {
/*     */     if (0 != getCacheLimit()) {
/*     */       Key key = new Key(paramFont, paramCharSequence);
/*     */       GLRegion gLRegion = this.stringCacheMap.put(key, paramGLRegion);
/*     */       if (null == gLRegion) {
/*     */         validateCache(paramGL2ES2, 1);
/*     */         this.stringCacheArray.add(this.stringCacheArray.size(), key);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void removeCachedRegion(GL2ES2 paramGL2ES2, Font paramFont, CharSequence paramCharSequence) {
/*     */     Key key = new Key(paramFont, paramCharSequence);
/*     */     GLRegion gLRegion = this.stringCacheMap.remove(key);
/*     */     if (null != gLRegion)
/*     */       gLRegion.destroy(paramGL2ES2); 
/*     */     this.stringCacheArray.remove(key);
/*     */   }
/*     */   
/*     */   private final void removeCachedRegion(GL2ES2 paramGL2ES2, int paramInt) {
/*     */     Key key = this.stringCacheArray.remove(paramInt);
/*     */     if (null != key) {
/*     */       GLRegion gLRegion = this.stringCacheMap.remove(key);
/*     */       if (null != gLRegion)
/*     */         gLRegion.destroy(paramGL2ES2); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private class Key {
/*     */     private final String fontName;
/*     */     private final CharSequence text;
/*     */     public final int hash;
/*     */     
/*     */     public Key(Font param1Font, CharSequence param1CharSequence) {
/*     */       this.fontName = param1Font.getName(3);
/*     */       this.text = param1CharSequence;
/*     */       int i = 31 + this.fontName.hashCode();
/*     */       this.hash = (i << 5) - i + param1CharSequence.hashCode();
/*     */     }
/*     */     
/*     */     public final int hashCode() {
/*     */       return this.hash;
/*     */     }
/*     */     
/*     */     public final boolean equals(Object param1Object) {
/*     */       if (this == param1Object)
/*     */         return true; 
/*     */       if (param1Object instanceof Key) {
/*     */         Key key = (Key)param1Object;
/*     */         return (key.fontName.equals(this.fontName) && key.text.equals(this.text));
/*     */       } 
/*     */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/opengl/TextRegionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */