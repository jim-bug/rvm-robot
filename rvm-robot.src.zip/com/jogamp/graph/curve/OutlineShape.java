/*      */ package com.jogamp.graph.curve;
/*      */ 
/*      */ import com.jogamp.graph.curve.tess.Triangulation;
/*      */ import com.jogamp.graph.curve.tess.Triangulator;
/*      */ import com.jogamp.graph.geom.Outline;
/*      */ import com.jogamp.graph.geom.Triangle;
/*      */ import com.jogamp.graph.geom.Vertex;
/*      */ import com.jogamp.graph.geom.plane.AffineTransform;
/*      */ import com.jogamp.graph.geom.plane.Path2F;
/*      */ import com.jogamp.graph.geom.plane.Winding;
/*      */ import com.jogamp.opengl.math.FloatUtil;
/*      */ import com.jogamp.opengl.math.Vec3f;
/*      */ import com.jogamp.opengl.math.VectorUtil;
/*      */ import com.jogamp.opengl.math.Vert2fImmutable;
/*      */ import com.jogamp.opengl.math.geom.AABBox;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class OutlineShape
/*      */   implements Comparable<OutlineShape>
/*      */ {
/*      */   public static final float DEFAULT_SHARPNESS = 0.5F;
/*      */   public static final int DIRTY_BOUNDS = 1;
/*      */   public static final int DIRTY_VERTICES = 2;
/*      */   public static final int DIRTY_TRIANGLES = 4;
/*      */   final ArrayList<Outline> outlines;
/*      */   private final AABBox bbox;
/*      */   private final ArrayList<Triangle> triangles;
/*      */   private final ArrayList<Vertex> vertices;
/*      */   private int addedVerticeCount;
/*      */   private VerticesState outlineState;
/*      */   private int dirtyBits;
/*      */   private float sharpness;
/*      */   
/*      */   public enum VerticesState
/*      */   {
/*  124 */     UNDEFINED(0), QUADRATIC_NURBS(1);
/*      */     
/*      */     public final int state;
/*      */     
/*      */     VerticesState(int param1Int1) {
/*  129 */       this.state = param1Int1;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  163 */   private final Vec3f tmpV1 = new Vec3f();
/*  164 */   private final Vec3f tmpV2 = new Vec3f();
/*  165 */   private final Vec3f tmpV3 = new Vec3f();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutlineShape() {
/*  171 */     this.outlines = new ArrayList<>(3);
/*  172 */     this.outlines.add(new Outline());
/*  173 */     this.outlineState = VerticesState.UNDEFINED;
/*  174 */     this.bbox = new AABBox();
/*  175 */     this.triangles = new ArrayList<>();
/*  176 */     this.vertices = new ArrayList<>();
/*  177 */     this.addedVerticeCount = 0;
/*  178 */     this.dirtyBits = 0;
/*  179 */     this.sharpness = 0.5F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getAddedVerticeCount() {
/*  188 */     return this.addedVerticeCount;
/*      */   }
/*      */   
/*      */   public final float getSharpness() {
/*  192 */     return this.sharpness;
/*      */   }
/*      */   
/*      */   public final void setSharpness(float paramFloat) {
/*  196 */     if (this.sharpness != paramFloat) {
/*  197 */       clearCache();
/*  198 */       this.sharpness = paramFloat;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void clear() {
/*  204 */     this.outlines.clear();
/*  205 */     this.outlines.add(new Outline());
/*  206 */     this.outlineState = VerticesState.UNDEFINED;
/*  207 */     this.bbox.reset();
/*  208 */     this.vertices.clear();
/*  209 */     this.triangles.clear();
/*  210 */     this.addedVerticeCount = 0;
/*  211 */     this.dirtyBits = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void clearCache() {
/*  216 */     this.vertices.clear();
/*  217 */     this.triangles.clear();
/*  218 */     this.dirtyBits |= 0x6;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getOutlineCount() {
/*  223 */     return this.outlines.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getVertexCount() {
/*  228 */     int i = 0;
/*  229 */     for (Outline outline : this.outlines) {
/*  230 */       i += outline.getVertexCount();
/*      */     }
/*  232 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Winding getWindingOfLastOutline() {
/*  240 */     return getLastOutline().getWinding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setWindingOfLastOutline(Winding paramWinding) {
/*  247 */     getLastOutline().setWinding(paramWinding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addEmptyOutline() {
/*  259 */     if (!getLastOutline().isEmpty()) {
/*  260 */       this.outlines.add(new Outline());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addOutline(Outline paramOutline) throws NullPointerException {
/*  275 */     addOutline(this.outlines.size(), paramOutline);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addOutline(int paramInt, Outline paramOutline) throws NullPointerException, IndexOutOfBoundsException {
/*  291 */     if (null == paramOutline) {
/*  292 */       throw new NullPointerException("outline is null");
/*      */     }
/*  294 */     if (this.outlines.size() == paramInt) {
/*  295 */       Outline outline = getLastOutline();
/*  296 */       if (paramOutline.isEmpty() && outline.isEmpty()) {
/*      */         return;
/*      */       }
/*  299 */       if (outline.isEmpty()) {
/*  300 */         this.outlines.set(paramInt - 1, paramOutline);
/*  301 */         if (0 == (this.dirtyBits & 0x1)) {
/*  302 */           this.bbox.resize(paramOutline.getBounds());
/*      */         }
/*      */         
/*  305 */         this.dirtyBits |= 0x6;
/*      */         return;
/*      */       } 
/*      */     } 
/*  309 */     this.outlines.add(paramInt, paramOutline);
/*  310 */     if (0 == (this.dirtyBits & 0x1)) {
/*  311 */       this.bbox.resize(paramOutline.getBounds());
/*      */     }
/*  313 */     this.dirtyBits |= 0x6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addOutlineShape(OutlineShape paramOutlineShape) throws NullPointerException {
/*  325 */     if (null == paramOutlineShape) {
/*  326 */       throw new NullPointerException("OutlineShape is null");
/*      */     }
/*  328 */     closeLastOutline(true);
/*  329 */     for (byte b = 0; b < paramOutlineShape.getOutlineCount(); b++) {
/*  330 */       addOutline(paramOutlineShape.getOutline(b));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOutline(int paramInt, Outline paramOutline) throws NullPointerException, IndexOutOfBoundsException {
/*  344 */     if (null == paramOutline) {
/*  345 */       throw new NullPointerException("outline is null");
/*      */     }
/*  347 */     this.outlines.set(paramInt, paramOutline);
/*  348 */     this.dirtyBits |= 0x7;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Outline removeOutline(int paramInt) throws IndexOutOfBoundsException {
/*  359 */     this.dirtyBits |= 0x7;
/*  360 */     return this.outlines.remove(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Outline getLastOutline() {
/*  369 */     return this.outlines.get(this.outlines.size() - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Outline getOutline(int paramInt) throws IndexOutOfBoundsException {
/*  377 */     return this.outlines.get(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addVertex(Vertex paramVertex) {
/*  387 */     Outline outline = getLastOutline();
/*  388 */     outline.addVertex(paramVertex);
/*  389 */     if (0 == (this.dirtyBits & 0x1)) {
/*  390 */       this.bbox.resize(paramVertex.getCoord());
/*      */     }
/*      */     
/*  393 */     this.dirtyBits |= 0x6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addVertex(int paramInt, Vertex paramVertex) {
/*  404 */     Outline outline = getLastOutline();
/*  405 */     outline.addVertex(paramInt, paramVertex);
/*  406 */     if (0 == (this.dirtyBits & 0x1)) {
/*  407 */       this.bbox.resize(paramVertex.getCoord());
/*      */     }
/*  409 */     this.dirtyBits |= 0x6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addVertex(float paramFloat1, float paramFloat2, boolean paramBoolean) {
/*  422 */     addVertex(new Vertex(paramFloat1, paramFloat2, 0.0F, paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addVertex(int paramInt, float paramFloat1, float paramFloat2, boolean paramBoolean) {
/*  436 */     addVertex(paramInt, new Vertex(paramFloat1, paramFloat2, 0.0F, paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addVertex(float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean) {
/*  449 */     addVertex(new Vertex(paramFloat1, paramFloat2, paramFloat3, paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addVertex(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean) {
/*  463 */     addVertex(paramInt, new Vertex(paramFloat1, paramFloat2, paramFloat3, paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addVertex(float[] paramArrayOffloat, int paramInt1, int paramInt2, boolean paramBoolean) {
/*  480 */     addVertex(new Vertex(paramArrayOffloat, paramInt1, paramInt2, paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addVertex(int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3, boolean paramBoolean) {
/*  498 */     addVertex(paramInt1, new Vertex(paramArrayOffloat, paramInt2, paramInt3, paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void closeLastOutline(boolean paramBoolean) {
/*  512 */     if (getLastOutline().setClosed(paramBoolean)) {
/*  513 */       this.dirtyBits |= 0x6;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPath(Path2F paramPath2F, boolean paramBoolean) {
/*  529 */     addPath(paramPath2F.iterator(null), paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addPath(Path2F.Iterator paramIterator, boolean paramBoolean) {
/*  544 */     float[] arrayOfFloat = paramIterator.points();
/*  545 */     while (paramIterator.hasNext()) {
/*  546 */       Outline outline; int j; Vertex vertex; int i = paramIterator.index();
/*  547 */       Path2F.SegmentType segmentType = paramIterator.next();
/*  548 */       switch (segmentType) {
/*      */         case MOVETO:
/*  550 */           outline = getLastOutline();
/*  551 */           j = outline.getVertexCount();
/*  552 */           if (0 == j) {
/*  553 */             addVertex(arrayOfFloat, i, 2, true); break;
/*      */           } 
/*  555 */           if (!paramBoolean) {
/*  556 */             closeLastOutline(false);
/*  557 */             addEmptyOutline();
/*  558 */             addVertex(arrayOfFloat, i, 2, true);
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*  563 */           vertex = outline.getVertex(j - 1);
/*  564 */           if (vertex.x() == arrayOfFloat[i + 0] && vertex
/*  565 */             .y() == arrayOfFloat[i + 1]) {
/*      */             break;
/*      */           }
/*      */ 
/*      */         
/*      */         case LINETO:
/*  571 */           addVertex(arrayOfFloat, i, 2, true);
/*      */           break;
/*      */         case QUADTO:
/*  574 */           addVertex(arrayOfFloat, i, 2, false);
/*  575 */           addVertex(arrayOfFloat, i + 2, 2, true);
/*      */           break;
/*      */         case CUBICTO:
/*  578 */           addVertex(arrayOfFloat, i, 2, false);
/*  579 */           addVertex(arrayOfFloat, i + 2, 2, false);
/*  580 */           addVertex(arrayOfFloat, i + 4, 2, true);
/*      */           break;
/*      */         case CLOSE:
/*  583 */           closeLastOutline(true);
/*  584 */           addEmptyOutline();
/*      */           break;
/*      */         default:
/*  587 */           throw new IllegalArgumentException("Unhandled Segment Type: " + segmentType);
/*      */       } 
/*  589 */       paramBoolean = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPathRev(Path2F paramPath2F, boolean paramBoolean) {
/*  604 */     addPathRev(paramPath2F.iterator(null), paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addPathRev(Path2F.Iterator paramIterator, boolean paramBoolean) {
/*  618 */     float[] arrayOfFloat = paramIterator.points();
/*  619 */     while (paramIterator.hasNext()) {
/*  620 */       Outline outline; int j; Vertex vertex; int i = paramIterator.index();
/*  621 */       Path2F.SegmentType segmentType = paramIterator.next();
/*  622 */       switch (segmentType) {
/*      */         case MOVETO:
/*  624 */           outline = getLastOutline();
/*  625 */           j = outline.getVertexCount();
/*  626 */           if (0 == j) {
/*  627 */             addVertex(0, arrayOfFloat, i, 2, true); break;
/*      */           } 
/*  629 */           if (!paramBoolean) {
/*  630 */             closeLastOutline(false);
/*  631 */             addEmptyOutline();
/*  632 */             addVertex(0, arrayOfFloat, i, 2, true);
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*  637 */           vertex = outline.getVertex(0);
/*  638 */           if (vertex.x() == arrayOfFloat[i + 0] && vertex
/*  639 */             .y() == arrayOfFloat[i + 1]) {
/*      */             break;
/*      */           }
/*      */ 
/*      */         
/*      */         case LINETO:
/*  645 */           addVertex(0, arrayOfFloat, i, 2, true);
/*      */           break;
/*      */         case QUADTO:
/*  648 */           addVertex(0, arrayOfFloat, i, 2, false);
/*  649 */           addVertex(0, arrayOfFloat, i + 2, 2, true);
/*      */           break;
/*      */         case CUBICTO:
/*  652 */           addVertex(0, arrayOfFloat, i, 2, false);
/*  653 */           addVertex(0, arrayOfFloat, i + 2, 2, false);
/*  654 */           addVertex(0, arrayOfFloat, i + 4, 2, true);
/*      */           break;
/*      */         case CLOSE:
/*  657 */           closeLastOutline(true);
/*  658 */           addEmptyOutline();
/*      */           break;
/*      */         default:
/*  661 */           throw new IllegalArgumentException("Unhandled Segment Type: " + segmentType);
/*      */       } 
/*  663 */       paramBoolean = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void moveTo(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  678 */     if (0 == getLastOutline().getVertexCount()) {
/*  679 */       addVertex(paramFloat1, paramFloat2, paramFloat3, true);
/*      */     } else {
/*  681 */       closeLastOutline(false);
/*  682 */       addEmptyOutline();
/*  683 */       addVertex(paramFloat1, paramFloat2, paramFloat3, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void lineTo(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  698 */     addVertex(paramFloat1, paramFloat2, paramFloat3, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void quadTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  715 */     addVertex(paramFloat1, paramFloat2, paramFloat3, false);
/*  716 */     addVertex(paramFloat4, paramFloat5, paramFloat6, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void cubicTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
/*  736 */     addVertex(paramFloat1, paramFloat2, paramFloat3, false);
/*  737 */     addVertex(paramFloat4, paramFloat5, paramFloat6, false);
/*  738 */     addVertex(paramFloat7, paramFloat8, paramFloat9, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void closePath() {
/*  747 */     if (0 < getLastOutline().getVertexCount()) {
/*  748 */       closeLastOutline(true);
/*  749 */       addEmptyOutline();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final VerticesState getOutlineState() {
/*  757 */     return this.outlineState;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setIsQuadraticNurbs() {
/*  765 */     this.outlineState = VerticesState.QUADRATIC_NURBS;
/*      */   }
/*      */ 
/*      */   
/*      */   private void subdivideTriangle(Outline paramOutline, Vertex paramVertex1, Vertex paramVertex2, Vertex paramVertex3, int paramInt) {
/*  770 */     VectorUtil.midVec3(this.tmpV1, paramVertex1.getCoord(), paramVertex2.getCoord());
/*  771 */     VectorUtil.midVec3(this.tmpV3, paramVertex2.getCoord(), paramVertex3.getCoord());
/*  772 */     VectorUtil.midVec3(this.tmpV2, this.tmpV1, this.tmpV3);
/*      */ 
/*      */     
/*  775 */     paramVertex2.setCoord(this.tmpV2);
/*  776 */     paramVertex2.setOnCurve(true);
/*      */     
/*  778 */     paramOutline.addVertex(paramInt, new Vertex(this.tmpV1, false));
/*  779 */     paramOutline.addVertex(paramInt + 2, new Vertex(this.tmpV3, false));
/*      */     
/*  781 */     this.addedVerticeCount += 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkOverlaps() {
/*  794 */     ArrayList<Vertex> arrayList = new ArrayList(3);
/*  795 */     int i = getOutlineCount();
/*  796 */     boolean bool = true;
/*      */     do {
/*  798 */       for (byte b = 0; b < i; b++) {
/*  799 */         Outline outline = getOutline(b);
/*  800 */         int j = outline.getVertexCount();
/*  801 */         for (byte b1 = 0; b1 < outline.getVertexCount(); b1++) {
/*  802 */           Vertex vertex = outline.getVertex(b1);
/*  803 */           if (!vertex.isOnCurve()) {
/*  804 */             Vertex vertex3, vertex1 = outline.getVertex((b1 + 1) % j);
/*  805 */             Vertex vertex2 = outline.getVertex((b1 + j - 1) % j);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  812 */             if (bool) {
/*  813 */               vertex3 = checkTriOverlaps0(vertex2, vertex, vertex1);
/*      */             } else {
/*  815 */               vertex3 = null;
/*      */             } 
/*  817 */             if (null != vertex3 || arrayList.contains(vertex)) {
/*  818 */               arrayList.remove(vertex);
/*      */               
/*  820 */               subdivideTriangle(outline, vertex2, vertex, vertex1, b1);
/*  821 */               b1 += 3;
/*  822 */               j += 2;
/*  823 */               this.addedVerticeCount += 2;
/*      */               
/*  825 */               if (vertex3 != null && !vertex3.isOnCurve() && 
/*  826 */                 !arrayList.contains(vertex3)) {
/*  827 */                 arrayList.add(vertex3);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  834 */       bool = false;
/*  835 */     } while (!arrayList.isEmpty());
/*      */   }
/*      */   
/*      */   private Vertex checkTriOverlaps0(Vertex paramVertex1, Vertex paramVertex2, Vertex paramVertex3) {
/*  839 */     int i = getOutlineCount();
/*  840 */     for (byte b = 0; b < i; b++) {
/*  841 */       Outline outline = getOutline(b);
/*  842 */       int j = outline.getVertexCount();
/*  843 */       for (byte b1 = 0; b1 < j; b1++) {
/*  844 */         Vertex vertex = outline.getVertex(b1);
/*  845 */         if (!vertex.isOnCurve() && vertex != paramVertex1 && vertex != paramVertex2 && vertex != paramVertex3) {
/*      */ 
/*      */           
/*  848 */           Vertex vertex1 = outline.getVertex((b1 + 1) % j);
/*  849 */           Vertex vertex2 = outline.getVertex((b1 + j - 1) % j);
/*      */ 
/*      */           
/*  852 */           if (vertex2 != paramVertex3 && vertex1 != paramVertex1) {
/*      */ 
/*      */ 
/*      */             
/*  856 */             if (VectorUtil.isVec3InTriangle3(paramVertex1.getCoord(), paramVertex2.getCoord(), paramVertex3.getCoord(), vertex
/*  857 */                 .getCoord(), vertex1.getCoord(), vertex2.getCoord(), this.tmpV1, this.tmpV2, this.tmpV3))
/*      */             {
/*  859 */               return vertex;
/*      */             }
/*  861 */             if (VectorUtil.testTri2SegIntersection((Vert2fImmutable)paramVertex1, (Vert2fImmutable)paramVertex2, (Vert2fImmutable)paramVertex3, (Vert2fImmutable)vertex2, (Vert2fImmutable)vertex) || 
/*  862 */               VectorUtil.testTri2SegIntersection((Vert2fImmutable)paramVertex1, (Vert2fImmutable)paramVertex2, (Vert2fImmutable)paramVertex3, (Vert2fImmutable)vertex, (Vert2fImmutable)vertex1) || 
/*  863 */               VectorUtil.testTri2SegIntersection((Vert2fImmutable)paramVertex1, (Vert2fImmutable)paramVertex2, (Vert2fImmutable)paramVertex3, (Vert2fImmutable)vertex2, (Vert2fImmutable)vertex1))
/*  864 */               return vertex; 
/*      */           } 
/*      */         } 
/*      */       } 
/*  868 */     }  return null;
/*      */   }
/*      */   
/*      */   private Vertex checkTriOverlaps1(Vertex paramVertex1, Vertex paramVertex2, Vertex paramVertex3) {
/*  872 */     int i = getOutlineCount();
/*  873 */     for (byte b = 0; b < i; b++) {
/*  874 */       Outline outline = getOutline(b);
/*  875 */       int j = outline.getVertexCount();
/*  876 */       for (byte b1 = 0; b1 < j; b1++) {
/*  877 */         Vertex vertex = outline.getVertex(b1);
/*  878 */         if (!vertex.isOnCurve() && vertex != paramVertex1 && vertex != paramVertex2 && vertex != paramVertex3) {
/*      */ 
/*      */           
/*  881 */           Vertex vertex1 = outline.getVertex((b1 + 1) % j);
/*  882 */           Vertex vertex2 = outline.getVertex((b1 + j - 1) % j);
/*      */ 
/*      */           
/*  885 */           if (vertex2 != paramVertex3 && vertex1 != paramVertex1) {
/*      */ 
/*      */ 
/*      */             
/*  889 */             if (VectorUtil.isVec3InTriangle3(paramVertex1.getCoord(), paramVertex2.getCoord(), paramVertex3.getCoord(), vertex
/*  890 */                 .getCoord(), vertex1.getCoord(), vertex2.getCoord(), this.tmpV1, this.tmpV2, this.tmpV3, 1.1920929E-7F))
/*      */             {
/*  892 */               return vertex;
/*      */             }
/*  894 */             if (VectorUtil.testTri2SegIntersection((Vert2fImmutable)paramVertex1, (Vert2fImmutable)paramVertex2, (Vert2fImmutable)paramVertex3, (Vert2fImmutable)vertex2, (Vert2fImmutable)vertex, 1.1920929E-7F) || 
/*  895 */               VectorUtil.testTri2SegIntersection((Vert2fImmutable)paramVertex1, (Vert2fImmutable)paramVertex2, (Vert2fImmutable)paramVertex3, (Vert2fImmutable)vertex, (Vert2fImmutable)vertex1, 1.1920929E-7F) || 
/*  896 */               VectorUtil.testTri2SegIntersection((Vert2fImmutable)paramVertex1, (Vert2fImmutable)paramVertex2, (Vert2fImmutable)paramVertex3, (Vert2fImmutable)vertex2, (Vert2fImmutable)vertex1, 1.1920929E-7F))
/*  897 */               return vertex; 
/*      */           } 
/*      */         } 
/*      */       } 
/*  901 */     }  return null;
/*      */   }
/*      */   
/*      */   private void cleanupOutlines() {
/*  905 */     boolean bool = (VerticesState.QUADRATIC_NURBS != this.outlineState) ? true : false;
/*  906 */     int i = getOutlineCount();
/*  907 */     for (byte b = 0; b < i; b++) {
/*  908 */       Outline outline = getOutline(b);
/*  909 */       int j = outline.getVertexCount();
/*      */       
/*  911 */       if (bool) {
/*  912 */         for (byte b1 = 0; b1 < j; b1++) {
/*  913 */           Vertex vertex1 = outline.getVertex(b1);
/*  914 */           int k = (b1 + 1) % j;
/*  915 */           Vertex vertex2 = outline.getVertex(k);
/*  916 */           if (!vertex1.isOnCurve() && !vertex2.isOnCurve()) {
/*  917 */             VectorUtil.midVec3(this.tmpV1, vertex1.getCoord(), vertex2.getCoord());
/*  918 */             System.err.println("XXX: Cubic: " + b1 + ": " + vertex1 + ", " + k + ": " + vertex2);
/*  919 */             Vertex vertex = new Vertex(this.tmpV1, true);
/*  920 */             b1++;
/*  921 */             j++;
/*  922 */             this.addedVerticeCount++;
/*  923 */             outline.addVertex(b1, vertex);
/*      */           } 
/*      */         } 
/*      */       }
/*  927 */       if (0 >= j) {
/*  928 */         this.outlines.remove(outline);
/*  929 */         b--;
/*  930 */         i--;
/*  931 */       } else if (0 < j && outline
/*  932 */         .getVertex(0).getCoord().isEqual(outline.getLastVertex().getCoord())) {
/*  933 */         outline.removeVertex(j - 1);
/*      */       } 
/*      */     } 
/*  936 */     this.outlineState = VerticesState.QUADRATIC_NURBS;
/*  937 */     checkOverlaps();
/*      */   }
/*      */   
/*      */   private int generateVertexIds() {
/*  941 */     byte b1 = 0;
/*  942 */     for (byte b2 = 0; b2 < this.outlines.size(); b2++) {
/*  943 */       ArrayList<Vertex> arrayList = ((Outline)this.outlines.get(b2)).getVertices();
/*  944 */       for (byte b = 0; b < arrayList.size(); b++) {
/*  945 */         ((Vertex)arrayList.get(b)).setId(b1++);
/*      */       }
/*      */     } 
/*  948 */     return b1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ArrayList<Vertex> getVertices() {
/*  964 */     if (0 != (0x2 & this.dirtyBits)) {
/*  965 */       this.vertices.clear();
/*  966 */       for (byte b = 0; b < this.outlines.size(); b++) {
/*  967 */         this.vertices.addAll(((Outline)this.outlines.get(b)).getVertices());
/*      */       }
/*  969 */       this.dirtyBits &= 0xFFFFFFFD;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  977 */     return this.vertices;
/*      */   }
/*      */   
/*      */   private void triangulateImpl() {
/*  981 */     if (0 < this.outlines.size()) {
/*  982 */       sortOutlines();
/*  983 */       generateVertexIds();
/*      */       
/*  985 */       this.triangles.clear();
/*  986 */       Triangulator triangulator = Triangulation.create();
/*  987 */       for (byte b = 0; b < this.outlines.size(); b++) {
/*  988 */         triangulator.addCurve(this.triangles, this.outlines.get(b), this.sharpness);
/*      */       }
/*  990 */       triangulator.generate(this.triangles);
/*  991 */       this.addedVerticeCount += triangulator.getAddedVerticeCount();
/*  992 */       triangulator.reset();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ArrayList<Triangle> getTriangles(VerticesState paramVerticesState) {
/*      */     boolean bool;
/* 1007 */     if (paramVerticesState != VerticesState.QUADRATIC_NURBS) {
/* 1008 */       throw new IllegalStateException("destinationType " + paramVerticesState.name() + " not supported (currently " + this.outlineState.name() + ")");
/*      */     }
/* 1010 */     if (0 != (0x4 & this.dirtyBits)) {
/* 1011 */       cleanupOutlines();
/* 1012 */       triangulateImpl();
/* 1013 */       bool = true;
/* 1014 */       this.dirtyBits |= 0x2;
/* 1015 */       this.dirtyBits &= 0xFFFFFFFB;
/*      */     } else {
/* 1017 */       bool = false;
/*      */     } 
/* 1019 */     if (Region.DEBUG_INSTANCE) {
/* 1020 */       System.err.println("OutlineShape.getTriangles().X: " + this.triangles.size() + ", updated " + bool);
/*      */     }
/* 1022 */     return this.triangles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final OutlineShape transform(AffineTransform paramAffineTransform) {
/* 1032 */     OutlineShape outlineShape = new OutlineShape();
/* 1033 */     int i = this.outlines.size();
/* 1034 */     for (byte b = 0; b < i; b++) {
/* 1035 */       outlineShape.addOutline(((Outline)this.outlines.get(b)).transform(paramAffineTransform));
/*      */     }
/* 1037 */     return outlineShape;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sortOutlines() {
/* 1045 */     Collections.sort(this.outlines, reversSizeComparator);
/*      */   }
/*      */   
/* 1048 */   private static Comparator<Outline> reversSizeComparator = new Comparator<Outline>()
/*      */     {
/*      */       public int compare(Outline param1Outline1, Outline param1Outline2) {
/* 1051 */         return param1Outline2.compareTo(param1Outline1);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int compareTo(OutlineShape paramOutlineShape) {
/* 1061 */     float f1 = getBounds().getSize();
/* 1062 */     float f2 = paramOutlineShape.getBounds().getSize();
/* 1063 */     if (FloatUtil.isEqual(f1, f2, 1.1920929E-7F))
/* 1064 */       return 0; 
/* 1065 */     if (f1 < f2) {
/* 1066 */       return -1;
/*      */     }
/* 1068 */     return 1;
/*      */   }
/*      */ 
/*      */   
/*      */   private void validateBoundingBox() {
/* 1073 */     this.dirtyBits &= 0xFFFFFFFE;
/* 1074 */     this.bbox.reset();
/* 1075 */     for (byte b = 0; b < this.outlines.size(); b++) {
/* 1076 */       this.bbox.resize(((Outline)this.outlines.get(b)).getBounds());
/*      */     }
/*      */   }
/*      */   
/*      */   public final AABBox getBounds() {
/* 1081 */     if (0 == (this.dirtyBits & 0x1)) {
/* 1082 */       validateBoundingBox();
/*      */     }
/* 1084 */     return this.bbox;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean equals(Object paramObject) {
/* 1094 */     if (paramObject == this) {
/* 1095 */       return true;
/*      */     }
/* 1097 */     if (null == paramObject || !(paramObject instanceof OutlineShape)) {
/* 1098 */       return false;
/*      */     }
/* 1100 */     OutlineShape outlineShape = (OutlineShape)paramObject;
/* 1101 */     if (getOutlineState() != outlineShape.getOutlineState()) {
/* 1102 */       return false;
/*      */     }
/* 1104 */     if (getOutlineCount() != outlineShape.getOutlineCount()) {
/* 1105 */       return false;
/*      */     }
/* 1107 */     if (!getBounds().equals(outlineShape.getBounds())) {
/* 1108 */       return false;
/*      */     }
/* 1110 */     for (int i = getOutlineCount() - 1; i >= 0; i--) {
/* 1111 */       if (!getOutline(i).equals(outlineShape.getOutline(i))) {
/* 1112 */         return false;
/*      */       }
/*      */     } 
/* 1115 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int hashCode() {
/* 1120 */     throw new InternalError("hashCode not designed");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1126 */     return getClass().getName() + "@" + Integer.toHexString(super.hashCode());
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/curve/OutlineShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */