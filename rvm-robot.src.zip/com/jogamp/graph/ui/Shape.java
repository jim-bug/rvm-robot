/*      */ package com.jogamp.graph.ui;
/*      */ 
/*      */ import com.jogamp.graph.curve.opengl.RegionRenderer;
/*      */ import com.jogamp.graph.ui.layout.Padding;
/*      */ import com.jogamp.nativewindow.NativeWindowException;
/*      */ import com.jogamp.newt.event.GestureHandler;
/*      */ import com.jogamp.newt.event.MouseAdapter;
/*      */ import com.jogamp.newt.event.MouseEvent;
/*      */ import com.jogamp.newt.event.MouseListener;
/*      */ import com.jogamp.newt.event.PinchToZoomGesture;
/*      */ import com.jogamp.opengl.GL2ES2;
/*      */ import com.jogamp.opengl.GLProfile;
/*      */ import com.jogamp.opengl.math.FloatUtil;
/*      */ import com.jogamp.opengl.math.Matrix4f;
/*      */ import com.jogamp.opengl.math.Quaternion;
/*      */ import com.jogamp.opengl.math.Recti;
/*      */ import com.jogamp.opengl.math.Vec2f;
/*      */ import com.jogamp.opengl.math.Vec3f;
/*      */ import com.jogamp.opengl.math.Vec4f;
/*      */ import com.jogamp.opengl.math.geom.AABBox;
/*      */ import com.jogamp.opengl.util.PMVMatrix;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Comparator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Shape
/*      */ {
/*      */   protected static final boolean DEBUG_DRAW = false;
/*      */   private static final boolean DEBUG = false;
/*      */   private static final int DIRTY_SHAPE = 1;
/*      */   private static final int DIRTY_STATE = 2;
/*      */   protected final AABBox box;
/*  130 */   private final Vec3f position = new Vec3f();
/*  131 */   private final Quaternion rotation = new Quaternion();
/*  132 */   private Vec3f rotPivot = null;
/*  133 */   private final Vec3f scale = new Vec3f(1.0F, 1.0F, 1.0F);
/*      */   
/*  135 */   private volatile int dirty = 3;
/*  136 */   private final Object dirtySync = new Object();
/*      */ 
/*      */   
/*  139 */   protected final Vec4f rgbaColor = new Vec4f(0.6F, 0.6F, 0.6F, 1.0F);
/*      */   
/*  141 */   protected final Vec4f pressedRGBAModulate = new Vec4f(0.7F, 0.7F, 0.7F, 0.8F);
/*      */   
/*  143 */   protected final Vec4f toggleOnRGBAModulate = new Vec4f(0.83F, 0.83F, 0.83F, 1.0F);
/*      */   
/*  145 */   protected final Vec4f toggleOffRGBAModulate = new Vec4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */   
/*  147 */   private final Vec4f rgba_tmp = new Vec4f(0.0F, 0.0F, 0.0F, 1.0F);
/*  148 */   private final Vec4f cWhite = new Vec4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */   
/*  150 */   private int name = -1;
/*      */   
/*      */   private boolean down = false;
/*      */   private boolean toggle = false;
/*      */   private boolean toggleable = false;
/*      */   private boolean draggable = true;
/*      */   private boolean resizable = true;
/*      */   private boolean interactive = true;
/*      */   private boolean enabled = true;
/*  159 */   private float borderThickness = 0.0F;
/*  160 */   private Padding padding = null;
/*  161 */   private final Vec4f borderColor = new Vec4f(0.0F, 0.0F, 0.0F, 1.0F);
/*  162 */   private ArrayList<MouseGestureListener> mouseListeners = new ArrayList<>();
/*      */   
/*  164 */   private ListenerBool onInitListener = null;
/*  165 */   private Listener onMoveListener = null;
/*  166 */   private Listener onToggleListener = null; private boolean dragFirst; private final Vec2f objDraggedFirst; private final int[] winDraggedLast; private boolean inMove;
/*  167 */   private Listener onClickedListener = null;
/*      */   
/*      */   private int inResize;
/*      */   private static final float resize_sxy_min = 0.005F;
/*      */   private static final float resize_section = 0.2F;
/*      */   
/*      */   public final Shape setName(int paramInt) {
/*  174 */     this.name = paramInt; return this;
/*      */   } public final int getName() {
/*  176 */     return this.name;
/*      */   }
/*      */   public final boolean isEnabled() {
/*  179 */     return this.enabled;
/*      */   } public final Shape setEnabled(boolean paramBoolean) {
/*  181 */     this.enabled = paramBoolean; return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setPaddding(Padding paramPadding) {
/*  194 */     this.padding = paramPadding;
/*  195 */     markShapeDirty();
/*  196 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Padding getPadding() {
/*  204 */     return this.padding;
/*      */   }
/*      */   public boolean hasPadding() {
/*  207 */     return (null != this.padding && !this.padding.zeroSumSize());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setBorder(float paramFloat) {
/*  218 */     this.borderThickness = Math.max(0.0F, paramFloat);
/*  219 */     markShapeDirty();
/*  220 */     return this;
/*      */   }
/*      */   public final boolean hasBorder() {
/*  223 */     return !FloatUtil.isZero(this.borderThickness);
/*      */   }
/*      */   public final float getBorderThickness() {
/*  226 */     return this.borderThickness;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void clear(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/*  234 */     synchronized (this.dirtySync) {
/*  235 */       clearImpl0(paramGL2ES2, paramRegionRenderer);
/*  236 */       this.position.set(0.0F, 0.0F, 0.0F);
/*  237 */       this.rotation.setIdentity();
/*  238 */       this.rotPivot = null;
/*  239 */       this.scale.set(1.0F, 1.0F, 1.0F);
/*  240 */       this.box.reset();
/*  241 */       markShapeDirty();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void destroy(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/*  251 */     destroyImpl0(paramGL2ES2, paramRegionRenderer);
/*  252 */     this.position.set(0.0F, 0.0F, 0.0F);
/*  253 */     this.rotation.setIdentity();
/*  254 */     this.rotPivot = null;
/*  255 */     this.scale.set(1.0F, 1.0F, 1.0F);
/*  256 */     this.box.reset();
/*  257 */     markShapeDirty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void onInit(ListenerBool paramListenerBool) {
/*  269 */     this.onInitListener = paramListenerBool;
/*  270 */   } public final void onMove(Listener paramListener) { this.onMoveListener = paramListener; }
/*  271 */   public final void onToggle(Listener paramListener) { this.onToggleListener = paramListener; } public final void onClicked(Listener paramListener) {
/*  272 */     this.onClickedListener = paramListener;
/*      */   }
/*      */   
/*      */   public final Shape moveTo(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  276 */     this.position.set(paramFloat1, paramFloat2, paramFloat3);
/*  277 */     if (null != this.onMoveListener) {
/*  278 */       this.onMoveListener.run(this);
/*      */     }
/*  280 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Shape moveTo(Vec3f paramVec3f) {
/*  285 */     this.position.set(paramVec3f);
/*  286 */     if (null != this.onMoveListener) {
/*  287 */       this.onMoveListener.run(this);
/*      */     }
/*  289 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Shape move(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  294 */     this.position.add(paramFloat1, paramFloat2, paramFloat3);
/*  295 */     if (null != this.onMoveListener) {
/*  296 */       this.onMoveListener.run(this);
/*      */     }
/*  298 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Shape move(Vec3f paramVec3f) {
/*  303 */     this.position.add(paramVec3f);
/*  304 */     if (null != this.onMoveListener) {
/*  305 */       this.onMoveListener.run(this);
/*      */     }
/*  307 */     return this;
/*      */   }
/*      */   
/*      */   public final Vec3f getPosition() {
/*  311 */     return this.position;
/*      */   }
/*      */   public final Quaternion getRotation() {
/*  314 */     return this.rotation;
/*      */   } public final Vec3f getRotationPivot() {
/*  316 */     return this.rotPivot;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setRotationPivot(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  322 */     this.rotPivot = new Vec3f(paramFloat1, paramFloat2, paramFloat3);
/*  323 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setRotationPivot(Vec3f paramVec3f) {
/*  331 */     this.rotPivot = new Vec3f(paramVec3f);
/*  332 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setScale(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  341 */     this.scale.set(paramFloat1, paramFloat2, paramFloat3);
/*  342 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape scale(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  350 */     this.scale.scale(paramFloat1, paramFloat2, paramFloat3);
/*  351 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Vec3f getScale() {
/*  358 */     return this.scale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markShapeDirty() {
/*  365 */     synchronized (this.dirtySync) {
/*  366 */       this.dirty |= 0x1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markStateDirty() {
/*  375 */     synchronized (this.dirtySync) {
/*  376 */       this.dirty |= 0x2;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final boolean isShapeDirty() {
/*  381 */     return (0 != (this.dirty & 0x1));
/*      */   }
/*      */   protected final boolean isStateDirty() {
/*  384 */     return (0 != (this.dirty & 0x2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AABBox getBounds() {
/*  398 */     return this.box;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getScaledWidth() {
/*  412 */     return this.box.getWidth() * getScale().x();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getScaledHeight() {
/*  427 */     return this.box.getHeight() * getScale().y();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AABBox getBounds(GLProfile paramGLProfile) {
/*  440 */     validate(paramGLProfile);
/*  441 */     return this.box;
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawToSelect(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint) {
/*  446 */     synchronized (this.dirtySync) {
/*  447 */       validate(paramGL2ES2);
/*  448 */       drawImpl0(paramGL2ES2, paramRegionRenderer, paramArrayOfint, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void draw(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint) {
/*      */     Vec4f vec4f;
/*  462 */     boolean bool1 = isPressed(), bool2 = isToggleOn();
/*      */     
/*  464 */     if (hasColorChannel()) {
/*  465 */       if (bool1) {
/*  466 */         vec4f = this.pressedRGBAModulate;
/*  467 */       } else if (isToggleable()) {
/*  468 */         if (bool2) {
/*  469 */           vec4f = this.toggleOnRGBAModulate;
/*      */         } else {
/*  471 */           vec4f = this.toggleOffRGBAModulate;
/*      */         } 
/*      */       } else {
/*  474 */         vec4f = this.cWhite;
/*      */       } 
/*      */     } else {
/*  477 */       vec4f = this.rgba_tmp;
/*  478 */       if (bool1) {
/*  479 */         vec4f.mul(this.rgbaColor, this.pressedRGBAModulate);
/*  480 */       } else if (isToggleable()) {
/*  481 */         if (bool2) {
/*  482 */           vec4f.mul(this.rgbaColor, this.toggleOnRGBAModulate);
/*      */         } else {
/*  484 */           vec4f.mul(this.rgbaColor, this.toggleOffRGBAModulate);
/*      */         } 
/*      */       } else {
/*  487 */         vec4f.set(this.rgbaColor);
/*      */       } 
/*      */     } 
/*  490 */     synchronized (this.dirtySync) {
/*  491 */       validate(paramGL2ES2);
/*  492 */       drawImpl0(paramGL2ES2, paramRegionRenderer, paramArrayOfint, vec4f);
/*      */     } 
/*  494 */     if (null != this.onInitListener && 
/*  495 */       this.onInitListener.run(this)) {
/*  496 */       this.onInitListener = null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape validate(GL2ES2 paramGL2ES2) {
/*  510 */     synchronized (this.dirtySync) {
/*  511 */       if (isShapeDirty()) {
/*  512 */         this.box.reset();
/*      */       }
/*  514 */       validateImpl(paramGL2ES2.getGLProfile(), paramGL2ES2);
/*  515 */       this.dirty = 0;
/*      */     } 
/*  517 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape validate(GLProfile paramGLProfile) {
/*  529 */     synchronized (this.dirtySync) {
/*  530 */       if (isShapeDirty()) {
/*  531 */         this.box.reset();
/*      */       }
/*  533 */       validateImpl(paramGLProfile, null);
/*  534 */       this.dirty = 0;
/*      */     } 
/*  536 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransform(PMVMatrix paramPMVMatrix) {
/*  553 */     boolean bool1 = !this.scale.isEqual(Vec3f.ONE) ? true : false;
/*  554 */     boolean bool2 = !this.rotation.isIdentity() ? true : false;
/*  555 */     boolean bool3 = (null != this.rotPivot) ? true : false;
/*  556 */     Vec3f vec3f = this.box.getCenter();
/*  557 */     boolean bool4 = (bool1 && bool2 && (!bool3 || this.rotPivot.isEqual(vec3f))) ? true : false;
/*      */     
/*  559 */     paramPMVMatrix.glTranslatef(this.position.x(), this.position.y(), this.position.z());
/*      */     
/*  561 */     if (bool4) {
/*      */       
/*  563 */       paramPMVMatrix.glTranslatef(vec3f.x() * this.scale.x(), vec3f.y() * this.scale.y(), vec3f.z() * this.scale.z());
/*  564 */       paramPMVMatrix.glRotate(this.rotation);
/*  565 */       paramPMVMatrix.glScalef(this.scale.x(), this.scale.y(), this.scale.z());
/*  566 */       paramPMVMatrix.glTranslatef(-vec3f.x(), -vec3f.y(), -vec3f.z());
/*  567 */     } else if (bool2 || bool1) {
/*  568 */       if (bool2) {
/*  569 */         if (bool3) {
/*      */           
/*  571 */           paramPMVMatrix.glTranslatef(this.rotPivot.x() * this.scale.x(), this.rotPivot.y() * this.scale.y(), this.rotPivot.z() * this.scale.z());
/*  572 */           paramPMVMatrix.glRotate(this.rotation);
/*  573 */           paramPMVMatrix.glTranslatef(-this.rotPivot.x() * this.scale.x(), -this.rotPivot.y() * this.scale.y(), -this.rotPivot.z() * this.scale.z());
/*      */         } else {
/*      */           
/*  576 */           paramPMVMatrix.glTranslatef(vec3f.x() * this.scale.x(), vec3f.y() * this.scale.y(), vec3f.z() * this.scale.z());
/*  577 */           paramPMVMatrix.glRotate(this.rotation);
/*  578 */           paramPMVMatrix.glTranslatef(-vec3f.x() * this.scale.x(), -vec3f.y() * this.scale.y(), -vec3f.z() * this.scale.z());
/*      */         } 
/*      */       }
/*  581 */       if (bool1) {
/*      */         
/*  583 */         paramPMVMatrix.glTranslatef(vec3f.x() * this.scale.x(), vec3f.y() * this.scale.y(), vec3f.z() * this.scale.z());
/*  584 */         paramPMVMatrix.glScalef(this.scale.x(), this.scale.y(), this.scale.z());
/*  585 */         paramPMVMatrix.glTranslatef(-vec3f.x(), -vec3f.y(), -vec3f.z());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Recti getSurfacePort(PMVMatrix paramPMVMatrix, Recti paramRecti1, Recti paramRecti2) {
/*  603 */     Vec3f vec3f1 = new Vec3f();
/*  604 */     Vec3f vec3f2 = new Vec3f();
/*  605 */     Vec3f vec3f3 = this.box.getHigh();
/*  606 */     Vec3f vec3f4 = this.box.getLow();
/*      */     
/*  608 */     Matrix4f matrix4f = paramPMVMatrix.getPMvMat();
/*  609 */     if (Matrix4f.mapObjToWin(vec3f3, matrix4f, paramRecti1, vec3f1) && 
/*  610 */       Matrix4f.mapObjToWin(vec3f4, matrix4f, paramRecti1, vec3f2)) {
/*  611 */       paramRecti2.setX((int)Math.abs(vec3f2.x()));
/*  612 */       paramRecti2.setY((int)Math.abs(vec3f2.y()));
/*  613 */       paramRecti2.setWidth((int)Math.abs(vec3f1.x() - vec3f2.x()));
/*  614 */       paramRecti2.setHeight((int)Math.abs(vec3f1.y() - vec3f2.y()));
/*  615 */       return paramRecti2;
/*      */     } 
/*      */     
/*  618 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getSurfaceSize(PMVMatrix paramPMVMatrix, Recti paramRecti, int[] paramArrayOfint) {
/*  637 */     Vec3f vec3f1 = new Vec3f();
/*  638 */     Vec3f vec3f2 = new Vec3f();
/*  639 */     Vec3f vec3f3 = this.box.getHigh();
/*  640 */     Vec3f vec3f4 = this.box.getLow();
/*      */     
/*  642 */     Matrix4f matrix4f = paramPMVMatrix.getPMvMat();
/*  643 */     if (Matrix4f.mapObjToWin(vec3f3, matrix4f, paramRecti, vec3f1) && 
/*  644 */       Matrix4f.mapObjToWin(vec3f4, matrix4f, paramRecti, vec3f2)) {
/*  645 */       paramArrayOfint[0] = (int)Math.abs(vec3f1.x() - vec3f2.x());
/*  646 */       paramArrayOfint[1] = (int)Math.abs(vec3f1.y() - vec3f2.y());
/*  647 */       return paramArrayOfint;
/*      */     } 
/*      */     
/*  650 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getSurfaceSize(Scene.PMVMatrixSetup paramPMVMatrixSetup, Recti paramRecti, PMVMatrix paramPMVMatrix, int[] paramArrayOfint) {
/*  669 */     paramPMVMatrixSetup.set(paramPMVMatrix, paramRecti);
/*  670 */     setTransform(paramPMVMatrix);
/*  671 */     return getSurfaceSize(paramPMVMatrix, paramRecti, paramArrayOfint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getSurfaceSize(Scene paramScene, PMVMatrix paramPMVMatrix, int[] paramArrayOfint) {
/*  689 */     return getSurfaceSize(paramScene.getPMVMatrixSetup(), paramScene.getViewport(), paramPMVMatrix, paramArrayOfint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getPixelPerShapeUnit(Scene paramScene, PMVMatrix paramPMVMatrix, float[] paramArrayOffloat) {
/*  709 */     int[] arrayOfInt = new int[2];
/*  710 */     if (null != getSurfaceSize(paramScene, new PMVMatrix(), arrayOfInt)) {
/*  711 */       return getPixelPerShapeUnit(arrayOfInt, paramArrayOffloat);
/*      */     }
/*  713 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getPixelPerShapeUnit(int[] paramArrayOfint, float[] paramArrayOffloat) {
/*  728 */     paramArrayOffloat[0] = paramArrayOfint[0] / getScaledWidth();
/*  729 */     paramArrayOffloat[0] = paramArrayOfint[1] / getScaledHeight();
/*  730 */     return paramArrayOffloat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] shapeToWinCoord(PMVMatrix paramPMVMatrix, Recti paramRecti, Vec3f paramVec3f, int[] paramArrayOfint) {
/*  750 */     Vec3f vec3f = new Vec3f();
/*      */     
/*  752 */     if (paramPMVMatrix.gluProject(paramVec3f, paramRecti, vec3f)) {
/*  753 */       paramArrayOfint[0] = (int)vec3f.x();
/*  754 */       paramArrayOfint[1] = (int)vec3f.y();
/*  755 */       return paramArrayOfint;
/*      */     } 
/*  757 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] shapeToWinCoord(Scene.PMVMatrixSetup paramPMVMatrixSetup, Recti paramRecti, Vec3f paramVec3f, PMVMatrix paramPMVMatrix, int[] paramArrayOfint) {
/*  777 */     paramPMVMatrixSetup.set(paramPMVMatrix, paramRecti);
/*  778 */     setTransform(paramPMVMatrix);
/*  779 */     return shapeToWinCoord(paramPMVMatrix, paramRecti, paramVec3f, paramArrayOfint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] shapeToWinCoord(Scene paramScene, Vec3f paramVec3f, PMVMatrix paramPMVMatrix, int[] paramArrayOfint) {
/*  798 */     return shapeToWinCoord(paramScene.getPMVMatrixSetup(), paramScene.getViewport(), paramVec3f, paramPMVMatrix, paramArrayOfint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3f winToShapeCoord(PMVMatrix paramPMVMatrix, Recti paramRecti, int paramInt1, int paramInt2, Vec3f paramVec3f) {
/*  818 */     Vec3f vec3f = this.box.getCenter();
/*      */     
/*  820 */     if (Matrix4f.mapObjToWin(vec3f, paramPMVMatrix.getPMvMat(), paramRecti, paramVec3f)) {
/*  821 */       float f = paramVec3f.z();
/*  822 */       if (Matrix4f.mapWinToObj(paramInt1, paramInt2, f, paramPMVMatrix.getPMviMat(), paramRecti, paramVec3f)) {
/*  823 */         return paramVec3f;
/*      */       }
/*      */     } 
/*  826 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3f winToShapeCoord(Scene.PMVMatrixSetup paramPMVMatrixSetup, Recti paramRecti, int paramInt1, int paramInt2, PMVMatrix paramPMVMatrix, Vec3f paramVec3f) {
/*  847 */     paramPMVMatrixSetup.set(paramPMVMatrix, paramRecti);
/*  848 */     setTransform(paramPMVMatrix);
/*  849 */     return winToShapeCoord(paramPMVMatrix, paramRecti, paramInt1, paramInt2, paramVec3f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3f winToShapeCoord(Scene paramScene, int paramInt1, int paramInt2, PMVMatrix paramPMVMatrix, Vec3f paramVec3f) {
/*  869 */     return winToShapeCoord(paramScene.getPMVMatrixSetup(), paramScene.getViewport(), paramInt1, paramInt2, paramPMVMatrix, paramVec3f);
/*      */   }
/*      */   public Vec4f getColor() {
/*  872 */     return this.rgbaColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setColor(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  881 */     this.rgbaColor.set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*  882 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setColor(Vec4f paramVec4f) {
/*  892 */     this.rgbaColor.set(paramVec4f);
/*  893 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setPressedColorMod(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  903 */     this.pressedRGBAModulate.set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*  904 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setToggleOnColorMod(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  914 */     this.toggleOnRGBAModulate.set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*  915 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape setToggleOffColorMod(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  925 */     this.toggleOffRGBAModulate.set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*  926 */     return this;
/*      */   }
/*      */   public Vec4f getBorderColor() {
/*  929 */     return this.borderColor;
/*      */   }
/*      */   
/*      */   public final Shape setBorderColor(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  933 */     this.borderColor.set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*  934 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Shape setBorderColor(Vec4f paramVec4f) {
/*  939 */     this.borderColor.set(paramVec4f);
/*  940 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String toString() {
/*  945 */     return getClass().getSimpleName() + "[" + getSubString() + "]";
/*      */   }
/*      */   
/*      */   public String getSubString() {
/*      */     String str1, str2, str3;
/*  950 */     if (null != this.rotPivot) {
/*  951 */       str1 = "pivot[" + this.rotPivot + "], ";
/*      */     } else {
/*  953 */       str1 = "";
/*      */     } 
/*      */     
/*  956 */     if (!this.scale.isEqual(Vec3f.ONE)) {
/*  957 */       str2 = "scale[" + this.scale + "], ";
/*      */     } else {
/*  959 */       str2 = "scale 1, ";
/*      */     } 
/*      */     
/*  962 */     if (!this.rotation.isIdentity()) {
/*  963 */       Vec3f vec3f = this.rotation.toEuler(new Vec3f());
/*  964 */       str3 = "rot[" + vec3f + "], ";
/*      */     } else {
/*  966 */       str3 = "";
/*      */     } 
/*  968 */     String str4 = hasPadding() ? (this.padding.toString() + ", ") : "";
/*  969 */     String str5 = hasBorder() ? ("Border " + getBorderThickness() + ", ") : "";
/*  970 */     return "enabled " + this.enabled + ", toggle[able " + this.toggleable + ", state " + this.toggle + "], able[iactive " + 
/*  971 */       isInteractive() + ", resize " + isResizable() + ", move " + isDraggable() + "], pos[" + this.position + "], " + str1 + str2 + str3 + str4 + str5 + "box" + this.box;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape setPressed(boolean paramBoolean) {
/*  981 */     this.down = paramBoolean;
/*  982 */     markStateDirty();
/*  983 */     return this;
/*      */   }
/*      */   public boolean isPressed() {
/*  986 */     return this.down;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape setToggleable(boolean paramBoolean) {
/*  995 */     this.toggleable = paramBoolean;
/*  996 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isToggleable() {
/* 1005 */     return this.toggleable;
/*      */   }
/*      */   public Shape setToggle(boolean paramBoolean) {
/* 1008 */     this.toggle = paramBoolean;
/* 1009 */     markStateDirty();
/* 1010 */     return this;
/*      */   }
/*      */   public Shape toggle() {
/* 1013 */     if (isToggleable()) {
/* 1014 */       this.toggle = !this.toggle;
/* 1015 */       if (null != this.onToggleListener) {
/* 1016 */         this.onToggleListener.run(this);
/*      */       }
/* 1018 */       markStateDirty();
/*      */     } 
/* 1020 */     return this;
/*      */   } public boolean isToggleOn() {
/* 1022 */     return this.toggle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape setInteractive(boolean paramBoolean) {
/* 1033 */     this.interactive = paramBoolean; return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInteractive() {
/* 1038 */     return this.interactive;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape setDraggable(boolean paramBoolean) {
/* 1049 */     this.draggable = paramBoolean;
/* 1050 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDraggable() {
/* 1057 */     return this.draggable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape setResizable(boolean paramBoolean) {
/* 1069 */     this.resizable = paramBoolean;
/* 1070 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isResizable() {
/* 1077 */     return this.resizable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape setDragAndResizeable(boolean paramBoolean) {
/* 1090 */     this.draggable = paramBoolean;
/* 1091 */     this.resizable = paramBoolean;
/* 1092 */     return this;
/*      */   }
/*      */   
/*      */   public final Shape addMouseListener(MouseGestureListener paramMouseGestureListener) {
/* 1096 */     if (paramMouseGestureListener == null) {
/* 1097 */       return this;
/*      */     }
/*      */     
/* 1100 */     ArrayList<MouseGestureListener> arrayList = (ArrayList)this.mouseListeners.clone();
/* 1101 */     arrayList.add(paramMouseGestureListener);
/* 1102 */     this.mouseListeners = arrayList;
/* 1103 */     return this;
/*      */   }
/*      */   
/*      */   public final Shape removeMouseListener(MouseGestureListener paramMouseGestureListener) {
/* 1107 */     if (paramMouseGestureListener == null) {
/* 1108 */       return this;
/*      */     }
/*      */     
/* 1111 */     ArrayList<MouseGestureListener> arrayList = (ArrayList)this.mouseListeners.clone();
/* 1112 */     arrayList.remove(paramMouseGestureListener);
/* 1113 */     this.mouseListeners = arrayList;
/* 1114 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class MouseGestureAdapter
/*      */     extends MouseAdapter
/*      */     implements MouseGestureListener
/*      */   {
/*      */     public void gestureDetected(GestureHandler.GestureEvent param1GestureEvent) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EventInfo
/*      */   {
/*      */     public final Shape shape;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Vec3f objPos;
/*      */ 
/*      */ 
/*      */     
/*      */     public final int[] winPos;
/*      */ 
/*      */ 
/*      */     
/* 1146 */     public final Vec2f objDrag = new Vec2f();
/*      */     
/* 1148 */     public final int[] winDrag = new int[] { 0, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     EventInfo(int param1Int1, int param1Int2, Shape param1Shape, Vec3f param1Vec3f) {
/* 1158 */       this.winPos = new int[] { param1Int1, param1Int2 };
/* 1159 */       this.shape = param1Shape;
/* 1160 */       this.objPos = param1Vec3f;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1165 */       return "EventInfo[winPos [" + this.winPos[0] + ", " + this.winPos[1] + "], objPos [" + this.objPos + "], " + this.shape + "]";
/*      */     } }
/*      */   
/*      */   public Shape() {
/* 1169 */     this.dragFirst = false;
/* 1170 */     this.objDraggedFirst = new Vec2f();
/* 1171 */     this.winDraggedLast = new int[] { 0, 0 };
/* 1172 */     this.inMove = false;
/* 1173 */     this.inResize = 0;
/*      */     this.box = new AABBox();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void dispatchMouseEvent(MouseEvent paramMouseEvent, int paramInt1, int paramInt2, Vec3f paramVec3f) {
/*      */     Vec3f vec3f;
/*      */     boolean bool1, bool2;
/*      */     float f1, f2;
/* 1185 */     EventInfo eventInfo = new EventInfo(paramInt1, paramInt2, this, paramVec3f);
/*      */     
/* 1187 */     short s = paramMouseEvent.getEventType();
/* 1188 */     if (1 == paramMouseEvent.getPointerCount()) {
/* 1189 */       switch (s) {
/*      */         case 200:
/* 1191 */           toggle();
/* 1192 */           if (null != this.onClickedListener) {
/* 1193 */             this.onClickedListener.run(this);
/*      */           }
/*      */           break;
/*      */         case 203:
/* 1197 */           this.dragFirst = true;
/* 1198 */           setPressed(true);
/*      */           break;
/*      */         
/*      */         case 204:
/* 1202 */           setPressed(false);
/* 1203 */           this.inMove = false;
/* 1204 */           this.inResize = 0;
/*      */           break;
/*      */       } 
/*      */     }
/* 1208 */     switch (s) {
/*      */       
/*      */       case 206:
/* 1211 */         vec3f = this.rotation.toEuler(new Vec3f());
/*      */ 
/*      */         
/* 1214 */         f1 = Math.abs(vec3f.x());
/* 1215 */         f2 = Math.abs(vec3f.y());
/* 1216 */         bool1 = (1.5707964F <= f2 && f2 <= 4.712389F) ? true : false;
/* 1217 */         bool2 = (1.5707964F <= f1 && f1 <= 4.712389F) ? true : false;
/*      */ 
/*      */         
/* 1220 */         if (this.dragFirst) {
/* 1221 */           this.objDraggedFirst.set(paramVec3f);
/* 1222 */           this.winDraggedLast[0] = paramInt1;
/* 1223 */           this.winDraggedLast[1] = paramInt2;
/* 1224 */           this.dragFirst = false;
/*      */           
/* 1226 */           f1 = bool1 ? (this.box.getWidth() - paramVec3f.x()) : paramVec3f.x();
/* 1227 */           f2 = bool2 ? (this.box.getHeight() - paramVec3f.y()) : paramVec3f.y();
/* 1228 */           float f3 = this.box.getMaxX() - this.box.getWidth() * 0.2F;
/* 1229 */           float f4 = this.box.getMinY();
/* 1230 */           float f5 = this.box.getMaxX();
/* 1231 */           float f6 = this.box.getMinY() + this.box.getHeight() * 0.2F;
/* 1232 */           if (f3 <= f1 && f1 <= f5 && f4 <= f2 && f2 <= f6) {
/*      */             
/* 1234 */             if (this.interactive && this.resizable) {
/* 1235 */               this.inResize = 1;
/*      */             }
/*      */           } else {
/* 1238 */             float f7 = this.box.getMinX();
/* 1239 */             float f8 = this.box.getMinY();
/* 1240 */             float f9 = this.box.getMinX() + this.box.getWidth() * 0.2F;
/* 1241 */             float f10 = this.box.getMinY() + this.box.getHeight() * 0.2F;
/* 1242 */             if (f7 <= f1 && f1 <= f9 && f8 <= f2 && f2 <= f10) {
/*      */               
/* 1244 */               if (this.interactive && this.resizable) {
/* 1245 */                 this.inResize = 2;
/*      */               }
/*      */             } else {
/* 1248 */               this.inMove = (this.interactive && this.draggable);
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */ 
/*      */         
/* 1258 */         eventInfo.objDrag.set(paramVec3f.x() - this.objDraggedFirst.x(), paramVec3f
/* 1259 */             .y() - this.objDraggedFirst.y());
/* 1260 */         eventInfo.objDrag.scale(bool1 ? -1.0F : 1.0F, bool2 ? -1.0F : 1.0F);
/*      */         
/* 1262 */         eventInfo.winDrag[0] = paramInt1 - this.winDraggedLast[0];
/* 1263 */         eventInfo.winDrag[1] = paramInt2 - this.winDraggedLast[1];
/* 1264 */         this.winDraggedLast[0] = paramInt1;
/* 1265 */         this.winDraggedLast[1] = paramInt2;
/* 1266 */         if (1 == paramMouseEvent.getPointerCount()) {
/* 1267 */           f1 = eventInfo.objDrag.x() * this.scale.x();
/* 1268 */           f2 = eventInfo.objDrag.y() * this.scale.y();
/* 1269 */           if (0 != this.inResize) {
/* 1270 */             float f5, f3 = this.box.getWidth();
/* 1271 */             float f4 = this.box.getHeight();
/*      */             
/* 1273 */             if (1 == this.inResize) {
/* 1274 */               f5 = this.scale.x() + f1 / f3;
/*      */             } else {
/* 1276 */               f5 = this.scale.x() - f1 / f3;
/*      */             } 
/* 1278 */             float f6 = this.scale.y() - f2 / f4;
/* 1279 */             if (0.005F <= f5 && 0.005F <= f6) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1286 */               if (1 == this.inResize) {
/* 1287 */                 move(0.0F, f2, 0.0F);
/*      */               } else {
/* 1289 */                 move(f1, f2, 0.0F);
/*      */               } 
/* 1291 */               setScale(f5, f6, this.scale.z());
/*      */             }  return;
/*      */           } 
/* 1294 */           if (this.inMove)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1300 */             move(f1, f2, 0.0F);
/*      */           }
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1307 */     paramMouseEvent.setAttachment(eventInfo);
/*      */     
/* 1309 */     for (byte b = 0; !paramMouseEvent.isConsumed() && b < this.mouseListeners.size(); b++) {
/* 1310 */       MouseGestureListener mouseGestureListener = this.mouseListeners.get(b);
/* 1311 */       switch (s) {
/*      */         case 200:
/* 1313 */           mouseGestureListener.mouseClicked(paramMouseEvent);
/*      */           break;
/*      */         case 201:
/* 1316 */           mouseGestureListener.mouseEntered(paramMouseEvent);
/*      */           break;
/*      */         case 202:
/* 1319 */           mouseGestureListener.mouseExited(paramMouseEvent);
/*      */           break;
/*      */         case 203:
/* 1322 */           mouseGestureListener.mousePressed(paramMouseEvent);
/*      */           break;
/*      */         case 204:
/* 1325 */           mouseGestureListener.mouseReleased(paramMouseEvent);
/*      */           break;
/*      */         case 205:
/* 1328 */           mouseGestureListener.mouseMoved(paramMouseEvent);
/*      */           break;
/*      */         case 206:
/* 1331 */           mouseGestureListener.mouseDragged(paramMouseEvent);
/*      */           break;
/*      */         case 207:
/* 1334 */           mouseGestureListener.mouseWheelMoved(paramMouseEvent);
/*      */           break;
/*      */         default:
/* 1337 */           throw new NativeWindowException("Unexpected mouse event type " + paramMouseEvent.getEventType());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void dispatchGestureEvent(GestureHandler.GestureEvent paramGestureEvent, int paramInt1, int paramInt2, PMVMatrix paramPMVMatrix, Recti paramRecti, Vec3f paramVec3f) {
/* 1351 */     if (this.interactive && this.resizable && paramGestureEvent instanceof PinchToZoomGesture.ZoomEvent) {
/* 1352 */       PinchToZoomGesture.ZoomEvent zoomEvent = (PinchToZoomGesture.ZoomEvent)paramGestureEvent;
/* 1353 */       float f1 = zoomEvent.getDelta() * zoomEvent.getScale();
/* 1354 */       int i = paramInt1 + Math.round(f1);
/* 1355 */       Vec3f vec3f = winToShapeCoord(paramPMVMatrix, paramRecti, i, paramInt2, new Vec3f());
/* 1356 */       if (null == vec3f) {
/*      */         return;
/*      */       }
/* 1359 */       float f2 = vec3f.x();
/* 1360 */       float f3 = vec3f.y();
/* 1361 */       float f4 = this.scale.x() + f2 / this.box.getWidth();
/* 1362 */       float f5 = this.scale.y() + f3 / this.box.getHeight();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1367 */       if (0.005F <= f4 && 0.005F <= f5)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1373 */         setScale(f4, f5, this.scale.z());
/*      */       }
/*      */       return;
/*      */     } 
/* 1377 */     EventInfo eventInfo = new EventInfo(paramInt1, paramInt2, this, paramVec3f);
/* 1378 */     paramGestureEvent.setAttachment(eventInfo);
/*      */     
/* 1380 */     for (byte b = 0; !paramGestureEvent.isConsumed() && b < this.mouseListeners.size(); b++) {
/* 1381 */       ((MouseGestureListener)this.mouseListeners.get(b)).gestureDetected(paramGestureEvent);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1412 */   public static Comparator<Shape> ZAscendingComparator = new Comparator<Shape>()
/*      */     {
/*      */       public int compare(Shape param1Shape1, Shape param1Shape2) {
/* 1415 */         float f1 = param1Shape1.getBounds().getMinZ() + param1Shape1.getPosition().z();
/* 1416 */         float f2 = param1Shape2.getBounds().getMinZ() + param1Shape2.getPosition().z();
/* 1417 */         if (FloatUtil.isEqual(f1, f2, 1.1920929E-7F))
/* 1418 */           return 0; 
/* 1419 */         if (f1 < f2) {
/* 1420 */           return -1;
/*      */         }
/* 1422 */         return 1;
/*      */       }
/*      */     };
/*      */   
/*      */   protected abstract void validateImpl(GLProfile paramGLProfile, GL2ES2 paramGL2ES2);
/*      */   
/*      */   protected abstract void drawImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint, Vec4f paramVec4f);
/*      */   
/*      */   protected abstract void clearImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer);
/*      */   
/*      */   protected abstract void destroyImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer);
/*      */   
/*      */   public abstract boolean hasColorChannel();
/*      */   
/*      */   public static interface ListenerBool {
/*      */     boolean run(Shape param1Shape);
/*      */   }
/*      */   
/*      */   public static interface Listener {
/*      */     void run(Shape param1Shape);
/*      */   }
/*      */   
/*      */   public static interface MouseGestureListener extends MouseListener, GestureHandler.GestureListener {}
/*      */   
/*      */   public static interface Visitor2 {
/*      */     boolean visit(Shape param1Shape, PMVMatrix param1PMVMatrix);
/*      */   }
/*      */   
/*      */   public static interface Visitor1 {
/*      */     boolean visit(Shape param1Shape);
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/Shape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */