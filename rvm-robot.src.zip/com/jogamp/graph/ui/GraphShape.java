/*     */ package com.jogamp.graph.ui;
/*     */ 
/*     */ import com.jogamp.graph.curve.OutlineShape;
/*     */ import com.jogamp.graph.curve.Region;
/*     */ import com.jogamp.graph.curve.opengl.GLRegion;
/*     */ import com.jogamp.graph.curve.opengl.RegionRenderer;
/*     */ import com.jogamp.graph.ui.layout.Padding;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.util.texture.TextureSequence;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GraphShape
/*     */   extends Shape
/*     */ {
/*     */   protected final int renderModes;
/*  56 */   protected int pass2TexUnit = 0;
/*  57 */   protected GLRegion region = null;
/*  58 */   protected float oshapeSharpness = 0.5F;
/*  59 */   private int regionQuality = 1;
/*  60 */   private final List<GLRegion> dirtyRegions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GraphShape(int paramInt) {
/*  69 */     this.renderModes = paramInt;
/*     */   }
/*     */   
/*     */   public final int getRenderModes() {
/*  73 */     return this.renderModes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GraphShape setQuality(int paramInt) {
/*  81 */     this.regionQuality = paramInt;
/*  82 */     if (null != this.region) {
/*  83 */       this.region.setQuality(paramInt);
/*     */     }
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTextureUnit(int paramInt) {
/*  90 */     this.pass2TexUnit = paramInt;
/*  91 */     if (null != this.region) {
/*  92 */       this.region.setTextureUnit(paramInt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getQuality() {
/* 100 */     return this.regionQuality;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GraphShape setSharpness(float paramFloat) {
/* 111 */     this.oshapeSharpness = paramFloat;
/* 112 */     markShapeDirty();
/* 113 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float getSharpness() {
/* 120 */     return this.oshapeSharpness;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasColorChannel() {
/* 125 */     return (Region.hasColorChannel(this.renderModes) || Region.hasColorTexture(this.renderModes));
/*     */   }
/*     */   
/*     */   private final void clearDirtyRegions(GL2ES2 paramGL2ES2) {
/* 129 */     for (GLRegion gLRegion : this.dirtyRegions) {
/* 130 */       gLRegion.destroy(paramGL2ES2);
/*     */     }
/* 132 */     this.dirtyRegions.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void clearImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/* 137 */     clearImpl(paramGL2ES2, paramRegionRenderer);
/* 138 */     clearDirtyRegions(paramGL2ES2);
/* 139 */     if (null != this.region) {
/* 140 */       this.region.clear(paramGL2ES2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void destroyImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/* 146 */     destroyImpl(paramGL2ES2, paramRegionRenderer);
/* 147 */     clearDirtyRegions(paramGL2ES2);
/* 148 */     if (null != this.region) {
/* 149 */       this.region.destroy(paramGL2ES2);
/* 150 */       this.region = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void drawImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint, Vec4f paramVec4f) {
/* 156 */     if (null != paramVec4f) {
/* 157 */       paramRegionRenderer.setColorStatic(paramVec4f);
/*     */     }
/* 159 */     this.region.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetGLRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2, TextureSequence paramTextureSequence, int paramInt1, int paramInt2) {
/* 186 */     if (hasBorder()) {
/* 187 */       paramInt1 += 8;
/* 188 */       paramInt2 += 24;
/*     */     } 
/* 190 */     if (null == this.region) {
/* 191 */       this.region = GLRegion.create(paramGLProfile, this.renderModes, paramTextureSequence, this.pass2TexUnit, paramInt1, paramInt2);
/* 192 */     } else if (null == paramGL2ES2) {
/* 193 */       this.dirtyRegions.add(this.region);
/* 194 */       this.region = GLRegion.create(paramGLProfile, this.renderModes, paramTextureSequence, this.pass2TexUnit, paramInt1, paramInt2);
/*     */     } else {
/* 196 */       this.region.clear(paramGL2ES2);
/* 197 */       this.region.setBufferCapacity(paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetGLRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2, TextureSequence paramTextureSequence, OutlineShape paramOutlineShape) {
/* 211 */     int[] arrayOfInt = Region.countOutlineShape(paramOutlineShape, new int[2]);
/* 212 */     resetGLRegion(paramGLProfile, paramGL2ES2, paramTextureSequence, arrayOfInt[0], arrayOfInt[1]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void validateImpl(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) {
/* 217 */     if (null != paramGL2ES2) {
/* 218 */       clearDirtyRegions(paramGL2ES2);
/*     */     }
/* 220 */     if (isShapeDirty()) {
/*     */       
/* 222 */       addShapeToRegion(paramGLProfile, paramGL2ES2);
/* 223 */       if (hasBorder()) {
/*     */         
/* 225 */         addBorderOutline();
/* 226 */       } else if (hasPadding()) {
/* 227 */         Padding padding = getPadding();
/* 228 */         Vec3f vec3f1 = this.box.getLow();
/* 229 */         Vec3f vec3f2 = this.box.getHigh();
/* 230 */         this.box.resize(vec3f1.x() - padding.left, vec3f1.y() - padding.bottom, vec3f1.z());
/* 231 */         this.box.resize(vec3f2.x() + padding.right, vec3f2.y() + padding.top, vec3f1.z());
/* 232 */         setRotationPivot(this.box.getCenter());
/*     */       } 
/* 234 */       this.region.setQuality(this.regionQuality);
/* 235 */     } else if (isStateDirty()) {
/* 236 */       this.region.markStateDirty();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void addBorderOutline() {
/* 241 */     OutlineShape outlineShape = new OutlineShape();
/* 242 */     Padding padding = (null != getPadding()) ? getPadding() : new Padding();
/* 243 */     float f1 = this.box.getMinX() - padding.left;
/* 244 */     float f2 = this.box.getMaxX() + padding.right;
/* 245 */     float f3 = this.box.getMinY() - padding.bottom;
/* 246 */     float f4 = this.box.getMaxY() + padding.top;
/* 247 */     float f5 = this.box.getCenter().z();
/*     */ 
/*     */     
/* 250 */     outlineShape.moveTo(f1, f3, f5);
/* 251 */     outlineShape.lineTo(f2, f3, f5);
/* 252 */     outlineShape.lineTo(f2, f4, f5);
/* 253 */     outlineShape.lineTo(f1, f4, f5);
/* 254 */     outlineShape.lineTo(f1, f3, f5);
/* 255 */     outlineShape.closeLastOutline(true);
/* 256 */     outlineShape.addEmptyOutline();
/*     */ 
/*     */ 
/*     */     
/* 260 */     float f6 = getBorderThickness();
/* 261 */     outlineShape.moveTo(f1 + f6, f3 + f6, f5);
/* 262 */     outlineShape.lineTo(f1 + f6, f4 - f6, f5);
/* 263 */     outlineShape.lineTo(f2 - f6, f4 - f6, f5);
/* 264 */     outlineShape.lineTo(f2 - f6, f3 + f6, f5);
/* 265 */     outlineShape.lineTo(f1 + f6, f3 + f6, f5);
/* 266 */     outlineShape.closeLastOutline(true);
/*     */     
/* 268 */     outlineShape.setIsQuadraticNurbs();
/* 269 */     outlineShape.setSharpness(this.oshapeSharpness);
/* 270 */     this.region.addOutlineShape(outlineShape, null, getBorderColor());
/* 271 */     this.box.resize(outlineShape.getBounds());
/* 272 */     setRotationPivot(this.box.getCenter());
/*     */   }
/*     */   
/*     */   protected void clearImpl(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {}
/*     */   
/*     */   protected void destroyImpl(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {}
/*     */   
/*     */   protected abstract void addShapeToRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2);
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/GraphShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */