/*      */ package com.jogamp.graph.ui;
/*      */ 
/*      */ import com.jogamp.common.nio.Buffers;
/*      */ import com.jogamp.graph.curve.Region;
/*      */ import com.jogamp.graph.curve.opengl.RegionRenderer;
/*      */ import com.jogamp.newt.event.GestureHandler;
/*      */ import com.jogamp.newt.event.InputEvent;
/*      */ import com.jogamp.newt.event.MouseEvent;
/*      */ import com.jogamp.newt.event.MouseListener;
/*      */ import com.jogamp.newt.event.PinchToZoomGesture;
/*      */ import com.jogamp.newt.opengl.GLWindow;
/*      */ import com.jogamp.opengl.FPSCounter;
/*      */ import com.jogamp.opengl.GL;
/*      */ import com.jogamp.opengl.GL2ES2;
/*      */ import com.jogamp.opengl.GLAnimatorControl;
/*      */ import com.jogamp.opengl.GLAutoDrawable;
/*      */ import com.jogamp.opengl.GLCapabilitiesImmutable;
/*      */ import com.jogamp.opengl.GLEventListener;
/*      */ import com.jogamp.opengl.GLException;
/*      */ import com.jogamp.opengl.GLRunnable;
/*      */ import com.jogamp.opengl.math.FloatUtil;
/*      */ import com.jogamp.opengl.math.Ray;
/*      */ import com.jogamp.opengl.math.Recti;
/*      */ import com.jogamp.opengl.math.Vec2f;
/*      */ import com.jogamp.opengl.math.Vec3f;
/*      */ import com.jogamp.opengl.math.geom.AABBox;
/*      */ import com.jogamp.opengl.util.GLPixelStorageModes;
/*      */ import com.jogamp.opengl.util.GLReadBufferUtil;
/*      */ import com.jogamp.opengl.util.PMVMatrix;
/*      */ import java.io.File;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import jogamp.graph.ui.TreeTool;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Scene
/*      */   implements Container, GLEventListener
/*      */ {
/*      */   public static final float DEFAULT_SCENE_DIST = -0.2F;
/*      */   public static final float DEFAULT_ANGLE = 45.0F;
/*      */   public static final float DEFAULT_ZNEAR = 0.1F;
/*      */   public static final float DEFAULT_ZFAR = 7000.0F;
/*      */   private static final boolean DEBUG = false;
/*  112 */   private final List<Shape> shapes = new ArrayList<>();
/*  113 */   private float dbgBorderThickness = 0.0F;
/*      */   
/*      */   private boolean doFrustumCulling = false;
/*  116 */   private float[] clearColor = null;
/*      */   
/*      */   private int clearMask;
/*      */   
/*      */   private final RegionRenderer renderer;
/*  121 */   private final int[] sampleCount = new int[1];
/*      */ 
/*      */   
/*  124 */   private final AABBox planeBox = new AABBox(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
/*      */   
/*  126 */   private volatile Shape activeShape = null;
/*      */   
/*  128 */   private SBCMouseListener sbcMouseListener = null;
/*  129 */   private SBCGestureListener sbcGestureListener = null;
/*  130 */   private PinchToZoomGesture pinchToZoomGesture = null;
/*      */   
/*      */   final GLReadBufferUtil screenshot;
/*      */   
/*  134 */   private GLAutoDrawable cDrawable = null;
/*      */   
/*      */   private static RegionRenderer createRenderer() {
/*  137 */     return RegionRenderer.create(RegionRenderer.defaultBlendEnable, RegionRenderer.defaultBlendDisable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Scene() {
/*  145 */     this(createRenderer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RegionRenderer getRenderer() {
/*  162 */     return this.renderer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setClearParams(float[] paramArrayOffloat, int paramInt) {
/*  175 */     this.clearColor = paramArrayOffloat; this.clearMask = paramInt;
/*      */   }
/*      */   public final float[] getClearColor() {
/*  178 */     return this.clearColor;
/*      */   }
/*      */   public final int getClearMask() {
/*  181 */     return this.clearMask;
/*      */   }
/*      */   public final void setFrustumCullingEnabled(boolean paramBoolean) {
/*  184 */     this.doFrustumCulling = paramBoolean;
/*      */   }
/*      */   public final boolean isFrustumCullingEnabled() {
/*  187 */     return this.doFrustumCulling;
/*      */   }
/*      */   public void attachInputListenerTo(GLWindow paramGLWindow) {
/*  190 */     if (null == this.sbcMouseListener) {
/*  191 */       this.sbcMouseListener = new SBCMouseListener();
/*  192 */       paramGLWindow.addMouseListener(this.sbcMouseListener);
/*  193 */       this.sbcGestureListener = new SBCGestureListener();
/*  194 */       paramGLWindow.addGestureListener(this.sbcGestureListener);
/*  195 */       this.pinchToZoomGesture = new PinchToZoomGesture(paramGLWindow.getNativeSurface(), false);
/*  196 */       paramGLWindow.addGestureHandler((GestureHandler)this.pinchToZoomGesture);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void detachInputListenerFrom(GLWindow paramGLWindow) {
/*  201 */     if (null != this.sbcMouseListener) {
/*  202 */       paramGLWindow.removeMouseListener(this.sbcMouseListener);
/*  203 */       this.sbcMouseListener = null;
/*  204 */       paramGLWindow.removeGestureListener(this.sbcGestureListener);
/*  205 */       this.sbcGestureListener = null;
/*  206 */       paramGLWindow.removeGestureHandler((GestureHandler)this.pinchToZoomGesture);
/*  207 */       this.pinchToZoomGesture = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Shape> getShapes() {
/*  213 */     return this.shapes;
/*      */   }
/*      */   
/*      */   public void addShape(Shape paramShape) {
/*  217 */     paramShape.setBorder(this.dbgBorderThickness);
/*  218 */     this.shapes.add(paramShape);
/*      */   }
/*      */   
/*      */   public Shape removeShape(Shape paramShape) {
/*  222 */     paramShape.setBorder(0.0F);
/*  223 */     return this.shapes.remove(paramShape) ? paramShape : null;
/*      */   }
/*      */   
/*      */   public Shape removeShape(int paramInt) {
/*  227 */     return this.shapes.remove(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeShape(GL2ES2 paramGL2ES2, Shape paramShape) {
/*  232 */     paramShape.setBorder(0.0F);
/*  233 */     this.shapes.remove(paramShape);
/*  234 */     paramShape.destroy(paramGL2ES2, this.renderer);
/*      */   }
/*      */   
/*      */   public void addShapes(Collection<? extends Shape> paramCollection) {
/*  238 */     for (Shape shape : paramCollection) {
/*  239 */       addShape(shape);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeShapes(Collection<? extends Shape> paramCollection) {
/*  244 */     for (Shape shape : paramCollection) {
/*  245 */       removeShape(shape);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeShapes(GL2ES2 paramGL2ES2, Collection<? extends Shape> paramCollection) {
/*  250 */     for (Shape shape : paramCollection) {
/*  251 */       removeShape(paramGL2ES2, shape);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeAllShapes() {
/*  256 */     this.shapes.clear();
/*      */   }
/*      */   
/*      */   public void removeAllShapes(GL2ES2 paramGL2ES2) {
/*  260 */     int i = this.shapes.size();
/*  261 */     for (int j = i - 1; j >= 0; j--) {
/*  262 */       removeShape(paramGL2ES2, this.shapes.get(j));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean contains(Shape paramShape) {
/*  268 */     return false;
/*      */   }
/*      */   public Shape getShapeByIdx(int paramInt) {
/*  271 */     if (0 > paramInt) {
/*  272 */       return null;
/*      */     }
/*  274 */     return this.shapes.get(paramInt);
/*      */   }
/*      */   public Shape getShapeByName(int paramInt) {
/*  277 */     for (Shape shape : this.shapes) {
/*  278 */       if (shape.getName() == paramInt) {
/*  279 */         return shape;
/*      */       }
/*      */     } 
/*  282 */     return null;
/*      */   }
/*      */   public int getSampleCount() {
/*  285 */     return this.sampleCount[0];
/*      */   } public int setSampleCount(int paramInt) {
/*  287 */     this.sampleCount[0] = Math.min(8, Math.max(paramInt, 0));
/*  288 */     markAllShapesDirty();
/*  289 */     return this.sampleCount[0];
/*      */   }
/*      */   
/*      */   public void setAllShapesQuality(int paramInt) {
/*  293 */     for (byte b = 0; b < this.shapes.size(); b++) {
/*  294 */       Shape shape = this.shapes.get(b);
/*  295 */       if (shape instanceof GraphShape)
/*  296 */         ((GraphShape)shape).setQuality(paramInt); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setAllShapesSharpness(float paramFloat) {
/*  301 */     for (byte b = 0; b < this.shapes.size(); b++) {
/*  302 */       Shape shape = this.shapes.get(b);
/*  303 */       if (shape instanceof GraphShape)
/*  304 */         ((GraphShape)shape).setSharpness(paramFloat); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void markAllShapesDirty() {
/*  309 */     for (byte b = 0; b < this.shapes.size(); b++) {
/*  310 */       ((Shape)this.shapes.get(b)).markShapeDirty();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setDebugBorderBox(float paramFloat) {
/*  319 */     this.dbgBorderThickness = paramFloat;
/*  320 */     for (byte b = 0; b < this.shapes.size(); b++) {
/*  321 */       ((Shape)this.shapes.get(b)).setBorder(paramFloat);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void init(GLAutoDrawable paramGLAutoDrawable) {
/*  327 */     this.cDrawable = paramGLAutoDrawable;
/*  328 */     this.renderer.init(paramGLAutoDrawable.getGL().getGL2ES2());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reshape(GLAutoDrawable paramGLAutoDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  344 */     this.renderer.reshapeNotify(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */     
/*  346 */     setupMatrix(this.renderer.getMatrix(), this.renderer.getViewport());
/*  347 */     this.pmvMatrixSetup.setPlaneBox(this.planeBox, this.renderer.getMatrix(), this.renderer.getViewport());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void display(GLAutoDrawable paramGLAutoDrawable) {
/*  353 */     Object[] arrayOfObject = this.shapes.toArray();
/*  354 */     Arrays.sort(arrayOfObject, (Comparator)Shape.ZAscendingComparator);
/*      */     
/*  356 */     display(paramGLAutoDrawable, arrayOfObject, false);
/*      */   }
/*      */   private volatile boolean displayedOnce; private final Object syncDisplayedOnce;
/*  359 */   private static final int[] sampleCountGLSelect = new int[] { -1 }; private int screenShotCount;
/*      */   private void display(GLAutoDrawable paramGLAutoDrawable, Object[] paramArrayOfObject, boolean paramBoolean) {
/*      */     int[] arrayOfInt;
/*  362 */     GL2ES2 gL2ES2 = paramGLAutoDrawable.getGL().getGL2ES2();
/*      */ 
/*      */     
/*  365 */     if (paramBoolean) {
/*  366 */       gL2ES2.glClearColor(0.0F, 0.0F, 0.0F, 1.0F);
/*  367 */       arrayOfInt = sampleCountGLSelect;
/*  368 */       gL2ES2.glClear(16640);
/*      */     } else {
/*  370 */       if (null != this.clearColor) {
/*  371 */         gL2ES2.glClearColor(this.clearColor[0], this.clearColor[1], this.clearColor[2], this.clearColor[3]);
/*  372 */         gL2ES2.glClear(this.clearMask);
/*      */       } 
/*  374 */       arrayOfInt = this.sampleCount;
/*      */     } 
/*      */     
/*  377 */     PMVMatrix pMVMatrix = this.renderer.getMatrix();
/*  378 */     pMVMatrix.glMatrixMode(5888);
/*      */     
/*  380 */     if (paramBoolean) {
/*  381 */       this.renderer.enable(gL2ES2, true, RegionRenderer.defaultBlendDisable, RegionRenderer.defaultBlendDisable);
/*      */     } else {
/*  383 */       this.renderer.enable(gL2ES2, true);
/*      */     } 
/*      */ 
/*      */     
/*  387 */     int i = paramArrayOfObject.length;
/*  388 */     for (byte b = 0; b < i; b++) {
/*      */       
/*  390 */       Shape shape = (Shape)paramArrayOfObject[b];
/*      */       
/*  392 */       if (shape.isEnabled()) {
/*  393 */         pMVMatrix.glPushMatrix();
/*  394 */         shape.setTransform(pMVMatrix);
/*      */         
/*  396 */         if (!this.doFrustumCulling || !pMVMatrix.getFrustum().isAABBoxOutside(shape.getBounds())) {
/*  397 */           if (paramBoolean) {
/*  398 */             float f = (b + 1.0F) / (i + 2.0F);
/*      */ 
/*      */             
/*  401 */             this.renderer.setColorStatic(f, f, f, 1.0F);
/*  402 */             shape.drawToSelect(gL2ES2, this.renderer, arrayOfInt);
/*      */           } else {
/*  404 */             shape.draw(gL2ES2, this.renderer, arrayOfInt);
/*      */           } 
/*      */         }
/*  407 */         pMVMatrix.glPopMatrix();
/*      */       } 
/*      */     } 
/*  410 */     if (paramBoolean) {
/*  411 */       this.renderer.enable(gL2ES2, false, RegionRenderer.defaultBlendDisable, RegionRenderer.defaultBlendDisable);
/*      */     } else {
/*  413 */       this.renderer.enable(gL2ES2, false);
/*      */     } 
/*  415 */     synchronized (this.syncDisplayedOnce) {
/*  416 */       this.displayedOnce = true;
/*  417 */       this.syncDisplayedOnce.notifyAll();
/*      */     } 
/*      */   }
/*      */   public Scene(RegionRenderer paramRegionRenderer) {
/*  421 */     this.displayedOnce = false;
/*  422 */     this.syncDisplayedOnce = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1089 */     this.screenShotCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1166 */     this.pmvMatrixSetup = defaultPMVMatrixSetup;
/*      */     if (null == paramRegionRenderer)
/*      */       throw new IllegalArgumentException("Null RegionRenderer"); 
/*      */     this.renderer = paramRegionRenderer;
/*      */     this.sampleCount[0] = 4;
/*      */     this.screenshot = new GLReadBufferUtil(false, false);
/*      */   }
/*      */   
/*      */   public void waitUntilDisplayed() {
/*      */     synchronized (this.syncDisplayedOnce) {
/*      */       while (!this.displayedOnce) {
/*      */         try {
/*      */           this.syncDisplayedOnce.wait();
/*      */         } catch (InterruptedException interruptedException) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void dispose(GLAutoDrawable paramGLAutoDrawable) {
/*      */     synchronized (this.syncDisplayedOnce) {
/*      */       this.displayedOnce = false;
/*      */       this.syncDisplayedOnce.notifyAll();
/*      */     } 
/*      */     if (paramGLAutoDrawable instanceof GLWindow) {
/*      */       GLWindow gLWindow = (GLWindow)paramGLAutoDrawable;
/*      */       detachInputListenerFrom(gLWindow);
/*      */     } 
/*      */     GL2ES2 gL2ES2 = paramGLAutoDrawable.getGL().getGL2ES2();
/*      */     for (byte b = 0; b < this.shapes.size(); b++)
/*      */       ((Shape)this.shapes.get(b)).destroy(gL2ES2, this.renderer); 
/*      */     this.shapes.clear();
/*      */     this.cDrawable = null;
/*      */     this.renderer.destroy(gL2ES2);
/*      */     this.screenshot.dispose((GL)gL2ES2);
/*      */   }
/*      */   
/*      */   public Shape pickShape(PMVMatrix paramPMVMatrix, int paramInt1, int paramInt2, Vec3f paramVec3f, Shape[] paramArrayOfShape, Runnable paramRunnable) {
/*      */     setupMatrix(paramPMVMatrix);
/*      */     Recti recti = getViewport();
/*      */     Ray ray = new Ray();
/*      */     paramArrayOfShape[0] = null;
/*      */     forSortedAll(Shape.ZAscendingComparator, paramPMVMatrix, (paramShape, paramPMVMatrix2) -> {
/*      */           boolean bool = (paramShape.isInteractive() && paramPMVMatrix1.gluUnProjectRay(paramInt1, paramInt2, 0.0F, 0.3F, paramRecti, paramRay)) ? true : false;
/*      */           if (bool) {
/*      */             AABBox aABBox = paramShape.getBounds();
/*      */             if (aABBox.intersectsRay(paramRay)) {
/*      */               if (null == aABBox.getRayIntersection(paramVec3f, paramRay, 1.1920929E-7F, true))
/*      */                 throw new InternalError("Ray " + paramRay + ", box " + aABBox); 
/*      */               paramArrayOfShape[0] = paramShape;
/*      */               paramRunnable.run();
/*      */               return true;
/*      */             } 
/*      */           } 
/*      */           return false;
/*      */         });
/*      */     return paramArrayOfShape[0];
/*      */   }
/*      */   
/*      */   public void pickShapeGL(final int glWinX, final int glWinY, final Vec3f objPos, final Shape[] shape, final Runnable runnable) {
/*      */     if (null == this.cDrawable)
/*      */       return; 
/*      */     this.cDrawable.invoke(false, new GLRunnable() {
/*      */           public boolean run(GLAutoDrawable param1GLAutoDrawable) {
/*      */             Shape shape = Scene.this.pickShapeGLImpl(param1GLAutoDrawable, glWinX, glWinY);
/*      */             shape[0] = shape;
/*      */             if (null != shape) {
/*      */               PMVMatrix pMVMatrix = Scene.this.renderer.getMatrix();
/*      */               pMVMatrix.glPushMatrix();
/*      */               shape.setTransform(pMVMatrix);
/*      */               boolean bool = (null != shape[0].winToShapeCoord(Scene.this.getMatrix(), Scene.this.getViewport(), glWinX, glWinY, objPos)) ? true : false;
/*      */               pMVMatrix.glPopMatrix();
/*      */               if (bool)
/*      */                 runnable.run(); 
/*      */             } 
/*      */             return false;
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private Shape pickShapeGLImpl(GLAutoDrawable paramGLAutoDrawable, int paramInt1, int paramInt2) {
/*      */     Object[] arrayOfObject = this.shapes.toArray();
/*      */     Arrays.sort(arrayOfObject, (Comparator)Shape.ZAscendingComparator);
/*      */     GLPixelStorageModes gLPixelStorageModes = new GLPixelStorageModes();
/*      */     ByteBuffer byteBuffer = Buffers.newDirectByteBuffer(4);
/*      */     GL2ES2 gL2ES2 = paramGLAutoDrawable.getGL().getGL2ES2();
/*      */     display(paramGLAutoDrawable, arrayOfObject, true);
/*      */     gLPixelStorageModes.setPackAlignment((GL)gL2ES2, 4);
/*      */     try {
/*      */       gL2ES2.glReadPixels(paramInt1, paramInt2, 1, 1, 6408, 5121, byteBuffer);
/*      */     } catch (GLException gLException) {
/*      */       gLException.printStackTrace();
/*      */       return null;
/*      */     } 
/*      */     gLPixelStorageModes.restore((GL)gL2ES2);
/*      */     int i = this.shapes.size();
/*      */     int j = byteBuffer.get(0) & 0xFF;
/*      */     float f = j / 255.0F;
/*      */     int k = Math.round(f * (i + 2.0F) - 1.0F);
/*      */     System.err.printf("pickGL: glWin %d / %d, byte %d, color %f, index %d of [0..%d[%n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(j), Float.valueOf(f), Integer.valueOf(k), Integer.valueOf(i) });
/*      */     if (0 <= k && k < i)
/*      */       return (Shape)arrayOfObject[k]; 
/*      */     return null;
/*      */   }
/*      */   
/*      */   public void winToShapeCoord(Shape paramShape, int paramInt1, int paramInt2, PMVMatrix paramPMVMatrix, Vec3f paramVec3f, Runnable paramRunnable) {
/*      */     if (null == paramShape)
/*      */       return; 
/*      */     Recti recti = getViewport();
/*      */     setupMatrix(paramPMVMatrix);
/*      */     forOne(paramPMVMatrix, paramShape, () -> {
/*      */           if (null != paramShape.winToShapeCoord(paramPMVMatrix, paramRecti, paramInt1, paramInt2, paramVec3f))
/*      */             paramRunnable.run(); 
/*      */         });
/*      */   }
/*      */   
/*      */   public AABBox getBounds(PMVMatrix paramPMVMatrix, Shape paramShape) {
/*      */     AABBox aABBox = new AABBox();
/*      */     if (null == paramShape)
/*      */       return aABBox; 
/*      */     setupMatrix(paramPMVMatrix);
/*      */     forOne(paramPMVMatrix, paramShape, () -> paramShape.getBounds().transformMv(paramPMVMatrix, paramAABBox));
/*      */     return aABBox;
/*      */   }
/*      */   
/*      */   public boolean forOne(PMVMatrix paramPMVMatrix, Shape paramShape, Runnable paramRunnable) {
/*      */     return TreeTool.forOne(this.shapes, paramPMVMatrix, paramShape, paramRunnable);
/*      */   }
/*      */   
/*      */   public boolean forAll(PMVMatrix paramPMVMatrix, Shape.Visitor2 paramVisitor2) {
/*      */     return TreeTool.forAll(this.shapes, paramPMVMatrix, paramVisitor2);
/*      */   }
/*      */   
/*      */   public boolean forAll(Shape.Visitor1 paramVisitor1) {
/*      */     return TreeTool.forAll(this.shapes, paramVisitor1);
/*      */   }
/*      */   
/*      */   public boolean forSortedAll(Comparator<Shape> paramComparator, PMVMatrix paramPMVMatrix, Shape.Visitor2 paramVisitor2) {
/*      */     return TreeTool.forSortedAll(paramComparator, this.shapes, paramPMVMatrix, paramVisitor2);
/*      */   }
/*      */   
/*      */   public final PMVMatrixSetup getPMVMatrixSetup() {
/*      */     return this.pmvMatrixSetup;
/*      */   }
/*      */   
/*      */   public final void setPMVMatrixSetup(PMVMatrixSetup paramPMVMatrixSetup) {
/*      */     this.pmvMatrixSetup = paramPMVMatrixSetup;
/*      */   }
/*      */   
/*      */   public static PMVMatrixSetup getDefaultPMVMatrixSetup() {
/*      */     return defaultPMVMatrixSetup;
/*      */   }
/*      */   
/*      */   public void setupMatrix(PMVMatrix paramPMVMatrix, Recti paramRecti) {
/*      */     this.pmvMatrixSetup.set(paramPMVMatrix, paramRecti);
/*      */   }
/*      */   
/*      */   public void setupMatrix(PMVMatrix paramPMVMatrix) {
/*      */     Recti recti = this.renderer.getViewport();
/*      */     setupMatrix(paramPMVMatrix, recti);
/*      */   }
/*      */   
/*      */   public final Recti getViewport(Recti paramRecti) {
/*      */     return this.renderer.getViewport(paramRecti);
/*      */   }
/*      */   
/*      */   public Recti getViewport() {
/*      */     return this.renderer.getViewport();
/*      */   }
/*      */   
/*      */   public int getWidth() {
/*      */     return this.renderer.getWidth();
/*      */   }
/*      */   
/*      */   public int getHeight() {
/*      */     return this.renderer.getHeight();
/*      */   }
/*      */   
/*      */   public PMVMatrix getMatrix() {
/*      */     return this.renderer.getMatrix();
/*      */   }
/*      */   
/*      */   public AABBox getBounds() {
/*      */     return this.planeBox;
/*      */   }
/*      */   
/*      */   public static void winToPlaneCoord(PMVMatrix paramPMVMatrix, Recti paramRecti, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, Vec3f paramVec3f) {
/*      */     float f = FloatUtil.getOrthoWinZ(paramFloat5, paramFloat1, paramFloat2);
/*      */     paramPMVMatrix.gluUnProject(paramFloat3, paramFloat4, f, paramRecti, paramVec3f);
/*      */   }
/*      */   
/*      */   public void surfaceToPlaneSize(Recti paramRecti, float paramFloat1, float paramFloat2, float paramFloat3, Vec2f paramVec2f) {
/*      */     PMVMatrix pMVMatrix = new PMVMatrix();
/*      */     setupMatrix(pMVMatrix, paramRecti);
/*      */     Vec3f vec3f1 = new Vec3f();
/*      */     Vec3f vec3f2 = new Vec3f();
/*      */     winToPlaneCoord(pMVMatrix, paramRecti, 0.1F, 7000.0F, paramRecti.x(), paramRecti.y(), paramFloat3, vec3f1);
/*      */     winToPlaneCoord(pMVMatrix, paramRecti, 0.1F, 7000.0F, paramRecti.width(), paramRecti.height(), paramFloat3, vec3f2);
/*      */     paramVec2f.set(vec3f2.x() - vec3f1.x(), vec3f2.y() - vec3f1.y());
/*      */   }
/*      */   
/*      */   public void surfaceToPlaneSize(Recti paramRecti, Vec2f paramVec2f) {
/*      */     surfaceToPlaneSize(paramRecti, 0.1F, 7000.0F, 0.2F, paramVec2f);
/*      */   }
/*      */   
/*      */   public final Shape getActiveShape() {
/*      */     return this.activeShape;
/*      */   }
/*      */   
/*      */   public void releaseActiveShape() {
/*      */     this.activeShape = null;
/*      */   }
/*      */   
/*      */   private void setActiveShape(Shape paramShape) {
/*      */     this.activeShape = paramShape;
/*      */   }
/*      */   
/*      */   private final class SBCGestureListener implements GestureHandler.GestureListener {
/*      */     private SBCGestureListener() {}
/*      */     
/*      */     public void gestureDetected(GestureHandler.GestureEvent param1GestureEvent) {
/*      */       if (null != Scene.this.activeShape) {
/*      */         InputEvent inputEvent = param1GestureEvent.getTrigger();
/*      */         if (inputEvent instanceof MouseEvent) {
/*      */           Shape shape = Scene.this.activeShape;
/*      */           if (shape.isInteractive()) {
/*      */             MouseEvent mouseEvent = (MouseEvent)inputEvent;
/*      */             int i = mouseEvent.getX();
/*      */             int j = Scene.this.getHeight() - mouseEvent.getY() - 1;
/*      */             PMVMatrix pMVMatrix = new PMVMatrix();
/*      */             Vec3f vec3f = new Vec3f();
/*      */             Scene.this.winToShapeCoord(shape, i, j, pMVMatrix, vec3f, () -> param1Shape.dispatchGestureEvent(param1GestureEvent, param1Int1, param1Int2, param1PMVMatrix, Scene.this.renderer.getViewport(), param1Vec3f));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   final void dispatchMouseEvent(MouseEvent paramMouseEvent, int paramInt1, int paramInt2) {
/*      */     if (null == this.activeShape) {
/*      */       dispatchMouseEventPickShape(paramMouseEvent, paramInt1, paramInt2);
/*      */     } else if (this.activeShape.isInteractive()) {
/*      */       dispatchMouseEventForShape(this.activeShape, paramMouseEvent, paramInt1, paramInt2);
/*      */     } 
/*      */   }
/*      */   
/*      */   final void dispatchMouseEventPickShape(MouseEvent paramMouseEvent, int paramInt1, int paramInt2) {
/*      */     PMVMatrix pMVMatrix = new PMVMatrix();
/*      */     Vec3f vec3f = new Vec3f();
/*      */     Shape[] arrayOfShape = { null };
/*      */     if (null == pickShape(pMVMatrix, paramInt1, paramInt2, vec3f, arrayOfShape, () -> {
/*      */           setActiveShape(paramArrayOfShape[0]);
/*      */           paramArrayOfShape[0].dispatchMouseEvent(paramMouseEvent, paramInt1, paramInt2, paramVec3f);
/*      */         }))
/*      */       releaseActiveShape(); 
/*      */   }
/*      */   
/*      */   final void dispatchMouseEventForShape(Shape paramShape, MouseEvent paramMouseEvent, int paramInt1, int paramInt2) {
/*      */     PMVMatrix pMVMatrix = new PMVMatrix();
/*      */     Vec3f vec3f = new Vec3f();
/*      */     winToShapeCoord(paramShape, paramInt1, paramInt2, pMVMatrix, vec3f, () -> paramShape.dispatchMouseEvent(paramMouseEvent, paramInt1, paramInt2, paramVec3f));
/*      */   }
/*      */   
/*      */   private class SBCMouseListener implements MouseListener {
/*      */     int lx = -1;
/*      */     int ly = -1;
/*      */     int lId = -1;
/*      */     
/*      */     void clear() {
/*      */       this.lx = -1;
/*      */       this.ly = -1;
/*      */       this.lId = -1;
/*      */     }
/*      */     
/*      */     public void mousePressed(MouseEvent param1MouseEvent) {
/*      */       if (-1 == this.lId || param1MouseEvent.getPointerId(0) == this.lId) {
/*      */         this.lx = param1MouseEvent.getX();
/*      */         this.ly = param1MouseEvent.getY();
/*      */         this.lId = param1MouseEvent.getPointerId(0);
/*      */       } 
/*      */       int i = param1MouseEvent.getX();
/*      */       int j = Scene.this.getHeight() - param1MouseEvent.getY() - 1;
/*      */       Scene.this.dispatchMouseEvent(param1MouseEvent, i, j);
/*      */     }
/*      */     
/*      */     public void mouseReleased(MouseEvent param1MouseEvent) {
/*      */       int i = param1MouseEvent.getX();
/*      */       int j = Scene.this.getHeight() - param1MouseEvent.getY() - 1;
/*      */       Scene.this.dispatchMouseEvent(param1MouseEvent, i, j);
/*      */       if (1 == param1MouseEvent.getPointerCount()) {
/*      */         Scene.this.releaseActiveShape();
/*      */         clear();
/*      */       } 
/*      */     }
/*      */     
/*      */     public void mouseClicked(MouseEvent param1MouseEvent) {
/*      */       int i = param1MouseEvent.getX();
/*      */       int j = Scene.this.getHeight() - param1MouseEvent.getY() - 1;
/*      */       Scene.this.dispatchMouseEventPickShape(param1MouseEvent, i, j);
/*      */       Scene.this.releaseActiveShape();
/*      */       clear();
/*      */     }
/*      */     
/*      */     public void mouseDragged(MouseEvent param1MouseEvent) {
/*      */       if (null != Scene.this.activeShape && !Scene.this.pinchToZoomGesture.isWithinGesture() && param1MouseEvent.getPointerId(0) == this.lId) {
/*      */         this.lx = param1MouseEvent.getX();
/*      */         this.ly = param1MouseEvent.getY();
/*      */         int i = this.lx;
/*      */         int j = Scene.this.getHeight() - this.ly - 1;
/*      */         Scene.this.dispatchMouseEventForShape(Scene.this.activeShape, param1MouseEvent, i, j);
/*      */       } 
/*      */     }
/*      */     
/*      */     public void mouseWheelMoved(MouseEvent param1MouseEvent) {
/*      */       int i = this.lx;
/*      */       int j = Scene.this.getHeight() - this.ly - 1;
/*      */       Scene.this.dispatchMouseEvent(param1MouseEvent, i, j);
/*      */     }
/*      */     
/*      */     public void mouseMoved(MouseEvent param1MouseEvent) {
/*      */       if (-1 == this.lId || param1MouseEvent.getPointerId(0) == this.lId) {
/*      */         this.lx = param1MouseEvent.getX();
/*      */         this.ly = param1MouseEvent.getY();
/*      */         this.lId = param1MouseEvent.getPointerId(0);
/*      */       } 
/*      */       int i = this.lx;
/*      */       int j = Scene.this.getHeight() - this.ly - 1;
/*      */       Scene.this.dispatchMouseEventPickShape(param1MouseEvent, i, j);
/*      */     }
/*      */     
/*      */     public void mouseEntered(MouseEvent param1MouseEvent) {}
/*      */     
/*      */     public void mouseExited(MouseEvent param1MouseEvent) {
/*      */       Scene.this.releaseActiveShape();
/*      */       clear();
/*      */     }
/*      */     
/*      */     private SBCMouseListener() {}
/*      */   }
/*      */   
/*      */   public String getStatusText(GLAutoDrawable paramGLAutoDrawable, int paramInt1, int paramInt2, float paramFloat) {
/*      */     float f1, f2, f3;
/*      */     String str2, str3;
/*      */     GLAnimatorControl gLAnimatorControl = paramGLAutoDrawable.getAnimator();
/*      */     if (null != gLAnimatorControl) {
/*      */       f1 = gLAnimatorControl.getLastFPS();
/*      */       f2 = gLAnimatorControl.getTotalFPS();
/*      */       f3 = (float)gLAnimatorControl.getLastFPSPeriod() / gLAnimatorControl.getUpdateFPSFrames();
/*      */     } else {
/*      */       f1 = 0.0F;
/*      */       f2 = 0.0F;
/*      */       f3 = 0.0F;
/*      */     } 
/*      */     GLCapabilitiesImmutable gLCapabilitiesImmutable = paramGLAutoDrawable.getChosenGLCapabilities();
/*      */     String str1 = Region.getRenderModeString(paramInt1, getSampleCount(), gLCapabilitiesImmutable.getNumSamples());
/*      */     if (0 <= paramInt2) {
/*      */       str2 = ", q " + paramInt2;
/*      */     } else {
/*      */       str2 = "";
/*      */     } 
/*      */     if (getRenderer().isHintMaskSet(1)) {
/*      */       str3 = ", blend";
/*      */     } else {
/*      */       str3 = "";
/*      */     } 
/*      */     return String.format("%03.1f/%03.1f fps, %.1f ms/f, vsync %d, dpi %.1f, %s%s%s, a %d", new Object[] { Float.valueOf(f1), Float.valueOf(f2), Float.valueOf(f3), Integer.valueOf(paramGLAutoDrawable.getGL().getSwapInterval()), Float.valueOf(paramFloat), str1, str2, str3, Integer.valueOf(gLCapabilitiesImmutable.getAlphaBits()) });
/*      */   }
/*      */   
/*      */   public static String getStatusText(FPSCounter paramFPSCounter) {
/*      */     float f1 = paramFPSCounter.getLastFPS();
/*      */     float f2 = paramFPSCounter.getTotalFPS();
/*      */     float f3 = (float)paramFPSCounter.getLastFPSPeriod() / paramFPSCounter.getUpdateFPSFrames();
/*      */     return String.format("%03.1f/%03.1f fps, %.1f ms/f", new Object[] { Float.valueOf(f1), Float.valueOf(f2), Float.valueOf(f3) });
/*      */   }
/*      */   
/*      */   public File nextScreenshotFile(String paramString1, String paramString2, int paramInt, GLCapabilitiesImmutable paramGLCapabilitiesImmutable, String paramString3) {
/*      */     String str1 = (null != paramString1 && paramString1.length() > 0) ? paramString1 : "";
/*      */     String str2 = (null != paramString2 && paramString2.length() > 0) ? (paramString2 + "-") : "";
/*      */     RegionRenderer regionRenderer = getRenderer();
/*      */     String str3 = Region.getRenderModeString(paramInt, getSampleCount(), paramGLCapabilitiesImmutable.getNumSamples());
/*      */     String str4 = (null != paramString3 && paramString3.length() > 0) ? (paramString3 + "-") : "";
/*      */     return new File(String.format((Locale)null, "%s%s%s-%ssnap%02d-%04dx%04d.png", new Object[] { str1, str2, str3, str4, Integer.valueOf(this.screenShotCount++), Integer.valueOf(regionRenderer.getWidth()), Integer.valueOf(regionRenderer.getHeight()) }));
/*      */   }
/*      */   
/*      */   public int getScreenshotCount() {
/*      */     return this.screenShotCount;
/*      */   }
/*      */   
/*      */   public void screenshot(GL paramGL, File paramFile) {
/*      */     if (this.screenshot.readPixels(paramGL, false)) {
/*      */       this.screenshot.write(paramFile);
/*      */       System.err.println("Wrote: " + paramFile);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void screenshot(boolean paramBoolean, File paramFile) {
/*      */     if (null != this.cDrawable)
/*      */       this.cDrawable.invoke(paramBoolean, paramGLAutoDrawable -> {
/*      */             screenshot(paramGLAutoDrawable.getGL(), paramFile);
/*      */             return true;
/*      */           }); 
/*      */   }
/*      */   
/*      */   private static final PMVMatrixSetup defaultPMVMatrixSetup = new PMVMatrixSetup() {
/*      */       public void set(PMVMatrix param1PMVMatrix, Recti param1Recti) {
/*      */         float f1 = param1Recti.width() / param1Recti.height();
/*      */         param1PMVMatrix.glMatrixMode(5889);
/*      */         param1PMVMatrix.glLoadIdentity();
/*      */         param1PMVMatrix.gluPerspective(45.0F, f1, 0.1F, 7000.0F);
/*      */         param1PMVMatrix.glTranslatef(0.0F, 0.0F, -0.2F);
/*      */         param1PMVMatrix.glMatrixMode(5888);
/*      */         param1PMVMatrix.glLoadIdentity();
/*      */         AABBox aABBox = new AABBox();
/*      */         setPlaneBox(aABBox, param1PMVMatrix, param1Recti);
/*      */         float f2 = aABBox.getWidth();
/*      */         float f3 = aABBox.getHeight();
/*      */         float f4 = (f2 > f3) ? f2 : f3;
/*      */         param1PMVMatrix.glMatrixMode(5889);
/*      */         param1PMVMatrix.glScalef(f4, f4, 1.0F);
/*      */         param1PMVMatrix.glMatrixMode(5888);
/*      */       }
/*      */       
/*      */       public void setPlaneBox(AABBox param1AABBox, PMVMatrix param1PMVMatrix, Recti param1Recti) {
/*      */         Vec3f vec3f1 = new Vec3f();
/*      */         Vec3f vec3f2 = new Vec3f();
/*      */         Scene.winToPlaneCoord(param1PMVMatrix, param1Recti, 0.1F, 7000.0F, param1Recti.x(), param1Recti.y(), 0.2F, vec3f1);
/*      */         Scene.winToPlaneCoord(param1PMVMatrix, param1Recti, 0.1F, 7000.0F, param1Recti.width(), param1Recti.height(), 0.2F, vec3f2);
/*      */         param1AABBox.setSize(vec3f1, vec3f2);
/*      */       }
/*      */     };
/*      */   
/*      */   private PMVMatrixSetup pmvMatrixSetup;
/*      */   
/*      */   public static interface PMVMatrixSetup {
/*      */     void set(PMVMatrix param1PMVMatrix, Recti param1Recti);
/*      */     
/*      */     void setPlaneBox(AABBox param1AABBox, PMVMatrix param1PMVMatrix, Recti param1Recti);
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/Scene.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */