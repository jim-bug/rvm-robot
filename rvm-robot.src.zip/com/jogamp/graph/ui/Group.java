/*     */ package com.jogamp.graph.ui;
/*     */ 
/*     */ import com.jogamp.graph.curve.opengl.RegionRenderer;
/*     */ import com.jogamp.graph.ui.layout.Padding;
/*     */ import com.jogamp.graph.ui.shapes.Rectangle;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import com.jogamp.opengl.util.PMVMatrix;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import jogamp.graph.ui.TreeTool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Group
/*     */   extends Shape
/*     */   implements Container
/*     */ {
/*  75 */   private final List<Shape> shapes = new ArrayList<>();
/*     */   private Layout layouter;
/*  77 */   private Rectangle border = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean doFrustumCulling;
/*     */ 
/*     */ 
/*     */   
/*     */   public Group() {
/*  86 */     this((Layout)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Layout getLayout() {
/* 102 */     return this.layouter;
/*     */   }
/*     */   public Group setLayout(Layout paramLayout) {
/* 105 */     this.layouter = paramLayout; return this;
/*     */   }
/*     */   
/*     */   public List<Shape> getShapes() {
/* 109 */     return this.shapes;
/*     */   }
/*     */   
/*     */   public void addShape(Shape paramShape) {
/* 113 */     this.shapes.add(paramShape);
/* 114 */     markShapeDirty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Shape removeShape(Shape paramShape) {
/* 120 */     Shape shape = this.shapes.remove(paramShape) ? paramShape : null;
/* 121 */     markShapeDirty();
/* 122 */     return shape;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape removeShape(int paramInt) {
/* 127 */     Shape shape = this.shapes.remove(paramInt);
/* 128 */     markShapeDirty();
/* 129 */     return shape;
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeShape(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, Shape paramShape) {
/* 134 */     this.shapes.remove(paramShape);
/* 135 */     paramShape.destroy(paramGL2ES2, paramRegionRenderer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addShapes(Collection<? extends Shape> paramCollection) {
/* 140 */     for (Shape shape : paramCollection) {
/* 141 */       addShape(shape);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeShapes(Collection<? extends Shape> paramCollection) {
/* 147 */     for (Shape shape : paramCollection) {
/* 148 */       removeShape(shape);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeShapes(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, Collection<? extends Shape> paramCollection) {
/* 153 */     for (Shape shape : paramCollection) {
/* 154 */       removeShape(paramGL2ES2, paramRegionRenderer, shape);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAllShapes() {
/* 160 */     this.shapes.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAllShapes(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/* 165 */     int i = this.shapes.size();
/* 166 */     for (int j = i - 1; j >= 0; j--) {
/* 167 */       removeShape(paramGL2ES2, paramRegionRenderer, this.shapes.get(j));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasColorChannel() {
/* 173 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void clearImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/* 178 */     for (Shape shape : this.shapes)
/*     */     {
/* 180 */       shape.clear(paramGL2ES2, paramRegionRenderer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void destroyImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/* 186 */     for (Shape shape : this.shapes)
/*     */     {
/* 188 */       shape.destroy(paramGL2ES2, paramRegionRenderer);
/*     */     }
/* 190 */     if (null != this.border) {
/* 191 */       this.border.destroy(paramGL2ES2, paramRegionRenderer);
/* 192 */       this.border = null;
/*     */     } 
/*     */   }
/*     */   
/* 196 */   public Group(Layout paramLayout) { this.doFrustumCulling = false;
/*     */     this.layouter = paramLayout;
/*     */     setInteractive(false); } public final void setFrustumCullingEnabled(boolean paramBoolean) {
/* 199 */     this.doFrustumCulling = paramBoolean;
/*     */   }
/*     */   public final boolean isFrustumCullingEnabled() {
/* 202 */     return this.doFrustumCulling;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void drawImpl0(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint, Vec4f paramVec4f) {
/* 207 */     PMVMatrix pMVMatrix = paramRegionRenderer.getMatrix();
/* 208 */     Object[] arrayOfObject = this.shapes.toArray();
/* 209 */     Arrays.sort(arrayOfObject, (Comparator)Shape.ZAscendingComparator);
/*     */     
/* 211 */     int i = arrayOfObject.length;
/* 212 */     for (byte b = 0; b < i; b++) {
/* 213 */       Shape shape = (Shape)arrayOfObject[b];
/* 214 */       if (shape.isEnabled()) {
/* 215 */         pMVMatrix.glPushMatrix();
/* 216 */         shape.setTransform(pMVMatrix);
/*     */         
/* 218 */         if (!this.doFrustumCulling || !pMVMatrix.getFrustum().isAABBoxOutside(shape.getBounds())) {
/* 219 */           if (null == paramVec4f) {
/* 220 */             shape.drawToSelect(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */           } else {
/* 222 */             shape.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */           } 
/*     */         }
/* 225 */         pMVMatrix.glPopMatrix();
/*     */       } 
/*     */     } 
/* 228 */     if (null != this.border) {
/* 229 */       if (null == paramVec4f) {
/* 230 */         this.border.drawToSelect(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */       } else {
/* 232 */         this.border.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validateImpl(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) {
/* 239 */     if (isShapeDirty()) {
/*     */       
/* 241 */       PMVMatrix pMVMatrix = new PMVMatrix();
/* 242 */       if (null != this.layouter) {
/* 243 */         for (Shape shape : this.shapes) {
/* 244 */           if (null != paramGL2ES2) {
/* 245 */             shape.validate(paramGL2ES2); continue;
/*     */           } 
/* 247 */           shape.validate(paramGLProfile);
/*     */         } 
/*     */         
/* 250 */         this.layouter.layout(this, this.box, pMVMatrix);
/*     */       } else {
/* 252 */         AABBox aABBox = new AABBox();
/* 253 */         for (Shape shape : this.shapes) {
/* 254 */           if (null != paramGL2ES2) {
/* 255 */             shape.validate(paramGL2ES2);
/*     */           } else {
/* 257 */             shape.validate(paramGLProfile);
/*     */           } 
/* 259 */           pMVMatrix.glPushMatrix();
/* 260 */           shape.setTransform(pMVMatrix);
/* 261 */           shape.getBounds().transformMv(pMVMatrix, aABBox);
/* 262 */           pMVMatrix.glPopMatrix();
/* 263 */           this.box.resize(aABBox);
/*     */         } 
/*     */       } 
/* 266 */       if (hasPadding()) {
/* 267 */         Padding padding = getPadding();
/* 268 */         Vec3f vec3f1 = this.box.getLow();
/* 269 */         Vec3f vec3f2 = this.box.getHigh();
/* 270 */         this.box.resize(vec3f1.x() - padding.left, vec3f1.y() - padding.bottom, vec3f1.z());
/* 271 */         this.box.resize(vec3f2.x() + padding.right, vec3f2.y() + padding.top, vec3f1.z());
/* 272 */         setRotationPivot(this.box.getCenter());
/*     */       } 
/* 274 */       if (hasBorder()) {
/* 275 */         if (null == this.border) {
/* 276 */           this.border = new Rectangle(2, this.box, getBorderThickness());
/*     */         } else {
/* 278 */           this.border.setEnabled(true);
/* 279 */           this.border.setBounds(this.box, getBorderThickness());
/*     */         } 
/* 281 */         this.border.setColor(getBorderColor());
/* 282 */       } else if (null != this.border) {
/* 283 */         this.border.setEnabled(false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Shape paramShape) {
/* 290 */     if (this.shapes.contains(paramShape)) {
/* 291 */       return true;
/*     */     }
/* 293 */     for (Shape shape : this.shapes) {
/* 294 */       if (shape instanceof Container && (
/* 295 */         (Container)shape).contains(paramShape)) {
/* 296 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 300 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public AABBox getBounds(PMVMatrix paramPMVMatrix, Shape paramShape) {
/* 305 */     paramPMVMatrix.reset();
/* 306 */     setTransform(paramPMVMatrix);
/* 307 */     AABBox aABBox = new AABBox();
/* 308 */     if (null == paramShape) {
/* 309 */       return aABBox;
/*     */     }
/* 311 */     forOne(paramPMVMatrix, paramShape, () -> paramShape.getBounds().transformMv(paramPMVMatrix, paramAABBox));
/*     */ 
/*     */     
/* 314 */     return aABBox;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSubString() {
/* 319 */     return super.getSubString() + ", shapes " + this.shapes.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean forOne(PMVMatrix paramPMVMatrix, Shape paramShape, Runnable paramRunnable) {
/* 324 */     return TreeTool.forOne(this.shapes, paramPMVMatrix, paramShape, paramRunnable);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean forAll(Shape.Visitor1 paramVisitor1) {
/* 329 */     return TreeTool.forAll(this.shapes, paramVisitor1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean forAll(PMVMatrix paramPMVMatrix, Shape.Visitor2 paramVisitor2) {
/* 334 */     return TreeTool.forAll(this.shapes, paramPMVMatrix, paramVisitor2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean forSortedAll(Comparator<Shape> paramComparator, PMVMatrix paramPMVMatrix, Shape.Visitor2 paramVisitor2) {
/* 339 */     return TreeTool.forSortedAll(paramComparator, this.shapes, paramPMVMatrix, paramVisitor2);
/*     */   }
/*     */   
/*     */   public static interface Layout {
/*     */     void layout(Group param1Group, AABBox param1AABBox, PMVMatrix param1PMVMatrix);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/Group.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */