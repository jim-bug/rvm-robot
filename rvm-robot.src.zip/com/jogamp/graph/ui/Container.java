package com.jogamp.graph.ui;

import com.jogamp.opengl.math.geom.AABBox;
import com.jogamp.opengl.util.PMVMatrix;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public interface Container {
  List<Shape> getShapes();
  
  void addShape(Shape paramShape);
  
  Shape removeShape(Shape paramShape);
  
  Shape removeShape(int paramInt);
  
  void addShapes(Collection<? extends Shape> paramCollection);
  
  void removeShapes(Collection<? extends Shape> paramCollection);
  
  void removeAllShapes();
  
  boolean contains(Shape paramShape);
  
  AABBox getBounds(PMVMatrix paramPMVMatrix, Shape paramShape);
  
  void setFrustumCullingEnabled(boolean paramBoolean);
  
  boolean isFrustumCullingEnabled();
  
  boolean forOne(PMVMatrix paramPMVMatrix, Shape paramShape, Runnable paramRunnable);
  
  boolean forAll(Shape.Visitor1 paramVisitor1);
  
  boolean forAll(PMVMatrix paramPMVMatrix, Shape.Visitor2 paramVisitor2);
  
  boolean forSortedAll(Comparator<Shape> paramComparator, PMVMatrix paramPMVMatrix, Shape.Visitor2 paramVisitor2);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/Container.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */