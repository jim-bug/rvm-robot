/*    */ package com.jogamp.graph.ui.shapes;
/*    */ 
/*    */ import com.jogamp.graph.curve.opengl.RegionRenderer;
/*    */ import com.jogamp.opengl.GL2ES2;
/*    */ import com.jogamp.opengl.util.texture.ImageSequence;
/*    */ import com.jogamp.opengl.util.texture.TextureSequence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageButton
/*    */   extends TexSeqButton
/*    */ {
/*    */   public ImageButton(int paramInt, float paramFloat1, float paramFloat2, ImageSequence paramImageSequence) {
/* 56 */     super(paramInt, paramFloat1, paramFloat2, (TextureSequence)paramImageSequence);
/*    */     
/* 58 */     setColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 59 */     setPressedColorMod(0.9F, 0.9F, 0.9F, 0.9F);
/* 60 */     setToggleOffColorMod(1.0F, 1.0F, 1.0F, 1.0F);
/* 61 */     setToggleOnColorMod(0.8F, 0.8F, 0.8F, 1.0F);
/*    */   }
/*    */   
/*    */   public final void setCurrentIdx(int paramInt) {
/* 65 */     ((ImageSequence)this.texSeq).setCurrentIdx(paramInt);
/* 66 */     markStateDirty();
/*    */   }
/*    */ 
/*    */   
/*    */   public void draw(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint) {
/* 71 */     super.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/* 72 */     if (!((ImageSequence)this.texSeq).getManualStepping())
/* 73 */       markStateDirty(); 
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/ImageButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */