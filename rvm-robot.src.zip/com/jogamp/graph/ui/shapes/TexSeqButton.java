/*    */ package com.jogamp.graph.ui.shapes;
/*    */ 
/*    */ import com.jogamp.graph.curve.OutlineShape;
/*    */ import com.jogamp.opengl.GL2ES2;
/*    */ import com.jogamp.opengl.GLProfile;
/*    */ import com.jogamp.opengl.util.texture.TextureSequence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TexSeqButton
/*    */   extends BaseButton
/*    */ {
/*    */   protected final TextureSequence texSeq;
/*    */   
/*    */   public TexSeqButton(int paramInt, float paramFloat1, float paramFloat2, TextureSequence paramTextureSequence) {
/* 52 */     super(paramInt | 0x400, paramFloat1, paramFloat2);
/* 53 */     this.texSeq = paramTextureSequence;
/*    */   }
/*    */   public final TextureSequence getTextureSequence() {
/* 56 */     return this.texSeq;
/*    */   }
/*    */   
/*    */   protected void addShapeToRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) {
/* 60 */     OutlineShape outlineShape = createBaseShape(0.0F);
/* 61 */     resetGLRegion(paramGLProfile, paramGL2ES2, this.texSeq, outlineShape);
/* 62 */     this.region.addOutlineShape(outlineShape, null, this.rgbaColor);
/* 63 */     this.box.resize(outlineShape.getBounds());
/* 64 */     setRotationPivot(this.box.getCenter());
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/TexSeqButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */