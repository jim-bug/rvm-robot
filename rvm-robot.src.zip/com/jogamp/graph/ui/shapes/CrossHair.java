/*     */ package com.jogamp.graph.ui.shapes;
/*     */ 
/*     */ import com.jogamp.graph.curve.OutlineShape;
/*     */ import com.jogamp.graph.ui.GraphShape;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrossHair
/*     */   extends GraphShape
/*     */ {
/*     */   private float width;
/*     */   private float height;
/*     */   private float lineWidth;
/*     */   
/*     */   public CrossHair(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  45 */     super(paramInt);
/*  46 */     this.width = paramFloat1;
/*  47 */     this.height = paramFloat2;
/*  48 */     this.lineWidth = paramFloat3;
/*     */   }
/*     */   
/*  51 */   public final float getWidth() { return this.width; }
/*  52 */   public final float getHeight() { return this.height; } public final float getLineWidth() {
/*  53 */     return this.lineWidth;
/*     */   }
/*     */   public void setDimension(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  56 */     this.width = paramFloat1;
/*  57 */     this.height = paramFloat2;
/*  58 */     this.lineWidth = paramFloat3;
/*  59 */     markShapeDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addShapeToRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) {
/*  64 */     OutlineShape outlineShape = new OutlineShape();
/*     */     
/*  66 */     float f1 = this.lineWidth / 2.0F;
/*     */     
/*  68 */     float f2 = getWidth();
/*  69 */     float f3 = getHeight();
/*  70 */     float f4 = f2 / 2.0F;
/*  71 */     float f5 = f3 / 2.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     outlineShape.moveTo(0.0F - f1, 0.0F - f5, 0.0F);
/*  78 */     outlineShape.lineTo(0.0F + f1, 0.0F - f5, 0.0F);
/*  79 */     outlineShape.lineTo(0.0F + f1, 0.0F + f5, 0.0F);
/*  80 */     outlineShape.lineTo(0.0F - f1, 0.0F + f5, 0.0F);
/*  81 */     outlineShape.closePath();
/*     */ 
/*     */     
/*  84 */     outlineShape.moveTo(0.0F - f4, 0.0F - f1, 0.0F);
/*  85 */     outlineShape.lineTo(0.0F + f4, 0.0F - f1, 0.0F);
/*  86 */     outlineShape.lineTo(0.0F + f4, 0.0F + f1, 0.0F);
/*  87 */     outlineShape.lineTo(0.0F - f4, 0.0F + f1, 0.0F);
/*  88 */     outlineShape.closePath();
/*     */     
/*  90 */     outlineShape.setIsQuadraticNurbs();
/*  91 */     outlineShape.setSharpness(this.oshapeSharpness);
/*     */     
/*  93 */     resetGLRegion(paramGLProfile, paramGL2ES2, null, outlineShape);
/*  94 */     this.region.addOutlineShape(outlineShape, null, this.rgbaColor);
/*  95 */     this.box.resize(outlineShape.getBounds());
/*  96 */     setRotationPivot(this.box.getCenter());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSubString() {
/* 101 */     return super.getSubString() + ", dim " + getWidth() + " x " + getHeight();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/CrossHair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */