/*     */ package com.jogamp.graph.ui.shapes;
/*     */ 
/*     */ import com.jogamp.graph.curve.OutlineShape;
/*     */ import com.jogamp.graph.curve.Region;
/*     */ import com.jogamp.graph.curve.opengl.RegionRenderer;
/*     */ import com.jogamp.graph.curve.opengl.TextRegionUtil;
/*     */ import com.jogamp.graph.font.Font;
/*     */ import com.jogamp.graph.geom.plane.AffineTransform;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ import com.jogamp.opengl.math.FloatUtil;
/*     */ import com.jogamp.opengl.math.Vec2f;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import jogamp.graph.ui.shapes.Label0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Button
/*     */   extends BaseButton
/*     */ {
/*     */   public static final float DEFAULT_SPACING_X = 0.12F;
/*     */   public static final float DEFAULT_SPACING_Y = 0.42F;
/*     */   private static final float DEFAULT_LABEL_ZOFFSET = 0.005F;
/*     */   private float labelZOffset;
/*     */   private final Label0 label;
/*  67 */   private float spacingX = 0.12F;
/*  68 */   private float spacingY = 0.42F;
/*     */   
/*  70 */   private final AffineTransform tempT1 = new AffineTransform();
/*  71 */   private final AffineTransform tempT2 = new AffineTransform();
/*  72 */   private final AffineTransform tempT3 = new AffineTransform();
/*     */ 
/*     */ 
/*     */   
/*     */   public Button(int paramInt, Font paramFont, String paramString, float paramFloat1, float paramFloat2) {
/*  77 */     super(paramInt | 0x200, paramFloat1, paramFloat2);
/*  78 */     this.labelZOffset = 0.005F;
/*  79 */     this.label = new Label0(paramFont, paramString, new Vec4f(1.66F, 1.66F, 1.66F, 1.0F));
/*     */   }
/*     */   
/*  82 */   public Font getFont() { return this.label.getFont(); } public String getLaben() {
/*  83 */     return this.label.getText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint) {
/*  91 */     super.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addShapeToRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) {
/*  97 */     OutlineShape outlineShape = createBaseShape(FloatUtil.isZero(this.labelZOffset) ? 0.0F : -this.labelZOffset);
/*  98 */     this.box.resize(outlineShape.getBounds());
/*  99 */     setRotationPivot(this.box.getCenter());
/*     */ 
/*     */     
/* 102 */     int[] arrayOfInt = Region.countOutlineShape(outlineShape, new int[2]);
/* 103 */     TextRegionUtil.countStringRegion(this.label.getFont(), this.label.getText(), arrayOfInt);
/* 104 */     resetGLRegion(paramGLProfile, paramGL2ES2, null, arrayOfInt[0], arrayOfInt[1]);
/*     */     
/* 106 */     this.region.addOutlineShape(outlineShape, null, this.rgbaColor);
/*     */ 
/*     */     
/* 109 */     float f1 = this.box.getWidth() * (1.0F - this.spacingX);
/* 110 */     float f2 = this.box.getHeight() * (1.0F - this.spacingY);
/* 111 */     AABBox aABBox1 = this.label.getFont().getGlyphBounds(this.label.getText(), this.tempT1, this.tempT2);
/*     */     
/* 113 */     float f3 = f1 / aABBox1.getWidth();
/* 114 */     float f4 = f2 / aABBox1.getHeight();
/* 115 */     float f5 = (f3 < f4) ? f3 : f4;
/*     */ 
/*     */     
/* 118 */     AABBox aABBox2 = (new AABBox(aABBox1)).scale2(f5);
/*     */     
/* 120 */     Vec3f vec3f1 = aABBox2.getCenter();
/* 121 */     Vec3f vec3f2 = this.box.getCenter();
/* 122 */     Vec2f vec2f = new Vec2f(vec3f2.x() - vec3f1.x(), vec3f2.y() - vec3f1.y());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     AABBox aABBox3 = this.label.addShapeToRegion(f5, (Region)this.region, vec2f, this.tempT1, this.tempT2, this.tempT3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getLabelZOffset() {
/* 140 */     return this.labelZOffset;
/*     */   }
/*     */   public Button setLabelZOffset(float paramFloat) {
/* 143 */     this.labelZOffset = paramFloat;
/* 144 */     markShapeDirty();
/* 145 */     return this;
/*     */   }
/*     */   
/* 148 */   public final float getSpacingX() { return this.spacingX; } public final float getSpacingY() {
/* 149 */     return this.spacingY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Button setSpacing(float paramFloat1, float paramFloat2) {
/* 157 */     if (paramFloat1 < 0.0F) {
/* 158 */       this.spacingX = 0.0F;
/* 159 */     } else if (paramFloat1 > 1.0F) {
/* 160 */       this.spacingX = 1.0F;
/*     */     } else {
/* 162 */       this.spacingX = paramFloat1;
/*     */     } 
/* 164 */     if (paramFloat2 < 0.0F) {
/* 165 */       this.spacingY = 0.0F;
/* 166 */     } else if (paramFloat2 > 1.0F) {
/* 167 */       this.spacingY = 1.0F;
/*     */     } else {
/* 169 */       this.spacingY = paramFloat2;
/*     */     } 
/* 171 */     markShapeDirty();
/* 172 */     return this;
/*     */   }
/*     */   
/*     */   public final Vec4f getLabelColor() {
/* 176 */     return this.label.getColor();
/*     */   }
/*     */   
/*     */   public final Button setLabelColor(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 180 */     this.label.setColor(paramFloat1, paramFloat2, paramFloat3, 1.0F);
/* 181 */     markShapeDirty();
/* 182 */     return this;
/*     */   }
/*     */   
/*     */   public final Button setFont(Font paramFont) {
/* 186 */     if (!this.label.getFont().equals(paramFont)) {
/* 187 */       this.label.setFont(paramFont);
/* 188 */       markShapeDirty();
/*     */     } 
/* 190 */     return this;
/*     */   }
/*     */   public final Button setLabel(String paramString) {
/* 193 */     if (!this.label.getText().equals(paramString)) {
/* 194 */       this.label.setText(paramString);
/* 195 */       markShapeDirty();
/*     */     } 
/* 197 */     return this;
/*     */   }
/*     */   public final Button setLabel(Font paramFont, String paramString) {
/* 200 */     if (!this.label.getText().equals(paramString) || !this.label.getFont().equals(paramFont)) {
/* 201 */       this.label.setFont(paramFont);
/* 202 */       this.label.setText(paramString);
/* 203 */       markShapeDirty();
/*     */     } 
/* 205 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSubString() {
/* 210 */     return super.getSubString() + ", " + this.label + ", spacing[" + this.spacingX + ", " + this.spacingY + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/Button.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */