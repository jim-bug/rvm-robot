/*     */ package com.jogamp.graph.ui.shapes;
/*     */ 
/*     */ import com.jogamp.graph.curve.OutlineShape;
/*     */ import com.jogamp.graph.curve.opengl.GLRegion;
/*     */ import com.jogamp.graph.curve.opengl.TextRegionUtil;
/*     */ import com.jogamp.graph.font.Font;
/*     */ import com.jogamp.graph.geom.plane.AffineTransform;
/*     */ import com.jogamp.graph.ui.GraphShape;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ import com.jogamp.opengl.math.Vec4f;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Label
/*     */   extends GraphShape
/*     */ {
/*     */   private Font font;
/*     */   private float fontScale;
/*     */   private String text;
/*  52 */   private final AffineTransform tempT1 = new AffineTransform();
/*  53 */   private final AffineTransform tempT2 = new AffineTransform();
/*  54 */   private final AffineTransform tempT3 = new AffineTransform();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Font.GlyphVisitor glyphVisitor;
/*     */ 
/*     */ 
/*     */   
/*     */   public Label(int paramInt, Font paramFont, float paramFloat, String paramString)
/*     */   {
/*  64 */     super(paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     this.glyphVisitor = new Font.GlyphVisitor()
/*     */       {
/*     */         public void visit(char param1Char, Font.Glyph param1Glyph, AffineTransform param1AffineTransform) {
/* 196 */           if (param1Glyph.isWhiteSpace()) {
/*     */             return;
/*     */           }
/* 199 */           OutlineShape outlineShape = param1Glyph.getShape();
/* 200 */           outlineShape.setSharpness(Label.this.oshapeSharpness);
/* 201 */           Label.this.region.addOutlineShape(outlineShape, param1AffineTransform, Label.this.rgbaColor); } }; this.font = paramFont; this.fontScale = paramFloat; this.text = paramString; } public Label(int paramInt, Font paramFont, String paramString) { super(paramInt); this.glyphVisitor = new Font.GlyphVisitor() { public void visit(char param1Char, Font.Glyph param1Glyph, AffineTransform param1AffineTransform) { if (param1Glyph.isWhiteSpace()) return;  OutlineShape outlineShape = param1Glyph.getShape(); outlineShape.setSharpness(Label.this.oshapeSharpness); Label.this.region.addOutlineShape(outlineShape, param1AffineTransform, Label.this.rgbaColor); } }; this.font = paramFont; this.fontScale = 1.0F; this.text = paramString; }
/*     */   public String getText() { return this.text; }
/*     */   public boolean setText(String paramString) { if (!this.text.equals(paramString)) {
/*     */       this.text = paramString; markShapeDirty();
/*     */       return true;
/*     */     } 
/* 207 */     return false; } protected void addShapeToRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) { int[] arrayOfInt = TextRegionUtil.countStringRegion(this.font, this.text, new int[2]);
/* 208 */     resetGLRegion(paramGLProfile, paramGL2ES2, null, arrayOfInt[0], arrayOfInt[1]);
/*     */     
/* 210 */     AABBox aABBox = this.font.getGlyphBounds(this.text, this.tempT2, this.tempT3);
/* 211 */     this.tempT1.setToScale(this.fontScale, this.fontScale);
/* 212 */     this.tempT1.translate(-aABBox.getMinX(), -aABBox.getMinY(), this.tempT2);
/* 213 */     aABBox = this.font.processString(this.glyphVisitor, this.tempT1, this.text, this.tempT2, this.tempT3);
/* 214 */     setRotationPivot(aABBox.getCenter());
/* 215 */     this.box.copy(aABBox); }
/*     */   public boolean setText(GL2ES2 paramGL2ES2, String paramString) { if (setText(paramString)) { validate(paramGL2ES2); return true; }  return false; }
/*     */   public boolean setText(GLProfile paramGLProfile, String paramString) { if (setText(paramString)) { validate(paramGLProfile); return true; }  return false; }
/*     */   public Font getFont() { return this.font; }
/*     */   public boolean setFont(Font paramFont) { if (!this.font.equals(paramFont)) { this.font = paramFont; markShapeDirty(); return true; }  return false; }
/* 220 */   public float getFontScale() { return this.fontScale; } public float getLineHeight() { return this.fontScale * this.font.getLineHeight(); } public float getScaledLineHeight() { return getScale().y() * this.fontScale * this.font.getLineHeight(); } public boolean setFontScale(float paramFloat) { if (this.fontScale != paramFloat) { this.fontScale = paramFloat; markShapeDirty(); return true; }  return false; } public String getSubString() { int i = Math.min(this.text.length(), 8);
/* 221 */     return super.getSubString() + ", fscale " + this.fontScale + ", '" + this.text.substring(0, i) + "'"; }
/*     */ 
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/Label.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */