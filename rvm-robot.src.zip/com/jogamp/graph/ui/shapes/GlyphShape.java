/*     */ package com.jogamp.graph.ui.shapes;
/*     */ 
/*     */ import com.jogamp.graph.curve.OutlineShape;
/*     */ import com.jogamp.graph.curve.Region;
/*     */ import com.jogamp.graph.font.Font;
/*     */ import com.jogamp.graph.geom.plane.AffineTransform;
/*     */ import com.jogamp.graph.ui.GraphShape;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlyphShape
/*     */   extends GraphShape
/*     */ {
/*     */   private final char symbol;
/*     */   private final Font.Glyph glyph;
/*     */   private final int regionVertCount;
/*     */   private final int regionIdxCount;
/*     */   private final Vec3f origPos;
/*     */   
/*     */   public GlyphShape(int paramInt, char paramChar, Font.Glyph paramGlyph, float paramFloat1, float paramFloat2) {
/*  70 */     super(paramInt);
/*  71 */     this.symbol = paramChar;
/*  72 */     this.glyph = paramGlyph;
/*  73 */     this.origPos = new Vec3f(paramFloat1, paramFloat2, 0.0F);
/*  74 */     if (paramGlyph.isWhiteSpace() || null == paramGlyph.getShape()) {
/*  75 */       setEnabled(false);
/*     */     }
/*  77 */     int[] arrayOfInt = Region.countOutlineShape(paramGlyph.getShape(), new int[2]);
/*  78 */     this.regionVertCount = arrayOfInt[0];
/*  79 */     this.regionIdxCount = arrayOfInt[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlyphShape(int paramInt, Font paramFont, char paramChar, float paramFloat1, float paramFloat2) {
/*  91 */     this(paramInt, paramChar, paramFont.getGlyph(paramFont.getGlyphID(paramChar)), paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getSymbol() {
/*  96 */     return this.symbol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font.Glyph getGlyph() {
/* 103 */     return this.glyph;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont() {
/* 110 */     return this.glyph.getFont();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec3f getOrigPos() {
/* 120 */     return this.origPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec3f getOrigPos(Vec3f paramVec3f) {
/* 129 */     return paramVec3f.set(this.origPos);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec3f getOrigPos(float paramFloat) {
/* 135 */     return this.origPos.mul(paramFloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec3f getOrigPos(Vec3f paramVec3f, float paramFloat) {
/* 143 */     return paramVec3f.set(this.origPos).scale(paramFloat);
/*     */   }
/*     */   
/*     */   public void resetPos(float paramFloat) {
/* 147 */     moveTo(this.origPos.x() * paramFloat, this.origPos.y() * paramFloat, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetPosAndScale(float paramFloat) {
/* 152 */     moveTo(this.origPos.x() * paramFloat, this.origPos.y() * paramFloat, 0.0F);
/* 153 */     setScale(paramFloat, paramFloat, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getLineHeight() {
/* 158 */     return this.glyph.getFont().getLineHeight();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final AABBox processString(final List<GlyphShape> res, final int renderModes, Font paramFont, String paramString) {
/* 172 */     Font.GlyphVisitor glyphVisitor = new Font.GlyphVisitor()
/*     */       {
/*     */         public void visit(char param1Char, Font.Glyph param1Glyph, AffineTransform param1AffineTransform) {
/* 175 */           if (!param1Glyph.isWhiteSpace() && null != param1Glyph.getShape()) {
/* 176 */             res.add(new GlyphShape(renderModes, param1Char, param1Glyph, param1AffineTransform.getTranslateX(), param1AffineTransform.getTranslateY()));
/*     */           }
/*     */         }
/*     */       };
/* 180 */     return paramFont.processString(glyphVisitor, null, paramString, new AffineTransform(), new AffineTransform());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addShapeToRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) {
/* 185 */     OutlineShape outlineShape = this.glyph.getShape();
/* 186 */     this.box.reset();
/* 187 */     if (null != outlineShape) {
/* 188 */       AABBox aABBox = outlineShape.getBounds();
/* 189 */       AffineTransform affineTransform = new AffineTransform();
/*     */ 
/*     */       
/* 192 */       affineTransform.setToTranslation(-aABBox.getMinX(), -aABBox.getMinY() + this.glyph.getBounds().getMinY());
/* 193 */       outlineShape.setSharpness(this.oshapeSharpness);
/*     */       
/* 195 */       resetGLRegion(paramGLProfile, paramGL2ES2, null, this.regionVertCount, this.regionIdxCount);
/* 196 */       this.region.addOutlineShape(outlineShape, affineTransform, this.rgbaColor);
/* 197 */       this.box.resize(affineTransform.transform(aABBox, new AABBox()));
/* 198 */       setRotationPivot(this.box.getCenter());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSubString() {
/* 204 */     return super.getSubString() + ", origPos " + this.origPos.x() + " / " + this.origPos.y() + ", '" + this.symbol + "'";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/GlyphShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */