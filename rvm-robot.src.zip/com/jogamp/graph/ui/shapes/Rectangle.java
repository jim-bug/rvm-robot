/*     */ package com.jogamp.graph.ui.shapes;
/*     */ 
/*     */ import com.jogamp.graph.curve.OutlineShape;
/*     */ import com.jogamp.graph.ui.GraphShape;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rectangle
/*     */   extends GraphShape
/*     */ {
/*     */   private float minX;
/*     */   private float minY;
/*     */   private float zPos;
/*     */   private float width;
/*     */   private float height;
/*     */   private float lineWidth;
/*     */   
/*     */   public Rectangle(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  49 */     super(paramInt);
/*  50 */     this.minX = paramFloat1;
/*  51 */     this.minY = paramFloat2;
/*  52 */     this.zPos = paramFloat6;
/*  53 */     this.width = paramFloat3;
/*  54 */     this.height = paramFloat4;
/*  55 */     this.lineWidth = paramFloat5;
/*     */   }
/*     */   
/*     */   public Rectangle(int paramInt, AABBox paramAABBox, float paramFloat) {
/*  59 */     this(paramInt, paramAABBox.getMinX(), paramAABBox.getMinY(), paramAABBox.getWidth(), paramAABBox.getHeight(), paramFloat, paramAABBox.getCenter().z());
/*     */   }
/*     */   
/*     */   public Rectangle(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
/*  63 */     this(paramInt, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, 0.0F);
/*     */   }
/*     */   public Rectangle(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  66 */     this(paramInt, 0.0F, 0.0F, paramFloat1, paramFloat2, paramFloat3, 0.0F);
/*     */   }
/*     */   
/*  69 */   public final float getWidth() { return this.width; }
/*  70 */   public final float getHeight() { return this.height; } public final float getLineWidth() {
/*  71 */     return this.lineWidth;
/*     */   }
/*     */   public void setPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  74 */     this.minX = paramFloat1;
/*  75 */     this.minY = paramFloat2;
/*  76 */     this.zPos = paramFloat3;
/*  77 */     markShapeDirty();
/*     */   }
/*     */   public void setDimension(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  80 */     this.width = paramFloat1;
/*  81 */     this.height = paramFloat2;
/*  82 */     this.lineWidth = paramFloat3;
/*  83 */     markShapeDirty();
/*     */   }
/*     */   public void setBounds(AABBox paramAABBox, float paramFloat) {
/*  86 */     setPosition(paramAABBox.getMinX(), paramAABBox.getMinY(), paramAABBox.getCenter().z());
/*  87 */     setDimension(paramAABBox.getWidth(), paramAABBox.getHeight(), paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addShapeToRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) {
/*  92 */     OutlineShape outlineShape = new OutlineShape();
/*  93 */     float f1 = this.minX;
/*  94 */     float f2 = this.minY;
/*  95 */     float f3 = this.minX + getWidth();
/*  96 */     float f4 = this.minY + getHeight();
/*  97 */     float f5 = this.zPos;
/*     */ 
/*     */     
/* 100 */     outlineShape.moveTo(f1, f2, f5);
/* 101 */     outlineShape.lineTo(f3, f2, f5);
/* 102 */     outlineShape.lineTo(f3, f4, f5);
/* 103 */     outlineShape.lineTo(f1, f4, f5);
/* 104 */     outlineShape.lineTo(f1, f2, f5);
/* 105 */     outlineShape.closeLastOutline(true);
/* 106 */     outlineShape.addEmptyOutline();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     float f6 = this.lineWidth;
/* 112 */     outlineShape.moveTo(f1 + f6, f2 + f6, f5);
/* 113 */     outlineShape.lineTo(f1 + f6, f4 - f6, f5);
/* 114 */     outlineShape.lineTo(f3 - f6, f4 - f6, f5);
/* 115 */     outlineShape.lineTo(f3 - f6, f2 + f6, f5);
/* 116 */     outlineShape.lineTo(f1 + f6, f2 + f6, f5);
/* 117 */     outlineShape.closeLastOutline(true);
/*     */     
/* 119 */     outlineShape.setIsQuadraticNurbs();
/* 120 */     outlineShape.setSharpness(this.oshapeSharpness);
/*     */     
/* 122 */     resetGLRegion(paramGLProfile, paramGL2ES2, null, outlineShape);
/* 123 */     this.region.addOutlineShape(outlineShape, null, this.rgbaColor);
/* 124 */     this.box.resize(outlineShape.getBounds());
/* 125 */     setRotationPivot(this.box.getCenter());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSubString() {
/* 130 */     return super.getSubString() + ", dim " + getWidth() + " x " + getHeight();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/Rectangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */