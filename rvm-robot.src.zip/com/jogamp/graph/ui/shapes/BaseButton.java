/*     */ package com.jogamp.graph.ui.shapes;
/*     */ 
/*     */ import com.jogamp.graph.curve.OutlineShape;
/*     */ import com.jogamp.graph.ui.GraphShape;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLProfile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseButton
/*     */   extends GraphShape
/*     */ {
/*     */   public static final float ROUND_CORNER = 1.0F;
/*     */   public static final float PERP_CORNER = 0.0F;
/*     */   protected float width;
/*     */   protected float height;
/*  55 */   protected float corner = 1.0F;
/*     */   
/*     */   public BaseButton(int paramInt, float paramFloat1, float paramFloat2) {
/*  58 */     super(paramInt);
/*  59 */     this.width = paramFloat1;
/*  60 */     this.height = paramFloat2;
/*     */   }
/*     */   public final float getWidth() {
/*  63 */     return this.width;
/*     */   } public final float getHeight() {
/*  65 */     return this.height;
/*     */   } public final float getCorner() {
/*  67 */     return this.corner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseButton setCorner(float paramFloat) {
/*  80 */     if (0.01F <= paramFloat && paramFloat <= 1.0F) {
/*  81 */       this.corner = paramFloat;
/*     */     }
/*  83 */     if (paramFloat > 1.0F) {
/*  84 */       this.corner = 1.0F;
/*  85 */     } else if (paramFloat < 0.01F) {
/*  86 */       this.corner = 0.0F;
/*     */     } else {
/*  88 */       this.corner = paramFloat;
/*     */     } 
/*  90 */     markShapeDirty();
/*  91 */     return this;
/*     */   }
/*     */   
/*     */   public BaseButton setSize(float paramFloat1, float paramFloat2) {
/*  95 */     this.width = paramFloat1;
/*  96 */     this.height = paramFloat2;
/*  97 */     markShapeDirty();
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addShapeToRegion(GLProfile paramGLProfile, GL2ES2 paramGL2ES2) {
/* 103 */     OutlineShape outlineShape = createBaseShape(0.0F);
/* 104 */     resetGLRegion(paramGLProfile, paramGL2ES2, null, outlineShape);
/* 105 */     this.region.addOutlineShape(outlineShape, null, this.rgbaColor);
/* 106 */     this.box.resize(outlineShape.getBounds());
/* 107 */     setRotationPivot(this.box.getCenter());
/*     */   }
/*     */   
/*     */   protected OutlineShape createBaseShape(float paramFloat) {
/* 111 */     OutlineShape outlineShape = new OutlineShape();
/* 112 */     if (this.corner == 0.0F) {
/* 113 */       createSharpOutline(outlineShape, paramFloat);
/*     */     } else {
/* 115 */       createCurvedOutline(outlineShape, paramFloat);
/*     */     } 
/* 117 */     outlineShape.setIsQuadraticNurbs();
/* 118 */     outlineShape.setSharpness(this.oshapeSharpness);
/*     */ 
/*     */ 
/*     */     
/* 122 */     return outlineShape;
/*     */   }
/*     */   
/*     */   protected void createSharpOutline(OutlineShape paramOutlineShape, float paramFloat) {
/* 126 */     float f1 = getWidth();
/* 127 */     float f2 = getHeight();
/*     */ 
/*     */ 
/*     */     
/* 131 */     float f3 = paramFloat;
/*     */     
/* 133 */     paramOutlineShape.addVertex(0.0F, 0.0F, f3, true);
/* 134 */     paramOutlineShape.addVertex(0.0F + f1, 0.0F, f3, true);
/* 135 */     paramOutlineShape.addVertex(0.0F + f1, 0.0F + f2, f3, true);
/* 136 */     paramOutlineShape.addVertex(0.0F, 0.0F + f2, f3, true);
/* 137 */     paramOutlineShape.closeLastOutline(true);
/*     */   }
/*     */   
/*     */   protected void createCurvedOutline(OutlineShape paramOutlineShape, float paramFloat) {
/* 141 */     float f1 = getWidth();
/* 142 */     float f2 = getHeight();
/* 143 */     float f3 = 0.5F * this.corner * Math.min(f1, f2);
/*     */ 
/*     */ 
/*     */     
/* 147 */     float f4 = paramFloat;
/*     */     
/* 149 */     paramOutlineShape.addVertex(0.0F, 0.0F + f3, f4, true);
/* 150 */     paramOutlineShape.addVertex(0.0F, 0.0F, f4, false);
/*     */     
/* 152 */     paramOutlineShape.addVertex(0.0F + f3, 0.0F, f4, true);
/*     */     
/* 154 */     paramOutlineShape.addVertex(0.0F + f1 - f3, 0.0F, f4, true);
/* 155 */     paramOutlineShape.addVertex(0.0F + f1, 0.0F, f4, false);
/* 156 */     paramOutlineShape.addVertex(0.0F + f1, 0.0F + f3, f4, true);
/* 157 */     paramOutlineShape.addVertex(0.0F + f1, 0.0F + f2 - f3, f4, true);
/* 158 */     paramOutlineShape.addVertex(0.0F + f1, 0.0F + f2, f4, false);
/* 159 */     paramOutlineShape.addVertex(0.0F + f1 - f3, 0.0F + f2, f4, true);
/* 160 */     paramOutlineShape.addVertex(0.0F + f3, 0.0F + f2, f4, true);
/* 161 */     paramOutlineShape.addVertex(0.0F, 0.0F + f2, f4, false);
/* 162 */     paramOutlineShape.addVertex(0.0F, 0.0F + f2 - f3, f4, true);
/*     */     
/* 164 */     paramOutlineShape.closeLastOutline(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSubString() {
/* 169 */     return super.getSubString() + ", dim " + getWidth() + " x " + getHeight() + ", corner " + this.corner;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/BaseButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */