/*     */ package com.jogamp.graph.ui.shapes;
/*     */ 
/*     */ import com.jogamp.common.av.AudioSink;
/*     */ import com.jogamp.common.util.InterruptSource;
/*     */ import com.jogamp.graph.curve.opengl.RegionRenderer;
/*     */ import com.jogamp.opengl.GL;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.util.av.GLMediaPlayer;
/*     */ import com.jogamp.opengl.util.texture.TextureSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaButton
/*     */   extends TexSeqButton
/*     */ {
/*     */   private boolean verbose = false;
/*     */   private final GLMediaPlayer.GLMediaEventListener defGLMediaEventListener;
/*     */   volatile boolean resetGL;
/*     */   
/*     */   public MediaButton(int paramInt, float paramFloat1, float paramFloat2, GLMediaPlayer paramGLMediaPlayer) {
/*  69 */     super(paramInt, paramFloat1, paramFloat2, (TextureSequence)paramGLMediaPlayer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     this.defGLMediaEventListener = new GLMediaPlayer.GLMediaEventListener()
/*     */       {
/*     */         public void newFrameAvailable(GLMediaPlayer param1GLMediaPlayer, TextureSequence.TextureFrame param1TextureFrame, long param1Long) {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void attributesChanged(final GLMediaPlayer mp, GLMediaPlayer.EventMask param1EventMask, long param1Long) {
/*  98 */           if (MediaButton.this.verbose) {
/*  99 */             System.err.println("MediaButton AttributesChanges: " + param1EventMask + ", when " + param1Long);
/* 100 */             System.err.println("MediaButton State: " + mp);
/*     */           } 
/* 102 */           if (param1EventMask.isSet(GLMediaPlayer.EventMask.Bit.Init)) {
/* 103 */             MediaButton.this.resetGL = true;
/*     */           }
/* 105 */           if (param1EventMask.isSet(GLMediaPlayer.EventMask.Bit.Size));
/*     */ 
/*     */           
/* 108 */           if (param1EventMask.isSet(GLMediaPlayer.EventMask.Bit.EOS)) {
/* 109 */             (new InterruptSource.Thread()
/*     */               {
/*     */                 public void run()
/*     */                 {
/* 113 */                   mp.seek(0);
/* 114 */                   mp.resume(); }
/* 115 */               }).start();
/* 116 */           } else if (param1EventMask.isSet(GLMediaPlayer.EventMask.Bit.Error)) {
/* 117 */             GLMediaPlayer.StreamException streamException = mp.getStreamException();
/* 118 */             if (null != streamException) {
/* 119 */               streamException.printStackTrace();
/*     */             }
/*     */           } 
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     this.resetGL = true;
/*     */     setColor(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     setPressedColorMod(0.9F, 0.9F, 0.9F, 0.7F);
/*     */     setToggleOffColorMod(0.8F, 0.8F, 0.8F, 1.0F);
/* 134 */     setToggleOnColorMod(1.0F, 1.0F, 1.0F, 1.0F); } public void draw(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint) { GLMediaPlayer gLMediaPlayer = (GLMediaPlayer)this.texSeq;
/* 135 */     if (this.resetGL) {
/* 136 */       this.resetGL = false;
/*     */       try {
/* 138 */         gLMediaPlayer.initGL((GL)paramGL2ES2);
/* 139 */         if (null != this.region) {
/* 140 */           this.region.markShapeDirty();
/*     */         }
/* 142 */       } catch (Exception exception) {
/* 143 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/* 146 */     super.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/* 147 */     markStateDirty(); }
/*     */ 
/*     */   
/*     */   public void setVerbose(boolean paramBoolean) {
/*     */     this.verbose = paramBoolean;
/*     */   }
/*     */   
/*     */   public void addDefaultEventListener() {
/*     */     getGLMediaPlayer().addEventListener(this.defGLMediaEventListener);
/*     */   }
/*     */   
/*     */   public final GLMediaPlayer getGLMediaPlayer() {
/*     */     return (GLMediaPlayer)this.texSeq;
/*     */   }
/*     */   
/*     */   public final AudioSink getAudioSink() {
/*     */     return getGLMediaPlayer().getAudioSink();
/*     */   }
/*     */   
/*     */   protected void destroyImpl(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/*     */     ((GLMediaPlayer)this.texSeq).destroy((GL)paramGL2ES2);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/MediaButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */