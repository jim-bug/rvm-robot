/*     */ package com.jogamp.graph.ui.shapes;
/*     */ 
/*     */ import com.jogamp.graph.curve.opengl.RegionRenderer;
/*     */ import com.jogamp.opengl.FBObject;
/*     */ import com.jogamp.opengl.GL;
/*     */ import com.jogamp.opengl.GL2ES2;
/*     */ import com.jogamp.opengl.GLCapabilities;
/*     */ import com.jogamp.opengl.GLCapabilitiesImmutable;
/*     */ import com.jogamp.opengl.GLContext;
/*     */ import com.jogamp.opengl.GLDrawable;
/*     */ import com.jogamp.opengl.GLDrawableFactory;
/*     */ import com.jogamp.opengl.GLEventListener;
/*     */ import com.jogamp.opengl.GLOffscreenAutoDrawable;
/*     */ import com.jogamp.opengl.util.texture.ImageSequence;
/*     */ import com.jogamp.opengl.util.texture.Texture;
/*     */ import com.jogamp.opengl.util.texture.TextureSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GLButton
/*     */   extends TexSeqButton
/*     */ {
/*     */   private final GLEventListener glel;
/*     */   private final boolean useAlpha;
/*  68 */   private volatile int fboWidth = 200;
/*  69 */   private volatile int fboHeight = 200;
/*  70 */   private volatile GLOffscreenAutoDrawable.FBO fboGLAD = null;
/*     */   
/*     */   private boolean animateGLEL = false;
/*     */   
/*     */   public GLButton(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, GLEventListener paramGLEventListener, boolean paramBoolean) {
/*  75 */     super(paramInt1, paramFloat1, paramFloat2, (TextureSequence)new ImageSequence(paramInt2, true));
/*  76 */     this.glel = paramGLEventListener;
/*  77 */     this.useAlpha = paramBoolean;
/*     */     
/*  79 */     setColor(1.0F, 1.0F, 1.0F, 1.0F);
/*  80 */     setPressedColorMod(0.9F, 0.9F, 0.9F, 0.7F);
/*  81 */     setToggleOffColorMod(0.8F, 0.8F, 0.8F, 1.0F);
/*  82 */     setToggleOnColorMod(1.0F, 1.0F, 1.0F, 1.0F);
/*     */ 
/*     */     
/*  85 */     this.fboWidth = 320;
/*  86 */     this.fboHeight = Math.round(640.0F * paramFloat2 / paramFloat1);
/*     */   }
/*     */   
/*  89 */   public final void setAnimate(boolean paramBoolean) { this.animateGLEL = paramBoolean; } public final boolean getAnimate() {
/*  90 */     return this.animateGLEL;
/*     */   }
/*     */   public final void setFBOSize(int paramInt1, int paramInt2) {
/*  93 */     this.fboWidth = paramInt1;
/*  94 */     this.fboHeight = paramInt2;
/*     */   }
/*     */   public final GLOffscreenAutoDrawable.FBO getFBOAutoDrawable() {
/*  97 */     return this.fboGLAD;
/*     */   }
/*     */   
/*     */   protected void destroyImpl(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer) {
/* 101 */     ((ImageSequence)this.texSeq).destroy((GL)paramGL2ES2);
/* 102 */     this.fboGLAD.destroy();
/*     */   }
/*     */ 
/*     */   
/*     */   public void draw(GL2ES2 paramGL2ES2, RegionRenderer paramRegionRenderer, int[] paramArrayOfint) {
/* 107 */     int[] arrayOfInt = getSurfaceSize(paramRegionRenderer.getMatrix(), paramRegionRenderer.getViewport(), new int[2]);
/* 108 */     boolean bool = (null != arrayOfInt && 0 < arrayOfInt[0] && 0 < arrayOfInt[1]) ? true : false;
/*     */     
/* 110 */     if (null == this.fboGLAD) {
/* 111 */       ImageSequence imageSequence = (ImageSequence)this.texSeq;
/*     */       
/* 113 */       GLContext gLContext = paramGL2ES2.getContext();
/* 114 */       GLDrawable gLDrawable = gLContext.getGLDrawable();
/* 115 */       GLCapabilitiesImmutable gLCapabilitiesImmutable = gLDrawable.getRequestedGLCapabilities();
/* 116 */       GLCapabilities gLCapabilities = (GLCapabilities)gLCapabilitiesImmutable.cloneMutable();
/* 117 */       gLCapabilities.setFBO(true);
/* 118 */       gLCapabilities.setDoubleBuffered(false);
/* 119 */       if (!this.useAlpha) {
/* 120 */         gLCapabilities.setAlphaBits(0);
/*     */       }
/* 122 */       GLDrawableFactory gLDrawableFactory = GLDrawableFactory.getFactory(gLCapabilities.getGLProfile());
/*     */ 
/*     */       
/* 125 */       if (bool) {
/*     */         
/* 127 */         this.fboWidth = arrayOfInt[0];
/* 128 */         this.fboHeight = arrayOfInt[1];
/*     */       } 
/* 130 */       this.fboGLAD = (GLOffscreenAutoDrawable.FBO)gLDrawableFactory.createOffscreenAutoDrawable(gLDrawable
/* 131 */           .getNativeSurface().getGraphicsConfiguration().getScreen().getDevice(), (GLCapabilitiesImmutable)gLCapabilities, null, this.fboWidth, this.fboHeight);
/*     */       
/* 133 */       this.fboWidth = 0;
/* 134 */       this.fboHeight = 0;
/* 135 */       this.fboGLAD.setSharedContext(gLContext);
/* 136 */       this.fboGLAD.setTextureUnit(imageSequence.getTextureUnit());
/* 137 */       this.fboGLAD.addGLEventListener(this.glel);
/* 138 */       this.fboGLAD.display();
/*     */       
/* 140 */       FBObject.TextureAttachment textureAttachment = this.fboGLAD.getColorbuffer(1028).getTextureAttachment();
/*     */ 
/*     */ 
/*     */       
/* 144 */       Texture texture = new Texture(textureAttachment.getName(), false, imageSequence.getTextureTarget(), this.fboGLAD.getSurfaceWidth(), this.fboGLAD.getSurfaceHeight(), this.fboGLAD.getSurfaceWidth(), this.fboGLAD.getSurfaceHeight(), false);
/*     */       
/* 146 */       imageSequence.addFrame((GL)paramGL2ES2, texture);
/* 147 */       markStateDirty();
/* 148 */     } else if (0 != this.fboWidth * this.fboHeight) {
/* 149 */       this.fboGLAD.setSurfaceSize(this.fboWidth, this.fboHeight);
/* 150 */       this.fboWidth = 0;
/* 151 */       this.fboHeight = 0;
/* 152 */       markStateDirty();
/* 153 */     } else if (bool && (this.fboGLAD.getSurfaceWidth() != arrayOfInt[0] || this.fboGLAD.getSurfaceHeight() != arrayOfInt[1])) {
/*     */       
/* 155 */       ImageSequence imageSequence = (ImageSequence)this.texSeq;
/*     */       
/* 157 */       this.fboGLAD.setSurfaceSize(arrayOfInt[0], arrayOfInt[1]);
/* 158 */       this.fboGLAD.display();
/*     */       
/* 160 */       imageSequence.destroy((GL)paramGL2ES2);
/* 161 */       FBObject.TextureAttachment textureAttachment = this.fboGLAD.getColorbuffer(1028).getTextureAttachment();
/*     */ 
/*     */ 
/*     */       
/* 165 */       Texture texture = new Texture(textureAttachment.getName(), false, imageSequence.getTextureTarget(), this.fboGLAD.getSurfaceWidth(), this.fboGLAD.getSurfaceHeight(), this.fboGLAD.getSurfaceWidth(), this.fboGLAD.getSurfaceHeight(), false);
/*     */       
/* 167 */       imageSequence.addFrame((GL)paramGL2ES2, texture);
/* 168 */       this.fboWidth = 0;
/* 169 */       this.fboHeight = 0;
/* 170 */       markStateDirty();
/* 171 */     } else if (this.animateGLEL) {
/* 172 */       this.fboGLAD.display();
/*     */     } 
/*     */     
/* 175 */     super.draw(paramGL2ES2, paramRegionRenderer, paramArrayOfint);
/*     */     
/* 177 */     if (this.animateGLEL)
/* 178 */       markStateDirty(); 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/shapes/GLButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */