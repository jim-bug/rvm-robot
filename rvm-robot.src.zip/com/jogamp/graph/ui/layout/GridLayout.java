/*     */ package com.jogamp.graph.ui.layout;
/*     */ 
/*     */ import com.jogamp.graph.ui.Group;
/*     */ import com.jogamp.graph.ui.Shape;
/*     */ import com.jogamp.opengl.math.FloatUtil;
/*     */ import com.jogamp.opengl.math.Vec3f;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import com.jogamp.opengl.util.PMVMatrix;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GridLayout
/*     */   implements Group.Layout
/*     */ {
/*     */   private final Order order;
/*     */   private final int col_limit;
/*     */   private final int row_limit;
/*     */   private final float cellWidth;
/*     */   private final float cellHeight;
/*     */   private final Alignment alignment;
/*     */   private final Gap gap;
/*     */   private int row_count;
/*     */   private int col_count;
/*     */   private static final boolean TRACE_LAYOUT = false;
/*     */   
/*     */   public enum Order
/*     */   {
/*  53 */     COLUMN,
/*     */     
/*  55 */     ROW;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GridLayout(int paramInt, float paramFloat1, float paramFloat2, Alignment paramAlignment) {
/*  75 */     this(paramAlignment, Math.max(1, paramInt), -1, paramFloat1, paramFloat2, new Gap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GridLayout(int paramInt, float paramFloat1, float paramFloat2, Alignment paramAlignment, Gap paramGap) {
/*  87 */     this(paramAlignment, Math.max(1, paramInt), -1, paramFloat1, paramFloat2, paramGap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GridLayout(float paramFloat1, float paramFloat2, Alignment paramAlignment, Gap paramGap, int paramInt) {
/*  99 */     this(paramAlignment, -1, Math.max(1, paramInt), paramFloat1, paramFloat2, paramGap);
/*     */   }
/*     */   
/*     */   private GridLayout(Alignment paramAlignment, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, Gap paramGap) {
/* 103 */     this.order = (0 < paramInt1) ? Order.COLUMN : Order.ROW;
/* 104 */     this.col_limit = paramInt1;
/* 105 */     this.row_limit = paramInt2;
/* 106 */     this.cellWidth = paramFloat1;
/* 107 */     this.cellHeight = paramFloat2;
/* 108 */     this.alignment = paramAlignment;
/* 109 */     this.gap = paramGap;
/* 110 */     this.row_count = 0;
/* 111 */     this.col_count = 0;
/*     */   }
/*     */   
/* 114 */   public Order getOrder() { return this.order; }
/* 115 */   public int getColumnCount() { return this.col_count; }
/* 116 */   public int getRowCount() { return this.row_count; } public Gap getGap() {
/* 117 */     return this.gap;
/*     */   }
/*     */   
/*     */   public void layout(Group paramGroup, AABBox paramAABBox, PMVMatrix paramPMVMatrix) {
/* 121 */     Vec3f vec3f = new Vec3f();
/* 122 */     boolean bool1 = !FloatUtil.isZero(this.cellWidth) ? true : false;
/* 123 */     boolean bool2 = !FloatUtil.isZero(this.cellHeight) ? true : false;
/* 124 */     boolean bool3 = (bool1 && this.alignment.isSet(Alignment.Bit.Center)) ? true : false;
/* 125 */     boolean bool4 = (bool2 && this.alignment.isSet(Alignment.Bit.Center)) ? true : false;
/* 126 */     boolean bool5 = (this.alignment.isSet(Alignment.Bit.Fill) && (bool1 || bool2)) ? true : false;
/* 127 */     List<Shape> list = paramGroup.getShapes();
/* 128 */     if (Order.COLUMN == this.order) {
/* 129 */       this.row_count = (int)Math.ceil(list.size() / this.col_limit);
/* 130 */       this.col_count = this.col_limit;
/*     */     } else {
/* 132 */       this.row_count = this.row_limit;
/* 133 */       this.col_count = (int)Math.ceil(list.size() / this.row_limit);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 138 */     byte b1 = 0, b2 = 0;
/* 139 */     float f1 = 0.0F, f2 = 0.0F;
/* 140 */     float f3 = -3.4028235E38F, f4 = -3.4028235E38F;
/* 141 */     AABBox[] arrayOfAABBox = new AABBox[list.size()];
/* 142 */     float[] arrayOfFloat = new float[this.col_count * this.row_count];
/*     */     
/*     */     byte b3;
/* 145 */     for (b3 = 0; b3 < list.size(); b3++) {
/* 146 */       float f5; Shape shape = list.get(b3);
/*     */       
/* 148 */       paramPMVMatrix.glPushMatrix();
/* 149 */       shape.setTransform(paramPMVMatrix);
/*     */       
/* 151 */       AABBox aABBox = shape.getBounds();
/* 152 */       arrayOfAABBox[b3] = aABBox.transformMv(paramPMVMatrix, new AABBox());
/*     */       
/* 154 */       paramPMVMatrix.glPopMatrix();
/* 155 */       aABBox = arrayOfAABBox[b3];
/*     */ 
/*     */       
/* 158 */       if (bool5) {
/*     */         
/* 160 */         float f12 = aABBox.getWidth();
/* 161 */         float f13 = aABBox.getHeight();
/* 162 */         float f14 = bool1 ? this.cellWidth : f12;
/* 163 */         float f15 = bool2 ? this.cellHeight : f13;
/* 164 */         float f16 = f14 / f12;
/* 165 */         float f17 = f15 / f13;
/* 166 */         f5 = (f16 < f17) ? f16 : f17;
/*     */       } else {
/* 168 */         f5 = 1.0F;
/*     */       } 
/* 170 */       float f6 = f5 * aABBox.getWidth();
/* 171 */       float f7 = f5 * aABBox.getHeight();
/* 172 */       float f8 = bool1 ? this.cellWidth : f6;
/* 173 */       float f9 = bool2 ? this.cellHeight : f7;
/*     */ 
/*     */       
/* 176 */       float f10 = f2 + f9;
/* 177 */       float f11 = f1 + f8;
/* 178 */       f4 = Math.max(f4, f10);
/* 179 */       f3 = Math.max(f3, f11);
/* 180 */       arrayOfFloat[this.col_count * b2 + b1] = f10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 186 */       if (b3 + 1 < list.size()) {
/* 187 */         if (Order.COLUMN == this.order) {
/* 188 */           if (b1 + 1 == this.col_count) {
/* 189 */             b1 = 0;
/* 190 */             b2++;
/* 191 */             f1 = 0.0F;
/* 192 */             f2 += f9 + this.gap.height();
/*     */           } else {
/* 194 */             b1++;
/* 195 */             f1 += f8 + this.gap.width();
/*     */           }
/*     */         
/* 198 */         } else if (b2 + 1 == this.row_count) {
/* 199 */           b2 = 0;
/* 200 */           b1++;
/* 201 */           f2 = 0.0F;
/* 202 */           f1 += f8 + this.gap.width();
/*     */         } else {
/* 204 */           b2++;
/* 205 */           f2 += f9 + this.gap.height();
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     b2 = 0; b1 = 0;
/* 216 */     f1 = 0.0F; f2 = 0.0F;
/* 217 */     for (b3 = 0; b3 < list.size(); b3++) {
/* 218 */       float f6; Shape shape = list.get(b3);
/* 219 */       AABBox aABBox1 = arrayOfAABBox[b3];
/* 220 */       float f5 = aABBox1.getCenter().z();
/* 221 */       Vec3f vec3f1 = new Vec3f();
/*     */ 
/*     */       
/* 224 */       AABBox aABBox2 = shape.getBounds();
/* 225 */       if (!vec3f1.set(aABBox2.getLow().x(), aABBox2.getLow().y(), 0.0F).min(vec3f).isZero()) {
/*     */         
/* 227 */         Vec3f vec3f2 = shape.getScale();
/* 228 */         vec3f1.scale(-1.0F * vec3f2.x(), -1.0F * vec3f2.y(), 0.0F);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       float f7 = 0.0F, f8 = 0.0F;
/* 240 */       if (bool5) {
/*     */         
/* 242 */         float f15 = aABBox1.getWidth();
/* 243 */         float f16 = aABBox1.getHeight();
/* 244 */         float f17 = bool1 ? this.cellWidth : f15;
/* 245 */         float f18 = bool2 ? this.cellHeight : f16;
/* 246 */         float f19 = f17 / f15;
/* 247 */         float f20 = f18 / f16;
/* 248 */         f6 = (f19 < f20) ? f19 : f20;
/* 249 */         f7 += f15 * (f19 - f6) * 0.5F;
/* 250 */         f8 += f16 * (f20 - f6) * 0.5F;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 255 */         f6 = 1.0F;
/*     */       } 
/* 257 */       float f9 = f6 * aABBox1.getWidth();
/* 258 */       float f10 = f6 * aABBox1.getHeight();
/* 259 */       float f11 = bool1 ? this.cellWidth : f9;
/* 260 */       float f12 = bool2 ? this.cellHeight : f10;
/*     */       
/* 262 */       f2 = f4 - arrayOfFloat[this.col_count * b2 + b1];
/*     */       
/* 264 */       if (bool3) {
/* 265 */         f7 += 0.5F * (f11 - f9);
/*     */       }
/* 267 */       if (bool4) {
/* 268 */         f8 += 0.5F * (f12 - f10);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 275 */       float f13 = f1 + f7;
/* 276 */       float f14 = f2 + f8;
/* 277 */       shape.moveTo(f13, f14, 0.0F);
/* 278 */       shape.move(vec3f1.scale(f6));
/*     */ 
/*     */       
/* 281 */       paramAABBox.resize(f1, f2, f5);
/* 282 */       paramAABBox.resize(f13 + f11, f14 + f12, f5);
/*     */       
/* 284 */       shape.scale(f6, f6, 1.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 291 */       if (b3 + 1 < list.size())
/*     */       {
/* 293 */         if (Order.COLUMN == this.order) {
/* 294 */           if (b1 + 1 == this.col_count) {
/* 295 */             b1 = 0;
/* 296 */             b2++;
/* 297 */             f1 = 0.0F;
/*     */           } else {
/* 299 */             b1++;
/* 300 */             f1 += f11 + this.gap.width();
/*     */           }
/*     */         
/* 303 */         } else if (b2 + 1 == this.row_count) {
/* 304 */           b2 = 0;
/* 305 */           b1++;
/* 306 */           f2 = 0.0F;
/* 307 */           f1 += f11 + this.gap.width();
/*     */         } else {
/* 309 */           b2++;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 321 */     return "Grid[" + this.col_count + "x" + this.row_count + ", " + this.order + ", cell[" + this.cellWidth + " x " + this.cellHeight + ", a " + this.alignment + "], " + this.gap + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/layout/GridLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */