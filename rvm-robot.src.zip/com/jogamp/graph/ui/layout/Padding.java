/*     */ package com.jogamp.graph.ui.layout;
/*     */ 
/*     */ import com.jogamp.opengl.math.FloatUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Padding
/*     */ {
/*     */   public final float top;
/*     */   public final float right;
/*     */   public final float bottom;
/*     */   public final float left;
/*     */   
/*     */   public Padding() {
/*  51 */     this.top = 0.0F; this.right = 0.0F; this.bottom = 0.0F; this.left = 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Padding(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  62 */     this.top = paramFloat1; this.right = paramFloat2; this.bottom = paramFloat3; this.left = paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Padding(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  72 */     this.top = paramFloat1; this.right = paramFloat2; this.bottom = paramFloat3; this.left = paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Padding(float paramFloat1, float paramFloat2) {
/*  81 */     this.top = paramFloat1; this.right = paramFloat2; this.bottom = paramFloat1; this.left = paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Padding(float paramFloat) {
/*  89 */     this.top = paramFloat; this.right = paramFloat; this.bottom = paramFloat; this.left = paramFloat;
/*     */   }
/*     */   
/*     */   public float width() {
/*  93 */     return this.left + this.right;
/*     */   }
/*     */   public float height() {
/*  96 */     return this.bottom + this.top;
/*     */   } public boolean zeroSumWidth() {
/*  98 */     return FloatUtil.isZero(width());
/*     */   } public boolean zeroSumHeight() {
/* 100 */     return FloatUtil.isZero(height());
/*     */   } public boolean zeroSumSize() {
/* 102 */     return (zeroSumWidth() && zeroSumHeight());
/*     */   }
/*     */   public String toString() {
/* 105 */     return "Padding[t " + this.top + ", r " + this.right + ", b " + this.bottom + ", l " + this.left + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/layout/Padding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */