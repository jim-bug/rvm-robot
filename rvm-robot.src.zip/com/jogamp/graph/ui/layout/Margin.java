/*     */ package com.jogamp.graph.ui.layout;
/*     */ 
/*     */ import com.jogamp.opengl.math.FloatUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Margin
/*     */ {
/*     */   public static final float CENTER = NaNF;
/*     */   public final float top;
/*     */   public final float right;
/*     */   public final float bottom;
/*     */   public final float left;
/*     */   private final int bits;
/*     */   private static final int CENTER_HORIZ = 1;
/*     */   private static final int CENTER_VERT = 2;
/*     */   
/*     */   private static int getBits(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  57 */     int i = 0;
/*  58 */     if (FloatUtil.isEqual(Float.NaN, paramFloat4) && FloatUtil.isEqual(Float.NaN, paramFloat2)) {
/*  59 */       i |= 0x1;
/*     */     }
/*  61 */     if (FloatUtil.isEqual(Float.NaN, paramFloat1) && FloatUtil.isEqual(Float.NaN, paramFloat3)) {
/*  62 */       i |= 0x2;
/*     */     }
/*  64 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Margin() {
/*  71 */     this.top = 0.0F; this.right = 0.0F; this.bottom = 0.0F; this.left = 0.0F; this.bits = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Margin(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  82 */     this.bits = getBits(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*  83 */     if (isCenteredVert()) {
/*  84 */       this.top = 0.0F;
/*  85 */       this.bottom = 0.0F;
/*     */     } else {
/*  87 */       this.top = paramFloat1;
/*  88 */       this.bottom = paramFloat3;
/*     */     } 
/*  90 */     if (isCenteredHoriz()) {
/*  91 */       this.right = 0.0F;
/*  92 */       this.left = 0.0F;
/*     */     } else {
/*  94 */       this.right = paramFloat2;
/*  95 */       this.left = paramFloat4;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Margin(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 106 */     this.bits = getBits(paramFloat1, paramFloat2, paramFloat3, paramFloat2);
/* 107 */     if (isCenteredVert()) {
/* 108 */       this.top = 0.0F;
/* 109 */       this.bottom = 0.0F;
/*     */     } else {
/* 111 */       this.top = paramFloat1;
/* 112 */       this.bottom = paramFloat3;
/*     */     } 
/* 114 */     if (isCenteredHoriz()) {
/* 115 */       this.right = 0.0F;
/* 116 */       this.left = 0.0F;
/*     */     } else {
/* 118 */       this.right = paramFloat2;
/* 119 */       this.left = paramFloat2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Margin(float paramFloat1, float paramFloat2) {
/* 129 */     this.bits = getBits(paramFloat1, paramFloat2, paramFloat1, paramFloat2);
/* 130 */     if (isCenteredVert()) {
/* 131 */       this.top = 0.0F;
/* 132 */       this.bottom = 0.0F;
/*     */     } else {
/* 134 */       this.top = paramFloat1;
/* 135 */       this.bottom = paramFloat1;
/*     */     } 
/* 137 */     if (isCenteredHoriz()) {
/* 138 */       this.right = 0.0F;
/* 139 */       this.left = 0.0F;
/*     */     } else {
/* 141 */       this.right = paramFloat2;
/* 142 */       this.left = paramFloat2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Margin(float paramFloat) {
/* 151 */     this.bits = getBits(paramFloat, paramFloat, paramFloat, paramFloat);
/* 152 */     if (isCenteredVert()) {
/* 153 */       this.top = 0.0F;
/* 154 */       this.bottom = 0.0F;
/*     */     } else {
/* 156 */       this.top = paramFloat;
/* 157 */       this.bottom = paramFloat;
/*     */     } 
/* 159 */     if (isCenteredHoriz()) {
/* 160 */       this.right = 0.0F;
/* 161 */       this.left = 0.0F;
/*     */     } else {
/* 163 */       this.right = paramFloat;
/* 164 */       this.left = paramFloat;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCenteredHoriz() {
/* 170 */     return (0 != (0x1 & this.bits));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCenteredVert() {
/* 175 */     return (0 != (0x2 & this.bits));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCentered() {
/* 180 */     return (0 != (0x3 & this.bits));
/*     */   }
/*     */   
/*     */   public float width() {
/* 184 */     return this.left + this.right;
/*     */   }
/*     */   public float height() {
/* 187 */     return this.bottom + this.top;
/*     */   } public boolean zeroSumWidth() {
/* 189 */     return FloatUtil.isZero(width());
/*     */   } public boolean zeroSumHeight() {
/* 191 */     return FloatUtil.isZero(height());
/*     */   } public boolean zeroSumSize() {
/* 193 */     return (zeroSumWidth() && zeroSumHeight());
/*     */   }
/*     */   public String toString() {
/* 196 */     return "Margin[t " + this.top + ", r " + this.right + ", b " + this.bottom + ", l " + this.left + ", ctr[h " + isCenteredHoriz() + ", v " + isCenteredVert() + "]]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/layout/Margin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */