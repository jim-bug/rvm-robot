/*     */ package com.jogamp.graph.ui.layout;
/*     */ 
/*     */ import com.jogamp.graph.ui.Group;
/*     */ import com.jogamp.graph.ui.Shape;
/*     */ import com.jogamp.opengl.math.FloatUtil;
/*     */ import com.jogamp.opengl.math.geom.AABBox;
/*     */ import com.jogamp.opengl.util.PMVMatrix;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoxLayout
/*     */   implements Group.Layout
/*     */ {
/*     */   private final float cellWidth;
/*     */   private final float cellHeight;
/*     */   private final Margin margin;
/*     */   private final Padding padding;
/*     */   private static final boolean TRACE_LAYOUT = false;
/*     */   
/*     */   public BoxLayout(Padding paramPadding) {
/*  55 */     this(0.0F, 0.0F, new Margin(), paramPadding);
/*     */   }
/*     */   public BoxLayout(float paramFloat1, float paramFloat2, Margin paramMargin) {
/*  58 */     this(paramFloat1, paramFloat2, paramMargin, new Padding());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxLayout(float paramFloat1, float paramFloat2, Margin paramMargin, Padding paramPadding) {
/*  69 */     this.cellWidth = Math.max(0.0F, paramFloat1);
/*  70 */     this.cellHeight = Math.max(0.0F, paramFloat2);
/*  71 */     this.margin = paramMargin;
/*  72 */     this.padding = paramPadding;
/*     */   }
/*     */   
/*  75 */   public Padding getPadding() { return this.padding; } public Margin getMargin() {
/*  76 */     return this.margin;
/*     */   }
/*     */   
/*     */   public void layout(Group paramGroup, AABBox paramAABBox, PMVMatrix paramPMVMatrix) {
/*  80 */     boolean bool1 = !FloatUtil.isZero(this.cellWidth) ? true : false;
/*  81 */     boolean bool2 = !FloatUtil.isZero(this.cellHeight) ? true : false;
/*  82 */     List<Shape> list = paramGroup.getShapes();
/*  83 */     AABBox aABBox = new AABBox();
/*  84 */     for (byte b = 0; b < list.size(); b++) {
/*  85 */       float f7, f8; Shape shape = list.get(b);
/*     */ 
/*     */       
/*  88 */       paramPMVMatrix.glPushMatrix();
/*  89 */       shape.setTransform(paramPMVMatrix);
/*  90 */       shape.getBounds().transformMv(paramPMVMatrix, aABBox);
/*  91 */       paramPMVMatrix.glPopMatrix();
/*     */ 
/*     */       
/*  94 */       float f1 = aABBox.getWidth() + this.padding.width();
/*  95 */       float f2 = aABBox.getHeight() + this.padding.height();
/*  96 */       float f3 = bool1 ? this.cellWidth : f1;
/*  97 */       float f4 = bool2 ? this.cellHeight : f2;
/*  98 */       float f5 = this.margin.left;
/*  99 */       float f6 = this.margin.bottom;
/* 100 */       if (!this.margin.isCenteredHoriz() && f1 <= f3) {
/* 101 */         f5 += this.padding.left;
/*     */       }
/* 103 */       if (!this.margin.isCenteredVert() && f2 <= f4) {
/* 104 */         f6 += this.padding.bottom;
/*     */       }
/*     */       
/* 107 */       if (this.margin.isCenteredHoriz()) {
/* 108 */         f7 = 0.5F * (f3 - f1);
/*     */       } else {
/* 110 */         f7 = 0.0F;
/*     */       } 
/* 112 */       if (this.margin.isCenteredVert()) {
/* 113 */         f8 = 0.5F * (f4 - f2);
/*     */       } else {
/* 115 */         f8 = 0.0F;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 121 */       shape.move(f5 + f7, f6 + f8, 0.0F);
/* 122 */       shape.move(aABBox.getLow().mul(-1.0F));
/*     */       
/* 124 */       paramAABBox.resize(f5 + aABBox.getWidth() + this.padding.right, f6 + aABBox.getHeight() + this.padding.top, 0.0F);
/* 125 */       paramAABBox.resize(f5 - this.padding.left, f6 - this.padding.bottom, 0.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return "Box[cell[" + this.cellWidth + " x " + this.cellHeight + "], " + this.margin + ", " + this.padding + "]";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/layout/BoxLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */