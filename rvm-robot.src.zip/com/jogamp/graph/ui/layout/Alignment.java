/*     */ package com.jogamp.graph.ui.layout;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Alignment
/*     */ {
/*  37 */   public static final Alignment None = new Alignment();
/*     */   
/*  39 */   public static final Alignment Center = new Alignment(Bit.Center);
/*     */   
/*  41 */   public static final Alignment Fill = new Alignment(Bit.Fill.value);
/*     */   
/*  43 */   public static final Alignment FillCenter = new Alignment(Bit.Fill.value | Bit.Center.value);
/*     */   public final int mask;
/*     */   
/*     */   public enum Bit {
/*  47 */     Left(1),
/*     */ 
/*     */     
/*  50 */     Right(2),
/*     */ 
/*     */     
/*  53 */     Bottom(4),
/*     */ 
/*     */     
/*  56 */     Top(256),
/*     */ 
/*     */     
/*  59 */     Center(512),
/*     */ 
/*     */     
/*  62 */     Fill(32768); public final int value;
/*     */     Bit(int param1Int1) {
/*  64 */       this.value = param1Int1;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getBits(List<Bit> paramList) {
/*  70 */     int i = 0;
/*  71 */     for (Bit bit : paramList) {
/*  72 */       i |= bit.value;
/*     */     }
/*  74 */     return i;
/*     */   }
/*     */   public Alignment(List<Bit> paramList) {
/*  77 */     this.mask = getBits(paramList);
/*     */   }
/*     */   public Alignment(Bit paramBit) {
/*  80 */     this.mask = paramBit.value;
/*     */   }
/*     */   public Alignment(int paramInt) {
/*  83 */     this.mask = paramInt;
/*     */   }
/*     */   public Alignment() {
/*  86 */     this.mask = 0;
/*     */   }
/*     */   
/*  89 */   public boolean isSet(Bit paramBit) { return (paramBit.value == (this.mask & paramBit.value)); }
/*  90 */   public boolean isSet(List<Bit> paramList) { int i = getBits(paramList); return (i == (this.mask & i)); } public boolean isSet(int paramInt) {
/*  91 */     return (paramInt == (this.mask & paramInt));
/*     */   }
/*     */   
/*     */   public String toString() {
/*  95 */     byte b = 0;
/*  96 */     StringBuilder stringBuilder = new StringBuilder();
/*  97 */     for (Bit bit : Bit.values()) {
/*  98 */       if (isSet(bit)) {
/*  99 */         if (0 < b) stringBuilder.append(", "); 
/* 100 */         stringBuilder.append(bit.name()); b++;
/*     */       } 
/*     */     } 
/* 103 */     if (0 == b) {
/* 104 */       stringBuilder.append("None");
/* 105 */     } else if (1 < b) {
/* 106 */       stringBuilder.insert(0, "[");
/* 107 */       stringBuilder.append("]");
/*     */     } 
/* 109 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 114 */     if (this == paramObject) {
/* 115 */       return true;
/*     */     }
/* 117 */     return (paramObject instanceof Alignment && this.mask == ((Alignment)paramObject).mask);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/layout/Alignment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */