/*    */ package com.jogamp.graph.ui.layout;
/*    */ 
/*    */ import com.jogamp.opengl.math.FloatUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Gap
/*    */ {
/*    */   public final float row;
/*    */   public final float column;
/*    */   
/*    */   public Gap() {
/* 47 */     this.row = 0.0F; this.column = 0.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Gap(float paramFloat1, float paramFloat2) {
/* 56 */     this.row = paramFloat1; this.column = paramFloat2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Gap(float paramFloat) {
/* 64 */     this.row = paramFloat; this.column = paramFloat;
/*    */   }
/*    */   
/*    */   public float width() {
/* 68 */     return this.column;
/*    */   }
/*    */   public float height() {
/* 71 */     return this.row;
/*    */   } public boolean zeroSumWidth() {
/* 73 */     return FloatUtil.isZero(width());
/*    */   } public boolean zeroSumHeight() {
/* 75 */     return FloatUtil.isZero(height());
/*    */   } public boolean zeroSumSize() {
/* 77 */     return (zeroSumWidth() && zeroSumHeight());
/*    */   }
/*    */   public String toString() {
/* 80 */     return "Gap[r " + this.row + ", c " + this.column + "]";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/graph/ui/layout/Gap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */