/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import com.jogamp.gluegen.cgram.types.AliasedSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.TypeComparator;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantDefinition
/*     */   extends AliasedSymbol.AliasedSymbolImpl
/*     */   implements TypeComparator.AliasedSemanticSymbol, ASTLocusTag.ASTLocusTagProvider
/*     */ {
/*     */   public static final long UNSIGNED_INT_MAX_VALUE = 4294967295L;
/*  56 */   public static final BigInteger UNSIGNED_LONG_MAX_VALUE = new BigInteger("ffffffffffffffff", 16);
/*     */   
/*     */   private final boolean relaxedEqSem;
/*     */   
/*     */   private final String nativeExpr;
/*     */   
/*     */   private final CNumber number;
/*     */   
/*     */   private final boolean isEnum;
/*     */   
/*     */   private final String enumName;
/*     */   
/*     */   private final ASTLocusTag astLocus;
/*     */ 
/*     */   
/*     */   public static class CNumber
/*     */   {
/*     */     public final boolean isInteger;
/*     */     
/*     */     public final boolean isLong;
/*     */     public final boolean isUnsigned;
/*     */     public final long i;
/*     */     public final boolean isDouble;
/*     */     public final double f;
/*     */     
/*     */     public CNumber(boolean param1Boolean1, boolean param1Boolean2, long param1Long) {
/*  82 */       this.isInteger = true;
/*  83 */       this.isLong = param1Boolean1;
/*  84 */       this.isUnsigned = param1Boolean2;
/*  85 */       this.i = param1Long;
/*  86 */       this.isDouble = false;
/*  87 */       this.f = 0.0D;
/*     */     }
/*     */     
/*     */     public CNumber(boolean param1Boolean, double param1Double) {
/*  91 */       this.isInteger = false;
/*  92 */       this.isLong = false;
/*  93 */       this.isUnsigned = false;
/*  94 */       this.i = 0L;
/*  95 */       this.isDouble = param1Boolean;
/*  96 */       this.f = param1Double;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 100 */       return this.isInteger ? Long.valueOf(this.i).hashCode() : Double.valueOf(this.f).hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 104 */       if (param1Object == this)
/* 105 */         return true; 
/* 106 */       if (!(param1Object instanceof CNumber)) {
/* 107 */         return false;
/*     */       }
/* 109 */       CNumber cNumber = (CNumber)param1Object;
/* 110 */       return (this.isInteger == cNumber.isInteger && (this.isInteger ? (this.i == cNumber.i) : (this.f == cNumber.f)));
/*     */     }
/*     */     
/*     */     public final String toJavaString() {
/* 114 */       if (this.isInteger) {
/* 115 */         if (this.i >= 0L || this.isUnsigned) {
/* 116 */           if (this.isLong) {
/* 117 */             return "0x" + Long.toHexString(this.i) + "L";
/*     */           }
/* 119 */           return "0x" + Integer.toHexString((int)this.i);
/*     */         } 
/*     */         
/* 122 */         if (this.isLong) {
/* 123 */           return String.valueOf(this.i) + "L";
/*     */         }
/* 125 */         return String.valueOf((int)this.i);
/*     */       } 
/*     */ 
/*     */       
/* 129 */       return String.valueOf(this.f) + (!this.isDouble ? "f" : "");
/*     */     }
/*     */ 
/*     */     
/*     */     public final String toString() {
/* 134 */       StringBuilder stringBuilder = new StringBuilder();
/* 135 */       stringBuilder.append("[");
/* 136 */       if (this.isInteger) {
/* 137 */         if (this.isUnsigned) {
/* 138 */           stringBuilder.append("unsigned ");
/*     */         }
/* 140 */         if (this.isLong) {
/* 141 */           stringBuilder.append("long: ");
/*     */         } else {
/* 143 */           stringBuilder.append("int: ");
/*     */         } 
/* 145 */         stringBuilder.append(this.i);
/*     */       } else {
/* 147 */         if (this.isDouble) {
/* 148 */           stringBuilder.append("double: ");
/*     */         } else {
/* 150 */           stringBuilder.append("float: ");
/*     */         } 
/* 152 */         stringBuilder.append(this.f);
/*     */       } 
/* 154 */       stringBuilder.append("]");
/* 155 */       return stringBuilder.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class JavaExpr
/*     */   {
/*     */     public final String javaExpression;
/*     */     
/*     */     public final ConstantDefinition.CNumber resultType;
/*     */     
/*     */     public final Number resultJavaType;
/*     */     public final String resultJavaTypeName;
/*     */     
/*     */     public JavaExpr(String param1String, ConstantDefinition.CNumber param1CNumber) {
/* 170 */       this.javaExpression = param1String;
/* 171 */       this.resultType = param1CNumber;
/* 172 */       if (param1CNumber.isDouble) {
/* 173 */         this.resultJavaTypeName = "double";
/* 174 */         this.resultJavaType = Double.valueOf(param1CNumber.f);
/* 175 */       } else if (!param1CNumber.isInteger) {
/* 176 */         this.resultJavaTypeName = "float";
/* 177 */         this.resultJavaType = Float.valueOf(Double.valueOf(param1CNumber.f).floatValue());
/* 178 */       } else if (param1CNumber.isLong) {
/* 179 */         this.resultJavaTypeName = "long";
/* 180 */         this.resultJavaType = Long.valueOf(param1CNumber.i);
/*     */       } else {
/* 182 */         this.resultJavaTypeName = "int";
/* 183 */         this.resultJavaType = Integer.valueOf(Long.valueOf(param1CNumber.i).intValue());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static JavaExpr compute(ConstantDefinition param1ConstantDefinition, Map<String, JavaExpr> param1Map) {
/* 193 */       boolean bool = GlueGen.debug();
/* 194 */       if (bool) {
/* 195 */         System.err.println("ConstJavaExpr.create: " + param1ConstantDefinition);
/*     */       }
/* 197 */       if (param1ConstantDefinition.hasNumber()) {
/*     */         
/* 199 */         if (bool) {
/* 200 */           System.err.printf("V %s (isCNumber)%n", new Object[] { param1ConstantDefinition });
/*     */         }
/* 202 */         return new JavaExpr(param1ConstantDefinition.getNumber().toJavaString(), param1ConstantDefinition.getNumber());
/*     */       } 
/* 204 */       StringBuilder stringBuilder = new StringBuilder();
/* 205 */       String str1 = param1ConstantDefinition.getNativeExpr();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 210 */       ConstantDefinition.CNumber cNumber = null;
/* 211 */       Matcher matcher = ConstantDefinition.patternCPPOperand.matcher(str1);
/* 212 */       int i = 0;
/* 213 */       int j = 0;
/* 214 */       while (matcher.find()) {
/* 215 */         int k = matcher.start();
/* 216 */         if (k > i) {
/* 217 */           String str3 = str1.substring(i, k).trim();
/* 218 */           if (str3.length() > 0) {
/* 219 */             if (bool) {
/* 220 */               System.err.printf("V %03d-%03d: %s%n", new Object[] { Integer.valueOf(i), Integer.valueOf(k), str3 });
/*     */             }
/* 222 */             cNumber = processValue(param1ConstantDefinition, str3, param1Map, cNumber, stringBuilder);
/* 223 */             stringBuilder.append(" ");
/*     */           } 
/*     */         } 
/* 226 */         j = matcher.end();
/* 227 */         String str = str1.substring(k, j);
/* 228 */         if (bool) {
/* 229 */           System.err.printf("O %03d-%03d: %s%n", new Object[] { Integer.valueOf(k), Integer.valueOf(j), str });
/*     */         }
/* 231 */         stringBuilder.append(str).append(" ");
/* 232 */         i = j;
/*     */       } 
/* 234 */       if (j < str1.length()) {
/*     */         
/* 236 */         String str = str1.substring(j).trim();
/* 237 */         if (str.length() > 0) {
/* 238 */           if (bool) {
/* 239 */             System.err.printf("V %03d %03d-%03d: %s (tail)%n", new Object[] { Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(str1.length()), str });
/*     */           }
/* 241 */           cNumber = processValue(param1ConstantDefinition, str, param1Map, cNumber, stringBuilder);
/*     */         } 
/*     */       } 
/* 244 */       String str2 = stringBuilder.toString().trim();
/* 245 */       if (null == cNumber) {
/* 246 */         throw new GlueGenException("Cannot emit const \"" + param1ConstantDefinition.getName() + "\": value \"" + str1 + "\", parsed \"" + str2 + "\" does not contain a constant number", param1ConstantDefinition
/* 247 */             .getASTLocusTag());
/*     */       }
/* 249 */       return new JavaExpr(str2, cNumber);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static ConstantDefinition.CNumber processValue(ConstantDefinition param1ConstantDefinition, String param1String, Map<String, JavaExpr> param1Map, ConstantDefinition.CNumber param1CNumber, StringBuilder param1StringBuilder) {
/* 256 */       ConstantDefinition.CNumber cNumber = getANumber(param1ConstantDefinition, param1String);
/* 257 */       if (null != cNumber) {
/* 258 */         param1CNumber = evalType(param1CNumber, cNumber);
/* 259 */         param1StringBuilder.append(cNumber.toJavaString());
/*     */       } else {
/*     */         
/* 262 */         JavaExpr javaExpr = param1Map.get(param1String);
/* 263 */         if (null != javaExpr) {
/* 264 */           param1CNumber = evalType(param1CNumber, javaExpr.resultType);
/*     */         }
/* 266 */         param1StringBuilder.append(param1String);
/*     */       } 
/* 268 */       return param1CNumber;
/*     */     }
/*     */     private static ConstantDefinition.CNumber getANumber(ConstantDefinition param1ConstantDefinition, String param1String) {
/*     */       try {
/* 272 */         ConstantDefinition.CNumber cNumber = ConstantDefinition.decodeANumber(param1String);
/* 273 */         if (null != cNumber) {
/* 274 */           return cNumber;
/*     */         }
/* 276 */       } catch (Throwable throwable) {
/* 277 */         String str = "Cannot emit const \"" + param1ConstantDefinition.getName() + "\": value \"" + param1String + "\" cannot be assigned to a int, long, float, or double";
/*     */         
/* 279 */         throw new GlueGenException(str, param1ConstantDefinition.getASTLocusTag(), throwable);
/*     */       } 
/* 281 */       return null;
/*     */     }
/*     */     
/*     */     private static ConstantDefinition.CNumber evalType(ConstantDefinition.CNumber param1CNumber1, ConstantDefinition.CNumber param1CNumber2) {
/* 285 */       if (param1CNumber2.isDouble) {
/* 286 */         return param1CNumber2;
/*     */       }
/* 288 */       if (null != param1CNumber1) {
/* 289 */         if (param1CNumber1.isInteger) {
/* 290 */           if (param1CNumber1.isLong) {
/*     */             
/* 292 */             if (!param1CNumber2.isInteger)
/*     */             {
/* 294 */               return param1CNumber2;
/*     */             }
/* 296 */           } else if (param1CNumber2.isLong || !param1CNumber2.isInteger) {
/*     */             
/* 298 */             return param1CNumber2;
/*     */           } 
/* 300 */         } else if (!param1CNumber1.isInteger && !param1CNumber1.isDouble && 
/* 301 */           param1CNumber2.isDouble) {
/*     */           
/* 303 */           return param1CNumber2;
/*     */         } 
/*     */       } else {
/*     */         
/* 307 */         return param1CNumber2;
/*     */       } 
/* 309 */       return param1CNumber1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantDefinition(String paramString1, String paramString2, CNumber paramCNumber, ASTLocusTag paramASTLocusTag) {
/* 333 */     this(paramString1, paramString2, paramCNumber, false, null, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantDefinition(String paramString1, String paramString2, CNumber paramCNumber, String paramString3, ASTLocusTag paramASTLocusTag) {
/* 349 */     this(paramString1, paramString2, paramCNumber, true, paramString3, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConstantDefinition(String paramString1, String paramString2, CNumber paramCNumber, boolean paramBoolean, String paramString3, ASTLocusTag paramASTLocusTag) {
/* 365 */     super(paramString1);
/* 366 */     this.nativeExpr = paramString2;
/* 367 */     this.relaxedEqSem = TypeConfig.relaxedEqualSemanticsTest();
/* 368 */     if (null != paramCNumber) {
/* 369 */       this.number = paramCNumber;
/*     */     } else {
/*     */       
/* 372 */       CNumber cNumber = decodeIntegerNumber(paramString2);
/* 373 */       if (null != cNumber) {
/* 374 */         this.number = cNumber;
/*     */       } else {
/* 376 */         CNumber cNumber1 = decodeDecimalNumber(paramString2);
/* 377 */         if (null != cNumber1) {
/* 378 */           this.number = cNumber1;
/*     */         } else {
/* 380 */           this.number = null;
/*     */         } 
/*     */       } 
/*     */     } 
/* 384 */     this.isEnum = paramBoolean;
/* 385 */     this.enumName = paramString3;
/* 386 */     this.astLocus = paramASTLocusTag;
/*     */   }
/*     */   
/*     */   public ASTLocusTag getASTLocusTag() {
/* 390 */     return this.astLocus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 397 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 405 */     if (paramObject == this)
/* 406 */       return true; 
/* 407 */     if (!(paramObject instanceof ConstantDefinition)) {
/* 408 */       return false;
/*     */     }
/* 410 */     ConstantDefinition constantDefinition = (ConstantDefinition)paramObject;
/* 411 */     return equals(getName(), constantDefinition.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCodeSemantics() {
/* 418 */     int i = 31 + ((null != getName()) ? getName().hashCode() : 0);
/* 419 */     i = (i << 5) - i + (this.isEnum ? 1 : 0);
/* 420 */     i = (i << 5) - i + ((null != this.enumName) ? this.enumName.hashCode() : 0);
/* 421 */     i = (i << 5) - i + ((null != this.number) ? this.number.hashCode() : 0);
/* 422 */     return (i << 5) - i + ((!this.relaxedEqSem && null != this.nativeExpr) ? this.nativeExpr.hashCode() : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean equalSemantics(TypeComparator.SemanticEqualityOp paramSemanticEqualityOp) {
/* 427 */     if (paramSemanticEqualityOp == this)
/* 428 */       return true; 
/* 429 */     if (!(paramSemanticEqualityOp instanceof ConstantDefinition)) {
/* 430 */       return false;
/*     */     }
/* 432 */     ConstantDefinition constantDefinition = (ConstantDefinition)paramSemanticEqualityOp;
/* 433 */     if (!equals(getName(), constantDefinition.getName()) || this.isEnum != constantDefinition.isEnum || 
/*     */       
/* 435 */       !equals(this.enumName, constantDefinition.enumName)) {
/* 436 */       return false;
/*     */     }
/* 438 */     if (null != this.number) {
/* 439 */       if (this.number.isInteger) {
/* 440 */         return (this.number.i == constantDefinition.number.i);
/*     */       }
/* 442 */       return (this.number.f == constantDefinition.number.f);
/*     */     } 
/*     */ 
/*     */     
/* 446 */     return (this.relaxedEqSem || equals(this.nativeExpr, constantDefinition.nativeExpr));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNativeExpr() {
/* 452 */     return this.nativeExpr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CNumber getNumber() {
/* 458 */     return this.number;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNumber() {
/* 463 */     return (null != this.number);
/*     */   }
/*     */   
/*     */   public String getEnumName() {
/* 467 */     return this.enumName;
/*     */   } public boolean isEnum() {
/* 469 */     return this.isEnum;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 473 */     return "ConstantDefinition [name \"" + getName() + "\", expression \"" + this.nativeExpr + "\", number " + this.number + "], enum[is " + this.isEnum + ", name \"" + this.enumName + "\"]]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean equals(String paramString1, String paramString2) {
/* 480 */     if (paramString1 == null || paramString2 == null) {
/* 481 */       if (paramString1 == null && paramString2 == null) {
/* 482 */         return true;
/*     */       }
/* 484 */       return false;
/*     */     } 
/*     */     
/* 487 */     return paramString1.equals(paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JavaExpr computeJavaExpr(Map<String, JavaExpr> paramMap) {
/* 495 */     return JavaExpr.compute(this, paramMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConstantExpression(String paramString) {
/* 503 */     if (null != paramString && paramString.length() > 0) {
/*     */       
/* 505 */       if (isNumber(paramString)) {
/* 506 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 512 */       String[] arrayOfString = paramString.split("[\\s\\+\\-\\*\\/\\|\\&\\(\\)]|(\\<\\<)|(\\>\\>)|(\\~)");
/* 513 */       byte b = 0;
/* 514 */       for (String str : arrayOfString) {
/* 515 */         if (str.length() > 0 && 
/* 516 */           !isCPPOperand(str))
/*     */         {
/* 518 */           if (isNumber(str)) {
/*     */             
/* 520 */             b++;
/*     */           } else {
/* 522 */             return false;
/*     */           } 
/*     */         }
/*     */       } 
/* 526 */       return (b > 0);
/*     */     } 
/*     */     
/* 529 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isIdentifier(String paramString) {
/* 533 */     boolean bool = false;
/*     */     
/* 535 */     char[] arrayOfChar = paramString.toCharArray();
/*     */     
/* 537 */     for (byte b = 0; b < arrayOfChar.length; b++) {
/* 538 */       char c = arrayOfChar[b];
/* 539 */       if (b == 0) {
/* 540 */         if (Character.isJavaIdentifierStart(c)) {
/* 541 */           bool = true;
/*     */         }
/*     */       }
/* 544 */       else if (!Character.isJavaIdentifierPart(c)) {
/* 545 */         bool = false;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 550 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CNumber decodeANumber(String paramString) {
/* 559 */     CNumber cNumber = decodeIntegerNumber(paramString);
/* 560 */     if (null != cNumber) {
/* 561 */       return cNumber;
/*     */     }
/* 563 */     return decodeDecimalNumber(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CNumber decodeIntegerNumber(String paramString) {
/*     */     boolean bool1;
/*     */     long l;
/* 578 */     if (null == paramString || !isIntegerNumber(paramString)) {
/* 579 */       return null;
/*     */     }
/* 581 */     String str = paramString.trim();
/* 582 */     if (0 == str.length()) {
/* 583 */       return null;
/*     */     }
/* 585 */     if (str.startsWith("+")) {
/* 586 */       str = str.substring(1, str.length()).trim();
/* 587 */       if (0 == str.length()) {
/* 588 */         return null;
/*     */       }
/*     */     } 
/*     */     
/* 592 */     if (str.startsWith("-")) {
/* 593 */       str = str.substring(1, str.length()).trim();
/* 594 */       if (0 == str.length()) {
/* 595 */         return null;
/*     */       }
/* 597 */       bool1 = true;
/*     */     } else {
/* 599 */       bool1 = false;
/*     */     } 
/*     */ 
/*     */     
/* 603 */     boolean bool2 = false;
/* 604 */     boolean bool3 = false;
/* 605 */     int i = str.length() - 2;
/* 606 */     for (int j = str.length() - 1; j >= 0 && j >= i; j--) {
/* 607 */       char c = str.charAt(str.length() - 1);
/* 608 */       if (c == 'u' || c == 'U') {
/* 609 */         str = str.substring(0, str.length() - 1);
/* 610 */         bool2 = true;
/* 611 */       } else if (c == 'l' || c == 'L') {
/* 612 */         str = str.substring(0, str.length() - 1);
/* 613 */         bool3 = true;
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 619 */     if (0 == str.length()) {
/* 620 */       return null;
/*     */     }
/*     */     
/* 623 */     if (bool3 && bool2) {
/* 624 */       l = decodeULong(str, bool1);
/*     */     } else {
/* 626 */       if (bool1) {
/* 627 */         str = "-" + str;
/*     */       }
/* 629 */       l = Long.decode(str).longValue();
/*     */     } 
/* 631 */     boolean bool4 = (bool3 || (!bool2 && (-2147483648L > l || l > 2147483647L)) || (bool2 && l > 4294967295L)) ? true : false;
/*     */ 
/*     */     
/* 634 */     return new CNumber(bool4, bool2, l);
/*     */   }
/*     */   private static long decodeULong(String paramString, boolean paramBoolean) throws NumberFormatException {
/*     */     byte b;
/*     */     boolean bool;
/* 639 */     if (paramString.startsWith("0x") || paramString.startsWith("0X")) {
/* 640 */       bool = true;
/* 641 */       b = 16;
/* 642 */     } else if (paramString.startsWith("#")) {
/* 643 */       bool = true;
/* 644 */       b = 16;
/* 645 */     } else if (paramString.startsWith("0") && paramString.length() > 1) {
/* 646 */       bool = true;
/* 647 */       b = 8;
/*     */     } else {
/* 649 */       bool = false;
/* 650 */       b = 10;
/*     */     } 
/* 652 */     String str = (paramBoolean ? "-" : "") + paramString.substring(bool);
/* 653 */     BigInteger bigInteger = new BigInteger(str, b);
/* 654 */     if (bigInteger.compareTo(UNSIGNED_LONG_MAX_VALUE) > 0) {
/* 655 */       throw new NumberFormatException("Value \"" + paramString + "\" is > UNSIGNED_LONG_MAX");
/*     */     }
/* 657 */     return bigInteger.longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CNumber decodeDecimalNumber(String paramString) {
/* 671 */     if (null == paramString || !isDecimalNumber(paramString)) {
/* 672 */       return null;
/*     */     }
/* 674 */     String str = paramString.trim();
/* 675 */     if (0 == str.length()) {
/* 676 */       return null;
/*     */     }
/* 678 */     boolean bool = false;
/* 679 */     char c = str.charAt(str.length() - 1);
/* 680 */     if (c == 'd' || c == 'D') {
/* 681 */       bool = true;
/*     */     }
/* 683 */     double d1 = Double.valueOf(str).doubleValue();
/* 684 */     double d2 = Math.abs(d1);
/* 685 */     return new CNumber((bool || 1.401298464324817E-45D > d2 || d2 > 3.4028234663852886E38D), d1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNumber(String paramString) {
/* 692 */     if (isHexNumber(paramString)) {
/* 693 */       return true;
/*     */     }
/* 695 */     return isDecimalOrIntNumber(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isIntegerNumber(String paramString) {
/* 703 */     if (isHexNumber(paramString)) {
/* 704 */       return true;
/*     */     }
/* 706 */     return patternIntegerNumber.matcher(paramString).matches();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHexNumber(String paramString) {
/* 714 */     return patternHexNumber.matcher(paramString).matches();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDecimalNumber(String paramString) {
/* 722 */     return patternDecimalNumber.matcher(paramString).matches();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDecimalOrIntNumber(String paramString) {
/* 730 */     return patternDecimalOrIntNumber.matcher(paramString).matches();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCPPOperand(String paramString) {
/* 737 */     return patternCPPOperand.matcher(paramString).matches();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 791 */   public static Pattern patternHexNumber = Pattern.compile("[\\x00-\\x20]*[+-]?0[xX](\\p{XDigit}+)([uU]|([uU][lL])|[lL]|([lL][uU]))?[\\x00-\\x20]*");
/*     */ 
/*     */   
/*     */   public static final Pattern patternDecimalNumber;
/*     */ 
/*     */   
/*     */   public static final Pattern patternDecimalOrIntNumber;
/*     */ 
/*     */   
/* 800 */   public static final Pattern patternIntegerNumber = Pattern.compile("[\\x00-\\x20]*[+-]?(\\p{Digit}+)([uU]|([uU][lL])|[lL]|([lL][uU]))?[\\x00-\\x20]*");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pattern patternCPPOperand;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 850 */     patternDecimalNumber = Pattern.compile("[\\x00-\\x20]*[+-]?(NaN|Infinity|((((\\p{Digit}+)(\\.)?((\\p{Digit}+)?)([eE][+-]?(\\p{Digit}+))?)|(\\.((\\p{Digit}+))([eE][+-]?(\\p{Digit}+))?)|(((0[xX](\\p{XDigit}+)(\\.)?)|(0[xX](\\p{XDigit}+)?(\\.)(\\p{XDigit}+)))[pP][+-]?(\\p{Digit}+)))[fFdD]?))[\\x00-\\x20]*");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 902 */     patternDecimalOrIntNumber = Pattern.compile("[\\x00-\\x20]*[+-]?(NaN|Infinity|((\\p{Digit}+)([uU]|([uU][lL])|[lL]|([lL][uU])))|((((\\p{Digit}+)(\\.)?((\\p{Digit}+)?)([eE][+-]?(\\p{Digit}+))?)|(\\.((\\p{Digit}+))([eE][+-]?(\\p{Digit}+))?)|(((0[xX](\\p{XDigit}+)(\\.)?)|(0[xX](\\p{XDigit}+)?(\\.)(\\p{XDigit}+)))[pP][+-]?(\\p{Digit}+)))[fFdD]?))[\\x00-\\x20]*");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 954 */     patternCPPOperand = Pattern.compile("(?![\\x00-\\x20]*(NaN|Infinity|((\\p{Digit}+)([uU]|([uU][lL])|[lL]|([lL][uU])))|((((\\p{Digit}+)(\\.)?((\\p{Digit}+)?)([eE][+-]?(\\p{Digit}+))?)|(\\.((\\p{Digit}+))([eE][+-]?(\\p{Digit}+))?)|(((0[xX](\\p{XDigit}+)(\\.)?)|(0[xX](\\p{XDigit}+)?(\\.)(\\p{XDigit}+)))[pP][+-]?(\\p{Digit}+)))[fFdD]?))[\\x00-\\x20]*)[\\+\\-\\*\\/\\|\\&\\(\\)]|(\\<\\<)|(\\>\\>)|(\\~)");
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/ConstantDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */