/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.FunctionType;
/*     */ import com.jogamp.gluegen.cgram.types.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodBinding
/*     */ {
/*     */   private final FunctionSymbol sym;
/*     */   private final String delegationImplName;
/*     */   private final JavaType containingType;
/*     */   private final Type containingCType;
/*     */   private String nativeName;
/*     */   private JavaType javaReturnType;
/*     */   private List<JavaType> javaArgumentTypes;
/*     */   private boolean computedSignatureProperties;
/*     */   private boolean argumentsUseNIO;
/*     */   private boolean signatureUsesNIO;
/*     */   private boolean signatureCanUseIndirectNIO;
/*     */   private boolean signatureUsesCompoundTypeWrappers;
/*     */   private boolean signatureUsesArraysOfCompoundTypeWrappers;
/*     */   private boolean signatureUsesCVoidPointers;
/*     */   private boolean signatureUsesCPrimitivePointers;
/*     */   private boolean signatureUsesCArrays;
/*     */   private boolean signatureUsesJavaPrimitiveArrays;
/*  73 */   private int thisPointerIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodBinding(MethodBinding paramMethodBinding) {
/*  81 */     this.sym = paramMethodBinding.sym;
/*  82 */     this.delegationImplName = paramMethodBinding.delegationImplName;
/*  83 */     this.containingType = paramMethodBinding.containingType;
/*  84 */     this.containingCType = paramMethodBinding.containingCType;
/*     */     
/*  86 */     this.nativeName = paramMethodBinding.nativeName;
/*  87 */     this.javaReturnType = paramMethodBinding.javaReturnType;
/*  88 */     this.javaArgumentTypes = (null != paramMethodBinding.javaArgumentTypes) ? new ArrayList<>(paramMethodBinding.javaArgumentTypes) : null;
/*  89 */     this.computedSignatureProperties = paramMethodBinding.computedSignatureProperties;
/*  90 */     this.argumentsUseNIO = paramMethodBinding.argumentsUseNIO;
/*  91 */     this.signatureUsesNIO = paramMethodBinding.signatureUsesNIO;
/*  92 */     this.signatureCanUseIndirectNIO = paramMethodBinding.signatureCanUseIndirectNIO;
/*  93 */     this.signatureUsesCompoundTypeWrappers = paramMethodBinding.signatureUsesCompoundTypeWrappers;
/*  94 */     this.signatureUsesArraysOfCompoundTypeWrappers = paramMethodBinding.signatureUsesArraysOfCompoundTypeWrappers;
/*  95 */     this.signatureUsesCVoidPointers = paramMethodBinding.signatureUsesCVoidPointers;
/*  96 */     this.signatureUsesCPrimitivePointers = paramMethodBinding.signatureUsesCPrimitivePointers;
/*  97 */     this.signatureUsesCArrays = paramMethodBinding.signatureUsesCArrays;
/*  98 */     this.signatureUsesJavaPrimitiveArrays = paramMethodBinding.signatureUsesJavaPrimitiveArrays;
/*  99 */     this.thisPointerIndex = paramMethodBinding.thisPointerIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodBinding(FunctionSymbol paramFunctionSymbol, String paramString, JavaType paramJavaType1, List<JavaType> paramList, JavaType paramJavaType2, Type paramType) {
/* 115 */     this.sym = paramFunctionSymbol;
/* 116 */     this.delegationImplName = paramString;
/* 117 */     this.containingType = paramJavaType2;
/* 118 */     this.containingCType = paramType;
/*     */     
/* 120 */     this.nativeName = null;
/* 121 */     this.javaReturnType = paramJavaType1;
/* 122 */     this.javaArgumentTypes = paramList;
/*     */   }
/*     */   
/*     */   public void setJavaReturnType(JavaType paramJavaType) {
/* 126 */     this.javaReturnType = paramJavaType;
/* 127 */     this.computedSignatureProperties = false;
/*     */   }
/*     */   
/*     */   public void addJavaArgumentType(JavaType paramJavaType) {
/* 131 */     if (this.javaArgumentTypes == null) {
/* 132 */       this.javaArgumentTypes = new ArrayList<>();
/*     */     }
/* 134 */     this.javaArgumentTypes.add(paramJavaType);
/* 135 */     this.computedSignatureProperties = false;
/*     */   }
/*     */   
/*     */   public JavaType getJavaReturnType() {
/* 139 */     return this.javaReturnType;
/*     */   }
/*     */   
/*     */   public int getNumArguments() {
/* 143 */     return this.sym.getNumArguments();
/*     */   }
/*     */   
/*     */   public JavaType getJavaArgumentType(int paramInt) {
/* 147 */     return this.javaArgumentTypes.get(paramInt);
/*     */   }
/*     */   
/*     */   public Type getCReturnType() {
/* 151 */     return this.sym.getReturnType();
/*     */   }
/*     */   
/*     */   public Type getCArgumentType(int paramInt) {
/* 155 */     return this.sym.getArgumentType(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getCParameterList(StringBuilder paramStringBuilder, boolean paramBoolean, String paramString) {
/* 166 */     return getCParameterList(paramStringBuilder, paramBoolean, paramString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getCParameterList(StringBuilder paramStringBuilder, boolean paramBoolean, String paramString, List<Integer> paramList) {
/* 177 */     forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString2) -> {
/*     */           if (!paramType.isVoid() && (null == paramList || !paramList.contains(Integer.valueOf(paramInt1)))) {
/*     */             if (0 < paramInt2) {
/*     */               paramStringBuilder.append(", ");
/*     */             }
/*     */             
/*     */             if (paramBoolean && paramType.isTypedef()) {
/*     */               paramStringBuilder.append(paramType.getName());
/*     */               if (paramString2 != null) {
/*     */                 paramStringBuilder.append(" ");
/*     */                 paramStringBuilder.append(paramString2);
/*     */               } 
/*     */             } else if (paramType.isFunctionPointer()) {
/*     */               FunctionType functionType = paramType.getTargetFunction();
/*     */               paramStringBuilder.append(functionType.toString(paramString2, paramString1, false, true));
/*     */             } else if (paramType.isArray()) {
/*     */               paramStringBuilder.append(paramType.asArray().toString(paramString2));
/*     */             } else {
/*     */               paramStringBuilder.append(paramType.getCName(true));
/*     */               if (paramString2 != null) {
/*     */                 paramStringBuilder.append(" ");
/*     */                 paramStringBuilder.append(paramString2);
/*     */               } 
/*     */             } 
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 205 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getJavaParameterList(StringBuilder paramStringBuilder) {
/* 214 */     return getJavaParameterList(paramStringBuilder, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getJavaParameterList(StringBuilder paramStringBuilder, List<Integer> paramList) {
/* 223 */     forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid() && (null == paramList || !paramList.contains(Integer.valueOf(paramInt1)))) {
/*     */             if (0 < paramInt2) {
/*     */               paramStringBuilder.append(", ");
/*     */             }
/*     */             
/*     */             paramStringBuilder.append(paramJavaType + " " + paramString);
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 234 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getJavaSelectParameter(StringBuilder paramStringBuilder, List<Integer> paramList, boolean paramBoolean) {
/* 244 */     forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid() && paramList.contains(Integer.valueOf(paramInt1))) {
/*     */             if (0 < paramInt2) {
/*     */               paramStringBuilder.append(", ");
/*     */             }
/*     */             
/*     */             paramStringBuilder.append(paramJavaType + " " + paramString);
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 255 */     if (paramBoolean && paramStringBuilder.length() > 0) {
/* 256 */       paramStringBuilder.append(", ");
/*     */     }
/* 258 */     return paramStringBuilder;
/*     */   }
/*     */   public StringBuilder getJavaCallArgumentList(StringBuilder paramStringBuilder, List<Integer> paramList) {
/* 261 */     forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid() && (null == paramList || !paramList.contains(Integer.valueOf(paramInt1)))) {
/*     */             if (0 < paramInt2) {
/*     */               paramStringBuilder.append(", ");
/*     */             }
/*     */             
/*     */             paramStringBuilder.append(paramString);
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 272 */     return paramStringBuilder;
/*     */   }
/*     */   public StringBuilder getJavaCallSelectArguments(StringBuilder paramStringBuilder, List<Integer> paramList, boolean paramBoolean) {
/* 275 */     forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid() && paramList.contains(Integer.valueOf(paramInt1))) {
/*     */             if (0 < paramInt2) {
/*     */               paramStringBuilder.append(", ");
/*     */             }
/*     */             
/*     */             paramStringBuilder.append(paramString);
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 286 */     if (paramBoolean && paramStringBuilder.length() > 0) {
/* 287 */       paramStringBuilder.append(", ");
/*     */     }
/* 289 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int forEachParameter(ParameterConsumer paramParameterConsumer) {
/* 307 */     int i = getNumArguments();
/* 308 */     byte b1 = 0;
/* 309 */     for (byte b2 = 0; b2 < i; b2++) {
/* 310 */       if (paramParameterConsumer.accept(b2, b1, getCArgumentType(b2), getJavaArgumentType(b2), getArgumentName(b2))) {
/* 311 */         b1++;
/*     */       }
/*     */     } 
/* 314 */     return b1;
/*     */   }
/*     */   
/*     */   public final boolean isReturnCompoundByValue() {
/* 318 */     Type type = getCReturnType();
/* 319 */     if (type.isVoid()) {
/* 320 */       return false;
/*     */     }
/* 322 */     if (this.javaReturnType.isPrimitive()) {
/* 323 */       return false;
/*     */     }
/* 325 */     return (!type.isPointer() && this.javaReturnType.isCompoundTypeWrapper());
/*     */   }
/*     */ 
/*     */   
/*     */   public FunctionSymbol getCSymbol() {
/* 330 */     return this.sym;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getArgumentName(int paramInt) {
/* 339 */     String str = this.sym.getArgumentName(paramInt);
/* 340 */     if (null != str) {
/* 341 */       return str;
/*     */     }
/* 343 */     return "arg" + paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 348 */     return this.sym.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDelegationImplName() {
/* 357 */     return this.delegationImplName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInterfaceName() {
/* 362 */     return this.sym.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImplName() {
/* 371 */     return (null != this.delegationImplName) ? this.delegationImplName : this.sym.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNativeName() {
/* 379 */     return (null != this.nativeName) ? this.nativeName : this.sym.getOrigName();
/*     */   } public void setNativeName(String paramString) {
/* 381 */     this.nativeName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodBinding replaceJavaArgumentType(int paramInt, JavaType paramJavaType) {
/* 388 */     MethodBinding methodBinding = new MethodBinding(this);
/* 389 */     methodBinding.javaArgumentTypes = null;
/* 390 */     if (paramInt < 0) {
/* 391 */       methodBinding.setJavaReturnType(paramJavaType);
/*     */     } else {
/* 393 */       methodBinding.setJavaReturnType(this.javaReturnType);
/*     */     } 
/* 395 */     for (byte b = 0; b < getNumArguments(); b++) {
/* 396 */       JavaType javaType = getJavaArgumentType(b);
/* 397 */       if (b == paramInt) {
/* 398 */         javaType = paramJavaType;
/*     */       }
/* 400 */       methodBinding.addJavaArgumentType(javaType);
/*     */     } 
/* 402 */     return methodBinding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean argumentsUseNIO() {
/* 411 */     computeSignatureProperties();
/* 412 */     return this.argumentsUseNIO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureUsesNIO() {
/* 421 */     computeSignatureProperties();
/* 422 */     return this.signatureUsesNIO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureCanUseIndirectNIO() {
/* 430 */     computeSignatureProperties();
/* 431 */     return this.signatureCanUseIndirectNIO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureUsesCompoundTypeWrappers() {
/* 440 */     computeSignatureProperties();
/* 441 */     return this.signatureUsesCompoundTypeWrappers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureUsesArraysOfCompoundTypeWrappers() {
/* 450 */     computeSignatureProperties();
/* 451 */     return this.signatureUsesArraysOfCompoundTypeWrappers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needsNIOWrappingOrUnwrapping() {
/* 461 */     return (signatureUsesNIO() || signatureUsesCompoundTypeWrappers() || signatureUsesArraysOfCompoundTypeWrappers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureUsesCVoidPointers() {
/* 469 */     computeSignatureProperties();
/* 470 */     return this.signatureUsesCVoidPointers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureUsesCPrimitivePointers() {
/* 478 */     computeSignatureProperties();
/* 479 */     return this.signatureUsesCPrimitivePointers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureUsesCArrays() {
/* 487 */     computeSignatureProperties();
/* 488 */     return this.signatureUsesCArrays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureUsesJavaPrimitiveArrays() {
/* 496 */     computeSignatureProperties();
/* 497 */     return this.signatureUsesJavaPrimitiveArrays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void computeSignatureProperties() {
/* 505 */     if (this.computedSignatureProperties) {
/*     */       return;
/*     */     }
/* 508 */     this.argumentsUseNIO = false;
/* 509 */     this.signatureUsesNIO = false;
/* 510 */     this.signatureCanUseIndirectNIO = false;
/* 511 */     this.signatureUsesCompoundTypeWrappers = false;
/* 512 */     this.signatureUsesArraysOfCompoundTypeWrappers = false;
/* 513 */     this.signatureUsesCVoidPointers = false;
/* 514 */     this.signatureUsesCPrimitivePointers = false;
/* 515 */     this.signatureUsesCArrays = false;
/* 516 */     this.signatureUsesJavaPrimitiveArrays = false;
/*     */     
/* 518 */     if (this.javaReturnType.isCompoundTypeWrapper())
/*     */     {
/*     */       
/* 521 */       this.signatureUsesCompoundTypeWrappers = true;
/*     */     }
/*     */     
/* 524 */     if (this.javaReturnType.isNIOBuffer() || this.javaReturnType
/* 525 */       .isArrayOfCompoundTypeWrappers())
/*     */     {
/*     */ 
/*     */       
/* 529 */       this.signatureUsesNIO = true;
/*     */     }
/*     */     
/* 532 */     Type type = this.sym.getReturnType();
/* 533 */     if (type.isArray()) {
/*     */       
/* 535 */       this.signatureUsesCArrays = true;
/* 536 */       if (type.asArray().getTargetType().isPrimitive()) {
/* 537 */         this.signatureUsesCPrimitivePointers = true;
/*     */       }
/*     */     } 
/*     */     
/* 541 */     if (type.isPointer()) {
/* 542 */       if (type.asPointer().getTargetType().isPrimitive()) {
/* 543 */         this.signatureUsesCPrimitivePointers = true;
/* 544 */       } else if (type.asPointer().getTargetType().isVoid()) {
/* 545 */         this.signatureUsesCVoidPointers = true;
/*     */       } 
/*     */     }
/*     */     
/* 549 */     for (byte b = 0; b < getNumArguments(); b++) {
/* 550 */       JavaType javaType = getJavaArgumentType(b);
/* 551 */       Type type1 = getCArgumentType(b);
/* 552 */       if (javaType.isCompoundTypeWrapper())
/*     */       {
/* 554 */         this.signatureUsesCompoundTypeWrappers = true;
/*     */       }
/*     */       
/* 557 */       if (javaType.isArrayOfCompoundTypeWrappers())
/*     */       {
/*     */         
/* 560 */         this.signatureUsesArraysOfCompoundTypeWrappers = true;
/*     */       }
/*     */       
/* 563 */       if (javaType.isNIOBuffer() || javaType
/* 564 */         .isNIOBufferArray()) {
/*     */         
/* 566 */         this.signatureUsesNIO = true;
/* 567 */         this.argumentsUseNIO = true;
/*     */         
/* 569 */         if (javaType.isNIOBuffer())
/*     */         {
/* 571 */           this.signatureCanUseIndirectNIO = true;
/*     */         }
/*     */       } 
/*     */       
/* 575 */       if (type1.isArray()) {
/*     */         
/* 577 */         this.signatureUsesCArrays = true;
/* 578 */         if (type1.asArray().getTargetType().isPrimitive()) {
/* 579 */           this.signatureUsesCPrimitivePointers = true;
/*     */         }
/*     */       } 
/*     */       
/* 583 */       if (type1.isPointer())
/*     */       {
/*     */         
/* 586 */         if (type1.asPointer().getTargetType().isPrimitive() || javaType
/* 587 */           .isCPrimitivePointerType()) {
/* 588 */           this.signatureUsesCPrimitivePointers = true;
/* 589 */         } else if (type1.asPointer().getTargetType().isVoid()) {
/* 590 */           this.signatureUsesCVoidPointers = true;
/*     */         } 
/*     */       }
/*     */       
/* 594 */       if (javaType.isPrimitiveArray())
/*     */       {
/*     */         
/* 597 */         this.signatureUsesJavaPrimitiveArrays = true;
/*     */       }
/*     */     } 
/*     */     
/* 601 */     this.computedSignatureProperties = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasContainingType() {
/* 615 */     return (getContainingType() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getContainingType() {
/* 621 */     return this.containingType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getContainingCType() {
/* 627 */     return this.containingCType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findThisPointer() {
/* 635 */     clearThisPointer();
/* 636 */     for (byte b = 0; b < getNumArguments(); b++) {
/* 637 */       JavaType javaType = getJavaArgumentType(b);
/* 638 */       if (javaType.equals(this.containingType)) {
/* 639 */         this.thisPointerIndex = b;
/*     */         
/*     */         break;
/*     */       } 
/* 643 */       if (!javaType.isJNIEnv()) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearThisPointer() {
/* 651 */     this.thisPointerIndex = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isArgumentThisPointer(int paramInt) {
/* 657 */     return (this.thisPointerIndex == paramInt);
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 661 */     if (paramObject == this) {
/* 662 */       return true;
/*     */     }
/*     */     
/* 665 */     if (paramObject == null || !(paramObject instanceof MethodBinding)) {
/* 666 */       return false;
/*     */     }
/*     */     
/* 669 */     MethodBinding methodBinding = (MethodBinding)paramObject;
/* 670 */     if (!getName().equals(methodBinding.getName()) || 
/* 671 */       !this.sym.getType().equals(methodBinding.sym.getType())) return false; 
/* 672 */     if (!this.javaReturnType.equals(methodBinding.getJavaReturnType())) return false; 
/* 673 */     if (this.containingCType != null && methodBinding
/* 674 */       .getContainingCType() != null && 
/* 675 */       !this.containingCType.equals(methodBinding.getContainingCType())) {
/* 676 */       return false;
/*     */     }
/* 678 */     if (this.javaArgumentTypes.size() != methodBinding.javaArgumentTypes.size()) {
/* 679 */       return false;
/*     */     }
/*     */     
/* 682 */     for (byte b = 0; b < this.javaArgumentTypes.size(); b++) {
/* 683 */       Object object = this.javaArgumentTypes.get(b);
/* 684 */       JavaType javaType = methodBinding.getJavaArgumentType(b);
/* 685 */       if (!object.equals(javaType)) {
/* 686 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 690 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 695 */     StringBuilder stringBuilder = new StringBuilder(200);
/* 696 */     stringBuilder.append(getName());
/* 697 */     stringBuilder.append(this.sym.getType().getName(true));
/* 698 */     stringBuilder.append(getJavaReturnType().getName());
/* 699 */     if (this.containingCType != null) {
/* 700 */       stringBuilder.append(this.containingCType.getName(true));
/*     */     }
/*     */     
/* 703 */     for (byte b = 0; b < getNumArguments(); b++) {
/* 704 */       JavaType javaType = getJavaArgumentType(b);
/* 705 */       if (javaType.isVoid()) {
/*     */ 
/*     */         
/* 708 */         assert getNumArguments() == 1;
/*     */       }
/*     */       else {
/*     */         
/* 712 */         stringBuilder.append(javaType.getName());
/*     */       } 
/* 714 */     }  return stringBuilder.toString().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 720 */     StringBuilder stringBuilder = new StringBuilder(200);
/* 721 */     stringBuilder.append(getJavaReturnType().getName());
/* 722 */     stringBuilder.append(' ');
/* 723 */     stringBuilder.append(getName());
/* 724 */     stringBuilder.append('(');
/* 725 */     boolean bool = false;
/* 726 */     for (byte b = 0; b < getNumArguments(); b++) {
/* 727 */       JavaType javaType = getJavaArgumentType(b);
/* 728 */       if (javaType.isVoid()) {
/*     */ 
/*     */         
/* 731 */         assert getNumArguments() == 1;
/*     */       
/*     */       }
/* 734 */       else if (!javaType.isJNIEnv() && !isArgumentThisPointer(b)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 739 */         if (bool) {
/* 740 */           stringBuilder.append(", ");
/*     */         }
/*     */         
/* 743 */         stringBuilder.append(javaType.getName());
/* 744 */         stringBuilder.append(' ');
/* 745 */         stringBuilder.append(getArgumentName(b));
/* 746 */         bool = true;
/*     */       } 
/* 748 */     }  stringBuilder.append(')');
/* 749 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescriptor(boolean paramBoolean1, boolean paramBoolean2) {
/* 758 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 760 */     stringBuilder.append('(');
/*     */     
/* 762 */     if (paramBoolean1 && hasContainingType())
/*     */     {
/* 764 */       stringBuilder.append("Ljava/nio/ByteBuffer;");
/*     */     }
/*     */     
/* 767 */     for (byte b = 0; b < getNumArguments(); b++) {
/* 768 */       JavaType javaType = getJavaArgumentType(b);
/* 769 */       if (javaType.isVoid()) {
/*     */ 
/*     */         
/* 772 */         if (getNumArguments() != 1) {
/* 773 */           throw new InternalError("\"void\" argument type found in multi-argument function \"" + this + "\"");
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 780 */       else if (!javaType.isJNIEnv() && !isArgumentThisPointer(b)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 785 */         stringBuilder.append(erasedTypeDescriptor(javaType, paramBoolean2, false));
/*     */ 
/*     */         
/* 788 */         if (paramBoolean1) {
/* 789 */           if (javaType.isNIOBuffer()) {
/* 790 */             stringBuilder.append('I');
/* 791 */           } else if (javaType.isNIOBufferArray()) {
/* 792 */             stringBuilder.append("[I");
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/* 797 */         if (javaType.isPrimitiveArray()) {
/* 798 */           stringBuilder.append('I');
/*     */         }
/*     */       } 
/*     */     } 
/* 802 */     stringBuilder.append(')');
/*     */ 
/*     */ 
/*     */     
/* 806 */     stringBuilder.append(erasedTypeDescriptor(getJavaReturnType(), paramBoolean2, false));
/*     */     
/* 808 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   protected String erasedTypeDescriptor(JavaType paramJavaType, boolean paramBoolean1, boolean paramBoolean2) {
/* 812 */     if (paramBoolean1)
/* 813 */       if (paramJavaType.isNIOBuffer() || paramJavaType
/* 814 */         .isPrimitiveArray()) {
/* 815 */         if (!paramBoolean2)
/*     */         {
/*     */           
/* 818 */           return "Ljava/lang/Object;"; } 
/*     */       } else {
/* 820 */         if (paramJavaType.isCompoundTypeWrapper())
/*     */         {
/* 822 */           return "Ljava/nio/ByteBuffer;"; } 
/* 823 */         if (paramJavaType.isArrayOfCompoundTypeWrappers()) {
/* 824 */           return "Ljava/nio/ByteBuffer;";
/*     */         }
/*     */       }  
/* 827 */     return paramJavaType.getDescriptor();
/*     */   }
/*     */   
/*     */   public static interface ParameterConsumer {
/*     */     boolean accept(int param1Int1, int param1Int2, Type param1Type, JavaType param1JavaType, String param1String);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/MethodBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */