package com.jogamp.gluegen;

import com.jogamp.gluegen.jcpp.LexerException;
import java.io.OutputStream;
import java.io.Reader;
import java.util.List;

public interface GenericCPP {
  void addDefine(String paramString1, String paramString2) throws LexerException;
  
  String findFile(String paramString);
  
  OutputStream out();
  
  void setOut(OutputStream paramOutputStream);
  
  void run(Reader paramReader, String paramString) throws GlueGenException;
  
  List<ConstantDefinition> getConstantDefinitions() throws GlueGenException;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/GenericCPP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */