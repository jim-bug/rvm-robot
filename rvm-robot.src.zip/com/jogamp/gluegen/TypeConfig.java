/*    */ package com.jogamp.gluegen;
/*    */ 
/*    */ import com.jogamp.gluegen.cgram.types.SizeThunk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeConfig
/*    */ {
/*    */   private static boolean relaxedEqualSemanticsTest = false;
/*    */   
/*    */   public static boolean relaxedEqualSemanticsTest() {
/* 46 */     return relaxedEqualSemanticsTest;
/*    */   }
/*    */   static void setRelaxedEqualSemanticsTest(boolean paramBoolean) {
/* 49 */     relaxedEqualSemanticsTest = paramBoolean;
/* 50 */     SizeThunk.setRelaxedEqualSemanticsTest(paramBoolean);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/TypeConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */