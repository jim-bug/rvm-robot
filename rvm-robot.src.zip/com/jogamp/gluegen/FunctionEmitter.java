/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FunctionEmitter
/*     */ {
/*  53 */   public static final EmissionModifier STATIC = new EmissionModifier("static");
/*     */   
/*     */   private final boolean isInterface;
/*     */   private final ArrayList<EmissionModifier> modifiers;
/*  57 */   private CommentEmitter commentEmitter = null;
/*     */   
/*     */   protected final MethodBinding binding;
/*     */   
/*     */   protected final CodeUnit unit;
/*     */   
/*     */   protected final JavaConfiguration cfg;
/*     */ 
/*     */   
/*     */   public FunctionEmitter(MethodBinding paramMethodBinding, CodeUnit paramCodeUnit, boolean paramBoolean, JavaConfiguration paramJavaConfiguration) {
/*  67 */     assert paramCodeUnit != null;
/*  68 */     this.isInterface = paramBoolean;
/*  69 */     this.modifiers = new ArrayList<>();
/*  70 */     this.binding = paramMethodBinding;
/*  71 */     this.unit = paramCodeUnit;
/*  72 */     this.cfg = paramJavaConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionEmitter(FunctionEmitter paramFunctionEmitter) {
/*  79 */     this.isInterface = paramFunctionEmitter.isInterface;
/*  80 */     this.modifiers = new ArrayList<>(paramFunctionEmitter.modifiers);
/*  81 */     this.commentEmitter = paramFunctionEmitter.commentEmitter;
/*  82 */     this.binding = paramFunctionEmitter.binding;
/*  83 */     this.unit = paramFunctionEmitter.unit;
/*  84 */     this.cfg = paramFunctionEmitter.cfg;
/*     */   }
/*     */   public final boolean isInterface() {
/*  87 */     return this.isInterface;
/*     */   }
/*  89 */   public final MethodBinding getBinding() { return this.binding; } public final CodeUnit getUnit() {
/*  90 */     return this.unit;
/*     */   }
/*     */   public void addModifiers(Iterator<EmissionModifier> paramIterator) {
/*  93 */     while (paramIterator.hasNext())
/*  94 */       this.modifiers.add(paramIterator.next()); 
/*     */   }
/*     */   public void addModifier(EmissionModifier paramEmissionModifier) {
/*  97 */     this.modifiers.add(paramEmissionModifier);
/*     */   } public boolean removeModifier(EmissionModifier paramEmissionModifier) {
/*  99 */     return this.modifiers.remove(paramEmissionModifier);
/*     */   } public void clearModifiers() {
/* 101 */     this.modifiers.clear();
/*     */   } public boolean hasModifier(EmissionModifier paramEmissionModifier) {
/* 103 */     return this.modifiers.contains(paramEmissionModifier);
/*     */   } public Iterator<EmissionModifier> getModifiers() {
/* 105 */     return this.modifiers.iterator();
/*     */   }
/*     */   
/*     */   public abstract String getInterfaceName();
/*     */   
/*     */   public abstract String getImplName();
/*     */   
/*     */   public abstract String getNativeName();
/*     */   
/*     */   public abstract FunctionSymbol getCSymbol();
/*     */   
/*     */   public final void emit() {
/* 117 */     emitAdditionalCode();
/* 118 */     emitDocComment();
/*     */     
/* 120 */     emitSignature();
/* 121 */     emitBody();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return getClass().getSimpleName() + "[" + this.binding.toString() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommentEmitter(CommentEmitter paramCommentEmitter) {
/* 134 */     this.commentEmitter = paramCommentEmitter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommentEmitter getCommentEmitter() {
/* 141 */     return this.commentEmitter;
/*     */   }
/*     */   protected void emitAdditionalCode() {}
/*     */   
/*     */   protected void emitDocComment() {
/* 146 */     if (this.commentEmitter != null) {
/* 147 */       this.unit.emit(getBaseIndentString());
/*     */       
/* 149 */       this.unit.emit(getCommentStartString());
/*     */       
/* 151 */       this.commentEmitter.emit(this, this.unit.output);
/*     */       
/* 153 */       this.unit.emit(getBaseIndentString());
/*     */       
/* 155 */       this.unit.emitln(getCommentEndString());
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void emitSignature() {
/* 160 */     this.unit.emit(appendSignature(new StringBuilder()).toString());
/*     */   }
/*     */   
/*     */   protected StringBuilder appendSignature(StringBuilder paramStringBuilder) {
/* 164 */     paramStringBuilder.append(getBaseIndentString());
/*     */     
/* 166 */     int i = appendModifiers(paramStringBuilder);
/* 167 */     if (i > 0) {
/* 168 */       paramStringBuilder.append(" ");
/*     */     }
/*     */     
/* 171 */     appendReturnType(paramStringBuilder);
/* 172 */     paramStringBuilder.append(" ");
/*     */     
/* 174 */     appendName(paramStringBuilder);
/* 175 */     paramStringBuilder.append("(");
/*     */     
/* 177 */     appendArguments(paramStringBuilder);
/* 178 */     paramStringBuilder.append(")");
/* 179 */     return paramStringBuilder;
/*     */   }
/*     */   
/*     */   protected final int emitModifiers() {
/* 183 */     StringBuilder stringBuilder = new StringBuilder();
/* 184 */     int i = appendModifiers(stringBuilder);
/* 185 */     this.unit.emit(stringBuilder.toString());
/* 186 */     return i;
/*     */   }
/*     */   protected int appendModifiers(StringBuilder paramStringBuilder) {
/* 189 */     byte b = 0;
/* 190 */     for (Iterator<EmissionModifier> iterator = getModifiers(); iterator.hasNext(); ) {
/* 191 */       paramStringBuilder.append(((EmissionModifier)iterator.next()).toString());
/* 192 */       b++;
/* 193 */       if (iterator.hasNext()) {
/* 194 */         paramStringBuilder.append(" ");
/*     */       }
/*     */     } 
/* 197 */     return b;
/*     */   }
/*     */   protected String getBaseIndentString() {
/* 200 */     return "";
/*     */   }
/* 202 */   protected String getCommentStartString() { return "/* "; } protected String getCommentEndString() {
/* 203 */     return " */";
/*     */   }
/*     */   protected final void emitReturnType() {
/* 206 */     this.unit.emit(appendReturnType(new StringBuilder()).toString());
/*     */   }
/*     */   protected abstract StringBuilder appendReturnType(StringBuilder paramStringBuilder);
/*     */   protected final void emitName() {
/* 210 */     this.unit.emit(appendName(new StringBuilder()).toString());
/*     */   }
/*     */   protected abstract StringBuilder appendName(StringBuilder paramStringBuilder);
/*     */   
/*     */   protected final int emitArguments() {
/* 215 */     StringBuilder stringBuilder = new StringBuilder();
/* 216 */     int i = appendArguments(stringBuilder);
/* 217 */     this.unit.emit(stringBuilder.toString());
/* 218 */     return i;
/*     */   }
/*     */   protected abstract int appendArguments(StringBuilder paramStringBuilder);
/*     */   
/*     */   protected abstract void emitBody();
/*     */   
/*     */   public static class EmissionModifier { private final String emittedForm;
/*     */     
/*     */     public final String toString() {
/* 227 */       return this.emittedForm;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 233 */       return this.emittedForm.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 238 */       if (param1Object == null || !(param1Object instanceof EmissionModifier)) {
/* 239 */         return false;
/*     */       }
/*     */       
/* 242 */       return this.emittedForm.equals(((EmissionModifier)param1Object).emittedForm);
/*     */     }
/*     */     protected EmissionModifier(String param1String) {
/* 245 */       this.emittedForm = param1String;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/FunctionEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */