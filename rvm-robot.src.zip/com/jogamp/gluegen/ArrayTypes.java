/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayTypes
/*     */ {
/* 107 */   public static final Class<?> booleanArrayClass = (new boolean[0]).getClass();
/* 108 */   public static final Class<?> byteArrayClass = (new byte[0]).getClass();
/* 109 */   public static final Class<?> charArrayClass = (new char[0]).getClass();
/* 110 */   public static final Class<?> shortArrayClass = (new short[0]).getClass();
/* 111 */   public static final Class<?> intArrayClass = (new int[0]).getClass();
/* 112 */   public static final Class<?> longArrayClass = (new long[0]).getClass();
/* 113 */   public static final Class<?> floatArrayClass = (new float[0]).getClass();
/* 114 */   public static final Class<?> doubleArrayClass = (new double[0]).getClass();
/* 115 */   public static final Class<?> stringArrayClass = (new String[0]).getClass();
/*     */   
/* 117 */   public static final Class<?> bufferArrayClass = (new java.nio.Buffer[0]).getClass();
/* 118 */   public static final Class<?> byteBufferArrayClass = (new java.nio.ByteBuffer[0]).getClass();
/* 119 */   public static final Class<?> shortBufferArrayClass = (new java.nio.ShortBuffer[0]).getClass();
/* 120 */   public static final Class<?> intBufferArrayClass = (new java.nio.IntBuffer[0]).getClass();
/* 121 */   public static final Class<?> longBufferArrayClass = (new java.nio.LongBuffer[0]).getClass();
/* 122 */   public static final Class<?> floatBufferArrayClass = (new java.nio.FloatBuffer[0]).getClass();
/* 123 */   public static final Class<?> doubleBufferArrayClass = (new java.nio.DoubleBuffer[0]).getClass();
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/ArrayTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */