/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnegative;
/*     */ import javax.annotation.Nonnull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MacroTokenSource
/*     */   extends Source
/*     */ {
/*     */   private final Macro macro;
/*     */   private final Iterator<Token> tokens;
/*     */   private final List<Argument> args;
/*     */   private Iterator<Token> arg;
/*     */   
/*     */   MacroTokenSource(@Nonnull Macro paramMacro, @Nonnull List<Argument> paramList) {
/*  40 */     this.macro = paramMacro;
/*  41 */     this.tokens = paramMacro.getTokens().iterator();
/*  42 */     this.args = paramList;
/*  43 */     this.arg = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isExpanding(@Nonnull Macro paramMacro) {
/*  50 */     if (this.macro == paramMacro)
/*  51 */       return true; 
/*  52 */     return super.isExpanding(paramMacro);
/*     */   }
/*     */ 
/*     */   
/*     */   static void escape(@Nonnull StringBuilder paramStringBuilder, @Nonnull CharSequence paramCharSequence) {
/*  57 */     if (paramStringBuilder == null)
/*  58 */       throw new NullPointerException("Buffer was null."); 
/*  59 */     if (paramCharSequence == null)
/*  60 */       throw new NullPointerException("CharSequence was null."); 
/*  61 */     for (byte b = 0; b < paramCharSequence.length(); b++) {
/*  62 */       char c = paramCharSequence.charAt(b);
/*  63 */       switch (c) {
/*     */         case '\\':
/*  65 */           paramStringBuilder.append("\\\\");
/*     */           break;
/*     */         case '"':
/*  68 */           paramStringBuilder.append("\\\"");
/*     */           break;
/*     */         case '\n':
/*  71 */           paramStringBuilder.append("\\n");
/*     */           break;
/*     */         case '\r':
/*  74 */           paramStringBuilder.append("\\r");
/*     */           break;
/*     */         default:
/*  77 */           paramStringBuilder.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void concat(@Nonnull StringBuilder paramStringBuilder, @Nonnull Argument paramArgument) {
/*  83 */     for (Token token : paramArgument) {
/*  84 */       paramStringBuilder.append(token.getText());
/*     */     }
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   private Token stringify(@Nonnull Token paramToken, @Nonnull Argument paramArgument) {
/*  90 */     StringBuilder stringBuilder1 = new StringBuilder();
/*  91 */     concat(stringBuilder1, paramArgument);
/*     */     
/*  93 */     StringBuilder stringBuilder2 = new StringBuilder("\"");
/*  94 */     escape(stringBuilder2, stringBuilder1);
/*  95 */     stringBuilder2.append("\"");
/*     */     
/*  97 */     return new Token(292, paramToken
/*  98 */         .getLine(), paramToken.getColumn(), stringBuilder2
/*  99 */         .toString(), stringBuilder1.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isVariadicArgument(@Nonnegative int paramInt) {
/* 109 */     if (!this.macro.isVariadic())
/* 110 */       return false; 
/* 111 */     return (paramInt == this.args.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paste(@Nonnull Token paramToken) throws IOException, LexerException {
/* 120 */     StringBuilder stringBuilder = new StringBuilder();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     byte b1 = 2;
/*     */ 
/*     */     
/* 128 */     boolean bool = false;
/*     */     
/* 130 */     for (byte b2 = 0; b2 < b1; b2++) {
/* 131 */       int i; Argument argument; if (!this.tokens.hasNext()) {
/*     */         
/* 133 */         error(paramToken.getLine(), paramToken.getColumn(), "Paste at end of expansion");
/*     */         
/* 135 */         stringBuilder.append(' ').append(paramToken.getText());
/*     */         break;
/*     */       } 
/* 138 */       Token token = this.tokens.next();
/*     */       
/* 140 */       switch (token.getType()) {
/*     */ 
/*     */         
/*     */         case 297:
/* 144 */           b1 += 2;
/* 145 */           paramToken = token;
/*     */         
/*     */         case 296:
/* 148 */           i = ((Integer)token.getValue()).intValue();
/* 149 */           argument = this.args.get(i);
/* 150 */           if (bool && isVariadicArgument(i) && argument.isEmpty()) {
/*     */             
/* 152 */             stringBuilder.setLength(stringBuilder.length() - 1);
/*     */           } else {
/* 154 */             concat(stringBuilder, argument);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 260:
/*     */         case 261:
/* 171 */           bool = false; break;
/*     */         case 44:
/*     */           bool = true;
/*     */           stringBuilder.append(token.getText());
/*     */           break;
/*     */         default:
/*     */           stringBuilder.append(token.getText());
/*     */       } 
/*     */     } 
/* 180 */     StringLexerSource stringLexerSource = new StringLexerSource(stringBuilder.toString());
/*     */ 
/*     */     
/* 183 */     this.arg = new SourceIterator(stringLexerSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token token() throws IOException, LexerException {
/*     */     Token token;
/*     */     while (true) {
/*     */       int i;
/* 193 */       if (this.arg != null) {
/* 194 */         if (this.arg.hasNext()) {
/* 195 */           Token token1 = this.arg.next();
/*     */           
/* 197 */           assert token1.getType() != 297 : "Unexpected paste token";
/*     */           
/* 199 */           return token1;
/*     */         } 
/* 201 */         this.arg = null;
/*     */       } 
/*     */       
/* 204 */       if (!this.tokens.hasNext()) {
/* 205 */         return new Token(265, -1, -1, "");
/*     */       }
/* 207 */       token = this.tokens.next();
/*     */       
/* 209 */       switch (token.getType()) {
/*     */         
/*     */         case 298:
/* 212 */           i = ((Integer)token.getValue()).intValue();
/* 213 */           return stringify(token, this.args.get(i));
/*     */         
/*     */         case 296:
/* 216 */           i = ((Integer)token.getValue()).intValue();
/*     */           
/* 218 */           this.arg = ((Argument)this.args.get(i)).expansion();
/*     */           continue;
/*     */         case 297:
/* 221 */           paste(token); continue;
/*     */       }  break;
/*     */     } 
/* 224 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 232 */     StringBuilder stringBuilder = new StringBuilder();
/* 233 */     stringBuilder.append("expansion of ").append(this.macro.getName());
/* 234 */     Source source = getParent();
/* 235 */     if (source != null)
/* 236 */       stringBuilder.append(" in ").append(String.valueOf(source)); 
/* 237 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/MacroTokenSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */