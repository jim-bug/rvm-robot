/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SourceIterator
/*    */   implements Iterator<Token>
/*    */ {
/*    */   private final Source source;
/*    */   private Token tok;
/*    */   
/*    */   public SourceIterator(@Nonnull Source paramSource) {
/* 36 */     this.source = paramSource;
/* 37 */     this.tok = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void advance() {
/*    */     try {
/* 45 */       if (this.tok == null)
/* 46 */         this.tok = this.source.token(); 
/* 47 */     } catch (LexerException lexerException) {
/* 48 */       throw new IllegalStateException(lexerException);
/* 49 */     } catch (IOException iOException) {
/* 50 */       throw new IllegalStateException(iOException);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 63 */     advance();
/* 64 */     return (this.tok.getType() != 265);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Token next() {
/* 76 */     if (!hasNext())
/* 77 */       throw new NoSuchElementException(); 
/* 78 */     Token token = this.tok;
/* 79 */     this.tok = null;
/* 80 */     return token;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void remove() {
/* 90 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/SourceIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */