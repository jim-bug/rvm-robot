/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Token
/*     */ {
/*     */   private final int type;
/*     */   private int line;
/*     */   private int column;
/*     */   private final Object value;
/*     */   private final String text;
/*     */   public static final int AND_EQ = 257;
/*     */   public static final int ARROW = 258;
/*     */   public static final int CHARACTER = 259;
/*     */   public static final int CCOMMENT = 260;
/*     */   public static final int CPPCOMMENT = 261;
/*     */   public static final int DEC = 262;
/*     */   public static final int DIV_EQ = 263;
/*     */   public static final int ELLIPSIS = 264;
/*     */   public static final int EOF = 265;
/*     */   public static final int EQ = 266;
/*     */   public static final int GE = 267;
/*     */   public static final int HASH = 268;
/*     */   public static final int HEADER = 269;
/*     */   public static final int IDENTIFIER = 270;
/*     */   public static final int INC = 271;
/*     */   public static final int NUMBER = 272;
/*     */   public static final int LAND = 273;
/*     */   public static final int LAND_EQ = 274;
/*     */   public static final int LE = 275;
/*     */   
/*     */   public Token(int paramInt1, int paramInt2, int paramInt3, String paramString, Object paramObject) {
/*  38 */     this.type = paramInt1;
/*  39 */     this.line = paramInt2;
/*  40 */     this.column = paramInt3;
/*  41 */     this.text = paramString;
/*  42 */     this.value = paramObject;
/*     */   }
/*     */   public static final int LITERAL = 276; public static final int LOR = 277; public static final int LOR_EQ = 278; public static final int LSH = 279; public static final int LSH_EQ = 280; public static final int MOD_EQ = 281; public static final int MULT_EQ = 282; public static final int NE = 283; public static final int NL = 284; public static final int OR_EQ = 285; public static final int PASTE = 286; public static final int PLUS_EQ = 287; public static final int RANGE = 288; public static final int RSH = 289; public static final int RSH_EQ = 290; public static final int SQSTRING = 291; public static final int STRING = 292; public static final int SUB_EQ = 293; public static final int WHITESPACE = 294; public static final int XOR_EQ = 295; public static final int M_ARG = 296; public static final int M_PASTE = 297; public static final int M_STRING = 298; public static final int P_LINE = 299; public static final int INVALID = 300;
/*     */   public Token(int paramInt1, int paramInt2, int paramInt3, String paramString) {
/*  46 */     this(paramInt1, paramInt2, paramInt3, paramString, null);
/*     */   }
/*     */   
/*     */   Token(int paramInt, String paramString, Object paramObject) {
/*  50 */     this(paramInt, -1, -1, paramString, paramObject);
/*     */   }
/*     */   
/*     */   Token(int paramInt, String paramString) {
/*  54 */     this(paramInt, paramString, null);
/*     */   }
/*     */   
/*     */   Token(int paramInt) {
/*  58 */     this(paramInt, TokenType.getTokenText(paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/*  68 */     return this.type;
/*     */   }
/*     */   
/*     */   void setLocation(int paramInt1, int paramInt2) {
/*  72 */     this.line = paramInt1;
/*  73 */     this.column = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLine() {
/*  86 */     return this.line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/*  99 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 112 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 127 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 135 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 137 */     stringBuilder.append('[').append(getTokenName(this.type));
/* 138 */     if (this.line != -1) {
/* 139 */       stringBuilder.append('@').append(this.line);
/* 140 */       if (this.column != -1)
/* 141 */         stringBuilder.append(',').append(this.column); 
/*     */     } 
/* 143 */     stringBuilder.append("]:");
/* 144 */     if (this.text != null) {
/* 145 */       stringBuilder.append('"').append(this.text).append('"');
/* 146 */     } else if (this.type > 3 && this.type < 256) {
/* 147 */       stringBuilder.append((char)this.type);
/*     */     } else {
/* 149 */       stringBuilder.append('<').append(this.type).append('>');
/* 150 */     }  if (this.value != null)
/* 151 */       stringBuilder.append('=').append(this.value); 
/* 152 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public static String getTokenName(int paramInt) {
/* 166 */     return TokenType.getTokenName(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   static final Token space = new Token(294, -1, -1, " ");
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/Token.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */