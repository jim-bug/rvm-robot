/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class TokenSnifferSource
/*    */   extends Source
/*    */ {
/*    */   private final List<Token> target;
/*    */   
/*    */   TokenSnifferSource(List<Token> paramList) {
/* 30 */     this.target = paramList;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Token token() throws IOException, LexerException {
/* 36 */     Token token = getParent().token();
/* 37 */     if (token.getType() != 265)
/* 38 */       this.target.add(token); 
/* 39 */     return token;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     return getParent().toString();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/TokenSnifferSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */