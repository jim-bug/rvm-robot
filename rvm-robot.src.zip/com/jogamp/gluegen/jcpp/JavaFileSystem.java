/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaFileSystem
/*    */   implements VirtualFileSystem
/*    */ {
/*    */   public VirtualFile getFile(String paramString) {
/* 29 */     return new JavaFile(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public VirtualFile getFile(String paramString1, String paramString2) {
/* 34 */     return new JavaFile(paramString1, paramString2);
/*    */   }
/*    */   
/*    */   private class JavaFile
/*    */     extends File implements VirtualFile {
/*    */     public JavaFile(String param1String) {
/* 40 */       super(param1String);
/*    */     }
/*    */     
/*    */     public JavaFile(String param1String1, String param1String2) {
/* 44 */       super(param1String1, param1String2);
/*    */     }
/*    */ 
/*    */     
/*    */     public JavaFile(File param1File, String param1String) {
/* 49 */       super(param1File, param1String);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public JavaFile getParentFile() {
/* 60 */       String str = getParent();
/* 61 */       if (str != null)
/* 62 */         return new JavaFile(str); 
/* 63 */       File file = getAbsoluteFile();
/* 64 */       str = file.getParent();
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 69 */       return new JavaFile(str);
/*    */     }
/*    */ 
/*    */     
/*    */     public JavaFile getChildFile(String param1String) {
/* 74 */       return new JavaFile(this, param1String);
/*    */     }
/*    */ 
/*    */     
/*    */     public Source getSource() throws IOException {
/* 79 */       return new FileLexerSource(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/JavaFileSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */