package com.jogamp.gluegen.jcpp;

import java.io.IOException;
import javax.annotation.CheckForNull;
import javax.annotation.Nonnull;

public interface VirtualFile {
  boolean isFile();
  
  @Nonnull
  String getPath();
  
  @Nonnull
  String getName();
  
  @CheckForNull
  VirtualFile getParentFile();
  
  @Nonnull
  VirtualFile getChildFile(String paramString);
  
  @Nonnull
  Source getSource() throws IOException;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/VirtualFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */