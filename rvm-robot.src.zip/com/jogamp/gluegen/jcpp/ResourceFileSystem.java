/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.nio.charset.Charset;
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceFileSystem
/*    */   implements VirtualFileSystem
/*    */ {
/*    */   private final ClassLoader loader;
/*    */   private final Charset charset;
/*    */   
/*    */   public ResourceFileSystem(@Nonnull ClassLoader paramClassLoader, @Nonnull Charset paramCharset) {
/* 23 */     this.loader = paramClassLoader;
/* 24 */     this.charset = paramCharset;
/*    */   }
/*    */ 
/*    */   
/*    */   public VirtualFile getFile(String paramString) {
/* 29 */     return new ResourceFile(this.loader, paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public VirtualFile getFile(String paramString1, String paramString2) {
/* 34 */     return getFile(paramString1 + "/" + paramString2);
/*    */   }
/*    */   
/*    */   private class ResourceFile
/*    */     implements VirtualFile {
/*    */     private final ClassLoader loader;
/*    */     private final String path;
/*    */     
/*    */     public ResourceFile(ClassLoader param1ClassLoader, String param1String) {
/* 43 */       this.loader = param1ClassLoader;
/* 44 */       this.path = param1String;
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean isFile() {
/* 49 */       throw new UnsupportedOperationException("Not supported yet.");
/*    */     }
/*    */ 
/*    */     
/*    */     public String getPath() {
/* 54 */       return this.path;
/*    */     }
/*    */ 
/*    */     
/*    */     public String getName() {
/* 59 */       return this.path.substring(this.path.lastIndexOf('/') + 1);
/*    */     }
/*    */ 
/*    */     
/*    */     public ResourceFile getParentFile() {
/* 64 */       int i = this.path.lastIndexOf('/');
/* 65 */       if (i < 1)
/* 66 */         return null; 
/* 67 */       return new ResourceFile(this.loader, this.path.substring(0, i));
/*    */     }
/*    */ 
/*    */     
/*    */     public ResourceFile getChildFile(String param1String) {
/* 72 */       return new ResourceFile(this.loader, this.path + "/" + param1String);
/*    */     }
/*    */ 
/*    */     
/*    */     public Source getSource() throws IOException {
/* 77 */       InputStream inputStream = this.loader.getResourceAsStream(this.path);
/* 78 */       return new InputLexerSource(inputStream, ResourceFileSystem.this.charset);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/ResourceFileSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */