/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FixedTokenSource
/*    */   extends Source
/*    */ {
/* 25 */   private static final Token EOF = new Token(265, "<ts-eof>");
/*    */   
/*    */   private final List<Token> tokens;
/*    */   
/*    */   private int idx;
/*    */   
/*    */   FixedTokenSource(Token... paramVarArgs) {
/* 32 */     this.tokens = Arrays.asList(paramVarArgs);
/* 33 */     this.idx = 0;
/*    */   }
/*    */   
/*    */   FixedTokenSource(List<Token> paramList) {
/* 37 */     this.tokens = paramList;
/* 38 */     this.idx = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Token token() throws IOException, LexerException {
/* 45 */     if (this.idx >= this.tokens.size())
/* 46 */       return EOF; 
/* 47 */     return this.tokens.get(this.idx++);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     StringBuilder stringBuilder = new StringBuilder();
/* 53 */     stringBuilder.append("constant token stream ").append(this.tokens);
/* 54 */     Source source = getParent();
/* 55 */     if (source != null)
/* 56 */       stringBuilder.append(" in ").append(String.valueOf(source)); 
/* 57 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/FixedTokenSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */