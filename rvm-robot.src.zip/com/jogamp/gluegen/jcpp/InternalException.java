/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalException
/*    */   extends RuntimeException
/*    */ {
/*    */   public InternalException(String paramString) {
/* 29 */     super(paramString);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/InternalException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */