/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.annotation.CheckForNull;
/*     */ import javax.annotation.Nonnegative;
/*     */ import javax.annotation.Nonnull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TokenType
/*     */ {
/*  23 */   private static final List<TokenType> TYPES = new ArrayList<>(); private final String name;
/*     */   
/*     */   private static void addTokenType(@Nonnegative int paramInt, @Nonnull String paramString1, @CheckForNull String paramString2) {
/*  26 */     while (TYPES.size() <= paramInt)
/*  27 */       TYPES.add(null); 
/*  28 */     TYPES.set(paramInt, new TokenType(paramString1, paramString2));
/*     */   }
/*     */   private final String text;
/*     */   private static void addTokenType(@Nonnegative int paramInt, @Nonnull String paramString) {
/*  32 */     addTokenType(paramInt, paramString, null);
/*     */   }
/*     */   
/*     */   @CheckForNull
/*     */   public static TokenType getTokenType(@Nonnegative int paramInt) {
/*     */     try {
/*  38 */       return TYPES.get(paramInt);
/*  39 */     } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*  40 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public static String getTokenName(@Nonnegative int paramInt) {
/*  46 */     if (paramInt < 0)
/*  47 */       return "Invalid" + paramInt; 
/*  48 */     TokenType tokenType = getTokenType(paramInt);
/*  49 */     if (tokenType == null)
/*  50 */       return "Unknown" + paramInt; 
/*  51 */     return tokenType.getName();
/*     */   }
/*     */   
/*     */   @CheckForNull
/*     */   public static String getTokenText(@Nonnegative int paramInt) {
/*  56 */     TokenType tokenType = getTokenType(paramInt);
/*  57 */     if (tokenType == null)
/*  58 */       return null; 
/*  59 */     return tokenType.getText();
/*     */   }
/*     */   
/*     */   static {
/*  63 */     for (byte b = 0; b < 'ÿ'; b++) {
/*  64 */       String str = String.valueOf((char)b);
/*  65 */       addTokenType(b, str, str);
/*     */     } 
/*  67 */     addTokenType(257, "AND_EQ", "&=");
/*  68 */     addTokenType(258, "ARROW", "->");
/*  69 */     addTokenType(259, "CHARACTER");
/*  70 */     addTokenType(260, "CCOMMENT");
/*  71 */     addTokenType(261, "CPPCOMMENT");
/*  72 */     addTokenType(262, "DEC", "--");
/*  73 */     addTokenType(263, "DIV_EQ", "/=");
/*  74 */     addTokenType(264, "ELLIPSIS", "...");
/*  75 */     addTokenType(265, "EOF");
/*  76 */     addTokenType(266, "EQ", "==");
/*  77 */     addTokenType(267, "GE", ">=");
/*  78 */     addTokenType(268, "HASH", "#");
/*  79 */     addTokenType(269, "HEADER");
/*  80 */     addTokenType(270, "IDENTIFIER");
/*  81 */     addTokenType(271, "INC", "++");
/*  82 */     addTokenType(272, "NUMBER");
/*  83 */     addTokenType(273, "LAND", "&&");
/*  84 */     addTokenType(274, "LAND_EQ", "&&=");
/*  85 */     addTokenType(275, "LE", "<=");
/*  86 */     addTokenType(276, "LITERAL");
/*  87 */     addTokenType(277, "LOR", "||");
/*  88 */     addTokenType(278, "LOR_EQ", "||=");
/*  89 */     addTokenType(279, "LSH", "<<");
/*  90 */     addTokenType(280, "LSH_EQ", "<<=");
/*  91 */     addTokenType(281, "MOD_EQ", "%=");
/*  92 */     addTokenType(282, "MULT_EQ", "*=");
/*  93 */     addTokenType(283, "NE", "!=");
/*  94 */     addTokenType(284, "NL");
/*  95 */     addTokenType(285, "OR_EQ", "|=");
/*  96 */     addTokenType(286, "PASTE", "##");
/*  97 */     addTokenType(287, "PLUS_EQ", "+=");
/*  98 */     addTokenType(288, "RANGE", "..");
/*  99 */     addTokenType(289, "RSH", ">>");
/* 100 */     addTokenType(290, "RSH_EQ", ">>=");
/* 101 */     addTokenType(291, "SQSTRING");
/* 102 */     addTokenType(292, "STRING");
/* 103 */     addTokenType(293, "SUB_EQ", "-=");
/* 104 */     addTokenType(294, "WHITESPACE");
/* 105 */     addTokenType(295, "XOR_EQ", "^=");
/* 106 */     addTokenType(296, "M_ARG");
/* 107 */     addTokenType(297, "M_PASTE");
/* 108 */     addTokenType(298, "M_STRING");
/* 109 */     addTokenType(299, "P_LINE");
/* 110 */     addTokenType(300, "INVALID");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TokenType(@Nonnull String paramString1, @CheckForNull String paramString2) {
/* 117 */     this.name = paramString1;
/* 118 */     this.text = paramString2;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public String getName() {
/* 123 */     return this.name;
/*     */   }
/*     */   
/*     */   @CheckForNull
/*     */   public String getText() {
/* 128 */     return this.text;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/TokenType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */