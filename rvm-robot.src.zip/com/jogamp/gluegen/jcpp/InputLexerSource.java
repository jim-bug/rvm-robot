/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import java.nio.charset.Charset;
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputLexerSource
/*    */   extends LexerSource
/*    */ {
/*    */   @Deprecated
/*    */   public InputLexerSource(@Nonnull InputStream paramInputStream) {
/* 36 */     this(paramInputStream, Charset.defaultCharset());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InputLexerSource(@Nonnull InputStream paramInputStream, Charset paramCharset) {
/* 45 */     this(new InputStreamReader(paramInputStream, paramCharset));
/*    */   }
/*    */   
/*    */   public InputLexerSource(@Nonnull Reader paramReader, boolean paramBoolean) {
/* 49 */     super(paramReader, true);
/*    */   }
/*    */   
/*    */   public InputLexerSource(@Nonnull Reader paramReader) {
/* 53 */     this(paramReader, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPath() {
/* 58 */     return "<standard-input>";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 63 */     return "standard input";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     return String.valueOf(getPath());
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/InputLexerSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */