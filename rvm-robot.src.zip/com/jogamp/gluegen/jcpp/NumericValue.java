/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import javax.annotation.CheckForNull;
/*     */ import javax.annotation.CheckForSigned;
/*     */ import javax.annotation.Nonnegative;
/*     */ import javax.annotation.Nonnull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumericValue
/*     */   extends Number
/*     */ {
/*     */   public static final int F_UNSIGNED = 1;
/*     */   public static final int F_INT = 2;
/*     */   public static final int F_LONG = 4;
/*     */   public static final int F_LONGLONG = 8;
/*     */   public static final int F_FLOAT = 16;
/*     */   public static final int F_DOUBLE = 32;
/*     */   public static final int FF_SIZE = 62;
/*     */   private final int base;
/*     */   private final String integer;
/*     */   private String fraction;
/*  40 */   private int expbase = 0;
/*     */   private String exponent;
/*     */   private int flags;
/*     */   
/*     */   public NumericValue(@Nonnegative int paramInt, @Nonnull String paramString) {
/*  45 */     this.base = paramInt;
/*  46 */     this.integer = paramString;
/*     */   }
/*     */   
/*     */   @Nonnegative
/*     */   public int getBase() {
/*  51 */     return this.base;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public String getIntegerPart() {
/*  56 */     return this.integer;
/*     */   }
/*     */   
/*     */   @CheckForNull
/*     */   public String getFractionalPart() {
/*  61 */     return this.fraction;
/*     */   }
/*     */   
/*     */   void setFractionalPart(@Nonnull String paramString) {
/*  65 */     this.fraction = paramString;
/*     */   }
/*     */   
/*     */   @CheckForSigned
/*     */   public int getExponentBase() {
/*  70 */     return this.expbase;
/*     */   }
/*     */   
/*     */   @CheckForNull
/*     */   public String getExponent() {
/*  75 */     return this.exponent;
/*     */   }
/*     */   
/*     */   void setExponent(@Nonnegative int paramInt, @Nonnull String paramString) {
/*  79 */     this.expbase = paramInt;
/*  80 */     this.exponent = paramString;
/*     */   }
/*     */   
/*     */   public int getFlags() {
/*  84 */     return this.flags;
/*     */   }
/*     */   
/*     */   void setFlags(int paramInt) {
/*  88 */     this.flags = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public BigDecimal toBigDecimal() {
/*  98 */     int i = 0;
/*  99 */     String str1 = getIntegerPart();
/* 100 */     String str2 = getFractionalPart();
/* 101 */     if (str2 != null) {
/* 102 */       str1 = str1 + getFractionalPart();
/*     */       
/* 104 */       i += str2.length();
/*     */     } 
/* 106 */     String str3 = getExponent();
/* 107 */     if (str3 != null)
/* 108 */       i -= Integer.parseInt(str3); 
/* 109 */     BigInteger bigInteger = new BigInteger(str1, getBase());
/* 110 */     return new BigDecimal(bigInteger, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public Number toJavaLangNumber() {
/* 119 */     int i = getFlags();
/* 120 */     if ((i & 0x20) != 0)
/* 121 */       return Double.valueOf(doubleValue()); 
/* 122 */     if ((i & 0x10) != 0)
/* 123 */       return Float.valueOf(floatValue()); 
/* 124 */     if ((i & 0xC) != 0)
/* 125 */       return Long.valueOf(longValue()); 
/* 126 */     if ((i & 0x2) != 0)
/* 127 */       return Integer.valueOf(intValue()); 
/* 128 */     if (getFractionalPart() != null)
/* 129 */       return Double.valueOf(doubleValue()); 
/* 130 */     if (getExponent() != null) {
/* 131 */       return Double.valueOf(doubleValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 136 */     long l = longValue();
/* 137 */     if (l <= 2147483647L && l >= -2147483648L)
/* 138 */       return Integer.valueOf((int)l); 
/* 139 */     return Long.valueOf(l);
/*     */   }
/*     */ 
/*     */   
/*     */   private int exponentValue() {
/* 144 */     return Integer.parseInt(this.exponent, 10);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int intValue() {
/* 150 */     int i = (this.integer.length() == 0) ? 0 : Integer.parseInt(this.integer, this.base);
/* 151 */     if (this.expbase == 2) {
/* 152 */       i <<= exponentValue();
/* 153 */     } else if (this.expbase != 0) {
/* 154 */       i = (int)(i * Math.pow(this.expbase, exponentValue()));
/* 155 */     }  return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long longValue() {
/* 161 */     long l = (this.integer.length() == 0) ? 0L : Long.parseLong(this.integer, this.base);
/* 162 */     if (this.expbase == 2) {
/* 163 */       l <<= exponentValue();
/* 164 */     } else if (this.expbase != 0) {
/* 165 */       l = (long)(l * Math.pow(this.expbase, exponentValue()));
/* 166 */     }  return l;
/*     */   }
/*     */ 
/*     */   
/*     */   public float floatValue() {
/* 171 */     if (getBase() != 10)
/* 172 */       return (float)longValue(); 
/* 173 */     return Float.parseFloat(toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public double doubleValue() {
/* 178 */     if (getBase() != 10)
/* 179 */       return longValue(); 
/* 180 */     return Double.parseDouble(toString());
/*     */   }
/*     */   
/*     */   private boolean appendFlags(StringBuilder paramStringBuilder, String paramString, int paramInt) {
/* 184 */     if ((getFlags() & paramInt) != paramInt)
/* 185 */       return false; 
/* 186 */     paramStringBuilder.append(paramString);
/* 187 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 192 */     StringBuilder stringBuilder = new StringBuilder();
/* 193 */     switch (this.base) {
/*     */       case 8:
/* 195 */         stringBuilder.append('0');
/*     */         break;
/*     */       case 10:
/*     */         break;
/*     */       case 16:
/* 200 */         stringBuilder.append("0x");
/*     */         break;
/*     */       case 2:
/* 203 */         stringBuilder.append('b');
/*     */         break;
/*     */       default:
/* 206 */         stringBuilder.append("[base-").append(this.base).append("]");
/*     */         break;
/*     */     } 
/* 209 */     stringBuilder.append(getIntegerPart());
/* 210 */     if (getFractionalPart() != null)
/* 211 */       stringBuilder.append('.').append(getFractionalPart()); 
/* 212 */     if (getExponent() != null) {
/* 213 */       stringBuilder.append((this.base > 10) ? 112 : 101);
/* 214 */       stringBuilder.append(getExponent());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/NumericValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */