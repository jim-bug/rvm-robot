/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.StringReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringLexerSource
/*    */   extends LexerSource
/*    */ {
/*    */   public StringLexerSource(String paramString, boolean paramBoolean) {
/* 37 */     super(new StringReader(paramString), paramBoolean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StringLexerSource(String paramString) {
/* 51 */     this(paramString, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 56 */     return "string literal";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/StringLexerSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */