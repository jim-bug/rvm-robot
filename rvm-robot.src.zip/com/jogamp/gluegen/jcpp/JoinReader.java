/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JoinReader
/*     */   implements Closeable
/*     */ {
/*     */   private final Reader in;
/*     */   private PreprocessorListener listener;
/*     */   private LexerSource source;
/*     */   private boolean trigraphs;
/*     */   private boolean warnings;
/*     */   private int newlines;
/*     */   private boolean flushnl;
/*     */   private int[] unget;
/*     */   private int uptr;
/*     */   
/*     */   public JoinReader(Reader paramReader, boolean paramBoolean) {
/*  38 */     this.in = paramReader;
/*  39 */     this.trigraphs = paramBoolean;
/*  40 */     this.newlines = 0;
/*  41 */     this.flushnl = false;
/*  42 */     this.unget = new int[2];
/*  43 */     this.uptr = 0;
/*     */   }
/*     */   
/*     */   public JoinReader(Reader paramReader) {
/*  47 */     this(paramReader, false);
/*     */   }
/*     */   
/*     */   public void setTrigraphs(boolean paramBoolean1, boolean paramBoolean2) {
/*  51 */     this.trigraphs = paramBoolean1;
/*  52 */     this.warnings = paramBoolean2;
/*     */   }
/*     */   
/*     */   void init(Preprocessor paramPreprocessor, LexerSource paramLexerSource) {
/*  56 */     this.listener = paramPreprocessor.getListener();
/*  57 */     this.source = paramLexerSource;
/*  58 */     setTrigraphs(paramPreprocessor.getFeature(Feature.TRIGRAPHS), paramPreprocessor
/*  59 */         .getWarning(Warning.TRIGRAPHS));
/*     */   }
/*     */   
/*     */   private int __read() throws IOException {
/*  63 */     if (this.uptr > 0)
/*  64 */       return this.unget[--this.uptr]; 
/*  65 */     return this.in.read();
/*     */   }
/*     */   
/*     */   private void _unread(int paramInt) {
/*  69 */     if (paramInt != -1)
/*  70 */       this.unget[this.uptr++] = paramInt; 
/*  71 */     assert this.uptr <= this.unget.length : "JoinReader ungets too many characters";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void warning(String paramString) throws LexerException {
/*  77 */     if (this.source != null) {
/*  78 */       this.source.warning(paramString);
/*     */     } else {
/*  80 */       throw new LexerException(paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   private char trigraph(char paramChar1, char paramChar2) throws IOException, LexerException {
/*  85 */     if (this.trigraphs) {
/*  86 */       if (this.warnings)
/*  87 */         warning("trigraph ??" + paramChar1 + " converted to " + paramChar2); 
/*  88 */       return paramChar2;
/*     */     } 
/*  90 */     if (this.warnings)
/*  91 */       warning("trigraph ??" + paramChar1 + " ignored"); 
/*  92 */     _unread(paramChar1);
/*  93 */     _unread(63);
/*  94 */     return '?';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int _read() throws IOException, LexerException {
/* 100 */     int i = __read();
/* 101 */     if (i == 63 && (this.trigraphs || this.warnings)) {
/* 102 */       int j = __read();
/* 103 */       if (j == 63) {
/* 104 */         int k = __read();
/* 105 */         switch (k) {
/*     */           case 40:
/* 107 */             return trigraph('(', '[');
/*     */           case 41:
/* 109 */             return trigraph(')', ']');
/*     */           case 60:
/* 111 */             return trigraph('<', '{');
/*     */           case 62:
/* 113 */             return trigraph('>', '}');
/*     */           case 61:
/* 115 */             return trigraph('=', '#');
/*     */           case 47:
/* 117 */             return trigraph('/', '\\');
/*     */           case 39:
/* 119 */             return trigraph('\'', '^');
/*     */           case 33:
/* 121 */             return trigraph('!', '|');
/*     */           case 45:
/* 123 */             return trigraph('-', '~');
/*     */         } 
/* 125 */         _unread(k);
/*     */       } 
/* 127 */       _unread(j);
/*     */     } 
/* 129 */     return i;
/*     */   }
/*     */   
/*     */   public int read() throws IOException, LexerException {
/*     */     int i;
/* 134 */     if (this.flushnl) {
/* 135 */       if (this.newlines > 0) {
/* 136 */         this.newlines--;
/* 137 */         return 10;
/*     */       } 
/* 139 */       this.flushnl = false;
/*     */     } 
/*     */     while (true)
/*     */     { int j, k;
/* 143 */       i = _read();
/* 144 */       switch (i)
/*     */       { case 92:
/* 146 */           j = _read();
/* 147 */           switch (j) {
/*     */             case 10:
/* 149 */               this.newlines++;
/*     */               continue;
/*     */             case 13:
/* 152 */               this.newlines++;
/* 153 */               k = _read();
/* 154 */               if (k != 10)
/* 155 */                 _unread(k); 
/*     */               continue;
/*     */           } 
/* 158 */           _unread(j);
/* 159 */           return i;
/*     */         
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 133:
/*     */         case 8232:
/*     */         case 8233:
/* 168 */           this.flushnl = true;
/* 169 */           return i;
/*     */         case -1:
/* 171 */           if (this.newlines > 0) {
/* 172 */             this.newlines--;
/* 173 */             return 10;
/*     */           } 
/*     */           
/* 176 */           return i; }  break; }  return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException, LexerException {
/* 183 */     for (byte b = 0; b < paramInt2; b++) {
/* 184 */       int i = read();
/* 185 */       if (i == -1)
/* 186 */         return b; 
/* 187 */       paramArrayOfchar[paramInt1 + b] = (char)i;
/*     */     } 
/* 189 */     return paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 195 */     this.in.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 200 */     return "JoinReader(nl=" + this.newlines + ")";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/JoinReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */