/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Warning
/*    */ {
/* 24 */   TRIGRAPHS,
/*    */   
/* 26 */   IMPORT,
/* 27 */   UNDEF,
/* 28 */   UNUSED_MACROS,
/* 29 */   ENDIF_LABELS,
/* 30 */   ERROR;
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/Warning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */