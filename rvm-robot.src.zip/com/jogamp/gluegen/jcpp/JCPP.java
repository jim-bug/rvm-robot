/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ import com.jogamp.gluegen.ConstantDefinition;
/*     */ import com.jogamp.gluegen.GenericCPP;
/*     */ import com.jogamp.gluegen.GlueGenException;
/*     */ import com.jogamp.gluegen.Logging;
/*     */ import java.io.File;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JCPP
/*     */   implements GenericCPP
/*     */ {
/*     */   private final Logging.LoggerIf LOG;
/*     */   public final Preprocessor cpp;
/*     */   private OutputStream out;
/*     */   private final List<String> includePaths;
/*     */   private final boolean enableCopyOutput2Stderr;
/*     */   
/*     */   public JCPP(List<String> paramList, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  48 */     this.LOG = Logging.getLogger(JCPP.class);
/*  49 */     setOut(System.out);
/*  50 */     this.includePaths = paramList;
/*  51 */     this.enableCopyOutput2Stderr = paramBoolean2;
/*     */     
/*  53 */     this.cpp = new Preprocessor();
/*  54 */     this.cpp.addFeature(Feature.DIGRAPHS);
/*  55 */     this.cpp.addFeature(Feature.TRIGRAPHS);
/*  56 */     this.cpp.addFeature(Feature.LINEMARKERS);
/*  57 */     this.cpp.addFeature(Feature.UNIFIED_OUTPUT);
/*  58 */     this.cpp.addFeature(Feature.CSYNTAX);
/*  59 */     this.cpp.addFeature(Feature.KEEPCOMMENTS);
/*  60 */     if (paramBoolean3) {
/*  61 */       this.cpp.addFeature(Feature.PRAGMA_ONCE);
/*     */     }
/*  63 */     this.cpp.addWarning(Warning.IMPORT);
/*  64 */     this.cpp.setListener(new DefaultPreprocessorListener()
/*     */         {
/*     */           public void handleError(Source param1Source, int param1Int1, int param1Int2, String param1String) throws LexerException
/*     */           {
/*  68 */             super.handleError(param1Source, param1Int1, param1Int2, param1String);
/*  69 */             throw new GlueGenException(param1String, new ASTLocusTag(param1Source.getPath(), param1Int1, param1Int2, null));
/*     */           }
/*     */         });
/*  72 */     if (paramBoolean1) {
/*  73 */       this.cpp.addFeature(Feature.DEBUG);
/*     */     }
/*  75 */     this.cpp.setSystemIncludePath(paramList);
/*  76 */     this.cpp.setQuoteIncludePath(paramList);
/*     */     
/*  78 */     if (this.cpp.getFeature(Feature.DEBUG)) {
/*  79 */       this.LOG.info("#include \"...\" search starts here:");
/*  80 */       for (String str : this.cpp.getQuoteIncludePath())
/*  81 */         this.LOG.info("  " + str); 
/*  82 */       this.LOG.info("#include <...> search starts here:");
/*  83 */       for (String str : this.cpp.getSystemIncludePath())
/*  84 */         this.LOG.info("  " + str); 
/*  85 */       this.LOG.info("End of search list.");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addDefine(String paramString1, String paramString2) throws LexerException {
/*  91 */     this.cpp.addMacro(paramString1, paramString2);
/*     */   }
/*     */   
/*     */   public List<ConstantDefinition> getConstantDefinitions() throws GlueGenException {
/*     */     List<Macro> list;
/*  96 */     ArrayList<ConstantDefinition> arrayList = new ArrayList();
/*     */     
/*     */     try {
/*  99 */       list = this.cpp.getMacros(true);
/* 100 */     } catch (Throwable throwable) {
/* 101 */       throw new GlueGenException(throwable);
/*     */     } 
/* 103 */     int i = list.size();
/* 104 */     for (byte b = 0; b < i; b++) {
/* 105 */       Macro macro = list.get(b);
/* 106 */       String str = macro.getName();
/* 107 */       if (!"__GLUEGEN__".equals(str) && 
/* 108 */         !macro.isFunctionLike()) {
/* 109 */         String str1 = macro.getText();
/* 110 */         if (ConstantDefinition.isConstantExpression(str1)) {
/* 111 */           Source source = macro.getSource();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 116 */           ASTLocusTag aSTLocusTag = new ASTLocusTag((null != source) ? source.getPath() : "<programmatic>", (null != source) ? source.getLine() : -1, (null != source) ? source.getColumn() : -1, macro.toString());
/* 117 */           ConstantDefinition constantDefinition = new ConstantDefinition(macro.getName(), str1, null, aSTLocusTag);
/* 118 */           arrayList.add(constantDefinition);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 123 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   public String findFile(String paramString) {
/* 128 */     String str = File.separator;
/* 129 */     for (String str1 : this.includePaths) {
/* 130 */       String str2 = str1 + str + paramString;
/* 131 */       File file = new File(str2);
/* 132 */       if (file.exists()) {
/* 133 */         return str2;
/*     */       }
/*     */     } 
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream out() {
/* 141 */     return this.out;
/*     */   }
/*     */   
/*     */   public void setOut(OutputStream paramOutputStream) {
/* 145 */     this.out = paramOutputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run(Reader paramReader, final String filename) throws GlueGenException {
/* 150 */     PrintWriter printWriter = new PrintWriter(this.out);
/* 151 */     this.cpp.addInput(new LexerSource(paramReader, true) {
/*     */           public String getPath() {
/* 153 */             return filename;
/*     */           } public String getName() {
/* 155 */             return filename;
/*     */           }
/* 157 */           public String toString() { return "file " + filename; }
/*     */         });
/*     */     try {
/*     */       while (true) {
/* 161 */         Token token = this.cpp.token();
/* 162 */         if (token == null)
/*     */           break; 
/* 164 */         if (token.getType() == 265)
/*     */           break; 
/* 166 */         String str = token.getText();
/* 167 */         printWriter.print(str);
/* 168 */         if (this.enableCopyOutput2Stderr) {
/* 169 */           System.err.print(str);
/* 170 */           System.err.flush();
/*     */         } 
/*     */       } 
/* 173 */       printWriter.flush();
/* 174 */     } catch (Exception exception) {
/* 175 */       StringBuilder stringBuilder = new StringBuilder("Preprocessor failed:\n");
/* 176 */       Source source = this.cpp.getSource();
/* 177 */       while (source != null) {
/* 178 */         stringBuilder.append(" -> ").append(source).append("\n");
/* 179 */         source = source.getParent();
/*     */       } 
/* 181 */       stringBuilder.append(" : {0}\n");
/* 182 */       this.LOG.log(Level.SEVERE, stringBuilder.toString(), exception);
/* 183 */       if (exception instanceof GlueGenException) {
/* 184 */         throw (GlueGenException)exception;
/*     */       }
/* 186 */       throw new GlueGenException("Preprocessor failed", new ASTLocusTag(
/* 187 */             (null != source) ? source.getPath() : "n/a", 
/* 188 */             (null != source) ? source.getLine() : -1, 
/* 189 */             (null != source) ? source.getColumn() : -1, null), exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/JCPP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */