/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import com.jogamp.gluegen.Logging;
/*    */ import javax.annotation.Nonnegative;
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultPreprocessorListener
/*    */   implements PreprocessorListener
/*    */ {
/*    */   private final Logging.LoggerIf LOG;
/*    */   private int errors;
/*    */   private int warnings;
/*    */   
/*    */   public DefaultPreprocessorListener() {
/* 40 */     this.LOG = Logging.getLogger(DefaultPreprocessorListener.class);
/* 41 */     clear();
/*    */   }
/*    */   
/*    */   public void clear() {
/* 45 */     this.errors = 0;
/* 46 */     this.warnings = 0;
/*    */   }
/*    */   
/*    */   @Nonnegative
/*    */   public int getErrors() {
/* 51 */     return this.errors;
/*    */   }
/*    */   
/*    */   @Nonnegative
/*    */   public int getWarnings() {
/* 56 */     return this.warnings;
/*    */   }
/*    */   
/*    */   protected void print(@Nonnull String paramString) {
/* 60 */     this.LOG.info(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handleWarning(Source paramSource, int paramInt1, int paramInt2, String paramString) throws LexerException {
/* 74 */     this.warnings++;
/* 75 */     print(paramSource.getName() + ":" + paramInt1 + ":" + paramInt2 + ": warning: " + paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handleError(Source paramSource, int paramInt1, int paramInt2, String paramString) throws LexerException {
/* 90 */     this.errors++;
/* 91 */     print(paramSource.getName() + ":" + paramInt1 + ":" + paramInt2 + ": error: " + paramString);
/*    */   }
/*    */   
/*    */   public void handleSourceChange(Source paramSource, PreprocessorListener.SourceChangeEvent paramSourceChangeEvent) {}
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/DefaultPreprocessorListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */