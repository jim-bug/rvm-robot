/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class State
/*    */ {
/*    */   boolean parent;
/*    */   boolean active;
/*    */   boolean sawElse;
/*    */   
/*    */   State() {
/* 26 */     this.parent = true;
/* 27 */     this.active = true;
/* 28 */     this.sawElse = false;
/*    */   }
/*    */   
/*    */   State(State paramState) {
/* 32 */     this.parent = (paramState.isParentActive() && paramState.isActive());
/* 33 */     this.active = true;
/* 34 */     this.sawElse = false;
/*    */   }
/*    */ 
/*    */   
/*    */   void setParentActive(boolean paramBoolean) {
/* 39 */     this.parent = paramBoolean;
/*    */   }
/*    */   
/*    */   boolean isParentActive() {
/* 43 */     return this.parent;
/*    */   }
/*    */   
/*    */   void setActive(boolean paramBoolean) {
/* 47 */     this.active = paramBoolean;
/*    */   }
/*    */   
/*    */   boolean isActive() {
/* 51 */     return this.active;
/*    */   }
/*    */   
/*    */   void setSawElse() {
/* 55 */     this.sawElse = true;
/*    */   }
/*    */   
/*    */   boolean sawElse() {
/* 59 */     return this.sawElse;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 64 */     return "parent=" + this.parent + ", active=" + this.active + ", sawelse=" + this.sawElse;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/State.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */