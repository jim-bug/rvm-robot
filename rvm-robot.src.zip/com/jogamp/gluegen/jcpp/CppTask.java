/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.taskdefs.Copy;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CppTask
/*     */   extends Copy
/*     */ {
/*     */   private class Listener
/*     */     extends DefaultPreprocessorListener
/*     */   {
/*     */     private Listener() {}
/*     */     
/*     */     protected void print(String param1String) {
/*  39 */       CppTask.this.log(param1String);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Macro
/*     */   {
/*     */     private String name;
/*     */     private String value;
/*     */     
/*     */     public void setName(String param1String) {
/*  49 */       this.name = param1String;
/*     */     }
/*     */     
/*     */     public String getName() {
/*  53 */       return this.name;
/*     */     }
/*     */     
/*     */     public void setValue(String param1String) {
/*  57 */       this.value = param1String;
/*     */     }
/*     */     
/*     */     public String getValue() {
/*  61 */       return this.value;
/*     */     }
/*     */   }
/*     */   
/*  65 */   private final Listener listener = new Listener();
/*  66 */   private final List<Macro> macros = new ArrayList<>();
/*     */   private Path systemincludepath;
/*     */   private Path localincludepath;
/*     */   
/*     */   public void addMacro(Macro paramMacro) {
/*  71 */     this.macros.add(paramMacro);
/*     */   }
/*     */   
/*     */   public void addSystemincludepath(Path paramPath) {
/*  75 */     if (this.systemincludepath == null)
/*  76 */       this.systemincludepath = new Path(getProject()); 
/*  77 */     this.systemincludepath.add(paramPath);
/*     */   }
/*     */   
/*     */   public void addLocalincludepath(Path paramPath) {
/*  81 */     if (this.localincludepath == null)
/*  82 */       this.localincludepath = new Path(getProject()); 
/*  83 */     this.localincludepath.add(paramPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void preprocess(File paramFile1, File paramFile2) throws Exception {
/* 118 */     if (paramFile1 == null)
/* 119 */       throw new BuildException("Input not specified"); 
/* 120 */     if (paramFile2 == null) {
/* 121 */       throw new BuildException("Output not specified");
/*     */     }
/* 123 */     Preprocessor preprocessor = new Preprocessor();
/* 124 */     preprocessor.setListener(this.listener);
/* 125 */     for (Macro macro : this.macros)
/* 126 */       preprocessor.addMacro(macro.getName(), macro.getValue()); 
/* 127 */     if (this.systemincludepath != null)
/* 128 */       preprocessor.setSystemIncludePath(Arrays.asList(this.systemincludepath.list())); 
/* 129 */     if (this.localincludepath != null) {
/* 130 */       preprocessor.setQuoteIncludePath(Arrays.asList(this.localincludepath.list()));
/*     */     }
/* 132 */     File file = paramFile2.getParentFile();
/* 133 */     if (!file.exists()) {
/* 134 */       if (!file.mkdirs())
/* 135 */         throw new BuildException("Failed to make parent directory " + file); 
/* 136 */     } else if (!file.isDirectory()) {
/* 137 */       throw new BuildException("Parent directory of output file " + paramFile2 + " exists, but is not a directory.");
/*     */     } 
/* 139 */     FileWriter fileWriter = null;
/*     */     try {
/* 141 */       preprocessor.addInput(paramFile1);
/* 142 */       fileWriter = new FileWriter(paramFile2);
/*     */       while (true) {
/* 144 */         Token token = preprocessor.token();
/* 145 */         if (token == null)
/*     */           break; 
/* 147 */         if (token.getType() == 265)
/*     */           break; 
/* 149 */         fileWriter.write(token.getText());
/*     */       } 
/*     */     } finally {
/* 152 */       if (fileWriter != null) {
/*     */         try {
/* 154 */           fileWriter.close();
/* 155 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFileOperations() {
/* 163 */     if (this.fileCopyMap.size() > 0) {
/* 164 */       log("Copying " + this.fileCopyMap.size() + " file" + (
/* 165 */           (this.fileCopyMap.size() == 1) ? "" : "s") + " to " + this.destDir
/* 166 */           .getAbsolutePath());
/*     */       
/* 168 */       Enumeration<String> enumeration = this.fileCopyMap.keys();
/*     */       
/* 170 */       while (enumeration.hasMoreElements()) {
/* 171 */         String str = enumeration.nextElement();
/* 172 */         String[] arrayOfString = (String[])this.fileCopyMap.get(str);
/*     */         
/* 174 */         for (String str1 : arrayOfString) {
/* 175 */           if (str.equals(str1)) {
/* 176 */             log("Skipping self-copy of " + str, this.verbosity);
/*     */           } else {
/*     */ 
/*     */             
/*     */             try {
/* 181 */               log("Copying " + str + " to " + str1, this.verbosity);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 196 */               File file1 = new File(str);
/* 197 */               File file2 = new File(str1);
/* 198 */               preprocess(file1, file2);
/* 199 */             } catch (Exception exception) {
/*     */ 
/*     */               
/* 202 */               String str2 = "Failed to copy " + str + " to " + str1 + " due to " + exception.getMessage();
/* 203 */               File file = new File(str1);
/* 204 */               if (file.exists() && !file.delete()) {
/* 205 */                 str2 = str2 + " and I couldn't delete the corrupt " + str1;
/*     */               }
/* 207 */               throw new BuildException(str2, exception, getLocation());
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/CppTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */