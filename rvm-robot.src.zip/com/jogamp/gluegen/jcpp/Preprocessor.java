/*      */ package com.jogamp.gluegen.jcpp;
/*      */ 
/*      */ import com.jogamp.gluegen.Logging;
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.TreeMap;
/*      */ import java.util.regex.Matcher;
/*      */ import javax.annotation.CheckForNull;
/*      */ import javax.annotation.Nonnull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Preprocessor
/*      */   implements Closeable
/*      */ {
/*      */   private final Logging.LoggerIf LOG;
/*      */   
/*   85 */   private static final Source INTERNAL = new Source()
/*      */     {
/*      */       
/*      */       public Token token() throws IOException, LexerException
/*      */       {
/*   90 */         throw new LexerException("Cannot read from " + getName());
/*      */       }
/*      */ 
/*      */       
/*      */       public String getPath() {
/*   95 */         return "<internal-data>";
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  100 */         return "internal data";
/*      */       }
/*      */     };
/*  103 */   private static final Macro __LINE__ = new Macro(INTERNAL, "__LINE__");
/*  104 */   private static final Macro __FILE__ = new Macro(INTERNAL, "__FILE__");
/*  105 */   private static final Macro __COUNTER__ = new Macro(INTERNAL, "__COUNTER__");
/*      */   
/*      */   private final List<Source> inputs;
/*      */   
/*      */   private final Map<String, Macro> macros;
/*      */   
/*      */   private final Stack<State> states;
/*      */   
/*      */   private Source source;
/*      */   
/*      */   private int counter;
/*  116 */   private final Set<String> onceseenpaths = new HashSet<>();
/*  117 */   private final List<VirtualFile> includes = new ArrayList<>();
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> quoteincludepath;
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> sysincludepath;
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> frameworkspath;
/*      */ 
/*      */ 
/*      */   
/*      */   private final Set<Feature> features;
/*      */ 
/*      */   
/*      */   private final Set<Warning> warnings;
/*      */ 
/*      */   
/*      */   private VirtualFileSystem filesystem;
/*      */ 
/*      */   
/*      */   private PreprocessorListener listener;
/*      */ 
/*      */   
/*      */   private Token source_token;
/*      */ 
/*      */   
/*      */   @CheckForNull
/*      */   private Token expr_token;
/*      */ 
/*      */ 
/*      */   
/*      */   public Preprocessor(@Nonnull Source paramSource) {
/*  154 */     this();
/*  155 */     addInput(paramSource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Preprocessor(@Nonnull File paramFile) throws IOException {
/*  163 */     this(new FileLexerSource(paramFile));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFileSystem(@Nonnull VirtualFileSystem paramVirtualFileSystem) {
/*  170 */     this.filesystem = paramVirtualFileSystem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public VirtualFileSystem getFileSystem() {
/*  178 */     return this.filesystem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListener(@Nonnull PreprocessorListener paramPreprocessorListener) {
/*  189 */     this.listener = paramPreprocessorListener;
/*  190 */     Source source = this.source;
/*  191 */     while (source != null) {
/*      */       
/*  193 */       source.init(this);
/*  194 */       source = source.getParent();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public PreprocessorListener getListener() {
/*  204 */     return this.listener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public Set<Feature> getFeatures() {
/*  214 */     return this.features;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFeature(@Nonnull Feature paramFeature) {
/*  221 */     this.features.add(paramFeature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFeatures(@Nonnull Collection<Feature> paramCollection) {
/*  228 */     this.features.addAll(paramCollection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFeatures(Feature... paramVarArgs) {
/*  235 */     addFeatures(Arrays.asList(paramVarArgs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFeature(@Nonnull Feature paramFeature) {
/*  243 */     return this.features.contains(paramFeature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public Set<Warning> getWarnings() {
/*  253 */     return this.warnings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addWarning(@Nonnull Warning paramWarning) {
/*  260 */     this.warnings.add(paramWarning);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addWarnings(@Nonnull Collection<Warning> paramCollection) {
/*  267 */     this.warnings.addAll(paramCollection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWarning(@Nonnull Warning paramWarning) {
/*  275 */     return this.warnings.contains(paramWarning);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInput(@Nonnull Source paramSource) {
/*  284 */     paramSource.init(this);
/*  285 */     this.inputs.add(paramSource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInput(@Nonnull File paramFile) throws IOException {
/*  295 */     addInput(new FileLexerSource(paramFile));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void error(int paramInt1, int paramInt2, @Nonnull String paramString) throws LexerException {
/*  306 */     if (this.listener != null) {
/*  307 */       this.listener.handleError(this.source, paramInt1, paramInt2, paramString);
/*      */     } else {
/*  309 */       throw new LexerException("Error at " + paramInt1 + ":" + paramInt2 + ": " + paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void error(@Nonnull Token paramToken, @Nonnull String paramString) throws LexerException {
/*  322 */     error(paramToken.getLine(), paramToken.getColumn(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void warning(int paramInt1, int paramInt2, @Nonnull String paramString) throws LexerException {
/*  333 */     if (this.warnings.contains(Warning.ERROR)) {
/*  334 */       error(paramInt1, paramInt2, paramString);
/*  335 */     } else if (this.listener != null) {
/*  336 */       this.listener.handleWarning(this.source, paramInt1, paramInt2, paramString);
/*      */     } else {
/*  338 */       throw new LexerException("Warning at " + paramInt1 + ":" + paramInt2 + ": " + paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void warning(@Nonnull Token paramToken, @Nonnull String paramString) throws LexerException {
/*  351 */     warning(paramToken.getLine(), paramToken.getColumn(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMacro(@Nonnull Macro paramMacro) throws LexerException, IOException {
/*  364 */     String str = paramMacro.getName();
/*      */     
/*  366 */     if ("defined".equals(str)) {
/*  367 */       throw new LexerException("Cannot redefine name 'defined'");
/*      */     }
/*  369 */     this.macros.put(paramMacro.getName(), paramMacro);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMacro(@Nonnull String paramString1, @Nonnull String paramString2) throws LexerException {
/*      */     try {
/*  383 */       Macro macro = new Macro(paramString1);
/*  384 */       StringLexerSource stringLexerSource = new StringLexerSource(paramString2);
/*      */       try {
/*      */         while (true) {
/*  387 */           Token token = stringLexerSource.token();
/*  388 */           if (token.getType() == 265)
/*      */             break; 
/*  390 */           macro.addToken(token);
/*      */         } 
/*      */       } finally {
/*  393 */         stringLexerSource.close();
/*      */       } 
/*  395 */       addMacro(macro);
/*  396 */     } catch (IOException iOException) {
/*  397 */       throw new LexerException(iOException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMacro(@Nonnull String paramString) throws LexerException {
/*  411 */     addMacro(paramString, "1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQuoteIncludePath(@Nonnull List<String> paramList) {
/*  419 */     this.quoteincludepath = paramList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public List<String> getQuoteIncludePath() {
/*  429 */     return this.quoteincludepath;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSystemIncludePath(@Nonnull List<String> paramList) {
/*  437 */     this.sysincludepath = paramList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public List<String> getSystemIncludePath() {
/*  447 */     return this.sysincludepath;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFrameworksPath(@Nonnull List<String> paramList) {
/*  455 */     this.frameworkspath = paramList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public List<String> getFrameworksPath() {
/*  466 */     return this.frameworkspath;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public Map<String, Macro> getMacros() {
/*  477 */     return this.macros;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Macro> getMacros(boolean paramBoolean) throws IOException, LexerException {
/*  491 */     ArrayList<Macro> arrayList = new ArrayList();
/*  492 */     Collection<Macro> collection = this.macros.values();
/*  493 */     for (Macro macro : collection) {
/*  494 */       if (paramBoolean && !macro.isFunctionLike()) {
/*  495 */         arrayList.add(new Macro(macro, expand(macro.getTokens()))); continue;
/*      */       } 
/*  497 */       arrayList.add(new Macro(macro));
/*      */     } 
/*      */     
/*  500 */     return arrayList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @CheckForNull
/*      */   public Macro getMacro(@Nonnull String paramString) {
/*  513 */     return this.macros.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public List<? extends VirtualFile> getIncludes() {
/*  525 */     return this.includes;
/*      */   }
/*      */ 
/*      */   
/*      */   private void push_state() {
/*  530 */     State state = this.states.peek();
/*  531 */     this.states.push(new State(state));
/*      */   }
/*      */ 
/*      */   
/*      */   private void pop_state() throws LexerException {
/*  536 */     State state = this.states.pop();
/*  537 */     if (this.states.isEmpty()) {
/*  538 */       error(0, 0, "#endif without #if");
/*  539 */       this.states.push(state);
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isActive() {
/*  544 */     State state = this.states.peek();
/*  545 */     return (state.isParentActive() && state.isActive());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Source getSource() {
/*  561 */     return this.source;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void push_source(@Nonnull Source paramSource, boolean paramBoolean) {
/*  573 */     paramSource.init(this);
/*  574 */     paramSource.setParent(this.source, paramBoolean);
/*      */     
/*  576 */     if (this.listener != null)
/*  577 */       this.listener.handleSourceChange(this.source, PreprocessorListener.SourceChangeEvent.SUSPEND); 
/*  578 */     this.source = paramSource;
/*  579 */     if (this.listener != null) {
/*  580 */       this.listener.handleSourceChange(this.source, PreprocessorListener.SourceChangeEvent.PUSH);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @CheckForNull
/*      */   protected Token pop_source(boolean paramBoolean) throws IOException {
/*  595 */     if (this.listener != null)
/*  596 */       this.listener.handleSourceChange(this.source, PreprocessorListener.SourceChangeEvent.POP); 
/*  597 */     Source source1 = this.source;
/*  598 */     this.source = source1.getParent();
/*      */     
/*  600 */     source1.close();
/*  601 */     if (this.listener != null && this.source != null) {
/*  602 */       this.listener.handleSourceChange(this.source, PreprocessorListener.SourceChangeEvent.RESUME);
/*      */     }
/*  604 */     Source source2 = getSource();
/*  605 */     if (getFeature(Feature.LINEMARKERS) && source1
/*  606 */       .isNumbered() && source2 != null)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  611 */       return line_token(source2.getLine(), source2.getName(), " 2");
/*      */     }
/*      */     
/*  614 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void pop_source() throws IOException {
/*  619 */     pop_source(false);
/*      */   }
/*      */   
/*      */   @Nonnull
/*      */   private Token next_source() {
/*  624 */     if (this.inputs.isEmpty())
/*  625 */       return new Token(265); 
/*  626 */     Source source = this.inputs.remove(0);
/*  627 */     push_source(source, true);
/*  628 */     return line_token(source.getLine(), source.getName(), " 1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token line_token(int paramInt, @CheckForNull String paramString1, @Nonnull String paramString2) {
/*  638 */     StringBuilder stringBuilder = new StringBuilder();
/*  639 */     stringBuilder.append("#line ").append(paramInt)
/*  640 */       .append(" \"");
/*      */     
/*  642 */     if (paramString1 == null) {
/*  643 */       stringBuilder.append("<no file>");
/*      */     }
/*  645 */     else if (File.separatorChar != '/' && getFeature(Feature.UNIFIED_OUTPUT)) {
/*  646 */       MacroTokenSource.escape(stringBuilder, paramString1.replaceAll(Matcher.quoteReplacement(File.separator), "/"));
/*      */     } else {
/*  648 */       MacroTokenSource.escape(stringBuilder, paramString1);
/*      */     } 
/*      */     
/*  651 */     stringBuilder.append("\"").append(paramString2).append("\n");
/*  652 */     return new Token(299, paramInt, 0, stringBuilder.toString(), null);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token source_token() throws IOException, LexerException {
/*      */     Token token;
/*  659 */     if (this.source_token != null) {
/*  660 */       Token token1 = this.source_token;
/*  661 */       this.source_token = null;
/*  662 */       if (getFeature(Feature.DEBUG))
/*  663 */         this.LOG.debug("Returning unget token " + token1); 
/*  664 */       return token1;
/*      */     } 
/*      */     
/*      */     while (true) {
/*  668 */       Source source = getSource();
/*  669 */       if (source == null) {
/*  670 */         Token token1 = next_source();
/*  671 */         if (token1.getType() == 299 && !getFeature(Feature.LINEMARKERS))
/*      */           continue; 
/*  673 */         return token1;
/*      */       } 
/*  675 */       token = source.token();
/*      */       
/*  677 */       if (token.getType() == 265 && source.isAutopop()) {
/*      */         
/*  679 */         Token token1 = pop_source(true);
/*  680 */         if (token1 != null)
/*  681 */           return token1;  continue;
/*      */       }  break;
/*      */     } 
/*  684 */     if (getFeature(Feature.DEBUG))
/*  685 */       this.LOG.debug("Returning fresh token " + token); 
/*  686 */     return token;
/*      */   }
/*      */ 
/*      */   
/*      */   private void source_untoken(Token paramToken) {
/*  691 */     if (this.source_token != null)
/*  692 */       throw new IllegalStateException("Cannot return two tokens"); 
/*  693 */     this.source_token = paramToken;
/*      */   }
/*      */   
/*      */   private boolean isWhite(Token paramToken) {
/*  697 */     int i = paramToken.getType();
/*  698 */     return (i == 294 || i == 260 || i == 261);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Token source_token_nonwhite() throws IOException, LexerException {
/*      */     while (true) {
/*  708 */       Token token = source_token();
/*  709 */       if (!isWhite(token)) {
/*  710 */         return token;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Token source_skipline(boolean paramBoolean) throws IOException, LexerException {
/*  725 */     Source source = getSource();
/*  726 */     Token token = source.skipline(paramBoolean);
/*      */     
/*  728 */     if (token.getType() == 265 && source.isAutopop()) {
/*      */       
/*  730 */       Token token1 = pop_source(true);
/*  731 */       if (token1 != null)
/*  732 */         return token1; 
/*      */     } 
/*  734 */     return token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean macro(Macro paramMacro, Token paramToken) throws IOException, LexerException {
/*      */     List list;
/*  745 */     if (paramMacro.isFunctionLike()) {
/*      */       
/*      */       while (true) {
/*  748 */         Token token1 = source_token();
/*      */         
/*  750 */         switch (token1.getType()) {
/*      */           case 260:
/*      */           case 261:
/*      */           case 284:
/*      */           case 294:
/*      */             continue;
/*      */           
/*      */           case 40:
/*      */             break;
/*      */         } 
/*      */         
/*  761 */         source_untoken(token1);
/*  762 */         return false;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  767 */       Token token = source_token_nonwhite();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  772 */       if (token.getType() != 41 || paramMacro.getArgs() > 0) {
/*  773 */         list = new ArrayList();
/*      */         
/*  775 */         Argument argument = new Argument();
/*  776 */         byte b = 0;
/*  777 */         boolean bool = false;
/*      */ 
/*      */ 
/*      */         
/*      */         while (true) {
/*  782 */           switch (token.getType()) {
/*      */             case 265:
/*  784 */               error(token, "EOF in macro args");
/*  785 */               return false;
/*      */             
/*      */             case 44:
/*  788 */               if (!b) {
/*  789 */                 if (paramMacro.isVariadic() && list
/*  790 */                   .size() == paramMacro.getArgs() - 1) {
/*      */                   
/*  792 */                   argument.addToken(token);
/*      */                 } else {
/*  794 */                   list.add(argument);
/*  795 */                   argument = new Argument();
/*      */                 } 
/*      */               } else {
/*  798 */                 argument.addToken(token);
/*      */               } 
/*  800 */               bool = false;
/*      */               break;
/*      */             case 41:
/*  803 */               if (!b) {
/*  804 */                 list.add(argument);
/*      */                 break;
/*      */               } 
/*  807 */               b--;
/*  808 */               argument.addToken(token);
/*      */               
/*  810 */               bool = false;
/*      */               break;
/*      */             case 40:
/*  813 */               b++;
/*  814 */               argument.addToken(token);
/*  815 */               bool = false;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 260:
/*      */             case 261:
/*      */             case 284:
/*      */             case 294:
/*  823 */               bool = true;
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             default:
/*  829 */               if (bool && !argument.isEmpty())
/*  830 */                 argument.addToken(Token.space); 
/*  831 */               argument.addToken(token);
/*  832 */               bool = false;
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/*  837 */           token = source_token();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  842 */         if (list.size() != paramMacro.getArgs()) {
/*  843 */           if (paramMacro.isVariadic()) {
/*  844 */             if (list.size() == paramMacro.getArgs() - 1) {
/*  845 */               list.add(new Argument());
/*      */             } else {
/*  847 */               error(token, "variadic macro " + paramMacro
/*  848 */                   .getName() + " has at least " + (paramMacro
/*  849 */                   .getArgs() - 1) + " parameters but given " + list
/*  850 */                   .size() + " args");
/*  851 */               return false;
/*      */             } 
/*      */           } else {
/*  854 */             error(token, "macro " + paramMacro
/*  855 */                 .getName() + " has " + paramMacro
/*  856 */                 .getArgs() + " parameters but given " + list
/*  857 */                 .size() + " args");
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  862 */             return false;
/*      */           } 
/*      */         }
/*      */         
/*  866 */         for (Argument argument1 : list) {
/*  867 */           argument1.expand(this);
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  873 */         list = null;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  878 */       list = null;
/*      */     } 
/*      */     
/*  881 */     if (paramMacro == __LINE__) {
/*  882 */       push_source(new FixedTokenSource(new Token[] { new Token(272, paramToken
/*      */                 
/*  884 */                 .getLine(), paramToken.getColumn(), 
/*  885 */                 Integer.toString(paramToken.getLine()), new NumericValue(10, 
/*  886 */                   Integer.toString(paramToken.getLine()))) }), true);
/*      */     }
/*  888 */     else if (paramMacro == __FILE__) {
/*  889 */       StringBuilder stringBuilder = new StringBuilder("\"");
/*  890 */       String str1 = getSource().getName();
/*  891 */       if (str1 == null)
/*  892 */         str1 = "<no file>"; 
/*  893 */       for (byte b = 0; b < str1.length(); b++) {
/*  894 */         char c = str1.charAt(b);
/*  895 */         switch (c) {
/*      */           case '\\':
/*  897 */             stringBuilder.append("\\\\");
/*      */             break;
/*      */           case '"':
/*  900 */             stringBuilder.append("\\\"");
/*      */             break;
/*      */           default:
/*  903 */             stringBuilder.append(c);
/*      */             break;
/*      */         } 
/*      */       } 
/*  907 */       stringBuilder.append("\"");
/*  908 */       String str2 = stringBuilder.toString();
/*  909 */       push_source(new FixedTokenSource(new Token[] { new Token(292, paramToken
/*      */                 
/*  911 */                 .getLine(), paramToken.getColumn(), str2, str2) }), true);
/*      */     
/*      */     }
/*  914 */     else if (paramMacro == __COUNTER__) {
/*      */ 
/*      */       
/*  917 */       int i = this.counter++;
/*  918 */       push_source(new FixedTokenSource(new Token[] { new Token(272, paramToken
/*      */                 
/*  920 */                 .getLine(), paramToken.getColumn(), 
/*  921 */                 Integer.toString(i), new NumericValue(10, 
/*  922 */                   Integer.toString(i))) }), true);
/*      */     } else {
/*      */       
/*  925 */       push_source(new MacroTokenSource(paramMacro, list), true);
/*      */     } 
/*      */     
/*  928 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   List<Token> expand(@Nonnull List<Token> paramList) throws IOException, LexerException {
/*  939 */     ArrayList<Token> arrayList = new ArrayList();
/*  940 */     boolean bool = false;
/*      */     
/*  942 */     push_source(new FixedTokenSource(paramList), false);
/*      */ 
/*      */     
/*      */     while (true) {
/*  946 */       Token token = expanded_token();
/*  947 */       switch (token.getType()) {
/*      */         case 265:
/*      */           break;
/*      */         
/*      */         case 260:
/*      */         case 261:
/*      */         case 294:
/*  954 */           bool = true;
/*      */           continue;
/*      */       } 
/*      */       
/*  958 */       if (bool && !arrayList.isEmpty())
/*  959 */         arrayList.add(Token.space); 
/*  960 */       arrayList.add(token);
/*  961 */       bool = false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  967 */     pop_source(false);
/*      */     
/*  969 */     return arrayList;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Token define() throws IOException, LexerException {
/*      */     List<?> list;
/*  976 */     Token token = source_token_nonwhite();
/*  977 */     if (token.getType() != 270) {
/*  978 */       error(token, "Expected identifier");
/*  979 */       return source_skipline(false);
/*      */     } 
/*      */     
/*  982 */     String str = token.getText();
/*  983 */     if ("defined".equals(str)) {
/*  984 */       error(token, "Cannot redefine name 'defined'");
/*  985 */       return source_skipline(false);
/*      */     } 
/*      */     
/*  988 */     Macro macro = new Macro(getSource(), str);
/*      */ 
/*      */     
/*  991 */     token = source_token();
/*  992 */     if (token.getType() == 40) {
/*  993 */       token = source_token_nonwhite();
/*  994 */       if (token.getType() != 41) {
/*  995 */         list = new ArrayList();
/*      */         
/*      */         while (true) {
/*  998 */           switch (token.getType()) {
/*      */             case 270:
/* 1000 */               list.add(token.getText());
/*      */               break;
/*      */             
/*      */             case 264:
/* 1004 */               list.add("__VA_ARGS__");
/*      */ 
/*      */               
/* 1007 */               source_untoken(token);
/*      */               break;
/*      */             case 265:
/*      */             case 284:
/* 1011 */               error(token, "Unterminated macro parameter list");
/*      */               
/* 1013 */               return token;
/*      */             default:
/* 1015 */               error(token, "error in macro parameters: " + token
/*      */                   
/* 1017 */                   .getText());
/* 1018 */               return source_skipline(false);
/*      */           } 
/* 1020 */           token = source_token_nonwhite();
/* 1021 */           switch (token.getType()) {
/*      */             case 44:
/*      */               break;
/*      */             case 264:
/* 1025 */               token = source_token_nonwhite();
/* 1026 */               if (token.getType() != 41) {
/* 1027 */                 error(token, "ellipsis must be on last argument");
/*      */               }
/* 1029 */               macro.setVariadic(true);
/*      */               break;
/*      */             
/*      */             case 41:
/*      */               break;
/*      */             
/*      */             case 265:
/*      */             case 284:
/* 1037 */               error(token, "Unterminated macro parameters");
/*      */               
/* 1039 */               return token;
/*      */             default:
/* 1041 */               error(token, "Bad token in macro parameters: " + token
/*      */                   
/* 1043 */                   .getText());
/* 1044 */               return source_skipline(false);
/*      */           } 
/* 1046 */           token = source_token_nonwhite();
/*      */         } 
/*      */       } else {
/* 1049 */         assert token.getType() == 41 : "Expected ')'";
/* 1050 */         list = Collections.emptyList();
/*      */       } 
/*      */       
/* 1053 */       macro.setArgs((List)list);
/*      */     } else {
/*      */       
/* 1056 */       list = Collections.emptyList();
/* 1057 */       source_untoken(token);
/*      */     } 
/*      */ 
/*      */     
/* 1061 */     boolean bool1 = false;
/* 1062 */     boolean bool2 = false;
/*      */ 
/*      */ 
/*      */     
/* 1066 */     token = source_token_nonwhite(); while (true) {
/*      */       int i;
/*      */       Token token1;
/* 1069 */       switch (token.getType()) {
/*      */         case 265:
/*      */         case 284:
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 260:
/*      */         case 261:
/*      */         case 294:
/* 1080 */           if (!bool2) {
/* 1081 */             bool1 = true;
/*      */           }
/*      */           break;
/*      */         
/*      */         case 286:
/* 1086 */           bool1 = false;
/* 1087 */           bool2 = true;
/* 1088 */           macro.addPaste(new Token(297, token
/* 1089 */                 .getLine(), token.getColumn(), "##", null));
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 35:
/* 1095 */           if (bool1)
/* 1096 */             macro.addToken(Token.space); 
/* 1097 */           bool1 = false;
/* 1098 */           token1 = source_token_nonwhite();
/* 1099 */           if (token1.getType() == 270 && (
/* 1100 */             i = list.indexOf(token1.getText())) != -1) {
/* 1101 */             macro.addToken(new Token(298, token1
/* 1102 */                   .getLine(), token1.getColumn(), "#" + token1
/* 1103 */                   .getText(), 
/* 1104 */                   Integer.valueOf(i))); break;
/*      */           } 
/* 1106 */           macro.addToken(token);
/*      */           
/* 1108 */           source_untoken(token1);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 270:
/* 1113 */           if (bool1)
/* 1114 */             macro.addToken(Token.space); 
/* 1115 */           bool1 = false;
/* 1116 */           bool2 = false;
/* 1117 */           i = list.indexOf(token.getText());
/* 1118 */           if (i == -1) {
/* 1119 */             macro.addToken(token); break;
/*      */           } 
/* 1121 */           macro.addToken(new Token(296, token
/* 1122 */                 .getLine(), token.getColumn(), token
/* 1123 */                 .getText(), 
/* 1124 */                 Integer.valueOf(i)));
/*      */           break;
/*      */         
/*      */         default:
/* 1128 */           if (bool1)
/* 1129 */             macro.addToken(Token.space); 
/* 1130 */           bool1 = false;
/* 1131 */           bool2 = false;
/* 1132 */           macro.addToken(token);
/*      */           break;
/*      */       } 
/* 1135 */       token = source_token();
/*      */     } 
/*      */     
/* 1138 */     if (getFeature(Feature.DEBUG)) {
/* 1139 */       this.LOG.debug("Defined macro " + macro);
/*      */     }
/* 1141 */     addMacro(macro);
/*      */     
/* 1143 */     return token;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token undef() throws IOException, LexerException {
/* 1150 */     Token token = source_token_nonwhite();
/* 1151 */     if (token.getType() != 270) {
/* 1152 */       error(token, "Expected identifier, not " + token
/* 1153 */           .getText());
/* 1154 */       if (token.getType() == 284 || token.getType() == 265)
/* 1155 */         return token; 
/*      */     } else {
/* 1157 */       Macro macro = getMacro(token.getText());
/* 1158 */       if (macro != null)
/*      */       {
/* 1160 */         this.macros.remove(macro.getName());
/*      */       }
/*      */     } 
/* 1163 */     return source_skipline(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean include(@Nonnull VirtualFile paramVirtualFile) throws IOException {
/* 1179 */     if (!paramVirtualFile.isFile())
/* 1180 */       return false; 
/* 1181 */     if (getFeature(Feature.DEBUG))
/* 1182 */       this.LOG.debug("pp: including " + paramVirtualFile); 
/* 1183 */     this.includes.add(paramVirtualFile);
/* 1184 */     push_source(paramVirtualFile.getSource(), true);
/* 1185 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean include(@Nonnull Iterable<String> paramIterable, @Nonnull String paramString) throws IOException {
/* 1198 */     for (String str : paramIterable) {
/* 1199 */       VirtualFile virtualFile = getFileSystem().getFile(str, paramString);
/* 1200 */       if (include(virtualFile))
/* 1201 */         return true; 
/*      */     } 
/* 1203 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void include(@CheckForNull String paramString1, int paramInt, @Nonnull String paramString2, boolean paramBoolean1, boolean paramBoolean2) throws IOException, LexerException {
/* 1217 */     if (paramString2.startsWith("/")) {
/* 1218 */       VirtualFile virtualFile1 = this.filesystem.getFile(paramString2);
/* 1219 */       if (include(virtualFile1))
/*      */         return; 
/* 1221 */       StringBuilder stringBuilder1 = new StringBuilder();
/* 1222 */       stringBuilder1.append("File not found: ").append(paramString2);
/* 1223 */       error(paramInt, 0, stringBuilder1.toString());
/*      */       
/*      */       return;
/*      */     } 
/* 1227 */     VirtualFile virtualFile = null;
/* 1228 */     if (paramBoolean1) {
/* 1229 */       if (paramString1 != null) {
/* 1230 */         VirtualFile virtualFile1 = this.filesystem.getFile(paramString1);
/* 1231 */         virtualFile = virtualFile1.getParentFile();
/*      */       } 
/* 1233 */       if (virtualFile != null) {
/* 1234 */         VirtualFile virtualFile1 = virtualFile.getChildFile(paramString2);
/* 1235 */         if (include(virtualFile1))
/*      */           return; 
/*      */       } 
/* 1238 */       if (include(this.quoteincludepath, paramString2))
/*      */         return; 
/*      */     } else {
/* 1241 */       int i = paramString2.indexOf('/');
/* 1242 */       if (i != -1) {
/* 1243 */         String str1 = paramString2.substring(0, i);
/* 1244 */         String str2 = paramString2.substring(i + 1);
/* 1245 */         String str3 = str1 + ".framework/Headers/" + str2;
/* 1246 */         if (include(this.frameworkspath, str3)) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */     } 
/* 1251 */     if (include(this.sysincludepath, paramString2)) {
/*      */       return;
/*      */     }
/* 1254 */     StringBuilder stringBuilder = new StringBuilder();
/* 1255 */     stringBuilder.append("File not found: ").append(paramString2);
/* 1256 */     stringBuilder.append(" in");
/* 1257 */     if (paramBoolean1) {
/* 1258 */       stringBuilder.append(" .").append('(').append(virtualFile).append(')');
/* 1259 */       for (String str : this.quoteincludepath)
/* 1260 */         stringBuilder.append(" ").append(str); 
/*      */     } 
/* 1262 */     for (String str : this.sysincludepath)
/* 1263 */       stringBuilder.append(" ").append(str); 
/* 1264 */     error(paramInt, 0, stringBuilder.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token include(boolean paramBoolean) throws IOException, LexerException {
/* 1271 */     LexerSource lexerSource = (LexerSource)this.source; try {
/*      */       String str; boolean bool;
/* 1273 */       lexerSource.setInclude(true);
/* 1274 */       Token token = token_nonwhite();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1279 */       if (token.getType() == 292) {
/*      */ 
/*      */         
/* 1282 */         StringBuilder stringBuilder = new StringBuilder((String)token.getValue());
/*      */         
/*      */         while (true) {
/* 1285 */           token = token_nonwhite();
/* 1286 */           switch (token.getType()) {
/*      */             case 292:
/* 1288 */               stringBuilder.append((String)token.getValue());
/*      */               continue;
/*      */             case 265:
/*      */             case 284:
/*      */               break;
/*      */           } 
/* 1294 */           warning(token, "Unexpected token on #include line");
/*      */           
/* 1296 */           return source_skipline(false);
/*      */         } 
/*      */         
/* 1299 */         str = stringBuilder.toString();
/* 1300 */         bool = true;
/* 1301 */       } else if (token.getType() == 269) {
/* 1302 */         str = (String)token.getValue();
/* 1303 */         bool = false;
/* 1304 */         token = source_skipline(true);
/*      */       } else {
/* 1306 */         error(token, "Expected string or header, not " + token
/* 1307 */             .getText());
/* 1308 */         switch (token.getType()) {
/*      */           case 265:
/*      */           case 284:
/* 1311 */             token1 = token; return token1;
/*      */         } 
/*      */         
/* 1314 */         Token token1 = source_skipline(false); return token1;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1319 */       include(this.source.getPath(), token.getLine(), str, bool, paramBoolean);
/*      */ 
/*      */ 
/*      */       
/* 1323 */       if (getFeature(Feature.LINEMARKERS))
/* 1324 */         return line_token(1, this.source.getName(), " 1"); 
/* 1325 */       return token;
/*      */     } finally {
/* 1327 */       lexerSource.setInclude(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void pragma_once(@Nonnull Token paramToken) throws IOException, LexerException {
/* 1333 */     Source source = this.source;
/* 1334 */     if (!this.onceseenpaths.add(source.getPath())) {
/* 1335 */       Token token = pop_source(true);
/*      */       
/* 1337 */       if (token != null) {
/* 1338 */         push_source(new FixedTokenSource(Arrays.asList(new Token[] { token }, )), true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void pragma(@Nonnull Token paramToken, @Nonnull List<Token> paramList) throws IOException, LexerException {
/* 1345 */     if (getFeature(Feature.PRAGMA_ONCE) && 
/* 1346 */       "once".equals(paramToken.getText())) {
/* 1347 */       pragma_once(paramToken);
/*      */       
/*      */       return;
/*      */     } 
/* 1351 */     warning(paramToken, "Unknown #pragma: " + paramToken.getText());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token pragma() throws IOException, LexerException {
/*      */     Token token;
/*      */     while (true) {
/*      */       Token token1;
/* 1362 */       token = source_token();
/* 1363 */       switch (token.getType()) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 265:
/* 1368 */           warning(token, "End of file in #pragma");
/*      */           
/* 1370 */           return token;
/*      */         
/*      */         case 284:
/* 1373 */           warning(token, "Empty #pragma");
/*      */           
/* 1375 */           return token;
/*      */         case 260:
/*      */         case 261:
/*      */         case 294:
/*      */           continue;
/*      */         case 270:
/* 1381 */           token1 = token;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 1391 */       ArrayList<Token> arrayList = new ArrayList();
/*      */       
/*      */       while (true) {
/* 1394 */         token = source_token();
/* 1395 */         switch (token.getType()) {
/*      */ 
/*      */ 
/*      */           
/*      */           case 265:
/* 1400 */             warning(token, "End of file in #pragma");
/*      */             break;
/*      */           
/*      */           case 284:
/*      */             break;
/*      */           
/*      */           case 260:
/*      */           case 261:
/*      */             continue;
/*      */           case 294:
/* 1410 */             arrayList.add(token);
/*      */             continue;
/*      */         } 
/* 1413 */         arrayList.add(token);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1418 */       pragma(token1, arrayList);
/*      */       
/* 1420 */       return token;
/*      */     } 
/*      */     warning(token, "Illegal #pragma " + token.getText());
/*      */     return source_skipline(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private void error(@Nonnull Token paramToken, boolean paramBoolean) throws IOException, LexerException {
/* 1428 */     StringBuilder stringBuilder = new StringBuilder();
/* 1429 */     stringBuilder.append('#').append(paramToken.getText()).append(' ');
/*      */     
/* 1431 */     Token token = source_token_nonwhite();
/*      */     
/*      */     while (true) {
/* 1434 */       switch (token.getType()) {
/*      */         case 265:
/*      */         case 284:
/*      */           break;
/*      */       } 
/* 1439 */       stringBuilder.append(token.getText());
/*      */ 
/*      */       
/* 1442 */       token = source_token();
/*      */     } 
/* 1444 */     if (paramBoolean) {
/* 1445 */       error(paramToken, stringBuilder.toString());
/*      */     } else {
/* 1447 */       warning(paramToken, stringBuilder.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token expanded_token() throws IOException, LexerException {
/*      */     Token token;
/*      */     while (true) {
/* 1458 */       token = source_token();
/*      */       
/* 1460 */       if (token.getType() == 270) {
/* 1461 */         Macro macro = getMacro(token.getText());
/* 1462 */         if (macro == null)
/* 1463 */           return token; 
/* 1464 */         if (this.source.isExpanding(macro))
/* 1465 */           return token; 
/* 1466 */         if (macro(macro, token))
/*      */           continue; 
/*      */       }  break;
/* 1469 */     }  return token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token expanded_token_nonwhite() throws IOException, LexerException {
/*      */     while (true) {
/* 1479 */       Token token = expanded_token();
/*      */       
/* 1481 */       if (!isWhite(token))
/* 1482 */         return token; 
/*      */     } 
/*      */   }
/* 1485 */   public Preprocessor() { this.expr_token = null; this.LOG = Logging.getLogger(Preprocessor.class); this.inputs = new ArrayList<>(); this.macros = new HashMap<>(); this.macros.put(__LINE__.getName(), __LINE__); this.macros.put(__FILE__.getName(), __FILE__); this.macros.put(__COUNTER__.getName(), __COUNTER__); this.states = new Stack<>(); this.states.push(new State()); this.source = null; this.counter = 0;
/*      */     this.quoteincludepath = new ArrayList<>();
/*      */     this.sysincludepath = new ArrayList<>();
/*      */     this.frameworkspath = new ArrayList<>();
/*      */     this.features = EnumSet.noneOf(Feature.class);
/*      */     this.warnings = EnumSet.noneOf(Warning.class);
/*      */     this.filesystem = new JavaFileSystem();
/* 1492 */     this.listener = null; } @Nonnull private Token expr_token() throws IOException, LexerException { Token token = this.expr_token;
/*      */     
/* 1494 */     if (token != null) {
/*      */       
/* 1496 */       this.expr_token = null;
/*      */     } else {
/* 1498 */       token = expanded_token_nonwhite();
/*      */ 
/*      */       
/* 1501 */       if (token.getType() == 270 && token
/* 1502 */         .getText().equals("defined")) {
/* 1503 */         Token token1 = source_token_nonwhite();
/* 1504 */         boolean bool = false;
/* 1505 */         if (token1.getType() == 40) {
/* 1506 */           bool = true;
/* 1507 */           token1 = source_token_nonwhite();
/*      */         } 
/*      */ 
/*      */         
/* 1511 */         if (token1.getType() != 270) {
/* 1512 */           error(token1, "defined() needs identifier, not " + token1
/*      */               
/* 1514 */               .getText());
/*      */           
/* 1516 */           token = new Token(272, token1.getLine(), token1.getColumn(), "0", new NumericValue(10, "0"));
/*      */         }
/* 1518 */         else if (this.macros.containsKey(token1.getText())) {
/*      */ 
/*      */           
/* 1521 */           token = new Token(272, token1.getLine(), token1.getColumn(), "1", new NumericValue(10, "1"));
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1526 */           token = new Token(272, token1.getLine(), token1.getColumn(), "0", new NumericValue(10, "0"));
/*      */         } 
/*      */ 
/*      */         
/* 1530 */         if (bool) {
/* 1531 */           token1 = source_token_nonwhite();
/* 1532 */           if (token1.getType() != 41) {
/* 1533 */             expr_untoken(token1);
/* 1534 */             error(token1, "Missing ) in defined(). Got " + token1.getText());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1541 */     return token; }
/*      */ 
/*      */ 
/*      */   
/*      */   private void expr_untoken(@Nonnull Token paramToken) throws LexerException {
/* 1546 */     if (this.expr_token != null) {
/* 1547 */       throw new InternalException("Cannot unget two expression tokens.");
/*      */     }
/*      */     
/* 1550 */     this.expr_token = paramToken;
/*      */   }
/*      */   
/*      */   private int expr_priority(@Nonnull Token paramToken) {
/* 1554 */     switch (paramToken.getType()) {
/*      */       case 47:
/* 1556 */         return 11;
/*      */       case 37:
/* 1558 */         return 11;
/*      */       case 42:
/* 1560 */         return 11;
/*      */       case 43:
/* 1562 */         return 10;
/*      */       case 45:
/* 1564 */         return 10;
/*      */       case 279:
/* 1566 */         return 9;
/*      */       case 289:
/* 1568 */         return 9;
/*      */       case 60:
/* 1570 */         return 8;
/*      */       case 62:
/* 1572 */         return 8;
/*      */       case 275:
/* 1574 */         return 8;
/*      */       case 267:
/* 1576 */         return 8;
/*      */       case 266:
/* 1578 */         return 7;
/*      */       case 283:
/* 1580 */         return 7;
/*      */       case 38:
/* 1582 */         return 6;
/*      */       case 94:
/* 1584 */         return 5;
/*      */       case 124:
/* 1586 */         return 4;
/*      */       case 273:
/* 1588 */         return 3;
/*      */       case 277:
/* 1590 */         return 2;
/*      */       case 63:
/* 1592 */         return 1;
/*      */     } 
/*      */     
/* 1595 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private int expr_char(Token paramToken) {
/* 1600 */     Object object = paramToken.getValue();
/* 1601 */     if (object instanceof Character)
/* 1602 */       return ((Character)object).charValue(); 
/* 1603 */     String str = String.valueOf(object);
/* 1604 */     if (str.length() == 0)
/* 1605 */       return 0; 
/* 1606 */     return str.charAt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long expr(int paramInt) throws IOException, LexerException {
/*      */     long l;
/*      */     NumericValue numericValue;
/* 1616 */     Token token = expr_token();
/*      */ 
/*      */ 
/*      */     
/* 1620 */     switch (token.getType()) {
/*      */       case 40:
/* 1622 */         l = expr(0);
/* 1623 */         token = expr_token();
/* 1624 */         if (token.getType() != 41) {
/* 1625 */           expr_untoken(token);
/* 1626 */           error(token, "Missing ) in expression. Got " + token.getText());
/* 1627 */           return 0L;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 126:
/* 1632 */         l = expr(11) ^ 0xFFFFFFFFFFFFFFFFL;
/*      */         break;
/*      */       case 33:
/* 1635 */         l = (expr(11) == 0L) ? 1L : 0L;
/*      */         break;
/*      */       case 45:
/* 1638 */         l = -expr(11);
/*      */         break;
/*      */       case 272:
/* 1641 */         numericValue = (NumericValue)token.getValue();
/* 1642 */         l = numericValue.longValue();
/*      */         break;
/*      */       case 259:
/* 1645 */         l = expr_char(token);
/*      */         break;
/*      */       case 270:
/* 1648 */         if (this.warnings.contains(Warning.UNDEF)) {
/* 1649 */           warning(token, "Undefined token '" + token.getText() + "' encountered in conditional.");
/*      */         }
/* 1651 */         l = 0L;
/*      */         break;
/*      */       
/*      */       default:
/* 1655 */         expr_untoken(token);
/* 1656 */         error(token, "Bad token in expression: " + token
/* 1657 */             .getText());
/* 1658 */         return 0L;
/*      */     } 
/*      */ 
/*      */     
/*      */     while (true) {
/*      */       long l2;
/* 1664 */       Token token1 = expr_token();
/* 1665 */       int i = expr_priority(token1);
/*      */       
/* 1667 */       if (i == 0 || paramInt >= i) {
/* 1668 */         expr_untoken(token1);
/*      */         break;
/*      */       } 
/* 1671 */       long l1 = expr(i);
/*      */       
/* 1673 */       switch (token1.getType()) {
/*      */         case 47:
/* 1675 */           if (l1 == 0L) {
/* 1676 */             error(token1, "Division by zero");
/* 1677 */             l = 0L; continue;
/*      */           } 
/* 1679 */           l /= l1;
/*      */           continue;
/*      */         
/*      */         case 37:
/* 1683 */           if (l1 == 0L) {
/* 1684 */             error(token1, "Modulus by zero");
/* 1685 */             l = 0L; continue;
/*      */           } 
/* 1687 */           l %= l1;
/*      */           continue;
/*      */         
/*      */         case 42:
/* 1691 */           l *= l1;
/*      */           continue;
/*      */         case 43:
/* 1694 */           l += l1;
/*      */           continue;
/*      */         case 45:
/* 1697 */           l -= l1;
/*      */           continue;
/*      */         case 60:
/* 1700 */           l = (l < l1) ? 1L : 0L;
/*      */           continue;
/*      */         case 62:
/* 1703 */           l = (l > l1) ? 1L : 0L;
/*      */           continue;
/*      */         case 38:
/* 1706 */           l &= l1;
/*      */           continue;
/*      */         case 94:
/* 1709 */           l ^= l1;
/*      */           continue;
/*      */         case 124:
/* 1712 */           l |= l1;
/*      */           continue;
/*      */         
/*      */         case 279:
/* 1716 */           l <<= (int)l1;
/*      */           continue;
/*      */         case 289:
/* 1719 */           l >>= (int)l1;
/*      */           continue;
/*      */         case 275:
/* 1722 */           l = (l <= l1) ? 1L : 0L;
/*      */           continue;
/*      */         case 267:
/* 1725 */           l = (l >= l1) ? 1L : 0L;
/*      */           continue;
/*      */         case 266:
/* 1728 */           l = (l == l1) ? 1L : 0L;
/*      */           continue;
/*      */         case 283:
/* 1731 */           l = (l != l1) ? 1L : 0L;
/*      */           continue;
/*      */         case 273:
/* 1734 */           l = (l != 0L && l1 != 0L) ? 1L : 0L;
/*      */           continue;
/*      */         case 277:
/* 1737 */           l = (l != 0L || l1 != 0L) ? 1L : 0L;
/*      */           continue;
/*      */         
/*      */         case 63:
/* 1741 */           token = expr_token();
/* 1742 */           if (token.getType() != 58) {
/* 1743 */             expr_untoken(token);
/* 1744 */             error(token, "Missing : in conditional expression. Got " + token.getText());
/* 1745 */             return 0L;
/*      */           } 
/* 1747 */           l2 = expr(0);
/* 1748 */           l = (l != 0L) ? l1 : l2;
/*      */           continue;
/*      */       } 
/*      */ 
/*      */       
/* 1753 */       error(token1, "Unexpected operator " + token1
/* 1754 */           .getText());
/* 1755 */       return 0L;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1764 */     return l;
/*      */   }
/*      */   
/*      */   @Nonnull
/*      */   private Token toWhitespace(@Nonnull Token paramToken) {
/* 1769 */     String str = paramToken.getText();
/* 1770 */     int i = str.length();
/* 1771 */     boolean bool = false;
/* 1772 */     byte b1 = 0;
/*      */     
/* 1774 */     for (byte b2 = 0; b2 < i; b2++) {
/* 1775 */       char c = str.charAt(b2);
/*      */       
/* 1777 */       switch (c) {
/*      */         case '\r':
/* 1779 */           bool = true;
/* 1780 */           b1++;
/*      */           break;
/*      */         case '\n':
/* 1783 */           if (bool) {
/* 1784 */             bool = false;
/*      */             break;
/*      */           } 
/*      */         
/*      */         case '\013':
/*      */         case '\f':
/*      */         case '':
/*      */         case ' ':
/*      */         case ' ':
/* 1793 */           bool = false;
/* 1794 */           b1++;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 1799 */     char[] arrayOfChar = new char[b1];
/* 1800 */     Arrays.fill(arrayOfChar, '\n');
/* 1801 */     return new Token(294, paramToken
/* 1802 */         .getLine(), paramToken.getColumn(), new String(arrayOfChar));
/*      */   }
/*      */   
/*      */   @Nonnull
/*      */   private Token _token() throws IOException, LexerException {
/*      */     Token token;
/*      */     while (true) {
/*      */       Macro macro;
/*      */       State state;
/*      */       String str;
/*      */       boolean bool;
/* 1813 */       if (!isActive()) {
/* 1814 */         Source source = getSource();
/* 1815 */         if (source == null) {
/* 1816 */           Token token1 = next_source();
/* 1817 */           if (token1.getType() == 299 && !getFeature(Feature.LINEMARKERS))
/*      */             continue; 
/* 1819 */           return token1;
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/* 1824 */           source.setActive(false);
/* 1825 */           token = source_token();
/*      */         } finally {
/*      */           
/* 1828 */           source.setActive(true);
/*      */         } 
/* 1830 */         switch (token.getType()) {
/*      */           case 265:
/*      */           case 268:
/*      */           case 284:
/*      */             break;
/*      */           
/*      */           case 294:
/* 1837 */             return token;
/*      */           
/*      */           case 260:
/*      */           case 261:
/* 1841 */             if (getFeature(Feature.KEEPALLCOMMENTS))
/* 1842 */               return token; 
/* 1843 */             if (!isActive())
/* 1844 */               return toWhitespace(token); 
/* 1845 */             if (getFeature(Feature.KEEPCOMMENTS))
/* 1846 */               return token; 
/* 1847 */             return toWhitespace(token);
/*      */ 
/*      */           
/*      */           default:
/* 1851 */             return source_skipline(false);
/*      */         } 
/*      */       } else {
/* 1854 */         token = source_token();
/*      */       } 
/*      */ 
/*      */       
/* 1858 */       switch (token.getType()) {
/*      */         
/*      */         case 265:
/* 1861 */           return token;
/*      */         
/*      */         case 284:
/*      */         case 294:
/* 1865 */           return token;
/*      */         
/*      */         case 260:
/*      */         case 261:
/* 1869 */           return token;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 33:
/*      */         case 37:
/*      */         case 38:
/*      */         case 40:
/*      */         case 41:
/*      */         case 42:
/*      */         case 43:
/*      */         case 44:
/*      */         case 45:
/*      */         case 46:
/*      */         case 47:
/*      */         case 58:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 62:
/*      */         case 63:
/*      */         case 64:
/*      */         case 91:
/*      */         case 93:
/*      */         case 94:
/*      */         case 96:
/*      */         case 123:
/*      */         case 124:
/*      */         case 125:
/*      */         case 126:
/*      */         case 257:
/*      */         case 258:
/*      */         case 259:
/*      */         case 262:
/*      */         case 263:
/*      */         case 264:
/*      */         case 266:
/*      */         case 267:
/*      */         case 269:
/*      */         case 271:
/*      */         case 273:
/*      */         case 275:
/*      */         case 277:
/*      */         case 279:
/*      */         case 280:
/*      */         case 281:
/*      */         case 282:
/*      */         case 283:
/*      */         case 285:
/*      */         case 287:
/*      */         case 288:
/*      */         case 289:
/*      */         case 290:
/*      */         case 291:
/*      */         case 292:
/*      */         case 293:
/*      */         case 295:
/* 1930 */           return token;
/*      */         
/*      */         case 272:
/* 1933 */           return token;
/*      */         
/*      */         case 270:
/* 1936 */           macro = getMacro(token.getText());
/* 1937 */           if (macro == null)
/* 1938 */             return token; 
/* 1939 */           if (this.source.isExpanding(macro))
/* 1940 */             return token; 
/* 1941 */           if (macro(macro, token))
/*      */             continue; 
/* 1943 */           return token;
/*      */         
/*      */         case 299:
/* 1946 */           if (getFeature(Feature.LINEMARKERS)) {
/* 1947 */             return token;
/*      */           }
/*      */           continue;
/*      */         case 300:
/* 1951 */           if (getFeature(Feature.CSYNTAX))
/* 1952 */             error(token, String.valueOf(token.getValue())); 
/* 1953 */           return token;
/*      */         
/*      */         default:
/* 1956 */           throw new InternalException("Bad token " + token);
/*      */         case 268:
/*      */           break;
/*      */       } 
/* 1960 */       token = source_token_nonwhite();
/*      */       
/* 1962 */       switch (token.getType()) {
/*      */         case 284:
/*      */           continue;
/*      */         
/*      */         case 270:
/*      */           break;
/*      */         default:
/* 1969 */           error(token, "Preprocessor directive not a word " + token
/*      */               
/* 1971 */               .getText());
/* 1972 */           return source_skipline(false);
/*      */       } 
/* 1974 */       PreprocessorCommand preprocessorCommand = PreprocessorCommand.forText(token.getText());
/* 1975 */       if (preprocessorCommand == null) {
/* 1976 */         error(token, "Unknown preprocessor directive " + token
/*      */             
/* 1978 */             .getText());
/* 1979 */         return source_skipline(false);
/*      */       } 
/*      */ 
/*      */       
/* 1983 */       switch (preprocessorCommand) {
/*      */         
/*      */         case PP_DEFINE:
/* 1986 */           if (!isActive()) {
/* 1987 */             return source_skipline(false);
/*      */           }
/* 1989 */           return define();
/*      */ 
/*      */         
/*      */         case PP_UNDEF:
/* 1993 */           if (!isActive()) {
/* 1994 */             return source_skipline(false);
/*      */           }
/* 1996 */           return undef();
/*      */ 
/*      */         
/*      */         case PP_INCLUDE:
/* 2000 */           if (!isActive()) {
/* 2001 */             return source_skipline(false);
/*      */           }
/* 2003 */           return include(false);
/*      */         
/*      */         case PP_INCLUDE_NEXT:
/* 2006 */           if (!isActive())
/* 2007 */             return source_skipline(false); 
/* 2008 */           if (!getFeature(Feature.INCLUDENEXT)) {
/* 2009 */             error(token, "Directive include_next not enabled");
/*      */ 
/*      */             
/* 2012 */             return source_skipline(false);
/*      */           } 
/* 2014 */           return include(true);
/*      */ 
/*      */         
/*      */         case PP_WARNING:
/*      */         case PP_ERROR:
/* 2019 */           if (!isActive()) {
/* 2020 */             return source_skipline(false);
/*      */           }
/* 2022 */           error(token, (preprocessorCommand == PreprocessorCommand.PP_ERROR));
/*      */           continue;
/*      */         
/*      */         case PP_IF:
/* 2026 */           push_state();
/* 2027 */           if (!isActive()) {
/* 2028 */             return source_skipline(false);
/*      */           }
/* 2030 */           this.expr_token = null;
/* 2031 */           ((State)this.states.peek()).setActive((expr(0) != 0L));
/* 2032 */           token = expr_token();
/*      */           
/* 2034 */           if (token.getType() == 284)
/* 2035 */             return token; 
/* 2036 */           return source_skipline(true);
/*      */ 
/*      */         
/*      */         case PP_ELIF:
/* 2040 */           state = this.states.peek();
/*      */ 
/*      */           
/* 2043 */           if (state.sawElse()) {
/* 2044 */             error(token, "#elif after #else");
/*      */             
/* 2046 */             return source_skipline(false);
/* 2047 */           }  if (!state.isParentActive())
/*      */           {
/* 2049 */             return source_skipline(false); } 
/* 2050 */           if (state.isActive()) {
/*      */             
/* 2052 */             state.setParentActive(false);
/*      */ 
/*      */             
/* 2055 */             state.setActive(false);
/* 2056 */             return source_skipline(false);
/*      */           } 
/* 2058 */           this.expr_token = null;
/* 2059 */           state.setActive((expr(0) != 0L));
/* 2060 */           token = expr_token();
/*      */           
/* 2062 */           if (token.getType() == 284)
/* 2063 */             return token; 
/* 2064 */           return source_skipline(true);
/*      */ 
/*      */ 
/*      */         
/*      */         case PP_ELSE:
/* 2069 */           state = this.states.peek();
/*      */           
/* 2071 */           if (state.sawElse()) {
/* 2072 */             error(token, "#else after #else");
/*      */             
/* 2074 */             return source_skipline(false);
/*      */           } 
/* 2076 */           state.setSawElse();
/* 2077 */           state.setActive(!state.isActive());
/* 2078 */           return source_skipline(this.warnings.contains(Warning.ENDIF_LABELS));
/*      */ 
/*      */ 
/*      */         
/*      */         case PP_IFDEF:
/* 2083 */           push_state();
/* 2084 */           if (!isActive()) {
/* 2085 */             return source_skipline(false);
/*      */           }
/* 2087 */           token = source_token_nonwhite();
/*      */           
/* 2089 */           if (token.getType() != 270) {
/* 2090 */             error(token, "Expected identifier, not " + token
/*      */                 
/* 2092 */                 .getText());
/* 2093 */             return source_skipline(false);
/*      */           } 
/* 2095 */           str = token.getText();
/*      */           
/* 2097 */           bool = this.macros.containsKey(str);
/* 2098 */           ((State)this.states.peek()).setActive(bool);
/* 2099 */           return source_skipline(true);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case PP_IFNDEF:
/* 2105 */           push_state();
/* 2106 */           if (!isActive()) {
/* 2107 */             return source_skipline(false);
/*      */           }
/* 2109 */           token = source_token_nonwhite();
/* 2110 */           if (token.getType() != 270) {
/* 2111 */             error(token, "Expected identifier, not " + token
/*      */                 
/* 2113 */                 .getText());
/* 2114 */             return source_skipline(false);
/*      */           } 
/* 2116 */           str = token.getText();
/*      */           
/* 2118 */           bool = this.macros.containsKey(str);
/* 2119 */           ((State)this.states.peek()).setActive(!bool);
/* 2120 */           return source_skipline(true);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case PP_ENDIF:
/* 2126 */           pop_state();
/* 2127 */           return source_skipline(this.warnings.contains(Warning.ENDIF_LABELS));
/*      */ 
/*      */         
/*      */         case PP_LINE:
/* 2131 */           return source_skipline(false);
/*      */ 
/*      */         
/*      */         case PP_PRAGMA:
/* 2135 */           if (!isActive())
/* 2136 */             return source_skipline(false); 
/* 2137 */           return pragma();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/* 2147 */     throw new InternalException("Internal error: Unknown directive " + token);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token token_nonwhite() throws IOException, LexerException {
/*      */     while (true) {
/* 2163 */       Token token = _token();
/* 2164 */       if (!isWhite(token)) {
/* 2165 */         return token;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   public Token token() throws IOException, LexerException {
/* 2181 */     Token token = _token();
/* 2182 */     if (getFeature(Feature.DEBUG))
/* 2183 */       this.LOG.debug("pp: Returning " + token); 
/* 2184 */     return token;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2189 */     StringBuilder stringBuilder = new StringBuilder();
/*      */     
/* 2191 */     Source source = getSource();
/* 2192 */     while (source != null) {
/* 2193 */       stringBuilder.append(" -> ").append(String.valueOf(source)).append("\n");
/* 2194 */       source = source.getParent();
/*      */     } 
/*      */     
/* 2197 */     TreeMap<String, Macro> treeMap = new TreeMap<>(getMacros());
/* 2198 */     for (Macro macro : treeMap.values()) {
/* 2199 */       stringBuilder.append("#").append("macro ").append(macro).append("\n");
/*      */     }
/*      */     
/* 2202 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/* 2209 */     Source source = this.source;
/* 2210 */     while (source != null) {
/* 2211 */       source.close();
/* 2212 */       source = source.getParent();
/*      */     } 
/*      */     
/* 2215 */     for (Source source1 : this.inputs)
/* 2216 */       source1.close(); 
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/Preprocessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */