/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Macro
/*     */ {
/*     */   private final Source source;
/*     */   private final String name;
/*     */   private List<String> args;
/*     */   private boolean variadic;
/*     */   private boolean hasPaste;
/*     */   private List<Token> tokens;
/*     */   
/*     */   public Macro(Source paramSource, String paramString) {
/*  44 */     this.source = paramSource;
/*  45 */     this.name = paramString;
/*  46 */     this.args = null;
/*  47 */     this.variadic = false;
/*  48 */     this.hasPaste = false;
/*  49 */     this.tokens = new ArrayList<>();
/*     */   }
/*     */   public Macro(Macro paramMacro) {
/*  52 */     this(paramMacro, paramMacro.tokens, true);
/*     */   }
/*     */   public Macro(Macro paramMacro, List<Token> paramList) {
/*  55 */     this(paramMacro, paramList, false);
/*     */   }
/*     */   private Macro(Macro paramMacro, List<Token> paramList, boolean paramBoolean) {
/*  58 */     this.source = paramMacro.source;
/*  59 */     this.name = paramMacro.name;
/*  60 */     if (null != paramMacro.args) {
/*  61 */       this.args = new ArrayList<>(paramMacro.args);
/*     */     } else {
/*  63 */       this.args = null;
/*     */     } 
/*  65 */     this.variadic = paramMacro.variadic;
/*  66 */     this.hasPaste = paramMacro.hasPaste;
/*  67 */     if (null != paramList) {
/*  68 */       this.tokens = paramBoolean ? new ArrayList<>(paramList) : paramList;
/*     */     } else {
/*  70 */       this.tokens = new ArrayList<>();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Macro(String paramString) {
/*  75 */     this((Source)null, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Source getSource() {
/*  85 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  92 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setArgs(List<String> paramList) {
/*  99 */     this.args = paramList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFunctionLike() {
/* 106 */     return (this.args != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getArgs() {
/* 113 */     return this.args.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariadic(boolean paramBoolean) {
/* 120 */     this.variadic = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVariadic() {
/* 127 */     return this.variadic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPaste() {
/* 134 */     return this.hasPaste;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addToken(Token paramToken) {
/* 141 */     this.tokens.add(paramToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPaste(Token paramToken) {
/* 159 */     this.tokens.add(this.tokens.size() - 1, paramToken);
/* 160 */     this.hasPaste = true;
/*     */   }
/*     */   
/*     */   List<Token> getTokens() {
/* 164 */     return this.tokens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 172 */     StringBuilder stringBuilder = new StringBuilder();
/* 173 */     boolean bool = false;
/* 174 */     for (Token token : this.tokens) {
/* 175 */       if (token.getType() == 297) {
/* 176 */         assert !bool : "Two sequential pastes.";
/* 177 */         bool = true;
/*     */         continue;
/*     */       } 
/* 180 */       stringBuilder.append(token.getText());
/*     */       
/* 182 */       if (bool) {
/* 183 */         stringBuilder.append(" ## ");
/* 184 */         bool = false;
/*     */       } 
/*     */     } 
/*     */     
/* 188 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 193 */     StringBuilder stringBuilder = new StringBuilder(this.name);
/* 194 */     if (this.args != null) {
/* 195 */       stringBuilder.append('(');
/* 196 */       Iterator<String> iterator = this.args.iterator();
/* 197 */       while (iterator.hasNext()) {
/* 198 */         stringBuilder.append(iterator.next());
/* 199 */         if (iterator.hasNext()) {
/* 200 */           stringBuilder.append(", "); continue;
/* 201 */         }  if (isVariadic())
/* 202 */           stringBuilder.append("..."); 
/*     */       } 
/* 204 */       stringBuilder.append(')');
/*     */     } 
/* 206 */     if (!this.tokens.isEmpty()) {
/* 207 */       stringBuilder.append(" => ").append(getText());
/*     */     }
/* 209 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/Macro.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */