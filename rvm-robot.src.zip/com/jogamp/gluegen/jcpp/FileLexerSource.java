/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.nio.charset.Charset;
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileLexerSource
/*    */   extends InputLexerSource
/*    */ {
/*    */   private final String path;
/*    */   private final File file;
/*    */   
/*    */   public FileLexerSource(@Nonnull File paramFile, @Nonnull Charset paramCharset, @Nonnull String paramString) throws IOException {
/* 46 */     super(new FileInputStream(paramFile), paramCharset);
/* 47 */     this.file = paramFile;
/* 48 */     this.path = paramString;
/*    */   }
/*    */ 
/*    */   
/*    */   public FileLexerSource(@Nonnull File paramFile, @Nonnull String paramString) throws IOException {
/* 53 */     this(paramFile, Charset.defaultCharset(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public FileLexerSource(@Nonnull File paramFile, @Nonnull Charset paramCharset) throws IOException {
/* 58 */     this(paramFile, paramCharset, paramFile.getPath());
/*    */   }
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public FileLexerSource(@Nonnull File paramFile) throws IOException {
/* 64 */     this(paramFile, Charset.defaultCharset());
/*    */   }
/*    */ 
/*    */   
/*    */   public FileLexerSource(@Nonnull String paramString, @Nonnull Charset paramCharset) throws IOException {
/* 69 */     this(new File(paramString), paramCharset, paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public FileLexerSource(@Nonnull String paramString) throws IOException {
/* 75 */     this(paramString, Charset.defaultCharset());
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public File getFile() {
/* 80 */     return this.file;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPath() {
/* 88 */     return this.path;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 93 */     return getPath();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 98 */     return "file " + getPath();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/FileLexerSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */