/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import javax.annotation.CheckForNull;
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PreprocessorCommand
/*    */ {
/* 17 */   PP_DEFINE("define"),
/* 18 */   PP_ELIF("elif"),
/* 19 */   PP_ELSE("else"),
/* 20 */   PP_ENDIF("endif"),
/* 21 */   PP_ERROR("error"),
/* 22 */   PP_IF("if"),
/* 23 */   PP_IFDEF("ifdef"),
/* 24 */   PP_IFNDEF("ifndef"),
/* 25 */   PP_INCLUDE("include"),
/* 26 */   PP_LINE("line"),
/* 27 */   PP_PRAGMA("pragma"),
/* 28 */   PP_UNDEF("undef"),
/* 29 */   PP_WARNING("warning"),
/* 30 */   PP_INCLUDE_NEXT("include_next"),
/* 31 */   PP_IMPORT("import");
/*    */   
/*    */   PreprocessorCommand(String paramString1) {
/* 34 */     this.text = paramString1;
/*    */   }
/*    */   private final String text;
/*    */   @CheckForNull
/*    */   public static PreprocessorCommand forText(@Nonnull String paramString) {
/* 39 */     for (PreprocessorCommand preprocessorCommand : values()) {
/* 40 */       if (preprocessorCommand.text.equals(paramString))
/* 41 */         return preprocessorCommand; 
/* 42 */     }  return null;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/PreprocessorCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */