/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Argument
/*    */   extends ArrayList<Token>
/*    */ {
/* 35 */   private List<Token> expansion = null;
/*    */ 
/*    */   
/*    */   public void addToken(@Nonnull Token paramToken) {
/* 39 */     add(paramToken);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void expand(@Nonnull Preprocessor paramPreprocessor) throws IOException, LexerException {
/* 46 */     if (this.expansion == null) {
/* 47 */       this.expansion = paramPreprocessor.expand(this);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Iterator<Token> expansion() {
/* 54 */     return this.expansion.iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     StringBuilder stringBuilder = new StringBuilder();
/* 60 */     stringBuilder.append("Argument(");
/*    */     
/* 62 */     stringBuilder.append("raw=[ ");
/* 63 */     for (byte b = 0; b < size(); b++)
/* 64 */       stringBuilder.append(get(b).getText()); 
/* 65 */     stringBuilder.append(" ];expansion=[ ");
/* 66 */     if (this.expansion == null) {
/* 67 */       stringBuilder.append("null");
/*    */     } else {
/* 69 */       for (Token token : this.expansion)
/* 70 */         stringBuilder.append(token.getText()); 
/* 71 */     }  stringBuilder.append(" ])");
/* 72 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/Argument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */