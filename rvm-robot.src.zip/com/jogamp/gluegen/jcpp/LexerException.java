/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LexerException
/*    */   extends Exception
/*    */ {
/*    */   public LexerException(String paramString) {
/* 27 */     super(paramString);
/*    */   }
/*    */   
/*    */   public LexerException(Throwable paramThrowable) {
/* 31 */     super(paramThrowable);
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/LexerException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */