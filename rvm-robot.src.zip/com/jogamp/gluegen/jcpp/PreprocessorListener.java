/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PreprocessorListener
/*    */ {
/*    */   void handleWarning(@Nonnull Source paramSource, int paramInt1, int paramInt2, @Nonnull String paramString) throws LexerException;
/*    */   
/*    */   void handleError(@Nonnull Source paramSource, int paramInt1, int paramInt2, @Nonnull String paramString) throws LexerException;
/*    */   
/*    */   void handleSourceChange(@Nonnull Source paramSource, @Nonnull SourceChangeEvent paramSourceChangeEvent);
/*    */   
/*    */   public enum SourceChangeEvent
/*    */   {
/* 54 */     SUSPEND, PUSH, POP, RESUME;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/PreprocessorListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */