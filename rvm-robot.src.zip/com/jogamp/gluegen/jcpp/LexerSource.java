/*      */ package com.jogamp.gluegen.jcpp;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import javax.annotation.Nonnull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LexerSource
/*      */   extends Source
/*      */ {
/*      */   private static final boolean DEBUG = false;
/*      */   private JoinReader reader;
/*      */   private final boolean ppvalid;
/*      */   private boolean bol;
/*      */   private boolean include;
/*      */   private boolean digraphs;
/*      */   private int u0;
/*      */   private int u1;
/*      */   private int ucount;
/*      */   private int line;
/*      */   private int column;
/*      */   private int lastcolumn;
/*      */   private boolean cr;
/*      */   
/*      */   @Nonnull
/*      */   protected static BufferedReader toBufferedReader(@Nonnull Reader paramReader) {
/*   32 */     if (paramReader instanceof BufferedReader)
/*   33 */       return (BufferedReader)paramReader; 
/*   34 */     return new BufferedReader(paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LexerSource(Reader paramReader, boolean paramBoolean) {
/*   59 */     this.reader = new JoinReader(paramReader);
/*   60 */     this.ppvalid = paramBoolean;
/*   61 */     this.bol = true;
/*   62 */     this.include = false;
/*      */     
/*   64 */     this.digraphs = true;
/*      */     
/*   66 */     this.ucount = 0;
/*      */     
/*   68 */     this.line = 1;
/*   69 */     this.column = 0;
/*   70 */     this.lastcolumn = -1;
/*   71 */     this.cr = false;
/*      */   }
/*      */ 
/*      */   
/*      */   void init(Preprocessor paramPreprocessor) {
/*   76 */     super.init(paramPreprocessor);
/*   77 */     this.digraphs = paramPreprocessor.getFeature(Feature.DIGRAPHS);
/*   78 */     this.reader.init(paramPreprocessor, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLine() {
/*   90 */     return this.line;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColumn() {
/*  102 */     return this.column;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isNumbered() {
/*  107 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _error(String paramString, boolean paramBoolean) throws LexerException {
/*  113 */     int i = this.line;
/*  114 */     int j = this.column;
/*  115 */     if (j == 0) {
/*  116 */       j = this.lastcolumn;
/*  117 */       i--;
/*      */     } else {
/*  119 */       j--;
/*      */     } 
/*  121 */     if (paramBoolean) {
/*  122 */       error(i, j, paramString);
/*      */     } else {
/*  124 */       warning(i, j, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final void error(String paramString) throws LexerException {
/*  130 */     _error(paramString, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void warning(String paramString) throws LexerException {
/*  136 */     _error(paramString, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void setInclude(boolean paramBoolean) {
/*  142 */     this.include = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isLineSeparator(int paramInt) {
/*  154 */     switch ((char)paramInt) {
/*      */       case '\n':
/*      */       case '\013':
/*      */       case '\f':
/*      */       case '\r':
/*      */       case '':
/*      */       case ' ':
/*      */       case ' ':
/*  162 */         return true;
/*      */     } 
/*  164 */     return (paramInt == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int read() throws IOException, LexerException {
/*      */     int i;
/*  172 */     assert this.ucount <= 2 : "Illegal ucount: " + this.ucount;
/*  173 */     switch (this.ucount) {
/*      */       case 2:
/*  175 */         this.ucount = 1;
/*  176 */         i = this.u1;
/*      */         break;
/*      */       case 1:
/*  179 */         this.ucount = 0;
/*  180 */         i = this.u0;
/*      */         break;
/*      */       default:
/*  183 */         if (this.reader == null) {
/*  184 */           i = -1; break;
/*      */         } 
/*  186 */         i = this.reader.read();
/*      */         break;
/*      */     } 
/*      */     
/*  190 */     switch (i)
/*      */     { case 13:
/*  192 */         this.cr = true;
/*  193 */         this.line++;
/*  194 */         this.lastcolumn = this.column;
/*  195 */         this.column = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  232 */         return i;case 10: if (this.cr) { this.cr = false; return i; } case 11: case 12: case 133: case 8232: case 8233: this.cr = false; this.line++; this.lastcolumn = this.column; this.column = 0; return i;case -1: this.cr = false; return i; }  this.cr = false; this.column++; return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unread(int paramInt) throws IOException {
/*  239 */     if (paramInt != -1) {
/*  240 */       if (isLineSeparator(paramInt)) {
/*  241 */         this.line--;
/*  242 */         this.column = this.lastcolumn;
/*  243 */         this.cr = false;
/*      */       } else {
/*  245 */         this.column--;
/*      */       } 
/*  247 */       switch (this.ucount) {
/*      */         case 0:
/*  249 */           this.u0 = paramInt;
/*  250 */           this.ucount = 1;
/*      */           return;
/*      */         case 1:
/*  253 */           this.u1 = paramInt;
/*  254 */           this.ucount = 2;
/*      */           return;
/*      */       } 
/*  257 */       throw new IllegalStateException("Cannot unget another character!");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token invalid(StringBuilder paramStringBuilder, String paramString) throws IOException, LexerException {
/*  270 */     int i = read();
/*  271 */     while (!isLineSeparator(i)) {
/*  272 */       paramStringBuilder.append((char)i);
/*  273 */       i = read();
/*      */     } 
/*  275 */     unread(i);
/*  276 */     return new Token(300, paramStringBuilder.toString(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token ccomment() throws IOException, LexerException {
/*  283 */     StringBuilder stringBuilder = new StringBuilder("/*");
/*      */ 
/*      */     
/*      */     while (true) {
/*  287 */       int i = read();
/*  288 */       if (i == -1) {
/*  289 */         return new Token(300, stringBuilder.toString(), "Unterminated comment");
/*      */       }
/*  291 */       stringBuilder.append((char)i);
/*  292 */       if (i == 42) {
/*      */         while (true) {
/*  294 */           i = read();
/*  295 */           if (i == -1) {
/*  296 */             return new Token(300, stringBuilder.toString(), "Unterminated comment");
/*      */           }
/*  298 */           stringBuilder.append((char)i);
/*  299 */           if (i != 42 && 
/*  300 */             i == 47)
/*  301 */             return new Token(260, stringBuilder.toString()); 
/*      */         } 
/*      */         break;
/*      */       } 
/*      */     } 
/*      */   } @Nonnull
/*      */   private Token cppcomment() throws IOException, LexerException {
/*  308 */     StringBuilder stringBuilder = new StringBuilder("//");
/*  309 */     int i = read();
/*  310 */     while (!isLineSeparator(i)) {
/*  311 */       stringBuilder.append((char)i);
/*  312 */       i = read();
/*      */     } 
/*  314 */     unread(i);
/*  315 */     return new Token(261, stringBuilder.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int escape(StringBuilder paramStringBuilder) throws IOException, LexerException {
/*      */     byte b;
/*  329 */     int j, i = read();
/*  330 */     switch (i) {
/*      */       case 97:
/*  332 */         paramStringBuilder.append('a');
/*  333 */         return 7;
/*      */       case 98:
/*  335 */         paramStringBuilder.append('b');
/*  336 */         return 8;
/*      */       case 102:
/*  338 */         paramStringBuilder.append('f');
/*  339 */         return 12;
/*      */       case 110:
/*  341 */         paramStringBuilder.append('n');
/*  342 */         return 10;
/*      */       case 114:
/*  344 */         paramStringBuilder.append('r');
/*  345 */         return 13;
/*      */       case 116:
/*  347 */         paramStringBuilder.append('t');
/*  348 */         return 9;
/*      */       case 118:
/*  350 */         paramStringBuilder.append('v');
/*  351 */         return 11;
/*      */       case 92:
/*  353 */         paramStringBuilder.append('\\');
/*  354 */         return 92;
/*      */       
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*  364 */         b = 0;
/*  365 */         j = 0;
/*      */         do {
/*  367 */           j = (j << 3) + Character.digit(i, 8);
/*  368 */           paramStringBuilder.append((char)i);
/*  369 */           i = read();
/*  370 */         } while (++b < 3 && Character.digit(i, 8) != -1);
/*  371 */         unread(i);
/*  372 */         return j;
/*      */       
/*      */       case 120:
/*  375 */         paramStringBuilder.append((char)i);
/*  376 */         b = 0;
/*  377 */         j = 0;
/*  378 */         while (b++ < 2) {
/*  379 */           i = read();
/*  380 */           if (Character.digit(i, 16) == -1) {
/*  381 */             unread(i);
/*      */             break;
/*      */           } 
/*  384 */           j = (j << 4) + Character.digit(i, 16);
/*  385 */           paramStringBuilder.append((char)i);
/*      */         } 
/*  387 */         return j;
/*      */ 
/*      */       
/*      */       case 34:
/*  391 */         paramStringBuilder.append('"');
/*  392 */         return 34;
/*      */       case 39:
/*  394 */         paramStringBuilder.append('\'');
/*  395 */         return 39;
/*      */     } 
/*      */     
/*  398 */     warning("Unnecessary escape character " + (char)i);
/*  399 */     paramStringBuilder.append((char)i);
/*  400 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token character() throws IOException, LexerException {
/*  408 */     StringBuilder stringBuilder = new StringBuilder("'");
/*  409 */     int i = read();
/*  410 */     if (i == 92)
/*  411 */     { stringBuilder.append('\\');
/*  412 */       i = escape(stringBuilder); }
/*  413 */     else { if (isLineSeparator(i)) {
/*  414 */         unread(i);
/*  415 */         return new Token(300, stringBuilder.toString(), "Unterminated character literal");
/*      */       } 
/*  417 */       if (i == 39) {
/*  418 */         stringBuilder.append('\'');
/*  419 */         return new Token(300, stringBuilder.toString(), "Empty character literal");
/*      */       } 
/*  421 */       if (!Character.isDefined(i)) {
/*  422 */         stringBuilder.append('?');
/*  423 */         return invalid(stringBuilder, "Illegal unicode character literal");
/*      */       } 
/*  425 */       stringBuilder.append((char)i); }
/*      */ 
/*      */     
/*  428 */     int j = read();
/*  429 */     if (j != 39) {
/*      */       
/*      */       while (true) {
/*      */         
/*  433 */         if (isLineSeparator(j)) {
/*  434 */           unread(j);
/*      */           break;
/*      */         } 
/*  437 */         stringBuilder.append((char)j);
/*  438 */         if (j == 39)
/*      */           break; 
/*  440 */         j = read();
/*      */       } 
/*  442 */       return new Token(300, stringBuilder.toString(), "Illegal character constant " + stringBuilder);
/*      */     } 
/*      */     
/*  445 */     stringBuilder.append('\'');
/*      */     
/*  447 */     return new Token(259, stringBuilder
/*  448 */         .toString(), Character.valueOf((char)i));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token string(char paramChar1, char paramChar2) throws IOException, LexerException {
/*  455 */     StringBuilder stringBuilder1 = new StringBuilder();
/*  456 */     stringBuilder1.append(paramChar1);
/*      */     
/*  458 */     StringBuilder stringBuilder2 = new StringBuilder();
/*      */     
/*      */     while (true) {
/*  461 */       int i = read();
/*  462 */       if (i == paramChar2)
/*      */         break; 
/*  464 */       if (i == 92) {
/*  465 */         stringBuilder1.append('\\');
/*  466 */         if (!this.include) {
/*  467 */           char c = (char)escape(stringBuilder1);
/*  468 */           stringBuilder2.append(c);
/*      */         }  continue;
/*  470 */       }  if (i == -1) {
/*  471 */         unread(i);
/*      */         
/*  473 */         return new Token(300, stringBuilder1.toString(), "End of file in string literal after " + stringBuilder2);
/*      */       } 
/*  475 */       if (isLineSeparator(i)) {
/*  476 */         unread(i);
/*      */         
/*  478 */         return new Token(300, stringBuilder1.toString(), "Unterminated string literal after " + stringBuilder2);
/*      */       } 
/*      */       
/*  481 */       stringBuilder1.append((char)i);
/*  482 */       stringBuilder2.append((char)i);
/*      */     } 
/*      */     
/*  485 */     stringBuilder1.append(paramChar2);
/*  486 */     switch (paramChar2) {
/*      */       case '"':
/*  488 */         return new Token(292, stringBuilder1
/*  489 */             .toString(), stringBuilder2.toString());
/*      */       case '>':
/*  491 */         return new Token(269, stringBuilder1
/*  492 */             .toString(), stringBuilder2.toString());
/*      */       case '\'':
/*  494 */         if (stringBuilder2.length() == 1)
/*  495 */           return new Token(259, stringBuilder1
/*  496 */               .toString(), stringBuilder2.toString()); 
/*  497 */         return new Token(291, stringBuilder1
/*  498 */             .toString(), stringBuilder2.toString());
/*      */     } 
/*  500 */     throw new IllegalStateException("Unknown closing character " + 
/*  501 */         String.valueOf(paramChar2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token _number_suffix(StringBuilder paramStringBuilder, NumericValue paramNumericValue, int paramInt) throws IOException, LexerException {
/*  509 */     int i = 0;
/*      */     while (true) {
/*  511 */       if (paramInt == 85 || paramInt == 117) {
/*  512 */         if ((i & 0x1) != 0)
/*  513 */           warning("Duplicate unsigned suffix " + paramInt); 
/*  514 */         i |= 0x1;
/*  515 */         paramStringBuilder.append((char)paramInt);
/*  516 */         paramInt = read(); continue;
/*  517 */       }  if (paramInt == 76 || paramInt == 108) {
/*  518 */         if ((i & 0x3E) != 0)
/*  519 */           warning("Multiple length suffixes after " + paramStringBuilder); 
/*  520 */         paramStringBuilder.append((char)paramInt);
/*  521 */         int j = read();
/*  522 */         if (j == paramInt) {
/*  523 */           i |= 0x8;
/*  524 */           paramStringBuilder.append((char)j);
/*  525 */           paramInt = read(); continue;
/*      */         } 
/*  527 */         i |= 0x4;
/*  528 */         paramInt = j; continue;
/*      */       } 
/*  530 */       if (paramInt == 73 || paramInt == 105) {
/*  531 */         if ((i & 0x3E) != 0)
/*  532 */           warning("Multiple length suffixes after " + paramStringBuilder); 
/*  533 */         i |= 0x2;
/*  534 */         paramStringBuilder.append((char)paramInt);
/*  535 */         paramInt = read(); continue;
/*  536 */       }  if (paramInt == 70 || paramInt == 102) {
/*  537 */         if ((i & 0x3E) != 0)
/*  538 */           warning("Multiple length suffixes after " + paramStringBuilder); 
/*  539 */         i |= 0x10;
/*  540 */         paramStringBuilder.append((char)paramInt);
/*  541 */         paramInt = read(); continue;
/*  542 */       }  if (paramInt == 68 || paramInt == 100)
/*  543 */       { if ((i & 0x3E) != 0)
/*  544 */           warning("Multiple length suffixes after " + paramStringBuilder); 
/*  545 */         i |= 0x20;
/*  546 */         paramStringBuilder.append((char)paramInt);
/*  547 */         paramInt = read(); continue; }  break;
/*  548 */     }  if (Character.isUnicodeIdentifierPart(paramInt)) {
/*  549 */       String str = "Invalid suffix \"" + (char)paramInt + "\" on numeric constant";
/*      */ 
/*      */       
/*  552 */       while (Character.isUnicodeIdentifierPart(paramInt)) {
/*  553 */         paramStringBuilder.append((char)paramInt);
/*  554 */         paramInt = read();
/*      */       } 
/*  556 */       unread(paramInt);
/*  557 */       return new Token(300, paramStringBuilder.toString(), str);
/*      */     } 
/*  559 */     unread(paramInt);
/*  560 */     paramNumericValue.setFlags(i);
/*  561 */     return new Token(272, paramStringBuilder
/*  562 */         .toString(), paramNumericValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private String _number_part(StringBuilder paramStringBuilder, int paramInt, boolean paramBoolean) throws IOException, LexerException {
/*  572 */     StringBuilder stringBuilder = new StringBuilder();
/*  573 */     int i = read();
/*  574 */     if (paramBoolean && (i == 43 || i == 45)) {
/*  575 */       paramStringBuilder.append((char)i);
/*  576 */       stringBuilder.append((char)i);
/*  577 */       i = read();
/*      */     } 
/*  579 */     while (Character.digit(i, paramInt) != -1) {
/*  580 */       paramStringBuilder.append((char)i);
/*  581 */       stringBuilder.append((char)i);
/*  582 */       i = read();
/*      */     } 
/*  584 */     unread(i);
/*  585 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token number_hex(char paramChar) throws IOException, LexerException {
/*  593 */     StringBuilder stringBuilder = new StringBuilder("0");
/*  594 */     stringBuilder.append(paramChar);
/*  595 */     String str = _number_part(stringBuilder, 16, false);
/*  596 */     NumericValue numericValue = new NumericValue(16, str);
/*  597 */     int i = read();
/*  598 */     if (i == 46) {
/*  599 */       stringBuilder.append((char)i);
/*  600 */       String str1 = _number_part(stringBuilder, 16, false);
/*  601 */       numericValue.setFractionalPart(str1);
/*  602 */       i = read();
/*      */     } 
/*  604 */     if (i == 80 || i == 112) {
/*  605 */       stringBuilder.append((char)i);
/*  606 */       String str1 = _number_part(stringBuilder, 10, true);
/*  607 */       numericValue.setExponent(2, str1);
/*  608 */       i = read();
/*      */     } 
/*      */     
/*  611 */     return _number_suffix(stringBuilder, numericValue, i);
/*      */   }
/*      */   
/*      */   private static boolean is_octal(@Nonnull String paramString) {
/*  615 */     if (!paramString.startsWith("0"))
/*  616 */       return false; 
/*  617 */     for (byte b = 0; b < paramString.length(); b++) {
/*  618 */       if (Character.digit(paramString.charAt(b), 8) == -1)
/*  619 */         return false; 
/*  620 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token number_decimal() throws IOException, LexerException {
/*  629 */     StringBuilder stringBuilder = new StringBuilder();
/*  630 */     String str1 = _number_part(stringBuilder, 10, false);
/*  631 */     String str2 = null;
/*  632 */     String str3 = null;
/*  633 */     int i = read();
/*  634 */     if (i == 46) {
/*  635 */       stringBuilder.append((char)i);
/*  636 */       str2 = _number_part(stringBuilder, 10, false);
/*  637 */       i = read();
/*      */     } 
/*  639 */     if (i == 69 || i == 101) {
/*  640 */       stringBuilder.append((char)i);
/*  641 */       str3 = _number_part(stringBuilder, 10, true);
/*  642 */       i = read();
/*      */     } 
/*  644 */     byte b = 10;
/*  645 */     if (str2 == null && str3 == null && str1.startsWith("0"))
/*  646 */       if (!is_octal(str1)) {
/*  647 */         warning("Decimal constant starts with 0, but not octal: " + str1);
/*      */       } else {
/*  649 */         b = 8;
/*      */       }  
/*  651 */     NumericValue numericValue = new NumericValue(b, str1);
/*  652 */     if (str2 != null)
/*  653 */       numericValue.setFractionalPart(str2); 
/*  654 */     if (str3 != null) {
/*  655 */       numericValue.setExponent(10, str3);
/*      */     }
/*  657 */     return _number_suffix(stringBuilder, numericValue, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token number() throws IOException, LexerException {
/*      */     Token token;
/*  700 */     int i = read();
/*  701 */     if (i == 48) {
/*  702 */       int j = read();
/*  703 */       if (j == 120 || j == 88) {
/*  704 */         token = number_hex((char)j);
/*      */       } else {
/*  706 */         unread(j);
/*  707 */         unread(i);
/*  708 */         token = number_decimal();
/*      */       } 
/*  710 */     } else if (Character.isDigit(i) || i == 46) {
/*  711 */       unread(i);
/*  712 */       token = number_decimal();
/*      */     } else {
/*  714 */       throw new LexerException("Asked to parse something as a number which isn't: " + (char)i);
/*      */     } 
/*  716 */     return token;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token identifier(int paramInt) throws IOException, LexerException {
/*      */     int i;
/*  723 */     StringBuilder stringBuilder = new StringBuilder();
/*      */     
/*  725 */     stringBuilder.append((char)paramInt);
/*      */     while (true) {
/*  727 */       i = read();
/*  728 */       if (Character.isIdentifierIgnorable(i))
/*  729 */         continue;  if (Character.isJavaIdentifierPart(i)) {
/*  730 */         stringBuilder.append((char)i); continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  734 */     unread(i);
/*  735 */     return new Token(270, stringBuilder.toString());
/*      */   }
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token whitespace(int paramInt) throws IOException, LexerException {
/*      */     int i;
/*  742 */     StringBuilder stringBuilder = new StringBuilder();
/*      */     
/*  744 */     stringBuilder.append((char)paramInt);
/*      */     while (true) {
/*  746 */       i = read();
/*  747 */       if (this.ppvalid && isLineSeparator(i))
/*      */         break; 
/*  749 */       if (Character.isWhitespace(i)) {
/*  750 */         stringBuilder.append((char)i); continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  754 */     unread(i);
/*  755 */     return new Token(294, stringBuilder.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   private Token cond(char paramChar, int paramInt1, int paramInt2) throws IOException, LexerException {
/*  763 */     int i = read();
/*  764 */     if (paramChar == i)
/*  765 */       return new Token(paramInt1); 
/*  766 */     unread(i);
/*  767 */     return new Token(paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Token token() throws IOException, LexerException {
/*      */     int m;
/*  774 */     Token token = null;
/*      */     
/*  776 */     int i = this.line;
/*  777 */     int j = this.column;
/*      */     
/*  779 */     int k = read();
/*      */ 
/*      */     
/*  782 */     switch (k) {
/*      */       case 10:
/*  784 */         if (this.ppvalid) {
/*  785 */           this.bol = true;
/*  786 */           if (this.include)
/*  787 */           { token = new Token(284, i, j, "\n"); }
/*      */           else
/*  789 */           { byte b = 0;
/*      */             while (true)
/*  791 */             { b++;
/*  792 */               int n = read();
/*  793 */               if (n != 10)
/*  794 */               { unread(n);
/*  795 */                 char[] arrayOfChar = new char[b];
/*  796 */                 for (byte b1 = 0; b1 < arrayOfChar.length; b1++) {
/*  797 */                   arrayOfChar[b1] = '\n';
/*      */                 }
/*  799 */                 token = new Token(284, i, j, new String(arrayOfChar));
/*      */ 
/*      */ 
/*      */                 
/*  803 */                 return token; }  }  }  return token;
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 33:
/*  809 */         token = cond('=', 283, 33);
/*      */         break;
/*      */       
/*      */       case 35:
/*  813 */         if (this.bol) {
/*  814 */           token = new Token(268); break;
/*      */         } 
/*  816 */         token = cond('#', 286, 35);
/*      */         break;
/*      */       
/*      */       case 43:
/*  820 */         m = read();
/*  821 */         if (m == 43) {
/*  822 */           token = new Token(271); break;
/*  823 */         }  if (m == 61) {
/*  824 */           token = new Token(287); break;
/*      */         } 
/*  826 */         unread(m);
/*      */         break;
/*      */       case 45:
/*  829 */         m = read();
/*  830 */         if (m == 45) {
/*  831 */           token = new Token(262); break;
/*  832 */         }  if (m == 61) {
/*  833 */           token = new Token(293); break;
/*  834 */         }  if (m == 62) {
/*  835 */           token = new Token(258); break;
/*      */         } 
/*  837 */         unread(m);
/*      */         break;
/*      */       
/*      */       case 42:
/*  841 */         token = cond('=', 282, 42);
/*      */         break;
/*      */       case 47:
/*  844 */         m = read();
/*  845 */         if (m == 42) {
/*  846 */           token = ccomment(); break;
/*  847 */         }  if (m == 47) {
/*  848 */           token = cppcomment(); break;
/*  849 */         }  if (m == 61) {
/*  850 */           token = new Token(263); break;
/*      */         } 
/*  852 */         unread(m);
/*      */         break;
/*      */       
/*      */       case 37:
/*  856 */         m = read();
/*  857 */         if (m == 61) {
/*  858 */           token = new Token(281); break;
/*  859 */         }  if (this.digraphs && m == 62) {
/*  860 */           token = new Token(125); break;
/*  861 */         }  if (this.digraphs && m == 58) {
/*      */ 
/*      */           
/*  864 */           m = read();
/*  865 */           if (m != 37) {
/*  866 */             unread(m);
/*  867 */             token = new Token(35);
/*      */             break;
/*      */           } 
/*  870 */           m = read();
/*  871 */           if (m != 58) {
/*  872 */             unread(m);
/*  873 */             unread(37);
/*  874 */             token = new Token(35);
/*      */             break;
/*      */           } 
/*  877 */           token = new Token(286);
/*      */           break;
/*      */         } 
/*  880 */         unread(m);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 58:
/*  885 */         m = read();
/*  886 */         if (this.digraphs && m == 62) {
/*  887 */           token = new Token(93); break;
/*      */         } 
/*  889 */         unread(m);
/*      */         break;
/*      */       
/*      */       case 60:
/*  893 */         if (this.include) {
/*  894 */           token = string('<', '>'); break;
/*      */         } 
/*  896 */         m = read();
/*  897 */         if (m == 61) {
/*  898 */           token = new Token(275); break;
/*  899 */         }  if (m == 60) {
/*  900 */           token = cond('=', 280, 279); break;
/*  901 */         }  if (this.digraphs && m == 58) {
/*  902 */           token = new Token(91); break;
/*  903 */         }  if (this.digraphs && m == 37) {
/*  904 */           token = new Token(123); break;
/*      */         } 
/*  906 */         unread(m);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 61:
/*  911 */         token = cond('=', 266, 61);
/*      */         break;
/*      */       
/*      */       case 62:
/*  915 */         m = read();
/*  916 */         if (m == 61) {
/*  917 */           token = new Token(267); break;
/*  918 */         }  if (m == 62) {
/*  919 */           token = cond('=', 290, 289); break;
/*      */         } 
/*  921 */         unread(m);
/*      */         break;
/*      */       
/*      */       case 94:
/*  925 */         token = cond('=', 295, 94);
/*      */         break;
/*      */       
/*      */       case 124:
/*  929 */         m = read();
/*  930 */         if (m == 61) {
/*  931 */           token = new Token(285); break;
/*  932 */         }  if (m == 124) {
/*  933 */           token = cond('=', 278, 277); break;
/*      */         } 
/*  935 */         unread(m);
/*      */         break;
/*      */       case 38:
/*  938 */         m = read();
/*  939 */         if (m == 38) {
/*  940 */           token = cond('=', 274, 273); break;
/*  941 */         }  if (m == 61) {
/*  942 */           token = new Token(257); break;
/*      */         } 
/*  944 */         unread(m);
/*      */         break;
/*      */       
/*      */       case 46:
/*  948 */         m = read();
/*  949 */         if (m == 46) {
/*  950 */           token = cond('.', 264, 288);
/*      */         } else {
/*  952 */           unread(m);
/*  953 */         }  if (Character.isDigit(m)) {
/*  954 */           unread(46);
/*  955 */           token = number();
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 39:
/*  961 */         token = string('\'', '\'');
/*      */         break;
/*      */       
/*      */       case 34:
/*  965 */         token = string('"', '"');
/*      */         break;
/*      */       
/*      */       case -1:
/*  969 */         close();
/*  970 */         token = new Token(265, i, j, "<eof>");
/*      */         break;
/*      */     } 
/*      */     
/*  974 */     if (token == null) {
/*  975 */       if (Character.isWhitespace(k)) {
/*  976 */         token = whitespace(k);
/*  977 */       } else if (Character.isDigit(k)) {
/*  978 */         unread(k);
/*  979 */         token = number();
/*  980 */       } else if (Character.isJavaIdentifierStart(k)) {
/*  981 */         token = identifier(k);
/*      */       } else {
/*  983 */         String str = TokenType.getTokenText(k);
/*  984 */         if (str == null)
/*  985 */           if (k >>> 16 == 0) {
/*  986 */             str = Character.toString((char)k);
/*      */           } else {
/*  988 */             str = new String(Character.toChars(k));
/*      */           }  
/*  990 */         token = new Token(k, str);
/*      */       } 
/*      */     }
/*      */     
/*  994 */     if (this.bol) {
/*  995 */       switch (token.getType()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 260:
/*      */         case 294:
/* 1005 */           token.setLocation(i, j);
/*      */ 
/*      */ 
/*      */           
/* 1009 */           return token;
/*      */       } 
/*      */       this.bol = false;
/*      */     } 
/*      */   }
/*      */   public void close() throws IOException {
/* 1015 */     if (this.reader != null) {
/* 1016 */       this.reader.close();
/* 1017 */       this.reader = null;
/*      */     } 
/* 1019 */     super.close();
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/LexerSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */