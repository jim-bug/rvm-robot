/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChrootFileSystem
/*    */   implements VirtualFileSystem
/*    */ {
/*    */   private File root;
/*    */   
/*    */   public ChrootFileSystem(File paramFile) {
/* 31 */     this.root = paramFile;
/*    */   }
/*    */ 
/*    */   
/*    */   public VirtualFile getFile(String paramString) {
/* 36 */     return new ChrootFile(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public VirtualFile getFile(String paramString1, String paramString2) {
/* 41 */     return new ChrootFile(paramString1, paramString2);
/*    */   }
/*    */   
/*    */   private class ChrootFile
/*    */     extends File implements VirtualFile {
/*    */     private File rfile;
/*    */     
/*    */     public ChrootFile(String param1String) {
/* 49 */       super(param1String);
/*    */     }
/*    */     
/*    */     public ChrootFile(String param1String1, String param1String2) {
/* 53 */       super(param1String1, param1String2);
/*    */     }
/*    */ 
/*    */     
/*    */     public ChrootFile(File param1File, String param1String) {
/* 58 */       super(param1File, param1String);
/*    */     }
/*    */ 
/*    */     
/*    */     public ChrootFile getParentFile() {
/* 63 */       return new ChrootFile(getParent());
/*    */     }
/*    */ 
/*    */     
/*    */     public ChrootFile getChildFile(String param1String) {
/* 68 */       return new ChrootFile(this, param1String);
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean isFile() {
/* 73 */       File file = new File(ChrootFileSystem.this.root, getPath());
/* 74 */       return file.isFile();
/*    */     }
/*    */ 
/*    */     
/*    */     public Source getSource() throws IOException {
/* 79 */       return new FileLexerSource(new File(ChrootFileSystem.this.root, getPath()), 
/* 80 */           getPath());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/ChrootFileSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */