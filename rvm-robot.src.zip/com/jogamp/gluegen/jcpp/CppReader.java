/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import javax.annotation.Nonnull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CppReader
/*     */   extends Reader
/*     */   implements Closeable
/*     */ {
/*     */   private final Preprocessor cpp;
/*     */   private String token;
/*     */   private int idx;
/*     */   
/*     */   public CppReader(@Nonnull final Reader r) {
/*  45 */     this.cpp = new Preprocessor(new LexerSource(r, true)
/*     */         {
/*     */           public String getName() {
/*  48 */             return "<CppReader Input@" + 
/*  49 */               System.identityHashCode(r) + ">";
/*     */           }
/*     */         });
/*  52 */     this.token = "";
/*  53 */     this.idx = 0;
/*     */   }
/*     */   
/*     */   public CppReader(@Nonnull Preprocessor paramPreprocessor) {
/*  57 */     this.cpp = paramPreprocessor;
/*  58 */     this.token = "";
/*  59 */     this.idx = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public Preprocessor getPreprocessor() {
/*  67 */     return this.cpp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMacro(@Nonnull String paramString) throws LexerException {
/*  77 */     this.cpp.addMacro(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMacro(@Nonnull String paramString1, @Nonnull String paramString2) throws LexerException {
/*  87 */     this.cpp.addMacro(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean refill() throws IOException {
/*     */     try {
/*  93 */       assert this.cpp != null : "cpp is null : was it closed?";
/*  94 */       if (this.token == null)
/*  95 */         return false; 
/*  96 */       while (this.idx >= this.token.length()) {
/*  97 */         Token token = this.cpp.token();
/*  98 */         switch (token.getType()) {
/*     */           case 265:
/* 100 */             this.token = null;
/* 101 */             return false;
/*     */           case 260:
/*     */           case 261:
/* 104 */             if (!this.cpp.getFeature(Feature.KEEPCOMMENTS)) {
/* 105 */               this.token = " ";
/*     */               break;
/*     */             } 
/*     */           default:
/* 109 */             this.token = token.getText();
/*     */             break;
/*     */         } 
/* 112 */         this.idx = 0;
/*     */       } 
/* 114 */       return true;
/* 115 */     } catch (LexerException lexerException) {
/*     */       
/* 117 */       IOException iOException = new IOException(String.valueOf(lexerException));
/* 118 */       iOException.initCause(lexerException);
/* 119 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 126 */     if (!refill())
/* 127 */       return -1; 
/* 128 */     return this.token.charAt(this.idx++);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
/* 135 */     if (this.token == null)
/* 136 */       return -1; 
/* 137 */     for (byte b = 0; b < paramInt2; b++) {
/* 138 */       int i = read();
/* 139 */       if (i == -1)
/* 140 */         return b; 
/* 141 */       paramArrayOfchar[paramInt1 + b] = (char)i;
/*     */     } 
/* 143 */     return paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 149 */     this.cpp.close();
/* 150 */     this.token = null;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/CppReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */