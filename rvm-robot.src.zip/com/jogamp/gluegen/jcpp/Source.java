/*     */ package com.jogamp.gluegen.jcpp;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import javax.annotation.CheckForNull;
/*     */ import javax.annotation.Nonnegative;
/*     */ import javax.annotation.Nonnull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Source
/*     */   implements Iterable<Token>, Closeable
/*     */ {
/*  87 */   private Source parent = null;
/*     */   private boolean autopop = false;
/*  89 */   private PreprocessorListener listener = null;
/*     */ 
/*     */   
/*     */   private boolean active = true;
/*     */ 
/*     */   
/*     */   private boolean werror = false;
/*     */ 
/*     */ 
/*     */   
/*     */   void setParent(Source paramSource, boolean paramBoolean) {
/* 100 */     this.parent = paramSource;
/* 101 */     this.autopop = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Source getParent() {
/* 110 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void init(Preprocessor paramPreprocessor) {
/* 116 */     setListener(paramPreprocessor.getListener());
/* 117 */     this.werror = paramPreprocessor.getWarnings().contains(Warning.ERROR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListener(PreprocessorListener paramPreprocessorListener) {
/* 128 */     this.listener = paramPreprocessorListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @CheckForNull
/*     */   public String getPath() {
/* 140 */     Source source = getParent();
/* 141 */     if (source != null)
/* 142 */       return source.getPath(); 
/* 143 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @CheckForNull
/*     */   public String getName() {
/* 151 */     Source source = getParent();
/* 152 */     if (source != null)
/* 153 */       return source.getName(); 
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnegative
/*     */   public int getLine() {
/* 162 */     Source source = getParent();
/* 163 */     if (source == null)
/* 164 */       return 0; 
/* 165 */     return source.getLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 172 */     Source source = getParent();
/* 173 */     if (source == null)
/* 174 */       return 0; 
/* 175 */     return source.getColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isExpanding(@Nonnull Macro paramMacro) {
/* 184 */     Source source = getParent();
/* 185 */     if (source != null)
/* 186 */       return source.isExpanding(paramMacro); 
/* 187 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isAutopop() {
/* 197 */     return this.autopop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isNumbered() {
/* 204 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setActive(boolean paramBoolean) {
/* 210 */     this.active = paramBoolean;
/*     */   }
/*     */   
/*     */   boolean isActive() {
/* 214 */     return this.active;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public abstract Token token() throws IOException, LexerException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Token> iterator() {
/* 232 */     return new SourceIterator(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public Token skipline(boolean paramBoolean) throws IOException, LexerException {
/*     */     while (true) {
/* 247 */       Token token = token();
/* 248 */       switch (token.getType()) {
/*     */ 
/*     */ 
/*     */         
/*     */         case 265:
/* 253 */           warning(token.getLine(), token.getColumn(), "No newline before end of file");
/*     */           
/* 255 */           return new Token(284, token
/* 256 */               .getLine(), token.getColumn(), "\n");
/*     */ 
/*     */ 
/*     */         
/*     */         case 284:
/* 261 */           return token;
/*     */         
/*     */         case 260:
/*     */         case 261:
/*     */         case 294:
/*     */           continue;
/*     */       } 
/* 268 */       if (paramBoolean) {
/* 269 */         warning(token.getLine(), token.getColumn(), "Unexpected nonwhite token");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void error(int paramInt1, int paramInt2, String paramString) throws LexerException {
/* 278 */     if (this.listener != null) {
/* 279 */       this.listener.handleError(this, paramInt1, paramInt2, paramString);
/*     */     } else {
/* 281 */       throw new LexerException("Error at " + paramInt1 + ":" + paramInt2 + ": " + paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void warning(int paramInt1, int paramInt2, String paramString) throws LexerException {
/* 286 */     if (this.werror) {
/* 287 */       error(paramInt1, paramInt2, paramString);
/* 288 */     } else if (this.listener != null) {
/* 289 */       this.listener.handleWarning(this, paramInt1, paramInt2, paramString);
/*     */     } else {
/* 291 */       throw new LexerException("Warning at " + paramInt1 + ":" + paramInt2 + ": " + paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {}
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/Source.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */