package com.jogamp.gluegen.jcpp;

import javax.annotation.Nonnull;

public interface VirtualFileSystem {
  @Nonnull
  VirtualFile getFile(@Nonnull String paramString);
  
  @Nonnull
  VirtualFile getFile(@Nonnull String paramString1, @Nonnull String paramString2);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/VirtualFileSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */