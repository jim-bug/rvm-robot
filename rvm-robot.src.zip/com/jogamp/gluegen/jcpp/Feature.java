/*    */ package com.jogamp.gluegen.jcpp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Feature
/*    */ {
/* 25 */   DIGRAPHS,
/*    */   
/* 27 */   TRIGRAPHS,
/*    */   
/* 29 */   LINEMARKERS,
/*    */   
/* 31 */   CSYNTAX,
/*    */   
/* 33 */   KEEPCOMMENTS,
/*    */   
/* 35 */   KEEPALLCOMMENTS,
/* 36 */   DEBUG,
/*    */   
/* 38 */   OBJCSYNTAX,
/* 39 */   INCLUDENEXT,
/*    */   
/* 41 */   PRAGMA_ONCE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   UNIFIED_OUTPUT;
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jcpp/Feature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */