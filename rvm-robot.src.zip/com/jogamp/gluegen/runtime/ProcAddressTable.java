/*     */ package com.jogamp.gluegen.runtime;
/*     */ 
/*     */ import com.jogamp.common.os.DynamicLookupHelper;
/*     */ import com.jogamp.common.util.SecurityUtil;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Field;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ProcAddressTable
/*     */ {
/*     */   private static final String PROCADDRESS_VAR_PREFIX = "_addressof_";
/*  82 */   private static final int PROCADDRESS_VAR_PREFIX_LEN = "_addressof_".length();
/*     */   
/*     */   protected static boolean DEBUG;
/*     */   
/*     */   protected static String DEBUG_PREFIX;
/*     */   protected static int debugNum;
/*     */   private final FunctionAddressResolver resolver;
/*     */   
/*     */   static {
/*  91 */     SecurityUtil.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/*  94 */             ProcAddressTable.DEBUG = (System.getProperty("jogamp.debug.ProcAddressHelper") != null);
/*  95 */             if (ProcAddressTable.DEBUG) {
/*  96 */               ProcAddressTable.DEBUG_PREFIX = System.getProperty("jogamp.debug.ProcAddressHelper.prefix");
/*     */             }
/*  98 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public ProcAddressTable() {
/* 104 */     this(new One2OneResolver(null));
/*     */   }
/*     */   
/*     */   public ProcAddressTable(FunctionAddressResolver paramFunctionAddressResolver) {
/* 108 */     this.resolver = paramFunctionAddressResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(DynamicLookupHelper paramDynamicLookupHelper) throws SecurityException, RuntimeException {
/*     */     PrintStream printStream;
/* 121 */     if (null == paramDynamicLookupHelper) {
/* 122 */       throw new RuntimeException("Passed null DynamicLookupHelper");
/*     */     }
/*     */     
/* 125 */     Field[] arrayOfField = getClass().getDeclaredFields();
/*     */ 
/*     */     
/* 128 */     if (DEBUG) {
/* 129 */       printStream = getDebugOutStream();
/* 130 */       printStream.println(getClass().getName() + ".reset() (w/ " + arrayOfField.length + " prospective fields)");
/*     */     } else {
/* 132 */       printStream = null;
/*     */     } 
/*     */ 
/*     */     
/* 136 */     AccessibleObject.setAccessible((AccessibleObject[])arrayOfField, true);
/* 137 */     paramDynamicLookupHelper.claimAllLinkPermission();
/*     */     try {
/* 139 */       for (byte b = 0; b < arrayOfField.length; b++) {
/* 140 */         String str = arrayOfField[b].getName();
/* 141 */         if (isAddressField(str)) {
/* 142 */           String str1 = fieldToFunctionName(str);
/* 143 */           setEntry(arrayOfField[b], str1, paramDynamicLookupHelper);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 147 */       paramDynamicLookupHelper.releaseAllLinkPermission();
/*     */     } 
/*     */     
/* 150 */     if (DEBUG) {
/* 151 */       printStream.flush();
/* 152 */       if (DEBUG_PREFIX != null) {
/* 153 */         printStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initEntry(String paramString, DynamicLookupHelper paramDynamicLookupHelper) throws SecurityException, IllegalArgumentException {
/* 169 */     Field field = fieldForFunction(paramString);
/* 170 */     field.setAccessible(true);
/* 171 */     setEntry(field, paramString, paramDynamicLookupHelper);
/*     */   }
/*     */   
/*     */   private final void setEntry(Field paramField, String paramString, DynamicLookupHelper paramDynamicLookupHelper) throws SecurityException {
/*     */     try {
/* 176 */       assert paramField.getType() == long.class;
/* 177 */       long l = this.resolver.resolve(paramString, paramDynamicLookupHelper);
/* 178 */       paramField.setLong(this, l);
/* 179 */       if (DEBUG) {
/* 180 */         getDebugOutStream().println("  " + paramField.getName() + " -> 0x" + Long.toHexString(l));
/*     */       }
/* 182 */     } catch (Exception exception) {
/* 183 */       throw new RuntimeException("Can not get proc address for method \"" + paramString + "\": Couldn't set value of field \"" + paramField, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final String fieldToFunctionName(String paramString) {
/* 189 */     return paramString.substring(PROCADDRESS_VAR_PREFIX_LEN);
/*     */   }
/*     */   
/*     */   private final Field fieldForFunction(String paramString) throws IllegalArgumentException {
/*     */     try {
/* 194 */       return getClass().getDeclaredField("_addressof_" + paramString);
/* 195 */     } catch (NoSuchFieldException noSuchFieldException) {
/* 196 */       throw new IllegalArgumentException(getClass().getName() + " has no entry for the function '" + paramString + "'.", noSuchFieldException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Field fieldForFunctionInSec(final String name) throws IllegalArgumentException {
/* 209 */     return (Field)SecurityUtil.doPrivileged(new PrivilegedAction<Field>()
/*     */         {
/*     */           public Field run() {
/*     */             try {
/* 213 */               Field field = ProcAddressTable.this.getClass().getDeclaredField("_addressof_" + name);
/* 214 */               field.setAccessible(true);
/* 215 */               return field;
/* 216 */             } catch (NoSuchFieldException noSuchFieldException) {
/* 217 */               throw new IllegalArgumentException(getClass().getName() + " has no entry for the function '" + name + "'.", noSuchFieldException);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private final boolean isAddressField(String paramString) {
/* 224 */     return paramString.startsWith("_addressof_");
/*     */   }
/*     */   
/*     */   private static final PrintStream getDebugOutStream() {
/* 228 */     PrintStream printStream = null;
/* 229 */     if (DEBUG) {
/* 230 */       if (DEBUG_PREFIX != null) {
/*     */         try {
/* 232 */           printStream = new PrintStream(new BufferedOutputStream(new FileOutputStream(DEBUG_PREFIX + File.separatorChar + "procaddresstable-" + ++debugNum + ".txt")));
/*     */         }
/* 234 */         catch (IOException iOException) {
/* 235 */           iOException.printStackTrace();
/* 236 */           printStream = System.err;
/*     */         } 
/*     */       } else {
/* 239 */         printStream = System.err;
/*     */       } 
/*     */     }
/* 242 */     return printStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, Long> toMap() {
/* 249 */     TreeMap<Object, Object> treeMap = new TreeMap<>();
/*     */     
/* 251 */     Field[] arrayOfField = getClass().getFields();
/*     */     try {
/* 253 */       for (byte b = 0; b < arrayOfField.length; b++) {
/* 254 */         String str = arrayOfField[b].getName();
/* 255 */         if (isAddressField(str)) {
/* 256 */           treeMap.put(fieldToFunctionName(str), arrayOfField[b].get(this));
/*     */         }
/*     */       } 
/* 259 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 260 */       throw new RuntimeException(illegalArgumentException);
/* 261 */     } catch (IllegalAccessException illegalAccessException) {
/* 262 */       throw new RuntimeException(illegalAccessException);
/*     */     } 
/*     */     
/* 265 */     return (Map)treeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isFunctionAvailable(String paramString) {
/*     */     try {
/* 273 */       return isFunctionAvailableImpl(paramString);
/* 274 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 275 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isFunctionAvailableImpl(String paramString) throws IllegalArgumentException {
/* 290 */     Field field = fieldForFunctionInSec(paramString);
/*     */     try {
/* 292 */       return (0L != field.getLong(this));
/* 293 */     } catch (IllegalAccessException illegalAccessException) {
/* 294 */       throw new RuntimeException(illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAddressFor(String paramString) throws SecurityException, IllegalArgumentException {
/* 314 */     SecurityUtil.checkAllLinkPermission();
/* 315 */     Field field = fieldForFunctionInSec(paramString);
/*     */     try {
/* 317 */       return field.getLong(this);
/* 318 */     } catch (IllegalAccessException illegalAccessException) {
/* 319 */       throw new RuntimeException(illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Set<String> getNullPointerFunctions() {
/* 327 */     Map<String, Long> map = toMap();
/* 328 */     LinkedHashSet<String> linkedHashSet = new LinkedHashSet();
/* 329 */     for (Map.Entry<String, Long> entry : map.entrySet()) {
/*     */       
/* 331 */       long l = ((Long)entry.getValue()).longValue();
/* 332 */       if (l == 0L) {
/* 333 */         linkedHashSet.add((String)entry.getKey());
/*     */       }
/*     */     } 
/* 336 */     return linkedHashSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 341 */     return getClass().getName() + "" + toMap();
/*     */   }
/*     */   
/*     */   private static class One2OneResolver
/*     */     implements FunctionAddressResolver {
/*     */     public long resolve(String param1String, DynamicLookupHelper param1DynamicLookupHelper) throws SecurityException {
/* 347 */       return param1DynamicLookupHelper.dynamicLookupFunction(param1String);
/*     */     }
/*     */     
/*     */     private One2OneResolver() {}
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/runtime/ProcAddressTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */