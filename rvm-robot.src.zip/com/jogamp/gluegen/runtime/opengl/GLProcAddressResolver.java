/*    */ package com.jogamp.gluegen.runtime.opengl;
/*    */ 
/*    */ import com.jogamp.common.os.DynamicLookupHelper;
/*    */ import com.jogamp.gluegen.runtime.FunctionAddressResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLProcAddressResolver
/*    */   implements FunctionAddressResolver
/*    */ {
/*    */   public static final boolean DEBUG = false;
/*    */   
/*    */   public long resolve(String paramString, DynamicLookupHelper paramDynamicLookupHelper) throws SecurityException {
/* 46 */     long l = 0L;
/* 47 */     int i = GLNameResolver.getFuncNamePermutationNumber(paramString);
/*    */     
/* 49 */     for (byte b = 0; 0L == l && b < i; b++) {
/* 50 */       String str = GLNameResolver.getFuncNamePermutation(paramString, b);
/*    */       try {
/* 52 */         l = paramDynamicLookupHelper.dynamicLookupFunction(str);
/* 53 */       } catch (Exception exception) {}
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 59 */     return l;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/runtime/opengl/GLProcAddressResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */