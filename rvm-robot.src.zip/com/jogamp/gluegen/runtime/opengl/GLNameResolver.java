/*     */ package com.jogamp.gluegen.runtime.opengl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GLNameResolver
/*     */ {
/*  50 */   private static final String[] extensionsARB = new String[] { "ARB", "GL2", "OES", "KHR", "OML" };
/*  51 */   private static final String[] extensionsVEN = new String[] { "3DFX", "AMD", "ANDROID", "ANGLE", "ARM", "APPLE", "ATI", "EXT", "FJ", "HI", "HP", "IBM", "IMG", "INGR", "INTEL", "MESA", "MESAX", "NV", "PGI", "QCOM", "SGI", "SGIS", "SGIX", "SUN", "VIV", "WIN" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isGLFunction(String paramString) {
/*  79 */     return (paramString.startsWith("gl") || paramString
/*  80 */       .startsWith("egl") || paramString.startsWith("wgl") || paramString.startsWith("agl") || paramString
/*  81 */       .startsWith("cgl"));
/*     */   }
/*     */   
/*     */   public static final boolean isGLEnumeration(String paramString) {
/*  85 */     return (paramString.startsWith("GL_") || paramString.startsWith("GLU_") || paramString.startsWith("GLX_") || paramString
/*  86 */       .startsWith("EGL_") || paramString.startsWith("WGL_") || paramString.startsWith("AGL_") || paramString
/*  87 */       .startsWith("CGL_"));
/*     */   }
/*     */   
/*     */   public static final int getExtensionIdx(String[] paramArrayOfString, String paramString, boolean paramBoolean) {
/*  91 */     if (paramBoolean) {
/*  92 */       for (int i = paramArrayOfString.length - 1; i >= 0; i--) {
/*  93 */         if (paramString.endsWith(paramArrayOfString[i])) {
/*  94 */           return i;
/*     */         }
/*     */       } 
/*     */     } else {
/*  98 */       for (int i = paramArrayOfString.length - 1; i >= 0; i--) {
/*  99 */         if (paramString.endsWith("_" + paramArrayOfString[i])) {
/* 100 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/* 104 */     return -1;
/*     */   }
/*     */   
/*     */   public static final boolean isExtension(String[] paramArrayOfString, String paramString, boolean paramBoolean) {
/* 108 */     return (getExtensionIdx(paramArrayOfString, paramString, paramBoolean) >= 0);
/*     */   }
/*     */   
/*     */   public static final String getExtensionSuffix(String paramString, boolean paramBoolean) {
/* 112 */     int i = getExtensionIdx(extensionsARB, paramString, paramBoolean);
/* 113 */     if (i >= 0) {
/* 114 */       return extensionsARB[i];
/*     */     }
/* 116 */     i = getExtensionIdx(extensionsVEN, paramString, paramBoolean);
/* 117 */     if (i >= 0) {
/* 118 */       return extensionsVEN[i];
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   public static final String normalize(String[] paramArrayOfString, String paramString, boolean paramBoolean) {
/* 124 */     boolean bool = false;
/* 125 */     for (int i = paramArrayOfString.length - 1; !bool && i >= 0; i--) {
/* 126 */       if (paramBoolean) {
/* 127 */         if (paramString.endsWith(paramArrayOfString[i]))
/*     */         {
/* 129 */           paramString = paramString.substring(0, paramString.length() - paramArrayOfString[i].length());
/* 130 */           bool = true;
/*     */         }
/*     */       
/* 133 */       } else if (paramString.endsWith("_" + paramArrayOfString[i])) {
/*     */         
/* 135 */         paramString = paramString.substring(0, paramString.length() - 1 - paramArrayOfString[i].length());
/* 136 */         bool = true;
/*     */       } 
/*     */     } 
/*     */     
/* 140 */     return paramString;
/*     */   }
/*     */   public static final String normalizeARB(String paramString, boolean paramBoolean) {
/* 143 */     return normalize(extensionsARB, paramString, paramBoolean);
/*     */   }
/*     */   public static final boolean isExtensionARB(String paramString, boolean paramBoolean) {
/* 146 */     return isExtension(extensionsARB, paramString, paramBoolean);
/*     */   }
/*     */   public static final String normalizeVEN(String paramString, boolean paramBoolean) {
/* 149 */     return normalize(extensionsVEN, paramString, paramBoolean);
/*     */   }
/*     */   public static final boolean isExtensionVEN(String paramString, boolean paramBoolean) {
/* 152 */     return isExtension(extensionsVEN, paramString, paramBoolean);
/*     */   }
/*     */   public static final String normalize(String paramString, boolean paramBoolean) {
/* 155 */     if (isExtensionARB(paramString, paramBoolean)) {
/* 156 */       return normalizeARB(paramString, paramBoolean);
/*     */     }
/* 158 */     if (isExtensionVEN(paramString, paramBoolean)) {
/* 159 */       return normalizeVEN(paramString, paramBoolean);
/*     */     }
/* 161 */     return paramString;
/*     */   }
/*     */   public static final boolean isExtension(String paramString, boolean paramBoolean) {
/* 164 */     return (isExtension(extensionsARB, paramString, paramBoolean) || 
/* 165 */       isExtension(extensionsVEN, paramString, paramBoolean));
/*     */   }
/*     */   
/*     */   public static final int getFuncNamePermutationNumber(String paramString) {
/* 169 */     if (isExtensionARB(paramString, true) || isExtensionVEN(paramString, true))
/*     */     {
/* 171 */       return 1;
/*     */     }
/* 173 */     return 1 + extensionsARB.length + extensionsVEN.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final String getFuncNamePermutation(String paramString, int paramInt) {
/* 178 */     if (paramInt == 0) {
/* 179 */       return paramString;
/*     */     }
/* 181 */     if (0 > paramInt || paramInt >= 1 + extensionsARB.length + extensionsVEN.length) {
/* 182 */       throw new RuntimeException("Index out of range [0.." + (1 + extensionsARB.length + extensionsVEN.length - 1) + "]: " + paramInt);
/*     */     }
/*     */     
/* 185 */     paramInt--;
/* 186 */     if (paramInt < extensionsARB.length) {
/* 187 */       return paramString + extensionsARB[paramInt];
/*     */     }
/*     */     
/* 190 */     paramInt -= extensionsARB.length;
/* 191 */     return paramString + extensionsVEN[paramInt];
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/runtime/opengl/GLNameResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */