package com.jogamp.gluegen.runtime;

import com.jogamp.common.os.DynamicLookupHelper;

public interface FunctionAddressResolver {
  long resolve(String paramString, DynamicLookupHelper paramDynamicLookupHelper) throws SecurityException;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/runtime/FunctionAddressResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */