/*     */ package com.jogamp.gluegen.ant;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.taskdefs.Execute;
/*     */ import org.apache.tools.ant.taskdefs.ExecuteStreamHandler;
/*     */ import org.apache.tools.ant.taskdefs.LogStreamHandler;
/*     */ import org.apache.tools.ant.types.AbstractFileSet;
/*     */ import org.apache.tools.ant.types.CommandlineJava;
/*     */ import org.apache.tools.ant.types.DirSet;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.PatternSet;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import org.apache.tools.ant.util.JavaEnvUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlueGenTask
/*     */   extends Task
/*     */ {
/*     */   private static final String GLUE_GEN = "com.jogamp.gluegen.GlueGen";
/*     */   private final CommandlineJava gluegenCommandline;
/*     */   private boolean debug = false;
/* 107 */   private String logLevel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dumpCPP = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String outputRootDir;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String emitter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String sourceFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   private final FileSet includeSet = new FileSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean usedIncludeSet = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   private final List<AbstractFileSet> setOfIncludeSets = new LinkedList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String literalIncludes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlueGenTask() {
/* 170 */     this.gluegenCommandline = new CommandlineJava();
/*     */ 
/*     */     
/* 173 */     this.gluegenCommandline.setVm(JavaEnvUtils.getJreExecutable("java"));
/* 174 */     this.gluegenCommandline.setClassname("com.jogamp.gluegen.GlueGen");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDebug(boolean paramBoolean) {
/* 186 */     log("Setting debug flag: " + paramBoolean, 3);
/* 187 */     this.debug = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogLevel(String paramString) {
/* 195 */     log("Setting logLevel: " + paramString, 3);
/* 196 */     this.logLevel = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDumpCPP(boolean paramBoolean) {
/* 204 */     log("Setting dumpCPP flag: " + paramBoolean, 3);
/* 205 */     this.dumpCPP = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputRootDir(String paramString) {
/* 215 */     log("Setting output root dir: " + paramString, 3);
/* 216 */     this.outputRootDir = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEmitter(String paramString) {
/* 226 */     log("Setting emitter class name to: " + paramString, 3);
/* 227 */     this.emitter = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfig(String paramString) {
/* 237 */     log("Setting configuration file name to: " + paramString, 3);
/*     */     
/* 239 */     this.configuration = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSrc(String paramString) {
/* 249 */     log("Setting source file name to: " + paramString, 3);
/* 250 */     this.sourceFile = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLiteralInclude(String paramString) {
/* 261 */     this.literalIncludes = paramString.trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatternSet.NameEntry createInclude() {
/* 272 */     this.usedIncludeSet = true;
/* 273 */     return this.includeSet.createInclude();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatternSet.NameEntry createIncludesFile() {
/* 284 */     this.usedIncludeSet = true;
/* 285 */     return this.includeSet.createIncludesFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludes(String paramString) {
/* 296 */     this.usedIncludeSet = true;
/* 297 */     this.includeSet.setIncludes(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatternSet.NameEntry createExclude() {
/* 308 */     this.usedIncludeSet = true;
/* 309 */     return this.includeSet.createExclude();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatternSet.NameEntry createExcludesFile() {
/* 320 */     this.usedIncludeSet = true;
/* 321 */     return this.includeSet.createExcludesFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExcludes(String paramString) {
/* 332 */     this.usedIncludeSet = true;
/* 333 */     this.includeSet.setExcludes(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludeRefid(Reference paramReference) {
/* 347 */     Object object = paramReference.getReferencedObject(getProject());
/* 348 */     if (object instanceof FileSet) {
/* 349 */       this.setOfIncludeSets.add(object);
/*     */       return;
/*     */     } 
/* 352 */     if (object instanceof DirSet) {
/* 353 */       this.setOfIncludeSets.add(object);
/*     */       
/*     */       return;
/*     */     } 
/* 357 */     throw new BuildException("Only FileSets or DirSets are allowed as an include refid.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDirset(DirSet paramDirSet) {
/* 368 */     this.setOfIncludeSets.add(paramDirSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/* 379 */     return this.gluegenCommandline.createClasspath(this.project).createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute() throws BuildException {
/* 394 */     validateAttributes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 400 */     addAttributes();
/*     */     
/* 402 */     log(this.gluegenCommandline.describeCommand(), 3);
/*     */ 
/*     */     
/* 405 */     int i = execute(this.gluegenCommandline.getCommandline());
/* 406 */     if (i == 1) {
/* 407 */       throw new BuildException("GlueGen returned: " + i, this.location);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateAttributes() throws BuildException {
/* 422 */     if (!isValid(this.emitter)) {
/* 423 */       throw new BuildException("Invalid emitter class name: " + this.emitter);
/*     */     }
/*     */     
/* 426 */     if (!isValid(this.configuration)) {
/* 427 */       throw new BuildException("Invalid configuration file name: " + this.configuration);
/*     */     }
/*     */     
/* 430 */     if (!isValid(this.sourceFile)) {
/* 431 */       throw new BuildException("Invalid source file name: " + this.sourceFile);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isValid(String paramString) {
/* 447 */     if (paramString == null) {
/* 448 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 452 */     if (paramString.trim().length() < 1) {
/* 453 */       return false;
/*     */     }
/*     */     
/* 456 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addAttributes() throws BuildException {
/* 470 */     if (this.debug) {
/* 471 */       this.gluegenCommandline.createArgument().setValue("--debug");
/*     */     }
/*     */ 
/*     */     
/* 475 */     if (null != this.logLevel) {
/* 476 */       this.gluegenCommandline.createArgument().setValue("--logLevel");
/* 477 */       this.gluegenCommandline.createArgument().setValue(this.logLevel);
/*     */     } 
/*     */ 
/*     */     
/* 481 */     if (this.dumpCPP) {
/* 482 */       this.gluegenCommandline.createArgument().setValue("--dumpCPP");
/*     */     }
/*     */ 
/*     */     
/* 486 */     if (null != this.outputRootDir && this.outputRootDir.trim().length() > 0) {
/* 487 */       this.gluegenCommandline.createArgument().setValue("-O" + this.outputRootDir);
/*     */     }
/*     */ 
/*     */     
/* 491 */     this.gluegenCommandline.createArgument().setValue("-E" + this.emitter);
/*     */ 
/*     */     
/* 494 */     this.gluegenCommandline.createArgument().setValue("-C" + this.configuration);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 501 */     if (this.usedIncludeSet) {
/*     */       
/* 503 */       this.includeSet.setDir(getProject().getBaseDir());
/* 504 */       this.setOfIncludeSets.add(this.includeSet);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 509 */     LinkedList<String> linkedList = new LinkedList();
/* 510 */     for (AbstractFileSet abstractFileSet : this.setOfIncludeSets) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 515 */       DirectoryScanner directoryScanner = abstractFileSet.getDirectoryScanner(getProject());
/* 516 */       String[] arrayOfString = directoryScanner.getIncludedDirectories();
/*     */ 
/*     */ 
/*     */       
/* 520 */       for (byte b = 0; b < arrayOfString.length; b++)
/*     */       {
/* 522 */         linkedList.add(arrayOfString[b]);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 528 */     if (isValid(this.literalIncludes)) {
/* 529 */       String[] arrayOfString = this.literalIncludes.split(",");
/* 530 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 531 */         String str = arrayOfString[b].trim();
/* 532 */         if (str.length() > 0) {
/* 533 */           linkedList.add(str);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 539 */     for (String str : linkedList)
/*     */     {
/*     */       
/* 542 */       this.gluegenCommandline.createArgument().setValue("-I" + str);
/*     */     }
/*     */ 
/*     */     
/* 546 */     this.gluegenCommandline.createArgument().setValue(this.sourceFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int execute(String[] paramArrayOfString) throws BuildException {
/* 558 */     Execute execute = new Execute((ExecuteStreamHandler)new LogStreamHandler(this, 2, 1), null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 563 */     execute.setAntRun(this.project);
/* 564 */     execute.setCommandline(paramArrayOfString);
/* 565 */     execute.setWorkingDirectory(this.project.getBaseDir());
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 570 */       return execute.execute();
/* 571 */     } catch (IOException iOException) {
/*     */       
/* 573 */       throw new BuildException(iOException, this.location);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/ant/GlueGenTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */