/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import com.jogamp.common.util.PropertyAccess;
/*     */ import com.jogamp.gluegen.cgram.types.AliasedSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.ConsoleHandler;
/*     */ import java.util.logging.Formatter;
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogRecord;
/*     */ import java.util.logging.Logger;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Logging
/*     */ {
/*  54 */   public static final boolean DEBUG = Debug.debug("Logging");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class FQNLogger
/*     */     implements LoggerIf
/*     */   {
/*     */     public final Logger impl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Logging.PlainLogConsoleHandler handler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FQNLogger(String param1String1, String param1String2, Level param1Level) {
/* 146 */       this.impl = Logger.getLogger(param1String1);
/* 147 */       this.handler = new Logging.PlainLogConsoleHandler(new Logging.PlainLogFormatter(param1String2), Level.ALL);
/* 148 */       this.impl.setUseParentHandlers(false);
/* 149 */       this.impl.setLevel(param1Level);
/* 150 */       this.impl.addHandler(this.handler);
/* 151 */       this.impl.log(Level.INFO, "Logging.new: " + this.impl.getName() + ": level " + param1Level + ": obj 0x" + 
/* 152 */           Integer.toHexString(this.impl.hashCode()));
/*     */     }
/*     */     
/*     */     public void info(String param1String) {
/* 156 */       this.impl.info(param1String);
/*     */     }
/*     */     
/*     */     public void info(ASTLocusTag param1ASTLocusTag, String param1String) {
/* 160 */       this.handler.plf.setASTLocusTag(param1ASTLocusTag);
/*     */       try {
/* 162 */         this.impl.info(param1String);
/*     */       } finally {
/* 164 */         this.handler.plf.setASTLocusTag(null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void warning(String param1String) {
/* 170 */       this.impl.warning(param1String);
/*     */     }
/*     */     
/*     */     public void warning(ASTLocusTag param1ASTLocusTag, String param1String) {
/* 174 */       this.handler.plf.setASTLocusTag(param1ASTLocusTag);
/*     */       try {
/* 176 */         this.impl.warning(param1String);
/*     */       } finally {
/* 178 */         this.handler.plf.setASTLocusTag(null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(String param1String) {
/* 184 */       log(Level.FINE, param1String);
/*     */     }
/*     */     
/*     */     public void debug(ASTLocusTag param1ASTLocusTag, String param1String) {
/* 188 */       log(Level.FINE, param1ASTLocusTag, param1String);
/*     */     }
/*     */ 
/*     */     
/*     */     public void log(Level param1Level, String param1String) {
/* 193 */       this.impl.log(param1Level, param1String);
/*     */     }
/*     */     
/*     */     public void log(Level param1Level, String param1String, Object param1Object) {
/* 197 */       this.impl.log(param1Level, param1String, param1Object);
/*     */     }
/*     */     
/*     */     public void log(Level param1Level, String param1String, Object... param1VarArgs) {
/* 201 */       this.impl.log(param1Level, param1String, param1VarArgs);
/*     */     }
/*     */ 
/*     */     
/*     */     public void log(Level param1Level, ASTLocusTag param1ASTLocusTag, String param1String) {
/* 206 */       this.handler.plf.setASTLocusTag(param1ASTLocusTag);
/*     */       try {
/* 208 */         this.impl.log(param1Level, param1String);
/*     */       } finally {
/* 210 */         this.handler.plf.setASTLocusTag(null);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void log(Level param1Level, ASTLocusTag param1ASTLocusTag, String param1String, Object param1Object) {
/* 215 */       this.handler.plf.setASTLocusTag(param1ASTLocusTag);
/*     */       try {
/* 217 */         this.impl.log(param1Level, param1String, param1Object);
/*     */       } finally {
/* 219 */         this.handler.plf.setASTLocusTag(null);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void log(Level param1Level, ASTLocusTag param1ASTLocusTag, String param1String, Object... param1VarArgs) {
/* 224 */       this.handler.plf.setASTLocusTag(param1ASTLocusTag);
/*     */       try {
/* 226 */         this.impl.log(param1Level, param1String, param1VarArgs);
/*     */       } finally {
/* 228 */         this.handler.plf.setASTLocusTag(null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLevel(Level param1Level) throws SecurityException {
/* 234 */       this.impl.setLevel(param1Level);
/*     */     }
/*     */     
/*     */     public void setLevelOfAllHandler(Level param1Level) throws SecurityException {
/* 238 */       Handler[] arrayOfHandler = getHandlers();
/* 239 */       for (Handler handler : arrayOfHandler) {
/* 240 */         handler.setLevel(param1Level);
/*     */       }
/*     */     }
/*     */     
/*     */     public Level getLevel() {
/* 245 */       return this.impl.getLevel();
/*     */     }
/*     */     
/*     */     public boolean isLoggable(Level param1Level) {
/* 249 */       return this.impl.isLoggable(param1Level);
/*     */     }
/*     */     
/*     */     public String getName() {
/* 253 */       return this.impl.getName();
/*     */     }
/*     */     
/*     */     public synchronized Handler[] getHandlers() {
/* 257 */       return this.impl.getHandlers();
/*     */     }
/*     */     
/*     */     public String getSourceClassName() {
/* 261 */       return this.handler.plf.simpleClassName;
/*     */     } }
/*     */   
/*     */   static class PlainLogConsoleHandler extends ConsoleHandler { final Logging.PlainLogFormatter plf;
/*     */     
/*     */     PlainLogConsoleHandler(Logging.PlainLogFormatter param1PlainLogFormatter, Level param1Level) {
/* 267 */       this.plf = param1PlainLogFormatter;
/* 268 */       setFormatter(param1PlainLogFormatter);
/* 269 */       setLevel(param1Level);
/*     */     }
/*     */     
/*     */     public Formatter getFormatter() {
/* 273 */       return this.plf;
/*     */     } }
/*     */   
/*     */   static class PlainLogFormatter extends Formatter {
/*     */     final String simpleClassName;
/*     */     
/*     */     PlainLogFormatter(String param1String) {
/* 280 */       this.simpleClassName = param1String;
/*     */     } ASTLocusTag astLocus; public void setASTLocusTag(ASTLocusTag param1ASTLocusTag) {
/* 282 */       this.astLocus = param1ASTLocusTag;
/*     */     }
/*     */     
/*     */     public String format(LogRecord param1LogRecord) {
/* 286 */       Object[] arrayOfObject = param1LogRecord.getParameters();
/* 287 */       if (null != arrayOfObject) {
/* 288 */         for (int i = arrayOfObject.length - 1; 0 <= i; i--) {
/* 289 */           Object object = arrayOfObject[i];
/* 290 */           if (object instanceof Type) {
/* 291 */             arrayOfObject[i] = ((Type)object).getDebugString();
/* 292 */           } else if (object instanceof JavaType) {
/* 293 */             arrayOfObject[i] = ((JavaType)object).getDebugString();
/* 294 */           } else if (object instanceof AliasedSymbol) {
/* 295 */             arrayOfObject[i] = ((AliasedSymbol)object).getAliasedString();
/*     */           } 
/*     */         } 
/*     */       }
/* 299 */       StringBuilder stringBuilder = new StringBuilder(256);
/* 300 */       if (null != this.astLocus) {
/* 301 */         this.astLocus.toString(stringBuilder, Logging.getCanonicalName(param1LogRecord.getLevel()), GlueGen.debug()).append(": ");
/*     */       }
/* 303 */       if (GlueGen.debug()) {
/* 304 */         stringBuilder.append(this.simpleClassName).append(": ");
/*     */       }
/* 306 */       stringBuilder.append(formatMessage(param1LogRecord)).append("\n");
/* 307 */       return stringBuilder.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final FQNLogger rootPackageLogger;
/*     */   
/* 314 */   private static final Map<String, LoggerIf> loggers = new HashMap<>(); static {
/* 315 */     String str1 = Logging.class.getPackage().getName();
/* 316 */     String str2 = PropertyAccess.getProperty(str1 + ".level", true);
/*     */     
/* 318 */     if (str2 != null) {
/* 319 */       level = Level.parse(str2);
/*     */     }
/* 321 */     else if (DEBUG || GlueGen.debug()) {
/* 322 */       level = Level.ALL;
/*     */     } else {
/* 324 */       level = Level.WARNING;
/*     */     } 
/*     */     
/* 327 */     String str3 = Logging.class.getSimpleName();
/* 328 */     String str4 = str1 + "." + str3;
/* 329 */     rootPackageLogger = new FQNLogger(str4, str3, level);
/* 330 */     loggers.put(str4, rootPackageLogger);
/*     */   }
/*     */   static {
/*     */     Level level;
/*     */   }
/*     */   
/*     */   public static String getCanonicalName(Level paramLevel) {
/* 337 */     if (Level.CONFIG == paramLevel)
/* 338 */       return "config"; 
/* 339 */     if (Level.FINER == paramLevel)
/* 340 */       return "verbose"; 
/* 341 */     if (Level.FINE == paramLevel)
/* 342 */       return "debug"; 
/* 343 */     if (Level.INFO == paramLevel)
/* 344 */       return "info"; 
/* 345 */     if (Level.WARNING == paramLevel)
/* 346 */       return "warning"; 
/* 347 */     if (Level.SEVERE == paramLevel) {
/* 348 */       return "error";
/*     */     }
/* 350 */     return paramLevel.getName().toLowerCase();
/*     */   }
/*     */   
/*     */   static void init() {}
/*     */   
/*     */   public static LoggerIf getLogger() {
/* 356 */     return rootPackageLogger;
/*     */   }
/*     */   
/*     */   public static synchronized LoggerIf getLogger(Class<?> paramClass) {
/* 360 */     return getLogger(paramClass.getPackage().getName(), paramClass.getSimpleName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized LoggerIf getLogger(String paramString1, String paramString2) {
/* 365 */     String str = paramString1 + "." + paramString2;
/* 366 */     LoggerIf loggerIf = loggers.get(str);
/* 367 */     if (null == loggerIf) {
/* 368 */       loggerIf = new FQNLogger(str, paramString2, rootPackageLogger.getLevel());
/* 369 */       loggers.put(str, loggerIf);
/*     */     } 
/* 371 */     return loggerIf;
/*     */   }
/*     */   
/*     */   public static void alignLevel(LoggerIf paramLoggerIf) {
/* 375 */     alignLevel(paramLoggerIf, rootPackageLogger.getLevel());
/*     */   }
/*     */   
/*     */   public static void alignLevel(LoggerIf paramLoggerIf, Level paramLevel) {
/* 379 */     paramLoggerIf.setLevel(paramLevel);
/* 380 */     paramLoggerIf.setLevelOfAllHandler(paramLevel);
/*     */   }
/*     */   
/*     */   public static interface LoggerIf {
/*     */     void info(String param1String);
/*     */     
/*     */     void info(ASTLocusTag param1ASTLocusTag, String param1String);
/*     */     
/*     */     void warning(String param1String);
/*     */     
/*     */     void warning(ASTLocusTag param1ASTLocusTag, String param1String);
/*     */     
/*     */     void debug(String param1String);
/*     */     
/*     */     void debug(ASTLocusTag param1ASTLocusTag, String param1String);
/*     */     
/*     */     void log(Level param1Level, String param1String);
/*     */     
/*     */     void log(Level param1Level, String param1String, Object param1Object);
/*     */     
/*     */     void log(Level param1Level, String param1String, Object... param1VarArgs);
/*     */     
/*     */     void log(Level param1Level, ASTLocusTag param1ASTLocusTag, String param1String);
/*     */     
/*     */     void log(Level param1Level, ASTLocusTag param1ASTLocusTag, String param1String, Object param1Object);
/*     */     
/*     */     void log(Level param1Level, ASTLocusTag param1ASTLocusTag, String param1String, Object... param1VarArgs);
/*     */     
/*     */     void setLevel(Level param1Level) throws SecurityException;
/*     */     
/*     */     void setLevelOfAllHandler(Level param1Level) throws SecurityException;
/*     */     
/*     */     Level getLevel();
/*     */     
/*     */     boolean isLoggable(Level param1Level);
/*     */     
/*     */     String getName();
/*     */     
/*     */     Handler[] getHandlers();
/*     */     
/*     */     String getSourceClassName();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/Logging.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */