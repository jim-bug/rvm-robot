/*     */ package com.jogamp.gluegen.structgen;
/*     */ 
/*     */ import com.jogamp.common.util.PropertyAccess;
/*     */ import com.jogamp.gluegen.CCodeUnit;
/*     */ import com.jogamp.gluegen.GlueGen;
/*     */ import com.jogamp.gluegen.JavaCodeUnit;
/*     */ import com.jogamp.gluegen.JavaEmitter;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.annotation.processing.AbstractProcessor;
/*     */ import javax.annotation.processing.Filer;
/*     */ import javax.annotation.processing.Messager;
/*     */ import javax.annotation.processing.ProcessingEnvironment;
/*     */ import javax.annotation.processing.RoundEnvironment;
/*     */ import javax.annotation.processing.SupportedAnnotationTypes;
/*     */ import javax.annotation.processing.SupportedSourceVersion;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.lang.model.util.Elements;
/*     */ import javax.tools.Diagnostic;
/*     */ import javax.tools.FileObject;
/*     */ import javax.tools.StandardLocation;
/*     */ import jogamp.common.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SupportedAnnotationTypes({"com.jogamp.gluegen.structgen.CStruct", "com.jogamp.gluegen.structgen.CStructs"})
/*     */ @SupportedSourceVersion(SourceVersion.RELEASE_11)
/*     */ public class CStructAnnotationProcessor
/*     */   extends AbstractProcessor
/*     */ {
/*     */   private static final String DEFAULT = "_default_";
/*     */   
/*     */   static {
/*  96 */     Debug.initSingleton();
/*  97 */   } static final boolean DEBUG = PropertyAccess.isPropertyDefined("jogamp.gluegen.structgen.debug", true);
/*     */   
/*     */   private static final String STRUCTGENOUTPUT_OPTION = "structgen.output";
/*     */   
/*     */   private static final String STRUCTGENPRAGMA_ONCE = "structgen.enable.pragma.once";
/* 102 */   private static final String STRUCTGENOUTPUT = PropertyAccess.getProperty("jogamp.gluegen.structgen.output", true, "gensrc");
/* 103 */   private static final String STRUCTGENPRAGMAONCE = PropertyAccess.getProperty("jogamp.gluegen.structgen.enable.pragma.once", true, "true");
/*     */   
/*     */   private Filer filer;
/*     */   
/*     */   private Messager messager;
/*     */   private Elements eltUtils;
/*     */   private String outputPath;
/*     */   private boolean enablePragmaOnce;
/* 111 */   private static final Set<String> generatedStructs = new HashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(ProcessingEnvironment paramProcessingEnvironment) {
/* 116 */     super.init(paramProcessingEnvironment);
/*     */     
/* 118 */     this.filer = paramProcessingEnvironment.getFiler();
/* 119 */     this.messager = paramProcessingEnvironment.getMessager();
/* 120 */     this.eltUtils = paramProcessingEnvironment.getElementUtils();
/*     */     
/* 122 */     this.outputPath = paramProcessingEnvironment.getOptions().get("structgen.output");
/* 123 */     this.outputPath = (this.outputPath == null) ? STRUCTGENOUTPUT : this.outputPath;
/*     */     
/* 125 */     String str = paramProcessingEnvironment.getOptions().get(STRUCTGENPRAGMAONCE);
/* 126 */     this.enablePragmaOnce = Boolean.parseBoolean((str == null) ? STRUCTGENPRAGMAONCE : str);
/*     */   }
/*     */   
/*     */   private File locateSource(String paramString1, String paramString2) {
/*     */     try {
/* 131 */       if (DEBUG) {
/* 132 */         System.err.println("CStruct.locateSource.0: p " + paramString1 + ", r " + paramString2);
/*     */       }
/* 134 */       FileObject fileObject = this.filer.getResource(StandardLocation.SOURCE_PATH, paramString1, paramString2);
/* 135 */       if (DEBUG) {
/* 136 */         System.err.println("CStruct.locateSource.1: h " + fileObject.toUri());
/*     */       }
/* 138 */       File file = new File(fileObject.toUri().getPath());
/* 139 */       if (file.exists()) {
/* 140 */         return file;
/*     */       }
/* 142 */     } catch (IOException iOException) {
/* 143 */       if (DEBUG) {
/* 144 */         System.err.println("Caught " + iOException.getClass().getSimpleName() + ": " + iOException.getMessage());
/*     */       }
/*     */     } 
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean process(Set<? extends TypeElement> paramSet, RoundEnvironment paramRoundEnvironment) {
/* 152 */     String str = System.getProperty("user.dir");
/*     */     
/* 154 */     Set<? extends Element> set1 = paramRoundEnvironment.getElementsAnnotatedWith((Class)CStructs.class);
/* 155 */     for (Element element : set1) {
/* 156 */       String str1 = this.eltUtils.getPackageOf(element).toString();
/* 157 */       CStructs cStructs = element.<CStructs>getAnnotation(CStructs.class);
/* 158 */       if (null != cStructs) {
/* 159 */         CStruct[] arrayOfCStruct = cStructs.value();
/* 160 */         for (CStruct cStruct : arrayOfCStruct) {
/* 161 */           processCStruct(cStruct, element, str1, str);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 166 */     Set<? extends Element> set2 = paramRoundEnvironment.getElementsAnnotatedWith((Class)CStruct.class);
/* 167 */     for (Element element : set2) {
/* 168 */       String str1 = this.eltUtils.getPackageOf(element).toString();
/* 169 */       CStruct cStruct = element.<CStruct>getAnnotation(CStruct.class);
/* 170 */       if (null != cStruct) {
/* 171 */         processCStruct(cStruct, element, str1, str);
/*     */       }
/*     */     } 
/* 174 */     return true;
/*     */   }
/*     */   
/*     */   private void processCStruct(CStruct paramCStruct, Element paramElement, String paramString1, String paramString2) {
/*     */     try {
/* 179 */       String str1 = paramCStruct.header();
/* 180 */       Element element = paramElement.getEnclosingElement();
/* 181 */       boolean bool = (null == element) ? true : false;
/*     */       
/* 183 */       System.err.println("CStruct: " + paramCStruct + ", package " + paramString1 + ", header " + str1);
/* 184 */       if (DEBUG) {
/* 185 */         System.err.println("CStruct.0: user.dir: " + paramString2);
/* 186 */         System.err.println("CStruct.0: element: " + paramElement + ", .simpleName " + paramElement.getSimpleName());
/* 187 */         System.err.print("CStruct.0: isPackageOrType " + bool + ", enclElement: " + element);
/* 188 */         if (!bool)
/* 189 */         { if (!element.toString().equals("unnamed module")) {
/* 190 */             System.err.println(", .simpleName " + element.getSimpleName() + ", .package " + this.eltUtils.getPackageOf(element).toString());
/*     */           } else {
/* 192 */             System.err.println(", .simpleName " + element.getSimpleName() + ", .package <unnamed modules have no package>");
/*     */           }  }
/* 194 */         else { System.err.println(""); }
/*     */       
/*     */       } 
/* 197 */       if (bool && paramCStruct.name().equals("_default_")) {
/* 198 */         throw new IllegalArgumentException("CStruct annotation on package or type must have name specified: " + paramCStruct + " @ " + paramElement);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 203 */       File file2 = locateSource(paramString1, str1);
/* 204 */       if (null == file2) {
/* 205 */         file2 = locateSource("", str1);
/* 206 */         if (null == file2)
/*     */         {
/* 208 */           throw new RuntimeException("Could not locate header " + str1 + ", package " + paramString1);
/*     */         }
/*     */       } 
/* 211 */       File file1 = file2;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 216 */       String str4 = file1.getAbsolutePath();
/* 217 */       String str3 = str4.substring(0, str4.length() - file1.getName().length() - 1);
/* 218 */       String str2 = str3.substring(0, str3.length() - paramString1.length()) + "..";
/*     */       
/* 220 */       System.err.println("CStruct: " + file1 + ", abs: " + file1.isAbsolute() + ", headerParent " + str3 + ", rootOut " + str2 + ", enablePragmaOnce " + this.enablePragmaOnce);
/*     */       
/* 222 */       generateStructBinding(paramElement, paramCStruct, bool, str2, paramString1, file1, str3);
/* 223 */     } catch (IOException iOException) {
/* 224 */       throw new RuntimeException("IOException while processing!", iOException);
/*     */     } 
/*     */   }
/*     */   private void generateStructBinding(Element paramElement, CStruct paramCStruct, boolean paramBoolean, String paramString1, String paramString2, File paramFile, String paramString3) throws IOException {
/*     */     BufferedReader bufferedReader;
/* 229 */     String str1 = paramElement.asType().toString();
/* 230 */     boolean bool1 = !paramCStruct.name().equals("_default_") ? true : false;
/* 231 */     String str2 = bool1 ? paramCStruct.name() : str1;
/* 232 */     boolean bool2 = !paramCStruct.jname().equals("_default_") ? true : false;
/*     */     
/* 234 */     String str3 = bool2 ? paramCStruct.jname() : (!paramBoolean ? str1 : str2);
/* 235 */     System.err.println("CStruct: Generating struct accessor for struct: " + str2 + " -> " + str3 + " [struct.name " + paramCStruct.name() + ", struct.jname " + paramCStruct.jname() + ", declaredType " + str1 + "]");
/* 236 */     if (generatedStructs.contains(str3)) {
/* 237 */       this.messager.printMessage(Diagnostic.Kind.NOTE, "struct " + str2 + " already defined elsewhere, skipping.", paramElement);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 243 */     File file1 = new File(this.outputPath);
/* 244 */     boolean bool = file1.isAbsolute();
/*     */     
/* 246 */     String str4 = bool ? this.outputPath : (paramString1 + File.separator + this.outputPath);
/* 247 */     String str5 = str4 + File.separator + paramFile.getName() + ".cfg";
/* 248 */     File file2 = new File(str5);
/* 249 */     if (DEBUG) {
/* 250 */       System.err.println("CStruct: OutputDir: " + this.outputPath + ", is-abs " + bool);
/* 251 */       System.err.println("CStruct: OutputPath: " + str4);
/* 252 */       System.err.println("CStruct: ConfigFile: " + file2);
/*     */     } 
/*     */     
/* 255 */     FileWriter fileWriter = null;
/*     */     try {
/* 257 */       fileWriter = new FileWriter(file2);
/* 258 */       fileWriter.write("Package " + paramString2 + "\n");
/* 259 */       fileWriter.write("EmitStruct " + str2 + "\n");
/* 260 */       if (!bool2 && str3 != str2)
/*     */       {
/* 262 */         fileWriter.write("RenameJavaType " + paramCStruct.name() + " " + str1 + "\n");
/*     */       }
/*     */     } finally {
/* 265 */       if (null != fileWriter) {
/* 266 */         fileWriter.close();
/*     */       }
/*     */     } 
/* 269 */     ArrayList<String> arrayList1 = new ArrayList();
/* 270 */     arrayList1.add(str5);
/* 271 */     ArrayList<String> arrayList2 = new ArrayList();
/* 272 */     arrayList2.add(paramString3);
/* 273 */     arrayList2.add(str4);
/*     */     
/* 275 */     String str6 = paramFile.getPath();
/*     */     try {
/* 277 */       bufferedReader = new BufferedReader(new FileReader(str6));
/* 278 */     } catch (FileNotFoundException fileNotFoundException) {
/* 279 */       throw new RuntimeException("input file not found", fileNotFoundException);
/*     */     } 
/* 281 */     if (DEBUG) {
/* 282 */       GlueGen.setDebug(true);
/*     */     }
/* 284 */     (new GlueGen()).run(bufferedReader, str6, AnnotationProcessorJavaStructEmitter.class, arrayList2, arrayList1, str4, false, this.enablePragmaOnce, false);
/*     */ 
/*     */     
/* 287 */     file2.delete();
/* 288 */     generatedStructs.add(str3);
/*     */   }
/*     */   
/*     */   public static class AnnotationProcessorJavaStructEmitter
/*     */     extends JavaEmitter {
/*     */     private boolean filter(String param1String) {
/* 294 */       if (CStructAnnotationProcessor.generatedStructs.contains(param1String)) {
/* 295 */         System.err.println("skipping -> " + param1String);
/* 296 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 300 */       if (!param1String.endsWith("32") && 
/* 301 */         !param1String.endsWith("64")) {
/* 302 */         System.err.println("generating -> " + param1String);
/* 303 */         CStructAnnotationProcessor.generatedStructs.add(param1String);
/*     */       } 
/* 305 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected CCodeUnit openCUnit(String param1String1, String param1String2) throws IOException {
/* 310 */       if (!filter(param1String2)) {
/* 311 */         return null;
/*     */       }
/* 313 */       return super.openCUnit(param1String1, param1String2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected JavaCodeUnit openJavaUnit(String param1String1, String param1String2, String param1String3) throws IOException {
/* 325 */       if (!filter(param1String3)) {
/* 326 */         return null;
/*     */       }
/* 328 */       return super.openJavaUnit(param1String1, param1String2, param1String3);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/structgen/CStructAnnotationProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */