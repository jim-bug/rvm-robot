/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import antlr.RecognitionException;
/*     */ import antlr.TokenStream;
/*     */ import antlr.TokenStreamException;
/*     */ import antlr.TokenStreamRecognitionException;
/*     */ import com.jogamp.common.GlueGenVersion;
/*     */ import com.jogamp.gluegen.cgram.CToken;
/*     */ import com.jogamp.gluegen.cgram.Define;
/*     */ import com.jogamp.gluegen.cgram.GNUCTokenTypes;
/*     */ import com.jogamp.gluegen.cgram.GnuCLexer;
/*     */ import com.jogamp.gluegen.cgram.GnuCParser;
/*     */ import com.jogamp.gluegen.cgram.HeaderParser;
/*     */ import com.jogamp.gluegen.cgram.TNode;
/*     */ import com.jogamp.gluegen.cgram.types.AliasedSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.CompoundType;
/*     */ import com.jogamp.gluegen.cgram.types.EnumType;
/*     */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.PointerType;
/*     */ import com.jogamp.gluegen.cgram.types.Type;
/*     */ import com.jogamp.gluegen.cgram.types.TypeDictionary;
/*     */ import com.jogamp.gluegen.jcpp.JCPP;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlueGen
/*     */   implements GlueEmitterControls
/*     */ {
/*     */   static {
/*  62 */     Logging.init();
/*     */   }
/*     */   
/*  65 */   private final List<String> forcedStructNames = new ArrayList<>();
/*     */   
/*     */   private GenericCPP preprocessor;
/*     */   
/*     */   private List<ConstantDefinition> allConstants;
/*     */   
/*     */   private List<FunctionSymbol> allFunctions;
/*     */   
/*     */   private static boolean debug = false;
/*  74 */   private static Level logLevel = null;
/*     */   public static final String __GLUEGEN__ = "__GLUEGEN__";
/*  76 */   public static void setDebug(boolean paramBoolean) { debug = paramBoolean; }
/*  77 */   public static void setLogLevel(Level paramLevel) { logLevel = paramLevel; } public static boolean debug() {
/*  78 */     return debug;
/*     */   }
/*     */   
/*     */   public void forceStructEmission(String paramString) {
/*  82 */     this.forcedStructNames.add(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String findHeaderFile(String paramString) {
/*  87 */     return this.preprocessor.findFile(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public void runSymbolFilter(SymbolFilter paramSymbolFilter) {
/*  92 */     paramSymbolFilter.filterSymbols(this.allConstants, this.allFunctions);
/*  93 */     List<ConstantDefinition> list = paramSymbolFilter.getConstants();
/*  94 */     List<FunctionSymbol> list1 = paramSymbolFilter.getFunctions();
/*  95 */     if (list != null) {
/*  96 */       this.allConstants = list;
/*     */     }
/*  98 */     if (list1 != null) {
/*  99 */       this.allFunctions = list1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(Reader paramReader, String paramString1, Class<?> paramClass, List<String> paramList1, List<String> paramList2, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*     */     try {
/*     */       GlueEmitter glueEmitter;
/* 111 */       if (debug) {
/* 112 */         Logging.getLogger().setLevel(Level.ALL);
/* 113 */         System.err.println("GlueGen.run: filename: " + paramString1 + ", emitter: " + paramClass.getName() + ", outputRootDir " + paramString2 + ", copyCPPOutput2Stderr " + paramBoolean1 + ", enablePragmaOnce " + paramBoolean2 + ", preserveGeneratedCPP " + paramBoolean3);
/*     */         
/* 115 */         System.err.println("GlueGen.run: includePaths " + paramList1);
/* 116 */         System.err.println("GlueGen.run: cfgFiles " + paramList2);
/* 117 */       } else if (null != logLevel) {
/* 118 */         Logging.getLogger().setLevel(logLevel);
/*     */       } 
/*     */       
/* 121 */       if (paramClass == null) {
/* 122 */         glueEmitter = new JavaEmitter();
/*     */       } else {
/*     */         try {
/* 125 */           glueEmitter = (GlueEmitter)paramClass.newInstance();
/* 126 */         } catch (Exception exception) {
/* 127 */           throw new RuntimeException("Exception occurred while instantiating emitter class.", exception);
/*     */         } 
/*     */       } 
/*     */       
/* 131 */       for (String str1 : paramList2) {
/* 132 */         glueEmitter.readConfigurationFile(str1);
/*     */       }
/* 134 */       JavaConfiguration javaConfiguration = glueEmitter.getConfig();
/*     */       
/* 136 */       File file = File.createTempFile("CPPTemp", ".cpp");
/* 137 */       FileOutputStream fileOutputStream = new FileOutputStream(file);
/*     */ 
/*     */       
/* 140 */       this.preprocessor = (GenericCPP)new JCPP(paramList1, debug, paramBoolean1, paramBoolean2);
/* 141 */       String str = this.preprocessor.getClass().getSimpleName();
/* 142 */       if (debug || paramBoolean3) {
/* 143 */         System.err.println("CPP <" + str + "> output at (persistent): " + file.getAbsolutePath());
/*     */       } else {
/* 145 */         file.deleteOnExit();
/*     */       } 
/*     */       
/* 148 */       this.preprocessor.addDefine("__GLUEGEN__", "2");
/* 149 */       this.preprocessor.setOut(fileOutputStream);
/*     */       
/* 151 */       this.preprocessor.run(paramReader, paramString1);
/* 152 */       fileOutputStream.flush();
/* 153 */       fileOutputStream.close();
/* 154 */       if (debug) {
/* 155 */         System.err.println("CPP <" + str + "> done");
/*     */       }
/*     */       
/* 158 */       FileInputStream fileInputStream = new FileInputStream(file);
/* 159 */       DataInputStream dataInputStream = new DataInputStream(fileInputStream);
/*     */       
/* 161 */       GnuCLexer gnuCLexer = new GnuCLexer(dataInputStream);
/* 162 */       gnuCLexer.setTokenObjectClass(CToken.class.getName());
/* 163 */       gnuCLexer.initialize();
/*     */       
/* 165 */       GnuCParser gnuCParser = new GnuCParser((TokenStream)gnuCLexer);
/*     */ 
/*     */       
/* 168 */       gnuCParser.setASTNodeClass(TNode.class.getName());
/* 169 */       TNode.setTokenVocabulary(GNUCTokenTypes.class.getName());
/*     */ 
/*     */       
/*     */       try {
/* 173 */         gnuCParser.translationUnit();
/* 174 */       } catch (RecognitionException recognitionException) {
/* 175 */         throw new RuntimeException(String.format("Fatal error during translation (Localisation : %s:%s:%s)", new Object[] { recognitionException
/*     */                 
/* 177 */                 .getFilename(), Integer.valueOf(recognitionException.getLine()), Integer.valueOf(recognitionException.getColumn()) }), recognitionException);
/*     */       }
/* 179 */       catch (TokenStreamRecognitionException tokenStreamRecognitionException) {
/* 180 */         throw new RuntimeException(String.format("Fatal error during translation (Localisation : %s:%s:%s)", new Object[] { tokenStreamRecognitionException.recog
/*     */                 
/* 182 */                 .getFilename(), Integer.valueOf(tokenStreamRecognitionException.recog.getLine()), Integer.valueOf(tokenStreamRecognitionException.recog.getColumn()) }), tokenStreamRecognitionException);
/*     */       }
/* 184 */       catch (TokenStreamException tokenStreamException) {
/* 185 */         throw new RuntimeException("Fatal IO error", tokenStreamException);
/*     */       } 
/*     */       
/* 188 */       HeaderParser headerParser = new HeaderParser();
/* 189 */       headerParser.setDebug(debug);
/* 190 */       headerParser.setJavaConfiguration(javaConfiguration);
/* 191 */       TypeDictionary typeDictionary1 = new TypeDictionary();
/* 192 */       headerParser.setTypedefDictionary(typeDictionary1);
/* 193 */       TypeDictionary typeDictionary2 = new TypeDictionary();
/* 194 */       headerParser.setStructDictionary(typeDictionary2);
/*     */       
/* 196 */       headerParser.setASTNodeClass(TNode.class.getName());
/*     */       
/* 198 */       headerParser.translationUnit(gnuCParser.getAST());
/* 199 */       dataInputStream.close();
/* 200 */       fileInputStream.close();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 213 */       if (null != paramString2 && paramString2.trim().length() > 0 && 
/* 214 */         glueEmitter instanceof JavaEmitter) {
/*     */         
/* 216 */         JavaEmitter javaEmitter = (JavaEmitter)glueEmitter;
/* 217 */         if (null != javaEmitter.getConfig()) {
/* 218 */           javaEmitter.getConfig().setOutputRootDir(paramString2);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 225 */       this.allConstants = new ArrayList<>();
/* 226 */       for (EnumType enumType : headerParser.getEnums()) {
/* 227 */         String str1 = enumType.getName();
/* 228 */         if (str1.equals("<anonymous>")) {
/* 229 */           str1 = null;
/*     */         }
/*     */         
/* 232 */         for (byte b = 0; b < enumType.getNumEnumerates(); b++) {
/* 233 */           EnumType.Enumerator enumerator = enumType.getEnum(b);
/*     */ 
/*     */ 
/*     */           
/* 237 */           ConstantDefinition constantDefinition = new ConstantDefinition(enumerator.getName(), enumerator.getExpr(), enumerator.getNumber(), str1, enumType.getASTLocusTag());
/* 238 */           this.allConstants.add(constantDefinition);
/*     */         } 
/*     */       } 
/* 241 */       for (Define define1 : gnuCLexer.getDefines()) {
/* 242 */         Define define2 = define1;
/* 243 */         this.allConstants.add(new ConstantDefinition(define2.getName(), define2.getValue(), null, define2.getASTLocusTag()));
/*     */       } 
/* 245 */       this.allConstants.addAll(this.preprocessor.getConstantDefinitions());
/*     */       
/* 247 */       this.allFunctions = headerParser.getParsedFunctions();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 253 */       glueEmitter.beginEmission(this);
/*     */       
/* 255 */       if (debug()) {
/* 256 */         byte b = 0;
/* 257 */         System.err.println("Filtered Constants: " + this.allConstants.size());
/* 258 */         for (ConstantDefinition constantDefinition : this.allConstants) {
/* 259 */           if (debug()) {
/* 260 */             System.err.println("Filtered [" + b + "]: " + constantDefinition.getAliasedString());
/* 261 */             b++;
/*     */           } 
/*     */         } 
/* 264 */         b = 0;
/* 265 */         System.err.println("Filtered Functions: " + this.allFunctions.size());
/* 266 */         for (FunctionSymbol functionSymbol : this.allFunctions) {
/* 267 */           System.err.println("Filtered [" + b + "]: " + functionSymbol.getAliasedString());
/* 268 */           b++;
/*     */         } 
/*     */       } 
/*     */       
/* 272 */       if (!javaConfiguration.structsOnly()) {
/* 273 */         glueEmitter.beginDefines();
/* 274 */         HashSet<String> hashSet = new HashSet(100);
/*     */         
/* 276 */         StringBuilder stringBuilder = new StringBuilder();
/* 277 */         for (ConstantDefinition constantDefinition : this.allConstants) {
/* 278 */           if (!hashSet.contains(constantDefinition.getName())) {
/* 279 */             hashSet.add(constantDefinition.getName());
/* 280 */             Set<String> set = javaConfiguration.getAliasedDocNames((AliasedSymbol)constantDefinition);
/* 281 */             if (set != null && set.size() > 0) {
/* 282 */               byte b = 0;
/* 283 */               stringBuilder.append("Alias for: <code>");
/* 284 */               for (String str1 : set) {
/* 285 */                 if (0 < b) {
/* 286 */                   stringBuilder.append("</code>, <code>");
/*     */                 }
/* 288 */                 stringBuilder.append(str1);
/* 289 */                 b++;
/*     */               } 
/* 291 */               stringBuilder.append("</code>");
/*     */             } 
/* 293 */             if (stringBuilder.length() > 0) {
/* 294 */               stringBuilder.append("<br>\n");
/*     */             }
/* 296 */             if (constantDefinition.getEnumName() != null) {
/* 297 */               stringBuilder.append("Defined as part of enum type \"");
/* 298 */               stringBuilder.append(constantDefinition.getEnumName());
/* 299 */               stringBuilder.append("\"");
/*     */             } else {
/* 301 */               stringBuilder.append("Define \"");
/* 302 */               stringBuilder.append(constantDefinition.getName());
/* 303 */               stringBuilder.append("\"");
/*     */             } 
/* 305 */             stringBuilder.append(" with expression '<code>" + constantDefinition.getNativeExpr() + "</code>'");
/* 306 */             if (stringBuilder.length() > 0) {
/* 307 */               glueEmitter.emitDefine(constantDefinition, stringBuilder.toString());
/* 308 */               stringBuilder.setLength(0);
/*     */               continue;
/*     */             } 
/* 311 */             glueEmitter.emitDefine(constantDefinition, null);
/*     */           } 
/*     */         } 
/*     */         
/* 315 */         glueEmitter.endDefines();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 320 */       ReferencedStructs referencedStructs = new ReferencedStructs();
/* 321 */       for (FunctionSymbol functionSymbol : this.allFunctions)
/*     */       {
/*     */ 
/*     */         
/* 325 */         functionSymbol.getType().visit(referencedStructs);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 331 */       for (String str1 : this.forcedStructNames) {
/* 332 */         Type type = typeDictionary1.get(str1);
/* 333 */         if (type == null) {
/* 334 */           System.err.println("WARNING: during forced struct emission: struct \"" + str1 + "\" not found"); continue;
/* 335 */         }  if (!type.isCompound()) {
/* 336 */           System.err.println("WARNING: during forced struct emission: type \"" + str1 + "\" was not a struct"); continue;
/*     */         } 
/* 338 */         type.visit(referencedStructs);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 343 */       glueEmitter.beginStructLayout(); Iterator<CompoundType> iterator;
/* 344 */       for (iterator = referencedStructs.layouts(); iterator.hasNext(); ) {
/* 345 */         CompoundType compoundType = iterator.next();
/* 346 */         if (!compoundType.isLayouted()) {
/* 347 */           glueEmitter.layoutStruct(compoundType);
/*     */         }
/*     */       } 
/* 350 */       glueEmitter.endStructLayout();
/*     */ 
/*     */       
/* 353 */       glueEmitter.beginStructs(typeDictionary1, typeDictionary2, headerParser.getCanonMap());
/* 354 */       for (iterator = (Iterator)referencedStructs.results(); iterator.hasNext(); ) {
/* 355 */         Type type = (Type)iterator.next();
/* 356 */         if (type.isCompound()) {
/* 357 */           assert type.isTypedef() && type.getName() == null : "ReferencedStructs incorrectly recorded compound type " + type;
/* 358 */           glueEmitter.emitStruct(type.asCompound(), null); continue;
/* 359 */         }  if (type.isPointer()) {
/* 360 */           PointerType pointerType = type.asPointer();
/* 361 */           CompoundType compoundType = pointerType.getTargetType().asCompound();
/* 362 */           assert pointerType.isTypedef() && compoundType.getName() == null : "ReferencedStructs incorrectly recorded pointer type " + pointerType;
/* 363 */           glueEmitter.emitStruct(compoundType, (Type)pointerType);
/*     */         } 
/*     */       } 
/* 366 */       glueEmitter.endStructs();
/*     */       
/* 368 */       if (!javaConfiguration.structsOnly()) {
/*     */         
/* 370 */         glueEmitter.beginFunctions(typeDictionary1, typeDictionary2, headerParser.getCanonMap(), this.allFunctions);
/* 371 */         glueEmitter.emitFunctions(this.allFunctions);
/* 372 */         glueEmitter.endFunctions();
/*     */       } 
/*     */ 
/*     */       
/* 376 */       glueEmitter.endEmission();
/*     */     }
/* 378 */     catch (Exception exception) {
/* 379 */       throw new RuntimeException("Exception occurred while generating glue code.", exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void main(String... paramVarArgs) {
/*     */     BufferedReader bufferedReader;
/* 385 */     if (paramVarArgs.length == 0) {
/* 386 */       System.err.println(GlueGenVersion.getInstance());
/* 387 */       usage();
/*     */     } 
/*     */     
/* 390 */     InputStreamReader inputStreamReader = null;
/* 391 */     String str1 = null;
/* 392 */     String str2 = null;
/* 393 */     String str3 = null;
/* 394 */     ArrayList<String> arrayList1 = new ArrayList();
/* 395 */     boolean bool1 = false;
/* 396 */     boolean bool2 = true;
/* 397 */     boolean bool3 = false;
/*     */     
/* 399 */     ArrayList<String> arrayList2 = new ArrayList();
/* 400 */     for (byte b = 0; b < paramVarArgs.length; b++) {
/* 401 */       if (b < paramVarArgs.length - 1) {
/* 402 */         String str = paramVarArgs[b];
/* 403 */         if (str.startsWith("-I")) {
/* 404 */           String[] arrayOfString = str.substring(2).split(System.getProperty("path.separator"));
/* 405 */           arrayList2.addAll(Arrays.asList(arrayOfString));
/* 406 */         } else if (str.startsWith("-O")) {
/* 407 */           str3 = str.substring(2);
/* 408 */         } else if (str.startsWith("-E")) {
/* 409 */           str2 = str.substring(2);
/* 410 */         } else if (str.startsWith("-C")) {
/* 411 */           arrayList1.add(str.substring(2));
/* 412 */         } else if (str.equals("--logLevel")) {
/* 413 */           b++;
/* 414 */           logLevel = Level.parse(paramVarArgs[b]);
/* 415 */         } else if (str.equals("--debug")) {
/* 416 */           debug = true;
/* 417 */         } else if (str.equals("--dumpCPP")) {
/* 418 */           bool1 = true;
/* 419 */         } else if (str.equals("--disablePragmaOnce")) {
/* 420 */           bool2 = false;
/* 421 */         } else if (str.equals("--preserveGeneratedCPP")) {
/* 422 */           bool3 = true;
/*     */         } else {
/* 424 */           usage();
/*     */         } 
/*     */       } else {
/* 427 */         String str = paramVarArgs[b];
/* 428 */         if (str.equals("-")) {
/* 429 */           inputStreamReader = new InputStreamReader(System.in);
/* 430 */           str1 = "standard input";
/*     */         } else {
/* 432 */           if (str.startsWith("-")) {
/* 433 */             usage();
/*     */           }
/* 435 */           str1 = str;
/*     */           try {
/* 437 */             bufferedReader = new BufferedReader(new FileReader(str1));
/* 438 */           } catch (FileNotFoundException fileNotFoundException) {
/* 439 */             throw new RuntimeException("input file not found", fileNotFoundException);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 446 */       Class<?> clazz = (str2 == null) ? null : Class.forName(str2);
/* 447 */       (new GlueGen()).run(bufferedReader, str1, clazz, arrayList2, arrayList1, str3, bool1, bool2, bool3);
/* 448 */     } catch (ClassNotFoundException classNotFoundException) {
/* 449 */       throw new RuntimeException("specified emitter class was not in the classpath", classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void usage() {
/* 458 */     System.out.println("Usage: java GlueGen [-I...] [-Eemitter_class_name] [-Ccfg_file_name...] <filename | ->");
/* 459 */     System.out.println();
/* 460 */     System.out.println("Runs C header parser on input file or standard input, first");
/* 461 */     System.out.println("passing input through minimal pseudo-C-preprocessor. Use -I");
/* 462 */     System.out.println("command-line arguments to specify the search path for #includes.");
/* 463 */     System.out.println("Emitter class name can be specified with -E option: i.e.,");
/* 464 */     System.out.println("-Ecom.jogamp.gluegen.JavaEmitter (the default). Use");
/* 465 */     System.out.println("-Ecom.jogamp.gluegen.DebugEmitter to print recognized entities");
/* 466 */     System.out.println("(#define directives to constant numbers, typedefs, and function");
/* 467 */     System.out.println("declarations) to standard output. Emitter-specific configuration");
/* 468 */     System.out.println("file or files can be specified with -C option; e.g,");
/* 469 */     System.out.println("-Cjava-emitter.cfg.");
/* 470 */     System.out.println("  --debug enables debug mode");
/* 471 */     System.out.println("  --dumpCPP directs CPP to dump all output to stderr as well");
/* 472 */     System.out.println("  --disablePragmaOnce disable handling of #pragma once directive during parsing (enabled by default)");
/* 473 */     System.out.println("  --preserveGeneratedCPP preserve generated CPP file during generation (File it's already preserved by debug mode)");
/* 474 */     System.exit(1);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/GlueGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */