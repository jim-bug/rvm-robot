/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import com.jogamp.gluegen.cgram.types.Type;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavaCallbackEmitter
/*     */ {
/*     */   final JavaConfiguration cfg;
/*     */   final MethodBinding binding;
/*     */   final String setFuncSignature;
/*     */   final JavaConfiguration.JavaCallbackInfo info;
/*     */   final String capIfaceName;
/*     */   final String lowIfaceName;
/*     */   final String lockInstanceName;
/*     */   final String dataMapInstanceName;
/*     */   final String dataInstanceName;
/*     */   final String DataClassName;
/*     */   final String fqUsrParamClassName;
/*     */   final JavaType cbFuncJavaReturnType;
/*     */   final String jcbNextIDVarName;
/*     */   final boolean userParamDefined;
/*     */   final String setFuncCBArgName;
/*     */   final Type setFuncUserParamCType;
/*     */   final JavaType setFuncUserParamJType;
/*     */   final String setFuncUserParamTypeName;
/*     */   final String setFuncUserParamArgName;
/*     */   final boolean userParamIsKey;
/*     */   final boolean userParamIsCompound;
/*     */   final boolean userParamIsMappedToID;
/*     */   final String userParamIDMapInstanceName;
/*     */   final String userParamClassName;
/*     */   final boolean customKeyClass;
/*     */   final String KeyClassName;
/*     */   final boolean useDataMap;
/*     */   
/*     */   public JavaCallbackEmitter(JavaConfiguration paramJavaConfiguration, MethodBinding paramMethodBinding, JavaConfiguration.JavaCallbackInfo paramJavaCallbackInfo, String paramString) {
/*  68 */     this.cfg = paramJavaConfiguration;
/*  69 */     this.binding = paramMethodBinding;
/*  70 */     this.setFuncSignature = paramString;
/*  71 */     this.info = paramJavaCallbackInfo;
/*     */     
/*  73 */     this.capIfaceName = CodeGenUtils.capitalizeString(paramMethodBinding.getInterfaceName());
/*  74 */     this.lowIfaceName = CodeGenUtils.decapitalizeString(paramMethodBinding.getInterfaceName());
/*  75 */     this.lockInstanceName = this.lowIfaceName + "Lock";
/*  76 */     this.dataMapInstanceName = this.lowIfaceName + "DataMap";
/*  77 */     this.dataInstanceName = this.lowIfaceName + "Data";
/*  78 */     this.DataClassName = this.capIfaceName + "Data";
/*  79 */     this.fqUsrParamClassName = paramJavaConfiguration.packageName() + "." + paramJavaConfiguration.className() + "." + this.DataClassName;
/*  80 */     this.cbFuncJavaReturnType = paramJavaCallbackInfo.cbFuncBinding.getJavaReturnType();
/*  81 */     this.jcbNextIDVarName = "NEXT_" + this.capIfaceName + "_ID";
/*     */     
/*  83 */     this.setFuncCBArgName = this.binding.getArgumentName(paramJavaCallbackInfo.setFuncCBParamIdx);
/*     */     
/*  85 */     this.userParamDefined = (paramJavaCallbackInfo.setFuncUserParamIdx >= 0);
/*  86 */     if (!this.userParamDefined) {
/*  87 */       this.setFuncUserParamCType = null;
/*  88 */       this.setFuncUserParamJType = null;
/*  89 */       this.setFuncUserParamTypeName = null;
/*  90 */       this.setFuncUserParamArgName = null;
/*     */       
/*  92 */       this.userParamIsKey = false;
/*     */     } else {
/*  94 */       this.setFuncUserParamCType = paramMethodBinding.getCArgumentType(paramJavaCallbackInfo.setFuncUserParamIdx);
/*  95 */       this.setFuncUserParamJType = paramMethodBinding.getJavaArgumentType(paramJavaCallbackInfo.setFuncUserParamIdx);
/*  96 */       this.setFuncUserParamTypeName = this.setFuncUserParamJType.getName();
/*  97 */       this.setFuncUserParamArgName = this.binding.getArgumentName(paramJavaCallbackInfo.setFuncUserParamIdx);
/*     */       
/*  99 */       this.userParamIsKey = this.info.setFuncKeyIndices.contains(Integer.valueOf(this.info.setFuncUserParamIdx));
/*     */     } 
/* 101 */     if (null != this.setFuncUserParamJType && !this.setFuncUserParamJType.isLong()) {
/* 102 */       if (this.setFuncUserParamJType.isCompoundTypeWrapper()) {
/* 103 */         this.userParamIsCompound = true;
/* 104 */         this.userParamIsMappedToID = false;
/* 105 */         this.userParamIDMapInstanceName = null;
/*     */       } else {
/* 107 */         this.userParamIsCompound = false;
/* 108 */         this.userParamIsMappedToID = true;
/* 109 */         this.userParamIDMapInstanceName = this.userParamIsKey ? (this.lowIfaceName + "UserObjIDMap") : null;
/*     */       } 
/*     */     } else {
/* 112 */       this.userParamIsCompound = false;
/* 113 */       this.userParamIsMappedToID = false;
/* 114 */       this.userParamIDMapInstanceName = null;
/*     */     } 
/*     */     
/* 117 */     if (this.userParamDefined) {
/* 118 */       if (this.userParamIsCompound) {
/* 119 */         this.userParamClassName = this.setFuncUserParamTypeName;
/* 120 */       } else if (null != paramJavaCallbackInfo.userParamClassName) {
/* 121 */         this.userParamClassName = paramJavaCallbackInfo.userParamClassName;
/*     */       } else {
/* 123 */         this.userParamClassName = "Object";
/*     */       } 
/*     */     } else {
/* 126 */       this.userParamClassName = null;
/*     */     } 
/*     */     
/* 129 */     if (null != paramJavaCallbackInfo.customKeyClassName) {
/* 130 */       this.customKeyClass = true;
/* 131 */       this.KeyClassName = paramJavaCallbackInfo.customKeyClassName;
/* 132 */       this.useDataMap = true;
/*     */     } else {
/* 134 */       this.customKeyClass = false;
/* 135 */       this.KeyClassName = this.capIfaceName + "Key";
/* 136 */       this.useDataMap = (paramJavaCallbackInfo.setFuncKeyIndices.size() > 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void emitJavaAdditionalCode(CodeUnit paramCodeUnit, boolean paramBoolean) {
/* 141 */     if (paramBoolean) {
/* 142 */       if (this.useDataMap) {
/* 143 */         if (!this.customKeyClass && !this.info.keyClassEmitted) {
/* 144 */           emitJavaKeyClass(paramCodeUnit);
/* 145 */           paramCodeUnit.emitln();
/* 146 */           this.info.keyClassEmitted = true;
/*     */         } 
/* 148 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns ", "set of ", "", "for ");
/* 149 */         paramCodeUnit.emitln("  public Set<" + this.KeyClassName + "> get" + this.capIfaceName + "Keys();");
/* 150 */         paramCodeUnit.emitln();
/* 151 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns ", "whether callback ", "if callback ", "is mapped for ");
/* 152 */         paramCodeUnit.emitln("  public boolean is" + this.capIfaceName + "Mapped(" + this.KeyClassName + " key);");
/* 153 */         paramCodeUnit.emitln();
/* 154 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns " + this.info.cbFuncTypeName + " callback ", "mapped to ", "", "for ");
/* 155 */         paramCodeUnit.emitln("  public " + this.info.cbFuncTypeName + " get" + this.capIfaceName + "(" + this.KeyClassName + " key);");
/* 156 */         paramCodeUnit.emitln();
/* 157 */         if (this.userParamDefined) {
/* 158 */           emitJavaBriefAPIDoc(paramCodeUnit, "Returns user-param ", "mapped to ", "", "for ");
/* 159 */           paramCodeUnit.emitln("  public " + this.userParamClassName + " get" + this.capIfaceName + "UserParam(" + this.KeyClassName + " key);");
/* 160 */           paramCodeUnit.emitln();
/*     */         } 
/* 162 */         emitJavaBriefAPIDoc(paramCodeUnit, "Releases all callback data ", "mapped via ", "", "skipping toolkit API. Favor passing `null` callback ref to ");
/* 163 */         paramCodeUnit.emitln("  public int releaseAll" + this.capIfaceName + "();");
/* 164 */         paramCodeUnit.emitln();
/* 165 */         emitJavaBriefAPIDoc(paramCodeUnit, "Releases callback data ", "mapped to ", "", "skipping toolkit API. Favor passing `null` callback ref to ");
/* 166 */         paramCodeUnit.emitln("  public void release" + this.capIfaceName + "(" + this.KeyClassName + " key);");
/* 167 */         paramCodeUnit.emitln();
/*     */       } else {
/* 169 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns ", "whether callback ", "if callback ", "is mapped for ");
/* 170 */         paramCodeUnit.emitln("  public boolean is" + this.capIfaceName + "Mapped();");
/* 171 */         paramCodeUnit.emitln();
/* 172 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns " + this.info.cbFuncTypeName + " callback ", "mapped to ", "", "for ");
/* 173 */         paramCodeUnit.emitln("  public " + this.info.cbFuncTypeName + " get" + this.capIfaceName + "();");
/* 174 */         paramCodeUnit.emitln();
/* 175 */         if (this.userParamDefined) {
/* 176 */           emitJavaBriefAPIDoc(paramCodeUnit, "Returns user-param ", "mapped to ", "", "for ");
/* 177 */           paramCodeUnit.emitln("  public " + this.userParamClassName + " get" + this.capIfaceName + "UserParam();");
/* 178 */           paramCodeUnit.emitln();
/*     */         } 
/* 180 */         emitJavaBriefAPIDoc(paramCodeUnit, "Releases callback data ", "", "", "skipping toolkit API. Favor passing `null` callback ref to ");
/* 181 */         paramCodeUnit.emitln("  public void release" + this.capIfaceName + "();");
/* 182 */         paramCodeUnit.emitln();
/*     */       } 
/*     */     } else {
/* 185 */       if (this.useDataMap) {
/* 186 */         if (!this.customKeyClass && !this.info.keyClassEmitted) {
/* 187 */           emitJavaKeyClass(paramCodeUnit);
/* 188 */           paramCodeUnit.emitln();
/* 189 */           this.info.keyClassEmitted = true;
/*     */         } 
/* 191 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns ", "set of ", "", "for ");
/* 192 */         paramCodeUnit.emitln("  public final Set<" + this.KeyClassName + "> get" + this.capIfaceName + "Keys() {");
/* 193 */         paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 194 */         paramCodeUnit.emitln("      return " + this.dataMapInstanceName + ".keySet();");
/* 195 */         paramCodeUnit.emitln("    }");
/* 196 */         paramCodeUnit.emitln("  }");
/* 197 */         paramCodeUnit.emitln();
/* 198 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns ", "whether callback ", "if callback ", "is mapped for ");
/* 199 */         paramCodeUnit.emitln("  public final boolean is" + this.capIfaceName + "Mapped(" + this.KeyClassName + " key) {");
/* 200 */         paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 201 */         paramCodeUnit.emitln("      return null != " + this.dataMapInstanceName + ".get(key);");
/* 202 */         paramCodeUnit.emitln("    }");
/* 203 */         paramCodeUnit.emitln("  }");
/* 204 */         paramCodeUnit.emitln();
/*     */         
/* 206 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns " + this.info.cbFuncTypeName + " callback ", "mapped to ", "", "for ");
/* 207 */         paramCodeUnit.emitln("  public final " + this.info.cbFuncTypeName + " get" + this.capIfaceName + "(" + this.KeyClassName + " key) {");
/* 208 */         paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 209 */         paramCodeUnit.emitln("      final " + this.DataClassName + " value = " + this.dataMapInstanceName + ".get(key);");
/* 210 */         paramCodeUnit.emitln("      return null != value ? value.func : null;");
/* 211 */         paramCodeUnit.emitln("    }");
/* 212 */         paramCodeUnit.emitln("  }");
/* 213 */         paramCodeUnit.emitln();
/*     */         
/* 215 */         if (this.userParamDefined) {
/* 216 */           emitJavaBriefAPIDoc(paramCodeUnit, "Returns user-param ", "mapped to ", "", "for ");
/* 217 */           paramCodeUnit.emitln("  public final " + this.userParamClassName + " get" + this.capIfaceName + "UserParam(" + this.KeyClassName + " key) {");
/* 218 */           paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 219 */           paramCodeUnit.emitln("      final " + this.DataClassName + " value = " + this.dataMapInstanceName + ".get(key);");
/* 220 */           paramCodeUnit.emitln("      return null != value ? value.param : null;");
/* 221 */           paramCodeUnit.emitln("    }");
/* 222 */           paramCodeUnit.emitln("  }");
/* 223 */           paramCodeUnit.emitln();
/*     */         } 
/* 225 */         emitJavaBriefAPIDoc(paramCodeUnit, "Releases all callback data ", "mapped via ", "", "skipping toolkit API. Favor passing `null` callback ref to ");
/* 226 */         paramCodeUnit.emitln("  public final int releaseAll" + this.capIfaceName + "() {");
/* 227 */         paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 228 */         paramCodeUnit.emitln("      final Set<" + this.KeyClassName + "> keySet = " + this.dataMapInstanceName + ".keySet();");
/* 229 */         paramCodeUnit.emitln("      final " + this.KeyClassName + "[] keys = keySet.toArray(new " + this.KeyClassName + "[keySet.size()]);");
/* 230 */         paramCodeUnit.emitln("      for(int i=0; i<keys.length; ++i) {");
/* 231 */         paramCodeUnit.emitln("        final " + this.KeyClassName + " key = keys[i];");
/* 232 */         paramCodeUnit.emitln("          release" + this.capIfaceName + "(key);");
/* 233 */         paramCodeUnit.emitln("      }");
/* 234 */         paramCodeUnit.emitln("      return keys.length;");
/* 235 */         paramCodeUnit.emitln("    }");
/* 236 */         paramCodeUnit.emitln("  }");
/* 237 */         paramCodeUnit.emitln();
/* 238 */         emitJavaBriefAPIDoc(paramCodeUnit, "Releases callback data ", "mapped to ", "", "skipping toolkit API. Favor passing `null` callback ref to ");
/* 239 */         paramCodeUnit.emitln("  public final void release" + this.capIfaceName + "(" + this.KeyClassName + " key) {");
/* 240 */         paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 241 */         if (this.userParamIsMappedToID && this.userParamIsKey) {
/* 242 */           paramCodeUnit.emitln("      " + this.DataClassName + " value = " + this.dataMapInstanceName + ".remove(key);");
/* 243 */           paramCodeUnit.emitln("      if( null != value ) {");
/* 244 */           paramCodeUnit.emitln("        " + this.userParamIDMapInstanceName + ".remove(value.paramID);");
/* 245 */           paramCodeUnit.emitln("      }");
/*     */         } else {
/* 247 */           paramCodeUnit.emitln("      /* " + this.DataClassName + " value = */ " + this.dataMapInstanceName + ".remove(key);");
/*     */         } 
/* 249 */         paramCodeUnit.emitln("    }");
/* 250 */         paramCodeUnit.emitln("  }");
/* 251 */         paramCodeUnit.emitln();
/*     */       } else {
/* 253 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns ", "whether callback ", "if callback ", "is mapped for ");
/* 254 */         paramCodeUnit.emitln("  public final boolean is" + this.capIfaceName + "Mapped() {");
/* 255 */         paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 256 */         paramCodeUnit.emitln("      return null != " + this.dataInstanceName + ";");
/* 257 */         paramCodeUnit.emitln("    }");
/* 258 */         paramCodeUnit.emitln("  }");
/* 259 */         paramCodeUnit.emitln();
/*     */         
/* 261 */         emitJavaBriefAPIDoc(paramCodeUnit, "Returns " + this.info.cbFuncTypeName + " callback ", "mapped to ", "", "for ");
/* 262 */         paramCodeUnit.emitln("  public final " + this.info.cbFuncTypeName + " get" + this.capIfaceName + "() {");
/* 263 */         paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 264 */         paramCodeUnit.emitln("      final " + this.DataClassName + " value = " + this.dataInstanceName + ";");
/* 265 */         paramCodeUnit.emitln("      return null != value ? value.func : null;");
/* 266 */         paramCodeUnit.emitln("    }");
/* 267 */         paramCodeUnit.emitln("  }");
/* 268 */         paramCodeUnit.emitln();
/*     */         
/* 270 */         if (this.userParamDefined) {
/* 271 */           emitJavaBriefAPIDoc(paramCodeUnit, "Returns user-param ", "mapped to ", "", "for ");
/* 272 */           paramCodeUnit.emitln("  public final " + this.userParamClassName + " get" + this.capIfaceName + "UserParam() {");
/* 273 */           paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 274 */           paramCodeUnit.emitln("      final " + this.DataClassName + " value = " + this.dataInstanceName + ";");
/* 275 */           paramCodeUnit.emitln("      return null != value ? value.param : null;");
/* 276 */           paramCodeUnit.emitln("    }");
/* 277 */           paramCodeUnit.emitln("  }");
/* 278 */           paramCodeUnit.emitln();
/*     */         } 
/*     */         
/* 281 */         emitJavaBriefAPIDoc(paramCodeUnit, "Releases callback data ", "", "", "skipping toolkit API. Favor passing `null` callback ref to ");
/* 282 */         paramCodeUnit.emitln("  public final void release" + this.capIfaceName + "() {");
/* 283 */         paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 284 */         paramCodeUnit.emitln("      // final " + this.DataClassName + " value = " + this.dataInstanceName + ";");
/* 285 */         if (this.userParamIsMappedToID && this.userParamIsKey) {
/* 286 */           paramCodeUnit.emitln("      " + this.userParamIDMapInstanceName + ".remove(dataInstanceName.paramID);");
/*     */         }
/* 288 */         paramCodeUnit.emitln("      " + this.dataInstanceName + " = null;");
/* 289 */         paramCodeUnit.emitln("    }");
/* 290 */         paramCodeUnit.emitln("  }");
/* 291 */         paramCodeUnit.emitln();
/*     */       } 
/* 293 */       paramCodeUnit.emitln("  private final void add" + this.capIfaceName + "(" + this.binding.getJavaSelectParameter(new StringBuilder(), this.info.setFuncKeyIndices, true).toString() + this.DataClassName + " value) {");
/* 294 */       if (this.useDataMap) {
/* 295 */         paramCodeUnit.emitln("    final " + this.KeyClassName + " key = new " + this.KeyClassName + "(" + this.binding.getJavaCallSelectArguments(new StringBuilder(), this.info.setFuncKeyIndices, false).toString() + ");");
/* 296 */         if (this.userParamIsMappedToID && this.userParamIsKey) {
/* 297 */           paramCodeUnit.emitln("    final " + this.DataClassName + " old = " + this.dataMapInstanceName + ".put(key, value);");
/*     */         } else {
/* 299 */           paramCodeUnit.emitln("    /* final " + this.DataClassName + " old = */ " + this.dataMapInstanceName + ".put(key, value);");
/*     */         } 
/*     */       } else {
/* 302 */         if (this.userParamIsMappedToID && this.userParamIsKey) {
/* 303 */           paramCodeUnit.emitln("    final " + this.DataClassName + " old = " + this.dataInstanceName + ";");
/*     */         } else {
/* 305 */           paramCodeUnit.emitln("    // final " + this.DataClassName + " old = " + this.dataInstanceName + ";");
/*     */         } 
/* 307 */         paramCodeUnit.emitln("    " + this.dataInstanceName + " = value;");
/*     */       } 
/* 309 */       if (this.userParamIsMappedToID && this.userParamIsKey) {
/* 310 */         paramCodeUnit.emitln("    if( null != old ) {");
/* 311 */         paramCodeUnit.emitln("      " + this.userParamIDMapInstanceName + ".remove(old.paramID);");
/* 312 */         paramCodeUnit.emitln("    }");
/* 313 */         paramCodeUnit.emitln("    if( null != value.param ) {");
/* 314 */         paramCodeUnit.emitln("      " + this.userParamIDMapInstanceName + ".put(value.paramID, value.param);");
/* 315 */         paramCodeUnit.emitln("    }");
/*     */       } 
/* 317 */       paramCodeUnit.emitln("  }");
/* 318 */       paramCodeUnit.emitln();
/* 319 */       if (!this.cfg.emittedJavaCallbackUserParamClasses.contains(this.fqUsrParamClassName)) {
/* 320 */         emitJavaDataClass(paramCodeUnit);
/* 321 */         this.cfg.emittedJavaCallbackUserParamClasses.add(this.fqUsrParamClassName);
/*     */       } 
/* 323 */       if (this.useDataMap) {
/* 324 */         paramCodeUnit.emitln("  private static final Map<" + this.KeyClassName + ", " + this.DataClassName + "> " + this.dataMapInstanceName + " = new HashMap<" + this.KeyClassName + ", " + this.DataClassName + ">();");
/*     */       } else {
/* 326 */         paramCodeUnit.emitln("  private static " + this.DataClassName + " " + this.dataInstanceName + " = null;");
/*     */       } 
/* 328 */       if (this.userParamIsMappedToID && this.userParamIsKey) {
/* 329 */         paramCodeUnit.emitln("  private static final LongObjectHashMap " + this.userParamIDMapInstanceName + " = new LongObjectHashMap();");
/*     */       }
/* 331 */       paramCodeUnit.emitln("  private static long " + this.jcbNextIDVarName + " = 1;");
/* 332 */       paramCodeUnit.emitln("  private static final Object " + this.lockInstanceName + " = new Object();");
/* 333 */       paramCodeUnit.emitln();
/* 334 */       emitJavaStaticCallback(paramCodeUnit);
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void emitJavaBriefAPIDoc(CodeUnit paramCodeUnit, String paramString1, String paramString2, String paramString3, String paramString4) {
/* 339 */     paramCodeUnit.emit("  /** " + paramString1);
/* 340 */     if (this.info.setFuncKeyIndices.size() > 0) {
/* 341 */       paramCodeUnit.emit(paramString2);
/* 342 */       paramCodeUnit.emit("Key { " + this.binding.getJavaSelectParameter(new StringBuilder(), this.info.setFuncKeyIndices, false).toString() + " } ");
/*     */     } else {
/* 344 */       paramCodeUnit.emit(paramString3);
/*     */     } 
/* 346 */     paramCodeUnit.emit(paramString4);
/* 347 */     paramCodeUnit.emitln("<br> <code>" + this.setFuncSignature + "</code> */");
/*     */   }
/*     */   
/*     */   private final void emitJavaKeyClass(CodeUnit paramCodeUnit) {
/* 351 */     if (this.cfg.shouldIgnoreInInterface(this.KeyClassName))
/*     */       return; 
/* 353 */     emitJavaBriefAPIDoc(paramCodeUnit, "", "", "", "for ");
/* 354 */     paramCodeUnit.emitln("  public static class " + this.KeyClassName + " {");
/* 355 */     this.binding.forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid() && this.info.setFuncKeyIndices.contains(Integer.valueOf(paramInt1))) {
/*     */             paramCodeUnit.emitln("    public final " + paramJavaType + " " + paramString + ";");
/*     */             
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 363 */     paramCodeUnit.emitln("    public " + this.KeyClassName + "(" + this.binding.getJavaSelectParameter(new StringBuilder(), this.info.setFuncKeyIndices, false).toString() + ") {");
/* 364 */     this.binding.forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid() && this.info.setFuncKeyIndices.contains(Integer.valueOf(paramInt1))) {
/*     */             paramCodeUnit.emitln("      this." + paramString + " = " + paramString + ";");
/*     */             
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 372 */     paramCodeUnit.emitln("    }");
/* 373 */     paramCodeUnit.emitln("    @Override");
/* 374 */     paramCodeUnit.emitln("    public boolean equals(final Object o) {");
/* 375 */     paramCodeUnit.emitln("      if( this == o ) {");
/* 376 */     paramCodeUnit.emitln("        return true;");
/* 377 */     paramCodeUnit.emitln("      }");
/* 378 */     paramCodeUnit.emitln("      if( !(o instanceof " + this.KeyClassName + ") ) {");
/* 379 */     paramCodeUnit.emitln("        return false;");
/* 380 */     paramCodeUnit.emitln("      }");
/*     */     
/* 382 */     int i = this.binding.forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid() && this.info.setFuncKeyIndices.contains(Integer.valueOf(paramInt1))) {
/*     */             if (0 == paramInt2) {
/*     */               paramCodeUnit.emitln("      final " + this.KeyClassName + " o2 = (" + this.KeyClassName + ")o;");
/*     */               
/*     */               paramCodeUnit.emit("      return ");
/*     */             } else {
/*     */               paramCodeUnit.emitln(" &&");
/*     */               paramCodeUnit.emit("             ");
/*     */             } 
/*     */             if (paramJavaType.isCompoundTypeWrapper()) {
/*     */               paramCodeUnit.emit(paramString + ".getDirectBufferAddress() == o2." + paramString + ".getDirectBufferAddress()");
/*     */             } else if (paramJavaType.isPrimitive() || paramInt1 == this.info.setFuncUserParamIdx) {
/*     */               paramCodeUnit.emit(paramString + " == o2." + paramString);
/*     */             } else {
/*     */               paramCodeUnit.emit(paramString + ".equals( o2." + paramString + " )");
/*     */             } 
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 403 */     if (0 == i) {
/* 404 */       paramCodeUnit.emit("      return true");
/*     */     }
/* 406 */     paramCodeUnit.emitln(";");
/*     */     
/* 408 */     paramCodeUnit.emitln("    }");
/* 409 */     paramCodeUnit.emitln("    @Override");
/* 410 */     paramCodeUnit.emitln("    public int hashCode() {");
/*     */     
/* 412 */     i = this.binding.forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid() && this.info.setFuncKeyIndices.contains(Integer.valueOf(paramInt1))) {
/*     */             if (0 == paramInt2) {
/*     */               paramCodeUnit.emitln("      // 31 * x == (x << 5) - x");
/*     */               
/*     */               paramCodeUnit.emit("      int hash = ");
/*     */             } else {
/*     */               paramCodeUnit.emit("      hash = ((hash << 5) - hash) + ");
/*     */             } 
/*     */             
/*     */             if (paramJavaType.isPrimitive()) {
/*     */               if (paramJavaType.isLong()) {
/*     */                 paramCodeUnit.emitln("HashUtil.getAddrHash32_EqualDist( " + paramString + " );");
/*     */               } else {
/*     */                 paramCodeUnit.emitln(paramString + ";");
/*     */               } 
/*     */             } else if (paramJavaType.isCompoundTypeWrapper()) {
/*     */               paramCodeUnit.emitln("HashUtil.getAddrHash32_EqualDist( " + paramString + ".getDirectBufferAddress() );");
/*     */             } else if (paramInt1 == this.info.setFuncUserParamIdx) {
/*     */               paramCodeUnit.emitln("System.identityHashCode( " + paramString + " );");
/*     */             } else {
/*     */               paramCodeUnit.emitln(paramString + ".hashCode();");
/*     */             } 
/*     */             
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 440 */     if (0 == i) {
/* 441 */       paramCodeUnit.emitln("      return 0;");
/*     */     } else {
/* 443 */       paramCodeUnit.emitln("      return hash;");
/*     */     } 
/*     */     
/* 446 */     paramCodeUnit.emitln("    }");
/* 447 */     paramCodeUnit.emitln("  }");
/*     */   }
/*     */   
/*     */   private final void emitJavaDataClass(CodeUnit paramCodeUnit) {
/* 451 */     paramCodeUnit.emitln("  private static class " + this.DataClassName + " {");
/* 452 */     paramCodeUnit.emitln("    final " + this.info.cbFuncTypeName + " func;");
/* 453 */     if (this.userParamDefined) {
/* 454 */       paramCodeUnit.emitln("    // userParamArgCType " + this.setFuncUserParamCType);
/* 455 */       paramCodeUnit.emitln("    // userParamArgJType " + this.setFuncUserParamJType);
/* 456 */       paramCodeUnit.emitln("    final " + this.setFuncUserParamTypeName + " param;");
/* 457 */       if (this.userParamIsMappedToID) {
/* 458 */         paramCodeUnit.emitln("    final long paramID;");
/*     */       }
/*     */     } else {
/* 461 */       paramCodeUnit.emitln("    // No user param defined.");
/*     */     } 
/* 463 */     paramCodeUnit.emit("    " + this.DataClassName + "(final " + this.info.cbFuncTypeName + " func");
/* 464 */     if (this.userParamDefined) {
/* 465 */       if (this.userParamIsMappedToID) {
/* 466 */         paramCodeUnit.emit(", final long paramID");
/*     */       }
/* 468 */       paramCodeUnit.emit(", final " + this.setFuncUserParamTypeName + " param");
/*     */     } 
/* 470 */     paramCodeUnit.emitln(") {");
/* 471 */     paramCodeUnit.emitln("      this.func = func;");
/* 472 */     if (this.userParamDefined) {
/* 473 */       if (this.userParamIsMappedToID) {
/* 474 */         paramCodeUnit.emitln("      this.paramID = paramID;");
/*     */       }
/* 476 */       paramCodeUnit.emitln("      this.param = param;");
/*     */     } 
/* 478 */     paramCodeUnit.emitln("    }");
/* 479 */     paramCodeUnit.emitln("  }");
/*     */   }
/*     */   
/*     */   public final String getJavaStaticCallbackSignature() {
/* 483 */     StringBuilder stringBuilder = new StringBuilder();
/* 484 */     stringBuilder.append("(");
/* 485 */     this.info.cbFuncBinding.forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid()) {
/*     */             if (paramInt1 == this.info.cbFuncUserParamIdx) {
/*     */               paramStringBuilder.append("J");
/*     */             } else {
/*     */               paramStringBuilder.append(paramJavaType.getDescriptor(this.cfg));
/*     */             } 
/*     */             
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 497 */     stringBuilder.append(")");
/* 498 */     stringBuilder.append(this.cbFuncJavaReturnType.getDescriptor(this.cfg));
/* 499 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   public final int appendJavaAdditionalJNIParameter(StringBuilder paramStringBuilder) {
/* 503 */     paramStringBuilder.append("Class<?> staticCBClazz, String callbackSignature");
/* 504 */     if (!this.userParamDefined) {
/* 505 */       return 2;
/*     */     }
/* 507 */     paramStringBuilder.append(", long nativeUserParam");
/* 508 */     return 3;
/*     */   }
/*     */   public final int appendJavaAdditionalJNIArguments(StringBuilder paramStringBuilder) {
/* 511 */     paramStringBuilder.append("this.getClass(), \"" + getJavaStaticCallbackSignature() + "\"");
/* 512 */     if (!this.userParamDefined) {
/* 513 */       return 2;
/*     */     }
/* 515 */     paramStringBuilder.append(", nativeUserParam");
/* 516 */     return 3;
/*     */   }
/*     */   
/*     */   public void emitJavaSetFuncPreCall(CodeUnit paramCodeUnit) {
/* 520 */     if (this.userParamDefined) {
/* 521 */       paramCodeUnit.emitln("    final long nativeUserParam;");
/*     */     }
/* 523 */     paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 524 */     if (this.userParamDefined) {
/* 525 */       if (this.setFuncUserParamJType.isLong()) {
/* 526 */         paramCodeUnit.emitln("      nativeUserParam = " + this.setFuncUserParamArgName + ";");
/*     */       } else {
/* 528 */         paramCodeUnit.emitln("      if( null != " + this.setFuncUserParamArgName + " ) {");
/* 529 */         if (this.setFuncUserParamJType.isCompoundTypeWrapper()) {
/*     */           
/* 531 */           paramCodeUnit.emitln("        nativeUserParam = " + this.setFuncUserParamArgName + ".getDirectBufferAddress();");
/*     */         } else {
/*     */           
/* 534 */           paramCodeUnit.emitln("        nativeUserParam = " + this.jcbNextIDVarName + "++;");
/* 535 */           paramCodeUnit.emitln("        if( 0 >= " + this.jcbNextIDVarName + " ) { " + this.jcbNextIDVarName + " = 1; }");
/*     */         } 
/* 537 */         paramCodeUnit.emitln("      } else {");
/* 538 */         paramCodeUnit.emitln("        nativeUserParam = 0;");
/* 539 */         paramCodeUnit.emitln("      }");
/*     */       } 
/*     */     }
/* 542 */     paramCodeUnit.emitln("      if( null != " + this.setFuncCBArgName + " ) {");
/* 543 */     paramCodeUnit.emit("        add" + this.capIfaceName + "(" + this.binding.getJavaCallSelectArguments(new StringBuilder(), this.info.setFuncKeyIndices, true).toString() + "new " + this.DataClassName + "(" + this.setFuncCBArgName);
/*     */     
/* 545 */     if (this.userParamDefined) {
/* 546 */       if (this.userParamIsMappedToID) {
/* 547 */         paramCodeUnit.emit(", nativeUserParam");
/*     */       }
/* 549 */       paramCodeUnit.emit(", " + this.setFuncUserParamArgName);
/*     */     } 
/* 551 */     paramCodeUnit.emitln("));");
/* 552 */     paramCodeUnit.emitln("      } else { ");
/* 553 */     paramCodeUnit.emitln("        // release a previously mapped instance ");
/* 554 */     if (this.useDataMap) {
/* 555 */       paramCodeUnit.emitln("        release" + this.capIfaceName + "( new " + this.KeyClassName + "( " + this.binding.getJavaCallSelectArguments(new StringBuilder(), this.info.setFuncKeyIndices, false).toString() + " ) );");
/*     */     } else {
/* 557 */       paramCodeUnit.emitln("        release" + this.capIfaceName + "();");
/*     */     } 
/* 559 */     paramCodeUnit.emitln("      }");
/* 560 */     paramCodeUnit.emitln("    } // synchronized ");
/* 561 */     paramCodeUnit.emitln();
/*     */   }
/*     */   
/*     */   private final void emitJavaStaticCallback(CodeUnit paramCodeUnit) {
/* 565 */     paramCodeUnit.emitln("  /** Static callback invocation, dispatching to " + this.info.cbSimpleClazzName + " for callback <br> <code>" + this.info.cbFuncType
/* 566 */         .toString(this.info.cbFuncTypeName, false, true) + "</code> */");
/* 567 */     paramCodeUnit.emit("  /* pp */ static " + this.cbFuncJavaReturnType.getName() + " invoke" + this.capIfaceName + "(");
/* 568 */     boolean[] arrayOfBoolean1 = { false };
/* 569 */     JavaType[] arrayOfJavaType = { null };
/* 570 */     this.info.cbFuncBinding.forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid()) {
/*     */             if (0 < paramInt2)
/*     */               paramCodeUnit.emit(", "); 
/*     */             if (paramInt1 == this.info.cbFuncUserParamIdx) {
/*     */               paramCodeUnit.emit("long nativeUserParam");
/*     */               if (paramJavaType.isCompoundTypeWrapper()) {
/*     */                 paramArrayOfboolean[0] = true;
/*     */                 paramArrayOfJavaType[0] = paramJavaType;
/*     */               } 
/*     */             } else {
/*     */               paramCodeUnit.emit(paramJavaType + " " + paramString);
/*     */             } 
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 587 */     paramCodeUnit.emitln(") {");
/* 588 */     boolean[] arrayOfBoolean2 = { false };
/* 589 */     if (this.userParamDefined) {
/* 590 */       if (arrayOfBoolean1[0]) {
/* 591 */         paramCodeUnit.emitln("    final " + arrayOfJavaType[0] + " " + this.info.cbFuncUserParamName + " = " + arrayOfJavaType[0] + ".derefPointer(nativeUserParam);");
/* 592 */         arrayOfBoolean2[0] = true;
/* 593 */       } else if (this.userParamIsMappedToID && this.userParamIsKey) {
/* 594 */         paramCodeUnit.emitln("    final " + this.userParamClassName + " " + this.info.cbFuncUserParamName + ";");
/*     */       } 
/*     */     }
/* 597 */     paramCodeUnit.emitln("    final " + this.DataClassName + " value;");
/* 598 */     paramCodeUnit.emitln("    synchronized( " + this.lockInstanceName + " ) {");
/* 599 */     if (this.userParamDefined && 
/* 600 */       this.userParamIsMappedToID && this.userParamIsKey && !arrayOfBoolean1[0]) {
/* 601 */       paramCodeUnit.emitln("      " + this.info.cbFuncUserParamName + " = (" + this.userParamClassName + ") " + this.userParamIDMapInstanceName + ".get(nativeUserParam);");
/* 602 */       arrayOfBoolean2[0] = true;
/*     */     } 
/*     */     
/* 605 */     if (this.useDataMap) {
/* 606 */       paramCodeUnit.emitln("      final " + this.KeyClassName + " key = new " + this.KeyClassName + "(" + this.info.cbFuncBinding.getJavaCallSelectArguments(new StringBuilder(), this.info.cbFuncKeyIndices, false).toString() + ");");
/* 607 */       paramCodeUnit.emitln("      value = " + this.dataMapInstanceName + ".get(key);");
/*     */     } else {
/* 609 */       paramCodeUnit.emitln("      value = " + this.dataInstanceName + ";");
/*     */     } 
/* 611 */     paramCodeUnit.emitln("    }");
/* 612 */     paramCodeUnit.emitln("    if( null == value ) {");
/* 613 */     if (!this.cbFuncJavaReturnType.isVoid()) {
/* 614 */       paramCodeUnit.emitln("      return 0;");
/*     */     } else {
/* 616 */       paramCodeUnit.emitln("      return;");
/*     */     } 
/* 618 */     paramCodeUnit.emitln("    }");
/* 619 */     if (!this.cbFuncJavaReturnType.isVoid()) {
/* 620 */       paramCodeUnit.emit("    return ");
/*     */     } else {
/* 622 */       paramCodeUnit.emit("    ");
/*     */     } 
/* 624 */     paramCodeUnit.emit("value.func.callback(");
/* 625 */     this.info.cbFuncBinding.forEachParameter((paramInt1, paramInt2, paramType, paramJavaType, paramString) -> {
/*     */           if (!paramType.isVoid()) {
/*     */             if (0 < paramInt2)
/*     */               paramCodeUnit.emit(", "); 
/*     */             if (paramInt1 == this.info.cbFuncUserParamIdx && !paramArrayOfboolean[0]) {
/*     */               paramCodeUnit.emit("value.param");
/*     */             } else {
/*     */               paramCodeUnit.emit(paramString);
/*     */             } 
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 638 */     paramCodeUnit.emitln(");");
/* 639 */     paramCodeUnit.emitln("  }");
/* 640 */     paramCodeUnit.emitln();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int appendCAdditionalParameter(StringBuilder paramStringBuilder) {
/* 648 */     paramStringBuilder.append(", jclass staticCBClazz, jstring jcallbackSignature");
/* 649 */     if (!this.userParamDefined) {
/* 650 */       return 2;
/*     */     }
/* 652 */     paramStringBuilder.append(", jlong jnativeUserParam");
/* 653 */     return 3;
/*     */   }
/*     */   
/*     */   public void emitCOptArgumentSuffix(CodeUnit paramCodeUnit, int paramInt) {
/* 657 */     if (paramInt == this.info.setFuncCBParamIdx || paramInt == this.info.setFuncUserParamIdx) {
/* 658 */       paramCodeUnit.emit("_native");
/*     */     }
/*     */   }
/*     */   
/*     */   public void appendCAdditionalJNIDescriptor(StringBuilder paramStringBuilder) {
/* 663 */     JavaType.appendJNIDescriptor(paramStringBuilder, Class.class, false);
/* 664 */     JavaType.appendJNIDescriptor(paramStringBuilder, String.class, false);
/* 665 */     if (this.userParamDefined) {
/* 666 */       JavaType.appendJNIDescriptor(paramStringBuilder, long.class, false);
/*     */     }
/*     */   }
/*     */   
/*     */   public void emitCSetFuncPreCall(CodeUnit paramCodeUnit) {
/* 671 */     String str8, str9, str1 = CodeGenUtils.capitalizeString(this.info.setFuncName);
/* 672 */     String str2 = this.info.setFuncName + "(" + this.info.cbSimpleClazzName + ")";
/* 673 */     String str3 = "invoke" + str1;
/* 674 */     String str4 = "staticCBClazz" + str1;
/* 675 */     String str5 = "staticCBMethod" + str1;
/* 676 */     String str6 = this.binding.getArgumentName(this.info.setFuncCBParamIdx);
/* 677 */     String str7 = str6 + "_native";
/*     */     
/* 679 */     if (this.userParamDefined) {
/* 680 */       str8 = this.info.cbFuncUserParamType.getCName();
/* 681 */       str9 = this.binding.getArgumentName(this.info.setFuncUserParamIdx) + "_native";
/*     */     } else {
/* 683 */       str8 = null;
/* 684 */       str9 = null;
/*     */     } 
/* 686 */     paramCodeUnit.emitln();
/* 687 */     paramCodeUnit.emitln("  // JavaCallback handling");
/* 688 */     paramCodeUnit.emitln("  if( NULL == staticCBClazz ) { (*env)->FatalError(env, \"NULL staticCBClazz passed to '" + str2 + "'\"); }");
/* 689 */     paramCodeUnit.emitln("  " + this.info.cbFuncTypeName + " " + str7 + ";");
/* 690 */     if (this.userParamDefined) {
/* 691 */       paramCodeUnit.emitln("  " + str8 + "* " + str9 + ";");
/*     */     }
/* 693 */     paramCodeUnit.emitln("  if( NULL != " + str6 + " ) {");
/* 694 */     paramCodeUnit.emitln("    if( NULL == " + str4 + " || NULL == " + str5 + " ) {");
/* 695 */     paramCodeUnit.emitln("      jclass staticCBClazz2 = (*env)->NewGlobalRef(env, staticCBClazz);");
/* 696 */     paramCodeUnit.emitln("      if( NULL == staticCBClazz2 ) { (*env)->FatalError(env, \"Failed NewGlobalRef(staticCBClazz) in '" + str2 + "'\"); }");
/* 697 */     paramCodeUnit.emitln("      const char* callbackSignature = (*env)->GetStringUTFChars(env, jcallbackSignature, (jboolean*)NULL);");
/* 698 */     paramCodeUnit.emitln("      if( NULL == callbackSignature ) { (*env)->FatalError(env, \"Failed callbackSignature in '" + str2 + "'\"); }");
/* 699 */     paramCodeUnit.emitln("      jmethodID cbMethodID = (*env)->GetStaticMethodID(env, staticCBClazz2, \"" + str3 + "\", callbackSignature);");
/* 700 */     paramCodeUnit.emitln("      if( NULL == cbMethodID ) {");
/* 701 */     paramCodeUnit.emitln("        char cmsg[400];");
/* 702 */     paramCodeUnit.emitln("        snprintf(cmsg, 400, \"Failed GetStaticMethodID of '" + str3 + "(%s)' in '" + str2 + "'\", callbackSignature);");
/* 703 */     paramCodeUnit.emitln("        (*env)->FatalError(env, cmsg);");
/* 704 */     paramCodeUnit.emitln("      }");
/* 705 */     paramCodeUnit.emitln("      (*env)->ReleaseStringUTFChars(env, jcallbackSignature, callbackSignature);");
/* 706 */     paramCodeUnit.emitln("      " + str4 + " = staticCBClazz2;");
/* 707 */     paramCodeUnit.emitln("      " + str5 + " = cbMethodID;");
/* 708 */     paramCodeUnit.emitln("    }");
/* 709 */     JavaType javaType = JavaType.createForClass(ByteBuffer.class);
/* 710 */     for (byte b = 0; b < this.info.cbFuncBinding.getNumArguments(); b++) {
/* 711 */       String str = CodeGenUtils.capitalizeString(this.info.cbFuncBinding.getArgumentName(b));
/* 712 */       JavaType javaType1 = this.info.cbFuncBinding.getJavaArgumentType(b);
/* 713 */       if (b != this.info.cbFuncUserParamIdx && javaType1.isCompoundTypeWrapper()) {
/* 714 */         String str10 = "staticCBArg" + str + "Clazz" + str1;
/* 715 */         String str11 = "staticCBArg" + str + "Method" + str1;
/* 716 */         paramCodeUnit.emitln("    if( NULL == " + str10 + " || NULL == " + str11 + " ) {");
/* 717 */         String str12 = javaType1.getDescriptor(this.cfg);
/* 718 */         String str13 = javaType1.getName(this.cfg);
/* 719 */         String str14 = str13.replace(".", "/");
/* 720 */         paramCodeUnit.emitln("      jclass " + str10 + "2 = (*env)->FindClass(env, \"" + str14 + "\");");
/* 721 */         paramCodeUnit.emitln("      if( NULL == " + str10 + "2 ) { (*env)->FatalError(env, \"Failed FindClass(" + str14 + ") in '" + str2 + "'\"); }");
/* 722 */         paramCodeUnit.emitln("      jmethodID " + str11 + "2 = (*env)->GetStaticMethodID(env, " + str10 + "2, \"create\", \"(" + javaType.getDescriptor() + ")" + str12 + "\");");
/* 723 */         paramCodeUnit.emitln("      if( NULL == " + str11 + "2 ) {");
/* 724 */         paramCodeUnit.emitln("        char cmsg[400];");
/* 725 */         paramCodeUnit.emitln("        snprintf(cmsg, 400, \"Failed GetStaticMethodID of '" + str13 + ".create(" + javaType.getDescriptor() + ")" + str12 + " in " + str2 + "'\");");
/* 726 */         paramCodeUnit.emitln("        (*env)->FatalError(env, cmsg);");
/* 727 */         paramCodeUnit.emitln("      }");
/* 728 */         paramCodeUnit.emitln("      " + str10 + " = " + str10 + "2;");
/* 729 */         paramCodeUnit.emitln("      " + str11 + " = " + str11 + "2;");
/* 730 */         paramCodeUnit.emitln("    }");
/*     */       } 
/*     */     } 
/* 733 */     paramCodeUnit.emitln("    " + str7 + " = func" + str1 + ";");
/* 734 */     if (this.userParamDefined) {
/* 735 */       paramCodeUnit.emitln("    " + str9 + " = (" + str8 + "*) jnativeUserParam;");
/*     */     }
/* 737 */     paramCodeUnit.emitln("  } else {");
/* 738 */     paramCodeUnit.emitln("    " + str7 + " = NULL;");
/* 739 */     if (this.userParamDefined) {
/* 740 */       paramCodeUnit.emitln("    " + str9 + " = NULL;");
/*     */     }
/* 742 */     paramCodeUnit.emitln("  }");
/* 743 */     paramCodeUnit.emitln();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void emitCAdditionalCode(CodeUnit paramCodeUnit, CMethodBindingEmitter paramCMethodBindingEmitter) {
/* 753 */     String str6, str7, str8, str1 = CodeGenUtils.capitalizeString(this.info.setFuncName);
/* 754 */     String str2 = this.info.setFuncName + "(" + this.info.cbSimpleClazzName + ")";
/* 755 */     String str3 = "staticCBClazz" + str1;
/* 756 */     String str4 = "staticCBMethod" + str1;
/* 757 */     String str5 = "func" + str1;
/*     */     
/* 759 */     if (this.userParamDefined) {
/*     */       
/* 761 */       str6 = this.info.cbFuncUserParamType.getCName();
/* 762 */       str7 = this.info.cbFuncBinding.getArgumentName(this.info.cbFuncUserParamIdx);
/*     */     } else {
/* 764 */       str6 = null;
/* 765 */       str7 = null;
/*     */     } 
/* 767 */     Type type = this.info.cbFuncBinding.getCReturnType();
/* 768 */     JavaType javaType = this.info.cbFuncBinding.getJavaReturnType();
/* 769 */     paramCodeUnit.emitln();
/* 770 */     paramCodeUnit.emitln("static jclass " + str3 + " = NULL;");
/* 771 */     paramCodeUnit.emitln("static jmethodID " + str4 + " = NULL;"); byte b;
/* 772 */     for (b = 0; b < this.info.cbFuncBinding.getNumArguments(); b++) {
/* 773 */       String str = CodeGenUtils.capitalizeString(this.info.cbFuncBinding.getArgumentName(b));
/* 774 */       JavaType javaType1 = this.info.cbFuncBinding.getJavaArgumentType(b);
/* 775 */       if (b != this.info.cbFuncUserParamIdx && javaType1.isCompoundTypeWrapper()) {
/* 776 */         String str9 = "staticCBArg" + str + "Clazz" + str1;
/* 777 */         String str10 = "staticCBArg" + str + "Method" + str1;
/* 778 */         paramCodeUnit.emitln("static jclass " + str9 + " = NULL;");
/* 779 */         paramCodeUnit.emitln("static jmethodID " + str10 + " = NULL;");
/*     */       } 
/*     */     } 
/* 782 */     paramCodeUnit.emitln();
/*     */     
/* 784 */     paramCodeUnit.emit("static " + type.getCName() + " " + str5 + "(");
/*     */     
/* 786 */     paramCodeUnit.emit(this.info.cbFuncBinding.getCParameterList(new StringBuilder(), false, null).toString());
/* 787 */     paramCodeUnit.emitln(") {");
/*     */ 
/*     */     
/* 790 */     paramCodeUnit.emitln("  int detachJVM = 0;");
/* 791 */     paramCodeUnit.emitln("  JNIEnv* env = JVMUtil_GetJNIEnv(1 /* daemon */, &detachJVM);");
/* 792 */     paramCodeUnit.emitln("  jclass cbClazz = " + str3 + ";");
/* 793 */     paramCodeUnit.emitln("  jmethodID cbMethod = " + str4 + ";");
/* 794 */     for (b = 0; b < this.info.cbFuncBinding.getNumArguments(); b++) {
/* 795 */       String str = CodeGenUtils.capitalizeString(this.info.cbFuncBinding.getArgumentName(b));
/* 796 */       JavaType javaType1 = this.info.cbFuncBinding.getJavaArgumentType(b);
/* 797 */       if (b != this.info.cbFuncUserParamIdx && javaType1.isCompoundTypeWrapper()) {
/* 798 */         String str9 = "staticCBArg" + str + "Clazz" + str1;
/* 799 */         String str10 = "staticCBArg" + str + "Method" + str1;
/* 800 */         paramCodeUnit.emitln("  jclass cbClazzArg" + str + " = " + str9 + ";");
/* 801 */         paramCodeUnit.emitln("  jmethodID cbMethodArg" + str + " = " + str10 + ";");
/*     */       } 
/*     */     } 
/* 804 */     paramCodeUnit.emitln("  if( NULL == env || NULL == cbClazz || NULL == cbMethod ) {");
/* 805 */     if (!type.isVoid()) {
/* 806 */       paramCodeUnit.emitln("    return 0;");
/*     */     } else {
/* 808 */       paramCodeUnit.emitln("    return;");
/*     */     } 
/* 810 */     paramCodeUnit.emitln("  }");
/*     */ 
/*     */ 
/*     */     
/* 814 */     emitJavaCallbackBodyCToJavaPreCall(paramCMethodBindingEmitter);
/*     */ 
/*     */     
/* 817 */     if (this.userParamDefined) {
/* 818 */       paramCodeUnit.emitln("  " + str6 + "* " + str7 + "_jni = (" + str6 + "*) " + str7 + ";");
/*     */     }
/* 820 */     paramCodeUnit.emitln("  // C Params: " + this.info.cbFuncBinding.getCParameterList(new StringBuilder(), false, null).toString());
/* 821 */     paramCodeUnit.emitln("  // J Params: " + this.info.cbFuncBinding.getJavaParameterList(new StringBuilder()).toString());
/*     */ 
/*     */     
/* 824 */     if (!type.isVoid()) {
/* 825 */       paramCodeUnit.emit("  " + type.getCName() + " _res = 0;");
/* 826 */       str8 = "return _res;";
/*     */     } else {
/* 828 */       str8 = "return;";
/*     */     } 
/* 830 */     if (!type.isVoid()) {
/* 831 */       paramCodeUnit.emit("  _res = (" + type.getCName() + ") ");
/*     */     } else {
/* 833 */       paramCodeUnit.emit("  ");
/*     */     } 
/* 835 */     paramCodeUnit.emit("(*env)->CallStatic" + CodeGenUtils.capitalizeString(javaType.getName()) + "Method(env, cbClazz, cbMethod, ");
/*     */     
/* 837 */     emitJavaCallbackBodyPassJavaArguments(paramCodeUnit);
/* 838 */     paramCodeUnit.emitln(");");
/* 839 */     paramCodeUnit.emitln("  if( (*env)->ExceptionCheck(env) ) {");
/* 840 */     paramCodeUnit.emitln("    fprintf(stderr, \"Info: Callback '" + str2 + "': Exception in Java Callback caught:\\n\");");
/* 841 */     paramCodeUnit.emitln("    (*env)->ExceptionDescribe(env);");
/* 842 */     paramCodeUnit.emitln("    (*env)->ExceptionClear(env);");
/* 843 */     paramCodeUnit.emitln("  }");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 848 */     paramCodeUnit.emitln("  JVMUtil_ReleaseJNIEnv(env, detachJVM);");
/* 849 */     paramCodeUnit.emitln("  " + str8);
/*     */     
/* 851 */     paramCodeUnit.emitln("}");
/* 852 */     paramCodeUnit.emitln();
/*     */   }
/*     */   
/*     */   private int emitJavaCallbackBodyCToJavaPreCall(CMethodBindingEmitter paramCMethodBindingEmitter) {
/* 856 */     byte b1 = 0;
/* 857 */     for (byte b2 = 0; b2 < paramCMethodBindingEmitter.binding.getNumArguments(); b2++) {
/* 858 */       if (b2 != this.info.cbFuncUserParamIdx)
/*     */       {
/*     */         
/* 861 */         if (paramCMethodBindingEmitter.emitBodyMapCToJNIType(b2, true))
/* 862 */           b1++; 
/*     */       }
/*     */     } 
/* 865 */     return b1;
/*     */   }
/*     */   
/*     */   private int emitJavaCallbackBodyPassJavaArguments(CodeUnit paramCodeUnit) {
/* 869 */     byte b1 = 0;
/* 870 */     boolean bool = false;
/* 871 */     for (byte b2 = 0; b2 < this.info.cbFuncBinding.getNumArguments(); b2++) {
/* 872 */       if (bool) {
/* 873 */         paramCodeUnit.emit(", ");
/* 874 */         bool = false;
/*     */       } 
/* 876 */       String str = this.info.cbFuncBinding.getArgumentName(b2);
/* 877 */       JavaType javaType = this.info.cbFuncBinding.getJavaArgumentType(b2);
/* 878 */       if (b2 != this.info.cbFuncUserParamIdx && javaType.isCompoundTypeWrapper()) {
/* 879 */         String str1 = CodeGenUtils.capitalizeString(str);
/* 880 */         paramCodeUnit.emit("(*env)->CallStaticObjectMethod(env, cbClazzArg" + str1 + ", cbMethodArg" + str1 + ", " + str + "_jni)");
/*     */       } else {
/* 882 */         paramCodeUnit.emit(str + "_jni");
/*     */       } 
/* 884 */       bool = true;
/* 885 */       b1++;
/*     */     } 
/* 887 */     return b1;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/JavaCallbackEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */