/*    */ package com.jogamp.gluegen.jgram;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ import java.io.Reader;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ class Test
/*    */ {
/*    */   static boolean showTree = false;
/*    */   
/*    */   public static void main(String[] paramArrayOfString) {
/*    */     try {
/* 17 */       if (paramArrayOfString.length > 0) {
/* 18 */         System.err.println("Parsing...");
/*    */ 
/*    */         
/* 21 */         for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 22 */           if (paramArrayOfString[b].equals("-showtree")) {
/* 23 */             showTree = true;
/*    */           } else {
/*    */             
/* 26 */             doFile(new File(paramArrayOfString[b]));
/*    */           } 
/*    */         } 
/*    */       } else {
/* 30 */         System.err.println("Usage: java com.jogamp.gluegen.jgram.Test [-showtree] <directory or file name>");
/*    */       }
/*    */     
/* 33 */     } catch (Exception exception) {
/* 34 */       System.err.println("exception: " + exception);
/* 35 */       exception.printStackTrace(System.err);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void doFile(File paramFile) throws Exception {
/* 45 */     if (paramFile.isDirectory()) {
/* 46 */       String[] arrayOfString = paramFile.list();
/* 47 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 48 */         doFile(new File(paramFile, arrayOfString[b]));
/*    */       
/*    */       }
/*    */     }
/* 52 */     else if (paramFile.getName().length() > 5 && paramFile
/* 53 */       .getName().substring(paramFile.getName().length() - 5).equals(".java")) {
/* 54 */       System.err.println("   " + paramFile.getAbsolutePath());
/*    */       
/* 56 */       parseFile(paramFile.getName(), new BufferedReader(new FileReader(paramFile)));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void parseFile(String paramString, Reader paramReader) throws Exception {
/*    */     try {
/* 65 */       JavaLexer javaLexer = new JavaLexer(paramReader);
/* 66 */       javaLexer.setFilename(paramString);
/*    */ 
/*    */       
/* 69 */       JavaParser javaParser = new JavaParser(javaLexer);
/* 70 */       javaParser.setFilename(paramString);
/*    */ 
/*    */       
/* 73 */       javaParser.compilationUnit();
/*    */       
/* 75 */       Set<String> set = javaParser.getParsedEnumNames();
/* 76 */       System.out.println("Enums");
/* 77 */       for (String str : set)
/*    */       {
/* 79 */         System.out.println(str);
/*    */       }
/* 81 */       System.out.println("Functions");
/* 82 */       set = javaParser.getParsedFunctionNames();
/* 83 */       for (String str : set)
/*    */       {
/* 85 */         System.out.println(str);
/*    */ 
/*    */       
/*    */       }
/*    */     
/*    */     }
/* 91 */     catch (Exception exception) {
/* 92 */       System.err.println("parser exception: " + exception);
/* 93 */       exception.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jgram/Test.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */