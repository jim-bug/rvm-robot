/*      */ package com.jogamp.gluegen.jgram;
/*      */ 
/*      */ import antlr.ANTLRHashString;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JavaLexer
/*      */   extends CharScanner
/*      */   implements JavaTokenTypes, TokenStream
/*      */ {
/*      */   public JavaLexer(InputStream paramInputStream) {
/*   36 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public JavaLexer(Reader paramReader) {
/*   39 */     this((InputBuffer)new CharBuffer(paramReader));
/*      */   }
/*      */   public JavaLexer(InputBuffer paramInputBuffer) {
/*   42 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public JavaLexer(LexerSharedInputState paramLexerSharedInputState) {
/*   45 */     super(paramLexerSharedInputState);
/*   46 */     this.caseSensitiveLiterals = true;
/*   47 */     setCaseSensitive(true);
/*   48 */     this.literals = new Hashtable<>();
/*   49 */     this.literals.put(new ANTLRHashString("byte", this), new Integer(56));
/*   50 */     this.literals.put(new ANTLRHashString("public", this), new Integer(67));
/*   51 */     this.literals.put(new ANTLRHashString("case", this), new Integer(98));
/*   52 */     this.literals.put(new ANTLRHashString("short", this), new Integer(58));
/*   53 */     this.literals.put(new ANTLRHashString("break", this), new Integer(93));
/*   54 */     this.literals.put(new ANTLRHashString("while", this), new Integer(91));
/*   55 */     this.literals.put(new ANTLRHashString("new", this), new Integer(138));
/*   56 */     this.literals.put(new ANTLRHashString("instanceof", this), new Integer(123));
/*   57 */     this.literals.put(new ANTLRHashString("implements", this), new Integer(80));
/*   58 */     this.literals.put(new ANTLRHashString("synchronized", this), new Integer(73));
/*   59 */     this.literals.put(new ANTLRHashString("float", this), new Integer(60));
/*   60 */     this.literals.put(new ANTLRHashString("package", this), new Integer(44));
/*   61 */     this.literals.put(new ANTLRHashString("return", this), new Integer(95));
/*   62 */     this.literals.put(new ANTLRHashString("throw", this), new Integer(97));
/*   63 */     this.literals.put(new ANTLRHashString("null", this), new Integer(137));
/*   64 */     this.literals.put(new ANTLRHashString("threadsafe", this), new Integer(72));
/*   65 */     this.literals.put(new ANTLRHashString("protected", this), new Integer(68));
/*   66 */     this.literals.put(new ANTLRHashString("class", this), new Integer(75));
/*   67 */     this.literals.put(new ANTLRHashString("throws", this), new Integer(86));
/*   68 */     this.literals.put(new ANTLRHashString("do", this), new Integer(92));
/*   69 */     this.literals.put(new ANTLRHashString("strictfp", this), new Integer(41));
/*   70 */     this.literals.put(new ANTLRHashString("super", this), new Integer(84));
/*   71 */     this.literals.put(new ANTLRHashString("transient", this), new Integer(70));
/*   72 */     this.literals.put(new ANTLRHashString("native", this), new Integer(71));
/*   73 */     this.literals.put(new ANTLRHashString("interface", this), new Integer(76));
/*   74 */     this.literals.put(new ANTLRHashString("final", this), new Integer(39));
/*   75 */     this.literals.put(new ANTLRHashString("if", this), new Integer(88));
/*   76 */     this.literals.put(new ANTLRHashString("double", this), new Integer(62));
/*   77 */     this.literals.put(new ANTLRHashString("volatile", this), new Integer(74));
/*   78 */     this.literals.put(new ANTLRHashString("catch", this), new Integer(102));
/*   79 */     this.literals.put(new ANTLRHashString("try", this), new Integer(100));
/*   80 */     this.literals.put(new ANTLRHashString("int", this), new Integer(59));
/*   81 */     this.literals.put(new ANTLRHashString("for", this), new Integer(90));
/*   82 */     this.literals.put(new ANTLRHashString("extends", this), new Integer(49));
/*   83 */     this.literals.put(new ANTLRHashString("boolean", this), new Integer(55));
/*   84 */     this.literals.put(new ANTLRHashString("char", this), new Integer(57));
/*   85 */     this.literals.put(new ANTLRHashString("private", this), new Integer(66));
/*   86 */     this.literals.put(new ANTLRHashString("default", this), new Integer(99));
/*   87 */     this.literals.put(new ANTLRHashString("false", this), new Integer(136));
/*   88 */     this.literals.put(new ANTLRHashString("this", this), new Integer(83));
/*   89 */     this.literals.put(new ANTLRHashString("static", this), new Integer(69));
/*   90 */     this.literals.put(new ANTLRHashString("abstract", this), new Integer(40));
/*   91 */     this.literals.put(new ANTLRHashString("continue", this), new Integer(94));
/*   92 */     this.literals.put(new ANTLRHashString("finally", this), new Integer(101));
/*   93 */     this.literals.put(new ANTLRHashString("else", this), new Integer(89));
/*   94 */     this.literals.put(new ANTLRHashString("import", this), new Integer(46));
/*   95 */     this.literals.put(new ANTLRHashString("void", this), new Integer(54));
/*   96 */     this.literals.put(new ANTLRHashString("switch", this), new Integer(96));
/*   97 */     this.literals.put(new ANTLRHashString("true", this), new Integer(135));
/*   98 */     this.literals.put(new ANTLRHashString("long", this), new Integer(61));
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  102 */     Token token = null;
/*      */     
/*      */     while (true) {
/*  105 */       Object object = null;
/*  106 */       int i = 0;
/*  107 */       resetText();
/*      */       
/*      */       try {
/*  110 */         switch (LA(1)) {
/*      */           
/*      */           case '?':
/*  113 */             mQUESTION(true);
/*  114 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*  119 */             mLPAREN(true);
/*  120 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*  125 */             mRPAREN(true);
/*  126 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '[':
/*  131 */             mLBRACK(true);
/*  132 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ']':
/*  137 */             mRBRACK(true);
/*  138 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '{':
/*  143 */             mLCURLY(true);
/*  144 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '}':
/*  149 */             mRCURLY(true);
/*  150 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ':':
/*  155 */             mCOLON(true);
/*  156 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ',':
/*  161 */             mCOMMA(true);
/*  162 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '~':
/*  167 */             mBNOT(true);
/*  168 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ';':
/*  173 */             mSEMI(true);
/*  174 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '@':
/*  179 */             mAT(true);
/*  180 */             token = this._returnToken; break;
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\f':
/*      */           case '\r':
/*      */           case ' ':
/*  186 */             mWS(true);
/*  187 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\'':
/*  192 */             mCHAR_LITERAL(true);
/*  193 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '"':
/*  198 */             mSTRING_LITERAL(true);
/*  199 */             token = this._returnToken; break;
/*      */           case '$': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/*  217 */             mIDENT(true);
/*  218 */             token = this._returnToken; break;
/*      */           case '.': case '0': case '1': case '2': case '3': case '4':
/*      */           case '5':
/*      */           case '6':
/*      */           case '7':
/*      */           case '8':
/*      */           case '9':
/*  225 */             mNUM_INT(true);
/*  226 */             token = this._returnToken;
/*      */             break;
/*      */           
/*      */           default:
/*  230 */             if (LA(1) == '>' && LA(2) == '>' && LA(3) == '>' && LA(4) == '=') {
/*  231 */               mBSR_ASSIGN(true);
/*  232 */               token = this._returnToken; break;
/*      */             } 
/*  234 */             if (LA(1) == '>' && LA(2) == '>' && LA(3) == '=') {
/*  235 */               mSR_ASSIGN(true);
/*  236 */               token = this._returnToken; break;
/*      */             } 
/*  238 */             if (LA(1) == '>' && LA(2) == '>' && LA(3) == '>') {
/*  239 */               mBSR(true);
/*  240 */               token = this._returnToken; break;
/*      */             } 
/*  242 */             if (LA(1) == '<' && LA(2) == '<' && LA(3) == '=') {
/*  243 */               mSL_ASSIGN(true);
/*  244 */               token = this._returnToken; break;
/*      */             } 
/*  246 */             if (LA(1) == '=' && LA(2) == '=') {
/*  247 */               mEQUAL(true);
/*  248 */               token = this._returnToken; break;
/*      */             } 
/*  250 */             if (LA(1) == '!' && LA(2) == '=') {
/*  251 */               mNOT_EQUAL(true);
/*  252 */               token = this._returnToken; break;
/*      */             } 
/*  254 */             if (LA(1) == '/' && LA(2) == '=') {
/*  255 */               mDIV_ASSIGN(true);
/*  256 */               token = this._returnToken; break;
/*      */             } 
/*  258 */             if (LA(1) == '+' && LA(2) == '=') {
/*  259 */               mPLUS_ASSIGN(true);
/*  260 */               token = this._returnToken; break;
/*      */             } 
/*  262 */             if (LA(1) == '+' && LA(2) == '+') {
/*  263 */               mINC(true);
/*  264 */               token = this._returnToken; break;
/*      */             } 
/*  266 */             if (LA(1) == '-' && LA(2) == '=') {
/*  267 */               mMINUS_ASSIGN(true);
/*  268 */               token = this._returnToken; break;
/*      */             } 
/*  270 */             if (LA(1) == '-' && LA(2) == '-') {
/*  271 */               mDEC(true);
/*  272 */               token = this._returnToken; break;
/*      */             } 
/*  274 */             if (LA(1) == '*' && LA(2) == '=') {
/*  275 */               mSTAR_ASSIGN(true);
/*  276 */               token = this._returnToken; break;
/*      */             } 
/*  278 */             if (LA(1) == '%' && LA(2) == '=') {
/*  279 */               mMOD_ASSIGN(true);
/*  280 */               token = this._returnToken; break;
/*      */             } 
/*  282 */             if (LA(1) == '>' && LA(2) == '>') {
/*  283 */               mSR(true);
/*  284 */               token = this._returnToken; break;
/*      */             } 
/*  286 */             if (LA(1) == '>' && LA(2) == '=') {
/*  287 */               mGE(true);
/*  288 */               token = this._returnToken; break;
/*      */             } 
/*  290 */             if (LA(1) == '<' && LA(2) == '<') {
/*  291 */               mSL(true);
/*  292 */               token = this._returnToken; break;
/*      */             } 
/*  294 */             if (LA(1) == '<' && LA(2) == '=') {
/*  295 */               mLE(true);
/*  296 */               token = this._returnToken; break;
/*      */             } 
/*  298 */             if (LA(1) == '^' && LA(2) == '=') {
/*  299 */               mBXOR_ASSIGN(true);
/*  300 */               token = this._returnToken; break;
/*      */             } 
/*  302 */             if (LA(1) == '|' && LA(2) == '=') {
/*  303 */               mBOR_ASSIGN(true);
/*  304 */               token = this._returnToken; break;
/*      */             } 
/*  306 */             if (LA(1) == '|' && LA(2) == '|') {
/*  307 */               mLOR(true);
/*  308 */               token = this._returnToken; break;
/*      */             } 
/*  310 */             if (LA(1) == '&' && LA(2) == '=') {
/*  311 */               mBAND_ASSIGN(true);
/*  312 */               token = this._returnToken; break;
/*      */             } 
/*  314 */             if (LA(1) == '&' && LA(2) == '&') {
/*  315 */               mLAND(true);
/*  316 */               token = this._returnToken; break;
/*      */             } 
/*  318 */             if (LA(1) == '/' && LA(2) == '/') {
/*  319 */               mSL_COMMENT(true);
/*  320 */               token = this._returnToken; break;
/*      */             } 
/*  322 */             if (LA(1) == '/' && LA(2) == '*') {
/*  323 */               mML_COMMENT(true);
/*  324 */               token = this._returnToken; break;
/*      */             } 
/*  326 */             if (LA(1) == '=') {
/*  327 */               mASSIGN(true);
/*  328 */               token = this._returnToken; break;
/*      */             } 
/*  330 */             if (LA(1) == '!') {
/*  331 */               mLNOT(true);
/*  332 */               token = this._returnToken; break;
/*      */             } 
/*  334 */             if (LA(1) == '/') {
/*  335 */               mDIV(true);
/*  336 */               token = this._returnToken; break;
/*      */             } 
/*  338 */             if (LA(1) == '+') {
/*  339 */               mPLUS(true);
/*  340 */               token = this._returnToken; break;
/*      */             } 
/*  342 */             if (LA(1) == '-') {
/*  343 */               mMINUS(true);
/*  344 */               token = this._returnToken; break;
/*      */             } 
/*  346 */             if (LA(1) == '*') {
/*  347 */               mSTAR(true);
/*  348 */               token = this._returnToken; break;
/*      */             } 
/*  350 */             if (LA(1) == '%') {
/*  351 */               mMOD(true);
/*  352 */               token = this._returnToken; break;
/*      */             } 
/*  354 */             if (LA(1) == '>') {
/*  355 */               mGT(true);
/*  356 */               token = this._returnToken; break;
/*      */             } 
/*  358 */             if (LA(1) == '<') {
/*  359 */               mLT(true);
/*  360 */               token = this._returnToken; break;
/*      */             } 
/*  362 */             if (LA(1) == '^') {
/*  363 */               mBXOR(true);
/*  364 */               token = this._returnToken; break;
/*      */             } 
/*  366 */             if (LA(1) == '|') {
/*  367 */               mBOR(true);
/*  368 */               token = this._returnToken; break;
/*      */             } 
/*  370 */             if (LA(1) == '&') {
/*  371 */               mBAND(true);
/*  372 */               token = this._returnToken;
/*      */               break;
/*      */             } 
/*  375 */             if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); break; }
/*  376 */              throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */         
/*  379 */         if (this._returnToken == null)
/*  380 */           continue;  i = this._returnToken.getType();
/*  381 */         this._returnToken.setType(i);
/*  382 */         return this._returnToken;
/*      */       }
/*  384 */       catch (RecognitionException recognitionException) {
/*  385 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  388 */       catch (CharStreamException charStreamException) {
/*  389 */         if (charStreamException instanceof CharStreamIOException) {
/*  390 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  393 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void mQUESTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  400 */     Token token = null; int i = this.text.length();
/*  401 */     byte b = 48;
/*      */ 
/*      */     
/*  404 */     match('?');
/*  405 */     if (paramBoolean && token == null && b != -1) {
/*  406 */       token = makeToken(b);
/*  407 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  409 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  413 */     Token token = null; int i = this.text.length();
/*  414 */     byte b = 81;
/*      */ 
/*      */     
/*  417 */     match('(');
/*  418 */     if (paramBoolean && token == null && b != -1) {
/*  419 */       token = makeToken(b);
/*  420 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  422 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  426 */     Token token = null; int i = this.text.length();
/*  427 */     byte b = 82;
/*      */ 
/*      */     
/*  430 */     match(')');
/*  431 */     if (paramBoolean && token == null && b != -1) {
/*  432 */       token = makeToken(b);
/*  433 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  435 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLBRACK(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  439 */     Token token = null; int i = this.text.length();
/*  440 */     byte b = 52;
/*      */ 
/*      */     
/*  443 */     match('[');
/*  444 */     if (paramBoolean && token == null && b != -1) {
/*  445 */       token = makeToken(b);
/*  446 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  448 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRBRACK(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  452 */     Token token = null; int i = this.text.length();
/*  453 */     byte b = 53;
/*      */ 
/*      */     
/*  456 */     match(']');
/*  457 */     if (paramBoolean && token == null && b != -1) {
/*  458 */       token = makeToken(b);
/*  459 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  461 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLCURLY(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  465 */     Token token = null; int i = this.text.length();
/*  466 */     byte b = 77;
/*      */ 
/*      */     
/*  469 */     match('{');
/*  470 */     if (paramBoolean && token == null && b != -1) {
/*  471 */       token = makeToken(b);
/*  472 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  474 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRCURLY(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  478 */     Token token = null; int i = this.text.length();
/*  479 */     byte b = 78;
/*      */ 
/*      */     
/*  482 */     match('}');
/*  483 */     if (paramBoolean && token == null && b != -1) {
/*  484 */       token = makeToken(b);
/*  485 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  487 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOLON(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  491 */     Token token = null; int i = this.text.length();
/*  492 */     byte b = 87;
/*      */ 
/*      */     
/*  495 */     match(':');
/*  496 */     if (paramBoolean && token == null && b != -1) {
/*  497 */       token = makeToken(b);
/*  498 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  500 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOMMA(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  504 */     Token token = null; int i = this.text.length();
/*  505 */     byte b = 79;
/*      */ 
/*      */     
/*  508 */     match(',');
/*  509 */     if (paramBoolean && token == null && b != -1) {
/*  510 */       token = makeToken(b);
/*  511 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  513 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  517 */     Token token = null; int i = this.text.length();
/*  518 */     byte b = 85;
/*      */ 
/*      */     
/*  521 */     match('=');
/*  522 */     if (paramBoolean && token == null && b != -1) {
/*  523 */       token = makeToken(b);
/*  524 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  526 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mEQUAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  530 */     Token token = null; int i = this.text.length();
/*  531 */     byte b = 120;
/*      */ 
/*      */     
/*  534 */     match("==");
/*  535 */     if (paramBoolean && token == null && b != -1) {
/*  536 */       token = makeToken(b);
/*  537 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  539 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLNOT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  543 */     Token token = null; int i = this.text.length();
/*  544 */     char c = '';
/*      */ 
/*      */     
/*  547 */     match('!');
/*  548 */     if (paramBoolean && token == null && c != -1) {
/*  549 */       token = makeToken(c);
/*  550 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  552 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBNOT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  556 */     Token token = null; int i = this.text.length();
/*  557 */     char c = '';
/*      */ 
/*      */     
/*  560 */     match('~');
/*  561 */     if (paramBoolean && token == null && c != -1) {
/*  562 */       token = makeToken(c);
/*  563 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  565 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mNOT_EQUAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  569 */     Token token = null; int i = this.text.length();
/*  570 */     byte b = 119;
/*      */ 
/*      */     
/*  573 */     match("!=");
/*  574 */     if (paramBoolean && token == null && b != -1) {
/*  575 */       token = makeToken(b);
/*  576 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  578 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDIV(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  582 */     Token token = null; int i = this.text.length();
/*  583 */     char c = '';
/*      */ 
/*      */     
/*  586 */     match('/');
/*  587 */     if (paramBoolean && token == null && c != -1) {
/*  588 */       token = makeToken(c);
/*  589 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  591 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDIV_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  595 */     Token token = null; int i = this.text.length();
/*  596 */     byte b = 107;
/*      */ 
/*      */     
/*  599 */     match("/=");
/*  600 */     if (paramBoolean && token == null && b != -1) {
/*  601 */       token = makeToken(b);
/*  602 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  604 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPLUS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  608 */     Token token = null; int i = this.text.length();
/*  609 */     byte b = 127;
/*      */ 
/*      */     
/*  612 */     match('+');
/*  613 */     if (paramBoolean && token == null && b != -1) {
/*  614 */       token = makeToken(b);
/*  615 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  617 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPLUS_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  621 */     Token token = null; int i = this.text.length();
/*  622 */     byte b = 104;
/*      */ 
/*      */     
/*  625 */     match("+=");
/*  626 */     if (paramBoolean && token == null && b != -1) {
/*  627 */       token = makeToken(b);
/*  628 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  630 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mINC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  634 */     Token token = null; int i = this.text.length();
/*  635 */     char c = '';
/*      */ 
/*      */     
/*  638 */     match("++");
/*  639 */     if (paramBoolean && token == null && c != -1) {
/*  640 */       token = makeToken(c);
/*  641 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  643 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMINUS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  647 */     Token token = null; int i = this.text.length();
/*  648 */     char c = '';
/*      */ 
/*      */     
/*  651 */     match('-');
/*  652 */     if (paramBoolean && token == null && c != -1) {
/*  653 */       token = makeToken(c);
/*  654 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  656 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMINUS_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  660 */     Token token = null; int i = this.text.length();
/*  661 */     byte b = 105;
/*      */ 
/*      */     
/*  664 */     match("-=");
/*  665 */     if (paramBoolean && token == null && b != -1) {
/*  666 */       token = makeToken(b);
/*  667 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  669 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDEC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  673 */     Token token = null; int i = this.text.length();
/*  674 */     char c = '';
/*      */ 
/*      */     
/*  677 */     match("--");
/*  678 */     if (paramBoolean && token == null && c != -1) {
/*  679 */       token = makeToken(c);
/*  680 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  682 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTAR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  686 */     Token token = null; int i = this.text.length();
/*  687 */     byte b = 65;
/*      */ 
/*      */     
/*  690 */     match('*');
/*  691 */     if (paramBoolean && token == null && b != -1) {
/*  692 */       token = makeToken(b);
/*  693 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  695 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTAR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  699 */     Token token = null; int i = this.text.length();
/*  700 */     byte b = 106;
/*      */ 
/*      */     
/*  703 */     match("*=");
/*  704 */     if (paramBoolean && token == null && b != -1) {
/*  705 */       token = makeToken(b);
/*  706 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  708 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMOD(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  712 */     Token token = null; int i = this.text.length();
/*  713 */     char c = '';
/*      */ 
/*      */     
/*  716 */     match('%');
/*  717 */     if (paramBoolean && token == null && c != -1) {
/*  718 */       token = makeToken(c);
/*  719 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  721 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMOD_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  725 */     Token token = null; int i = this.text.length();
/*  726 */     byte b = 108;
/*      */ 
/*      */     
/*  729 */     match("%=");
/*  730 */     if (paramBoolean && token == null && b != -1) {
/*  731 */       token = makeToken(b);
/*  732 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  734 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  738 */     Token token = null; int i = this.text.length();
/*  739 */     byte b = 125;
/*      */ 
/*      */     
/*  742 */     match(">>");
/*  743 */     if (paramBoolean && token == null && b != -1) {
/*  744 */       token = makeToken(b);
/*  745 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  747 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  751 */     Token token = null; int i = this.text.length();
/*  752 */     byte b = 109;
/*      */ 
/*      */     
/*  755 */     match(">>=");
/*  756 */     if (paramBoolean && token == null && b != -1) {
/*  757 */       token = makeToken(b);
/*  758 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  760 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBSR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  764 */     Token token = null; int i = this.text.length();
/*  765 */     byte b = 126;
/*      */ 
/*      */     
/*  768 */     match(">>>");
/*  769 */     if (paramBoolean && token == null && b != -1) {
/*  770 */       token = makeToken(b);
/*  771 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  773 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBSR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  777 */     Token token = null; int i = this.text.length();
/*  778 */     byte b = 110;
/*      */ 
/*      */     
/*  781 */     match(">>>=");
/*  782 */     if (paramBoolean && token == null && b != -1) {
/*  783 */       token = makeToken(b);
/*  784 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  786 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mGE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  790 */     Token token = null; int i = this.text.length();
/*  791 */     byte b = 122;
/*      */ 
/*      */     
/*  794 */     match(">=");
/*  795 */     if (paramBoolean && token == null && b != -1) {
/*  796 */       token = makeToken(b);
/*  797 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  799 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mGT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  803 */     Token token = null; int i = this.text.length();
/*  804 */     byte b = 51;
/*      */ 
/*      */     
/*  807 */     match(">");
/*  808 */     if (paramBoolean && token == null && b != -1) {
/*  809 */       token = makeToken(b);
/*  810 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  812 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  816 */     Token token = null; int i = this.text.length();
/*  817 */     byte b = 124;
/*      */ 
/*      */     
/*  820 */     match("<<");
/*  821 */     if (paramBoolean && token == null && b != -1) {
/*  822 */       token = makeToken(b);
/*  823 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  825 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSL_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  829 */     Token token = null; int i = this.text.length();
/*  830 */     byte b = 111;
/*      */ 
/*      */     
/*  833 */     match("<<=");
/*  834 */     if (paramBoolean && token == null && b != -1) {
/*  835 */       token = makeToken(b);
/*  836 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  838 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  842 */     Token token = null; int i = this.text.length();
/*  843 */     byte b = 121;
/*      */ 
/*      */     
/*  846 */     match("<=");
/*  847 */     if (paramBoolean && token == null && b != -1) {
/*  848 */       token = makeToken(b);
/*  849 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  851 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  855 */     Token token = null; int i = this.text.length();
/*  856 */     byte b = 47;
/*      */ 
/*      */     
/*  859 */     match('<');
/*  860 */     if (paramBoolean && token == null && b != -1) {
/*  861 */       token = makeToken(b);
/*  862 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  864 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBXOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  868 */     Token token = null; int i = this.text.length();
/*  869 */     byte b = 118;
/*      */ 
/*      */     
/*  872 */     match('^');
/*  873 */     if (paramBoolean && token == null && b != -1) {
/*  874 */       token = makeToken(b);
/*  875 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  877 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBXOR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  881 */     Token token = null; int i = this.text.length();
/*  882 */     byte b = 113;
/*      */ 
/*      */     
/*  885 */     match("^=");
/*  886 */     if (paramBoolean && token == null && b != -1) {
/*  887 */       token = makeToken(b);
/*  888 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  890 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  894 */     Token token = null; int i = this.text.length();
/*  895 */     byte b = 117;
/*      */ 
/*      */     
/*  898 */     match('|');
/*  899 */     if (paramBoolean && token == null && b != -1) {
/*  900 */       token = makeToken(b);
/*  901 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  903 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBOR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  907 */     Token token = null; int i = this.text.length();
/*  908 */     byte b = 114;
/*      */ 
/*      */     
/*  911 */     match("|=");
/*  912 */     if (paramBoolean && token == null && b != -1) {
/*  913 */       token = makeToken(b);
/*  914 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  916 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  920 */     Token token = null; int i = this.text.length();
/*  921 */     byte b = 115;
/*      */ 
/*      */     
/*  924 */     match("||");
/*  925 */     if (paramBoolean && token == null && b != -1) {
/*  926 */       token = makeToken(b);
/*  927 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  929 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBAND(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  933 */     Token token = null; int i = this.text.length();
/*  934 */     byte b = 50;
/*      */ 
/*      */     
/*  937 */     match('&');
/*  938 */     if (paramBoolean && token == null && b != -1) {
/*  939 */       token = makeToken(b);
/*  940 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  942 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBAND_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  946 */     Token token = null; int i = this.text.length();
/*  947 */     byte b = 112;
/*      */ 
/*      */     
/*  950 */     match("&=");
/*  951 */     if (paramBoolean && token == null && b != -1) {
/*  952 */       token = makeToken(b);
/*  953 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  955 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLAND(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  959 */     Token token = null; int i = this.text.length();
/*  960 */     byte b = 116;
/*      */ 
/*      */     
/*  963 */     match("&&");
/*  964 */     if (paramBoolean && token == null && b != -1) {
/*  965 */       token = makeToken(b);
/*  966 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  968 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSEMI(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  972 */     Token token = null; int i = this.text.length();
/*  973 */     byte b = 45;
/*      */ 
/*      */     
/*  976 */     match(';');
/*  977 */     if (paramBoolean && token == null && b != -1) {
/*  978 */       token = makeToken(b);
/*  979 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  981 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mAT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  985 */     Token token = null; int i = this.text.length();
/*  986 */     byte b = 103;
/*      */ 
/*      */     
/*  989 */     match('@');
/*  990 */     if (paramBoolean && token == null && b != -1) {
/*  991 */       token = makeToken(b);
/*  992 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  994 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  998 */     Token token = null; int i = this.text.length();
/*  999 */     short s = 145;
/*      */ 
/*      */ 
/*      */     
/* 1003 */     byte b = 0;
/*      */     
/*      */     while (true) {
/* 1006 */       switch (LA(1)) {
/*      */         
/*      */         case ' ':
/* 1009 */           match(' ');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\t':
/* 1014 */           match('\t');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\f':
/* 1019 */           match('\f');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\n':
/*      */         case '\r':
/* 1025 */           if (LA(1) == '\r' && LA(2) == '\n') {
/* 1026 */             match("\r\n");
/*      */           }
/* 1028 */           else if (LA(1) == '\r') {
/* 1029 */             match('\r');
/*      */           }
/* 1031 */           else if (LA(1) == '\n') {
/* 1032 */             match('\n');
/*      */           } else {
/*      */             
/* 1035 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */ 
/*      */           
/* 1039 */           if (this.inputState.guessing == 0) {
/* 1040 */             newline();
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1046 */           if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1049 */       b++;
/*      */     } 
/*      */     
/* 1052 */     if (this.inputState.guessing == 0) {
/* 1053 */       s = -1;
/*      */     }
/* 1055 */     if (paramBoolean && token == null && s != -1) {
/* 1056 */       token = makeToken(s);
/* 1057 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1059 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1063 */     Token token = null; int i = this.text.length();
/* 1064 */     short s = 146;
/*      */ 
/*      */     
/* 1067 */     match("//");
/*      */ 
/*      */ 
/*      */     
/* 1071 */     while (_tokenSet_0.member(LA(1)))
/*      */     {
/* 1073 */       match(_tokenSet_0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1083 */     switch (LA(1)) {
/*      */       
/*      */       case '\n':
/* 1086 */         match('\n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\r':
/* 1091 */         match('\r');
/*      */         
/* 1093 */         if (LA(1) == '\n') {
/* 1094 */           match('\n');
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1107 */     if (this.inputState.guessing == 0) {
/* 1108 */       s = -1; newline();
/*      */     } 
/* 1110 */     if (paramBoolean && token == null && s != -1) {
/* 1111 */       token = makeToken(s);
/* 1112 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1114 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1118 */     Token token = null; int i = this.text.length();
/* 1119 */     short s = 147;
/*      */ 
/*      */     
/* 1122 */     match("/*");
/*      */ 
/*      */     
/*      */     while (true) {
/* 1126 */       if (LA(1) == '\r' && LA(2) == '\n' && LA(3) >= '\003' && LA(3) <= '翾' && LA(4) >= '\003' && LA(4) <= '翾') {
/* 1127 */         match('\r');
/* 1128 */         match('\n');
/* 1129 */         if (this.inputState.guessing == 0)
/* 1130 */           newline(); 
/*      */         continue;
/*      */       } 
/* 1133 */       if (LA(1) == '*' && LA(2) >= '\003' && LA(2) <= '翾' && LA(3) >= '\003' && LA(3) <= '翾' && LA(2) != '/') {
/* 1134 */         match('*'); continue;
/*      */       } 
/* 1136 */       if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= '翾' && LA(3) >= '\003' && LA(3) <= '翾') {
/* 1137 */         match('\r');
/* 1138 */         if (this.inputState.guessing == 0)
/* 1139 */           newline(); 
/*      */         continue;
/*      */       } 
/* 1142 */       if (LA(1) == '\n') {
/* 1143 */         match('\n');
/* 1144 */         if (this.inputState.guessing == 0)
/* 1145 */           newline(); 
/*      */         continue;
/*      */       } 
/* 1148 */       if (_tokenSet_1.member(LA(1))) {
/*      */         
/* 1150 */         match(_tokenSet_1);
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1159 */     match("*/");
/* 1160 */     if (this.inputState.guessing == 0) {
/* 1161 */       s = -1;
/*      */     }
/* 1163 */     if (paramBoolean && token == null && s != -1) {
/* 1164 */       token = makeToken(s);
/* 1165 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1167 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCHAR_LITERAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1171 */     Token token = null; int i = this.text.length();
/* 1172 */     char c = '';
/*      */ 
/*      */     
/* 1175 */     match('\'');
/*      */     
/* 1177 */     if (LA(1) == '\\') {
/* 1178 */       mESC(false);
/*      */     }
/* 1180 */     else if (_tokenSet_2.member(LA(1))) {
/*      */       
/* 1182 */       match(_tokenSet_2);
/*      */     }
/*      */     else {
/*      */       
/* 1186 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1190 */     match('\'');
/* 1191 */     if (paramBoolean && token == null && c != -1) {
/* 1192 */       token = makeToken(c);
/* 1193 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1195 */     this._returnToken = token;
/*      */   }
/*      */   protected final void mESC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     byte b;
/* 1199 */     Token token = null; int i = this.text.length();
/* 1200 */     char c = '';
/*      */ 
/*      */     
/* 1203 */     match('\\');
/*      */     
/* 1205 */     switch (LA(1)) {
/*      */       
/*      */       case 'n':
/* 1208 */         match('n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'r':
/* 1213 */         match('r');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 't':
/* 1218 */         match('t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'b':
/* 1223 */         match('b');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/* 1228 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1233 */         match('"');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 1238 */         match('\'');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\\':
/* 1243 */         match('\\');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 'u':
/* 1249 */         b = 0;
/*      */         
/*      */         while (true) {
/* 1252 */           if (LA(1) == 'u') {
/* 1253 */             match('u');
/*      */           } else {
/*      */             
/* 1256 */             if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 1259 */           b++;
/*      */         } 
/*      */         
/* 1262 */         mHEX_DIGIT(false);
/* 1263 */         mHEX_DIGIT(false);
/* 1264 */         mHEX_DIGIT(false);
/* 1265 */         mHEX_DIGIT(false); break;
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/* 1270 */         matchRange('0', '3');
/*      */         
/* 1272 */         if (LA(1) >= '0' && LA(1) <= '7' && _tokenSet_0.member(LA(2))) {
/* 1273 */           matchRange('0', '7');
/*      */           
/* 1275 */           if (LA(1) >= '0' && LA(1) <= '7' && _tokenSet_0.member(LA(2))) {
/* 1276 */             matchRange('0', '7'); break;
/*      */           } 
/* 1278 */           if (_tokenSet_0.member(LA(1))) {
/*      */             break;
/*      */           }
/* 1281 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1286 */         if (_tokenSet_0.member(LA(1))) {
/*      */           break;
/*      */         }
/* 1289 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/* 1297 */         matchRange('4', '7');
/*      */         
/* 1299 */         if (LA(1) >= '0' && LA(1) <= '7' && _tokenSet_0.member(LA(2))) {
/* 1300 */           matchRange('0', '7'); break;
/*      */         } 
/* 1302 */         if (_tokenSet_0.member(LA(1))) {
/*      */           break;
/*      */         }
/* 1305 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1313 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1317 */     if (paramBoolean && token == null && c != -1) {
/* 1318 */       token = makeToken(c);
/* 1319 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1321 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTRING_LITERAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1325 */     Token token = null; int i = this.text.length();
/* 1326 */     char c = '';
/*      */ 
/*      */     
/* 1329 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/* 1333 */       while (LA(1) == '\\') {
/* 1334 */         mESC(false);
/*      */       }
/* 1336 */       if (_tokenSet_3.member(LA(1))) {
/*      */         
/* 1338 */         match(_tokenSet_3);
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1347 */     match('"');
/* 1348 */     if (paramBoolean && token == null && c != -1) {
/* 1349 */       token = makeToken(c);
/* 1350 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1352 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mHEX_DIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1356 */     Token token = null; int i = this.text.length();
/* 1357 */     char c = '';
/*      */ 
/*      */ 
/*      */     
/* 1361 */     switch (LA(1)) { case '0': case '1': case '2': case '3': case '4': case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1366 */         matchRange('0', '9'); break;
/*      */       case 'A': case 'B':
/*      */       case 'C':
/*      */       case 'D':
/*      */       case 'E':
/*      */       case 'F':
/* 1372 */         matchRange('A', 'F'); break;
/*      */       case 'a': case 'b':
/*      */       case 'c':
/*      */       case 'd':
/*      */       case 'e':
/*      */       case 'f':
/* 1378 */         matchRange('a', 'f');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1383 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/* 1387 */     if (paramBoolean && token == null && c != -1) {
/* 1388 */       token = makeToken(c);
/* 1389 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1391 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mIDENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1395 */     Token token = null; int j = this.text.length();
/* 1396 */     int i = 63;
/*      */ 
/*      */ 
/*      */     
/* 1400 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1409 */         matchRange('a', 'z'); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */       case 'R':
/*      */       case 'S':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       case 'Z':
/* 1420 */         matchRange('A', 'Z');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '_':
/* 1425 */         match('_');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '$':
/* 1430 */         match('$');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1435 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1442 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/* 1451 */           matchRange('a', 'z'); continue;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */         case 'R':
/*      */         case 'S':
/*      */         case 'T':
/*      */         case 'U':
/*      */         case 'V':
/*      */         case 'W':
/*      */         case 'X':
/*      */         case 'Y':
/*      */         case 'Z':
/* 1462 */           matchRange('A', 'Z');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '_':
/* 1467 */           match('_'); continue;
/*      */         case '0': case '1': case '2': case '3': case '4':
/*      */         case '5':
/*      */         case '6':
/*      */         case '7':
/*      */         case '8':
/*      */         case '9':
/* 1474 */           matchRange('0', '9');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '$':
/* 1479 */           match('$');
/*      */           continue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/* 1489 */     i = testLiteralsTable(i);
/* 1490 */     if (paramBoolean && token == null && i != -1) {
/* 1491 */       token = makeToken(i);
/* 1492 */       token.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/* 1494 */     this._returnToken = token;
/*      */   }
/*      */   public final void mNUM_INT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     byte b;
/* 1498 */     Token token1 = null; int i = this.text.length();
/* 1499 */     char c = '';
/*      */     
/* 1501 */     Token token2 = null;
/* 1502 */     Token token3 = null;
/* 1503 */     Token token4 = null;
/* 1504 */     Token token5 = null;
/* 1505 */     Token token6 = null;
/* 1506 */     boolean bool1 = false, bool2 = false; Token token7 = null;
/*      */     
/* 1508 */     switch (LA(1)) {
/*      */       
/*      */       case '.':
/* 1511 */         match('.');
/* 1512 */         if (this.inputState.guessing == 0) {
/* 1513 */           c = '@';
/*      */         }
/*      */         
/* 1516 */         if (LA(1) >= '0' && LA(1) <= '9') {
/*      */           
/* 1518 */           byte b1 = 0;
/*      */           
/*      */           while (true) {
/* 1521 */             if (LA(1) >= '0' && LA(1) <= '9') {
/* 1522 */               matchRange('0', '9');
/*      */             } else {
/*      */               
/* 1525 */               if (b1 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */             
/* 1528 */             b1++;
/*      */           } 
/*      */ 
/*      */           
/* 1532 */           if (LA(1) == 'E' || LA(1) == 'e') {
/* 1533 */             mEXPONENT(false);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1540 */           if (LA(1) == 'D' || LA(1) == 'F' || LA(1) == 'd' || LA(1) == 'f') {
/* 1541 */             mFLOAT_SUFFIX(true);
/* 1542 */             token2 = this._returnToken;
/* 1543 */             if (this.inputState.guessing == 0) {
/* 1544 */               token7 = token2;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1551 */           if (this.inputState.guessing == 0) {
/*      */             
/* 1553 */             if (token7 != null && token7.getText().toUpperCase().indexOf('F') >= 0) {
/* 1554 */               c = '';
/*      */               break;
/*      */             } 
/* 1557 */             c = '';
/*      */           } 
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1573 */         switch (LA(1)) {
/*      */           
/*      */           case '0':
/* 1576 */             match('0');
/* 1577 */             if (this.inputState.guessing == 0) {
/* 1578 */               bool1 = true;
/*      */             }
/*      */             
/* 1581 */             if (LA(1) == 'X' || LA(1) == 'x') {
/*      */               
/* 1583 */               switch (LA(1)) {
/*      */                 
/*      */                 case 'x':
/* 1586 */                   match('x');
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 'X':
/* 1591 */                   match('X');
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 default:
/* 1596 */                   throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */               } 
/*      */ 
/*      */               
/* 1600 */               if (this.inputState.guessing == 0) {
/* 1601 */                 bool2 = true;
/*      */               }
/*      */               
/* 1604 */               byte b1 = 0;
/*      */               
/*      */               while (true) {
/* 1607 */                 if (_tokenSet_4.member(LA(1))) {
/* 1608 */                   mHEX_DIGIT(false);
/*      */                 } else {
/*      */                   
/* 1611 */                   if (b1 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */                 } 
/*      */                 
/* 1614 */                 b1++;
/*      */               } 
/*      */               
/*      */               break;
/*      */             } 
/* 1619 */             b = 0;
/* 1620 */             if (LA(1) >= '0' && LA(1) <= '9') {
/* 1621 */               int j = mark();
/* 1622 */               b = 1;
/* 1623 */               this.inputState.guessing++;
/*      */ 
/*      */               
/*      */               try {
/* 1627 */                 byte b1 = 0;
/*      */                 
/*      */                 while (true) {
/* 1630 */                   if (LA(1) >= '0' && LA(1) <= '9') {
/* 1631 */                     matchRange('0', '9');
/*      */                   } else {
/*      */                     
/* 1634 */                     if (b1 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */                   } 
/*      */                   
/* 1637 */                   b1++;
/*      */                 } 
/*      */ 
/*      */                 
/* 1641 */                 switch (LA(1)) {
/*      */                   
/*      */                   case '.':
/* 1644 */                     match('.');
/*      */                     break;
/*      */                   
/*      */                   case 'E':
/*      */                   case 'e':
/* 1649 */                     mEXPONENT(false); break;
/*      */                   case 'D':
/*      */                   case 'F':
/*      */                   case 'd':
/*      */                   case 'f':
/* 1654 */                     mFLOAT_SUFFIX(false);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 1659 */                     throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1665 */               } catch (RecognitionException recognitionException) {
/* 1666 */                 b = 0;
/*      */               } 
/* 1668 */               rewind(j);
/* 1669 */               this.inputState.guessing--;
/*      */             } 
/* 1671 */             if (b) {
/*      */               
/* 1673 */               byte b1 = 0;
/*      */               
/*      */               while (true) {
/* 1676 */                 if (LA(1) >= '0' && LA(1) <= '9') {
/* 1677 */                   matchRange('0', '9');
/*      */                 } else {
/*      */                   
/* 1680 */                   if (b1 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */                 } 
/*      */                 
/* 1683 */                 b1++;
/*      */               } 
/*      */               break;
/*      */             } 
/* 1687 */             if (LA(1) >= '0' && LA(1) <= '7') {
/*      */               
/* 1689 */               byte b1 = 0;
/*      */               
/*      */               while (true) {
/* 1692 */                 if (LA(1) >= '0' && LA(1) <= '7') {
/* 1693 */                   matchRange('0', '7');
/*      */                 } else {
/*      */                   
/* 1696 */                   if (b1 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */                 } 
/*      */                 
/* 1699 */                 b1++;
/*      */               } 
/*      */             } 
/*      */             break;
/*      */ 
/*      */           
/*      */           case '1':
/*      */           case '2':
/*      */           case '3':
/*      */           case '4':
/*      */           case '5':
/*      */           case '6':
/*      */           case '7':
/*      */           case '8':
/*      */           case '9':
/* 1714 */             matchRange('1', '9');
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1719 */             while (LA(1) >= '0' && LA(1) <= '9') {
/* 1720 */               matchRange('0', '9');
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1728 */             if (this.inputState.guessing == 0) {
/* 1729 */               bool1 = true;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1735 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1740 */         if ((LA(1) == '.' || LA(1) == 'P' || LA(1) == 'p') && _tokenSet_5.member(LA(2)) && bool2) {
/*      */           
/* 1742 */           switch (LA(1)) {
/*      */             
/*      */             case '.':
/* 1745 */               match('.');
/*      */ 
/*      */ 
/*      */               
/* 1749 */               while (_tokenSet_4.member(LA(1))) {
/* 1750 */                 mHEX_DIGIT(false);
/*      */               }
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 'P':
/*      */             case 'p':
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             default:
/* 1766 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1771 */           switch (LA(1)) {
/*      */             
/*      */             case 'p':
/* 1774 */               match('p');
/*      */               break;
/*      */ 
/*      */             
/*      */             case 'P':
/* 1779 */               match('P');
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1784 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1789 */           switch (LA(1)) {
/*      */             
/*      */             case '+':
/* 1792 */               match('+');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '-':
/* 1797 */               match('-'); break;
/*      */             case '0': case '1': case '2':
/*      */             case '3':
/*      */             case '4':
/*      */             case '5':
/*      */             case '6':
/*      */             case '7':
/*      */             case '8':
/*      */             case '9':
/*      */               break;
/*      */             default:
/* 1808 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1813 */           b = 0;
/*      */           
/*      */           while (true) {
/* 1816 */             if (LA(1) >= '0' && LA(1) <= '9') {
/* 1817 */               matchRange('0', '9');
/*      */             } else {
/*      */               
/* 1820 */               if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */             
/* 1823 */             b++;
/*      */           } 
/*      */ 
/*      */           
/* 1827 */           if (LA(1) == 'D' || LA(1) == 'F' || LA(1) == 'd' || LA(1) == 'f') {
/* 1828 */             mFLOAT_SUFFIX(true);
/* 1829 */             token3 = this._returnToken;
/* 1830 */             if (this.inputState.guessing == 0) {
/* 1831 */               token7 = token3;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1838 */           if (this.inputState.guessing == 0) {
/*      */             
/* 1840 */             if (token7 != null && token7.getText().toUpperCase().indexOf('F') >= 0) {
/* 1841 */               c = ''; break;
/*      */             } 
/* 1843 */             c = '';
/*      */           } 
/*      */           
/*      */           break;
/*      */         } 
/* 1848 */         if (LA(1) == 'L' || LA(1) == 'l') {
/*      */           
/* 1850 */           switch (LA(1)) {
/*      */             
/*      */             case 'l':
/* 1853 */               match('l');
/*      */               break;
/*      */ 
/*      */             
/*      */             case 'L':
/* 1858 */               match('L');
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1863 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */ 
/*      */           
/* 1867 */           if (this.inputState.guessing == 0)
/* 1868 */             c = ''; 
/*      */           break;
/*      */         } 
/* 1871 */         if ((LA(1) == '.' || LA(1) == 'D' || LA(1) == 'E' || LA(1) == 'F' || LA(1) == 'd' || LA(1) == 'e' || LA(1) == 'f') && bool1) {
/*      */           
/* 1873 */           switch (LA(1)) {
/*      */             
/*      */             case '.':
/* 1876 */               match('.');
/*      */ 
/*      */ 
/*      */               
/* 1880 */               while (LA(1) >= '0' && LA(1) <= '9') {
/* 1881 */                 matchRange('0', '9');
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1890 */               if (LA(1) == 'E' || LA(1) == 'e') {
/* 1891 */                 mEXPONENT(false);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1898 */               if (LA(1) == 'D' || LA(1) == 'F' || LA(1) == 'd' || LA(1) == 'f') {
/* 1899 */                 mFLOAT_SUFFIX(true);
/* 1900 */                 token4 = this._returnToken;
/* 1901 */                 if (this.inputState.guessing == 0) {
/* 1902 */                   token7 = token4;
/*      */                 }
/*      */               } 
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 'E':
/*      */             case 'e':
/* 1913 */               mEXPONENT(false);
/*      */               
/* 1915 */               if (LA(1) == 'D' || LA(1) == 'F' || LA(1) == 'd' || LA(1) == 'f') {
/* 1916 */                 mFLOAT_SUFFIX(true);
/* 1917 */                 token5 = this._returnToken;
/* 1918 */                 if (this.inputState.guessing == 0) {
/* 1919 */                   token7 = token5;
/*      */                 }
/*      */               } 
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 'D':
/*      */             case 'F':
/*      */             case 'd':
/*      */             case 'f':
/* 1930 */               mFLOAT_SUFFIX(true);
/* 1931 */               token6 = this._returnToken;
/* 1932 */               if (this.inputState.guessing == 0) {
/* 1933 */                 token7 = token6;
/*      */               }
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1939 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */ 
/*      */           
/* 1943 */           if (this.inputState.guessing == 0) {
/*      */             
/* 1945 */             if (token7 != null && token7.getText().toUpperCase().indexOf('F') >= 0) {
/* 1946 */               c = ''; break;
/*      */             } 
/* 1948 */             c = '';
/*      */           } 
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1961 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1964 */     if (paramBoolean && token1 == null && c != -1) {
/* 1965 */       token1 = makeToken(c);
/* 1966 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1968 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mEXPONENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1972 */     Token token = null; int i = this.text.length();
/* 1973 */     char c = '';
/*      */ 
/*      */ 
/*      */     
/* 1977 */     switch (LA(1)) {
/*      */       
/*      */       case 'e':
/* 1980 */         match('e');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'E':
/* 1985 */         match('E');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1990 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1995 */     switch (LA(1)) {
/*      */       
/*      */       case '+':
/* 1998 */         mPLUS(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '-':
/* 2003 */         mMINUS(false); break;
/*      */       case '0': case '1': case '2':
/*      */       case '3':
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/*      */         break;
/*      */       default:
/* 2014 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2019 */     byte b = 0;
/*      */     
/*      */     while (true) {
/* 2022 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 2023 */         matchRange('0', '9');
/*      */       } else {
/*      */         
/* 2026 */         if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 2029 */       b++;
/*      */     } 
/*      */     
/* 2032 */     if (paramBoolean && token == null && c != -1) {
/* 2033 */       token = makeToken(c);
/* 2034 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2036 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mFLOAT_SUFFIX(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2040 */     Token token = null; int i = this.text.length();
/* 2041 */     char c = '';
/*      */ 
/*      */     
/* 2044 */     switch (LA(1)) {
/*      */       
/*      */       case 'f':
/* 2047 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'F':
/* 2052 */         match('F');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'd':
/* 2057 */         match('d');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'D':
/* 2062 */         match('D');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2067 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 2070 */     if (paramBoolean && token == null && c != -1) {
/* 2071 */       token = makeToken(c);
/* 2072 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2074 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 2079 */     long[] arrayOfLong = new long[1024];
/* 2080 */     arrayOfLong[0] = -9224L;
/* 2081 */     for (byte b = 1; b <= 'Ǿ'; ) { arrayOfLong[b] = -1L; b++; }
/* 2082 */      arrayOfLong[511] = Long.MAX_VALUE;
/* 2083 */     return arrayOfLong;
/*      */   }
/* 2085 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 2087 */     long[] arrayOfLong = new long[1024];
/* 2088 */     arrayOfLong[0] = -4398046520328L;
/* 2089 */     for (byte b = 1; b <= 'Ǿ'; ) { arrayOfLong[b] = -1L; b++; }
/* 2090 */      arrayOfLong[511] = Long.MAX_VALUE;
/* 2091 */     return arrayOfLong;
/*      */   }
/* 2093 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 2095 */     long[] arrayOfLong = new long[1024];
/* 2096 */     arrayOfLong[0] = -549755823112L;
/* 2097 */     arrayOfLong[1] = -268435457L;
/* 2098 */     for (byte b = 2; b <= 'Ǿ'; ) { arrayOfLong[b] = -1L; b++; }
/* 2099 */      arrayOfLong[511] = Long.MAX_VALUE;
/* 2100 */     return arrayOfLong;
/*      */   }
/* 2102 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 2104 */     long[] arrayOfLong = new long[1024];
/* 2105 */     arrayOfLong[0] = -17179878408L;
/* 2106 */     arrayOfLong[1] = -268435457L;
/* 2107 */     for (byte b = 2; b <= 'Ǿ'; ) { arrayOfLong[b] = -1L; b++; }
/* 2108 */      arrayOfLong[511] = Long.MAX_VALUE;
/* 2109 */     return arrayOfLong;
/*      */   }
/* 2111 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 2113 */     long[] arrayOfLong = new long[513];
/* 2114 */     arrayOfLong[0] = 287948901175001088L;
/* 2115 */     arrayOfLong[1] = 541165879422L;
/* 2116 */     return arrayOfLong;
/*      */   }
/* 2118 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 2120 */     long[] arrayOfLong = new long[513];
/* 2121 */     arrayOfLong[0] = 287992881640112128L;
/* 2122 */     arrayOfLong[1] = 282016142655614L;
/* 2123 */     return arrayOfLong;
/*      */   }
/* 2125 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jgram/JavaLexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */