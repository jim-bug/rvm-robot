/*      */ package com.jogamp.gluegen.jgram;
/*      */ 
/*      */ import antlr.ASTFactory;
/*      */ import antlr.ASTPair;
/*      */ import antlr.LLkParser;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.ParserSharedInputState;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenBuffer;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.ASTArray;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import java.util.HashSet;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JavaParser
/*      */   extends LLkParser
/*      */   implements JavaTokenTypes
/*      */ {
/*      */   public void clearParsedEnumNames() {
/*   32 */     this.enumNames.clear();
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getParsedEnumNames() {
/*   37 */     return this.enumNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParsedFunctionNames() {
/*   44 */     this.functionNames.clear();
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getParsedFunctionNames() {
/*   49 */     return this.functionNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParsedInnerInterfacesNames() {
/*   56 */     this.innerInterfacesNames.clear();
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getParsedInnerInterfacesNames() {
/*   61 */     return this.innerInterfacesNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParsedInnerClassesNames() {
/*   68 */     this.innerClassesNames.clear();
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getParsedInnerClassesNames() {
/*   73 */     return this.innerClassesNames;
/*      */   }
/*      */   
/*   76 */   private Set<String> functionNames = new HashSet<>();
/*      */   
/*   78 */   private Set<String> enumNames = new HashSet<>();
/*   79 */   private Set<String> innerInterfacesNames = new HashSet<>();
/*   80 */   private Set<String> innerClassesNames = new HashSet<>();
/*      */   
/*   82 */   private int blockDepth = 0;
/*      */   
/*      */   protected JavaParser(TokenBuffer paramTokenBuffer, int paramInt) {
/*   85 */     super(paramTokenBuffer, paramInt);
/*   86 */     this.tokenNames = _tokenNames;
/*   87 */     buildTokenTypeASTClassMap();
/*   88 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public JavaParser(TokenBuffer paramTokenBuffer) {
/*   92 */     this(paramTokenBuffer, 2);
/*      */   }
/*      */   
/*      */   protected JavaParser(TokenStream paramTokenStream, int paramInt) {
/*   96 */     super(paramTokenStream, paramInt);
/*   97 */     this.tokenNames = _tokenNames;
/*   98 */     buildTokenTypeASTClassMap();
/*   99 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public JavaParser(TokenStream paramTokenStream) {
/*  103 */     this(paramTokenStream, 2);
/*      */   }
/*      */   
/*      */   public JavaParser(ParserSharedInputState paramParserSharedInputState) {
/*  107 */     super(paramParserSharedInputState, 2);
/*  108 */     this.tokenNames = _tokenNames;
/*  109 */     buildTokenTypeASTClassMap();
/*  110 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */ 
/*      */   
/*      */   public final void compilationUnit() throws RecognitionException, TokenStreamException {
/*  115 */     this.returnAST = null;
/*  116 */     ASTPair aSTPair = new ASTPair();
/*  117 */     AST aST = null;
/*      */ 
/*      */     
/*  120 */     switch (LA(1)) {
/*      */       
/*      */       case 44:
/*  123 */         packageDefinition();
/*  124 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 45:
/*      */       case 46:
/*      */       case 66:
/*      */       case 67:
/*      */       case 68:
/*      */       case 69:
/*      */       case 70:
/*      */       case 71:
/*      */       case 72:
/*      */       case 73:
/*      */       case 74:
/*      */       case 75:
/*      */       case 76:
/*      */       case 103:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  150 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  157 */     while (LA(1) == 46) {
/*  158 */       importDefinition();
/*  159 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  170 */     while (_tokenSet_0.member(LA(1))) {
/*  171 */       typeDefinition();
/*  172 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  180 */     match(1);
/*  181 */     aST = aSTPair.root;
/*  182 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void packageDefinition() throws RecognitionException, TokenStreamException {
/*  187 */     this.returnAST = null;
/*  188 */     ASTPair aSTPair = new ASTPair();
/*  189 */     AST aST1 = null;
/*  190 */     Token token = null;
/*  191 */     AST aST2 = null;
/*      */     
/*      */     try {
/*  194 */       token = LT(1);
/*  195 */       aST2 = this.astFactory.create(token);
/*  196 */       this.astFactory.makeASTRoot(aSTPair, aST2);
/*  197 */       match(44);
/*  198 */       if (this.inputState.guessing == 0) {
/*  199 */         aST2.setType(16);
/*      */       }
/*  201 */       identifier();
/*  202 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  203 */       match(45);
/*  204 */       aST1 = aSTPair.root;
/*      */     }
/*  206 */     catch (RecognitionException recognitionException) {
/*  207 */       if (this.inputState.guessing == 0) {
/*  208 */         reportError(recognitionException);
/*  209 */         recover(recognitionException, _tokenSet_1);
/*      */       } else {
/*  211 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  214 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void importDefinition() throws RecognitionException, TokenStreamException {
/*  219 */     this.returnAST = null;
/*  220 */     ASTPair aSTPair = new ASTPair();
/*  221 */     AST aST1 = null;
/*  222 */     Token token = null;
/*  223 */     AST aST2 = null;
/*      */     
/*      */     try {
/*  226 */       token = LT(1);
/*  227 */       aST2 = this.astFactory.create(token);
/*  228 */       this.astFactory.makeASTRoot(aSTPair, aST2);
/*  229 */       match(46);
/*  230 */       if (this.inputState.guessing == 0) {
/*  231 */         aST2.setType(30);
/*      */       }
/*  233 */       identifierStar();
/*  234 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  235 */       match(45);
/*  236 */       aST1 = aSTPair.root;
/*      */     }
/*  238 */     catch (RecognitionException recognitionException) {
/*  239 */       if (this.inputState.guessing == 0) {
/*  240 */         reportError(recognitionException);
/*  241 */         recover(recognitionException, _tokenSet_1);
/*      */       } else {
/*  243 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  246 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typeDefinition() throws RecognitionException, TokenStreamException {
/*  251 */     this.returnAST = null;
/*  252 */     ASTPair aSTPair = new ASTPair();
/*  253 */     AST aST1 = null;
/*  254 */     AST aST2 = null;
/*  255 */     AST aST3 = null;
/*  256 */     AST aST4 = null;
/*      */     
/*      */     try {
/*  259 */       switch (LA(1)) {
/*      */         
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 103:
/*  276 */           annotations();
/*  277 */           aST2 = this.returnAST;
/*  278 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  279 */           modifiers();
/*  280 */           aST3 = this.returnAST;
/*  281 */           annotations();
/*  282 */           aST4 = this.returnAST;
/*  283 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           
/*  285 */           switch (LA(1)) {
/*      */             
/*      */             case 75:
/*  288 */               classDefinition(aST2, aST3, aST4);
/*  289 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 76:
/*  294 */               interfaceDefinition(aST2, aST3, aST4);
/*  295 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/*  300 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/*  304 */           aST1 = aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 45:
/*  309 */           match(45);
/*  310 */           aST1 = aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  315 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/*  319 */     } catch (RecognitionException recognitionException) {
/*  320 */       if (this.inputState.guessing == 0) {
/*  321 */         reportError(recognitionException);
/*  322 */         recover(recognitionException, _tokenSet_2);
/*      */       } else {
/*  324 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  327 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void identifier() throws RecognitionException, TokenStreamException {
/*  332 */     this.returnAST = null;
/*  333 */     ASTPair aSTPair = new ASTPair();
/*  334 */     AST aST1 = null;
/*      */     
/*  336 */     AST aST2 = null;
/*  337 */     aST2 = this.astFactory.create(LT(1));
/*  338 */     this.astFactory.addASTChild(aSTPair, aST2);
/*  339 */     match(63);
/*      */ 
/*      */ 
/*      */     
/*  343 */     while (LA(1) == 64) {
/*  344 */       AST aST3 = null;
/*  345 */       aST3 = this.astFactory.create(LT(1));
/*  346 */       this.astFactory.makeASTRoot(aSTPair, aST3);
/*  347 */       match(64);
/*  348 */       AST aST4 = null;
/*  349 */       aST4 = this.astFactory.create(LT(1));
/*  350 */       this.astFactory.addASTChild(aSTPair, aST4);
/*  351 */       match(63);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  359 */     aST1 = aSTPair.root;
/*  360 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void identifierStar() throws RecognitionException, TokenStreamException {
/*      */     AST aST3, aST4;
/*  365 */     this.returnAST = null;
/*  366 */     ASTPair aSTPair = new ASTPair();
/*  367 */     AST aST1 = null;
/*      */     
/*  369 */     AST aST2 = null;
/*  370 */     aST2 = this.astFactory.create(LT(1));
/*  371 */     this.astFactory.addASTChild(aSTPair, aST2);
/*  372 */     match(63);
/*      */ 
/*      */ 
/*      */     
/*  376 */     while (LA(1) == 64 && LA(2) == 63) {
/*  377 */       AST aST5 = null;
/*  378 */       aST5 = this.astFactory.create(LT(1));
/*  379 */       this.astFactory.makeASTRoot(aSTPair, aST5);
/*  380 */       match(64);
/*  381 */       AST aST6 = null;
/*  382 */       aST6 = this.astFactory.create(LT(1));
/*  383 */       this.astFactory.addASTChild(aSTPair, aST6);
/*  384 */       match(63);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  393 */     switch (LA(1)) {
/*      */       
/*      */       case 64:
/*  396 */         aST3 = null;
/*  397 */         aST3 = this.astFactory.create(LT(1));
/*  398 */         this.astFactory.makeASTRoot(aSTPair, aST3);
/*  399 */         match(64);
/*  400 */         aST4 = null;
/*  401 */         aST4 = this.astFactory.create(LT(1));
/*  402 */         this.astFactory.addASTChild(aSTPair, aST4);
/*  403 */         match(65);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 45:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  412 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/*  416 */     aST1 = aSTPair.root;
/*  417 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void annotations() throws RecognitionException, TokenStreamException {
/*  422 */     this.returnAST = null;
/*  423 */     ASTPair aSTPair = new ASTPair();
/*  424 */     AST aST = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  429 */     while (LA(1) == 103 && LA(2) >= 54 && LA(2) <= 63) {
/*  430 */       annotation();
/*  431 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  439 */     aST = aSTPair.root;
/*  440 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void modifiers() throws RecognitionException, TokenStreamException {
/*  445 */     this.returnAST = null;
/*  446 */     ASTPair aSTPair = new ASTPair();
/*  447 */     AST aST = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  452 */     while (_tokenSet_3.member(LA(1))) {
/*  453 */       modifier();
/*  454 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  462 */     if (this.inputState.guessing == 0) {
/*  463 */       aST = aSTPair.root;
/*  464 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(5, "MODIFIERS")).add(aST));
/*  465 */       aSTPair.root = aST;
/*  466 */       aSTPair
/*  467 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/*  468 */       aSTPair.advanceChildToEnd();
/*      */     } 
/*  470 */     aST = aSTPair.root;
/*  471 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void classDefinition(AST paramAST1, AST paramAST2, AST paramAST3) throws RecognitionException, TokenStreamException {
/*  478 */     this.returnAST = null;
/*  479 */     ASTPair aSTPair = new ASTPair();
/*  480 */     AST aST1 = null;
/*  481 */     Token token = null;
/*  482 */     AST aST2 = null;
/*  483 */     AST aST3 = null;
/*  484 */     AST aST4 = null;
/*  485 */     AST aST5 = null;
/*      */     
/*  487 */     match(75);
/*  488 */     token = LT(1);
/*  489 */     aST2 = this.astFactory.create(token);
/*  490 */     match(63);
/*  491 */     superClassClause();
/*  492 */     aST3 = this.returnAST;
/*  493 */     implementsClause();
/*  494 */     aST4 = this.returnAST;
/*  495 */     classBlock();
/*  496 */     aST5 = this.returnAST;
/*  497 */     if (this.inputState.guessing == 0) {
/*  498 */       aST1 = aSTPair.root;
/*  499 */       aST1 = this.astFactory.make((new ASTArray(8)).add(this.astFactory.create(14, "CLASS_DEF")).add(paramAST1).add(paramAST2).add(paramAST3).add(aST2).add(aST3).add(aST4).add(aST5));
/*  500 */       if (this.blockDepth == 1)
/*  501 */         this.innerClassesNames.add(token.getText()); 
/*  502 */       aSTPair.root = aST1;
/*  503 */       aSTPair
/*  504 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/*  505 */       aSTPair.advanceChildToEnd();
/*      */     } 
/*  507 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void interfaceDefinition(AST paramAST1, AST paramAST2, AST paramAST3) throws RecognitionException, TokenStreamException {
/*  514 */     this.returnAST = null;
/*  515 */     ASTPair aSTPair = new ASTPair();
/*  516 */     AST aST1 = null;
/*  517 */     Token token = null;
/*  518 */     AST aST2 = null;
/*  519 */     AST aST3 = null;
/*  520 */     AST aST4 = null;
/*      */     
/*  522 */     match(76);
/*  523 */     token = LT(1);
/*  524 */     aST2 = this.astFactory.create(token);
/*  525 */     match(63);
/*  526 */     interfaceExtends();
/*  527 */     aST3 = this.returnAST;
/*  528 */     classBlock();
/*  529 */     aST4 = this.returnAST;
/*  530 */     if (this.inputState.guessing == 0) {
/*  531 */       aST1 = aSTPair.root;
/*  532 */       aST1 = this.astFactory.make((new ASTArray(7)).add(this.astFactory.create(15, "INTERFACE_DEF")).add(paramAST1).add(paramAST2).add(paramAST3).add(aST2).add(aST3).add(aST4));
/*  533 */       if (this.blockDepth == 1)
/*  534 */         this.innerInterfacesNames.add(token.getText()); 
/*  535 */       aSTPair.root = aST1;
/*  536 */       aSTPair
/*  537 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/*  538 */       aSTPair.advanceChildToEnd();
/*      */     } 
/*  540 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void declaration() throws RecognitionException, TokenStreamException {
/*  548 */     this.returnAST = null;
/*  549 */     ASTPair aSTPair = new ASTPair();
/*  550 */     AST aST1 = null;
/*  551 */     AST aST2 = null;
/*  552 */     AST aST3 = null;
/*  553 */     AST aST4 = null;
/*  554 */     AST aST5 = null;
/*  555 */     AST aST6 = null;
/*      */     
/*  557 */     annotations();
/*  558 */     aST2 = this.returnAST;
/*  559 */     modifiers();
/*  560 */     aST3 = this.returnAST;
/*  561 */     annotations();
/*  562 */     aST4 = this.returnAST;
/*  563 */     typeSpec(false);
/*  564 */     aST5 = this.returnAST;
/*  565 */     variableDefinitions(aST2, aST3, aST4, aST5);
/*  566 */     aST6 = this.returnAST;
/*  567 */     if (this.inputState.guessing == 0) {
/*  568 */       aST1 = aSTPair.root;
/*  569 */       aST1 = aST6;
/*  570 */       aSTPair.root = aST1;
/*  571 */       aSTPair
/*  572 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/*  573 */       aSTPair.advanceChildToEnd();
/*      */     } 
/*  575 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void typeSpec(boolean paramBoolean) throws RecognitionException, TokenStreamException {
/*  582 */     this.returnAST = null;
/*  583 */     ASTPair aSTPair = new ASTPair();
/*  584 */     AST aST = null;
/*      */     
/*  586 */     switch (LA(1)) {
/*      */       
/*      */       case 63:
/*  589 */         classTypeSpec(paramBoolean);
/*  590 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  591 */         aST = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*  604 */         builtInTypeSpec(paramBoolean);
/*  605 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  606 */         aST = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  611 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/*  614 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void variableDefinitions(AST paramAST1, AST paramAST2, AST paramAST3, AST paramAST4) throws RecognitionException, TokenStreamException {
/*  621 */     this.returnAST = null;
/*  622 */     ASTPair aSTPair = new ASTPair();
/*  623 */     AST aST = null;
/*      */     
/*  625 */     variableDeclarator(getASTFactory().dupTree(paramAST1), 
/*  626 */         getASTFactory().dupTree(paramAST2), 
/*  627 */         getASTFactory().dupTree(paramAST3), 
/*  628 */         getASTFactory().dupTree(paramAST4));
/*  629 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/*  633 */     while (LA(1) == 79) {
/*  634 */       match(79);
/*  635 */       variableDeclarator(getASTFactory().dupTree(paramAST1), 
/*  636 */           getASTFactory().dupTree(paramAST2), 
/*  637 */           getASTFactory().dupTree(paramAST3), 
/*  638 */           getASTFactory().dupTree(paramAST4));
/*  639 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  647 */     aST = aSTPair.root;
/*  648 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void classTypeSpec(boolean paramBoolean) throws RecognitionException, TokenStreamException {
/*      */     AST aST3, aST4, aST5;
/*  655 */     this.returnAST = null;
/*  656 */     ASTPair aSTPair = new ASTPair();
/*  657 */     AST aST1 = null;
/*  658 */     Token token = null;
/*  659 */     AST aST2 = null;
/*      */     
/*  661 */     identifier();
/*  662 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     
/*  664 */     switch (LA(1)) {
/*      */       
/*      */       case 47:
/*  667 */         aST3 = null;
/*  668 */         aST3 = this.astFactory.create(LT(1));
/*  669 */         this.astFactory.addASTChild(aSTPair, aST3);
/*  670 */         match(47);
/*      */         
/*  672 */         switch (LA(1)) {
/*      */           
/*      */           case 63:
/*  675 */             classTypeSpec(false);
/*  676 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 48:
/*  681 */             aST4 = null;
/*  682 */             aST4 = this.astFactory.create(LT(1));
/*  683 */             this.astFactory.addASTChild(aSTPair, aST4);
/*  684 */             match(48);
/*      */             
/*  686 */             switch (LA(1)) {
/*      */               
/*      */               case 49:
/*  689 */                 aST5 = null;
/*  690 */                 aST5 = this.astFactory.create(LT(1));
/*  691 */                 this.astFactory.addASTChild(aSTPair, aST5);
/*  692 */                 match(49);
/*  693 */                 classTypeSpec(false);
/*  694 */                 this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */                 
/*  698 */                 while (LA(1) == 50) {
/*  699 */                   AST aST = null;
/*  700 */                   aST = this.astFactory.create(LT(1));
/*  701 */                   this.astFactory.addASTChild(aSTPair, aST);
/*  702 */                   match(50);
/*  703 */                   classTypeSpec(false);
/*  704 */                   this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                 } 
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 51:
/*      */                 break;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  720 */             throw new NoViableAltException(LT(1), getFilename());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  728 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/*  732 */         aST4 = null;
/*  733 */         aST4 = this.astFactory.create(LT(1));
/*  734 */         this.astFactory.addASTChild(aSTPair, aST4);
/*  735 */         match(51);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 45:
/*      */       case 48:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 66:
/*      */       case 67:
/*      */       case 68:
/*      */       case 69:
/*      */       case 70:
/*      */       case 71:
/*      */       case 72:
/*      */       case 73:
/*      */       case 74:
/*      */       case 75:
/*      */       case 76:
/*      */       case 78:
/*      */       case 79:
/*      */       case 81:
/*      */       case 82:
/*      */       case 85:
/*      */       case 87:
/*      */       case 103:
/*      */       case 104:
/*      */       case 105:
/*      */       case 106:
/*      */       case 107:
/*      */       case 108:
/*      */       case 109:
/*      */       case 110:
/*      */       case 111:
/*      */       case 112:
/*      */       case 113:
/*      */       case 114:
/*      */       case 115:
/*      */       case 116:
/*      */       case 117:
/*      */       case 118:
/*      */       case 119:
/*      */       case 120:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  797 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  804 */     while (LA(1) == 52) {
/*  805 */       token = LT(1);
/*  806 */       aST2 = this.astFactory.create(token);
/*  807 */       this.astFactory.makeASTRoot(aSTPair, aST2);
/*  808 */       match(52);
/*  809 */       if (this.inputState.guessing == 0) {
/*  810 */         aST2.setType(17);
/*      */       }
/*  812 */       match(53);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  820 */     if (this.inputState.guessing == 0) {
/*  821 */       aST1 = aSTPair.root;
/*      */       
/*  823 */       if (paramBoolean) {
/*  824 */         aST1 = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(13, "TYPE")).add(aST1));
/*      */       }
/*      */       
/*  827 */       aSTPair.root = aST1;
/*  828 */       aSTPair
/*  829 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/*  830 */       aSTPair.advanceChildToEnd();
/*      */     } 
/*  832 */     aST1 = aSTPair.root;
/*  833 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void builtInTypeSpec(boolean paramBoolean) throws RecognitionException, TokenStreamException {
/*  840 */     this.returnAST = null;
/*  841 */     ASTPair aSTPair = new ASTPair();
/*  842 */     AST aST1 = null;
/*  843 */     Token token = null;
/*  844 */     AST aST2 = null;
/*      */     
/*  846 */     builtInType();
/*  847 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/*  851 */     while (LA(1) == 52) {
/*  852 */       token = LT(1);
/*  853 */       aST2 = this.astFactory.create(token);
/*  854 */       this.astFactory.makeASTRoot(aSTPair, aST2);
/*  855 */       match(52);
/*  856 */       if (this.inputState.guessing == 0) {
/*  857 */         aST2.setType(17);
/*      */       }
/*  859 */       match(53);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  867 */     if (this.inputState.guessing == 0) {
/*  868 */       aST1 = aSTPair.root;
/*      */       
/*  870 */       if (paramBoolean) {
/*  871 */         aST1 = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(13, "TYPE")).add(aST1));
/*      */       }
/*      */       
/*  874 */       aSTPair.root = aST1;
/*  875 */       aSTPair
/*  876 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/*  877 */       aSTPair.advanceChildToEnd();
/*      */     } 
/*  879 */     aST1 = aSTPair.root;
/*  880 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void builtInType() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/*  885 */     this.returnAST = null;
/*  886 */     ASTPair aSTPair = new ASTPair();
/*  887 */     AST aST1 = null;
/*      */     
/*  889 */     switch (LA(1)) {
/*      */       
/*      */       case 54:
/*  892 */         aST2 = null;
/*  893 */         aST2 = this.astFactory.create(LT(1));
/*  894 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  895 */         match(54);
/*  896 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 55:
/*  901 */         aST2 = null;
/*  902 */         aST2 = this.astFactory.create(LT(1));
/*  903 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  904 */         match(55);
/*  905 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 56:
/*  910 */         aST2 = null;
/*  911 */         aST2 = this.astFactory.create(LT(1));
/*  912 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  913 */         match(56);
/*  914 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 57:
/*  919 */         aST2 = null;
/*  920 */         aST2 = this.astFactory.create(LT(1));
/*  921 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  922 */         match(57);
/*  923 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 58:
/*  928 */         aST2 = null;
/*  929 */         aST2 = this.astFactory.create(LT(1));
/*  930 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  931 */         match(58);
/*  932 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 59:
/*  937 */         aST2 = null;
/*  938 */         aST2 = this.astFactory.create(LT(1));
/*  939 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  940 */         match(59);
/*  941 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 60:
/*  946 */         aST2 = null;
/*  947 */         aST2 = this.astFactory.create(LT(1));
/*  948 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  949 */         match(60);
/*  950 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 61:
/*  955 */         aST2 = null;
/*  956 */         aST2 = this.astFactory.create(LT(1));
/*  957 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  958 */         match(61);
/*  959 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 62:
/*  964 */         aST2 = null;
/*  965 */         aST2 = this.astFactory.create(LT(1));
/*  966 */         this.astFactory.addASTChild(aSTPair, aST2);
/*  967 */         match(62);
/*  968 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  973 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/*  976 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void type() throws RecognitionException, TokenStreamException {
/*  981 */     this.returnAST = null;
/*  982 */     ASTPair aSTPair = new ASTPair();
/*  983 */     AST aST = null;
/*      */     
/*  985 */     switch (LA(1)) {
/*      */       
/*      */       case 63:
/*  988 */         identifier();
/*  989 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  990 */         aST = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/* 1003 */         builtInType();
/* 1004 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1005 */         aST = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1010 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 1013 */     this.returnAST = aST;
/*      */   }
/*      */   
/*      */   public final void modifier() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/* 1018 */     this.returnAST = null;
/* 1019 */     ASTPair aSTPair = new ASTPair();
/* 1020 */     AST aST1 = null;
/*      */     
/* 1022 */     switch (LA(1)) {
/*      */       
/*      */       case 66:
/* 1025 */         aST2 = null;
/* 1026 */         aST2 = this.astFactory.create(LT(1));
/* 1027 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1028 */         match(66);
/* 1029 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 67:
/* 1034 */         aST2 = null;
/* 1035 */         aST2 = this.astFactory.create(LT(1));
/* 1036 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1037 */         match(67);
/* 1038 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 68:
/* 1043 */         aST2 = null;
/* 1044 */         aST2 = this.astFactory.create(LT(1));
/* 1045 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1046 */         match(68);
/* 1047 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 69:
/* 1052 */         aST2 = null;
/* 1053 */         aST2 = this.astFactory.create(LT(1));
/* 1054 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1055 */         match(69);
/* 1056 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 70:
/* 1061 */         aST2 = null;
/* 1062 */         aST2 = this.astFactory.create(LT(1));
/* 1063 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1064 */         match(70);
/* 1065 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 39:
/* 1070 */         aST2 = null;
/* 1071 */         aST2 = this.astFactory.create(LT(1));
/* 1072 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1073 */         match(39);
/* 1074 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 40:
/* 1079 */         aST2 = null;
/* 1080 */         aST2 = this.astFactory.create(LT(1));
/* 1081 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1082 */         match(40);
/* 1083 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 71:
/* 1088 */         aST2 = null;
/* 1089 */         aST2 = this.astFactory.create(LT(1));
/* 1090 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1091 */         match(71);
/* 1092 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 72:
/* 1097 */         aST2 = null;
/* 1098 */         aST2 = this.astFactory.create(LT(1));
/* 1099 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1100 */         match(72);
/* 1101 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 73:
/* 1106 */         aST2 = null;
/* 1107 */         aST2 = this.astFactory.create(LT(1));
/* 1108 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1109 */         match(73);
/* 1110 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 74:
/* 1115 */         aST2 = null;
/* 1116 */         aST2 = this.astFactory.create(LT(1));
/* 1117 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1118 */         match(74);
/* 1119 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 41:
/* 1124 */         aST2 = null;
/* 1125 */         aST2 = this.astFactory.create(LT(1));
/* 1126 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 1127 */         match(41);
/* 1128 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1133 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 1136 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void superClassClause() throws RecognitionException, TokenStreamException {
/* 1141 */     this.returnAST = null;
/* 1142 */     ASTPair aSTPair = new ASTPair();
/* 1143 */     AST aST1 = null;
/* 1144 */     AST aST2 = null;
/*      */ 
/*      */     
/* 1147 */     switch (LA(1)) {
/*      */       
/*      */       case 49:
/* 1150 */         match(49);
/* 1151 */         identifier();
/* 1152 */         aST2 = this.returnAST;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 77:
/*      */       case 80:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1162 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 1166 */     if (this.inputState.guessing == 0) {
/* 1167 */       aST1 = aSTPair.root;
/* 1168 */       aST1 = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(18, "EXTENDS_CLAUSE")).add(aST2));
/* 1169 */       aSTPair.root = aST1;
/* 1170 */       aSTPair
/* 1171 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1172 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 1174 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void implementsClause() throws RecognitionException, TokenStreamException {
/* 1179 */     this.returnAST = null;
/* 1180 */     ASTPair aSTPair = new ASTPair();
/* 1181 */     AST aST1 = null;
/* 1182 */     Token token = null;
/* 1183 */     AST aST2 = null;
/*      */ 
/*      */     
/* 1186 */     switch (LA(1)) {
/*      */       
/*      */       case 80:
/* 1189 */         token = LT(1);
/* 1190 */         aST2 = this.astFactory.create(token);
/* 1191 */         match(80);
/* 1192 */         identifier();
/* 1193 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */         
/* 1197 */         while (LA(1) == 79) {
/* 1198 */           match(79);
/* 1199 */           identifier();
/* 1200 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 77:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1216 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 1220 */     if (this.inputState.guessing == 0) {
/* 1221 */       aST1 = aSTPair.root;
/* 1222 */       aST1 = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(19, "IMPLEMENTS_CLAUSE")).add(aST1));
/* 1223 */       aSTPair.root = aST1;
/* 1224 */       aSTPair
/* 1225 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1226 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 1228 */     aST1 = aSTPair.root;
/* 1229 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void classBlock() throws RecognitionException, TokenStreamException {
/* 1234 */     this.returnAST = null;
/* 1235 */     ASTPair aSTPair = new ASTPair();
/* 1236 */     AST aST = null;
/*      */     
/* 1238 */     match(77);
/* 1239 */     if (this.inputState.guessing == 0) {
/* 1240 */       this.blockDepth++;
/*      */     }
/*      */ 
/*      */     
/*      */     while (true) {
/* 1245 */       switch (LA(1)) {
/*      */         
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 62:
/*      */         case 63:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 103:
/* 1273 */           field();
/* 1274 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 45:
/* 1279 */           match(45);
/*      */           continue;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/* 1289 */     match(78);
/* 1290 */     if (this.inputState.guessing == 0) {
/* 1291 */       this.blockDepth--;
/*      */     }
/* 1293 */     if (this.inputState.guessing == 0) {
/* 1294 */       aST = aSTPair.root;
/* 1295 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(6, "OBJBLOCK")).add(aST));
/* 1296 */       aSTPair.root = aST;
/* 1297 */       aSTPair
/* 1298 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 1299 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 1301 */     aST = aSTPair.root;
/* 1302 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void interfaceExtends() throws RecognitionException, TokenStreamException {
/* 1307 */     this.returnAST = null;
/* 1308 */     ASTPair aSTPair = new ASTPair();
/* 1309 */     AST aST1 = null;
/* 1310 */     Token token = null;
/* 1311 */     AST aST2 = null;
/*      */ 
/*      */     
/* 1314 */     switch (LA(1)) {
/*      */       
/*      */       case 49:
/* 1317 */         token = LT(1);
/* 1318 */         aST2 = this.astFactory.create(token);
/* 1319 */         match(49);
/* 1320 */         identifier();
/* 1321 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */         
/* 1325 */         while (LA(1) == 79) {
/* 1326 */           match(79);
/* 1327 */           identifier();
/* 1328 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 77:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1344 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 1348 */     if (this.inputState.guessing == 0) {
/* 1349 */       aST1 = aSTPair.root;
/* 1350 */       aST1 = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(18, "EXTENDS_CLAUSE")).add(aST1));
/* 1351 */       aSTPair.root = aST1;
/* 1352 */       aSTPair
/* 1353 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1354 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 1356 */     aST1 = aSTPair.root;
/* 1357 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void field() throws RecognitionException, TokenStreamException {
/* 1362 */     this.returnAST = null;
/* 1363 */     ASTPair aSTPair = new ASTPair();
/* 1364 */     AST aST1 = null;
/* 1365 */     AST aST2 = null;
/* 1366 */     AST aST3 = null;
/* 1367 */     AST aST4 = null;
/* 1368 */     AST aST5 = null;
/* 1369 */     AST aST6 = null;
/* 1370 */     AST aST7 = null;
/* 1371 */     AST aST8 = null;
/* 1372 */     AST aST9 = null;
/* 1373 */     Token token = null;
/* 1374 */     AST aST10 = null;
/* 1375 */     AST aST11 = null;
/* 1376 */     AST aST12 = null;
/* 1377 */     AST aST13 = null;
/* 1378 */     AST aST14 = null;
/* 1379 */     AST aST15 = null;
/* 1380 */     AST aST16 = null;
/* 1381 */     AST aST17 = null;
/*      */     
/* 1383 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_5.member(LA(2))) {
/* 1384 */       annotations();
/* 1385 */       aST2 = this.returnAST;
/* 1386 */       modifiers();
/* 1387 */       aST3 = this.returnAST;
/* 1388 */       annotations();
/* 1389 */       aST4 = this.returnAST;
/*      */       
/* 1391 */       switch (LA(1)) {
/*      */         
/*      */         case 75:
/* 1394 */           classDefinition(aST2, aST3, aST4);
/* 1395 */           aST7 = this.returnAST;
/* 1396 */           if (this.inputState.guessing == 0) {
/* 1397 */             aST1 = aSTPair.root;
/* 1398 */             aST1 = aST7;
/* 1399 */             aSTPair.root = aST1;
/* 1400 */             aSTPair
/* 1401 */               .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1402 */             aSTPair.advanceChildToEnd();
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 76:
/* 1408 */           interfaceDefinition(aST2, aST3, aST4);
/* 1409 */           aST8 = this.returnAST;
/* 1410 */           if (this.inputState.guessing == 0) {
/* 1411 */             aST1 = aSTPair.root;
/* 1412 */             aST1 = aST8;
/* 1413 */             aSTPair.root = aST1;
/* 1414 */             aSTPair
/* 1415 */               .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1416 */             aSTPair.advanceChildToEnd();
/*      */           } 
/*      */           break;
/*      */         
/*      */         default:
/* 1421 */           if (LA(1) == 63 && LA(2) == 81) {
/* 1422 */             ctorHead();
/* 1423 */             aST5 = this.returnAST;
/* 1424 */             constructorBody();
/* 1425 */             aST6 = this.returnAST;
/* 1426 */             if (this.inputState.guessing == 0) {
/* 1427 */               aST1 = aSTPair.root;
/* 1428 */               aST1 = this.astFactory.make((new ASTArray(6)).add(this.astFactory.create(8, "CTOR_DEF")).add(aST2).add(aST3).add(aST4).add(aST5).add(aST6));
/* 1429 */               aSTPair.root = aST1;
/* 1430 */               aSTPair
/* 1431 */                 .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1432 */               aSTPair.advanceChildToEnd();
/*      */             }  break;
/*      */           } 
/* 1435 */           if (LA(1) >= 54 && LA(1) <= 63 && _tokenSet_6.member(LA(2))) {
/* 1436 */             typeSpec(false);
/* 1437 */             aST9 = this.returnAST;
/*      */             
/* 1439 */             if (LA(1) == 63 && LA(2) == 81) {
/* 1440 */               AST aST; token = LT(1);
/* 1441 */               aST10 = this.astFactory.create(token);
/* 1442 */               match(63);
/* 1443 */               match(81);
/* 1444 */               parameterDeclarationList();
/* 1445 */               aST11 = this.returnAST;
/* 1446 */               match(82);
/* 1447 */               declaratorBrackets(aST9);
/* 1448 */               aST12 = this.returnAST;
/*      */               
/* 1450 */               switch (LA(1)) {
/*      */                 
/*      */                 case 86:
/* 1453 */                   throwsClause();
/* 1454 */                   aST13 = this.returnAST;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 45:
/*      */                 case 77:
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 default:
/* 1464 */                   throw new NoViableAltException(LT(1), getFilename());
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 1469 */               switch (LA(1)) {
/*      */                 
/*      */                 case 77:
/* 1472 */                   compoundStatement();
/* 1473 */                   aST14 = this.returnAST;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 45:
/* 1478 */                   aST = null;
/* 1479 */                   aST = this.astFactory.create(LT(1));
/* 1480 */                   match(45);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 default:
/* 1485 */                   throw new NoViableAltException(LT(1), getFilename());
/*      */               } 
/*      */ 
/*      */               
/* 1489 */               if (this.inputState.guessing == 0) {
/* 1490 */                 aST1 = aSTPair.root;
/* 1491 */                 aST1 = this.astFactory.make((new ASTArray(9)).add(this.astFactory.create(9, "METHOD_DEF")).add(aST2).add(aST3).add(aST4).add(this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(13, "TYPE")).add(aST12))).add(aST10).add(aST11).add(aST13).add(aST14));
/* 1492 */                 if (this.blockDepth == 1)
/* 1493 */                   this.functionNames.add(token.getText()); 
/* 1494 */                 aSTPair.root = aST1;
/* 1495 */                 aSTPair
/* 1496 */                   .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1497 */                 aSTPair.advanceChildToEnd();
/*      */               }  break;
/*      */             } 
/* 1500 */             if (LA(1) == 63 && _tokenSet_7.member(LA(2))) {
/* 1501 */               variableDefinitions(aST2, aST3, aST4, aST9);
/* 1502 */               aST15 = this.returnAST;
/* 1503 */               AST aST = null;
/* 1504 */               aST = this.astFactory.create(LT(1));
/* 1505 */               match(45);
/* 1506 */               if (this.inputState.guessing == 0) {
/* 1507 */                 aST1 = aSTPair.root;
/* 1508 */                 aST1 = aST15;
/* 1509 */                 aSTPair.root = aST1;
/* 1510 */                 aSTPair
/* 1511 */                   .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1512 */                 aSTPair.advanceChildToEnd();
/*      */               } 
/*      */               break;
/*      */             } 
/* 1516 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1522 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 1527 */     } else if (LA(1) == 69 && LA(2) == 77) {
/* 1528 */       match(69);
/* 1529 */       compoundStatement();
/* 1530 */       aST16 = this.returnAST;
/* 1531 */       if (this.inputState.guessing == 0) {
/* 1532 */         aST1 = aSTPair.root;
/* 1533 */         aST1 = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(12, "STATIC_INIT")).add(aST16));
/* 1534 */         aSTPair.root = aST1;
/* 1535 */         aSTPair
/* 1536 */           .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1537 */         aSTPair.advanceChildToEnd();
/*      */       }
/*      */     
/* 1540 */     } else if (LA(1) == 77) {
/* 1541 */       compoundStatement();
/* 1542 */       aST17 = this.returnAST;
/* 1543 */       if (this.inputState.guessing == 0) {
/* 1544 */         aST1 = aSTPair.root;
/* 1545 */         aST1 = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(11, "INSTANCE_INIT")).add(aST17));
/* 1546 */         aSTPair.root = aST1;
/* 1547 */         aSTPair
/* 1548 */           .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1549 */         aSTPair.advanceChildToEnd();
/*      */       } 
/*      */     } else {
/*      */       
/* 1553 */       throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 1556 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void ctorHead() throws RecognitionException, TokenStreamException {
/* 1561 */     this.returnAST = null;
/* 1562 */     ASTPair aSTPair = new ASTPair();
/* 1563 */     AST aST1 = null;
/*      */     
/* 1565 */     AST aST2 = null;
/* 1566 */     aST2 = this.astFactory.create(LT(1));
/* 1567 */     this.astFactory.addASTChild(aSTPair, aST2);
/* 1568 */     match(63);
/* 1569 */     match(81);
/* 1570 */     parameterDeclarationList();
/* 1571 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1572 */     match(82);
/*      */     
/* 1574 */     switch (LA(1)) {
/*      */       
/*      */       case 86:
/* 1577 */         throwsClause();
/* 1578 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 77:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1587 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 1591 */     aST1 = aSTPair.root;
/* 1592 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void constructorBody() throws RecognitionException, TokenStreamException {
/* 1597 */     this.returnAST = null;
/* 1598 */     ASTPair aSTPair = new ASTPair();
/* 1599 */     AST aST1 = null;
/* 1600 */     Token token = null;
/* 1601 */     AST aST2 = null;
/*      */     
/* 1603 */     token = LT(1);
/* 1604 */     aST2 = this.astFactory.create(token);
/* 1605 */     this.astFactory.makeASTRoot(aSTPair, aST2);
/* 1606 */     match(77);
/* 1607 */     if (this.inputState.guessing == 0) {
/* 1608 */       aST2.setType(7); this.blockDepth++;
/*      */     } 
/*      */     
/* 1611 */     if ((LA(1) == 83 || LA(1) == 84) && LA(2) == 81) {
/* 1612 */       explicitConstructorInvocation();
/* 1613 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     }
/* 1615 */     else if (!_tokenSet_8.member(LA(1)) || !_tokenSet_9.member(LA(2))) {
/*      */ 
/*      */       
/* 1618 */       throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1625 */     while (_tokenSet_10.member(LA(1))) {
/* 1626 */       statement();
/* 1627 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1635 */     match(78);
/* 1636 */     if (this.inputState.guessing == 0) {
/* 1637 */       this.blockDepth--;
/*      */     }
/* 1639 */     aST1 = aSTPair.root;
/* 1640 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void parameterDeclarationList() throws RecognitionException, TokenStreamException {
/* 1645 */     this.returnAST = null;
/* 1646 */     ASTPair aSTPair = new ASTPair();
/* 1647 */     AST aST = null;
/*      */ 
/*      */     
/* 1650 */     switch (LA(1)) {
/*      */       
/*      */       case 39:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 103:
/* 1664 */         parameterDeclaration();
/* 1665 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */         
/* 1669 */         while (LA(1) == 79) {
/* 1670 */           match(79);
/* 1671 */           parameterDeclaration();
/* 1672 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 82:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1688 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 1692 */     if (this.inputState.guessing == 0) {
/* 1693 */       aST = aSTPair.root;
/* 1694 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(20, "PARAMETERS")).add(aST));
/* 1695 */       aSTPair.root = aST;
/* 1696 */       aSTPair
/* 1697 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 1698 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 1700 */     aST = aSTPair.root;
/* 1701 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void declaratorBrackets(AST paramAST) throws RecognitionException, TokenStreamException {
/* 1708 */     this.returnAST = null;
/* 1709 */     ASTPair aSTPair = new ASTPair();
/* 1710 */     AST aST1 = null;
/* 1711 */     Token token = null;
/* 1712 */     AST aST2 = null;
/*      */     
/* 1714 */     if (this.inputState.guessing == 0) {
/* 1715 */       aST1 = aSTPair.root;
/* 1716 */       aST1 = paramAST;
/* 1717 */       aSTPair.root = aST1;
/* 1718 */       aSTPair
/* 1719 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 1720 */       aSTPair.advanceChildToEnd();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1725 */     while (LA(1) == 52) {
/* 1726 */       token = LT(1);
/* 1727 */       aST2 = this.astFactory.create(token);
/* 1728 */       this.astFactory.makeASTRoot(aSTPair, aST2);
/* 1729 */       match(52);
/* 1730 */       if (this.inputState.guessing == 0) {
/* 1731 */         aST2.setType(17);
/*      */       }
/* 1733 */       match(53);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1741 */     aST1 = aSTPair.root;
/* 1742 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void throwsClause() throws RecognitionException, TokenStreamException {
/* 1747 */     this.returnAST = null;
/* 1748 */     ASTPair aSTPair = new ASTPair();
/* 1749 */     AST aST1 = null;
/*      */     
/* 1751 */     AST aST2 = null;
/* 1752 */     aST2 = this.astFactory.create(LT(1));
/* 1753 */     this.astFactory.makeASTRoot(aSTPair, aST2);
/* 1754 */     match(86);
/* 1755 */     identifier();
/* 1756 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 1760 */     while (LA(1) == 79) {
/* 1761 */       match(79);
/* 1762 */       identifier();
/* 1763 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1771 */     aST1 = aSTPair.root;
/* 1772 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void compoundStatement() throws RecognitionException, TokenStreamException {
/* 1777 */     this.returnAST = null;
/* 1778 */     ASTPair aSTPair = new ASTPair();
/* 1779 */     AST aST1 = null;
/* 1780 */     Token token = null;
/* 1781 */     AST aST2 = null;
/*      */     
/* 1783 */     token = LT(1);
/* 1784 */     aST2 = this.astFactory.create(token);
/* 1785 */     this.astFactory.makeASTRoot(aSTPair, aST2);
/* 1786 */     match(77);
/* 1787 */     if (this.inputState.guessing == 0) {
/* 1788 */       aST2.setType(7); this.blockDepth++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1793 */     while (_tokenSet_10.member(LA(1))) {
/* 1794 */       statement();
/* 1795 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1803 */     match(78);
/* 1804 */     if (this.inputState.guessing == 0) {
/* 1805 */       this.blockDepth--;
/*      */     }
/* 1807 */     aST1 = aSTPair.root;
/* 1808 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void explicitConstructorInvocation() throws RecognitionException, TokenStreamException {
/* 1814 */     this.returnAST = null;
/* 1815 */     ASTPair aSTPair = new ASTPair();
/* 1816 */     AST aST1 = null;
/* 1817 */     Token token1 = null;
/* 1818 */     AST aST2 = null;
/* 1819 */     Token token2 = null;
/* 1820 */     AST aST3 = null;
/*      */     
/* 1822 */     switch (LA(1)) {
/*      */       
/*      */       case 83:
/* 1825 */         match(83);
/* 1826 */         token1 = LT(1);
/* 1827 */         aST2 = this.astFactory.create(token1);
/* 1828 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 1829 */         match(81);
/* 1830 */         argList();
/* 1831 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1832 */         match(82);
/* 1833 */         match(45);
/* 1834 */         if (this.inputState.guessing == 0) {
/* 1835 */           aST2.setType(43);
/*      */         }
/* 1837 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 84:
/* 1842 */         match(84);
/* 1843 */         token2 = LT(1);
/* 1844 */         aST3 = this.astFactory.create(token2);
/* 1845 */         this.astFactory.makeASTRoot(aSTPair, aST3);
/* 1846 */         match(81);
/* 1847 */         argList();
/* 1848 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1849 */         match(82);
/* 1850 */         match(45);
/* 1851 */         if (this.inputState.guessing == 0) {
/* 1852 */           aST3.setType(42);
/*      */         }
/* 1854 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1859 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 1862 */     this.returnAST = aST1;
/*      */   } public final void statement() throws RecognitionException, TokenStreamException {
/*      */     AST aST7;
/*      */     boolean bool;
/*      */     AST aST8;
/* 1867 */     this.returnAST = null;
/* 1868 */     ASTPair aSTPair = new ASTPair();
/* 1869 */     AST aST1 = null;
/* 1870 */     AST aST2 = null;
/* 1871 */     AST aST3 = null;
/* 1872 */     AST aST4 = null;
/* 1873 */     Token token1 = null;
/* 1874 */     AST aST5 = null;
/* 1875 */     Token token2 = null;
/* 1876 */     AST aST6 = null;
/*      */     
/* 1878 */     switch (LA(1)) {
/*      */       
/*      */       case 77:
/* 1881 */         compoundStatement();
/* 1882 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1883 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 88:
/* 1888 */         aST7 = null;
/* 1889 */         aST7 = this.astFactory.create(LT(1));
/* 1890 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 1891 */         match(88);
/* 1892 */         match(81);
/* 1893 */         expression();
/* 1894 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1895 */         match(82);
/* 1896 */         statement();
/* 1897 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         
/* 1899 */         if (LA(1) == 89 && _tokenSet_10.member(LA(2))) {
/* 1900 */           match(89);
/* 1901 */           statement();
/* 1902 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         }
/* 1904 */         else if (!_tokenSet_11.member(LA(1)) || !_tokenSet_12.member(LA(2))) {
/*      */ 
/*      */           
/* 1907 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 1911 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 90:
/* 1916 */         aST7 = null;
/* 1917 */         aST7 = this.astFactory.create(LT(1));
/* 1918 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 1919 */         match(90);
/* 1920 */         match(81);
/* 1921 */         forInit();
/* 1922 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1923 */         match(45);
/* 1924 */         forCond();
/* 1925 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1926 */         match(45);
/* 1927 */         forIter();
/* 1928 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1929 */         match(82);
/* 1930 */         statement();
/* 1931 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1932 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 91:
/* 1937 */         aST7 = null;
/* 1938 */         aST7 = this.astFactory.create(LT(1));
/* 1939 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 1940 */         match(91);
/* 1941 */         match(81);
/* 1942 */         expression();
/* 1943 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1944 */         match(82);
/* 1945 */         statement();
/* 1946 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1947 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 92:
/* 1952 */         aST7 = null;
/* 1953 */         aST7 = this.astFactory.create(LT(1));
/* 1954 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 1955 */         match(92);
/* 1956 */         statement();
/* 1957 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1958 */         match(91);
/* 1959 */         match(81);
/* 1960 */         expression();
/* 1961 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1962 */         match(82);
/* 1963 */         match(45);
/* 1964 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 93:
/* 1969 */         aST7 = null;
/* 1970 */         aST7 = this.astFactory.create(LT(1));
/* 1971 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 1972 */         match(93);
/*      */         
/* 1974 */         switch (LA(1)) {
/*      */           
/*      */           case 63:
/* 1977 */             aST8 = null;
/* 1978 */             aST8 = this.astFactory.create(LT(1));
/* 1979 */             this.astFactory.addASTChild(aSTPair, aST8);
/* 1980 */             match(63);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 45:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1989 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 1993 */         match(45);
/* 1994 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 94:
/* 1999 */         aST7 = null;
/* 2000 */         aST7 = this.astFactory.create(LT(1));
/* 2001 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 2002 */         match(94);
/*      */         
/* 2004 */         switch (LA(1)) {
/*      */           
/*      */           case 63:
/* 2007 */             aST8 = null;
/* 2008 */             aST8 = this.astFactory.create(LT(1));
/* 2009 */             this.astFactory.addASTChild(aSTPair, aST8);
/* 2010 */             match(63);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 45:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2019 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 2023 */         match(45);
/* 2024 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 95:
/* 2029 */         aST7 = null;
/* 2030 */         aST7 = this.astFactory.create(LT(1));
/* 2031 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 2032 */         match(95);
/*      */         
/* 2034 */         switch (LA(1)) {
/*      */           
/*      */           case 54:
/*      */           case 55:
/*      */           case 56:
/*      */           case 57:
/*      */           case 58:
/*      */           case 59:
/*      */           case 60:
/*      */           case 61:
/*      */           case 62:
/*      */           case 63:
/*      */           case 81:
/*      */           case 83:
/*      */           case 84:
/*      */           case 127:
/*      */           case 128:
/*      */           case 131:
/*      */           case 132:
/*      */           case 133:
/*      */           case 134:
/*      */           case 135:
/*      */           case 136:
/*      */           case 137:
/*      */           case 138:
/*      */           case 139:
/*      */           case 140:
/*      */           case 141:
/*      */           case 142:
/*      */           case 143:
/*      */           case 144:
/* 2065 */             expression();
/* 2066 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 45:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2075 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 2079 */         match(45);
/* 2080 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 96:
/* 2085 */         aST7 = null;
/* 2086 */         aST7 = this.astFactory.create(LT(1));
/* 2087 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 2088 */         match(96);
/* 2089 */         match(81);
/* 2090 */         expression();
/* 2091 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2092 */         match(82);
/* 2093 */         match(77);
/* 2094 */         if (this.inputState.guessing == 0) {
/* 2095 */           this.blockDepth++;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2100 */         while (LA(1) == 98 || LA(1) == 99) {
/* 2101 */           casesGroup();
/* 2102 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2110 */         match(78);
/* 2111 */         if (this.inputState.guessing == 0) {
/* 2112 */           this.blockDepth--;
/*      */         }
/* 2114 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 100:
/* 2119 */         tryBlock();
/* 2120 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2121 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 97:
/* 2126 */         aST7 = null;
/* 2127 */         aST7 = this.astFactory.create(LT(1));
/* 2128 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 2129 */         match(97);
/* 2130 */         expression();
/* 2131 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2132 */         match(45);
/* 2133 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 45:
/* 2138 */         token2 = LT(1);
/* 2139 */         aST6 = this.astFactory.create(token2);
/* 2140 */         this.astFactory.addASTChild(aSTPair, aST6);
/* 2141 */         match(45);
/* 2142 */         if (this.inputState.guessing == 0) {
/* 2143 */           aST6.setType(38);
/*      */         }
/* 2145 */         aST1 = aSTPair.root;
/*      */         break;
/*      */       
/*      */       default:
/* 2149 */         bool = false;
/* 2150 */         if (_tokenSet_13.member(LA(1)) && _tokenSet_14.member(LA(2))) {
/* 2151 */           int i = mark();
/* 2152 */           bool = true;
/* 2153 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 2156 */             declaration();
/*      */           
/*      */           }
/* 2159 */           catch (RecognitionException recognitionException) {
/* 2160 */             bool = false;
/*      */           } 
/* 2162 */           rewind(i);
/* 2163 */           this.inputState.guessing--;
/*      */         } 
/* 2165 */         if (bool) {
/* 2166 */           declaration();
/* 2167 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2168 */           match(45);
/* 2169 */           aST1 = aSTPair.root; break;
/*      */         } 
/* 2171 */         if (_tokenSet_15.member(LA(1)) && _tokenSet_16.member(LA(2))) {
/* 2172 */           expression();
/* 2173 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2174 */           match(45);
/* 2175 */           aST1 = aSTPair.root; break;
/*      */         } 
/* 2177 */         if (_tokenSet_17.member(LA(1)) && _tokenSet_18.member(LA(2))) {
/* 2178 */           annotations();
/* 2179 */           aST2 = this.returnAST;
/* 2180 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2181 */           modifiers();
/* 2182 */           aST3 = this.returnAST;
/* 2183 */           annotations();
/* 2184 */           aST4 = this.returnAST;
/* 2185 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2186 */           classDefinition(aST2, aST3, aST4);
/* 2187 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2188 */           aST1 = aSTPair.root; break;
/*      */         } 
/* 2190 */         if (LA(1) == 63 && LA(2) == 87) {
/* 2191 */           aST8 = null;
/* 2192 */           aST8 = this.astFactory.create(LT(1));
/* 2193 */           this.astFactory.addASTChild(aSTPair, aST8);
/* 2194 */           match(63);
/* 2195 */           token1 = LT(1);
/* 2196 */           aST5 = this.astFactory.create(token1);
/* 2197 */           this.astFactory.makeASTRoot(aSTPair, aST5);
/* 2198 */           match(87);
/* 2199 */           if (this.inputState.guessing == 0) {
/* 2200 */             aST5.setType(22);
/*      */           }
/* 2202 */           statement();
/* 2203 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2204 */           aST1 = aSTPair.root; break;
/*      */         } 
/* 2206 */         if (LA(1) == 73 && LA(2) == 81) {
/* 2207 */           aST8 = null;
/* 2208 */           aST8 = this.astFactory.create(LT(1));
/* 2209 */           this.astFactory.makeASTRoot(aSTPair, aST8);
/* 2210 */           match(73);
/* 2211 */           match(81);
/* 2212 */           expression();
/* 2213 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2214 */           match(82);
/* 2215 */           compoundStatement();
/* 2216 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2217 */           aST1 = aSTPair.root;
/*      */           break;
/*      */         } 
/* 2220 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 2223 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void argList() throws RecognitionException, TokenStreamException {
/* 2228 */     this.returnAST = null;
/* 2229 */     ASTPair aSTPair = new ASTPair();
/* 2230 */     AST aST = null;
/*      */ 
/*      */     
/* 2233 */     switch (LA(1)) {
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 81:
/*      */       case 83:
/*      */       case 84:
/*      */       case 127:
/*      */       case 128:
/*      */       case 131:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 135:
/*      */       case 136:
/*      */       case 137:
/*      */       case 138:
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/* 2264 */         expressionList();
/* 2265 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 82:
/* 2270 */         if (this.inputState.guessing == 0) {
/* 2271 */           aST = aSTPair.root;
/* 2272 */           aST = this.astFactory.create(34, "ELIST");
/* 2273 */           aSTPair.root = aST;
/* 2274 */           aSTPair
/* 2275 */             .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 2276 */           aSTPair.advanceChildToEnd();
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2282 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2286 */     aST = aSTPair.root;
/* 2287 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void variableDeclarator(AST paramAST1, AST paramAST2, AST paramAST3, AST paramAST4) throws RecognitionException, TokenStreamException {
/* 2298 */     this.returnAST = null;
/* 2299 */     ASTPair aSTPair = new ASTPair();
/* 2300 */     AST aST1 = null;
/* 2301 */     Token token = null;
/* 2302 */     AST aST2 = null;
/* 2303 */     AST aST3 = null;
/* 2304 */     AST aST4 = null;
/*      */     
/* 2306 */     token = LT(1);
/* 2307 */     aST2 = this.astFactory.create(token);
/* 2308 */     match(63);
/* 2309 */     declaratorBrackets(paramAST4);
/* 2310 */     aST3 = this.returnAST;
/* 2311 */     varInitializer();
/* 2312 */     aST4 = this.returnAST;
/* 2313 */     if (this.inputState.guessing == 0) {
/* 2314 */       aST1 = aSTPair.root;
/* 2315 */       aST1 = this.astFactory.make((new ASTArray(7)).add(this.astFactory.create(10, "VARIABLE_DEF")).add(paramAST1).add(paramAST2).add(paramAST3).add(this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(13, "TYPE")).add(aST3))).add(aST2).add(aST4));
/* 2316 */       if (this.blockDepth == 1) {
/* 2317 */         this.enumNames.add(token.getText());
/*      */       }
/*      */       
/* 2320 */       aSTPair.root = aST1;
/* 2321 */       aSTPair
/* 2322 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 2323 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 2325 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void varInitializer() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/* 2330 */     this.returnAST = null;
/* 2331 */     ASTPair aSTPair = new ASTPair();
/* 2332 */     AST aST1 = null;
/*      */ 
/*      */     
/* 2335 */     switch (LA(1)) {
/*      */       
/*      */       case 85:
/* 2338 */         aST2 = null;
/* 2339 */         aST2 = this.astFactory.create(LT(1));
/* 2340 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 2341 */         match(85);
/* 2342 */         initializer();
/* 2343 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 45:
/*      */       case 79:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2353 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2357 */     aST1 = aSTPair.root;
/* 2358 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void initializer() throws RecognitionException, TokenStreamException {
/* 2363 */     this.returnAST = null;
/* 2364 */     ASTPair aSTPair = new ASTPair();
/* 2365 */     AST aST = null;
/*      */     
/* 2367 */     switch (LA(1)) {
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 81:
/*      */       case 83:
/*      */       case 84:
/*      */       case 127:
/*      */       case 128:
/*      */       case 131:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 135:
/*      */       case 136:
/*      */       case 137:
/*      */       case 138:
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/* 2398 */         expression();
/* 2399 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2400 */         aST = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 77:
/* 2405 */         arrayInitializer();
/* 2406 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2407 */         aST = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2412 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 2415 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void arrayInitializer() throws RecognitionException, TokenStreamException {
/* 2420 */     this.returnAST = null;
/* 2421 */     ASTPair aSTPair = new ASTPair();
/* 2422 */     AST aST1 = null;
/* 2423 */     Token token = null;
/* 2424 */     AST aST2 = null;
/*      */     
/* 2426 */     token = LT(1);
/* 2427 */     aST2 = this.astFactory.create(token);
/* 2428 */     this.astFactory.makeASTRoot(aSTPair, aST2);
/* 2429 */     match(77);
/* 2430 */     if (this.inputState.guessing == 0) {
/* 2431 */       aST2.setType(29); this.blockDepth++;
/*      */     } 
/*      */     
/* 2434 */     switch (LA(1)) {
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 77:
/*      */       case 81:
/*      */       case 83:
/*      */       case 84:
/*      */       case 127:
/*      */       case 128:
/*      */       case 131:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 135:
/*      */       case 136:
/*      */       case 137:
/*      */       case 138:
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/* 2466 */         initializer();
/* 2467 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */         
/* 2471 */         while (LA(1) == 79 && _tokenSet_19.member(LA(2))) {
/* 2472 */           match(79);
/* 2473 */           initializer();
/* 2474 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2483 */         switch (LA(1)) {
/*      */           
/*      */           case 79:
/* 2486 */             match(79);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 78:
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/* 2495 */         throw new NoViableAltException(LT(1), getFilename());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 78:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 2507 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2511 */     match(78);
/* 2512 */     if (this.inputState.guessing == 0) {
/* 2513 */       this.blockDepth--;
/*      */     }
/* 2515 */     aST1 = aSTPair.root;
/* 2516 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void expression() throws RecognitionException, TokenStreamException {
/* 2521 */     this.returnAST = null;
/* 2522 */     ASTPair aSTPair = new ASTPair();
/* 2523 */     AST aST = null;
/*      */     
/* 2525 */     assignmentExpression();
/* 2526 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2527 */     if (this.inputState.guessing == 0) {
/* 2528 */       aST = aSTPair.root;
/* 2529 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(28, "EXPR")).add(aST));
/* 2530 */       aSTPair.root = aST;
/* 2531 */       aSTPair
/* 2532 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 2533 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 2535 */     aST = aSTPair.root;
/* 2536 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void parameterDeclaration() throws RecognitionException, TokenStreamException {
/* 2541 */     this.returnAST = null;
/* 2542 */     ASTPair aSTPair = new ASTPair();
/* 2543 */     AST aST1 = null;
/* 2544 */     AST aST2 = null;
/* 2545 */     AST aST3 = null;
/* 2546 */     AST aST4 = null;
/* 2547 */     AST aST5 = null;
/* 2548 */     Token token = null;
/* 2549 */     AST aST6 = null;
/* 2550 */     AST aST7 = null;
/*      */     
/* 2552 */     annotations();
/* 2553 */     aST2 = this.returnAST;
/* 2554 */     parameterModifier();
/* 2555 */     aST3 = this.returnAST;
/* 2556 */     annotations();
/* 2557 */     aST4 = this.returnAST;
/* 2558 */     typeSpec(false);
/* 2559 */     aST5 = this.returnAST;
/* 2560 */     token = LT(1);
/* 2561 */     aST6 = this.astFactory.create(token);
/* 2562 */     match(63);
/* 2563 */     declaratorBrackets(aST5);
/* 2564 */     aST7 = this.returnAST;
/* 2565 */     if (this.inputState.guessing == 0) {
/* 2566 */       aST1 = aSTPair.root;
/* 2567 */       aST1 = this.astFactory.make((new ASTArray(6)).add(this.astFactory.create(21, "PARAMETER_DEF")).add(aST2).add(aST3).add(aST4).add(this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(13, "TYPE")).add(aST7))).add(aST6));
/* 2568 */       aSTPair.root = aST1;
/* 2569 */       aSTPair
/* 2570 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 2571 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 2573 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void parameterModifier() throws RecognitionException, TokenStreamException {
/* 2578 */     this.returnAST = null;
/* 2579 */     ASTPair aSTPair = new ASTPair();
/* 2580 */     AST aST1 = null;
/* 2581 */     Token token = null;
/* 2582 */     AST aST2 = null;
/*      */ 
/*      */     
/* 2585 */     switch (LA(1)) {
/*      */       
/*      */       case 39:
/* 2588 */         token = LT(1);
/* 2589 */         aST2 = this.astFactory.create(token);
/* 2590 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 2591 */         match(39);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 103:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2610 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2614 */     if (this.inputState.guessing == 0) {
/* 2615 */       aST1 = aSTPair.root;
/* 2616 */       aST1 = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(5, "MODIFIERS")).add(aST2));
/* 2617 */       aSTPair.root = aST1;
/* 2618 */       aSTPair
/* 2619 */         .child = (aST1 != null && aST1.getFirstChild() != null) ? aST1.getFirstChild() : aST1;
/* 2620 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 2622 */     aST1 = aSTPair.root;
/* 2623 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void forInit() throws RecognitionException, TokenStreamException {
/* 2628 */     this.returnAST = null;
/* 2629 */     ASTPair aSTPair = new ASTPair();
/* 2630 */     AST aST = null;
/*      */ 
/*      */     
/* 2633 */     boolean bool = false;
/* 2634 */     if (_tokenSet_13.member(LA(1)) && _tokenSet_14.member(LA(2))) {
/* 2635 */       int i = mark();
/* 2636 */       bool = true;
/* 2637 */       this.inputState.guessing++;
/*      */       
/*      */       try {
/* 2640 */         declaration();
/*      */       
/*      */       }
/* 2643 */       catch (RecognitionException recognitionException) {
/* 2644 */         bool = false;
/*      */       } 
/* 2646 */       rewind(i);
/* 2647 */       this.inputState.guessing--;
/*      */     } 
/* 2649 */     if (bool) {
/* 2650 */       declaration();
/* 2651 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     }
/* 2653 */     else if (_tokenSet_15.member(LA(1)) && _tokenSet_20.member(LA(2))) {
/* 2654 */       expressionList();
/* 2655 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     }
/* 2657 */     else if (LA(1) != 45) {
/*      */ 
/*      */       
/* 2660 */       throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2664 */     if (this.inputState.guessing == 0) {
/* 2665 */       aST = aSTPair.root;
/* 2666 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(35, "FOR_INIT")).add(aST));
/* 2667 */       aSTPair.root = aST;
/* 2668 */       aSTPair
/* 2669 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 2670 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 2672 */     aST = aSTPair.root;
/* 2673 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void forCond() throws RecognitionException, TokenStreamException {
/* 2678 */     this.returnAST = null;
/* 2679 */     ASTPair aSTPair = new ASTPair();
/* 2680 */     AST aST = null;
/*      */ 
/*      */     
/* 2683 */     switch (LA(1)) {
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 81:
/*      */       case 83:
/*      */       case 84:
/*      */       case 127:
/*      */       case 128:
/*      */       case 131:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 135:
/*      */       case 136:
/*      */       case 137:
/*      */       case 138:
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/* 2714 */         expression();
/* 2715 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 45:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2724 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2728 */     if (this.inputState.guessing == 0) {
/* 2729 */       aST = aSTPair.root;
/* 2730 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(36, "FOR_CONDITION")).add(aST));
/* 2731 */       aSTPair.root = aST;
/* 2732 */       aSTPair
/* 2733 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 2734 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 2736 */     aST = aSTPair.root;
/* 2737 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void forIter() throws RecognitionException, TokenStreamException {
/* 2742 */     this.returnAST = null;
/* 2743 */     ASTPair aSTPair = new ASTPair();
/* 2744 */     AST aST = null;
/*      */ 
/*      */     
/* 2747 */     switch (LA(1)) {
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 81:
/*      */       case 83:
/*      */       case 84:
/*      */       case 127:
/*      */       case 128:
/*      */       case 131:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 135:
/*      */       case 136:
/*      */       case 137:
/*      */       case 138:
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/* 2778 */         expressionList();
/* 2779 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 82:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2788 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2792 */     if (this.inputState.guessing == 0) {
/* 2793 */       aST = aSTPair.root;
/* 2794 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(37, "FOR_ITERATOR")).add(aST));
/* 2795 */       aSTPair.root = aST;
/* 2796 */       aSTPair
/* 2797 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 2798 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 2800 */     aST = aSTPair.root;
/* 2801 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void casesGroup() throws RecognitionException, TokenStreamException {
/* 2806 */     this.returnAST = null;
/* 2807 */     ASTPair aSTPair = new ASTPair();
/* 2808 */     AST aST = null;
/*      */ 
/*      */     
/* 2811 */     byte b = 0;
/*      */     
/*      */     while (true) {
/* 2814 */       if ((LA(1) == 98 || LA(1) == 99) && _tokenSet_21.member(LA(2))) {
/* 2815 */         aCase();
/* 2816 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } else {
/*      */         
/* 2819 */         if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */       
/* 2822 */       b++;
/*      */     } 
/*      */     
/* 2825 */     caseSList();
/* 2826 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2827 */     if (this.inputState.guessing == 0) {
/* 2828 */       aST = aSTPair.root;
/* 2829 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(33, "CASE_GROUP")).add(aST));
/* 2830 */       aSTPair.root = aST;
/* 2831 */       aSTPair
/* 2832 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 2833 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 2835 */     aST = aSTPair.root;
/* 2836 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void tryBlock() throws RecognitionException, TokenStreamException {
/* 2841 */     this.returnAST = null;
/* 2842 */     ASTPair aSTPair = new ASTPair();
/* 2843 */     AST aST1 = null;
/*      */     
/* 2845 */     AST aST2 = null;
/* 2846 */     aST2 = this.astFactory.create(LT(1));
/* 2847 */     this.astFactory.makeASTRoot(aSTPair, aST2);
/* 2848 */     match(100);
/* 2849 */     compoundStatement();
/* 2850 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 2854 */     while (LA(1) == 102) {
/* 2855 */       handler();
/* 2856 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2865 */     switch (LA(1)) {
/*      */       
/*      */       case 101:
/* 2868 */         finallyClause();
/* 2869 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 45:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 66:
/*      */       case 67:
/*      */       case 68:
/*      */       case 69:
/*      */       case 70:
/*      */       case 71:
/*      */       case 72:
/*      */       case 73:
/*      */       case 74:
/*      */       case 75:
/*      */       case 77:
/*      */       case 78:
/*      */       case 81:
/*      */       case 83:
/*      */       case 84:
/*      */       case 88:
/*      */       case 89:
/*      */       case 90:
/*      */       case 91:
/*      */       case 92:
/*      */       case 93:
/*      */       case 94:
/*      */       case 95:
/*      */       case 96:
/*      */       case 97:
/*      */       case 98:
/*      */       case 99:
/*      */       case 100:
/*      */       case 103:
/*      */       case 127:
/*      */       case 128:
/*      */       case 131:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 135:
/*      */       case 136:
/*      */       case 137:
/*      */       case 138:
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2936 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2940 */     aST1 = aSTPair.root;
/* 2941 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void aCase() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/* 2946 */     this.returnAST = null;
/* 2947 */     ASTPair aSTPair = new ASTPair();
/* 2948 */     AST aST1 = null;
/*      */ 
/*      */     
/* 2951 */     switch (LA(1)) {
/*      */       
/*      */       case 98:
/* 2954 */         aST2 = null;
/* 2955 */         aST2 = this.astFactory.create(LT(1));
/* 2956 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 2957 */         match(98);
/* 2958 */         expression();
/* 2959 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 99:
/* 2964 */         aST2 = null;
/* 2965 */         aST2 = this.astFactory.create(LT(1));
/* 2966 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 2967 */         match(99);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2972 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 2976 */     match(87);
/* 2977 */     aST1 = aSTPair.root;
/* 2978 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void caseSList() throws RecognitionException, TokenStreamException {
/* 2983 */     this.returnAST = null;
/* 2984 */     ASTPair aSTPair = new ASTPair();
/* 2985 */     AST aST = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2990 */     while (_tokenSet_10.member(LA(1))) {
/* 2991 */       statement();
/* 2992 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3000 */     if (this.inputState.guessing == 0) {
/* 3001 */       aST = aSTPair.root;
/* 3002 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(7, "SLIST")).add(aST));
/* 3003 */       aSTPair.root = aST;
/* 3004 */       aSTPair
/* 3005 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 3006 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 3008 */     aST = aSTPair.root;
/* 3009 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void expressionList() throws RecognitionException, TokenStreamException {
/* 3014 */     this.returnAST = null;
/* 3015 */     ASTPair aSTPair = new ASTPair();
/* 3016 */     AST aST = null;
/*      */     
/* 3018 */     expression();
/* 3019 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 3023 */     while (LA(1) == 79) {
/* 3024 */       match(79);
/* 3025 */       expression();
/* 3026 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3034 */     if (this.inputState.guessing == 0) {
/* 3035 */       aST = aSTPair.root;
/* 3036 */       aST = this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(34, "ELIST")).add(aST));
/* 3037 */       aSTPair.root = aST;
/* 3038 */       aSTPair
/* 3039 */         .child = (aST != null && aST.getFirstChild() != null) ? aST.getFirstChild() : aST;
/* 3040 */       aSTPair.advanceChildToEnd();
/*      */     } 
/* 3042 */     aST = aSTPair.root;
/* 3043 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void handler() throws RecognitionException, TokenStreamException {
/* 3048 */     this.returnAST = null;
/* 3049 */     ASTPair aSTPair = new ASTPair();
/* 3050 */     AST aST1 = null;
/*      */     
/* 3052 */     AST aST2 = null;
/* 3053 */     aST2 = this.astFactory.create(LT(1));
/* 3054 */     this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3055 */     match(102);
/* 3056 */     match(81);
/* 3057 */     parameterDeclaration();
/* 3058 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3059 */     match(82);
/* 3060 */     compoundStatement();
/* 3061 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3062 */     aST1 = aSTPair.root;
/* 3063 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void finallyClause() throws RecognitionException, TokenStreamException {
/* 3068 */     this.returnAST = null;
/* 3069 */     ASTPair aSTPair = new ASTPair();
/* 3070 */     AST aST1 = null;
/*      */     
/* 3072 */     AST aST2 = null;
/* 3073 */     aST2 = this.astFactory.create(LT(1));
/* 3074 */     this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3075 */     match(101);
/* 3076 */     compoundStatement();
/* 3077 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3078 */     aST1 = aSTPair.root;
/* 3079 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void annotation() throws RecognitionException, TokenStreamException {
/*      */     AST aST5, aST6;
/* 3084 */     this.returnAST = null;
/* 3085 */     ASTPair aSTPair = new ASTPair();
/* 3086 */     AST aST1 = null;
/* 3087 */     AST aST2 = null;
/* 3088 */     AST aST3 = null;
/*      */ 
/*      */     
/* 3091 */     AST aST4 = null;
/* 3092 */     aST4 = this.astFactory.create(LT(1));
/* 3093 */     this.astFactory.addASTChild(aSTPair, aST4);
/* 3094 */     match(103);
/* 3095 */     typeSpec(false);
/* 3096 */     aST2 = this.returnAST;
/* 3097 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     
/* 3099 */     switch (LA(1)) {
/*      */       
/*      */       case 81:
/* 3102 */         aST5 = null;
/* 3103 */         aST5 = this.astFactory.create(LT(1));
/* 3104 */         this.astFactory.addASTChild(aSTPair, aST5);
/* 3105 */         match(81);
/*      */         
/* 3107 */         if (_tokenSet_22.member(LA(1)) && _tokenSet_23.member(LA(2))) {
/* 3108 */           primaryExpression();
/* 3109 */           aST3 = this.returnAST;
/* 3110 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         }
/* 3112 */         else if (LA(1) == 63 && _tokenSet_24.member(LA(2))) {
/* 3113 */           identPrimary();
/* 3114 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3115 */           AST aST = null;
/* 3116 */           aST = this.astFactory.create(LT(1));
/* 3117 */           this.astFactory.addASTChild(aSTPair, aST);
/* 3118 */           match(85);
/* 3119 */           primaryExpression();
/* 3120 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */           
/* 3124 */           while (LA(1) == 79) {
/* 3125 */             AST aST7 = null;
/* 3126 */             aST7 = this.astFactory.create(LT(1));
/* 3127 */             this.astFactory.addASTChild(aSTPair, aST7);
/* 3128 */             match(79);
/* 3129 */             identPrimary();
/* 3130 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3131 */             AST aST8 = null;
/* 3132 */             aST8 = this.astFactory.create(LT(1));
/* 3133 */             this.astFactory.addASTChild(aSTPair, aST8);
/* 3134 */             match(85);
/* 3135 */             primaryExpression();
/* 3136 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 3146 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 3150 */         aST6 = null;
/* 3151 */         aST6 = this.astFactory.create(LT(1));
/* 3152 */         this.astFactory.addASTChild(aSTPair, aST6);
/* 3153 */         match(82);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 66:
/*      */       case 67:
/*      */       case 68:
/*      */       case 69:
/*      */       case 70:
/*      */       case 71:
/*      */       case 72:
/*      */       case 73:
/*      */       case 74:
/*      */       case 75:
/*      */       case 76:
/*      */       case 103:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 3186 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3191 */     aST1 = aSTPair.root;
/* 3192 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void primaryExpression() throws RecognitionException, TokenStreamException {
/*      */     AST aST3, aST4;
/* 3197 */     this.returnAST = null;
/* 3198 */     ASTPair aSTPair = new ASTPair();
/* 3199 */     AST aST1 = null;
/* 3200 */     Token token = null;
/* 3201 */     AST aST2 = null;
/*      */     
/* 3203 */     switch (LA(1)) {
/*      */       
/*      */       case 63:
/* 3206 */         identPrimary();
/* 3207 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         
/* 3209 */         if (LA(1) == 64 && LA(2) == 75) {
/* 3210 */           AST aST5 = null;
/* 3211 */           aST5 = this.astFactory.create(LT(1));
/* 3212 */           this.astFactory.makeASTRoot(aSTPair, aST5);
/* 3213 */           match(64);
/* 3214 */           AST aST6 = null;
/* 3215 */           aST6 = this.astFactory.create(LT(1));
/* 3216 */           this.astFactory.addASTChild(aSTPair, aST6);
/* 3217 */           match(75);
/*      */         }
/* 3219 */         else if (!_tokenSet_25.member(LA(1)) || !_tokenSet_26.member(LA(2))) {
/*      */ 
/*      */           
/* 3222 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 3226 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/* 3236 */         constant();
/* 3237 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3238 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 135:
/* 3243 */         aST3 = null;
/* 3244 */         aST3 = this.astFactory.create(LT(1));
/* 3245 */         this.astFactory.addASTChild(aSTPair, aST3);
/* 3246 */         match(135);
/* 3247 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 136:
/* 3252 */         aST3 = null;
/* 3253 */         aST3 = this.astFactory.create(LT(1));
/* 3254 */         this.astFactory.addASTChild(aSTPair, aST3);
/* 3255 */         match(136);
/* 3256 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 137:
/* 3261 */         aST3 = null;
/* 3262 */         aST3 = this.astFactory.create(LT(1));
/* 3263 */         this.astFactory.addASTChild(aSTPair, aST3);
/* 3264 */         match(137);
/* 3265 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 138:
/* 3270 */         newExpression();
/* 3271 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3272 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 83:
/* 3277 */         aST3 = null;
/* 3278 */         aST3 = this.astFactory.create(LT(1));
/* 3279 */         this.astFactory.addASTChild(aSTPair, aST3);
/* 3280 */         match(83);
/* 3281 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 84:
/* 3286 */         aST3 = null;
/* 3287 */         aST3 = this.astFactory.create(LT(1));
/* 3288 */         this.astFactory.addASTChild(aSTPair, aST3);
/* 3289 */         match(84);
/* 3290 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 81:
/* 3295 */         match(81);
/* 3296 */         assignmentExpression();
/* 3297 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3298 */         match(82);
/* 3299 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/* 3312 */         builtInType();
/* 3313 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */         
/* 3317 */         while (LA(1) == 52) {
/* 3318 */           token = LT(1);
/* 3319 */           aST2 = this.astFactory.create(token);
/* 3320 */           this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3321 */           match(52);
/* 3322 */           if (this.inputState.guessing == 0) {
/* 3323 */             aST2.setType(17);
/*      */           }
/* 3325 */           match(53);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3333 */         aST3 = null;
/* 3334 */         aST3 = this.astFactory.create(LT(1));
/* 3335 */         this.astFactory.makeASTRoot(aSTPair, aST3);
/* 3336 */         match(64);
/* 3337 */         aST4 = null;
/* 3338 */         aST4 = this.astFactory.create(LT(1));
/* 3339 */         this.astFactory.addASTChild(aSTPair, aST4);
/* 3340 */         match(75);
/* 3341 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 3346 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 3349 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void identPrimary() throws RecognitionException, TokenStreamException {
/* 3358 */     this.returnAST = null;
/* 3359 */     ASTPair aSTPair = new ASTPair();
/* 3360 */     AST aST1 = null;
/* 3361 */     Token token1 = null;
/* 3362 */     AST aST2 = null;
/* 3363 */     Token token2 = null;
/* 3364 */     AST aST3 = null;
/*      */     
/* 3366 */     AST aST4 = null;
/* 3367 */     aST4 = this.astFactory.create(LT(1));
/* 3368 */     this.astFactory.addASTChild(aSTPair, aST4);
/* 3369 */     match(63);
/*      */ 
/*      */ 
/*      */     
/* 3373 */     while (LA(1) == 64 && LA(2) == 63) {
/* 3374 */       AST aST5 = null;
/* 3375 */       aST5 = this.astFactory.create(LT(1));
/* 3376 */       this.astFactory.makeASTRoot(aSTPair, aST5);
/* 3377 */       match(64);
/* 3378 */       AST aST6 = null;
/* 3379 */       aST6 = this.astFactory.create(LT(1));
/* 3380 */       this.astFactory.addASTChild(aSTPair, aST6);
/* 3381 */       match(63);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3390 */     if (LA(1) == 81) {
/*      */       
/* 3392 */       token1 = LT(1);
/* 3393 */       aST2 = this.astFactory.create(token1);
/* 3394 */       this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3395 */       match(81);
/* 3396 */       if (this.inputState.guessing == 0) {
/* 3397 */         aST2.setType(27);
/*      */       }
/* 3399 */       argList();
/* 3400 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3401 */       match(82);
/*      */     
/*      */     }
/* 3404 */     else if (LA(1) == 52 && LA(2) == 53) {
/*      */       
/* 3406 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 3409 */         if (LA(1) == 52 && LA(2) == 53) {
/* 3410 */           token2 = LT(1);
/* 3411 */           aST3 = this.astFactory.create(token2);
/* 3412 */           this.astFactory.makeASTRoot(aSTPair, aST3);
/* 3413 */           match(52);
/* 3414 */           if (this.inputState.guessing == 0) {
/* 3415 */             aST3.setType(17);
/*      */           }
/* 3417 */           match(53);
/*      */         } else {
/*      */           
/* 3420 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 3423 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3427 */     else if (!_tokenSet_25.member(LA(1)) || !_tokenSet_26.member(LA(2))) {
/*      */ 
/*      */       
/* 3430 */       throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 3434 */     aST1 = aSTPair.root;
/* 3435 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void assignmentExpression() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/* 3440 */     this.returnAST = null;
/* 3441 */     ASTPair aSTPair = new ASTPair();
/* 3442 */     AST aST1 = null;
/*      */     
/* 3444 */     conditionalExpression();
/* 3445 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     
/* 3447 */     switch (LA(1)) {
/*      */ 
/*      */       
/*      */       case 85:
/*      */       case 104:
/*      */       case 105:
/*      */       case 106:
/*      */       case 107:
/*      */       case 108:
/*      */       case 109:
/*      */       case 110:
/*      */       case 111:
/*      */       case 112:
/*      */       case 113:
/*      */       case 114:
/* 3462 */         switch (LA(1)) {
/*      */           
/*      */           case 85:
/* 3465 */             aST2 = null;
/* 3466 */             aST2 = this.astFactory.create(LT(1));
/* 3467 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3468 */             match(85);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 104:
/* 3473 */             aST2 = null;
/* 3474 */             aST2 = this.astFactory.create(LT(1));
/* 3475 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3476 */             match(104);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 105:
/* 3481 */             aST2 = null;
/* 3482 */             aST2 = this.astFactory.create(LT(1));
/* 3483 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3484 */             match(105);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 106:
/* 3489 */             aST2 = null;
/* 3490 */             aST2 = this.astFactory.create(LT(1));
/* 3491 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3492 */             match(106);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 107:
/* 3497 */             aST2 = null;
/* 3498 */             aST2 = this.astFactory.create(LT(1));
/* 3499 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3500 */             match(107);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 108:
/* 3505 */             aST2 = null;
/* 3506 */             aST2 = this.astFactory.create(LT(1));
/* 3507 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3508 */             match(108);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 109:
/* 3513 */             aST2 = null;
/* 3514 */             aST2 = this.astFactory.create(LT(1));
/* 3515 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3516 */             match(109);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 110:
/* 3521 */             aST2 = null;
/* 3522 */             aST2 = this.astFactory.create(LT(1));
/* 3523 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3524 */             match(110);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 111:
/* 3529 */             aST2 = null;
/* 3530 */             aST2 = this.astFactory.create(LT(1));
/* 3531 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3532 */             match(111);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 112:
/* 3537 */             aST2 = null;
/* 3538 */             aST2 = this.astFactory.create(LT(1));
/* 3539 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3540 */             match(112);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 113:
/* 3545 */             aST2 = null;
/* 3546 */             aST2 = this.astFactory.create(LT(1));
/* 3547 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3548 */             match(113);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 114:
/* 3553 */             aST2 = null;
/* 3554 */             aST2 = this.astFactory.create(LT(1));
/* 3555 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3556 */             match(114);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 3561 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 3565 */         assignmentExpression();
/* 3566 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 45:
/*      */       case 53:
/*      */       case 78:
/*      */       case 79:
/*      */       case 82:
/*      */       case 87:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 3580 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 3584 */     aST1 = aSTPair.root;
/* 3585 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void conditionalExpression() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/* 3590 */     this.returnAST = null;
/* 3591 */     ASTPair aSTPair = new ASTPair();
/* 3592 */     AST aST1 = null;
/*      */     
/* 3594 */     logicalOrExpression();
/* 3595 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     
/* 3597 */     switch (LA(1)) {
/*      */       
/*      */       case 48:
/* 3600 */         aST2 = null;
/* 3601 */         aST2 = this.astFactory.create(LT(1));
/* 3602 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3603 */         match(48);
/* 3604 */         assignmentExpression();
/* 3605 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3606 */         match(87);
/* 3607 */         conditionalExpression();
/* 3608 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 45:
/*      */       case 53:
/*      */       case 78:
/*      */       case 79:
/*      */       case 82:
/*      */       case 85:
/*      */       case 87:
/*      */       case 104:
/*      */       case 105:
/*      */       case 106:
/*      */       case 107:
/*      */       case 108:
/*      */       case 109:
/*      */       case 110:
/*      */       case 111:
/*      */       case 112:
/*      */       case 113:
/*      */       case 114:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 3634 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 3638 */     aST1 = aSTPair.root;
/* 3639 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalOrExpression() throws RecognitionException, TokenStreamException {
/* 3644 */     this.returnAST = null;
/* 3645 */     ASTPair aSTPair = new ASTPair();
/* 3646 */     AST aST = null;
/*      */     
/* 3648 */     logicalAndExpression();
/* 3649 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 3653 */     while (LA(1) == 115) {
/* 3654 */       AST aST1 = null;
/* 3655 */       aST1 = this.astFactory.create(LT(1));
/* 3656 */       this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3657 */       match(115);
/* 3658 */       logicalAndExpression();
/* 3659 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3667 */     aST = aSTPair.root;
/* 3668 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalAndExpression() throws RecognitionException, TokenStreamException {
/* 3673 */     this.returnAST = null;
/* 3674 */     ASTPair aSTPair = new ASTPair();
/* 3675 */     AST aST = null;
/*      */     
/* 3677 */     inclusiveOrExpression();
/* 3678 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 3682 */     while (LA(1) == 116) {
/* 3683 */       AST aST1 = null;
/* 3684 */       aST1 = this.astFactory.create(LT(1));
/* 3685 */       this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3686 */       match(116);
/* 3687 */       inclusiveOrExpression();
/* 3688 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3696 */     aST = aSTPair.root;
/* 3697 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void inclusiveOrExpression() throws RecognitionException, TokenStreamException {
/* 3702 */     this.returnAST = null;
/* 3703 */     ASTPair aSTPair = new ASTPair();
/* 3704 */     AST aST = null;
/*      */     
/* 3706 */     exclusiveOrExpression();
/* 3707 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 3711 */     while (LA(1) == 117) {
/* 3712 */       AST aST1 = null;
/* 3713 */       aST1 = this.astFactory.create(LT(1));
/* 3714 */       this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3715 */       match(117);
/* 3716 */       exclusiveOrExpression();
/* 3717 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3725 */     aST = aSTPair.root;
/* 3726 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void exclusiveOrExpression() throws RecognitionException, TokenStreamException {
/* 3731 */     this.returnAST = null;
/* 3732 */     ASTPair aSTPair = new ASTPair();
/* 3733 */     AST aST = null;
/*      */     
/* 3735 */     andExpression();
/* 3736 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 3740 */     while (LA(1) == 118) {
/* 3741 */       AST aST1 = null;
/* 3742 */       aST1 = this.astFactory.create(LT(1));
/* 3743 */       this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3744 */       match(118);
/* 3745 */       andExpression();
/* 3746 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3754 */     aST = aSTPair.root;
/* 3755 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void andExpression() throws RecognitionException, TokenStreamException {
/* 3760 */     this.returnAST = null;
/* 3761 */     ASTPair aSTPair = new ASTPair();
/* 3762 */     AST aST = null;
/*      */     
/* 3764 */     equalityExpression();
/* 3765 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 3769 */     while (LA(1) == 50) {
/* 3770 */       AST aST1 = null;
/* 3771 */       aST1 = this.astFactory.create(LT(1));
/* 3772 */       this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3773 */       match(50);
/* 3774 */       equalityExpression();
/* 3775 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3783 */     aST = aSTPair.root;
/* 3784 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void equalityExpression() throws RecognitionException, TokenStreamException {
/* 3789 */     this.returnAST = null;
/* 3790 */     ASTPair aSTPair = new ASTPair();
/* 3791 */     AST aST = null;
/*      */     
/* 3793 */     relationalExpression();
/* 3794 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 3798 */     while (LA(1) == 119 || LA(1) == 120) {
/*      */       AST aST1;
/* 3800 */       switch (LA(1)) {
/*      */         
/*      */         case 119:
/* 3803 */           aST1 = null;
/* 3804 */           aST1 = this.astFactory.create(LT(1));
/* 3805 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3806 */           match(119);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 120:
/* 3811 */           aST1 = null;
/* 3812 */           aST1 = this.astFactory.create(LT(1));
/* 3813 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3814 */           match(120);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3819 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3823 */       relationalExpression();
/* 3824 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3832 */     aST = aSTPair.root;
/* 3833 */     this.returnAST = aST;
/*      */   }
/*      */   
/*      */   public final void relationalExpression() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/* 3838 */     this.returnAST = null;
/* 3839 */     ASTPair aSTPair = new ASTPair();
/* 3840 */     AST aST1 = null;
/*      */     
/* 3842 */     shiftExpression();
/* 3843 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     
/* 3845 */     switch (LA(1)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 45:
/*      */       case 47:
/*      */       case 48:
/*      */       case 50:
/*      */       case 51:
/*      */       case 53:
/*      */       case 78:
/*      */       case 79:
/*      */       case 82:
/*      */       case 85:
/*      */       case 87:
/*      */       case 104:
/*      */       case 105:
/*      */       case 106:
/*      */       case 107:
/*      */       case 108:
/*      */       case 109:
/*      */       case 110:
/*      */       case 111:
/*      */       case 112:
/*      */       case 113:
/*      */       case 114:
/*      */       case 115:
/*      */       case 116:
/*      */       case 117:
/*      */       case 118:
/*      */       case 119:
/*      */       case 120:
/*      */       case 121:
/*      */       case 122:
/* 3880 */         while (_tokenSet_27.member(LA(1))) {
/*      */           AST aST;
/* 3882 */           switch (LA(1)) {
/*      */             
/*      */             case 47:
/* 3885 */               aST = null;
/* 3886 */               aST = this.astFactory.create(LT(1));
/* 3887 */               this.astFactory.makeASTRoot(aSTPair, aST);
/* 3888 */               match(47);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 51:
/* 3893 */               aST = null;
/* 3894 */               aST = this.astFactory.create(LT(1));
/* 3895 */               this.astFactory.makeASTRoot(aSTPair, aST);
/* 3896 */               match(51);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 121:
/* 3901 */               aST = null;
/* 3902 */               aST = this.astFactory.create(LT(1));
/* 3903 */               this.astFactory.makeASTRoot(aSTPair, aST);
/* 3904 */               match(121);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 122:
/* 3909 */               aST = null;
/* 3910 */               aST = this.astFactory.create(LT(1));
/* 3911 */               this.astFactory.makeASTRoot(aSTPair, aST);
/* 3912 */               match(122);
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3917 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 3921 */           shiftExpression();
/* 3922 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 123:
/* 3934 */         aST2 = null;
/* 3935 */         aST2 = this.astFactory.create(LT(1));
/* 3936 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 3937 */         match(123);
/* 3938 */         typeSpec(true);
/* 3939 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 3944 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 3948 */     aST1 = aSTPair.root;
/* 3949 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void shiftExpression() throws RecognitionException, TokenStreamException {
/* 3954 */     this.returnAST = null;
/* 3955 */     ASTPair aSTPair = new ASTPair();
/* 3956 */     AST aST = null;
/*      */     
/* 3958 */     additiveExpression();
/* 3959 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 3963 */     while (LA(1) >= 124 && LA(1) <= 126) {
/*      */       AST aST1;
/* 3965 */       switch (LA(1)) {
/*      */         
/*      */         case 124:
/* 3968 */           aST1 = null;
/* 3969 */           aST1 = this.astFactory.create(LT(1));
/* 3970 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3971 */           match(124);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 125:
/* 3976 */           aST1 = null;
/* 3977 */           aST1 = this.astFactory.create(LT(1));
/* 3978 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3979 */           match(125);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 126:
/* 3984 */           aST1 = null;
/* 3985 */           aST1 = this.astFactory.create(LT(1));
/* 3986 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 3987 */           match(126);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3992 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3996 */       additiveExpression();
/* 3997 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4005 */     aST = aSTPair.root;
/* 4006 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void additiveExpression() throws RecognitionException, TokenStreamException {
/* 4011 */     this.returnAST = null;
/* 4012 */     ASTPair aSTPair = new ASTPair();
/* 4013 */     AST aST = null;
/*      */     
/* 4015 */     multiplicativeExpression();
/* 4016 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 4020 */     while (LA(1) == 127 || LA(1) == 128) {
/*      */       AST aST1;
/* 4022 */       switch (LA(1)) {
/*      */         
/*      */         case 127:
/* 4025 */           aST1 = null;
/* 4026 */           aST1 = this.astFactory.create(LT(1));
/* 4027 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 4028 */           match(127);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 128:
/* 4033 */           aST1 = null;
/* 4034 */           aST1 = this.astFactory.create(LT(1));
/* 4035 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 4036 */           match(128);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4041 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 4045 */       multiplicativeExpression();
/* 4046 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4054 */     aST = aSTPair.root;
/* 4055 */     this.returnAST = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void multiplicativeExpression() throws RecognitionException, TokenStreamException {
/* 4060 */     this.returnAST = null;
/* 4061 */     ASTPair aSTPair = new ASTPair();
/* 4062 */     AST aST = null;
/*      */     
/* 4064 */     unaryExpression();
/* 4065 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */     
/* 4069 */     while (_tokenSet_28.member(LA(1))) {
/*      */       AST aST1;
/* 4071 */       switch (LA(1)) {
/*      */         
/*      */         case 65:
/* 4074 */           aST1 = null;
/* 4075 */           aST1 = this.astFactory.create(LT(1));
/* 4076 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 4077 */           match(65);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 129:
/* 4082 */           aST1 = null;
/* 4083 */           aST1 = this.astFactory.create(LT(1));
/* 4084 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 4085 */           match(129);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 130:
/* 4090 */           aST1 = null;
/* 4091 */           aST1 = this.astFactory.create(LT(1));
/* 4092 */           this.astFactory.makeASTRoot(aSTPair, aST1);
/* 4093 */           match(130);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4098 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 4102 */       unaryExpression();
/* 4103 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4111 */     aST = aSTPair.root;
/* 4112 */     this.returnAST = aST;
/*      */   }
/*      */   
/*      */   public final void unaryExpression() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/* 4117 */     this.returnAST = null;
/* 4118 */     ASTPair aSTPair = new ASTPair();
/* 4119 */     AST aST1 = null;
/*      */     
/* 4121 */     switch (LA(1)) {
/*      */       
/*      */       case 131:
/* 4124 */         aST2 = null;
/* 4125 */         aST2 = this.astFactory.create(LT(1));
/* 4126 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 4127 */         match(131);
/* 4128 */         unaryExpression();
/* 4129 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4130 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 132:
/* 4135 */         aST2 = null;
/* 4136 */         aST2 = this.astFactory.create(LT(1));
/* 4137 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 4138 */         match(132);
/* 4139 */         unaryExpression();
/* 4140 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4141 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 128:
/* 4146 */         aST2 = null;
/* 4147 */         aST2 = this.astFactory.create(LT(1));
/* 4148 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 4149 */         match(128);
/* 4150 */         if (this.inputState.guessing == 0) {
/* 4151 */           aST2.setType(31);
/*      */         }
/* 4153 */         unaryExpression();
/* 4154 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4155 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 127:
/* 4160 */         aST2 = null;
/* 4161 */         aST2 = this.astFactory.create(LT(1));
/* 4162 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 4163 */         match(127);
/* 4164 */         if (this.inputState.guessing == 0) {
/* 4165 */           aST2.setType(32);
/*      */         }
/* 4167 */         unaryExpression();
/* 4168 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4169 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 81:
/*      */       case 83:
/*      */       case 84:
/*      */       case 133:
/*      */       case 134:
/*      */       case 135:
/*      */       case 136:
/*      */       case 137:
/*      */       case 138:
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/* 4198 */         unaryExpressionNotPlusMinus();
/* 4199 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4200 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 4205 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 4208 */     this.returnAST = aST1;
/*      */   }
/*      */   public final void unaryExpressionNotPlusMinus() throws RecognitionException, TokenStreamException {
/*      */     AST aST4;
/*      */     boolean bool1, bool2;
/* 4213 */     this.returnAST = null;
/* 4214 */     ASTPair aSTPair = new ASTPair();
/* 4215 */     AST aST1 = null;
/* 4216 */     Token token1 = null;
/* 4217 */     AST aST2 = null;
/* 4218 */     Token token2 = null;
/* 4219 */     AST aST3 = null;
/*      */     
/* 4221 */     switch (LA(1)) {
/*      */       
/*      */       case 133:
/* 4224 */         aST4 = null;
/* 4225 */         aST4 = this.astFactory.create(LT(1));
/* 4226 */         this.astFactory.makeASTRoot(aSTPair, aST4);
/* 4227 */         match(133);
/* 4228 */         unaryExpression();
/* 4229 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4230 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 134:
/* 4235 */         aST4 = null;
/* 4236 */         aST4 = this.astFactory.create(LT(1));
/* 4237 */         this.astFactory.makeASTRoot(aSTPair, aST4);
/* 4238 */         match(134);
/* 4239 */         unaryExpression();
/* 4240 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4241 */         aST1 = aSTPair.root;
/*      */         break;
/*      */       
/*      */       default:
/* 4245 */         bool1 = false;
/* 4246 */         if (LA(1) == 81 && LA(2) >= 54 && LA(2) <= 62) {
/* 4247 */           int i = mark();
/* 4248 */           bool1 = true;
/* 4249 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 4252 */             match(81);
/* 4253 */             builtInTypeSpec(true);
/* 4254 */             match(82);
/*      */           
/*      */           }
/* 4257 */           catch (RecognitionException recognitionException) {
/* 4258 */             bool1 = false;
/*      */           } 
/* 4260 */           rewind(i);
/* 4261 */           this.inputState.guessing--;
/*      */         } 
/* 4263 */         if (bool1) {
/* 4264 */           token1 = LT(1);
/* 4265 */           aST2 = this.astFactory.create(token1);
/* 4266 */           this.astFactory.makeASTRoot(aSTPair, aST2);
/* 4267 */           match(81);
/* 4268 */           if (this.inputState.guessing == 0) {
/* 4269 */             aST2.setType(23);
/*      */           }
/* 4271 */           builtInTypeSpec(true);
/* 4272 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4273 */           match(82);
/* 4274 */           unaryExpression();
/* 4275 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4276 */           aST1 = aSTPair.root;
/*      */           break;
/*      */         } 
/* 4279 */         bool2 = false;
/* 4280 */         if (LA(1) == 81 && LA(2) == 63) {
/* 4281 */           int i = mark();
/* 4282 */           bool2 = true;
/* 4283 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 4286 */             match(81);
/* 4287 */             classTypeSpec(true);
/* 4288 */             match(82);
/* 4289 */             unaryExpressionNotPlusMinus();
/*      */           
/*      */           }
/* 4292 */           catch (RecognitionException recognitionException) {
/* 4293 */             bool2 = false;
/*      */           } 
/* 4295 */           rewind(i);
/* 4296 */           this.inputState.guessing--;
/*      */         } 
/* 4298 */         if (bool2) {
/* 4299 */           token2 = LT(1);
/* 4300 */           aST3 = this.astFactory.create(token2);
/* 4301 */           this.astFactory.makeASTRoot(aSTPair, aST3);
/* 4302 */           match(81);
/* 4303 */           if (this.inputState.guessing == 0) {
/* 4304 */             aST3.setType(23);
/*      */           }
/* 4306 */           classTypeSpec(true);
/* 4307 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4308 */           match(82);
/* 4309 */           unaryExpressionNotPlusMinus();
/* 4310 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4311 */           aST1 = aSTPair.root; break;
/*      */         } 
/* 4313 */         if (_tokenSet_22.member(LA(1)) && _tokenSet_29.member(LA(2))) {
/* 4314 */           postfixExpression();
/* 4315 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4316 */           aST1 = aSTPair.root;
/*      */           break;
/*      */         } 
/* 4319 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 4322 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void postfixExpression() throws RecognitionException, TokenStreamException {
/* 4327 */     this.returnAST = null;
/* 4328 */     ASTPair aSTPair = new ASTPair();
/* 4329 */     AST aST1 = null;
/* 4330 */     Token token1 = null;
/* 4331 */     AST aST2 = null;
/* 4332 */     Token token2 = null;
/* 4333 */     AST aST3 = null;
/* 4334 */     Token token3 = null;
/* 4335 */     AST aST4 = null;
/* 4336 */     Token token4 = null;
/* 4337 */     AST aST5 = null;
/* 4338 */     Token token5 = null;
/* 4339 */     AST aST6 = null;
/* 4340 */     Token token6 = null;
/* 4341 */     AST aST7 = null;
/*      */     
/* 4343 */     primaryExpression();
/* 4344 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */     
/*      */     while (true) {
/* 4348 */       if (LA(1) == 64 && LA(2) == 63) {
/* 4349 */         AST aST8 = null;
/* 4350 */         aST8 = this.astFactory.create(LT(1));
/* 4351 */         this.astFactory.makeASTRoot(aSTPair, aST8);
/* 4352 */         match(64);
/* 4353 */         AST aST9 = null;
/* 4354 */         aST9 = this.astFactory.create(LT(1));
/* 4355 */         this.astFactory.addASTChild(aSTPair, aST9);
/* 4356 */         match(63);
/*      */         
/* 4358 */         switch (LA(1)) {
/*      */           
/*      */           case 81:
/* 4361 */             token1 = LT(1);
/* 4362 */             aST2 = this.astFactory.create(token1);
/* 4363 */             this.astFactory.makeASTRoot(aSTPair, aST2);
/* 4364 */             match(81);
/* 4365 */             if (this.inputState.guessing == 0) {
/* 4366 */               aST2.setType(27);
/*      */             }
/* 4368 */             argList();
/* 4369 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4370 */             match(82);
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 45:
/*      */           case 47:
/*      */           case 48:
/*      */           case 50:
/*      */           case 51:
/*      */           case 52:
/*      */           case 53:
/*      */           case 64:
/*      */           case 65:
/*      */           case 78:
/*      */           case 79:
/*      */           case 82:
/*      */           case 85:
/*      */           case 87:
/*      */           case 104:
/*      */           case 105:
/*      */           case 106:
/*      */           case 107:
/*      */           case 108:
/*      */           case 109:
/*      */           case 110:
/*      */           case 111:
/*      */           case 112:
/*      */           case 113:
/*      */           case 114:
/*      */           case 115:
/*      */           case 116:
/*      */           case 117:
/*      */           case 118:
/*      */           case 119:
/*      */           case 120:
/*      */           case 121:
/*      */           case 122:
/*      */           case 123:
/*      */           case 124:
/*      */           case 125:
/*      */           case 126:
/*      */           case 127:
/*      */           case 128:
/*      */           case 129:
/*      */           case 130:
/*      */           case 131:
/*      */           case 132:
/*      */             continue;
/*      */         } 
/*      */ 
/*      */         
/* 4421 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4426 */       if (LA(1) == 64 && LA(2) == 83) {
/* 4427 */         AST aST8 = null;
/* 4428 */         aST8 = this.astFactory.create(LT(1));
/* 4429 */         this.astFactory.makeASTRoot(aSTPair, aST8);
/* 4430 */         match(64);
/* 4431 */         AST aST9 = null;
/* 4432 */         aST9 = this.astFactory.create(LT(1));
/* 4433 */         this.astFactory.addASTChild(aSTPair, aST9);
/* 4434 */         match(83); continue;
/*      */       } 
/* 4436 */       if (LA(1) == 64 && LA(2) == 84) {
/* 4437 */         AST aST10, aST11, aST8 = null;
/* 4438 */         aST8 = this.astFactory.create(LT(1));
/* 4439 */         this.astFactory.makeASTRoot(aSTPair, aST8);
/* 4440 */         match(64);
/* 4441 */         AST aST9 = null;
/* 4442 */         aST9 = this.astFactory.create(LT(1));
/* 4443 */         this.astFactory.addASTChild(aSTPair, aST9);
/* 4444 */         match(84);
/*      */         
/* 4446 */         switch (LA(1)) {
/*      */           
/*      */           case 81:
/* 4449 */             token2 = LT(1);
/* 4450 */             aST3 = this.astFactory.create(token2);
/* 4451 */             this.astFactory.makeASTRoot(aSTPair, aST3);
/* 4452 */             match(81);
/* 4453 */             argList();
/* 4454 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4455 */             match(82);
/* 4456 */             if (this.inputState.guessing == 0) {
/* 4457 */               aST3.setType(42);
/*      */             }
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 64:
/* 4463 */             aST10 = null;
/* 4464 */             aST10 = this.astFactory.create(LT(1));
/* 4465 */             this.astFactory.makeASTRoot(aSTPair, aST10);
/* 4466 */             match(64);
/* 4467 */             aST11 = null;
/* 4468 */             aST11 = this.astFactory.create(LT(1));
/* 4469 */             this.astFactory.addASTChild(aSTPair, aST11);
/* 4470 */             match(63);
/*      */             
/* 4472 */             switch (LA(1)) {
/*      */               
/*      */               case 81:
/* 4475 */                 token3 = LT(1);
/* 4476 */                 aST4 = this.astFactory.create(token3);
/* 4477 */                 this.astFactory.makeASTRoot(aSTPair, aST4);
/* 4478 */                 match(81);
/* 4479 */                 if (this.inputState.guessing == 0) {
/* 4480 */                   aST4.setType(27);
/*      */                 }
/* 4482 */                 argList();
/* 4483 */                 this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4484 */                 match(82);
/*      */                 continue;
/*      */ 
/*      */               
/*      */               case 45:
/*      */               case 47:
/*      */               case 48:
/*      */               case 50:
/*      */               case 51:
/*      */               case 52:
/*      */               case 53:
/*      */               case 64:
/*      */               case 65:
/*      */               case 78:
/*      */               case 79:
/*      */               case 82:
/*      */               case 85:
/*      */               case 87:
/*      */               case 104:
/*      */               case 105:
/*      */               case 106:
/*      */               case 107:
/*      */               case 108:
/*      */               case 109:
/*      */               case 110:
/*      */               case 111:
/*      */               case 112:
/*      */               case 113:
/*      */               case 114:
/*      */               case 115:
/*      */               case 116:
/*      */               case 117:
/*      */               case 118:
/*      */               case 119:
/*      */               case 120:
/*      */               case 121:
/*      */               case 122:
/*      */               case 123:
/*      */               case 124:
/*      */               case 125:
/*      */               case 126:
/*      */               case 127:
/*      */               case 128:
/*      */               case 129:
/*      */               case 130:
/*      */               case 131:
/*      */               case 132:
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */             
/* 4535 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4543 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4548 */       if (LA(1) == 64 && LA(2) == 138) {
/* 4549 */         AST aST = null;
/* 4550 */         aST = this.astFactory.create(LT(1));
/* 4551 */         this.astFactory.makeASTRoot(aSTPair, aST);
/* 4552 */         match(64);
/* 4553 */         newExpression();
/* 4554 */         this.astFactory.addASTChild(aSTPair, this.returnAST); continue;
/*      */       } 
/* 4556 */       if (LA(1) == 52) {
/* 4557 */         token4 = LT(1);
/* 4558 */         aST5 = this.astFactory.create(token4);
/* 4559 */         this.astFactory.makeASTRoot(aSTPair, aST5);
/* 4560 */         match(52);
/* 4561 */         if (this.inputState.guessing == 0) {
/* 4562 */           aST5.setType(24);
/*      */         }
/* 4564 */         expression();
/* 4565 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4566 */         match(53);
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 4575 */     switch (LA(1)) {
/*      */       
/*      */       case 131:
/* 4578 */         token5 = LT(1);
/* 4579 */         aST6 = this.astFactory.create(token5);
/* 4580 */         this.astFactory.makeASTRoot(aSTPair, aST6);
/* 4581 */         match(131);
/* 4582 */         if (this.inputState.guessing == 0) {
/* 4583 */           aST6.setType(25);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 132:
/* 4589 */         token6 = LT(1);
/* 4590 */         aST7 = this.astFactory.create(token6);
/* 4591 */         this.astFactory.makeASTRoot(aSTPair, aST7);
/* 4592 */         match(132);
/* 4593 */         if (this.inputState.guessing == 0) {
/* 4594 */           aST7.setType(26);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 45:
/*      */       case 47:
/*      */       case 48:
/*      */       case 50:
/*      */       case 51:
/*      */       case 53:
/*      */       case 65:
/*      */       case 78:
/*      */       case 79:
/*      */       case 82:
/*      */       case 85:
/*      */       case 87:
/*      */       case 104:
/*      */       case 105:
/*      */       case 106:
/*      */       case 107:
/*      */       case 108:
/*      */       case 109:
/*      */       case 110:
/*      */       case 111:
/*      */       case 112:
/*      */       case 113:
/*      */       case 114:
/*      */       case 115:
/*      */       case 116:
/*      */       case 117:
/*      */       case 118:
/*      */       case 119:
/*      */       case 120:
/*      */       case 121:
/*      */       case 122:
/*      */       case 123:
/*      */       case 124:
/*      */       case 125:
/*      */       case 126:
/*      */       case 127:
/*      */       case 128:
/*      */       case 129:
/*      */       case 130:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 4642 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 4646 */     aST1 = aSTPair.root;
/* 4647 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void newExpression() throws RecognitionException, TokenStreamException {
/* 4701 */     this.returnAST = null;
/* 4702 */     ASTPair aSTPair = new ASTPair();
/* 4703 */     AST aST1 = null;
/*      */     
/* 4705 */     AST aST2 = null;
/* 4706 */     aST2 = this.astFactory.create(LT(1));
/* 4707 */     this.astFactory.makeASTRoot(aSTPair, aST2);
/* 4708 */     match(138);
/* 4709 */     type();
/* 4710 */     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */     
/* 4712 */     switch (LA(1)) {
/*      */       
/*      */       case 81:
/* 4715 */         match(81);
/* 4716 */         argList();
/* 4717 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4718 */         match(82);
/*      */         
/* 4720 */         switch (LA(1)) {
/*      */           
/*      */           case 77:
/* 4723 */             classBlock();
/* 4724 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 45:
/*      */           case 47:
/*      */           case 48:
/*      */           case 50:
/*      */           case 51:
/*      */           case 52:
/*      */           case 53:
/*      */           case 64:
/*      */           case 65:
/*      */           case 78:
/*      */           case 79:
/*      */           case 82:
/*      */           case 85:
/*      */           case 87:
/*      */           case 104:
/*      */           case 105:
/*      */           case 106:
/*      */           case 107:
/*      */           case 108:
/*      */           case 109:
/*      */           case 110:
/*      */           case 111:
/*      */           case 112:
/*      */           case 113:
/*      */           case 114:
/*      */           case 115:
/*      */           case 116:
/*      */           case 117:
/*      */           case 118:
/*      */           case 119:
/*      */           case 120:
/*      */           case 121:
/*      */           case 122:
/*      */           case 123:
/*      */           case 124:
/*      */           case 125:
/*      */           case 126:
/*      */           case 127:
/*      */           case 128:
/*      */           case 129:
/*      */           case 130:
/*      */           case 131:
/*      */           case 132:
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/* 4775 */         throw new NoViableAltException(LT(1), getFilename());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 52:
/* 4783 */         newArrayDeclarator();
/* 4784 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         
/* 4786 */         switch (LA(1)) {
/*      */           
/*      */           case 77:
/* 4789 */             arrayInitializer();
/* 4790 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 45:
/*      */           case 47:
/*      */           case 48:
/*      */           case 50:
/*      */           case 51:
/*      */           case 52:
/*      */           case 53:
/*      */           case 64:
/*      */           case 65:
/*      */           case 78:
/*      */           case 79:
/*      */           case 82:
/*      */           case 85:
/*      */           case 87:
/*      */           case 104:
/*      */           case 105:
/*      */           case 106:
/*      */           case 107:
/*      */           case 108:
/*      */           case 109:
/*      */           case 110:
/*      */           case 111:
/*      */           case 112:
/*      */           case 113:
/*      */           case 114:
/*      */           case 115:
/*      */           case 116:
/*      */           case 117:
/*      */           case 118:
/*      */           case 119:
/*      */           case 120:
/*      */           case 121:
/*      */           case 122:
/*      */           case 123:
/*      */           case 124:
/*      */           case 125:
/*      */           case 126:
/*      */           case 127:
/*      */           case 128:
/*      */           case 129:
/*      */           case 130:
/*      */           case 131:
/*      */           case 132:
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/* 4841 */         throw new NoViableAltException(LT(1), getFilename());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 4849 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */ 
/*      */     
/* 4853 */     aST1 = aSTPair.root;
/* 4854 */     this.returnAST = aST1;
/*      */   }
/*      */   
/*      */   public final void constant() throws RecognitionException, TokenStreamException {
/*      */     AST aST2;
/* 4859 */     this.returnAST = null;
/* 4860 */     ASTPair aSTPair = new ASTPair();
/* 4861 */     AST aST1 = null;
/*      */     
/* 4863 */     switch (LA(1)) {
/*      */       
/*      */       case 139:
/* 4866 */         aST2 = null;
/* 4867 */         aST2 = this.astFactory.create(LT(1));
/* 4868 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 4869 */         match(139);
/* 4870 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 140:
/* 4875 */         aST2 = null;
/* 4876 */         aST2 = this.astFactory.create(LT(1));
/* 4877 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 4878 */         match(140);
/* 4879 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 141:
/* 4884 */         aST2 = null;
/* 4885 */         aST2 = this.astFactory.create(LT(1));
/* 4886 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 4887 */         match(141);
/* 4888 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 142:
/* 4893 */         aST2 = null;
/* 4894 */         aST2 = this.astFactory.create(LT(1));
/* 4895 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 4896 */         match(142);
/* 4897 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 143:
/* 4902 */         aST2 = null;
/* 4903 */         aST2 = this.astFactory.create(LT(1));
/* 4904 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 4905 */         match(143);
/* 4906 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 144:
/* 4911 */         aST2 = null;
/* 4912 */         aST2 = this.astFactory.create(LT(1));
/* 4913 */         this.astFactory.addASTChild(aSTPair, aST2);
/* 4914 */         match(144);
/* 4915 */         aST1 = aSTPair.root;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 4920 */         throw new NoViableAltException(LT(1), getFilename());
/*      */     } 
/*      */     
/* 4923 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void newArrayDeclarator() throws RecognitionException, TokenStreamException {
/* 4928 */     this.returnAST = null;
/* 4929 */     ASTPair aSTPair = new ASTPair();
/* 4930 */     AST aST1 = null;
/* 4931 */     Token token = null;
/* 4932 */     AST aST2 = null;
/*      */ 
/*      */     
/* 4935 */     byte b = 0;
/*      */     
/*      */     while (true) {
/* 4938 */       if (LA(1) == 52 && _tokenSet_30.member(LA(2))) {
/* 4939 */         token = LT(1);
/* 4940 */         aST2 = this.astFactory.create(token);
/* 4941 */         this.astFactory.makeASTRoot(aSTPair, aST2);
/* 4942 */         match(52);
/* 4943 */         if (this.inputState.guessing == 0) {
/* 4944 */           aST2.setType(17);
/*      */         }
/*      */         
/* 4947 */         switch (LA(1)) {
/*      */           
/*      */           case 54:
/*      */           case 55:
/*      */           case 56:
/*      */           case 57:
/*      */           case 58:
/*      */           case 59:
/*      */           case 60:
/*      */           case 61:
/*      */           case 62:
/*      */           case 63:
/*      */           case 81:
/*      */           case 83:
/*      */           case 84:
/*      */           case 127:
/*      */           case 128:
/*      */           case 131:
/*      */           case 132:
/*      */           case 133:
/*      */           case 134:
/*      */           case 135:
/*      */           case 136:
/*      */           case 137:
/*      */           case 138:
/*      */           case 139:
/*      */           case 140:
/*      */           case 141:
/*      */           case 142:
/*      */           case 143:
/*      */           case 144:
/* 4978 */             expression();
/* 4979 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 53:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4988 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 4992 */         match(53);
/*      */       } else {
/*      */         
/* 4995 */         if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */       
/* 4998 */       b++;
/*      */     } 
/*      */     
/* 5001 */     aST1 = aSTPair.root;
/* 5002 */     this.returnAST = aST1;
/*      */   }
/*      */ 
/*      */   
/* 5006 */   public static final String[] _tokenNames = new String[] { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "BLOCK", "MODIFIERS", "OBJBLOCK", "SLIST", "CTOR_DEF", "METHOD_DEF", "VARIABLE_DEF", "INSTANCE_INIT", "STATIC_INIT", "TYPE", "CLASS_DEF", "INTERFACE_DEF", "PACKAGE_DEF", "ARRAY_DECLARATOR", "EXTENDS_CLAUSE", "IMPLEMENTS_CLAUSE", "PARAMETERS", "PARAMETER_DEF", "LABELED_STAT", "TYPECAST", "INDEX_OP", "POST_INC", "POST_DEC", "METHOD_CALL", "EXPR", "ARRAY_INIT", "IMPORT", "UNARY_MINUS", "UNARY_PLUS", "CASE_GROUP", "ELIST", "FOR_INIT", "FOR_CONDITION", "FOR_ITERATOR", "EMPTY_STAT", "\"final\"", "\"abstract\"", "\"strictfp\"", "SUPER_CTOR_CALL", "CTOR_CALL", "\"package\"", "SEMI", "\"import\"", "LT", "QUESTION", "\"extends\"", "BAND", "GT", "LBRACK", "RBRACK", "\"void\"", "\"boolean\"", "\"byte\"", "\"char\"", "\"short\"", "\"int\"", "\"float\"", "\"long\"", "\"double\"", "IDENT", "DOT", "STAR", "\"private\"", "\"public\"", "\"protected\"", "\"static\"", "\"transient\"", "\"native\"", "\"threadsafe\"", "\"synchronized\"", "\"volatile\"", "\"class\"", "\"interface\"", "LCURLY", "RCURLY", "COMMA", "\"implements\"", "LPAREN", "RPAREN", "\"this\"", "\"super\"", "ASSIGN", "\"throws\"", "COLON", "\"if\"", "\"else\"", "\"for\"", "\"while\"", "\"do\"", "\"break\"", "\"continue\"", "\"return\"", "\"switch\"", "\"throw\"", "\"case\"", "\"default\"", "\"try\"", "\"finally\"", "\"catch\"", "AT", "PLUS_ASSIGN", "MINUS_ASSIGN", "STAR_ASSIGN", "DIV_ASSIGN", "MOD_ASSIGN", "SR_ASSIGN", "BSR_ASSIGN", "SL_ASSIGN", "BAND_ASSIGN", "BXOR_ASSIGN", "BOR_ASSIGN", "LOR", "LAND", "BOR", "BXOR", "NOT_EQUAL", "EQUAL", "LE", "GE", "\"instanceof\"", "SL", "SR", "BSR", "PLUS", "MINUS", "DIV", "MOD", "INC", "DEC", "BNOT", "LNOT", "\"true\"", "\"false\"", "\"null\"", "\"new\"", "NUM_INT", "CHAR_LITERAL", "STRING_LITERAL", "NUM_FLOAT", "NUM_LONG", "NUM_DOUBLE", "WS", "SL_COMMENT", "ML_COMMENT", "ESC", "HEX_DIGIT", "EXPONENT", "FLOAT_SUFFIX" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void buildTokenTypeASTClassMap() {
/* 5162 */     this.tokenTypeToASTClassMap = null;
/*      */   }
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 5166 */     return new long[] { 39032662786048L, 549755822076L, 0L, 0L };
/*      */   }
/*      */   
/* 5169 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 5171 */     return new long[] { 109401406963714L, 549755822076L, 0L, 0L };
/*      */   }
/*      */   
/* 5174 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 5176 */     return new long[] { 39032662786050L, 549755822076L, 0L, 0L };
/*      */   }
/*      */   
/* 5179 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 5181 */     return new long[] { 3848290697216L, 2044L, 0L, 0L };
/*      */   }
/*      */   
/* 5184 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 5186 */     return new long[] { -18010550218784768L, 549755822076L, 0L, 0L };
/*      */   }
/*      */   
/* 5189 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 5191 */     return new long[] { -13366213103058944L, 549755953149L, 0L, 0L };
/*      */   }
/*      */   
/* 5194 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 5196 */     return new long[] { -9218727699739049984L, 1L, 0L, 0L };
/*      */   }
/*      */   
/* 5199 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 5201 */     return new long[] { 4538783999459328L, 2129920L, 0L, 0L };
/*      */   }
/*      */   
/* 5204 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 5206 */     return new long[] { -17975365846695936L, -9223371401248215044L, 131065L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5209 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 5211 */     return new long[] { -9671854033731584L, -463894577153L, 131071L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5214 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 5216 */     return new long[] { -17975365846695936L, -9223371401248231428L, 131065L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5219 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 5221 */     return new long[] { -17975365846695936L, -9223371349675053060L, 131065L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5224 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 5226 */     return new long[] { -9671854033731584L, -4554753L, 131071L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5229 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 5231 */     return new long[] { -18010550218784768L, 549755815932L, 0L, 0L };
/*      */   }
/*      */   
/* 5234 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 5236 */     return new long[] { -13366213103058944L, 549755815933L, 0L, 0L };
/*      */   }
/*      */   
/* 5239 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 5241 */     return new long[] { -18014398509481984L, -9223372036853071872L, 131065L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5244 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 5246 */     return new long[] { -9675702324428800L, -1099507826685L, 131071L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5249 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 5251 */     return new long[] { 3848290697216L, 549755817980L, 0L, 0L };
/*      */   }
/*      */   
/* 5254 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 5256 */     return new long[] { -18010550218784768L, 549755817980L, 0L, 0L };
/*      */   }
/*      */   
/* 5259 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 5261 */     return new long[] { -18014398509481984L, -9223372036853063680L, 131065L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5264 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 5266 */     return new long[] { -9675702324428800L, -1099507793917L, 131071L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5269 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 5271 */     return new long[] { -18014398509481984L, -9223372036844683264L, 131065L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5274 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 5276 */     return new long[] { -18014398509481984L, 1703936L, 130944L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5279 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */   private static final long[] mk_tokenSet_23() {
/* 5281 */     return new long[] { -13510798882111488L, -9223372036852809727L, 131065L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5284 */   public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
/*      */   private static final long[] mk_tokenSet_24() {
/* 5286 */     return new long[] { 4503599627370496L, 2228225L, 0L, 0L };
/*      */   }
/*      */   
/* 5289 */   public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
/*      */   private static final long[] mk_tokenSet_25() {
/* 5291 */     return new long[] { 17345895439794176L, -1099500830717L, 31L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5294 */   public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
/*      */   private static final long[] mk_tokenSet_26() {
/* 5296 */     return new long[] { -664654778990592L, -412321120257L, 131071L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5299 */   public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
/*      */   private static final long[] mk_tokenSet_27() {
/* 5301 */     return new long[] { 2392537302040576L, 432345564227567616L, 0L, 0L };
/*      */   }
/*      */   
/* 5304 */   public static final BitSet _tokenSet_27 = new BitSet(mk_tokenSet_27());
/*      */   private static final long[] mk_tokenSet_28() {
/* 5306 */     return new long[] { 0L, 2L, 6L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5309 */   public static final BitSet _tokenSet_28 = new BitSet(mk_tokenSet_28());
/*      */   private static final long[] mk_tokenSet_29() {
/* 5311 */     return new long[] { -668503069687808L, -1099499126781L, 131071L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5314 */   public static final BitSet _tokenSet_29 = new BitSet(mk_tokenSet_29());
/*      */   private static final long[] mk_tokenSet_30() {
/* 5316 */     return new long[] { -9007199254740992L, -9223372036853071872L, 131065L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5319 */   public static final BitSet _tokenSet_30 = new BitSet(mk_tokenSet_30());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jgram/JavaParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */