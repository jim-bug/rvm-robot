package com.jogamp.gluegen.jgram;

public interface JavaTokenTypes {
  public static final int EOF = 1;
  
  public static final int NULL_TREE_LOOKAHEAD = 3;
  
  public static final int BLOCK = 4;
  
  public static final int MODIFIERS = 5;
  
  public static final int OBJBLOCK = 6;
  
  public static final int SLIST = 7;
  
  public static final int CTOR_DEF = 8;
  
  public static final int METHOD_DEF = 9;
  
  public static final int VARIABLE_DEF = 10;
  
  public static final int INSTANCE_INIT = 11;
  
  public static final int STATIC_INIT = 12;
  
  public static final int TYPE = 13;
  
  public static final int CLASS_DEF = 14;
  
  public static final int INTERFACE_DEF = 15;
  
  public static final int PACKAGE_DEF = 16;
  
  public static final int ARRAY_DECLARATOR = 17;
  
  public static final int EXTENDS_CLAUSE = 18;
  
  public static final int IMPLEMENTS_CLAUSE = 19;
  
  public static final int PARAMETERS = 20;
  
  public static final int PARAMETER_DEF = 21;
  
  public static final int LABELED_STAT = 22;
  
  public static final int TYPECAST = 23;
  
  public static final int INDEX_OP = 24;
  
  public static final int POST_INC = 25;
  
  public static final int POST_DEC = 26;
  
  public static final int METHOD_CALL = 27;
  
  public static final int EXPR = 28;
  
  public static final int ARRAY_INIT = 29;
  
  public static final int IMPORT = 30;
  
  public static final int UNARY_MINUS = 31;
  
  public static final int UNARY_PLUS = 32;
  
  public static final int CASE_GROUP = 33;
  
  public static final int ELIST = 34;
  
  public static final int FOR_INIT = 35;
  
  public static final int FOR_CONDITION = 36;
  
  public static final int FOR_ITERATOR = 37;
  
  public static final int EMPTY_STAT = 38;
  
  public static final int FINAL = 39;
  
  public static final int ABSTRACT = 40;
  
  public static final int STRICTFP = 41;
  
  public static final int SUPER_CTOR_CALL = 42;
  
  public static final int CTOR_CALL = 43;
  
  public static final int LITERAL_package = 44;
  
  public static final int SEMI = 45;
  
  public static final int LITERAL_import = 46;
  
  public static final int LT = 47;
  
  public static final int QUESTION = 48;
  
  public static final int LITERAL_extends = 49;
  
  public static final int BAND = 50;
  
  public static final int GT = 51;
  
  public static final int LBRACK = 52;
  
  public static final int RBRACK = 53;
  
  public static final int LITERAL_void = 54;
  
  public static final int LITERAL_boolean = 55;
  
  public static final int LITERAL_byte = 56;
  
  public static final int LITERAL_char = 57;
  
  public static final int LITERAL_short = 58;
  
  public static final int LITERAL_int = 59;
  
  public static final int LITERAL_float = 60;
  
  public static final int LITERAL_long = 61;
  
  public static final int LITERAL_double = 62;
  
  public static final int IDENT = 63;
  
  public static final int DOT = 64;
  
  public static final int STAR = 65;
  
  public static final int LITERAL_private = 66;
  
  public static final int LITERAL_public = 67;
  
  public static final int LITERAL_protected = 68;
  
  public static final int LITERAL_static = 69;
  
  public static final int LITERAL_transient = 70;
  
  public static final int LITERAL_native = 71;
  
  public static final int LITERAL_threadsafe = 72;
  
  public static final int LITERAL_synchronized = 73;
  
  public static final int LITERAL_volatile = 74;
  
  public static final int LITERAL_class = 75;
  
  public static final int LITERAL_interface = 76;
  
  public static final int LCURLY = 77;
  
  public static final int RCURLY = 78;
  
  public static final int COMMA = 79;
  
  public static final int LITERAL_implements = 80;
  
  public static final int LPAREN = 81;
  
  public static final int RPAREN = 82;
  
  public static final int LITERAL_this = 83;
  
  public static final int LITERAL_super = 84;
  
  public static final int ASSIGN = 85;
  
  public static final int LITERAL_throws = 86;
  
  public static final int COLON = 87;
  
  public static final int LITERAL_if = 88;
  
  public static final int LITERAL_else = 89;
  
  public static final int LITERAL_for = 90;
  
  public static final int LITERAL_while = 91;
  
  public static final int LITERAL_do = 92;
  
  public static final int LITERAL_break = 93;
  
  public static final int LITERAL_continue = 94;
  
  public static final int LITERAL_return = 95;
  
  public static final int LITERAL_switch = 96;
  
  public static final int LITERAL_throw = 97;
  
  public static final int LITERAL_case = 98;
  
  public static final int LITERAL_default = 99;
  
  public static final int LITERAL_try = 100;
  
  public static final int LITERAL_finally = 101;
  
  public static final int LITERAL_catch = 102;
  
  public static final int AT = 103;
  
  public static final int PLUS_ASSIGN = 104;
  
  public static final int MINUS_ASSIGN = 105;
  
  public static final int STAR_ASSIGN = 106;
  
  public static final int DIV_ASSIGN = 107;
  
  public static final int MOD_ASSIGN = 108;
  
  public static final int SR_ASSIGN = 109;
  
  public static final int BSR_ASSIGN = 110;
  
  public static final int SL_ASSIGN = 111;
  
  public static final int BAND_ASSIGN = 112;
  
  public static final int BXOR_ASSIGN = 113;
  
  public static final int BOR_ASSIGN = 114;
  
  public static final int LOR = 115;
  
  public static final int LAND = 116;
  
  public static final int BOR = 117;
  
  public static final int BXOR = 118;
  
  public static final int NOT_EQUAL = 119;
  
  public static final int EQUAL = 120;
  
  public static final int LE = 121;
  
  public static final int GE = 122;
  
  public static final int LITERAL_instanceof = 123;
  
  public static final int SL = 124;
  
  public static final int SR = 125;
  
  public static final int BSR = 126;
  
  public static final int PLUS = 127;
  
  public static final int MINUS = 128;
  
  public static final int DIV = 129;
  
  public static final int MOD = 130;
  
  public static final int INC = 131;
  
  public static final int DEC = 132;
  
  public static final int BNOT = 133;
  
  public static final int LNOT = 134;
  
  public static final int LITERAL_true = 135;
  
  public static final int LITERAL_false = 136;
  
  public static final int LITERAL_null = 137;
  
  public static final int LITERAL_new = 138;
  
  public static final int NUM_INT = 139;
  
  public static final int CHAR_LITERAL = 140;
  
  public static final int STRING_LITERAL = 141;
  
  public static final int NUM_FLOAT = 142;
  
  public static final int NUM_LONG = 143;
  
  public static final int NUM_DOUBLE = 144;
  
  public static final int WS = 145;
  
  public static final int SL_COMMENT = 146;
  
  public static final int ML_COMMENT = 147;
  
  public static final int ESC = 148;
  
  public static final int HEX_DIGIT = 149;
  
  public static final int EXPONENT = 150;
  
  public static final int FLOAT_SUFFIX = 151;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/jgram/JavaTokenTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */