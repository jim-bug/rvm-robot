/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import com.jogamp.gluegen.cgram.types.AliasedSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.ArrayType;
/*     */ import com.jogamp.gluegen.cgram.types.EnumType;
/*     */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.Type;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaMethodBindingEmitter
/*     */   extends FunctionEmitter
/*     */ {
/*  60 */   public static final FunctionEmitter.EmissionModifier PUBLIC = new FunctionEmitter.EmissionModifier("public");
/*  61 */   public static final FunctionEmitter.EmissionModifier PROTECTED = new FunctionEmitter.EmissionModifier("protected");
/*  62 */   public static final FunctionEmitter.EmissionModifier PRIVATE = new FunctionEmitter.EmissionModifier("private");
/*  63 */   public static final FunctionEmitter.EmissionModifier ABSTRACT = new FunctionEmitter.EmissionModifier("abstract");
/*  64 */   public static final FunctionEmitter.EmissionModifier FINAL = new FunctionEmitter.EmissionModifier("final");
/*  65 */   public static final FunctionEmitter.EmissionModifier NATIVE = new FunctionEmitter.EmissionModifier("native");
/*  66 */   public static final FunctionEmitter.EmissionModifier SYNCHRONIZED = new FunctionEmitter.EmissionModifier("synchronized");
/*     */   
/*  68 */   protected final CommentEmitter defaultJavaCommentEmitter = new DefaultCommentEmitter();
/*  69 */   protected final CommentEmitter defaultInterfaceCommentEmitter = new InterfaceCommentEmitter();
/*     */ 
/*     */   
/*     */   protected final boolean tagNativeBinding;
/*     */ 
/*     */   
/*     */   protected final boolean useNIODirectOnly;
/*     */ 
/*     */   
/*     */   private final String runtimeExceptionType;
/*     */ 
/*     */   
/*     */   private final String unsupportedExceptionType;
/*     */ 
/*     */   
/*     */   private final boolean useNIOOnly;
/*     */ 
/*     */   
/*     */   private final boolean isNativeMethod;
/*     */ 
/*     */   
/*     */   private final boolean isUnimplemented;
/*     */ 
/*     */   
/*     */   private boolean emitBody;
/*     */ 
/*     */   
/*     */   private boolean eraseBufferAndArrayTypes;
/*     */ 
/*     */   
/*     */   private boolean isPrivateNativeMethod;
/*     */   
/*     */   private boolean forDirectBufferImplementation;
/*     */   
/*     */   private boolean forIndirectBufferAndArrayImplementation;
/*     */   
/*     */   protected List<String> prologue;
/*     */   
/*     */   protected List<String> epilogue;
/*     */   
/*     */   private String returnedArrayLengthExpression;
/*     */   
/*     */   private boolean returnedArrayLengthExpressionOnlyForComments = false;
/*     */   
/*     */   private final JavaCallbackEmitter javaCallbackEmitter;
/*     */   
/*     */   private static final String COMPOUND_ARRAY_SUFFIX = "_buf_array_copy";
/*     */ 
/*     */   
/*     */   public JavaMethodBindingEmitter(MethodBinding paramMethodBinding, CodeUnit paramCodeUnit, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, boolean paramBoolean10, boolean paramBoolean11, JavaConfiguration paramJavaConfiguration) {
/* 119 */     super(paramMethodBinding, paramCodeUnit, paramBoolean9, paramJavaConfiguration);
/* 120 */     this.runtimeExceptionType = paramString1;
/* 121 */     this.unsupportedExceptionType = paramString2;
/* 122 */     this.emitBody = paramBoolean1;
/* 123 */     this.tagNativeBinding = paramBoolean2;
/* 124 */     this.eraseBufferAndArrayTypes = paramBoolean3;
/* 125 */     this.useNIOOnly = paramBoolean4;
/* 126 */     this.useNIODirectOnly = paramBoolean5;
/* 127 */     this.forDirectBufferImplementation = paramBoolean6;
/* 128 */     this.forIndirectBufferAndArrayImplementation = paramBoolean7;
/* 129 */     this.isUnimplemented = paramBoolean8;
/* 130 */     this.isNativeMethod = paramBoolean10;
/* 131 */     this.isPrivateNativeMethod = paramBoolean11;
/* 132 */     if (paramBoolean11) {
/* 133 */       setCommentEmitter(this.defaultJavaCommentEmitter);
/*     */     } else {
/* 135 */       setCommentEmitter(this.defaultInterfaceCommentEmitter);
/*     */     } 
/* 137 */     JavaConfiguration.JavaCallbackInfo javaCallbackInfo = this.cfg.setFuncToJavaCallbackMap.get(paramMethodBinding.getName());
/* 138 */     if (null != javaCallbackInfo) {
/* 139 */       this.javaCallbackEmitter = new JavaCallbackEmitter(this.cfg, paramMethodBinding, javaCallbackInfo, appendSignature(new StringBuilder()).toString());
/*     */     } else {
/* 141 */       this.javaCallbackEmitter = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaMethodBindingEmitter(JavaMethodBindingEmitter paramJavaMethodBindingEmitter) {
/* 147 */     super(paramJavaMethodBindingEmitter);
/* 148 */     this.runtimeExceptionType = paramJavaMethodBindingEmitter.runtimeExceptionType;
/* 149 */     this.unsupportedExceptionType = paramJavaMethodBindingEmitter.unsupportedExceptionType;
/* 150 */     this.emitBody = paramJavaMethodBindingEmitter.emitBody;
/* 151 */     this.tagNativeBinding = paramJavaMethodBindingEmitter.tagNativeBinding;
/* 152 */     this.eraseBufferAndArrayTypes = paramJavaMethodBindingEmitter.eraseBufferAndArrayTypes;
/* 153 */     this.useNIOOnly = paramJavaMethodBindingEmitter.useNIOOnly;
/* 154 */     this.useNIODirectOnly = paramJavaMethodBindingEmitter.useNIODirectOnly;
/* 155 */     this.isNativeMethod = paramJavaMethodBindingEmitter.isNativeMethod;
/* 156 */     this.isPrivateNativeMethod = paramJavaMethodBindingEmitter.isPrivateNativeMethod;
/* 157 */     this.forDirectBufferImplementation = paramJavaMethodBindingEmitter.forDirectBufferImplementation;
/* 158 */     this.forIndirectBufferAndArrayImplementation = paramJavaMethodBindingEmitter.forIndirectBufferAndArrayImplementation;
/* 159 */     this.isUnimplemented = paramJavaMethodBindingEmitter.isUnimplemented;
/* 160 */     this.prologue = paramJavaMethodBindingEmitter.prologue;
/* 161 */     this.epilogue = paramJavaMethodBindingEmitter.epilogue;
/* 162 */     this.returnedArrayLengthExpression = paramJavaMethodBindingEmitter.returnedArrayLengthExpression;
/* 163 */     this.returnedArrayLengthExpressionOnlyForComments = paramJavaMethodBindingEmitter.returnedArrayLengthExpressionOnlyForComments;
/* 164 */     this.javaCallbackEmitter = paramJavaMethodBindingEmitter.javaCallbackEmitter;
/*     */   }
/*     */   
/* 167 */   public boolean isNativeMethod() { return this.isNativeMethod; }
/* 168 */   public boolean isPrivateNativeMethod() { return this.isPrivateNativeMethod; }
/* 169 */   public boolean isForDirectBufferImplementation() { return this.forDirectBufferImplementation; } public boolean isForIndirectBufferAndArrayImplementation() {
/* 170 */     return this.forIndirectBufferAndArrayImplementation;
/*     */   }
/*     */   
/*     */   public String getInterfaceName() {
/* 174 */     return this.binding.getInterfaceName();
/*     */   }
/*     */   
/*     */   public String getImplName() {
/* 178 */     return this.binding.getImplName();
/*     */   }
/*     */   
/*     */   public String getNativeName() {
/* 182 */     return this.binding.getNativeName();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunctionSymbol getCSymbol() {
/* 187 */     return this.binding.getCSymbol();
/*     */   }
/*     */   
/*     */   protected String getArgumentName(int paramInt) {
/* 191 */     return this.binding.getArgumentName(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRuntimeExceptionType() {
/* 198 */     return this.runtimeExceptionType;
/*     */   }
/*     */   
/*     */   public String getUnsupportedExceptionType() {
/* 202 */     return this.unsupportedExceptionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnedArrayLengthExpression(String paramString) {
/* 213 */     this.returnedArrayLengthExpression = paramString;
/* 214 */     this.returnedArrayLengthExpressionOnlyForComments = false;
/*     */   }
/*     */   protected void setReturnedArrayLengthExpression(String paramString, boolean paramBoolean) {
/* 217 */     this.returnedArrayLengthExpression = paramString;
/* 218 */     this.returnedArrayLengthExpressionOnlyForComments = paramBoolean;
/*     */   }
/*     */   protected String getReturnedArrayLengthExpression() {
/* 221 */     return this.returnedArrayLengthExpressionOnlyForComments ? null : this.returnedArrayLengthExpression;
/*     */   }
/*     */   protected String getReturnedArrayLengthComment() {
/* 224 */     return this.returnedArrayLengthExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrologue(List<String> paramList) {
/* 229 */     this.prologue = paramList;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEpilogue(List<String> paramList) {
/* 234 */     this.epilogue = paramList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean signatureOnly() {
/* 241 */     return !this.emitBody;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEmitBody(boolean paramBoolean) {
/* 246 */     this.emitBody = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEraseBufferAndArrayTypes(boolean paramBoolean) {
/* 251 */     this.eraseBufferAndArrayTypes = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrivateNativeMethod(boolean paramBoolean) {
/* 256 */     this.isPrivateNativeMethod = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setForDirectBufferImplementation(boolean paramBoolean) {
/* 261 */     this.forDirectBufferImplementation = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setForIndirectBufferAndArrayImplementation(boolean paramBoolean) {
/* 266 */     this.forIndirectBufferAndArrayImplementation = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringBuilder appendReturnType(StringBuilder paramStringBuilder) {
/* 271 */     return paramStringBuilder.append(getReturnTypeString(false));
/*     */   }
/*     */   
/*     */   protected String erasedTypeString(JavaType paramJavaType, boolean paramBoolean) {
/* 275 */     if (this.eraseBufferAndArrayTypes) {
/* 276 */       if (paramJavaType.isNIOBuffer()) {
/* 277 */         if (!paramBoolean)
/*     */         {
/*     */           
/* 280 */           return "Object";
/*     */         }
/* 282 */         if (!paramJavaType.isNIOByteBuffer())
/*     */         {
/* 284 */           return "ByteBuffer";
/*     */         }
/* 286 */       } else if (paramJavaType.isPrimitiveArray()) {
/* 287 */         if (!paramBoolean)
/*     */         {
/*     */           
/* 290 */           return "Object"; } 
/*     */       } else {
/* 292 */         if (paramJavaType.isNIOBufferArray())
/*     */         {
/*     */           
/* 295 */           return "Object[]"; } 
/* 296 */         if (paramJavaType.isCompoundTypeWrapper())
/*     */         {
/* 298 */           return "ByteBuffer"; } 
/* 299 */         if (paramJavaType.isArrayOfCompoundTypeWrappers()) {
/* 300 */           if (paramBoolean) {
/* 301 */             return "ByteBuffer";
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 306 */           return "ByteBuffer[]";
/*     */         } 
/*     */       } 
/*     */     }
/* 310 */     String str = paramJavaType.getName();
/* 311 */     if (null == str) {
/* 312 */       throw new IllegalArgumentException("null type name: " + paramJavaType.getDebugString());
/*     */     }
/* 314 */     int i = str.lastIndexOf('.') + 1;
/* 315 */     str = str.substring(i);
/*     */     
/* 317 */     if (paramJavaType.isArrayOfCompoundTypeWrappers())
/*     */     {
/* 319 */       return str + "[]";
/*     */     }
/* 321 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getReturnTypeString(boolean paramBoolean) {
/* 327 */     if (paramBoolean || (
/*     */       
/* 329 */       getReturnedArrayLengthExpression() == null && 
/* 330 */       !this.binding.getJavaReturnType().isArrayOfCompoundTypeWrappers()) || (this.eraseBufferAndArrayTypes && this.binding
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 335 */       .getJavaReturnType().isCompoundTypeWrapper() && 
/* 336 */       getReturnedArrayLengthExpression() != null)) {
/* 337 */       return erasedTypeString(this.binding.getJavaReturnType(), true);
/*     */     }
/* 339 */     return erasedTypeString(this.binding.getJavaReturnType(), true) + "[]";
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringBuilder appendName(StringBuilder paramStringBuilder) {
/* 344 */     if (this.isPrivateNativeMethod) {
/* 345 */       paramStringBuilder.append(getNativeImplMethodName());
/* 346 */     } else if (isInterface()) {
/* 347 */       paramStringBuilder.append(getInterfaceName());
/*     */     } else {
/* 349 */       paramStringBuilder.append(getImplName());
/*     */     } 
/* 351 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int appendArguments(StringBuilder paramStringBuilder) {
/* 356 */     boolean bool = false;
/* 357 */     int i = 0;
/*     */     
/* 359 */     if (hasModifier(NATIVE) && this.binding.isReturnCompoundByValue()) {
/* 360 */       paramStringBuilder.append("final Class<?> _clazzBuffers");
/* 361 */       i++;
/* 362 */       bool = true;
/*     */     } 
/* 364 */     if (this.isPrivateNativeMethod && this.binding.hasContainingType()) {
/*     */       
/* 366 */       if (bool) {
/* 367 */         paramStringBuilder.append(", ");
/*     */       }
/* 369 */       paramStringBuilder.append("ByteBuffer ");
/* 370 */       paramStringBuilder.append(javaThisArgumentName());
/* 371 */       i++;
/* 372 */       bool = true;
/*     */     } 
/*     */     
/* 375 */     for (byte b = 0; b < this.binding.getNumArguments(); b++) {
/* 376 */       JavaType javaType = this.binding.getJavaArgumentType(b);
/* 377 */       if (javaType.isVoid()) {
/*     */ 
/*     */         
/* 380 */         if (this.binding.getNumArguments() != 1) {
/* 381 */           throw new InternalError("\"void\" argument type found in multi-argument function \"" + this.binding + "\"");
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 388 */       else if (!javaType.isJNIEnv() && !this.binding.isArgumentThisPointer(b)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 393 */         if (bool) {
/* 394 */           paramStringBuilder.append(", ");
/*     */         }
/*     */         
/* 397 */         paramStringBuilder.append(erasedTypeString(javaType, false));
/* 398 */         paramStringBuilder.append(" ");
/* 399 */         paramStringBuilder.append(getArgumentName(b));
/*     */         
/* 401 */         i++;
/* 402 */         bool = true;
/*     */ 
/*     */         
/* 405 */         if (this.forDirectBufferImplementation || this.forIndirectBufferAndArrayImplementation) {
/* 406 */           if (javaType.isNIOBuffer()) {
/* 407 */             paramStringBuilder.append(", int " + byteOffsetArgName(b));
/* 408 */             if (!this.useNIODirectOnly) {
/* 409 */               paramStringBuilder.append(", boolean " + isNIOArgName(b));
/*     */             }
/* 411 */           } else if (javaType.isNIOBufferArray()) {
/* 412 */             paramStringBuilder.append(", int[] " + byteOffsetArrayArgName(b));
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/* 417 */         if (javaType.isPrimitiveArray()) {
/* 418 */           if (this.useNIOOnly) {
/* 419 */             throw new RuntimeException("NIO[Direct]Only " + this.binding + " is set, but " + getArgumentName(b) + " is a primitive array");
/*     */           }
/* 421 */           paramStringBuilder.append(", int " + offsetArgName(b));
/*     */         } 
/*     */       } 
/* 424 */     }  if (hasModifier(NATIVE) && null != this.javaCallbackEmitter) {
/*     */ 
/*     */       
/* 427 */       if (bool) {
/* 428 */         paramStringBuilder.append(", ");
/*     */       }
/* 430 */       i += this.javaCallbackEmitter.appendJavaAdditionalJNIParameter(paramStringBuilder);
/*     */     } 
/* 432 */     return i;
/*     */   }
/*     */   
/*     */   protected String getNativeImplMethodName() {
/* 436 */     return this.binding.getImplName() + (this.useNIODirectOnly ? "0" : "1");
/*     */   }
/*     */   
/*     */   protected String byteOffsetArgName(int paramInt) {
/* 440 */     return byteOffsetArgName(getArgumentName(paramInt));
/*     */   }
/*     */   
/*     */   protected static String byteOffsetArgName(String paramString) {
/* 444 */     return paramString + "_byte_offset";
/*     */   }
/*     */   
/*     */   protected String isNIOArgName(int paramInt) {
/* 448 */     return isNIOArgName(this.binding.getArgumentName(paramInt));
/*     */   }
/*     */   
/*     */   protected String isNIOArgName(String paramString) {
/* 452 */     return paramString + "_is_direct";
/*     */   }
/*     */   
/*     */   protected String byteOffsetArrayArgName(int paramInt) {
/* 456 */     return getArgumentName(paramInt) + "_byte_offset_array";
/*     */   }
/*     */   
/*     */   protected String offsetArgName(int paramInt) {
/* 460 */     return getArgumentName(paramInt) + "_offset";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void emitAdditionalCode() {
/* 465 */     if (null != this.javaCallbackEmitter && !this.isPrivateNativeMethod) {
/* 466 */       this.javaCallbackEmitter.emitJavaAdditionalCode(this.unit, isInterface());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void emitBody() {
/* 472 */     if (!this.emitBody) {
/* 473 */       this.unit.emitln(";");
/*     */     } else {
/* 475 */       MethodBinding methodBinding = getBinding();
/* 476 */       this.unit.emitln("  {");
/* 477 */       this.unit.emitln();
/* 478 */       if (this.isUnimplemented) {
/* 479 */         this.unit.emitln("    throw new " + getUnsupportedExceptionType() + "(\"Unimplemented\");");
/*     */       } else {
/* 481 */         emitPrologueOrEpilogue(this.prologue);
/* 482 */         emitPreCallSetup(methodBinding);
/*     */         
/* 484 */         emitReturnVariableSetupAndCall(methodBinding);
/*     */       } 
/* 486 */       this.unit.emitln("  }");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void emitPrologueOrEpilogue(List<String> paramList) {
/* 491 */     if (paramList != null) {
/* 492 */       String[] arrayOfString = argumentNameArray();
/* 493 */       for (String str : paramList) {
/*     */         try {
/* 495 */           MessageFormat messageFormat = new MessageFormat(str);
/* 496 */           this.unit.emitln("    " + messageFormat.format(arrayOfString));
/* 497 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */           
/* 499 */           this.unit.emitln("    " + str);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void emitPreCallSetup(MethodBinding paramMethodBinding) {
/* 506 */     emitArrayLengthAndNIOBufferChecks(paramMethodBinding);
/* 507 */     emitCompoundArrayCopies(paramMethodBinding);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void emitArrayLengthAndNIOBufferChecks(MethodBinding paramMethodBinding) {
/* 512 */     for (byte b = 0; b < paramMethodBinding.getNumArguments(); b++) {
/* 513 */       Type type = paramMethodBinding.getCArgumentType(b);
/* 514 */       JavaType javaType = paramMethodBinding.getJavaArgumentType(b);
/* 515 */       if (type.isArray()) {
/*     */         
/* 517 */         ArrayType arrayType = type.asArray();
/* 518 */         if (javaType.isNIOBuffer()) {
/* 519 */           this.unit.emitln("    if ( Buffers.remainingElem(" + getArgumentName(b) + ") < " + arrayType.getLength() + ")");
/*     */         } else {
/* 521 */           this.unit.emitln("    if ( " + getArgumentName(b) + ".length < " + arrayType.getLength() + ")");
/*     */         } 
/* 523 */         this.unit.emit("      throw new " + getRuntimeExceptionType() + "(\"Array \\\"" + 
/* 524 */             getArgumentName(b) + "\\\" length (\" + ");
/*     */         
/* 526 */         if (javaType.isNIOBuffer()) {
/* 527 */           this.unit.emit("Buffers.remainingElem(" + getArgumentName(b) + ")");
/*     */         } else {
/* 529 */           this.unit.emit(getArgumentName(b) + ".length");
/*     */         } 
/* 531 */         this.unit.emitln("+ \") was less than the required (" + arrayType.getLength() + ")\");");
/*     */       } 
/* 533 */       if (javaType.isNIOBuffer()) {
/* 534 */         if (this.useNIODirectOnly) {
/* 535 */           this.unit.emitln("    if (!Buffers.isDirect(" + getArgumentName(b) + "))");
/* 536 */           this.unit.emitln("      throw new " + getRuntimeExceptionType() + "(\"Argument \\\"" + 
/* 537 */               getArgumentName(b) + "\\\" is not a direct buffer\");");
/*     */         } else {
/* 539 */           this.unit.emitln("    final boolean " + isNIOArgName(b) + " = Buffers.isDirect(" + getArgumentName(b) + ");");
/*     */         } 
/* 541 */       } else if (javaType.isNIOBufferArray()) {
/*     */         
/* 543 */         String str1 = getArgumentName(b);
/* 544 */         String str2 = byteOffsetArrayArgName(b);
/* 545 */         this.unit.emitln("    final int[] " + str2 + " = new int[" + str1 + ".length];");
/*     */         
/* 547 */         this.unit.emitln("    if (" + str1 + " != null) {");
/* 548 */         this.unit.emitln("      for (int _ctr = 0; _ctr < " + str1 + ".length; _ctr++) {");
/* 549 */         this.unit.emitln("        if (!Buffers.isDirect(" + str1 + "[_ctr])) {");
/* 550 */         this.unit.emitln("          throw new " + getRuntimeExceptionType() + "(\"Element \" + _ctr + \" of argument \\\"" + 
/*     */             
/* 552 */             getArgumentName(b) + "\\\" was not a direct buffer\");");
/* 553 */         this.unit.emitln("        }");
/*     */         
/* 555 */         this.unit.emit("        " + str2 + "[_ctr] = Buffers.getDirectBufferByteOffset(");
/* 556 */         this.unit.emitln(str1 + "[_ctr]);");
/* 557 */         this.unit.emitln("      }");
/* 558 */         this.unit.emitln("    }");
/* 559 */       } else if (javaType.isPrimitiveArray()) {
/* 560 */         String str1 = getArgumentName(b);
/* 561 */         String str2 = offsetArgName(b);
/* 562 */         this.unit.emitln("    if(" + str1 + " != null && " + str1 + ".length <= " + str2 + ")");
/* 563 */         this.unit.emit("      throw new " + getRuntimeExceptionType());
/* 564 */         this.unit.emitln("(\"array offset argument \\\"" + str2 + "\\\" (\" + " + str2 + " + \") equals or exceeds array length (\" + " + str1 + ".length + \")\");");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void emitCompoundArrayCopies(MethodBinding paramMethodBinding) {
/* 574 */     if (paramMethodBinding.signatureUsesArraysOfCompoundTypeWrappers()) {
/* 575 */       for (byte b = 0; b < paramMethodBinding.getNumArguments(); b++) {
/* 576 */         JavaType javaType = paramMethodBinding.getJavaArgumentType(b);
/* 577 */         if (javaType.isArrayOfCompoundTypeWrappers()) {
/* 578 */           String str1 = getArgumentName(b);
/* 579 */           String str2 = str1 + "_buf_array_copy";
/* 580 */           this.unit.emitln("    final ByteBuffer[] " + str2 + " = new ByteBuffer[" + str1 + ".length];");
/* 581 */           this.unit.emitln("    for (int _ctr = 0; _ctr < + " + str1 + ".length; _ctr++) {");
/* 582 */           this.unit.emitln("      " + javaType.getName() + " _tmp = " + str1 + "[_ctr];");
/* 583 */           this.unit.emitln("      " + str2 + "[_ctr] = ((_tmp == null) ? null : _tmp.getBuffer());");
/* 584 */           this.unit.emitln("    }");
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void emitCall(MethodBinding paramMethodBinding) {
/* 591 */     this.unit.emit(getNativeImplMethodName());
/* 592 */     this.unit.emit("(");
/* 593 */     emitCallArguments(paramMethodBinding);
/* 594 */     this.unit.emit(");");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void emitReturnVariableSetupAndCall(MethodBinding paramMethodBinding) {
/* 599 */     JavaType javaType = paramMethodBinding.getJavaReturnType();
/*     */     
/* 601 */     boolean bool = false;
/*     */     
/* 603 */     if (null != this.javaCallbackEmitter) {
/* 604 */       this.javaCallbackEmitter.emitJavaSetFuncPreCall(this.unit);
/*     */     }
/* 606 */     if (!javaType.isVoid()) {
/* 607 */       this.unit.emit("    ");
/* 608 */       if (javaType.isCompoundTypeWrapper() || javaType
/* 609 */         .isNIOBuffer()) {
/* 610 */         this.unit.emitln("final ByteBuffer _res;");
/* 611 */         bool = true;
/* 612 */       } else if (javaType.isArrayOfCompoundTypeWrappers()) {
/* 613 */         this.unit.emitln("final ByteBuffer[] _res;");
/* 614 */         bool = true;
/* 615 */       } else if ((this.epilogue != null && this.epilogue.size() > 0) || paramMethodBinding
/* 616 */         .signatureUsesArraysOfCompoundTypeWrappers()) {
/* 617 */         this.unit.emit("final ");
/* 618 */         emitReturnType();
/* 619 */         this.unit.emitln(" _res;");
/* 620 */         bool = true;
/*     */       } 
/*     */     } 
/*     */     
/* 624 */     if (bool) {
/* 625 */       this.unit.emit("    _res = ");
/*     */     } else {
/* 627 */       this.unit.emit("    ");
/* 628 */       if (!javaType.isVoid()) {
/* 629 */         this.unit.emit("return ");
/*     */       }
/*     */     } 
/*     */     
/* 633 */     emitCall(paramMethodBinding);
/* 634 */     this.unit.emitln();
/*     */     
/* 636 */     emitPostCallCleanup(paramMethodBinding);
/* 637 */     emitPrologueOrEpilogue(this.epilogue);
/* 638 */     if (bool) {
/* 639 */       emitCallResultReturn(paramMethodBinding);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int emitCallArguments(MethodBinding paramMethodBinding) {
/* 644 */     boolean bool = false;
/* 645 */     int i = 0;
/*     */     
/* 647 */     if (paramMethodBinding.isReturnCompoundByValue()) {
/* 648 */       this.unit.emit("com.jogamp.common.nio.Buffers.class");
/* 649 */       bool = true;
/* 650 */       i++;
/*     */     } 
/* 652 */     if (paramMethodBinding.hasContainingType()) {
/*     */       
/* 654 */       assert paramMethodBinding.getContainingType().isCompoundTypeWrapper();
/* 655 */       if (bool) {
/* 656 */         this.unit.emit(", ");
/*     */       }
/* 658 */       this.unit.emit("getBuffer()");
/* 659 */       bool = true;
/* 660 */       i++;
/*     */     } 
/* 662 */     for (byte b = 0; b < paramMethodBinding.getNumArguments(); b++) {
/* 663 */       JavaType javaType = paramMethodBinding.getJavaArgumentType(b);
/* 664 */       if (!javaType.isJNIEnv() && !paramMethodBinding.isArgumentThisPointer(b))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 669 */         if (javaType.isVoid()) {
/*     */ 
/*     */           
/* 672 */           assert paramMethodBinding.getNumArguments() == 1;
/*     */         }
/*     */         else {
/*     */           
/* 676 */           if (bool) {
/* 677 */             this.unit.emit(", ");
/*     */           }
/*     */           
/* 680 */           if (javaType.isCompoundTypeWrapper()) {
/* 681 */             this.unit.emit("((");
/*     */           }
/*     */           
/* 684 */           if (javaType.isNIOBuffer()) {
/* 685 */             if (javaType.isNIOPointerBuffer()) {
/* 686 */               if (this.useNIODirectOnly) {
/* 687 */                 this.unit.emit(getArgumentName(b) + " != null ? " + getArgumentName(b) + ".getBuffer() : null");
/*     */               } else {
/* 689 */                 this.unit.emit(isNIOArgName(b) + " ? ( " + getArgumentName(b) + " != null ? " + getArgumentName(b) + ".getBuffer() : null )");
/* 690 */                 this.unit.emit(" : Buffers.getArray(" + getArgumentName(b) + ")");
/*     */               }
/*     */             
/* 693 */             } else if (this.useNIODirectOnly) {
/* 694 */               this.unit.emit(getArgumentName(b));
/*     */             } else {
/* 696 */               this.unit.emit(isNIOArgName(b) + " ? " + getArgumentName(b) + " : Buffers.getArray(" + getArgumentName(b) + ")");
/*     */             }
/*     */           
/* 699 */           } else if (javaType.isArrayOfCompoundTypeWrappers()) {
/* 700 */             this.unit.emit(getArgumentName(b) + "_buf_array_copy");
/*     */           } else {
/* 702 */             this.unit.emit(getArgumentName(b));
/*     */           } 
/*     */           
/* 705 */           if (javaType.isCompoundTypeWrapper()) {
/* 706 */             this.unit.emit(" == null) ? null : ");
/* 707 */             this.unit.emit(getArgumentName(b));
/* 708 */             this.unit.emit(".getBuffer())");
/*     */           } 
/*     */           
/* 711 */           if (javaType.isNIOBuffer()) {
/* 712 */             if (this.useNIODirectOnly) {
/* 713 */               this.unit.emit(", Buffers.getDirectBufferByteOffset(" + getArgumentName(b) + ")");
/*     */             } else {
/* 715 */               this.unit.emit(", " + isNIOArgName(b) + " ? Buffers.getDirectBufferByteOffset(" + getArgumentName(b) + ")");
/* 716 */               this.unit.emit(" : Buffers.getIndirectBufferByteOffset(" + getArgumentName(b) + ")");
/*     */             } 
/* 718 */           } else if (javaType.isNIOBufferArray()) {
/* 719 */             this.unit.emit(", " + byteOffsetArrayArgName(b));
/* 720 */           } else if (javaType.isPrimitiveArray()) {
/* 721 */             if (javaType.isFloatArray()) {
/* 722 */               this.unit.emit(", Buffers.SIZEOF_FLOAT * ");
/* 723 */             } else if (javaType.isDoubleArray()) {
/* 724 */               this.unit.emit(", Buffers.SIZEOF_DOUBLE * ");
/* 725 */             } else if (javaType.isByteArray()) {
/* 726 */               this.unit.emit(", ");
/* 727 */             } else if (javaType.isLongArray()) {
/* 728 */               this.unit.emit(", Buffers.SIZEOF_LONG * ");
/* 729 */             } else if (javaType.isShortArray()) {
/* 730 */               this.unit.emit(", Buffers.SIZEOF_SHORT * ");
/* 731 */             } else if (javaType.isIntArray()) {
/* 732 */               this.unit.emit(", Buffers.SIZEOF_INT * ");
/*     */             } else {
/* 734 */               throw new GlueGenException("Unsupported type for calculating array offset argument for " + 
/* 735 */                   getArgumentName(b) + " -- error occurred while processing Java glue code for " + 
/* 736 */                   getCSymbol().getAliasedString(), 
/* 737 */                   getCSymbol().getASTLocusTag());
/*     */             } 
/* 739 */             this.unit.emit(offsetArgName(b));
/*     */           } 
/*     */           
/* 742 */           if (javaType.isNIOBuffer()) {
/* 743 */             if (!this.useNIODirectOnly) {
/* 744 */               this.unit.emit(", " + isNIOArgName(b));
/*     */             }
/* 746 */           } else if (javaType.isPrimitiveArray()) {
/* 747 */             if (this.useNIOOnly) {
/* 748 */               throw new GlueGenException("NIO[Direct]Only " + paramMethodBinding + " is set, but " + getArgumentName(b) + " is a primitive array", 
/* 749 */                   getCSymbol().getASTLocusTag());
/*     */             }
/* 751 */             this.unit.emit(", false");
/*     */           } 
/*     */           
/* 754 */           bool = true;
/* 755 */           i++;
/*     */         }  } 
/* 757 */     }  if (null != this.javaCallbackEmitter) {
/* 758 */       if (bool) {
/* 759 */         this.unit.emit(", ");
/*     */       }
/* 761 */       StringBuilder stringBuilder = new StringBuilder();
/* 762 */       i += this.javaCallbackEmitter.appendJavaAdditionalJNIArguments(stringBuilder);
/* 763 */       this.unit.emit(stringBuilder.toString());
/*     */     } 
/* 765 */     return i;
/*     */   }
/*     */   
/*     */   protected void emitPostCallCleanup(MethodBinding paramMethodBinding) {
/* 769 */     if (paramMethodBinding.signatureUsesArraysOfCompoundTypeWrappers())
/*     */     {
/*     */ 
/*     */       
/* 773 */       for (byte b = 0; b < paramMethodBinding.getNumArguments(); b++) {
/* 774 */         JavaType javaType = paramMethodBinding.getJavaArgumentType(b);
/* 775 */         if (javaType.isArrayOfCompoundTypeWrappers() && !javaType.getElementCType().isBaseTypeConst()) {
/* 776 */           String str = paramMethodBinding.getArgumentName(b);
/* 777 */           this.unit.emitln("    for (int _ctr = 0; _ctr < " + str + ".length; _ctr++) {");
/* 778 */           this.unit.emitln("      if ((" + str + "[_ctr] == null && " + str + "_buf_array_copy" + "[_ctr] == null) ||");
/* 779 */           this.unit.emitln("          (" + str + "[_ctr] != null && " + str + "[_ctr].getBuffer() == " + str + "_buf_array_copy" + "[_ctr])) {");
/* 780 */           this.unit.emitln("        // No copy back needed");
/* 781 */           this.unit.emitln("      } else {");
/* 782 */           this.unit.emitln("        if (" + str + "_buf_array_copy" + "[_ctr] == null) {");
/* 783 */           this.unit.emitln("          " + str + "[_ctr] = null;");
/* 784 */           this.unit.emitln("        } else {");
/* 785 */           this.unit.emitln("          " + str + "[_ctr] = " + javaType.getName() + ".create(" + str + "_buf_array_copy" + "[_ctr]);");
/* 786 */           this.unit.emitln("        }");
/* 787 */           this.unit.emitln("      }");
/* 788 */           this.unit.emitln("    }");
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void emitCallResultReturn(MethodBinding paramMethodBinding) {
/* 795 */     JavaType javaType = paramMethodBinding.getJavaReturnType();
/*     */     
/* 797 */     if (javaType.isCompoundTypeWrapper()) {
/*     */       
/* 799 */       this.unit.emitln("    if (_res == null) return null;");
/* 800 */       this.unit.emitln("    return " + javaType.getName() + ".create(Buffers.nativeOrder(_res));");
/* 801 */     } else if (javaType.isNIOBuffer()) {
/* 802 */       this.unit.emitln("    if (_res == null) return null;");
/* 803 */       this.unit.emitln("    Buffers.nativeOrder(_res);");
/* 804 */       if (!javaType.isNIOByteBuffer()) {
/*     */         
/* 806 */         if (getBinding().getCReturnType().pointerDepth() >= 2) {
/* 807 */           if (javaType.isNIOPointerBuffer()) {
/* 808 */             this.unit.emitln("    return PointerBuffer.wrap(_res);");
/* 809 */           } else if (javaType.isNIOLongBuffer()) {
/* 810 */             this.unit.emitln("    return _res.asLongBuffer();");
/*     */           } else {
/* 812 */             throw new GlueGenException("While emitting glue code for " + getCSymbol().getAliasedString() + ": can not legally make pointers opaque to anything but PointerBuffer or LongBuffer/long", 
/*     */                 
/* 814 */                 getCSymbol().getASTLocusTag());
/*     */           } 
/* 816 */         } else if (getBinding().getCReturnType().pointerDepth() == 1 && javaType.isNIOLongBuffer()) {
/* 817 */           this.unit.emitln("    return _res.asLongBuffer();");
/*     */         } else {
/* 819 */           String str = javaType.getName().substring("java.nio.".length());
/* 820 */           this.unit.emitln("    return _res.as" + str + "();");
/*     */         } 
/*     */       } else {
/* 823 */         this.unit.emitln("    return _res;");
/*     */       } 
/* 825 */     } else if (javaType.isArrayOfCompoundTypeWrappers()) {
/* 826 */       this.unit.emitln("    if (_res == null) return null;");
/* 827 */       this.unit.emitln("    final " + getReturnTypeString(false) + " _retarray = new " + getReturnTypeString(true) + "[_res.length];");
/* 828 */       this.unit.emitln("    for (int _count = 0; _count < _res.length; _count++) {");
/* 829 */       this.unit.emitln("      _retarray[_count] = " + getReturnTypeString(true) + ".create(_res[_count]);");
/* 830 */       this.unit.emitln("    }");
/* 831 */       this.unit.emitln("    return _retarray;");
/*     */     }
/*     */     else {
/*     */       
/* 835 */       this.unit.emitln("    return _res;");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String[] argumentNameArray() {
/* 840 */     String[] arrayOfString = new String[this.binding.getNumArguments()];
/* 841 */     for (byte b = 0; b < this.binding.getNumArguments(); b++) {
/* 842 */       arrayOfString[b] = getArgumentName(b);
/* 843 */       if (this.binding.getJavaArgumentType(b).isPrimitiveArray())
/*     */       {
/* 845 */         arrayOfString[b] = arrayOfString[b] + ", " + offsetArgName(b);
/*     */       }
/*     */     } 
/* 848 */     return arrayOfString;
/*     */   }
/*     */   
/*     */   public static String javaThisArgumentName() {
/* 852 */     return "jthis0";
/*     */   }
/*     */   
/*     */   protected String getCommentStartString() {
/* 856 */     return "/** ";
/*     */   }
/*     */   
/*     */   protected String getCommentEndString() {
/* 860 */     StringBuilder stringBuilder = new StringBuilder();
/* 861 */     String str = this.binding.getName();
/* 862 */     List<String> list = this.cfg.javadocForMethod(str);
/* 863 */     for (Iterator<String> iterator = list.iterator(); iterator.hasNext();) {
/* 864 */       stringBuilder.append(JavaConfiguration.NEWLINE).append(getBaseIndentString()).append(iterator.next());
/*     */     }
/* 866 */     if (list.size() > 0) {
/* 867 */       stringBuilder.append(JavaConfiguration.NEWLINE).append(getBaseIndentString());
/*     */     }
/* 869 */     stringBuilder.append(" */");
/* 870 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   protected String getBaseIndentString() {
/* 874 */     return "  ";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected class DefaultCommentEmitter
/*     */     implements CommentEmitter
/*     */   {
/*     */     protected void emitAliasedDocNamesComment(AliasedSymbol param1AliasedSymbol, PrintWriter param1PrintWriter) {
/* 883 */       param1PrintWriter.print(emitAliasedDocNamesComment(param1AliasedSymbol, new StringBuilder()).toString());
/*     */     }
/*     */     protected StringBuilder emitAliasedDocNamesComment(AliasedSymbol param1AliasedSymbol, StringBuilder param1StringBuilder) {
/* 886 */       Set<String> set = JavaMethodBindingEmitter.this.cfg.getAliasedDocNames(param1AliasedSymbol);
/* 887 */       if (set != null && set.size() > 0) {
/* 888 */         byte b = 0;
/* 889 */         param1StringBuilder.append("Alias for: <code>");
/* 890 */         for (String str : set) {
/* 891 */           if (0 < b) {
/* 892 */             param1StringBuilder.append("</code>, <code>");
/*     */           }
/* 894 */           param1StringBuilder.append(str);
/* 895 */           b++;
/*     */         } 
/* 897 */         param1StringBuilder.append("</code>");
/*     */       } 
/* 899 */       return param1StringBuilder;
/*     */     }
/*     */ 
/*     */     
/*     */     public void emit(FunctionEmitter param1FunctionEmitter, PrintWriter param1PrintWriter) {
/* 904 */       emitBeginning(param1FunctionEmitter, param1PrintWriter);
/* 905 */       emitBindingCSignature(((JavaMethodBindingEmitter)param1FunctionEmitter).getBinding(), param1PrintWriter);
/* 906 */       String str = JavaMethodBindingEmitter.this.getReturnedArrayLengthComment();
/* 907 */       if (null != str) {
/* 908 */         param1PrintWriter.print(", covering an array of length <code>" + str + "</code>");
/*     */       }
/* 910 */       emitEnding(param1FunctionEmitter, param1PrintWriter);
/*     */     }
/*     */     protected void emitBeginning(FunctionEmitter param1FunctionEmitter, PrintWriter param1PrintWriter) {
/* 913 */       param1PrintWriter.print("Entry point to C language function: ");
/*     */     }
/*     */     protected void emitBindingCSignature(MethodBinding param1MethodBinding, PrintWriter param1PrintWriter) {
/* 916 */       FunctionSymbol functionSymbol = param1MethodBinding.getCSymbol();
/* 917 */       param1PrintWriter.print("<code>");
/* 918 */       param1PrintWriter.print(functionSymbol.toString(JavaMethodBindingEmitter.this.tagNativeBinding));
/* 919 */       param1PrintWriter.print("</code><br>");
/* 920 */       emitAliasedDocNamesComment((AliasedSymbol)functionSymbol, param1PrintWriter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void emitEnding(FunctionEmitter param1FunctionEmitter, PrintWriter param1PrintWriter) {
/* 927 */       MethodBinding methodBinding = ((JavaMethodBindingEmitter)param1FunctionEmitter).getBinding();
/* 928 */       for (byte b = 0; b < methodBinding.getNumArguments(); b++) {
/* 929 */         Type type = methodBinding.getCArgumentType(b);
/* 930 */         JavaType javaType = methodBinding.getJavaArgumentType(b);
/*     */ 
/*     */ 
/*     */         
/* 934 */         if (type.isEnum() && !"<anonymous>".equals(type.getName())) {
/* 935 */           EnumType enumType = (EnumType)type;
/* 936 */           param1PrintWriter.println();
/* 937 */           param1PrintWriter.print(param1FunctionEmitter.getBaseIndentString());
/* 938 */           param1PrintWriter.print("    ");
/* 939 */           param1PrintWriter.print("@param ");
/* 940 */           param1PrintWriter.print(JavaMethodBindingEmitter.this.getArgumentName(b));
/* 941 */           param1PrintWriter.print(" valid values are: <code>");
/* 942 */           for (byte b1 = 0; b1 < enumType.getNumEnumerates(); b1++) {
/* 943 */             if (b1 > 0) param1PrintWriter.print(", "); 
/* 944 */             param1PrintWriter.print(enumType.getEnum(b1).getName());
/*     */           } 
/* 946 */           param1PrintWriter.println("</code>");
/* 947 */         } else if (javaType.isNIOBuffer()) {
/* 948 */           param1PrintWriter.println();
/* 949 */           param1PrintWriter.print(param1FunctionEmitter.getBaseIndentString());
/* 950 */           param1PrintWriter.print("    ");
/* 951 */           param1PrintWriter.print("@param ");
/* 952 */           param1PrintWriter.print(JavaMethodBindingEmitter.this.getArgumentName(b));
/* 953 */           if (JavaMethodBindingEmitter.this.useNIODirectOnly) {
/* 954 */             param1PrintWriter.print(" a direct only {@link " + javaType.getName() + "}");
/*     */           } else {
/* 956 */             param1PrintWriter.print(" a direct or array-backed {@link " + javaType.getName() + "}");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected class InterfaceCommentEmitter
/*     */     extends DefaultCommentEmitter {
/*     */     protected void emitBeginning(FunctionEmitter param1FunctionEmitter, PrintWriter param1PrintWriter) {
/* 966 */       param1PrintWriter.print("Interface to C language function: <br> ");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/JavaMethodBindingEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */