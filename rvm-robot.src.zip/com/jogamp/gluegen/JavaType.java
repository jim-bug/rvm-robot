/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import com.jogamp.common.nio.NativeBuffer;
/*     */ import com.jogamp.common.nio.PointerBuffer;
/*     */ import com.jogamp.gluegen.cgram.types.Type;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaType
/*     */ {
/*     */   private final Class<?> clazz;
/*     */   private final String clazzName;
/*     */   private final String structName;
/*     */   private final Type elementType;
/*     */   private final C_PTR primitivePointerType;
/*     */   private final boolean opaqued;
/*     */   private final boolean pascalString;
/*     */   private static JavaType objectType;
/*     */   private static JavaType nioBufferType;
/*     */   private static JavaType nioByteBufferType;
/*     */   private static JavaType nioShortBufferType;
/*     */   private static JavaType nioIntBufferType;
/*     */   private static JavaType nioLongBufferType;
/*     */   private static JavaType nioPointerBufferType;
/*     */   private static JavaType nioFloatBufferType;
/*     */   private static JavaType nioDoubleBufferType;
/*     */   private static JavaType nioByteBufferArrayType;
/*     */   
/*     */   private enum C_PTR
/*     */   {
/*  59 */     VOID, CHAR, SHORT, INT32, INT64, FLOAT, DOUBLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ifnull -> 11
/*     */     //   4: aload_1
/*     */     //   5: instanceof com/jogamp/gluegen/JavaType
/*     */     //   8: ifne -> 13
/*     */     //   11: iconst_0
/*     */     //   12: ireturn
/*     */     //   13: aload_1
/*     */     //   14: checkcast com/jogamp/gluegen/JavaType
/*     */     //   17: astore_2
/*     */     //   18: aload_0
/*     */     //   19: aload_2
/*     */     //   20: if_acmpeq -> 202
/*     */     //   23: aload_2
/*     */     //   24: getfield clazz : Ljava/lang/Class;
/*     */     //   27: aload_0
/*     */     //   28: getfield clazz : Ljava/lang/Class;
/*     */     //   31: if_acmpne -> 206
/*     */     //   34: aload_0
/*     */     //   35: getfield clazzName : Ljava/lang/String;
/*     */     //   38: ifnonnull -> 51
/*     */     //   41: aload_2
/*     */     //   42: getfield clazzName : Ljava/lang/String;
/*     */     //   45: ifnonnull -> 65
/*     */     //   48: goto -> 93
/*     */     //   51: aload_0
/*     */     //   52: getfield clazzName : Ljava/lang/String;
/*     */     //   55: aload_2
/*     */     //   56: getfield clazzName : Ljava/lang/String;
/*     */     //   59: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   62: ifne -> 93
/*     */     //   65: aload_0
/*     */     //   66: getfield clazzName : Ljava/lang/String;
/*     */     //   69: ifnull -> 206
/*     */     //   72: aload_2
/*     */     //   73: getfield clazzName : Ljava/lang/String;
/*     */     //   76: ifnull -> 206
/*     */     //   79: aload_0
/*     */     //   80: getfield clazzName : Ljava/lang/String;
/*     */     //   83: aload_2
/*     */     //   84: getfield clazzName : Ljava/lang/String;
/*     */     //   87: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   90: ifeq -> 206
/*     */     //   93: aload_0
/*     */     //   94: getfield structName : Ljava/lang/String;
/*     */     //   97: ifnonnull -> 110
/*     */     //   100: aload_2
/*     */     //   101: getfield structName : Ljava/lang/String;
/*     */     //   104: ifnonnull -> 124
/*     */     //   107: goto -> 152
/*     */     //   110: aload_0
/*     */     //   111: getfield structName : Ljava/lang/String;
/*     */     //   114: aload_2
/*     */     //   115: getfield structName : Ljava/lang/String;
/*     */     //   118: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   121: ifne -> 152
/*     */     //   124: aload_0
/*     */     //   125: getfield structName : Ljava/lang/String;
/*     */     //   128: ifnull -> 206
/*     */     //   131: aload_2
/*     */     //   132: getfield structName : Ljava/lang/String;
/*     */     //   135: ifnull -> 206
/*     */     //   138: aload_0
/*     */     //   139: getfield structName : Ljava/lang/String;
/*     */     //   142: aload_2
/*     */     //   143: getfield structName : Ljava/lang/String;
/*     */     //   146: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   149: ifeq -> 206
/*     */     //   152: aload_0
/*     */     //   153: getfield elementType : Lcom/jogamp/gluegen/cgram/types/Type;
/*     */     //   156: aload_2
/*     */     //   157: getfield elementType : Lcom/jogamp/gluegen/cgram/types/Type;
/*     */     //   160: if_acmpeq -> 191
/*     */     //   163: aload_0
/*     */     //   164: getfield elementType : Lcom/jogamp/gluegen/cgram/types/Type;
/*     */     //   167: ifnull -> 206
/*     */     //   170: aload_2
/*     */     //   171: getfield elementType : Lcom/jogamp/gluegen/cgram/types/Type;
/*     */     //   174: ifnull -> 206
/*     */     //   177: aload_0
/*     */     //   178: getfield elementType : Lcom/jogamp/gluegen/cgram/types/Type;
/*     */     //   181: aload_2
/*     */     //   182: getfield elementType : Lcom/jogamp/gluegen/cgram/types/Type;
/*     */     //   185: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   188: ifeq -> 206
/*     */     //   191: aload_0
/*     */     //   192: getfield primitivePointerType : Lcom/jogamp/gluegen/JavaType$C_PTR;
/*     */     //   195: aload_2
/*     */     //   196: getfield primitivePointerType : Lcom/jogamp/gluegen/JavaType$C_PTR;
/*     */     //   199: if_acmpne -> 206
/*     */     //   202: iconst_1
/*     */     //   203: goto -> 207
/*     */     //   206: iconst_0
/*     */     //   207: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #83	-> 0
/*     */     //   #84	-> 11
/*     */     //   #86	-> 13
/*     */     //   #87	-> 18
/*     */     //   #89	-> 59
/*     */     //   #90	-> 87
/*     */     //   #92	-> 118
/*     */     //   #93	-> 146
/*     */     //   #96	-> 185
/*     */     //   #87	-> 207
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 104 */     if (this.clazz != null) {
/* 105 */       return this.clazz.hashCode();
/*     */     }
/* 107 */     if (this.clazzName != null) {
/* 108 */       return this.clazzName.hashCode();
/*     */     }
/* 110 */     if (this.structName != null) {
/* 111 */       return this.structName.hashCode();
/*     */     }
/* 113 */     if (this.elementType != null) {
/* 114 */       return this.elementType.hashCode();
/*     */     }
/* 116 */     if (this.primitivePointerType != null) {
/* 117 */       return this.primitivePointerType.hashCode();
/*     */     }
/* 119 */     return 0;
/*     */   }
/*     */   
/*     */   public JavaType getElementType() {
/* 123 */     return new JavaType(this.elementType);
/*     */   }
/*     */   public Type getElementCType() {
/* 126 */     return this.elementType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaType createForOpaqueClass(Class<?> paramClass) {
/* 134 */     return new JavaType(paramClass, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaType createForClass(Class<?> paramClass) {
/* 142 */     return new JavaType(paramClass, false, false);
/*     */   }
/*     */   
/*     */   public static JavaType createForStringClass(Class<?> paramClass, boolean paramBoolean) {
/* 146 */     return new JavaType(paramClass, false, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaType createForNamedClass(String paramString) {
/* 154 */     return new JavaType(paramString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaType createForCStruct(String paramString) {
/* 161 */     return new JavaType(null, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaType createForCArray(Type paramType) {
/* 168 */     return new JavaType(paramType);
/*     */   }
/*     */   
/*     */   public static JavaType createForCVoidPointer() {
/* 172 */     return new JavaType(C_PTR.VOID);
/*     */   }
/*     */   
/*     */   public static JavaType createForCCharPointer() {
/* 176 */     return new JavaType(C_PTR.CHAR);
/*     */   }
/*     */   
/*     */   public static JavaType createForCShortPointer() {
/* 180 */     return new JavaType(C_PTR.SHORT);
/*     */   }
/*     */   
/*     */   public static JavaType createForCInt32Pointer() {
/* 184 */     return new JavaType(C_PTR.INT32);
/*     */   }
/*     */   
/*     */   public static JavaType createForCInt64Pointer() {
/* 188 */     return new JavaType(C_PTR.INT64);
/*     */   }
/*     */   
/*     */   public static JavaType createForCFloatPointer() {
/* 192 */     return new JavaType(C_PTR.FLOAT);
/*     */   }
/*     */   
/*     */   public static JavaType createForCDoublePointer() {
/* 196 */     return new JavaType(C_PTR.DOUBLE);
/*     */   }
/*     */   
/*     */   public static JavaType createForJNIEnv() {
/* 200 */     return createForCStruct("JNIEnv");
/*     */   }
/*     */   
/*     */   public static JavaType forObjectClass() {
/* 204 */     if (objectType == null) {
/* 205 */       objectType = createForClass(Object.class);
/*     */     }
/* 207 */     return objectType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIOBufferClass() {
/* 211 */     if (nioBufferType == null) {
/* 212 */       nioBufferType = createForClass(Buffer.class);
/*     */     }
/* 214 */     return nioBufferType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIOByteBufferClass() {
/* 218 */     if (nioByteBufferType == null) {
/* 219 */       nioByteBufferType = createForClass(ByteBuffer.class);
/*     */     }
/* 221 */     return nioByteBufferType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIOShortBufferClass() {
/* 225 */     if (nioShortBufferType == null) {
/* 226 */       nioShortBufferType = createForClass(ShortBuffer.class);
/*     */     }
/* 228 */     return nioShortBufferType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIOIntBufferClass() {
/* 232 */     if (nioIntBufferType == null) {
/* 233 */       nioIntBufferType = createForClass(IntBuffer.class);
/*     */     }
/* 235 */     return nioIntBufferType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIOLongBufferClass() {
/* 239 */     if (nioLongBufferType == null) {
/* 240 */       nioLongBufferType = createForClass(LongBuffer.class);
/*     */     }
/* 242 */     return nioLongBufferType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIOPointerBufferClass() {
/* 246 */     if (nioPointerBufferType == null)
/* 247 */       nioPointerBufferType = createForClass(PointerBuffer.class); 
/* 248 */     return nioPointerBufferType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIOFloatBufferClass() {
/* 252 */     if (nioFloatBufferType == null) {
/* 253 */       nioFloatBufferType = createForClass(FloatBuffer.class);
/*     */     }
/* 255 */     return nioFloatBufferType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIODoubleBufferClass() {
/* 259 */     if (nioDoubleBufferType == null) {
/* 260 */       nioDoubleBufferType = createForClass(DoubleBuffer.class);
/*     */     }
/* 262 */     return nioDoubleBufferType;
/*     */   }
/*     */   
/*     */   public static JavaType forNIOByteBufferArrayClass() {
/* 266 */     if (nioByteBufferArrayType == null) {
/* 267 */       ByteBuffer[] arrayOfByteBuffer = new ByteBuffer[0];
/* 268 */       nioByteBufferArrayType = createForClass(arrayOfByteBuffer.getClass());
/*     */     } 
/* 270 */     return nioByteBufferArrayType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getJavaClass() {
/* 278 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 285 */     return getName(null);
/*     */   }
/*     */   
/*     */   public String getName(JavaConfiguration paramJavaConfiguration) {
/* 289 */     if (this.clazz != null) {
/* 290 */       if (this.clazz.isArray()) {
/* 291 */         return arrayName(this.clazz);
/*     */       }
/* 293 */       return this.clazz.getName();
/*     */     } 
/* 295 */     if (this.clazzName != null) {
/* 296 */       return ((null != paramJavaConfiguration) ? (paramJavaConfiguration.packageForStruct(this.clazzName) + ".") : "") + this.clazzName;
/*     */     }
/* 298 */     if (this.elementType != null) {
/* 299 */       return this.elementType.getName();
/*     */     }
/* 301 */     return ((null != paramJavaConfiguration) ? (paramJavaConfiguration.packageForStruct(this.clazzName) + ".") : "") + this.structName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescriptor() {
/* 308 */     return getDescriptor(null);
/*     */   }
/*     */   public String getDescriptor(JavaConfiguration paramJavaConfiguration) {
/* 311 */     if (this.clazz != null) {
/* 312 */       return descriptor(this.clazz);
/*     */     }
/* 314 */     if (null != this.clazzName) {
/* 315 */       return descriptor(((null != paramJavaConfiguration) ? (paramJavaConfiguration.packageForStruct(this.clazzName) + ".") : "") + this.clazzName);
/*     */     }
/* 317 */     if (null != this.structName) {
/* 318 */       return descriptor(((null != paramJavaConfiguration) ? (paramJavaConfiguration.packageForStruct(this.structName) + ".") : "") + this.structName);
/*     */     }
/* 320 */     if (this.elementType != null) {
/* 321 */       if (this.elementType.getName() == null) {
/* 322 */         throw new RuntimeException("elementType.name is null: " + getDebugString());
/*     */       }
/* 324 */       return "[" + descriptor(this.elementType.getName());
/*     */     } 
/* 326 */     return "ANON_NIO";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJNIMethodDesciptor() {
/* 342 */     return toJNIMethodDescriptor(getDescriptor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder appendDescriptor(StringBuilder paramStringBuilder, Class<?> paramClass, boolean paramBoolean) {
/* 353 */     if (paramClass.isPrimitive()) {
/* 354 */       if (paramClass == boolean.class) { paramStringBuilder.append("Z"); }
/* 355 */       else if (paramClass == byte.class) { paramStringBuilder.append("B"); }
/* 356 */       else if (paramClass == char.class) { paramStringBuilder.append("C"); }
/* 357 */       else if (paramClass == short.class) { paramStringBuilder.append("S"); }
/* 358 */       else if (paramClass == int.class) { paramStringBuilder.append("I"); }
/* 359 */       else if (paramClass == long.class) { paramStringBuilder.append("J"); }
/* 360 */       else if (paramClass == float.class) { paramStringBuilder.append("F"); }
/* 361 */       else if (paramClass == double.class) { paramStringBuilder.append("D"); }
/* 362 */       else { throw new RuntimeException("Illegal primitive type \"" + paramClass.getName() + "\"");
/*     */         
/*     */          }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 370 */     else if (paramBoolean) {
/* 371 */       if (paramClass.isArray()) {
/* 372 */         paramStringBuilder.append("[");
/* 373 */         Class<?> clazz = paramClass.getComponentType();
/*     */ 
/*     */         
/* 376 */         appendDescriptor(paramStringBuilder, clazz, (clazz == ByteBuffer.class));
/*     */       } else {
/*     */         
/* 379 */         paramStringBuilder.append("L");
/* 380 */         paramStringBuilder.append(paramClass.getName().replace('.', '/'));
/* 381 */         paramStringBuilder.append(";");
/*     */       }
/*     */     
/* 384 */     } else if (paramClass.isArray()) {
/* 385 */       paramStringBuilder.append("[");
/* 386 */       appendDescriptor(paramStringBuilder, paramClass.getComponentType(), false);
/* 387 */     } else if (paramClass == String.class) {
/* 388 */       paramStringBuilder.append("L");
/* 389 */       paramStringBuilder.append(paramClass.getName().replace('.', '/'));
/* 390 */       paramStringBuilder.append(";");
/*     */     } else {
/* 392 */       paramStringBuilder.append("Ljava/lang/Object;");
/*     */     } 
/*     */ 
/*     */     
/* 396 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder appendJNIDescriptor(StringBuilder paramStringBuilder, Class<?> paramClass, boolean paramBoolean) {
/* 417 */     int i = paramStringBuilder.length();
/* 418 */     return toJNIMethodDescriptor(appendDescriptor(paramStringBuilder, paramClass, paramBoolean), i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJNIMethodDescriptor(String paramString) {
/* 434 */     return paramString.replace("_", "_1")
/* 435 */       .replace("/", "_")
/* 436 */       .replace(";", "_2")
/* 437 */       .replace("[", "_3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder toJNIMethodDescriptor(StringBuilder paramStringBuilder, int paramInt) {
/* 455 */     replace(paramStringBuilder, paramInt, "_", "_1");
/* 456 */     replace(paramStringBuilder, paramInt, "/", "_");
/* 457 */     replace(paramStringBuilder, paramInt, ";", "_2");
/* 458 */     replace(paramStringBuilder, paramInt, "[", "_3");
/* 459 */     return paramStringBuilder;
/*     */   }
/*     */   private static StringBuilder replace(StringBuilder paramStringBuilder, int paramInt, String paramString1, String paramString2) {
/* 462 */     paramInt = paramStringBuilder.indexOf(paramString1, paramInt);
/* 463 */     while (0 <= paramInt) {
/* 464 */       paramStringBuilder.replace(paramInt, paramInt + paramString1.length(), paramString2);
/* 465 */       paramInt = paramStringBuilder.indexOf(paramString1, paramInt + paramString2.length());
/*     */     } 
/* 467 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String jniTypeName() {
/* 474 */     if (isCompoundTypeWrapper())
/*     */     {
/* 476 */       return "jobject";
/*     */     }
/*     */     
/* 479 */     if (isArrayOfCompoundTypeWrappers())
/*     */     {
/* 481 */       return "jobjectArray /* of ByteBuffer */";
/*     */     }
/*     */     
/* 484 */     if (this.clazzName != null) {
/* 485 */       return "jobject";
/*     */     }
/*     */     
/* 488 */     if (this.clazz == null) {
/* 489 */       return null;
/*     */     }
/*     */     
/* 492 */     if (isVoid()) {
/* 493 */       return "void";
/*     */     }
/*     */     
/* 496 */     if (isPrimitive()) {
/* 497 */       return "j" + this.clazz.getName();
/*     */     }
/*     */     
/* 500 */     if (isPrimitiveArray() || isNIOBuffer())
/*     */     {
/* 502 */       return "jobject";
/*     */     }
/*     */     
/* 505 */     if (isArray()) {
/* 506 */       if (isStringArray()) {
/* 507 */         return "jobjectArray /*elements are String*/";
/*     */       }
/*     */       
/* 510 */       Class<?> clazz = this.clazz.getComponentType();
/*     */       
/* 512 */       if (isNIOBufferArray()) {
/* 513 */         return "jobjectArray /*elements are " + clazz.getName() + "*/";
/*     */       }
/*     */       
/* 516 */       if (clazz.isArray()) {
/*     */ 
/*     */         
/* 519 */         if (clazz.getComponentType().isPrimitive())
/*     */         {
/* 521 */           return "jobjectArray /* elements are " + clazz.getComponentType() + "[]*/";
/*     */         }
/*     */         
/* 524 */         throw new RuntimeException("Multi-dimensional arrays of types that are not primitives or Strings are not supported.");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 529 */       throw new RuntimeException("Unexpected and unsupported array type: \"" + this + "\"");
/*     */     } 
/*     */     
/* 532 */     if (isString()) {
/* 533 */       return "jstring";
/*     */     }
/*     */     
/* 536 */     return "jobject";
/*     */   }
/*     */   public boolean isOpaqued() {
/* 539 */     return this.opaqued;
/*     */   }
/*     */   public boolean isNIOBuffer() {
/* 542 */     return (this.clazz != null && (Buffer.class.isAssignableFrom(this.clazz) || NativeBuffer.class
/* 543 */       .isAssignableFrom(this.clazz)));
/*     */   }
/*     */   
/*     */   public boolean isNIOByteBuffer() {
/* 547 */     return (this.clazz == ByteBuffer.class);
/*     */   }
/*     */   
/*     */   public boolean isNIOByteBufferArray() {
/* 551 */     return (this == nioByteBufferArrayType);
/*     */   }
/*     */   
/*     */   public boolean isNIOBufferArray() {
/* 555 */     return (isArray() && Buffer.class.isAssignableFrom(this.clazz.getComponentType()));
/*     */   }
/*     */   
/*     */   public boolean isNIOLongBuffer() {
/* 559 */     return (this.clazz == LongBuffer.class);
/*     */   }
/*     */   
/*     */   public boolean isNIOPointerBuffer() {
/* 563 */     return (this.clazz == PointerBuffer.class);
/*     */   }
/*     */   
/*     */   public boolean isString() {
/* 567 */     return (this.clazz == String.class);
/*     */   }
/*     */   public boolean isPascalStringVariant() {
/* 570 */     return this.pascalString;
/*     */   }
/*     */   public boolean isPascalString() {
/* 573 */     return (isString() && this.pascalString);
/*     */   }
/*     */   
/*     */   public boolean isArray() {
/* 577 */     return (this.clazz != null && this.clazz.isArray());
/*     */   }
/*     */   
/*     */   public boolean isFloatArray() {
/* 581 */     return (this.clazz != null && this.clazz.isArray() && this.clazz.getComponentType() == float.class);
/*     */   }
/*     */   
/*     */   public boolean isDoubleArray() {
/* 585 */     return (this.clazz != null && this.clazz.isArray() && this.clazz.getComponentType() == double.class);
/*     */   }
/*     */   
/*     */   public boolean isByteArray() {
/* 589 */     return (this.clazz != null && this.clazz.isArray() && this.clazz.getComponentType() == byte.class);
/*     */   }
/*     */   
/*     */   public boolean isIntArray() {
/* 593 */     return (this.clazz != null && this.clazz.isArray() && this.clazz.getComponentType() == int.class);
/*     */   }
/*     */   
/*     */   public boolean isShortArray() {
/* 597 */     return (this.clazz != null && this.clazz.isArray() && this.clazz.getComponentType() == short.class);
/*     */   }
/*     */   
/*     */   public boolean isLongArray() {
/* 601 */     return (this.clazz != null && this.clazz.isArray() && this.clazz.getComponentType() == long.class);
/*     */   }
/*     */   
/*     */   public boolean isStringArray() {
/* 605 */     return (this.clazz != null && this.clazz.isArray() && this.clazz.getComponentType() == String.class);
/*     */   }
/*     */   
/*     */   public boolean isPascalStringArray() {
/* 609 */     return (isStringArray() && this.pascalString);
/*     */   }
/*     */   
/*     */   public boolean isPrimitive() {
/* 613 */     return (this.clazz != null && !isArray() && this.clazz.isPrimitive() && this.clazz != void.class);
/*     */   }
/*     */   
/*     */   public boolean isPrimitiveArray() {
/* 617 */     return (isArray() && this.clazz.getComponentType().isPrimitive());
/*     */   }
/*     */   
/*     */   public boolean isShort() {
/* 621 */     return (this.clazz == short.class);
/*     */   }
/*     */   
/*     */   public boolean isFloat() {
/* 625 */     return (this.clazz == float.class);
/*     */   }
/*     */   
/*     */   public boolean isDouble() {
/* 629 */     return (this.clazz == double.class);
/*     */   }
/*     */   
/*     */   public boolean isByte() {
/* 633 */     return (this.clazz == byte.class);
/*     */   }
/*     */   
/*     */   public boolean isLong() {
/* 637 */     return (this.clazz == long.class);
/*     */   }
/*     */   
/*     */   public boolean isInt() {
/* 641 */     return (this.clazz == int.class);
/*     */   }
/*     */   
/*     */   public boolean isVoid() {
/* 645 */     return (this.clazz == void.class);
/*     */   }
/*     */   
/*     */   public boolean isNamedClass() {
/* 649 */     return (this.clazzName != null);
/*     */   }
/*     */   
/*     */   public boolean isCompoundTypeWrapper() {
/* 653 */     return (this.structName != null && !isJNIEnv());
/*     */   }
/*     */   
/*     */   public boolean isArrayOfCompoundTypeWrappers() {
/* 657 */     return (this.elementType != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCPrimitivePointerType() {
/* 662 */     return (this.primitivePointerType != null);
/*     */   }
/*     */   
/*     */   public boolean isCVoidPointerType() {
/* 666 */     return C_PTR.VOID.equals(this.primitivePointerType);
/*     */   }
/*     */   
/*     */   public boolean isCCharPointerType() {
/* 670 */     return C_PTR.CHAR.equals(this.primitivePointerType);
/*     */   }
/*     */   
/*     */   public boolean isCShortPointerType() {
/* 674 */     return C_PTR.SHORT.equals(this.primitivePointerType);
/*     */   }
/*     */   
/*     */   public boolean isCInt32PointerType() {
/* 678 */     return C_PTR.INT32.equals(this.primitivePointerType);
/*     */   }
/*     */   
/*     */   public boolean isCInt64PointerType() {
/* 682 */     return C_PTR.INT64.equals(this.primitivePointerType);
/*     */   }
/*     */   
/*     */   public boolean isCFloatPointerType() {
/* 686 */     return C_PTR.FLOAT.equals(this.primitivePointerType);
/*     */   }
/*     */   
/*     */   public boolean isCDoublePointerType() {
/* 690 */     return C_PTR.DOUBLE.equals(this.primitivePointerType);
/*     */   }
/*     */   
/*     */   public boolean isJNIEnv() {
/* 694 */     return "JNIEnv".equals(this.structName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 699 */     return new JavaType(this.primitivePointerType, this.clazz, this.clazzName, this.structName, this.elementType, this.pascalString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 704 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void append(StringBuilder paramStringBuilder, String paramString, boolean paramBoolean) {
/* 712 */     if (paramBoolean) {
/* 713 */       paramStringBuilder.append(", ");
/*     */     }
/* 715 */     paramStringBuilder.append(paramString);
/*     */   }
/*     */   public final StringBuilder getSignature(StringBuilder paramStringBuilder) {
/* 718 */     if (null == paramStringBuilder) {
/* 719 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 721 */     boolean bool = false;
/*     */     
/* 723 */     String str = getName();
/* 724 */     if (null != str) {
/* 725 */       append(paramStringBuilder, str, false);
/*     */     } else {
/* 727 */       append(paramStringBuilder, "ANON", false);
/*     */     } 
/*     */     
/* 730 */     if (null != this.clazz) {
/* 731 */       append(paramStringBuilder, "clazz = " + this.clazz.getName(), bool); bool = true;
/*     */     } 
/* 733 */     if (null != this.clazzName) {
/* 734 */       append(paramStringBuilder, "clazzName = " + this.clazzName, bool); bool = true;
/*     */     } 
/* 736 */     if (null != this.structName) {
/* 737 */       append(paramStringBuilder, "struct = " + this.structName, bool); bool = true;
/*     */     } 
/* 739 */     if (null != this.elementType) {
/* 740 */       append(paramStringBuilder, "elementType = " + this.elementType, bool); bool = true;
/*     */     } 
/* 742 */     if (null != this.primitivePointerType) {
/* 743 */       append(paramStringBuilder, "primitivePointerType = " + this.primitivePointerType, bool); bool = true;
/*     */     } 
/* 745 */     append(paramStringBuilder, "is[", bool); bool = false;
/*     */     
/* 747 */     if (isOpaqued()) {
/* 748 */       append(paramStringBuilder, "opaque", bool); bool = true;
/*     */     } 
/* 750 */     if (isString()) {
/* 751 */       if (this.pascalString) {
/* 752 */         paramStringBuilder.append("pascal ");
/*     */       }
/* 754 */       append(paramStringBuilder, "string", bool); bool = true;
/*     */     } 
/* 756 */     if (isStringArray()) {
/* 757 */       if (this.pascalString) {
/* 758 */         paramStringBuilder.append("pascal ");
/*     */       }
/* 760 */       append(paramStringBuilder, "stringArray", bool); bool = true;
/* 761 */     } else if (isArray()) {
/* 762 */       append(paramStringBuilder, "array", bool); bool = true;
/*     */     } 
/* 764 */     if (isArrayOfCompoundTypeWrappers()) {
/* 765 */       append(paramStringBuilder, "compoundArray", bool); bool = true;
/*     */     } 
/* 767 */     if (isCompoundTypeWrapper()) {
/* 768 */       append(paramStringBuilder, "compound", bool); bool = true;
/*     */     } 
/* 770 */     if (isPrimitive()) {
/* 771 */       append(paramStringBuilder, "primitive", bool); bool = true;
/*     */     } 
/* 773 */     if (isPrimitiveArray()) {
/* 774 */       append(paramStringBuilder, "primitiveArray", bool); bool = true;
/*     */     } 
/* 776 */     if (isNIOBuffer()) {
/* 777 */       append(paramStringBuilder, "nioBuffer", bool); bool = true;
/*     */     } 
/* 779 */     if (isNIOBufferArray()) {
/* 780 */       append(paramStringBuilder, "nioBufferArray", bool); bool = true;
/*     */     } 
/* 782 */     if (isCPrimitivePointerType()) {
/* 783 */       append(paramStringBuilder, "C-Primitive-Pointer", bool); bool = true;
/*     */     } 
/*     */     
/* 786 */     append(paramStringBuilder, "], descriptor '" + getDescriptor() + "'", false); bool = true;
/* 787 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDebugString() {
/* 792 */     StringBuilder stringBuilder = new StringBuilder();
/* 793 */     stringBuilder.append("JType[");
/* 794 */     getSignature(stringBuilder);
/* 795 */     stringBuilder.append("]");
/* 796 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JavaType(Class<?> paramClass, boolean paramBoolean1, boolean paramBoolean2) {
/* 804 */     if (null == paramClass) {
/* 805 */       throw new IllegalArgumentException("null clazz passed");
/*     */     }
/* 807 */     this.primitivePointerType = null;
/* 808 */     this.clazz = paramClass;
/* 809 */     this.clazzName = null;
/* 810 */     this.structName = null;
/* 811 */     this.elementType = null;
/* 812 */     this.opaqued = paramBoolean1;
/* 813 */     this.pascalString = paramBoolean2;
/*     */   }
/*     */ 
/*     */   
/*     */   private JavaType(String paramString1, String paramString2) {
/* 818 */     if (null != paramString1 && null != paramString2) {
/* 819 */       throw new IllegalArgumentException("Both clazzName and structName set");
/*     */     }
/* 821 */     if (null != paramString1) {
/* 822 */       this.clazzName = paramString1;
/* 823 */       this.structName = null;
/* 824 */     } else if (null != paramString2) {
/* 825 */       this.clazzName = null;
/* 826 */       this.structName = paramString2;
/*     */     } else {
/* 828 */       throw new IllegalArgumentException("Neither clazzName nor structName set");
/*     */     } 
/* 830 */     this.primitivePointerType = null;
/* 831 */     this.clazz = null;
/* 832 */     this.elementType = null;
/* 833 */     this.opaqued = false;
/* 834 */     this.pascalString = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JavaType(C_PTR paramC_PTR) {
/* 840 */     if (null == paramC_PTR) {
/* 841 */       throw new IllegalArgumentException("null primitivePointerType passed");
/*     */     }
/* 843 */     this.primitivePointerType = paramC_PTR;
/* 844 */     this.clazz = null;
/* 845 */     this.clazzName = null;
/* 846 */     this.structName = null;
/* 847 */     this.elementType = null;
/* 848 */     this.opaqued = false;
/* 849 */     this.pascalString = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private JavaType(Type paramType) {
/* 854 */     if (null == paramType) {
/* 855 */       throw new IllegalArgumentException("null elementType passed");
/*     */     }
/* 857 */     this.primitivePointerType = null;
/* 858 */     this.clazz = null;
/* 859 */     this.clazzName = null;
/* 860 */     this.structName = null;
/* 861 */     this.elementType = paramType;
/* 862 */     this.opaqued = false;
/* 863 */     this.pascalString = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private JavaType(C_PTR paramC_PTR, Class<?> paramClass, String paramString1, String paramString2, Type paramType, boolean paramBoolean) {
/* 868 */     this.primitivePointerType = paramC_PTR;
/* 869 */     this.clazz = paramClass;
/* 870 */     this.clazzName = paramString1;
/* 871 */     this.structName = paramString2;
/* 872 */     this.elementType = paramType;
/* 873 */     this.opaqued = false;
/* 874 */     this.pascalString = paramBoolean;
/*     */   }
/*     */   
/*     */   private static String arrayName(Class<?> paramClass) {
/* 878 */     StringBuilder stringBuilder = new StringBuilder();
/* 879 */     byte b = 0;
/* 880 */     while (paramClass.isArray()) {
/* 881 */       b++;
/* 882 */       paramClass = paramClass.getComponentType();
/*     */     } 
/* 884 */     stringBuilder.append(paramClass.getName());
/* 885 */     while (--b >= 0) {
/* 886 */       stringBuilder.append("[]");
/*     */     }
/* 888 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   private static String arrayDescriptor(Class<?> paramClass) {
/* 892 */     StringBuilder stringBuilder = new StringBuilder();
/* 893 */     while (paramClass.isArray()) {
/* 894 */       stringBuilder.append("[");
/* 895 */       paramClass = paramClass.getComponentType();
/*     */     } 
/* 897 */     stringBuilder.append(descriptor(paramClass));
/* 898 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   private static String descriptor(Class<?> paramClass) {
/* 902 */     if (paramClass.isPrimitive()) {
/* 903 */       if (paramClass == boolean.class) return "Z"; 
/* 904 */       if (paramClass == byte.class) return "B"; 
/* 905 */       if (paramClass == double.class) return "D"; 
/* 906 */       if (paramClass == float.class) return "F"; 
/* 907 */       if (paramClass == int.class) return "I"; 
/* 908 */       if (paramClass == long.class) return "J"; 
/* 909 */       if (paramClass == short.class) return "S"; 
/* 910 */       if (paramClass == void.class) return "V"; 
/* 911 */       throw new RuntimeException("Unexpected primitive type " + paramClass.getName());
/*     */     } 
/* 913 */     if (paramClass.isArray()) {
/* 914 */       return arrayDescriptor(paramClass);
/*     */     }
/* 916 */     return descriptor(paramClass.getName());
/*     */   }
/*     */   
/*     */   private static String descriptor(String paramString) {
/* 920 */     return "L" + paramString.replace('.', '/') + ";";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/JavaType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */