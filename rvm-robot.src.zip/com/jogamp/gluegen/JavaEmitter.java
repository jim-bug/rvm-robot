/*      */ package com.jogamp.gluegen;
/*      */ 
/*      */ import com.jogamp.common.nio.Buffers;
/*      */ import com.jogamp.common.os.DynamicLookupHelper;
/*      */ import com.jogamp.common.os.MachineDataInfo;
/*      */ import com.jogamp.common.util.ArrayHashMap;
/*      */ import com.jogamp.common.util.HashUtil;
/*      */ import com.jogamp.gluegen.cgram.types.AliasedSymbol;
/*      */ import com.jogamp.gluegen.cgram.types.ArrayType;
/*      */ import com.jogamp.gluegen.cgram.types.CompoundType;
/*      */ import com.jogamp.gluegen.cgram.types.Field;
/*      */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*      */ import com.jogamp.gluegen.cgram.types.FunctionType;
/*      */ import com.jogamp.gluegen.cgram.types.PointerType;
/*      */ import com.jogamp.gluegen.cgram.types.SizeThunk;
/*      */ import com.jogamp.gluegen.cgram.types.StructLayout;
/*      */ import com.jogamp.gluegen.cgram.types.Type;
/*      */ import com.jogamp.gluegen.cgram.types.TypeComparator;
/*      */ import com.jogamp.gluegen.cgram.types.TypeDictionary;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.logging.Level;
/*      */ import jogamp.common.os.MachineDataInfoRuntime;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JavaEmitter
/*      */   implements GlueEmitter
/*      */ {
/*      */   private StructLayout layout;
/*      */   private Map<Type, Type> canonMap;
/*      */   protected JavaConfiguration cfg;
/*      */   private JavaCodeUnit javaUnit;
/*      */   private JavaCodeUnit javaImplUnit;
/*      */   private CCodeUnit cUnit;
/*      */   
/*      */   public enum EmissionStyle
/*      */   {
/*  119 */     AllStatic, InterfaceAndImpl, InterfaceOnly, ImplOnly;
/*      */   }
/*      */ 
/*      */   
/*      */   public enum MethodAccess
/*      */   {
/*  125 */     PUBLIC("public"), PROTECTED("protected"), PRIVATE("private"), PACKAGE_PRIVATE("/* pp */"), PUBLIC_ABSTRACT("abstract"); private final String javaName;
/*      */     public final String getJavaName() {
/*  127 */       return this.javaName;
/*      */     }
/*      */     MethodAccess(String param1String1) {
/*  130 */       this.javaName = param1String1;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Ownership
/*      */   {
/*  140 */     Parent,
/*      */     
/*  142 */     Java,
/*      */     
/*  144 */     Native,
/*      */     
/*  146 */     Mixed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  152 */   private final MachineDataInfo machDescJava = MachineDataInfo.StaticConfig.LP64_UNIX.md;
/*  153 */   private final MachineDataInfo.StaticConfig[] machDescTargetConfigs = MachineDataInfo.StaticConfig.values(); protected final Logging.LoggerIf LOG; private final Map<String, ConstantDefinition.JavaExpr> constMap; private final Map<String, JavaConfiguration.JavaCallbackInfo> javaCallbackInterfaceMap; private static final String GetElemValueApiDocTail = "@return element value of the corresponding field-array"; private static final String GetElemCountApiDocTail = "@return element count of the corresponding field-array"; private static final String SetSubArrayArgsPost = "final int srcPos, final int destPos, final int length"; private static final String SetSubArrayArgsCheck = "    if( 0 > srcPos || 0 > destPos || 0 > length || srcPos + length > src.length ) { throw new IndexOutOfBoundsException(\"src[pos \"+srcPos+\", length \"+src.length+\"], destPos \"+destPos+\", length \"+length); }"; private static final String SetSubArrayApiDocDetail = "Copies the given source elements into the respective field's existing memory."; private static final String SetSubArrayApiDocArgs = "   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param destPos starting element position within the destination with 'destPos >= 0` && `destPos + length <= elemCount`, otherwise an exception is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length` && `destPos + length <= elemCount`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining"; private static final String SetArrayArgsPre = "final boolean subset"; private static final String SetArrayArgsPost = "final int srcPos, final int destPos, final int length"; private static final String SetArrayArgsCheck = "    if( 0 > srcPos || 0 > destPos || 0 > length || srcPos + length > src.length ) { throw new IndexOutOfBoundsException(\"subset \"+subset+\", src[pos \"+srcPos+\", length \"+src.length+\"], destPos \"+destPos+\", length \"+length); }"; private static final String SetArrayApiDocDetail = "Copies the given source elements into the respective field, either writing into the existing memory or creating a new memory and referencing it."; private static final String SetArrayApiDocArgs = "   * @param subset if `true` keeps the underlying memory and only allows to set up to `elemCount` elements. Otherwise may replace the underlying memory if `destPos + length != elemCount`.\n   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param destPos starting element position within the destination with 'destPos >= 0`. If `subset == true`, `destPos + length <= elemCount` also must be be `true`. Otherwise an exception is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining"; private static final String SetReplaceArrayArgsPost = "final int srcPos, final int length"; private static final String SetReplaceArrayArgsCheck = "    if( 0 > srcPos || 0 > length || srcPos + length > src.length ) { throw new IndexOutOfBoundsException(\"src[pos \"+srcPos+\", length \"+src.length+\"], length \"+length); }";
/*      */   private static final String SetReplaceArrayApiDocDetail = "Replaces the respective field's memory with a new memory segment containing given source elements and referencing it.";
/*      */   private static final String SetReplaceArrayApiDocArgs = "   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining";
/*      */   private static final String GetArrayArgs = "final int destPos, final int length";
/*      */   private static final String GetArrayArgsCheck = "    if( 0 > srcPos || 0 > destPos || 0 > length || destPos + length > dest.length ) { throw new IndexOutOfBoundsException(\"dest[pos \"+destPos+\", length \"+dest.length+\"], srcPos \"+srcPos+\", length \"+length); }";
/*      */   private static final String optStringCharsetCode = "  private static Charset _charset = StandardCharsets.UTF_8;\n\n  /** Returns the Charset for this class's String mapping, default is StandardCharsets.UTF_8. */\n  public static Charset getCharset() { return _charset; };\n\n  /** Sets the Charset for this class's String mapping, default is StandardCharsets.UTF_8. */\n  public static void setCharset(Charset cs) { _charset = cs; }\n";
/*      */   private static final String optStringMaxStrnlenCode = "  private static int _max_strnlen = 8192;\n\n  /** Returns the maximum number of bytes to read to determine native string length using `strnlen(..)`, default is 8192. */\n  public static int getMaxStrnlen() { return _max_strnlen; };\n\n  /** Sets the maximum number of bytes to read to determine native string length using `strnlen(..)`, default is 8192. */\n  public static void setMaxStrnlen(int v) { _max_strnlen = v; }\n";
/*      */   
/*      */   public JavaEmitter(JavaConfiguration paramJavaConfiguration) {
/*  162 */     this();
/*  163 */     this.cfg = paramJavaConfiguration;
/*      */   }
/*      */ 
/*      */   
/*      */   public void readConfigurationFile(String paramString) throws Exception {
/*  168 */     this.cfg = createConfig();
/*  169 */     this.cfg.read(paramString);
/*      */   }
/*      */   
/*      */   public JavaConfiguration getConfig() {
/*  173 */     return this.cfg;
/*      */   }
/*      */   
/*      */   class ConstFuncRenamer implements SymbolFilter {
/*      */     private List<ConstantDefinition> constants;
/*      */     private List<FunctionSymbol> functions;
/*      */     
/*      */     public List<ConstantDefinition> getConstants() {
/*  181 */       return this.constants;
/*      */     }
/*      */     
/*      */     public List<FunctionSymbol> getFunctions() {
/*  185 */       return this.functions;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private <T extends TypeComparator.AliasedSemanticSymbol> List<T> filterSymbolsInt(List<T> param1List1, boolean param1Boolean, List<T> param1List2) {
/*  191 */       JavaConfiguration javaConfiguration = JavaEmitter.this.getConfig();
/*  192 */       ArrayHashMap arrayHashMap = new ArrayHashMap(false, 100, 0.75F);
/*      */       
/*  194 */       for (TypeComparator.AliasedSemanticSymbol aliasedSemanticSymbol1 : param1List1) {
/*  195 */         TypeComparator.AliasedSemanticSymbol aliasedSemanticSymbol2; String str1 = aliasedSemanticSymbol1.getName();
/*  196 */         String str2 = javaConfiguration.getJavaSymbolRename(str1);
/*      */         
/*  198 */         if (null != str2) {
/*      */           
/*  200 */           aliasedSemanticSymbol2 = (TypeComparator.AliasedSemanticSymbol)arrayHashMap.get(str2);
/*  201 */           if (null != aliasedSemanticSymbol2)
/*      */           {
/*  203 */             aliasedSemanticSymbol1.rename(str2);
/*      */           }
/*      */         } else {
/*      */           
/*  207 */           aliasedSemanticSymbol2 = (TypeComparator.AliasedSemanticSymbol)arrayHashMap.get(str1);
/*      */         } 
/*  209 */         if (null != aliasedSemanticSymbol2)
/*      */         {
/*  211 */           if (!aliasedSemanticSymbol2.equalSemantics((TypeComparator.SemanticEqualityOp)aliasedSemanticSymbol1)) {
/*      */             Object object;
/*      */             String str3;
/*  214 */             if (aliasedSemanticSymbol1 instanceof ASTLocusTag.ASTLocusTagProvider) {
/*  215 */               object = ((ASTLocusTag.ASTLocusTagProvider)aliasedSemanticSymbol1).getASTLocusTag();
/*      */             } else {
/*  217 */               object = null;
/*      */             } 
/*  219 */             if (aliasedSemanticSymbol2 instanceof ASTLocusTag.ASTLocusTagProvider) {
/*  220 */               str3 = String.format(",%n  %s: previous definition is here", new Object[] { ((ASTLocusTag.ASTLocusTagProvider)aliasedSemanticSymbol2)
/*  221 */                     .getASTLocusTag().toString(new StringBuilder(), "note", true) });
/*      */             } else {
/*  223 */               str3 = "";
/*      */             } 
/*  225 */             String str4 = (null != str2) ? "alias" : "orig";
/*      */             
/*  227 */             String str5 = String.format("Duplicate Name (%s) w/ incompatible value:%n  this '%s',%n  have '%s'%s", new Object[] {
/*  228 */                   str4, aliasedSemanticSymbol1.getAliasedString(), aliasedSemanticSymbol2.getAliasedString(), str3 });
/*  229 */             throw new GlueGenException(str5, object);
/*      */           } 
/*      */         }
/*  232 */         if (null != str2) {
/*      */           
/*  234 */           if (null != aliasedSemanticSymbol2) {
/*      */             
/*  236 */             aliasedSemanticSymbol2.addAliasedName(str1);
/*      */             continue;
/*      */           } 
/*  239 */           aliasedSemanticSymbol1.rename(str2);
/*  240 */           arrayHashMap.put(str2, aliasedSemanticSymbol1);
/*      */           
/*      */           continue;
/*      */         } 
/*  244 */         if (null != aliasedSemanticSymbol2) {
/*      */           continue;
/*      */         }
/*      */         
/*  248 */         arrayHashMap.put(str1, aliasedSemanticSymbol1);
/*      */       } 
/*      */ 
/*      */       
/*  252 */       param1List2.addAll(arrayHashMap.getData());
/*  253 */       if (!param1Boolean)
/*      */       {
/*  255 */         Collections.sort(param1List2, new Comparator<T>()
/*      */             {
/*      */               public int compare(T param2T1, T param2T2) {
/*  258 */                 return param2T1.getName().compareTo(param2T2.getName());
/*      */               }
/*      */             });
/*      */       }
/*  262 */       return param1List2;
/*      */     }
/*      */ 
/*      */     
/*      */     public void filterSymbols(List<ConstantDefinition> param1List, List<FunctionSymbol> param1List1) {
/*  267 */       this.constants = filterSymbolsInt(param1List, true, new ArrayList<>(100));
/*  268 */       this.functions = filterSymbolsInt(param1List1, true, new ArrayList<>(100));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void beginEmission(GlueEmitterControls paramGlueEmitterControls) throws IOException {
/*  275 */     paramGlueEmitterControls.runSymbolFilter(new ConstFuncRenamer());
/*      */ 
/*      */     
/*  278 */     for (String str : this.cfg.forcedStructs()) {
/*  279 */       paramGlueEmitterControls.forceStructEmission(str);
/*      */     }
/*      */     
/*  282 */     if (!this.cfg.structsOnly()) {
/*      */       try {
/*  284 */         openCodeUnits();
/*  285 */       } catch (Exception exception) {
/*  286 */         throw new RuntimeException("Unable to open files for writing", exception);
/*      */       } 
/*  288 */       emitAllFileHeaders();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void endEmission() {
/*  294 */     if (!this.cfg.structsOnly()) {
/*  295 */       emitAllFileFooters();
/*      */       
/*      */       try {
/*  298 */         closeWriters();
/*  299 */       } catch (Exception exception) {
/*  300 */         throw new RuntimeException("Unable to close open files", exception);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void beginDefines() throws Exception {
/*  307 */     if ((this.cfg.allStatic() || this.cfg.emitInterface()) && !this.cfg.structsOnly()) {
/*  308 */       javaUnit().emitln();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected static String jniMangle(String paramString) {
/*  314 */     return paramString.replaceAll("_", "_1").replace('.', '_');
/*      */   }
/*      */   
/*      */   protected static String getJNIMethodNamePrefix(String paramString1, String paramString2) {
/*  318 */     return "Java_" + jniMangle(paramString1) + "_" + jniMangle(paramString2);
/*      */   }
/*      */   
/*  321 */   public JavaEmitter() { this.constMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1537 */     this.javaCallbackInterfaceMap = new HashMap<>(); this.LOG = Logging.getLogger(JavaEmitter.class.getPackage().getName(), JavaEmitter.class.getSimpleName()); } public void emitDefine(ConstantDefinition paramConstantDefinition, String paramString) throws Exception { if ((this.cfg.allStatic() || this.cfg.emitInterface()) && !this.cfg.structsOnly()) if (!this.cfg.shouldIgnoreInInterface((AliasedSymbol)paramConstantDefinition)) { ConstantDefinition.JavaExpr javaExpr = paramConstantDefinition.computeJavaExpr(this.constMap); this.constMap.put(paramConstantDefinition.getName(), javaExpr); javaUnit().emit("  /** "); if (paramString != null && paramString.length() != 0) { javaUnit().emit(paramString); javaUnit().emit(", "); }  javaUnit().emit("CType: "); if (javaExpr.resultType.isUnsigned) javaUnit().emit("unsigned ");  javaUnit().emit(javaExpr.resultJavaTypeName); javaUnit().emitln(" */"); javaUnit().emitln("  public static final " + javaExpr.resultJavaTypeName + " " + paramConstantDefinition.getName() + " = " + javaExpr.javaExpression + ";"); }   } public void endDefines() throws Exception {} public void beginFunctions(TypeDictionary paramTypeDictionary1, TypeDictionary paramTypeDictionary2, Map<Type, Type> paramMap, List<FunctionSymbol> paramList) throws Exception { this.canonMap = paramMap; if ((this.cfg.allStatic() || this.cfg.emitInterface()) && !this.cfg.structsOnly()) { javaUnit().emitln(); if (!this.cfg.getJavaCallbackList().isEmpty()) { List<JavaConfiguration.JavaCallbackDef> list = this.cfg.getJavaCallbackList(); for (JavaConfiguration.JavaCallbackDef javaCallbackDef : list) { Type type = paramTypeDictionary1.get(javaCallbackDef.cbFuncTypeName); if (null != type && type.isFunctionPointer()) { Optional optional = paramList.stream().filter(paramFunctionSymbol -> paramJavaCallbackDef.setFuncName.equals(paramFunctionSymbol.getName())).findFirst(); if (optional.isPresent()) { generateJavaCallbackCode(javaCallbackDef, type.getTargetFunction()); continue; }  this.LOG.log(Level.WARNING, "JavaCallback '{0}' setter not available", javaCallbackDef); continue; }  this.LOG.log(Level.WARNING, "JavaCallback '{0}' function-pointer type not available", javaCallbackDef); }  }  }  } public Iterator<FunctionSymbol> emitFunctions(List<FunctionSymbol> paramList) throws Exception { if (!this.cfg.structsOnly()) { ArrayList<FunctionEmitter> arrayList = new ArrayList(2 * paramList.size()); byte b = 0; for (FunctionSymbol functionSymbol : paramList) { if (!this.cfg.shouldIgnoreInImpl((AliasedSymbol)functionSymbol)) { arrayList.addAll(generateMethodBindingEmitters(functionSymbol)); this.LOG.log(Level.INFO, functionSymbol.getASTLocusTag(), "Non-Ignored Impl[{0}]: {1}", new Object[] { Integer.valueOf(b++), functionSymbol }); }  }  b = 0; for (FunctionEmitter functionEmitter : arrayList) { try { FunctionSymbol functionSymbol = functionEmitter.getCSymbol(); if (!functionEmitter.isInterface() || !this.cfg.shouldIgnoreInInterface((AliasedSymbol)functionSymbol)) { functionEmitter.emit(); functionEmitter.getUnit().emitln(); this.LOG.log(Level.INFO, functionSymbol.getASTLocusTag(), "Non-Ignored Intf[{0}]: {1}", new Object[] { Integer.valueOf(b++), functionSymbol }); }  } catch (Exception exception) { throw new GlueGenException("Error while emitting binding for \"" + functionEmitter.getCSymbol().getAliasedString() + "\"", functionEmitter.getCSymbol().getASTLocusTag(), exception); }  }  }  return paramList.iterator(); } protected JavaConfiguration createConfig() { return new JavaConfiguration(); } protected void generatePublicEmitters(MethodBinding paramMethodBinding, List<FunctionEmitter> paramList, boolean paramBoolean) { MethodAccess methodAccess; FunctionSymbol functionSymbol = paramMethodBinding.getCSymbol(); if (!paramBoolean && this.cfg.manuallyImplement((AliasedSymbol)functionSymbol)) return;  if (!paramBoolean && null != paramMethodBinding.getDelegationImplName()) { methodAccess = MethodAccess.PRIVATE; } else { methodAccess = this.cfg.accessControl(paramMethodBinding.getName()); }  if (paramBoolean && MethodAccess.PUBLIC != methodAccess) return;  boolean bool1 = this.cfg.isUnimplemented((AliasedSymbol)functionSymbol); List<String> list1 = this.cfg.javaPrologueForMethod(paramMethodBinding, false, false); List<String> list2 = this.cfg.javaEpilogueForMethod(paramMethodBinding, false, false); boolean bool2 = this.cfg.requiresJavaCallbackCode(paramMethodBinding.getName()); boolean bool3 = (bool1 || paramMethodBinding.needsNIOWrappingOrUnwrapping() || paramMethodBinding.signatureUsesJavaPrimitiveArrays() || bool2 || null != list1 || null != list2) ? true : false; boolean bool4 = (!paramBoolean && bool3) ? true : false; boolean bool5 = (!bool1 && !bool3 && !paramBoolean) ? true : false; JavaCodeUnit javaCodeUnit = (paramBoolean || this.cfg.allStatic()) ? javaUnit() : javaImplUnit(); JavaMethodBindingEmitter javaMethodBindingEmitter = new JavaMethodBindingEmitter(paramMethodBinding, javaCodeUnit, this.cfg.runtimeExceptionType(), this.cfg.unsupportedExceptionType(), bool4, this.cfg.tagNativeBinding(), false, this.cfg.useNIOOnly(paramMethodBinding.getName()), this.cfg.useNIODirectOnly(paramMethodBinding.getName()), false, false, bool1, paramBoolean, bool5, false, this.cfg); switch (methodAccess) { case Parent: javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.PUBLIC); break;case Java: javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.PROTECTED); break;case Native: javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.PRIVATE); break; }  if (this.cfg.allStatic()) javaMethodBindingEmitter.addModifier(FunctionEmitter.STATIC);  if (bool5) javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.NATIVE);  javaMethodBindingEmitter.setReturnedArrayLengthExpression(this.cfg.returnedArrayLength(paramMethodBinding.getName())); javaMethodBindingEmitter.setPrologue(list1); javaMethodBindingEmitter.setEpilogue(list2); paramList.add(javaMethodBindingEmitter); } protected void generatePrivateEmitters(MethodBinding paramMethodBinding, List<FunctionEmitter> paramList) { FunctionSymbol functionSymbol = paramMethodBinding.getCSymbol(); if (this.cfg.manuallyImplement((AliasedSymbol)functionSymbol)) return;  boolean bool = (this.cfg.javaPrologueForMethod(paramMethodBinding, false, false) != null || this.cfg.javaEpilogueForMethod(paramMethodBinding, false, false) != null) ? true : false; boolean bool1 = this.cfg.requiresJavaCallbackCode(paramMethodBinding.getName()); if (!this.cfg.isUnimplemented((AliasedSymbol)functionSymbol)) { if (!paramMethodBinding.signatureUsesJavaPrimitiveArrays() && (paramMethodBinding.needsNIOWrappingOrUnwrapping() || bool || bool1)) { JavaCodeUnit javaCodeUnit = this.cfg.allStatic() ? javaUnit() : javaImplUnit(); JavaMethodBindingEmitter javaMethodBindingEmitter = new JavaMethodBindingEmitter(paramMethodBinding, javaCodeUnit, this.cfg.runtimeExceptionType(), this.cfg.unsupportedExceptionType(), false, this.cfg.tagNativeBinding(), true, this.cfg.useNIOOnly(paramMethodBinding.getName()), this.cfg.useNIODirectOnly(paramMethodBinding.getName()), true, false, false, false, true, true, this.cfg); javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.PRIVATE); if (this.cfg.allStatic()) javaMethodBindingEmitter.addModifier(FunctionEmitter.STATIC);  javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.NATIVE); javaMethodBindingEmitter.setReturnedArrayLengthExpression(this.cfg.returnedArrayLength(paramMethodBinding.getName())); paramList.add(javaMethodBindingEmitter); }  if (!paramMethodBinding.signatureUsesJavaPrimitiveArrays()) { CMethodBindingEmitter cMethodBindingEmitter = new CMethodBindingEmitter(paramMethodBinding, cUnit(), this.cfg.implPackageName(), this.cfg.implClassName(), true, this.cfg.allStatic(), (paramMethodBinding.needsNIOWrappingOrUnwrapping() || bool || bool1), !this.cfg.useNIODirectOnly(paramMethodBinding.getName()), this.machDescJava, getConfig()); prepCEmitter(paramMethodBinding.getName(), paramMethodBinding.getJavaReturnType(), cMethodBindingEmitter); paramList.add(cMethodBindingEmitter); }  }  } protected void prepCEmitter(String paramString, JavaType paramJavaType, CMethodBindingEmitter paramCMethodBindingEmitter) { if (paramJavaType.isNIOBuffer() || paramJavaType.isCompoundTypeWrapper()) { String str = this.cfg.returnValueCapacity(paramString); if (str != null) paramCMethodBindingEmitter.setReturnValueCapacityExpression(new MessageFormat(str));  } else if (paramJavaType.isArray() || paramJavaType.isArrayOfCompoundTypeWrappers()) { if (paramJavaType.isPrimitiveArray()) throw new RuntimeException("Primitive array return types not yet supported");  String str = this.cfg.returnValueLength(paramString); if (str != null) paramCMethodBindingEmitter.setReturnValueLengthExpression(new MessageFormat(str));  }  paramCMethodBindingEmitter.setTemporaryCVariableDeclarations(this.cfg.temporaryCVariableDeclarations(paramString)); paramCMethodBindingEmitter.setTemporaryCVariableAssignments(this.cfg.temporaryCVariableAssignments(paramString)); } protected List<? extends FunctionEmitter> generateMethodBindingEmitters(FunctionSymbol paramFunctionSymbol) throws Exception { ArrayList<FunctionEmitter> arrayList = new ArrayList(); try { if (this.cfg.emitInterface()) generateMethodBindingEmittersImpl(arrayList, paramFunctionSymbol, true);  if (this.cfg.emitImpl()) generateMethodBindingEmittersImpl(arrayList, paramFunctionSymbol, false);  } catch (Exception exception) { throw new GlueGenException("Error while generating bindings for \"" + paramFunctionSymbol + "\"", paramFunctionSymbol.getASTLocusTag(), exception); }  return arrayList; }
/*      */   private void generateMethodBindingEmittersImpl(ArrayList<FunctionEmitter> paramArrayList, FunctionSymbol paramFunctionSymbol, boolean paramBoolean) throws Exception { MethodBinding methodBinding = bindFunction(paramFunctionSymbol, paramBoolean, this.machDescJava, null, null); List<MethodBinding> list = expandMethodBinding(methodBinding); HashSet<MethodBinding> hashSet = new HashSet(); for (MethodBinding methodBinding1 : list) { if (!hashSet.add(methodBinding1)) continue;  if (this.cfg.allStatic() && methodBinding1.hasContainingType()) throw new IllegalArgumentException("Cannot create binding in AllStatic mode because method has containing type: \"" + methodBinding1 + "\"");  if (paramBoolean) { generatePublicEmitters(methodBinding1, paramArrayList, true); continue; }  generatePublicEmitters(methodBinding1, paramArrayList, false); generatePrivateEmitters(methodBinding1, paramArrayList); }  }
/*      */   public void endFunctions() throws Exception { if (!this.cfg.structsOnly()) { if (this.cfg.allStatic() || this.cfg.emitInterface()) emitCustomJavaCode(javaUnit(), this.cfg.className());  if (this.cfg.allStatic() && this.cfg.emitImpl()) emitCustomJNICode(cUnit(), this.cfg.className());  if (!this.cfg.allStatic() && this.cfg.emitImpl()) { emitCustomJavaCode(javaImplUnit(), this.cfg.implClassName()); emitCustomJNICode(cUnit(), this.cfg.implClassName()); }  }  }
/*      */   public void beginStructLayout() throws Exception {}
/* 1541 */   private List<MethodBinding> generateFunctionInterfaceCode(JavaCodeUnit paramJavaCodeUnit, FunctionSymbol paramFunctionSymbol, JavaConfiguration.JavaCallbackDef paramJavaCallbackDef, StringBuilder paramStringBuilder) { MethodBinding methodBinding = bindFunction(paramFunctionSymbol, true, this.machDescJava, null, null);
/*      */ 
/*      */     
/* 1544 */     int i = paramJavaCallbackDef.cbFuncUserParamIdx;
/* 1545 */     if (0 <= i && i < methodBinding.getNumArguments()) {
/* 1546 */       JavaType javaType1 = methodBinding.getJavaArgumentType(i);
/* 1547 */       if (javaType1.isCVoidPointerType()) {
/*      */         JavaType javaType2;
/* 1549 */         if (null != paramJavaCallbackDef.userParamClassName) {
/* 1550 */           javaType2 = JavaType.createForNamedClass(paramJavaCallbackDef.userParamClassName);
/* 1551 */           methodBinding = methodBinding.replaceJavaArgumentType(i, JavaType.forObjectClass());
/*      */         } else {
/* 1553 */           javaType2 = JavaType.forObjectClass();
/*      */         } 
/* 1555 */         methodBinding = methodBinding.replaceJavaArgumentType(i, javaType2);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1560 */     paramStringBuilder.append("(");
/* 1561 */     for (byte b = 0; b < methodBinding.getNumArguments(); b++) {
/* 1562 */       JavaType javaType1 = methodBinding.getJavaArgumentType(b);
/* 1563 */       paramStringBuilder.append(javaType1.getDescriptor(this.cfg));
/*      */     } 
/* 1565 */     paramStringBuilder.append(")");
/* 1566 */     JavaType javaType = methodBinding.getJavaReturnType();
/* 1567 */     paramStringBuilder.append(javaType.getDescriptor(this.cfg));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1572 */     List<MethodBinding> list = expandMethodBinding(methodBinding);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1577 */     if (null != paramJavaCodeUnit) {
/* 1578 */       for (MethodBinding methodBinding1 : list) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1585 */         JavaMethodBindingEmitter javaMethodBindingEmitter = new JavaMethodBindingEmitter(methodBinding1, paramJavaCodeUnit, this.cfg.runtimeExceptionType(), this.cfg.unsupportedExceptionType(), false, this.cfg.tagNativeBinding(), false, true, true, false, false, true, true, false, false, this.cfg)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected String getBaseIndentString()
/*      */             {
/* 1597 */               return "    "; }
/*      */           };
/* 1599 */         javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.PUBLIC);
/* 1600 */         javaMethodBindingEmitter.emit();
/*      */       } 
/*      */     }
/* 1603 */     return list; }
/*      */   public void layoutStruct(CompoundType paramCompoundType) throws Exception { getLayout().layout(paramCompoundType); }
/*      */   public void endStructLayout() throws Exception {}
/*      */   public void beginStructs(TypeDictionary paramTypeDictionary1, TypeDictionary paramTypeDictionary2, Map<Type, Type> paramMap) throws Exception { this.canonMap = paramMap; }
/*      */   public void emitStruct(CompoundType paramCompoundType, Type paramType) throws Exception { String str1, str2; PointerType pointerType; byte b1; JavaCodeUnit javaCodeUnit; CCodeUnit cCodeUnit; String str3 = paramCompoundType.getName(); if (null != paramType && null != paramType.getName()) { str2 = paramType.getName(); str1 = str2; } else { str2 = null; str1 = str3; }  this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "Struct emission of structCType {0}", paramCompoundType); this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "              structCTypedefPtr {0}", paramType); this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "   : structCTypeName \"{0}\" -> typedefedName \"{1}\" -> \"{2}\"", new Object[] { str3, str2, str1 }); if (null == str1) { this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "skipping emission of unnamed struct {0} w/o typedef", paramCompoundType); return; }  AliasedSymbol.AliasedSymbolImpl aliasedSymbolImpl = new AliasedSymbol.AliasedSymbolImpl(str1); aliasedSymbolImpl.addAliasedName(str3); aliasedSymbolImpl.addAliasedName(str2); if (this.cfg.shouldIgnoreInInterface((AliasedSymbol)aliasedSymbolImpl)) { this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "skipping emission of ignored \"{0}\": {1}", new Object[] { aliasedSymbolImpl, paramCompoundType }); return; }  boolean bool = this.cfg.immutableAccess((AliasedSymbol)aliasedSymbolImpl); if (null != paramType && isOpaque(paramType)) { this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "skipping emission of opaque typedef {0}", paramType); return; }  if (isOpaque((Type)paramCompoundType)) { this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "skipping emission of opaque c-struct {0}", paramCompoundType); return; }  if (null != str2) { Type type1 = paramType; b1 = 1; } else { pointerType = new PointerType(SizeThunk.POINTER, (Type)paramCompoundType, 0); pointerType.setTypedefName(str2); b1 = 2; }  Type type = canonicalize((Type)pointerType); this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "containingCType[{0}]: {1} -canon-> {2}", new Object[] { Integer.valueOf(b1), pointerType, type }); JavaType javaType = typeToJavaType(type, null); if (javaType.isOpaqued()) { this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "skipping emission of opaque {0}, {1}", new Object[] { javaType, paramCompoundType }); return; }  if (!javaType.isCompoundTypeWrapper()) { this.LOG.log(Level.WARNING, paramCompoundType.getASTLocusTag(), "skipping emission of non-compound {0}, {1}", new Object[] { javaType, paramCompoundType }); return; }  String str4 = javaType.getName(); this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "perform emission of \"{0}\" -> \"{1}\": {2}", new Object[] { str1, str4, paramCompoundType }); if (0 == paramCompoundType.getNumFields()) this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), "emission of \"{0}\" with zero fields {1}", new Object[] { str4, paramCompoundType });  boolean bool1 = !this.cfg.customJNICodeForClass(str4).isEmpty() ? true : false; for (byte b2 = 0; b2 < paramCompoundType.getNumFields(); b2++) { Field field = paramCompoundType.getField(b2); cCodeUnit = (CCodeUnit)field.getType(); String str = JavaConfiguration.canonicalStructFieldSymbol(str4, field.getName()); if (!this.cfg.shouldIgnoreInInterface(str)) { String str8 = this.cfg.getJavaSymbolRename(str); String str9 = (str8 == null) ? field.getName() : str8; String str10 = JavaConfiguration.canonicalStructFieldSymbol(str4, str9); TypeInfo typeInfo = this.cfg.canonicalNameOpaque(str10); boolean bool3 = (null != typeInfo) ? true : false; if (cCodeUnit.isFunctionPointer() && !bool3) { bool1 = true; break; }  }  }  String str5 = this.cfg.packageForStruct(str1); try { String str = this.cfg.javaOutputDir() + File.separator + CodeGenUtils.packageAsPath(str5) + File.separator + str4 + ".java"; javaCodeUnit = openJavaUnit(str, str5, str4); if (null == javaCodeUnit) return;  if (bool1) { str = this.cfg.nativeOutputDir(); if (this.cfg.nativeOutputUsesJavaHierarchy()) str = str + File.separator + CodeGenUtils.packageAsPath(this.cfg.packageName());  String str8 = str4 + "_JNI.c"; String str9 = str + File.separator + str8; cCodeUnit = openCUnit(str9, str8); cCodeUnit.emitHeader(str5, str4, this.cfg.customCCode()); } else { cCodeUnit = null; }  } catch (Exception exception) { throw new RuntimeException("Unable to open files for emission of struct class", exception); }  javaCodeUnit.emitln(); javaCodeUnit.emitln("package " + str5 + ";"); javaCodeUnit.emitln(); javaCodeUnit.emitln("import java.nio.*;"); javaCodeUnit.emitln("import java.nio.charset.Charset;"); javaCodeUnit.emitln("import java.nio.charset.StandardCharsets;"); javaCodeUnit.emitln(); javaCodeUnit.emitln("import " + this.cfg.gluegenRuntimePackage() + ".*;"); javaCodeUnit.emitln("import " + DynamicLookupHelper.class.getPackage().getName() + ".*;"); javaCodeUnit.emitln("import " + Buffers.class.getPackage().getName() + ".*;"); javaCodeUnit.emitln("import " + MachineDataInfoRuntime.class.getName() + ";"); javaCodeUnit.emitln(); List<String> list1 = this.cfg.imports(); for (String str : list1) { javaCodeUnit.emit("import "); javaCodeUnit.emit(str); javaCodeUnit.emitln(";"); }  javaCodeUnit.emitln(); List<String> list2 = this.cfg.javadocForClass(str4); for (String str : list2) javaCodeUnit.emitln(str);  javaCodeUnit.emit("public class " + str4 + " "); boolean bool2 = true; List<String> list3 = this.cfg.implementedInterfaces(str4); for (String str : list3) { if (bool2) javaCodeUnit.emit("implements ");  bool2 = false; javaCodeUnit.emit(str); javaCodeUnit.emit(" "); }  javaCodeUnit.emitln("{"); javaCodeUnit.emitln(); javaCodeUnit.emitln("  StructAccessor accessor;"); javaCodeUnit.emitln(); String str6 = this.cfg.returnStructMachineDataInfoIndex(str4); String str7 = (null != str6) ? str6 : "private static final int mdIdx = MachineDataInfoRuntime.getStatic().ordinal();"; javaCodeUnit.emitln("  " + str7); javaCodeUnit.emitln("  private final MachineDataInfo md;"); javaCodeUnit.emitln(); generateOffsetAndSizeArrays(javaCodeUnit, "  ", str4, (Type)paramCompoundType, null, null); if (GlueGen.debug()) { System.err.printf("SE.__: structCType %s%n", new Object[] { paramCompoundType.getDebugString() }); System.err.printf("SE.__: contCTypeName %s%n", new Object[] { type.getDebugString() }); System.err.printf("SE.__: contJTypeName %s%n", new Object[] { javaType.getDebugString() }); }  for (byte b3 = 0; b3 < paramCompoundType.getNumFields(); b3++) { Field field = paramCompoundType.getField(b3); Type type1 = field.getType(); String str = JavaConfiguration.canonicalStructFieldSymbol(str4, field.getName()); if (!this.cfg.shouldIgnoreInInterface(str)) { String str8 = this.cfg.getJavaSymbolRename(str); String str9 = (null == str8) ? field.getName() : str8; String str10 = JavaConfiguration.canonicalStructFieldSymbol(str4, str9); if (type1.isFunctionPointer()) { if (GlueGen.debug()) System.err.printf("SE.os.%02d: %s / %s, %s (%s)%n", new Object[] { Integer.valueOf(b3 + 1), field, str10, type1.getDebugString(), "FuncPtr" });  generateOffsetAndSizeArrays(javaCodeUnit, "  ", str9, null, field, null); generateOffsetAndSizeArrays(javaCodeUnit, "//", str9, type1, null, null); } else if (type1.isCompound()) { if (type1.getName() == null) throw new GlueGenException("Anonymous structs as fields not supported yet, field \"" + str10 + "\", " + type1.getDebugString(), type1.getASTLocusTag());  if (GlueGen.debug()) System.err.printf("SE.os.%02d: %s / %s, %s (%s)%n", new Object[] { Integer.valueOf(b3 + 1), field, str10, type1.getDebugString(), "compound" });  generateOffsetAndSizeArrays(javaCodeUnit, "  ", str9, type1, field, null); } else if (type1.isArray()) { Type type2 = type1.getBaseType(); if (GlueGen.debug()) { System.err.printf("SE.os.%02d: %s / %s, %s (%s)%n", new Object[] { Integer.valueOf(b3 + 1), field, str10, type1.getDebugString(), "array" }); System.err.printf("SE.os.%02d: baseType %s%n", new Object[] { Integer.valueOf(b3 + 1), type2.getDebugString() }); }  generateOffsetAndSizeArrays(javaCodeUnit, "  ", str9, null, field, null); generateOffsetAndSizeArrays(javaCodeUnit, "//", str9, type1, null, null); } else { JavaType javaType1; try { javaType1 = typeToJavaType(type1, this.machDescJava); } catch (Exception exception) { throw new GlueGenException("Error occurred while creating accessor for field \"" + str10 + "\", " + type1.getDebugString(), type1.getASTLocusTag(), exception); }  if (GlueGen.debug()) { System.err.printf("SE.os.%02d: %s / %s, %s (%s)%n", new Object[] { Integer.valueOf(b3 + 1), field, str10, type1.getDebugString(), "MISC" }); System.err.printf("SE.os.%02d: javaType %s%n", new Object[] { Integer.valueOf(b3 + 1), javaType1.getDebugString() }); }  if (javaType1.isPrimitive()) { generateOffsetAndSizeArrays(javaCodeUnit, "  ", str9, null, field, null); generateOffsetAndSizeArrays(javaCodeUnit, "//", str9, type1, null, null); } else if (javaType1.isCPrimitivePointerType()) { if (requiresGetCStringLength(type1, str10)) { generateOffsetAndSizeArrays(javaCodeUnit, "  ", str9, null, field, null); generateOffsetAndSizeArrays(javaCodeUnit, "//", str9, type1, null, "// " + javaType1.getDebugString()); } else { generateOffsetAndSizeArrays(javaCodeUnit, "  ", str9, null, field, null); generateOffsetAndSizeArrays(javaCodeUnit, "//", str9, type1, field, "// " + javaType1.getDebugString()); }  } else { generateOffsetAndSizeArrays(javaCodeUnit, "  ", str9, null, field, null); generateOffsetAndSizeArrays(javaCodeUnit, "//", str9, type1, null, "// " + javaType1.getDebugString()); }  }  } else if (GlueGen.debug()) { System.err.printf("SE.os.%02d: %s, %s (IGNORED)%n", new Object[] { Integer.valueOf(b3 + 1), field, type1.getDebugString() }); }  }  javaCodeUnit.emitln(); javaCodeUnit.emitln("  /** Returns true if this generated implementation uses native code, otherwise false. */"); javaCodeUnit.emitln("  public static boolean usesNativeCode() {"); javaCodeUnit.emitln("    return " + bool1 + ";"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); if (!this.cfg.manuallyImplement(JavaConfiguration.canonicalStructFieldSymbol(str4, "size"))) { javaCodeUnit.emitln("  /** Returns the aligned total size of a native instance. */"); javaCodeUnit.emitln("  public static int size() {"); javaCodeUnit.emitln("    return " + str4 + "_size[mdIdx];"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); }  if (!this.cfg.manuallyImplement(JavaConfiguration.canonicalStructFieldSymbol(str4, "create"))) { javaCodeUnit.emitln("  /** Returns a new instance with all bytes set to zero. */"); javaCodeUnit.emitln("  public static " + str4 + " create() {"); javaCodeUnit.emitln("    return create(Buffers.newDirectByteBuffer(size()));"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); javaCodeUnit.emitln("  /** Returns a new instance using the given ByteBuffer having at least {#link size()} bytes capacity. The ByteBuffer will be {@link ByteBuffer#rewind()} and native-order set. */"); javaCodeUnit.emitln("  public static " + str4 + " create(java.nio.ByteBuffer buf) {"); javaCodeUnit.emitln("      return new " + str4 + "(buf);"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); }  javaCodeUnit.emitln("  /** Returns new instance dereferencing ByteBuffer at given native address `addr` with size {@link #size()}. */"); javaCodeUnit.emitln("  public static " + str4 + " derefPointer(final long addr) {"); javaCodeUnit.emitln("      return create( ElementBuffer.derefPointer(size(), addr, 1).getByteBuffer() );"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); if (!this.cfg.manuallyImplement(JavaConfiguration.canonicalStructFieldSymbol(str4, str4))) { javaCodeUnit.emitln("  " + str4 + "(java.nio.ByteBuffer buf) {"); javaCodeUnit.emitln("    md = MachineDataInfo.StaticConfig.values()[mdIdx].md;"); javaCodeUnit.emitln("    accessor = new StructAccessor(buf);"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); }  javaCodeUnit.emitln("  /** Return the underlying native direct ByteBuffer */"); javaCodeUnit.emitln("  public final java.nio.ByteBuffer getBuffer() {"); javaCodeUnit.emitln("    return accessor.getBuffer();"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); javaCodeUnit.emitln("  /** Returns the native address of the underlying native ByteBuffer {@link #getBuffer()} */"); javaCodeUnit.emitln("  public final long getDirectBufferAddress() {"); javaCodeUnit.emitln("    return accessor.getDirectBufferAddress();"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); HashSet<MethodBinding> hashSet = new HashSet(); for (byte b4 = 0; b4 < paramCompoundType.getNumFields(); b4++) { Field field = paramCompoundType.getField(b4); Type type1 = field.getType(); String str = JavaConfiguration.canonicalStructFieldSymbol(str4, field.getName()); if (!this.cfg.shouldIgnoreInInterface(str)) { String str8 = this.cfg.getJavaSymbolRename(str); String str9 = (str8 == null) ? field.getName() : str8; String str10 = JavaConfiguration.canonicalStructFieldSymbol(str4, str9); TypeInfo typeInfo1 = this.cfg.typeInfo(type1); boolean bool3 = (null != typeInfo1) ? true : false; TypeInfo typeInfo2 = this.cfg.canonicalNameOpaque(str10); boolean bool4 = (null != typeInfo2) ? true : false; boolean bool5 = (bool || this.cfg.immutableAccess(str10)) ? true : false; if (GlueGen.debug()) { System.err.printf("SE.ac.%02d: field %s / %s / rename %s -> %s / opaque %b, fieldType %s (opaque %b), immutable[struct %b, field %b]%n", new Object[] { Integer.valueOf(b4 + 1), field, str10, str8, str9, Boolean.valueOf(bool4), type1.getDebugString(), Boolean.valueOf(bool3), Boolean.valueOf(bool), Boolean.valueOf(bool5) }); System.err.printf("SE.ac.%02d: opaqueFieldType %s%n", new Object[] { Integer.valueOf(b4 + 1), typeInfo1 }); }  if (type1.isFunctionPointer() && !bool4) { FunctionSymbol functionSymbol = new FunctionSymbol(field.getName(), type1.getTargetFunction()); functionSymbol.rename(str8); String str11 = CodeGenUtils.capitalizeString(str9); if (!bool5 && !type1.isConst()) { generateSetterSignature(javaCodeUnit, MethodAccess.PUBLIC, false, false, str9, type1, Ownership.Parent, str4, str11, null, "long", null, false, false, null, null, null); javaCodeUnit.emitln(" {"); javaCodeUnit.emitln("    accessor.setLongAt(" + str9 + "_offset[mdIdx], src, md.pointerSizeInBytes());"); javaCodeUnit.emitln("    return this;"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); }  generateGetterSignature(javaCodeUnit, false, false, str9, type1, Ownership.Parent, "long", str11, null, false, false, null, null); javaCodeUnit.emitln(" {"); javaCodeUnit.emitln("    return accessor.getLongAt(" + str9 + "_offset[mdIdx], md.pointerSizeInBytes());"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); generateFunctionPointerCode(hashSet, javaCodeUnit, cCodeUnit, str1, type, javaType, b4, functionSymbol, str10); } else if (type1.isCompound() && !bool4) { if (type1.getName() == null)
/*      */             throw new GlueGenException("Anonymous structs as fields not supported yet (field \"" + field + "\" in type \"" + str1 + "\")", type1.getASTLocusTag());  if (!bool5 && !type1.isConst()) { generateSetterSignature(javaCodeUnit, MethodAccess.PUBLIC, false, false, str9, type1, Ownership.Parent, str4, CodeGenUtils.capitalizeString(str9), null, type1.getName(), null, false, false, null, null, null); javaCodeUnit.emitln(" {"); javaCodeUnit.emitln("    final ByteBuffer bb = src.getBuffer();"); javaCodeUnit.emitln("    final int size = " + str9 + "_size[mdIdx];"); javaCodeUnit.emitln("    final byte[] content = new byte[size];"); javaCodeUnit.emitln("    bb.get(content, 0, size);"); javaCodeUnit.emitln("    accessor.setBytesAt(" + str9 + "_offset[mdIdx], content);"); javaCodeUnit.emitln("    return this;"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); }  generateGetterSignature(javaCodeUnit, false, false, str9, type1, Ownership.Parent, type1.getName(), CodeGenUtils.capitalizeString(str9), null, false, false, null, null); javaCodeUnit.emitln(" {"); javaCodeUnit.emitln("    return " + type1.getName() + ".create( accessor.slice( " + str9 + "_offset[mdIdx], " + str9 + "_size[mdIdx] ) );"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); } else if ((type1.isArray() || type1.isPointer()) && !bool4) { generateArrayGetterSetterCode(javaCodeUnit, paramCompoundType, javaType, b4, field, str9, bool5, str10); } else { JavaType javaType1; try { javaType1 = typeToJavaType(type1, this.machDescJava); } catch (Exception exception) { throw new GlueGenException("Error occurred while creating accessor for field \"" + field.getName() + "\", " + type1.getDebugString(), type1.getASTLocusTag(), exception); }  if (bool3 || bool4 || javaType1.isPrimitive()) { String str11; boolean bool6 = type1.getSize().hasFixedNativeSize(); if (bool3) { str11 = typeInfo1.javaType().getName(); } else if (bool4) { str11 = typeInfo2.javaType().getName(); } else { str11 = javaType1.getName(); }  String str12 = CodeGenUtils.capitalizeString(str11); String str13 = CodeGenUtils.capitalizeString(str9); String str14 = type1.isPointer() ? "pointer" : str11; this.LOG.log(Level.FINE, paramCompoundType.getASTLocusTag(), "Java.StructEmitter.Primitive: " + field.getName() + ", " + type1 + ", " + str11 + ", , fixedSize " + bool6 + ", opaque[t " + bool3 + ", f " + bool4 + "], sizeDenominator " + str14); if (!bool5 && !type1.isConst()) { generateSetterSignature(javaCodeUnit, MethodAccess.PUBLIC, false, false, str9, type1, Ownership.Parent, str4, str13, null, str11, null, false, false, null, null, null); javaCodeUnit.emitln(" {"); if (bool6) { javaCodeUnit.emitln("    accessor.set" + str12 + "At(" + str9 + "_offset[mdIdx], src);"); } else { javaCodeUnit.emitln("    accessor.set" + str12 + "At(" + str9 + "_offset[mdIdx], src, md." + str14 + "SizeInBytes());"); }  javaCodeUnit.emitln("    return this;"); javaCodeUnit.emitln("  }"); javaCodeUnit.emitln(); }  generateGetterSignature(javaCodeUnit, false, false, str9, type1, Ownership.Parent, str11, str13, null, false, false, null, null); javaCodeUnit.emitln(" {"); javaCodeUnit.emit("    return "); if (bool6) { javaCodeUnit.emitln("accessor.get" + str12 + "At(" + str9 + "_offset[mdIdx]);"); } else { javaCodeUnit.emitln("accessor.get" + str12 + "At(" + str9 + "_offset[mdIdx], md." + str14 + "SizeInBytes());"); }  javaCodeUnit.emitln("  }"); } else { javaCodeUnit.emitln("  /** UNKNOWN: " + str10 + ": " + type1.getDebugString() + ", " + javaType1.getDebugString() + " */"); }  javaCodeUnit.emitln(); }  }  }  emitCustomJavaCode(javaCodeUnit, str4); javaCodeUnit.emitTailCode(); javaCodeUnit.emitln("}"); javaCodeUnit.close(); if (bool1) { emitCustomJNICode(cCodeUnit, str4); cCodeUnit.close(); }  if (GlueGen.debug()) { System.err.printf("SE.XX: structCType %s%n", new Object[] { paramCompoundType.getDebugString() }); System.err.printf("SE.XX: contCTypeName %s%n", new Object[] { type.getDebugString() }); System.err.printf("SE.XX: contJTypeName %s%n", new Object[] { javaType.getDebugString() }); }  } public void endStructs() throws Exception {} public static int addStrings2Buffer(StringBuilder paramStringBuilder, String paramString1, String paramString2, Collection<String> paramCollection) { byte b = 0; if (null == paramStringBuilder)
/*      */       paramStringBuilder = new StringBuilder();  Iterator<String> iterator = paramCollection.iterator(); if (null != paramString2) { paramStringBuilder.append(paramString2); if (iterator.hasNext())
/*      */         paramStringBuilder.append(paramString1);  b++; }  while (iterator.hasNext()) { paramStringBuilder.append(iterator.next()); if (iterator.hasNext())
/* 1611 */         paramStringBuilder.append(paramString1);  b++; }  return b; } private void generateFunctionPointerCode(Set<MethodBinding> paramSet, JavaCodeUnit paramJavaCodeUnit, CCodeUnit paramCCodeUnit, String paramString1, Type paramType, JavaType paramJavaType, int paramInt, FunctionSymbol paramFunctionSymbol, String paramString2) { MethodBinding methodBinding = bindFunction(paramFunctionSymbol, true, this.machDescJava, paramJavaType, paramType);
/* 1612 */     methodBinding.findThisPointer();
/*      */ 
/*      */ 
/*      */     
/* 1616 */     List<MethodBinding> list = expandMethodBinding(methodBinding);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1621 */     for (MethodBinding methodBinding1 : list)
/* 1622 */     { if (!paramSet.add(methodBinding1)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1633 */       JavaMethodBindingEmitter javaMethodBindingEmitter = new JavaMethodBindingEmitter(methodBinding1, paramJavaCodeUnit, this.cfg.runtimeExceptionType(), this.cfg.unsupportedExceptionType(), true, this.cfg.tagNativeBinding(), false, true, true, false, false, false, false, false, false, this.cfg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1644 */       javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.PUBLIC);
/* 1645 */       javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.FINAL);
/* 1646 */       javaMethodBindingEmitter.emit();
/* 1647 */       paramJavaCodeUnit.emitln();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1656 */       javaMethodBindingEmitter = new JavaMethodBindingEmitter(methodBinding1, paramJavaCodeUnit, this.cfg.runtimeExceptionType(), this.cfg.unsupportedExceptionType(), false, this.cfg.tagNativeBinding(), true, true, true, true, false, false, false, false, true, this.cfg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1666 */       javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.PRIVATE);
/* 1667 */       javaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.NATIVE);
/* 1668 */       javaMethodBindingEmitter.emit();
/* 1669 */       paramJavaCodeUnit.emitln();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1681 */       CMethodBindingEmitter cMethodBindingEmitter = new CMethodBindingEmitter(methodBinding1, paramCCodeUnit, paramJavaCodeUnit.pkgName, paramJavaType.getName(), true, false, true, false, this.machDescJava, getConfig());
/* 1682 */       cMethodBindingEmitter.setIsCStructFunctionPointer(true);
/* 1683 */       prepCEmitter(paramString2, methodBinding1.getJavaReturnType(), cMethodBindingEmitter);
/* 1684 */       cMethodBindingEmitter.emit();
/* 1685 */       paramCCodeUnit.emitln(); }  }
/*      */   private void generateArrayFieldNote(CodeUnit paramCodeUnit, String paramString1, String paramString2, String paramString3, Type paramType, Ownership paramOwnership, boolean paramBoolean1, boolean paramBoolean2, String paramString4, boolean paramBoolean3, boolean paramBoolean4) { boolean bool; Type type; String str1, str2, str3; if (paramType.isFunctionPointer()) { bool = false; type = null; str1 = "being"; } else if (paramType.isPointer()) { bool = true; type = paramType.getTargetType(); str1 = "referencing"; } else if (paramType.isArray()) { bool = true; Type type1 = paramType.getArrayBaseOrPointerTargetType(); if (type1 != paramType && type1.isPointer()) { type = type1; } else { type = null; }  str1 = "being"; } else { bool = false; type = null; str1 = "being"; }  if (paramBoolean3) { if (paramBoolean4) paramCodeUnit.emitln("   * <p>");  paramCodeUnit.emit("   * "); }  if (null != paramString1) paramCodeUnit.emit(paramString1 + " ");  switch (paramOwnership) { case Parent: str2 = "a <i>struct</i> owned"; break;case Java: str2 = "a <i>Java</i> owned"; break;case Native: str2 = "a <i>natively</i> owned"; break;default: str2 = "a <i>mixed and ambigously</i> owned (<b>warning</b>)"; break; }  if (paramType.isFunctionPointer()) { str3 = "function pointer"; } else if (bool) { str3 = "array"; } else { str3 = paramType.getClass().getSimpleName(); }  paramCodeUnit.emit("native field <code>" + paramString3 + "</code>, " + str1 + " " + str2 + " " + str3); if (bool) { paramCodeUnit.emit(" with " + (paramBoolean1 ? "fixed" : "variable") + " element count"); if (null != paramString4) { if (paramString4.startsWith("get") && paramString4.endsWith("()")) { paramCodeUnit.emit(" of {@link #" + paramString4 + "} "); } else { paramCodeUnit.emit(" of <code>" + paramString4 + "</code> "); }  if (paramBoolean1 || Ownership.Mixed == paramOwnership) { paramCodeUnit.emit("elements."); } else { paramCodeUnit.emit("initial elements."); }  } else { paramCodeUnit.emit("."); }  } else { paramCodeUnit.emit("."); }  if (paramBoolean3) { paramCodeUnit.emitln(); if (paramBoolean4) paramCodeUnit.emitln("   * </p>");  }  if (paramBoolean2) if (paramBoolean3) { paramCodeUnit.emitln("   * <p>"); paramCodeUnit.emitln("   * Maximum element count is <code>1</code>."); paramCodeUnit.emitln("   * </p>"); } else { paramCodeUnit.emit(" Maximum element count is <code>1</code>."); }   if (paramBoolean3) { paramCodeUnit.emitln("   * <p>"); if (null == type) { paramCodeUnit.emitln("   * Native Field Signature <code>" + paramType.getSignature(null).toString() + "</code>"); } else { paramCodeUnit.emitln("   * Native Signature:"); paramCodeUnit.emitln("   * <ul>"); paramCodeUnit.emitln("   *   <li>field-type <code>" + paramType.getSignature(null).toString() + "</code></li>"); paramCodeUnit.emitln("   *   <li>referenced <code>" + type.getSignature(null).toString() + "</code></li>"); paramCodeUnit.emitln("   * </ul>"); }  paramCodeUnit.emitln("   * </p>"); } else { paramCodeUnit.emit(" NativeSig <code>" + paramType.getSignature(null).toString() + "</code>"); }  if (null != paramString2) paramCodeUnit.emit(" " + paramString2);  if (!paramBoolean3) paramCodeUnit.emitln();  }
/*      */   private void generateIsNullSignature(CodeUnit paramCodeUnit, boolean paramBoolean1, String paramString1, Type paramType, Ownership paramOwnership, String paramString2, boolean paramBoolean2, boolean paramBoolean3, String paramString3) { paramCodeUnit.emitln("  /**"); paramCodeUnit.emitln("   * Returns `true` if native pointer <code>" + paramString1 + "</code> is `null`, otherwise `false`."); generateArrayFieldNote(paramCodeUnit, "Corresponds to", null, paramString1, paramType, paramOwnership, paramBoolean2, paramBoolean3, paramString3, true, true); paramCodeUnit.emitln("   */"); paramCodeUnit.emit("  public " + (paramBoolean1 ? "abstract " : "final ") + "boolean is" + paramString2 + "Null()"); }
/*      */   private void generateReleaseSignature(CodeUnit paramCodeUnit, boolean paramBoolean1, String paramString1, Type paramType, Ownership paramOwnership, String paramString2, String paramString3, boolean paramBoolean2, boolean paramBoolean3, String paramString4) { paramCodeUnit.emitln("  /**"); generateArrayFieldNote(paramCodeUnit, "Releases memory referenced by", null, paramString1, paramType, paramOwnership, paramBoolean2, paramBoolean3, paramString4, true, false); paramCodeUnit.emitln("   */"); paramCodeUnit.emit("  public " + (paramBoolean1 ? "abstract " : "final ") + paramString2 + " release" + paramString3 + "()"); }
/*      */   private void generateGetterSignature(CodeUnit paramCodeUnit, boolean paramBoolean1, boolean paramBoolean2, String paramString1, Type paramType, Ownership paramOwnership, String paramString2, String paramString3, String paramString4, boolean paramBoolean3, boolean paramBoolean4, String paramString5, String paramString6) { paramCodeUnit.emitln("  /**"); generateArrayFieldNote(paramCodeUnit, "Getter for", null, paramString1, paramType, paramOwnership, paramBoolean3, paramBoolean4, paramString5, true, false); if (null != paramString6) paramCodeUnit.emitln("   * " + paramString6);  paramCodeUnit.emitln("   */"); paramCodeUnit.emit("  public " + (paramBoolean1 ? "static " : "final ") + (paramBoolean2 ? "abstract " : "") + paramString2 + " get" + paramString3 + "("); if (null != paramString4) paramCodeUnit.emit(paramString4);  paramCodeUnit.emit(")"); }
/* 1690 */   private void generateSetterSignature(CodeUnit paramCodeUnit, MethodAccess paramMethodAccess, boolean paramBoolean1, boolean paramBoolean2, String paramString1, Type paramType, Ownership paramOwnership, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, boolean paramBoolean3, boolean paramBoolean4, String paramString7, String paramString8, String paramString9) { paramCodeUnit.emitln("  /**"); generateArrayFieldNote(paramCodeUnit, "Setter for", null, paramString1, paramType, paramOwnership, paramBoolean3, paramBoolean4, paramString7, true, false); if (null != paramString8) { paramCodeUnit.emitln("   * <p>"); paramCodeUnit.emitln("   * " + paramString8); paramCodeUnit.emitln("   * </p>"); }  if (null != paramString9) paramCodeUnit.emitln(paramString9);  paramCodeUnit.emitln("   */"); paramCodeUnit.emit("  " + paramMethodAccess.getJavaName() + " " + (paramBoolean1 ? "static " : "final ") + (paramBoolean2 ? "abstract " : "") + paramString2 + " set" + paramString3 + "("); if (null != paramString4) paramCodeUnit.emit(paramString4 + ", ");  paramCodeUnit.emit(paramString5 + " src"); if (null != paramString6) paramCodeUnit.emit(", " + paramString6);  paramCodeUnit.emit(")"); } private void generateOffsetAndSizeArrays(CodeUnit paramCodeUnit, String paramString1, String paramString2, Type paramType, Field paramField, String paramString3) { if (null != paramField) { paramCodeUnit.emit(paramString1 + "private static final int[] " + paramString2 + "_offset = new int[] { "); for (byte b = 0; b < this.machDescTargetConfigs.length; b++) { if (0 < b) paramCodeUnit.emit(", ");  paramCodeUnit.emit(paramField.getOffset((this.machDescTargetConfigs[b]).md) + " /* " + this.machDescTargetConfigs[b].name() + " */"); }  paramCodeUnit.emitln(" };"); }  if (null != paramType) { paramCodeUnit.emit(paramString1 + "private static final int[] " + paramString2 + "_size = new int[] { "); for (byte b = 0; b < this.machDescTargetConfigs.length; b++) { if (0 < b) paramCodeUnit.emit(", ");  paramCodeUnit.emit(paramType.getSize((this.machDescTargetConfigs[b]).md) + " /* " + this.machDescTargetConfigs[b].name() + " */"); }  paramCodeUnit.emit("  };"); if (null != paramString3) { paramCodeUnit.emitln(paramString3); } else { paramCodeUnit.emitln(); }  }  } private void generateJavaCallbackCode(JavaConfiguration.JavaCallbackDef paramJavaCallbackDef, FunctionType paramFunctionType) { FunctionSymbol functionSymbol = new FunctionSymbol("callback", paramFunctionType); functionSymbol.addAliasedName(paramJavaCallbackDef.cbFuncTypeName); this.LOG.log(Level.INFO, "JavaCallback: fSym {0}, {1}", new Object[] { functionSymbol.getAliasedString(), paramJavaCallbackDef }); String str1 = CodeGenUtils.capitalizeString(paramJavaCallbackDef.cbFuncTypeName); String str2 = this.cfg.packageName() + "." + this.cfg.className() + "." + str1; JavaConfiguration.JavaCallbackInfo javaCallbackInfo = this.javaCallbackInterfaceMap.get(str2); if (null != javaCallbackInfo) { if (javaCallbackInfo.cbFuncUserParamIdx != paramJavaCallbackDef.cbFuncUserParamIdx) throw new UnsupportedOperationException("Reused FuncTypeName " + paramJavaCallbackDef.cbFuncTypeName + " used with different FuncUserParamIdx " + javaCallbackInfo.cbFuncUserParamIdx + " -> " + paramJavaCallbackDef.cbFuncUserParamIdx + ". Func " + paramFunctionType.toString(paramJavaCallbackDef.cbFuncTypeName, false, true));  JavaConfiguration.JavaCallbackInfo javaCallbackInfo1 = new JavaConfiguration.JavaCallbackInfo(paramJavaCallbackDef.cbFuncTypeName, str1, str2, javaCallbackInfo.staticCBMethodSignature, paramFunctionType, javaCallbackInfo.cbFuncBinding, javaCallbackInfo.cbFuncUserParamIdx, paramJavaCallbackDef.cbFuncKeyIndices, paramJavaCallbackDef.setFuncName, paramJavaCallbackDef.setFuncUserParamIdx, paramJavaCallbackDef.setFuncKeyIndices, paramJavaCallbackDef.userParamClassName, paramJavaCallbackDef.customKeyClassName); this.cfg.setFuncToJavaCallbackMap.put(paramJavaCallbackDef.setFuncName, javaCallbackInfo1); this.LOG.log(Level.INFO, "JavaCallbackInfo: Reusing {0} -> {1}", new Object[] { paramJavaCallbackDef.setFuncName, javaCallbackInfo }); } else { List<MethodBinding> list; StringBuilder stringBuilder = new StringBuilder(); if (!this.cfg.shouldIgnoreInInterface(paramJavaCallbackDef.cbFuncTypeName)) { this.javaUnit.emitln("  /** JavaCallback interface: " + paramJavaCallbackDef.cbFuncTypeName + " -> " + paramFunctionType.toString(paramJavaCallbackDef.cbFuncTypeName, false, true) + " */"); this.javaUnit.emitln("  public static interface " + str1 + " {"); list = generateFunctionInterfaceCode(this.javaUnit, functionSymbol, paramJavaCallbackDef, stringBuilder); this.javaUnit.emitln("  }"); this.javaUnit.emitln(); } else { this.LOG.log(Level.WARNING, "JavaCallbackInfo: Java Configuration indicate current JavaCallback must be ignored so assume JavaCallback meet presents requirements of {0}", paramJavaCallbackDef.setFuncName); list = generateFunctionInterfaceCode(null, functionSymbol, paramJavaCallbackDef, stringBuilder); }  if (1 != list.size()) throw new UnsupportedOperationException("Multiple bindings generated where only 1 is allowed for func " + paramFunctionType.toString(paramJavaCallbackDef.cbFuncTypeName, false, true));  MethodBinding methodBinding = list.get(0); if (!methodBinding.getJavaReturnType().isVoid() && !methodBinding.getJavaReturnType().isPrimitive()) throw new UnsupportedOperationException("Non void or non-primitive callback return types not suppored. Java " + methodBinding.getJavaReturnType() + ", func " + paramFunctionType.toString(paramJavaCallbackDef.cbFuncTypeName, false, true));  JavaConfiguration.JavaCallbackInfo javaCallbackInfo1 = new JavaConfiguration.JavaCallbackInfo(paramJavaCallbackDef.cbFuncTypeName, str1, str2, stringBuilder.toString(), paramFunctionType, methodBinding, paramJavaCallbackDef.cbFuncUserParamIdx, paramJavaCallbackDef.cbFuncKeyIndices, paramJavaCallbackDef.setFuncName, paramJavaCallbackDef.setFuncUserParamIdx, paramJavaCallbackDef.setFuncKeyIndices, paramJavaCallbackDef.userParamClassName, paramJavaCallbackDef.customKeyClassName); this.cfg.setFuncToJavaCallbackMap.put(paramJavaCallbackDef.setFuncName, javaCallbackInfo1); this.javaCallbackInterfaceMap.put(str2, javaCallbackInfo1); this.LOG.log(Level.INFO, "JavaCallbackInfo: Added {0} -> {1}", new Object[] { paramJavaCallbackDef.setFuncName, javaCallbackInfo1 }); }  } private String getArrayArrayLengthExpr(ArrayType paramArrayType, String paramString, boolean[] paramArrayOfboolean, int[][] paramArrayOfint) { int[] arrayOfInt = new int[paramArrayType.arrayDimension()];
/* 1691 */     paramArrayOfint[0] = arrayOfInt;
/* 1692 */     StringBuilder stringBuilder = new StringBuilder();
/* 1693 */     paramArrayOfboolean[0] = true;
/* 1694 */     ArrayType arrayType = paramArrayType;
/* 1695 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/* 1696 */       if (null != arrayType && arrayType.hasLength()) {
/* 1697 */         arrayOfInt[b] = arrayType.getLength();
/* 1698 */         if (0 < b) {
/* 1699 */           stringBuilder.append("*");
/*      */         }
/* 1701 */         stringBuilder.append(arrayOfInt[b]);
/*      */       } else {
/* 1703 */         arrayOfInt[b] = -1;
/* 1704 */         paramArrayOfboolean[0] = false;
/*      */       } 
/* 1706 */       if (null != arrayType) {
/* 1707 */         arrayType = arrayType.getTargetType().asArray();
/*      */       }
/*      */     } 
/* 1710 */     String str = this.cfg.returnedArrayLength(paramString);
/* 1711 */     if (null != str) {
/* 1712 */       if (paramArrayOfboolean[0]) {
/* 1713 */         this.LOG.log(Level.WARNING, paramArrayType.getASTLocusTag(), "struct array field '" + paramString + "' of '" + paramArrayType + "' length '" + 
/* 1714 */             Arrays.toString(arrayOfInt) + "' overwritten by cfg-expression: " + str);
/*      */       }
/* 1716 */       return str;
/*      */     } 
/* 1718 */     if (paramArrayOfboolean[0]) {
/* 1719 */       return stringBuilder.toString();
/*      */     }
/* 1721 */     this.LOG.log(Level.WARNING, paramArrayType.getASTLocusTag(), "struct array field '" + paramString + "' length '" + 
/* 1722 */         Arrays.toString(arrayOfInt) + "' without fixed- nor configured-size: {0}", paramArrayType);
/* 1723 */     return null; }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean requiresGetCStringLength(Type paramType, String paramString) {
/* 1728 */     if (!this.cfg.returnsString(paramString) && !this.cfg.returnsStringOnly(paramString)) {
/* 1729 */       return false;
/*      */     }
/* 1731 */     PointerType pointerType = paramType.asPointer();
/* 1732 */     if (null != pointerType) {
/* 1733 */       return (null == this.cfg.returnedArrayLength(paramString));
/*      */     }
/* 1735 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateArrayGetterSetterCode(JavaCodeUnit paramJavaCodeUnit, CompoundType paramCompoundType, JavaType paramJavaType, int paramInt, Field paramField, String paramString1, boolean paramBoolean, String paramString2) throws Exception {
/*      */     boolean bool4, bool5;
/*      */     boolean bool6;
/*      */     Ownership ownership;
/*      */     String str2;
/*      */     boolean bool7;
/*      */     boolean bool8;
/*      */     JavaType javaType;
/*      */     String str3;
/*      */     boolean bool9;
/*      */     boolean bool10;
/*      */     String str4;
/*      */     boolean bool11;
/*      */     boolean bool12;
/*      */     String str5;
/*      */     boolean bool13;
/*      */     String str6;
/*      */     boolean bool14, bool15;
/*      */     String str8, str9;
/* 1782 */     Type type1 = paramField.getType();
/* 1783 */     TypeInfo typeInfo = this.cfg.typeInfo(type1);
/* 1784 */     boolean bool1 = (null != typeInfo) ? true : false;
/* 1785 */     Type type2 = type1.getArrayBaseOrPointerTargetType();
/* 1786 */     if (GlueGen.debug()) {
/* 1787 */       System.err.printf("SE.ac.%02d: fieldName    %s, fqName %s%n", new Object[] { Integer.valueOf(paramInt + 1), paramString1, paramString2 });
/* 1788 */       System.err.printf("SE.ac.%02d: structCType  %s, %s%n", new Object[] { Integer.valueOf(paramInt + 1), paramCompoundType.toString(), paramCompoundType.getSignature(null).toString() });
/* 1789 */       System.err.printf("SE.ac.%02d: fieldType    %s, %s%n", new Object[] { Integer.valueOf(paramInt + 1), type1.toString(), type1.getSignature(null).toString() });
/* 1790 */       System.err.printf("SE.ac.%02d: opaqueInfo   %b, %s%n", new Object[] { Integer.valueOf(paramInt + 1), Boolean.valueOf(bool1), typeInfo });
/* 1791 */       System.err.printf("SE.ac.%02d: baseElemType %s, %s%n", new Object[] { Integer.valueOf(paramInt + 1), type2.toString(), type2.getSignature(null).toString() });
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1797 */     String str1 = paramJavaType.getName();
/* 1798 */     boolean bool2 = this.cfg.returnsStringOnly(paramString2);
/* 1799 */     boolean bool3 = (bool2 || this.cfg.returnsString(paramString2)) ? true : false;
/* 1800 */     if (bool3) {
/* 1801 */       paramJavaCodeUnit.addTailCode("  private static Charset _charset = StandardCharsets.UTF_8;\n\n  /** Returns the Charset for this class's String mapping, default is StandardCharsets.UTF_8. */\n  public static Charset getCharset() { return _charset; };\n\n  /** Sets the Charset for this class's String mapping, default is StandardCharsets.UTF_8. */\n  public static void setCharset(Charset cs) { _charset = cs; }\n");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1806 */     MethodAccess methodAccess = MethodAccess.PUBLIC;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1818 */     if ((bool1 && typeInfo.pointerDepth() <= 1) || (type1
/* 1819 */       .isPrimitive() && !type2.isFunctionPointer()) || (type1
/* 1820 */       .isPointer() && type2.isVoid())) {
/*      */ 
/*      */ 
/*      */       
/* 1824 */       bool5 = true;
/* 1825 */       bool4 = false;
/* 1826 */       bool6 = type1.isConst();
/* 1827 */       str2 = "1";
/* 1828 */       bool7 = true;
/* 1829 */       ownership = Ownership.Parent;
/* 1830 */       bool8 = true;
/* 1831 */       javaType = null;
/* 1832 */       str3 = compatiblePrimitiveJavaTypeName(type1, this.machDescJava);
/* 1833 */       bool9 = false;
/* 1834 */       bool10 = type1.isPointer();
/* 1835 */       str4 = bool10 ? "pointer" : str3;
/* 1836 */       bool11 = false;
/* 1837 */       bool12 = true;
/*      */     } else {
/* 1839 */       if (type1.arrayDimension() > 0) {
/* 1840 */         str5 = (String)new int[1][];
/* 1841 */         boolean[] arrayOfBoolean = { false };
/* 1842 */         str2 = getArrayArrayLengthExpr(type1.asArray(), paramString2, arrayOfBoolean, (int[][])str5);
/* 1843 */         if (null == str2) {
/* 1844 */           str6 = "SKIP unsized array in struct: " + paramString2 + ": " + type1.getSignature(null).toString();
/* 1845 */           paramJavaCodeUnit.emitln("  // " + str6);
/* 1846 */           paramJavaCodeUnit.emitln();
/* 1847 */           this.LOG.log(Level.WARNING, paramCompoundType.getASTLocusTag(), str6);
/*      */           
/*      */           return;
/*      */         } 
/* 1851 */         bool7 = arrayOfBoolean[0];
/* 1852 */         ownership = Ownership.Parent;
/* 1853 */         bool8 = bool7;
/*      */         
/* 1855 */         bool4 = false;
/* 1856 */         bool11 = false;
/*      */       } else {
/* 1858 */         str5 = this.cfg.returnedArrayLength(paramString2);
/* 1859 */         bool4 = true;
/* 1860 */         if (null == str5 && bool3) {
/* 1861 */           bool11 = true;
/* 1862 */           paramJavaCodeUnit.addTailCode("  private static int _max_strnlen = 8192;\n\n  /** Returns the maximum number of bytes to read to determine native string length using `strnlen(..)`, default is 8192. */\n  public static int getMaxStrnlen() { return _max_strnlen; };\n\n  /** Sets the maximum number of bytes to read to determine native string length using `strnlen(..)`, default is 8192. */\n  public static void setMaxStrnlen(int v) { _max_strnlen = v; }\n");
/* 1863 */           str2 = "Buffers.strnlen(pString, _max_strnlen)+1";
/* 1864 */           bool7 = false;
/* 1865 */           ownership = Ownership.Java;
/* 1866 */           bool8 = bool7;
/* 1867 */         } else if (null == str5) {
/* 1868 */           bool11 = false;
/* 1869 */           str2 = "0";
/* 1870 */           bool7 = false;
/* 1871 */           ownership = Ownership.Java;
/* 1872 */           bool8 = bool7;
/*      */         } else {
/*      */           
/* 1875 */           bool11 = false;
/* 1876 */           str2 = str5;
/* 1877 */           bool13 = false;
/* 1878 */           boolean bool16 = false;
/*      */ 
/*      */           
/*      */           try {
/* 1882 */             Integer.parseInt(str2);
/* 1883 */             bool13 = true;
/* 1884 */             bool16 = true;
/* 1885 */           } catch (Exception exception) {}
/* 1886 */           if (!bool13)
/*      */           {
/* 1888 */             if (str2.startsWith("get") && str2.endsWith("()")) {
/* 1889 */               String str10 = str2.substring(3, str2.length() - 2);
/* 1890 */               String str11 = CodeGenUtils.decapitalizeString(str10);
/* 1891 */               Field field = paramCompoundType.getField(str11);
/* 1892 */               if (null == field) {
/* 1893 */                 str11 = str10;
/* 1894 */                 field = paramCompoundType.getField(str11);
/*      */               } 
/* 1896 */               if (null == field) {
/* 1897 */                 throw new GlueGenException("Unable to creating array accessors for field \"" + paramString2 + "\", because elemCountExpr specify following getter \"" + str2 + "\" and host structure doesn't contain following field \"" + 
/*      */ 
/*      */                     
/* 1900 */                     CodeGenUtils.decapitalizeString(str10) + "\" or \"" + str10 + "\"", type1
/*      */                     
/* 1902 */                     .getASTLocusTag());
/*      */               }
/* 1904 */               bool13 = field.getType().isConst();
/* 1905 */               this.LOG.log(Level.INFO, paramCompoundType.getASTLocusTag(), paramJavaCodeUnit.className + ": elemCountExpr " + str2 + ", lenFieldName " + str11 + " -> " + field
/* 1906 */                   .toString() + ", isConst " + bool13);
/*      */             } 
/*      */           }
/* 1909 */           bool7 = bool13;
/* 1910 */           if (bool7) {
/* 1911 */             ownership = Ownership.Native;
/*      */           } else {
/* 1913 */             ownership = Ownership.Mixed;
/*      */           } 
/* 1915 */           bool8 = bool16;
/*      */         } 
/*      */       } 
/* 1918 */       boolean bool = this.cfg.maxOneElement(paramString2);
/* 1919 */       if (!bool) {
/*      */         try {
/* 1921 */           bool = (1 == Integer.parseInt(str2));
/* 1922 */         } catch (Exception exception) {}
/*      */       }
/* 1924 */       bool12 = bool;
/* 1925 */       if (GlueGen.debug()) {
/* 1926 */         System.err.printf("SE.ac.%02d: ownership %s%n", new Object[] { Integer.valueOf(paramInt + 1), ownership });
/*      */       }
/* 1928 */       bool10 = type2.isPointer();
/* 1929 */       bool6 = type2.isConst();
/* 1930 */       if (bool10) {
/* 1931 */         javaType = javaType(long.class);
/*      */       } else {
/*      */         try {
/* 1934 */           javaType = typeToJavaType(type2, this.machDescJava);
/* 1935 */         } catch (Exception exception) {
/* 1936 */           throw new GlueGenException("Error occurred while creating array/pointer accessor for field \"" + paramString2 + "\", baseType " + type2
/* 1937 */               .getDebugString() + ", topType " + type1.getDebugString(), type1
/* 1938 */               .getASTLocusTag(), exception);
/*      */         } 
/*      */       } 
/* 1941 */       str3 = javaType.getName();
/* 1942 */       bool5 = (javaType.isPrimitive() || type2.isPrimitive() || type2.isFunctionPointer()) ? true : false;
/* 1943 */       bool9 = bool5 ? type2.getSize().hasFixedNativeSize() : false;
/* 1944 */       str4 = bool10 ? "pointer" : str3;
/*      */     } 
/* 1946 */     if (GlueGen.debug()) {
/* 1947 */       System.err.printf("SE.ac.%02d: baseJElemType %s%n", new Object[] { Integer.valueOf(paramInt + 1), (null != javaType) ? javaType.getDebugString() : null });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1954 */     if (bool5) {
/* 1955 */       Class<?> clazz = Buffers.typeNameToBufferClass(str3);
/* 1956 */       if (null == clazz) {
/* 1957 */         String str = "Failed to map '" + str3 + "' to Buffer class, field " + paramField + ", j-type " + javaType;
/* 1958 */         paramJavaCodeUnit.emitln("  // ERROR: " + str);
/* 1959 */         paramJavaCodeUnit.emitln();
/* 1960 */         this.LOG.log(Level.SEVERE, paramCompoundType.getASTLocusTag(), str);
/* 1961 */         throw new InternalError(str);
/*      */       } 
/* 1963 */       str5 = clazz.getSimpleName();
/* 1964 */       bool13 = Buffers.sizeOfBufferElem(clazz);
/* 1965 */       bool14 = (null != clazz) ? ByteBuffer.class.isAssignableFrom(clazz) : false;
/* 1966 */       if (bool9) {
/* 1967 */         str6 = String.valueOf(bool13);
/*      */       } else {
/* 1969 */         str6 = "md." + str4 + "SizeInBytes()";
/*      */       } 
/*      */     } else {
/* 1972 */       str5 = null;
/* 1973 */       bool13 = false;
/* 1974 */       bool14 = false;
/* 1975 */       str6 = null;
/*      */     } 
/*      */     
/* 1978 */     String str7 = CodeGenUtils.capitalizeString(paramString1);
/*      */ 
/*      */     
/* 1981 */     if (bool7) {
/* 1982 */       bool15 = true;
/* 1983 */       str8 = "get" + str7 + "ElemCount()";
/* 1984 */       str9 = null;
/*      */     }
/* 1986 */     else if (bool11) {
/* 1987 */       bool15 = true;
/* 1988 */       str8 = "get" + str7 + "ElemCount()";
/* 1989 */       str9 = null;
/* 1990 */     } else if (str2.startsWith("get") && str2.endsWith("()")) {
/* 1991 */       bool15 = false;
/* 1992 */       str8 = str2;
/* 1993 */       str9 = "set" + str2.substring(3, str2.length() - 2);
/*      */     } else {
/* 1995 */       bool15 = true;
/* 1996 */       str8 = "get" + str7 + "ElemCount()";
/* 1997 */       str9 = "set" + str7 + "ElemCount";
/*      */     } 
/*      */     
/* 2000 */     if (GlueGen.debug()) {
/* 2001 */       System.err.printf("SE.ac.%02d: baseJElemTypeName %s%n", new Object[] { Integer.valueOf(paramInt + 1), str3 });
/* 2002 */       System.err.printf("SE.ac.%02d: elemCountExpr: %s (const %b, ownership %s), ownArrayLenCpde %b, maxOneElement %b, Primitive[is %b, aptr %b, buffer %s, fixedSize %b, elemSize %d, sizeDenom %s, sizeExpr %s, isByteBuffer %b], isString[%b, only %b, strnlen %b], isPointer %b, isOpaque %b, constVal %b, immutableAccess %b%n", new Object[] {
/*      */ 
/*      */             
/* 2005 */             Integer.valueOf(paramInt + 1), str2, Boolean.valueOf(bool7), ownership, Boolean.valueOf(bool15), Boolean.valueOf(bool12), 
/* 2006 */             Boolean.valueOf(bool5), Boolean.valueOf(bool10), str5, Boolean.valueOf(bool9), Integer.valueOf(bool13), str4, str6, Boolean.valueOf(bool14), 
/* 2007 */             Boolean.valueOf(bool3), Boolean.valueOf(bool2), Boolean.valueOf(bool11), 
/* 2008 */             Boolean.valueOf(bool4), Boolean.valueOf(bool1), Boolean.valueOf(bool6), Boolean.valueOf(paramBoolean)
/*      */           });
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2014 */     if (bool15) {
/* 2015 */       if (bool7) {
/* 2016 */         if (!bool5 || bool4 || !bool8 || !bool12) {
/* 2017 */           generateGetterSignature(paramJavaCodeUnit, bool8, false, paramString1, type1, ownership, "int", str7 + "ElemCount", null, bool7, bool12, str2, "@return element count of the corresponding field-array");
/* 2018 */           paramJavaCodeUnit.emitln(" { return " + str2 + "; }");
/*      */         } 
/* 2020 */       } else if (bool11) {
/* 2021 */         generateGetterSignature(paramJavaCodeUnit, bool8, false, paramString1, type1, ownership, "int", str7 + "ElemCount", null, bool7, bool12, str2, "@return element count of the corresponding field-array");
/* 2022 */         paramJavaCodeUnit.emitln(" {");
/* 2023 */         paramJavaCodeUnit.emitln("    final long pString = PointerBuffer.wrap( accessor.slice(" + paramString1 + "_offset[mdIdx],  PointerBuffer.POINTER_SIZE) ).get(0);");
/* 2024 */         paramJavaCodeUnit.emitln("    return 0 != pString ? " + str2 + " : 0;");
/* 2025 */         paramJavaCodeUnit.emitln("  }");
/*      */       } else {
/* 2027 */         paramJavaCodeUnit.emitln("  private int _" + paramString1 + "ArrayLen = " + str2 + "; // " + (bool7 ? "const" : "initial") + " array length");
/* 2028 */         generateGetterSignature(paramJavaCodeUnit, bool8, false, paramString1, type1, ownership, "int", str7 + "ElemCount", null, bool7, bool12, str2, "@return element count of the corresponding field-array");
/* 2029 */         paramJavaCodeUnit.emitln("  { return _" + paramString1 + "ArrayLen; }");
/* 2030 */         if (!paramBoolean) {
/* 2031 */           generateSetterSignature(paramJavaCodeUnit, MethodAccess.PRIVATE, bool8, false, paramString1, type1, ownership, "void", str7 + "ElemCount", null, "int", null, bool7, bool12, str2, null, null);
/*      */           
/* 2033 */           paramJavaCodeUnit.emitln("  { _" + paramString1 + "ArrayLen = src; }");
/*      */         } 
/*      */       } 
/* 2036 */       paramJavaCodeUnit.emitln();
/*      */     } 
/*      */ 
/*      */     
/* 2040 */     if (bool4) {
/* 2041 */       generateIsNullSignature(paramJavaCodeUnit, false, paramString1, type1, ownership, str7, bool7, bool12, str2);
/* 2042 */       paramJavaCodeUnit.emitln(" {");
/* 2043 */       paramJavaCodeUnit.emitln("    return 0 == PointerBuffer.wrap(getBuffer(), " + paramString1 + "_offset[mdIdx], 1).get(0);");
/* 2044 */       paramJavaCodeUnit.emitln("  }");
/* 2045 */       paramJavaCodeUnit.emitln();
/* 2046 */       if (!bool7 && !paramBoolean) {
/* 2047 */         generateReleaseSignature(paramJavaCodeUnit, false, paramString1, type1, ownership, str1, str7, bool7, bool12, str2);
/* 2048 */         paramJavaCodeUnit.emitln(" {");
/* 2049 */         paramJavaCodeUnit.emitln("    accessor.setLongAt(" + paramString1 + "_offset[mdIdx], 0, md.pointerSizeInBytes()); // write nullptr");
/* 2050 */         paramJavaCodeUnit.emitln("    _eb" + str7 + " = null;");
/* 2051 */         emitSetElemCount(paramJavaCodeUnit, str9, "0", !bool11, str7, (Type)paramCompoundType, "    ");
/* 2052 */         paramJavaCodeUnit.emitln("    return this;");
/* 2053 */         paramJavaCodeUnit.emitln("  }");
/* 2054 */         paramJavaCodeUnit.emitln("  @SuppressWarnings(\"unused\")");
/* 2055 */         if (bool10) {
/* 2056 */           paramJavaCodeUnit.emitln("  private PointerBuffer _eb" + str7 + "; // cache new memory buffer ensuring same lifecycle");
/*      */         } else {
/* 2058 */           paramJavaCodeUnit.emitln("  private ElementBuffer _eb" + str7 + "; // cache new memory buffer ensuring same lifecycle");
/*      */         } 
/* 2060 */         paramJavaCodeUnit.emitln();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2065 */     if (paramBoolean) {
/* 2066 */       generateArrayFieldNote(paramJavaCodeUnit, "  /** SKIP setter for immutable", " */", paramString1, type1, ownership, bool7, bool12, str2, false, false);
/* 2067 */       paramJavaCodeUnit.emitln();
/* 2068 */     } else if (bool4 && bool6 && (Ownership.Native == ownership || bool7)) {
/* 2069 */       generateArrayFieldNote(paramJavaCodeUnit, "  /** SKIP setter for constValue constElemCount Pointer w/ native ownership", " */", paramString1, type1, ownership, bool7, bool12, str2, false, false);
/* 2070 */       paramJavaCodeUnit.emitln();
/* 2071 */     } else if (!bool4 && bool6) {
/* 2072 */       generateArrayFieldNote(paramJavaCodeUnit, "  /** SKIP setter for constValue Array", " */", paramString1, type1, ownership, bool7, bool12, str2, false, false);
/* 2073 */       paramJavaCodeUnit.emitln();
/* 2074 */     } else if (bool5) {
/*      */       
/* 2076 */       if (bool12) {
/*      */         
/* 2078 */         if (bool4) {
/* 2079 */           generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, str3, null, bool7, bool12, str2, null, null);
/*      */           
/* 2081 */           if (bool6) {
/*      */             
/* 2083 */             if (Ownership.Native == ownership) {
/* 2084 */               throw new InternalError("Native ownership but adding potential memory-replacement for '" + paramString2 + "': " + type1.getSignature(null).toString());
/*      */             }
/* 2086 */             paramJavaCodeUnit.emitln(" {");
/* 2087 */             if (bool10) {
/* 2088 */               paramJavaCodeUnit.emitln("    final PointerBuffer eb = PointerBuffer.allocateDirect(1);");
/* 2089 */               paramJavaCodeUnit.emitln("    eb.put(0, src);");
/*      */             } else {
/* 2091 */               paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.allocateDirect(" + str6 + ", 1);");
/* 2092 */               paramJavaCodeUnit.emit("    eb.getByteBuffer()");
/* 2093 */               if (!bool14) {
/* 2094 */                 paramJavaCodeUnit.emit(".as" + str5 + "()");
/*      */               }
/* 2096 */               paramJavaCodeUnit.emitln(".put(0, src);");
/*      */             } 
/* 2098 */             paramJavaCodeUnit.emitln("    eb.storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2099 */             paramJavaCodeUnit.emitln("    _eb" + str7 + " = eb;");
/* 2100 */             emitSetElemCount(paramJavaCodeUnit, str9, "1", !bool11, str7, (Type)paramCompoundType, "      ");
/* 2101 */             paramJavaCodeUnit.emitln("    return this;");
/* 2102 */             paramJavaCodeUnit.emitln("  }");
/*      */           } else {
/* 2104 */             paramJavaCodeUnit.emitln(" {");
/* 2105 */             paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2106 */             paramJavaCodeUnit.emitln("    if( 1 == elemCount ) {");
/* 2107 */             if (bool10) {
/* 2108 */               paramJavaCodeUnit.emitln("      PointerBuffer.derefPointer(getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/* 2109 */               paramJavaCodeUnit.emitln("        .put(0, src);");
/*      */             } else {
/* 2111 */               paramJavaCodeUnit.emitln("      ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/* 2112 */               paramJavaCodeUnit.emit("        .getByteBuffer()");
/* 2113 */               if (!bool14) {
/* 2114 */                 paramJavaCodeUnit.emit(".as" + str5 + "()");
/*      */               }
/* 2116 */               paramJavaCodeUnit.emitln(".put(0, src);");
/*      */             } 
/* 2118 */             paramJavaCodeUnit.emitln("    } else {");
/* 2119 */             if (bool7 || Ownership.Native == ownership) {
/* 2120 */               paramJavaCodeUnit.emitln("      throw new RuntimeException(\"Primitive '" + paramString1 + "' of " + ownership + " ownership and maxOneElement has " + (
/* 2121 */                   bool7 ? "const" : "") + "elemCount \"+elemCount);");
/* 2122 */               paramJavaCodeUnit.emitln("    }");
/* 2123 */               paramJavaCodeUnit.emitln("    return this;");
/* 2124 */               paramJavaCodeUnit.emitln("  }");
/*      */             } else {
/* 2126 */               if (bool10) {
/* 2127 */                 paramJavaCodeUnit.emitln("      final PointerBuffer eb = PointerBuffer.allocateDirect(1);");
/* 2128 */                 paramJavaCodeUnit.emitln("      eb.put(0, src);");
/*      */               } else {
/* 2130 */                 paramJavaCodeUnit.emitln("      final ElementBuffer eb = ElementBuffer.allocateDirect(" + str6 + ", 1);");
/* 2131 */                 paramJavaCodeUnit.emit("      eb.getByteBuffer()");
/* 2132 */                 if (!bool14) {
/* 2133 */                   paramJavaCodeUnit.emit(".as" + str5 + "()");
/*      */                 }
/* 2135 */                 paramJavaCodeUnit.emitln(".put(0, src);");
/*      */               } 
/* 2137 */               paramJavaCodeUnit.emitln("      eb.storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2138 */               paramJavaCodeUnit.emitln("      _eb" + str7 + " = eb;");
/* 2139 */               emitSetElemCount(paramJavaCodeUnit, str9, "1", !bool11, str7, (Type)paramCompoundType, "      ");
/* 2140 */               paramJavaCodeUnit.emitln("    }");
/* 2141 */               paramJavaCodeUnit.emitln("    return this;");
/* 2142 */               paramJavaCodeUnit.emitln("  }");
/*      */             } 
/*      */           } 
/*      */         } else {
/* 2146 */           generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, str3, null, bool7, bool12, str2, null, null);
/*      */           
/* 2148 */           paramJavaCodeUnit.emitln(" {");
/* 2149 */           if (bool10) {
/* 2150 */             paramJavaCodeUnit.emitln("    PointerBuffer.wrap(getBuffer(), " + paramString1 + "_offset[mdIdx], 1).put(0, src);");
/*      */           } else {
/* 2152 */             paramJavaCodeUnit.emitln("    ElementBuffer.wrap(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/* 2153 */             paramJavaCodeUnit.emit("      .getByteBuffer()");
/* 2154 */             if (!bool14) {
/* 2155 */               paramJavaCodeUnit.emit(".as" + str5 + "()");
/*      */             }
/* 2157 */             paramJavaCodeUnit.emitln(".put(0, src);");
/*      */           } 
/* 2159 */           paramJavaCodeUnit.emitln("    return this;");
/* 2160 */           paramJavaCodeUnit.emitln("  }");
/*      */         } 
/* 2162 */         paramJavaCodeUnit.emitln();
/*      */       } else {
/*      */         
/* 2165 */         boolean bool = false;
/*      */         
/* 2167 */         if (bool3 && bool14 && bool4) {
/*      */           
/* 2169 */           generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, "String", null, bool7, bool12, str2, null, null);
/*      */           
/* 2171 */           paramJavaCodeUnit.emitln(" {");
/* 2172 */           paramJavaCodeUnit.emitln("    final byte[] srcBytes = src.getBytes(_charset);");
/* 2173 */           if (bool7 || Ownership.Native == ownership) {
/* 2174 */             paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2175 */             paramJavaCodeUnit.emitln("    if( srcBytes.length + 1 != elemCount ) { throw new IllegalArgumentException(\"strlen+1 \"+(srcBytes.length+1)+\" != " + (
/* 2176 */                 bool7 ? "const" : "") + " elemCount \"+elemCount+\" of " + ownership + " ownership\"); };");
/* 2177 */             paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */           } else {
/* 2179 */             paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.allocateDirect(" + str6 + ", srcBytes.length + 1);");
/*      */           } 
/* 2181 */           paramJavaCodeUnit.emitln("    eb.getByteBuffer().put(srcBytes, 0, srcBytes.length).put((byte)0).rewind(); // w/ EOS");
/* 2182 */           if (!bool7) {
/* 2183 */             paramJavaCodeUnit.emitln("    eb.storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2184 */             paramJavaCodeUnit.emitln("    _eb" + str7 + " = eb;");
/* 2185 */             emitSetElemCount(paramJavaCodeUnit, str9, "srcBytes.length + 1", !bool11, str7, (Type)paramCompoundType, "    ");
/*      */           } 
/* 2187 */           paramJavaCodeUnit.emitln("    return this;");
/* 2188 */           paramJavaCodeUnit.emitln("  }");
/* 2189 */           paramJavaCodeUnit.emitln();
/* 2190 */           bool = true;
/*      */         } 
/* 2192 */         if (bool && bool2) {
/* 2193 */           generateArrayFieldNote(paramJavaCodeUnit, "  /** SKIP setter for String alternative (ByteBuffer)", " */", paramString1, type1, ownership, bool7, bool12, str2, false, false);
/* 2194 */         } else if (bool6) {
/* 2195 */           if (bool4) {
/*      */             
/* 2197 */             generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, str3 + "[]", "final int srcPos, final int length", bool7, bool12, str2, "Replaces the respective field's memory with a new memory segment containing given source elements and referencing it.", "   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining");
/*      */             
/* 2199 */             if (Ownership.Native == ownership) {
/* 2200 */               throw new InternalError("Native ownership but adding potential memory-replacement for '" + paramString2 + "': " + type1.getSignature(null).toString());
/*      */             }
/* 2202 */             paramJavaCodeUnit.emitln(" {");
/*      */             
/* 2204 */             if (bool10) {
/* 2205 */               paramJavaCodeUnit.emitln("    final PointerBuffer eb = PointerBuffer.allocateDirect(length);");
/*      */             } else {
/* 2207 */               paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.allocateDirect(" + str6 + ", length);");
/*      */             } 
/* 2209 */             paramJavaCodeUnit.emitln("    eb.put(src, srcPos, 0, length).storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2210 */             paramJavaCodeUnit.emitln("    _eb" + str7 + " = eb;");
/* 2211 */             emitSetElemCount(paramJavaCodeUnit, str9, "length", !bool11, str7, (Type)paramCompoundType, "    ");
/* 2212 */             paramJavaCodeUnit.emitln("    return this;");
/* 2213 */             paramJavaCodeUnit.emitln("  }");
/*      */           } 
/* 2215 */         } else if (bool7 || !bool4) {
/* 2216 */           generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, str3 + "[]", "final int srcPos, final int destPos, final int length", bool7, bool12, str2, "Copies the given source elements into the respective field's existing memory.", "   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param destPos starting element position within the destination with 'destPos >= 0` && `destPos + length <= elemCount`, otherwise an exception is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length` && `destPos + length <= elemCount`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining");
/*      */           
/* 2218 */           paramJavaCodeUnit.emitln(" {");
/*      */           
/* 2220 */           paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/*      */           
/* 2222 */           if (bool10) {
/* 2223 */             if (bool4) {
/* 2224 */               paramJavaCodeUnit.emitln("    final PointerBuffer eb = PointerBuffer.derefPointer(getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */             } else {
/* 2226 */               paramJavaCodeUnit.emitln("    final PointerBuffer eb = PointerBuffer.wrap(getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */             }
/*      */           
/* 2229 */           } else if (bool4) {
/* 2230 */             paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */           } else {
/* 2232 */             paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.wrap(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */           } 
/*      */           
/* 2235 */           paramJavaCodeUnit.emitln("    eb.put(src, srcPos, destPos, length);");
/* 2236 */           paramJavaCodeUnit.emitln("    return this;");
/* 2237 */           paramJavaCodeUnit.emitln("  }");
/*      */         } else {
/* 2239 */           generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, "final boolean subset", str3 + "[]", "final int srcPos, final int destPos, final int length", bool7, bool12, str2, "Copies the given source elements into the respective field, either writing into the existing memory or creating a new memory and referencing it.", "   * @param subset if `true` keeps the underlying memory and only allows to set up to `elemCount` elements. Otherwise may replace the underlying memory if `destPos + length != elemCount`.\n   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param destPos starting element position within the destination with 'destPos >= 0`. If `subset == true`, `destPos + length <= elemCount` also must be be `true`. Otherwise an exception is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining");
/*      */           
/* 2241 */           if (Ownership.Native == ownership) {
/* 2242 */             throw new InternalError("Native ownership but adding potential memory-replacement for '" + paramString2 + "': " + type1.getSignature(null).toString());
/*      */           }
/* 2244 */           paramJavaCodeUnit.emitln(" {");
/*      */           
/* 2246 */           paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2247 */           paramJavaCodeUnit.emitln("    if( subset || destPos + length == elemCount ) {");
/*      */           
/* 2249 */           if (bool10) {
/* 2250 */             paramJavaCodeUnit.emitln("      final PointerBuffer eb = PointerBuffer.derefPointer(getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */           } else {
/* 2252 */             paramJavaCodeUnit.emitln("      final ElementBuffer eb = ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */           } 
/* 2254 */           paramJavaCodeUnit.emitln("      eb.put(src, srcPos, destPos, length);");
/* 2255 */           paramJavaCodeUnit.emitln("    } else {");
/* 2256 */           paramJavaCodeUnit.emitln("      final int newElemCount = destPos + length;");
/* 2257 */           if (bool10) {
/* 2258 */             paramJavaCodeUnit.emitln("      final PointerBuffer eb = PointerBuffer.allocateDirect(newElemCount);");
/* 2259 */             paramJavaCodeUnit.emitln("      if( 0 < destPos ) {");
/* 2260 */             paramJavaCodeUnit.emitln("        final PointerBuffer pre_eb = PointerBuffer.derefPointer(getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/* 2261 */             paramJavaCodeUnit.emitln("        pre_eb.position(0).limit(destPos);");
/* 2262 */             paramJavaCodeUnit.emitln("        eb.put(pre_eb).rewind();");
/* 2263 */             paramJavaCodeUnit.emitln("      }");
/*      */           } else {
/* 2265 */             paramJavaCodeUnit.emitln("      final ElementBuffer eb = ElementBuffer.allocateDirect(" + str6 + ", newElemCount);");
/* 2266 */             paramJavaCodeUnit.emitln("      if( 0 < destPos ) {");
/* 2267 */             paramJavaCodeUnit.emitln("        final ElementBuffer pre_eb = ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/* 2268 */             paramJavaCodeUnit.emitln("        eb.put(pre_eb.getByteBuffer(), 0, 0, destPos);");
/* 2269 */             paramJavaCodeUnit.emitln("      }");
/*      */           } 
/* 2271 */           paramJavaCodeUnit.emitln("      eb.put(src, srcPos, destPos, length);");
/* 2272 */           paramJavaCodeUnit.emitln("      eb.storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2273 */           paramJavaCodeUnit.emitln("      _eb" + str7 + " = eb;");
/* 2274 */           emitSetElemCount(paramJavaCodeUnit, str9, "newElemCount", !bool11, str7, (Type)paramCompoundType, "      ");
/* 2275 */           paramJavaCodeUnit.emitln("    }");
/* 2276 */           paramJavaCodeUnit.emitln("    return this;");
/* 2277 */           paramJavaCodeUnit.emitln("  }");
/*      */         } 
/* 2279 */         paramJavaCodeUnit.emitln();
/*      */       }
/*      */     
/*      */     }
/* 2283 */     else if (bool12) {
/*      */       
/* 2285 */       if (bool4) {
/* 2286 */         generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, str3, null, bool7, bool12, str2, null, null);
/*      */         
/* 2288 */         if (bool6) {
/*      */           
/* 2290 */           if (Ownership.Native == ownership) {
/* 2291 */             throw new InternalError("Native ownership but adding potential memory-replacement for '" + paramString2 + "': " + type1.getSignature(null).toString());
/*      */           }
/* 2293 */           paramJavaCodeUnit.emitln(" {");
/* 2294 */           paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.allocateDirect(" + str3 + ".size(), 1);");
/* 2295 */           paramJavaCodeUnit.emitln("    eb.put(0, src.getBuffer());");
/* 2296 */           paramJavaCodeUnit.emitln("    eb.storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2297 */           paramJavaCodeUnit.emitln("    _eb" + str7 + " = eb;");
/* 2298 */           emitSetElemCount(paramJavaCodeUnit, str9, "1", !bool11, str7, (Type)paramCompoundType, "      ");
/* 2299 */           paramJavaCodeUnit.emitln("    return this;");
/* 2300 */           paramJavaCodeUnit.emitln("  }");
/*      */         } else {
/* 2302 */           paramJavaCodeUnit.emitln(" {");
/* 2303 */           paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2304 */           paramJavaCodeUnit.emitln("    if( 1 == elemCount ) {");
/* 2305 */           paramJavaCodeUnit.emitln("      ElementBuffer.derefPointer(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/* 2306 */           paramJavaCodeUnit.emitln("        .put(0, src.getBuffer());");
/* 2307 */           paramJavaCodeUnit.emitln("    } else {");
/* 2308 */           if (bool7 || Ownership.Native == ownership) {
/* 2309 */             paramJavaCodeUnit.emitln("      throw new RuntimeException(\"Primitive '" + paramString1 + "' of " + ownership + " ownership and maxOneElement has " + (
/* 2310 */                 bool7 ? "const" : "") + "elemCount \"+elemCount);");
/* 2311 */             paramJavaCodeUnit.emitln("    }");
/* 2312 */             paramJavaCodeUnit.emitln("    return this;");
/* 2313 */             paramJavaCodeUnit.emitln("  }");
/*      */           } else {
/* 2315 */             paramJavaCodeUnit.emitln("      final ElementBuffer eb = ElementBuffer.allocateDirect(" + str3 + ".size(), 1);");
/* 2316 */             paramJavaCodeUnit.emitln("      eb.put(0, src.getBuffer());");
/* 2317 */             paramJavaCodeUnit.emitln("      eb.storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2318 */             paramJavaCodeUnit.emitln("      _eb" + str7 + " = eb;");
/* 2319 */             emitSetElemCount(paramJavaCodeUnit, str9, "1", !bool11, str7, (Type)paramCompoundType, "      ");
/* 2320 */             paramJavaCodeUnit.emitln("    }");
/* 2321 */             paramJavaCodeUnit.emitln("    return this;");
/* 2322 */             paramJavaCodeUnit.emitln("  }");
/*      */           } 
/*      */         } 
/* 2325 */       } else if (!bool6) {
/* 2326 */         generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, str3, null, bool7, bool12, str2, null, null);
/*      */         
/* 2328 */         paramJavaCodeUnit.emitln(" {");
/* 2329 */         paramJavaCodeUnit.emitln("    ElementBuffer.wrap(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/* 2330 */         paramJavaCodeUnit.emitln("      .put(0, src.getBuffer());");
/* 2331 */         paramJavaCodeUnit.emitln("    return this;");
/* 2332 */         paramJavaCodeUnit.emitln("  }");
/*      */       } 
/* 2334 */       paramJavaCodeUnit.emitln();
/*      */     } else {
/*      */       
/* 2337 */       if (bool6) {
/* 2338 */         if (bool4) {
/*      */           
/* 2340 */           generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, str3 + "[]", "final int srcPos, final int length", bool7, bool12, str2, "Replaces the respective field's memory with a new memory segment containing given source elements and referencing it.", "   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining");
/*      */           
/* 2342 */           if (Ownership.Native == ownership) {
/* 2343 */             throw new InternalError("Native ownership but adding potential memory-replacement for '" + paramString2 + "': " + type1.getSignature(null).toString());
/*      */           }
/* 2345 */           paramJavaCodeUnit.emitln(" {");
/* 2346 */           paramJavaCodeUnit.emitln("    if( 0 > srcPos || 0 > length || srcPos + length > src.length ) { throw new IndexOutOfBoundsException(\"src[pos \"+srcPos+\", length \"+src.length+\"], length \"+length); }");
/* 2347 */           paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.allocateDirect(" + str3 + ".size(), length);");
/* 2348 */           paramJavaCodeUnit.emitln("    for(int i=0; i<length; ++i) {");
/* 2349 */           paramJavaCodeUnit.emitln("      eb.put(i, src[srcPos+i].getBuffer());");
/* 2350 */           paramJavaCodeUnit.emitln("    }");
/* 2351 */           paramJavaCodeUnit.emitln("    eb.storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2352 */           paramJavaCodeUnit.emitln("    _eb" + str7 + " = eb;");
/* 2353 */           emitSetElemCount(paramJavaCodeUnit, str9, "length", !bool11, str7, (Type)paramCompoundType, "    ");
/* 2354 */           paramJavaCodeUnit.emitln("    return this;");
/* 2355 */           paramJavaCodeUnit.emitln("  }");
/*      */         } 
/* 2357 */       } else if (bool7 || !bool4) {
/* 2358 */         generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, null, str3 + "[]", "final int srcPos, final int destPos, final int length", bool7, bool12, str2, "Copies the given source elements into the respective field's existing memory.", "   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param destPos starting element position within the destination with 'destPos >= 0` && `destPos + length <= elemCount`, otherwise an exception is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length` && `destPos + length <= elemCount`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining");
/*      */         
/* 2360 */         paramJavaCodeUnit.emitln(" {");
/* 2361 */         paramJavaCodeUnit.emitln("    if( 0 > srcPos || 0 > destPos || 0 > length || srcPos + length > src.length ) { throw new IndexOutOfBoundsException(\"src[pos \"+srcPos+\", length \"+src.length+\"], destPos \"+destPos+\", length \"+length); }");
/* 2362 */         paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2363 */         paramJavaCodeUnit.emitln("    if( destPos + length > elemCount ) { throw new IndexOutOfBoundsException(\"destPos \"+destPos+\" + length \"+length+\" > elemCount \"+elemCount); };");
/* 2364 */         if (bool4) {
/* 2365 */           paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.derefPointer(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */         } else {
/* 2367 */           paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.wrap(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */         } 
/* 2369 */         paramJavaCodeUnit.emitln("    for(int i=0; i<length; ++i) {");
/* 2370 */         paramJavaCodeUnit.emitln("      eb.put(destPos+i, src[srcPos+i].getBuffer());");
/* 2371 */         paramJavaCodeUnit.emitln("    }");
/* 2372 */         paramJavaCodeUnit.emitln("    return this;");
/* 2373 */         paramJavaCodeUnit.emitln("  }");
/*      */       } else {
/* 2375 */         generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, "final boolean subset", str3 + "[]", "final int srcPos, final int destPos, final int length", bool7, bool12, str2, "Copies the given source elements into the respective field, either writing into the existing memory or creating a new memory and referencing it.", "   * @param subset if `true` keeps the underlying memory and only allows to set up to `elemCount` elements. Otherwise may replace the underlying memory if `destPos + length != elemCount`.\n   * @param src the source array of elements\n   * @param srcPos starting element position within the source array with 'srcPos >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @param destPos starting element position within the destination with 'destPos >= 0`. If `subset == true`, `destPos + length <= elemCount` also must be be `true`. Otherwise an exception is thrown\n   * @param length the element count to be copied with 'length >= 0` &&  `srcPos + length <= src.length`, otherwise an {@link IndexOutOfBoundsException} is thrown\n   * @return this instance of chaining");
/*      */         
/* 2377 */         if (Ownership.Native == ownership) {
/* 2378 */           throw new InternalError("Native ownership but adding potential memory-replacement for '" + paramString2 + "': " + type1.getSignature(null).toString());
/*      */         }
/* 2380 */         paramJavaCodeUnit.emitln(" {");
/* 2381 */         paramJavaCodeUnit.emitln("    if( 0 > srcPos || 0 > destPos || 0 > length || srcPos + length > src.length ) { throw new IndexOutOfBoundsException(\"subset \"+subset+\", src[pos \"+srcPos+\", length \"+src.length+\"], destPos \"+destPos+\", length \"+length); }");
/* 2382 */         paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2383 */         paramJavaCodeUnit.emitln("    if( subset || destPos + length == elemCount ) {");
/* 2384 */         paramJavaCodeUnit.emitln("      if( destPos + length > elemCount ) { throw new IndexOutOfBoundsException(\"subset \"+subset+\", destPos \"+destPos+\" + length \"+length+\" > elemCount \"+elemCount); };");
/* 2385 */         paramJavaCodeUnit.emitln("      final ElementBuffer eb = ElementBuffer.derefPointer(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/* 2386 */         paramJavaCodeUnit.emitln("      for(int i=0; i<length; ++i) {");
/* 2387 */         paramJavaCodeUnit.emitln("        eb.put(destPos+i, src[srcPos+i].getBuffer());");
/* 2388 */         paramJavaCodeUnit.emitln("      }");
/* 2389 */         paramJavaCodeUnit.emitln("    } else {");
/* 2390 */         paramJavaCodeUnit.emitln("      final int newElemCount = destPos + length;");
/* 2391 */         paramJavaCodeUnit.emitln("      final ElementBuffer eb = ElementBuffer.allocateDirect(" + str3 + ".size(), newElemCount);");
/*      */         
/* 2393 */         paramJavaCodeUnit.emitln("      if( 0 < destPos ) {");
/* 2394 */         paramJavaCodeUnit.emitln("        final ElementBuffer pre_eb = ElementBuffer.derefPointer(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/* 2395 */         paramJavaCodeUnit.emitln("        eb.put(pre_eb.getByteBuffer(), 0, 0, destPos);");
/* 2396 */         paramJavaCodeUnit.emitln("      }");
/* 2397 */         paramJavaCodeUnit.emitln("      for(int i=0; i<length; ++i) {");
/* 2398 */         paramJavaCodeUnit.emitln("        eb.put(destPos+i, src[srcPos+i].getBuffer());");
/* 2399 */         paramJavaCodeUnit.emitln("      }");
/* 2400 */         paramJavaCodeUnit.emitln("      eb.storeDirectAddress(getBuffer(), " + paramString1 + "_offset[mdIdx]);");
/* 2401 */         paramJavaCodeUnit.emitln("      _eb" + str7 + " = eb;");
/* 2402 */         emitSetElemCount(paramJavaCodeUnit, str9, "newElemCount", !bool11, str7, (Type)paramCompoundType, "      ");
/* 2403 */         paramJavaCodeUnit.emitln("    }");
/* 2404 */         paramJavaCodeUnit.emitln("    return this;");
/* 2405 */         paramJavaCodeUnit.emitln("  }");
/*      */       } 
/* 2407 */       paramJavaCodeUnit.emitln();
/* 2408 */       if (!bool6) {
/* 2409 */         generateSetterSignature(paramJavaCodeUnit, methodAccess, false, false, paramString1, type1, ownership, str1, str7, "final int destPos", str3, null, bool7, bool12, str2, null, null);
/*      */         
/* 2411 */         paramJavaCodeUnit.emitln(" {");
/* 2412 */         paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2413 */         paramJavaCodeUnit.emitln("    if( destPos + 1 > elemCount ) { throw new IndexOutOfBoundsException(\"destPos \"+destPos+\" + 1 > elemCount \"+elemCount); };");
/* 2414 */         if (bool4) {
/* 2415 */           paramJavaCodeUnit.emitln("    ElementBuffer.derefPointer(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount)");
/*      */         } else {
/* 2417 */           paramJavaCodeUnit.emitln("    ElementBuffer.wrap(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount)");
/*      */         } 
/* 2419 */         paramJavaCodeUnit.emitln("      .put(destPos, src.getBuffer());");
/* 2420 */         paramJavaCodeUnit.emitln("    return this;");
/* 2421 */         paramJavaCodeUnit.emitln("  }");
/* 2422 */         paramJavaCodeUnit.emitln();
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2428 */     if (bool5) {
/*      */       
/* 2430 */       if (bool12) {
/* 2431 */         generateGetterSignature(paramJavaCodeUnit, false, false, paramString1, type1, ownership, str3, str7, null, bool7, bool12, str2, "@return element value of the corresponding field-array");
/*      */         
/* 2433 */         paramJavaCodeUnit.emitln(" {");
/* 2434 */         if (bool10) {
/* 2435 */           if (bool4) {
/* 2436 */             paramJavaCodeUnit.emit("    return PointerBuffer.derefPointer(getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/*      */           } else {
/* 2438 */             paramJavaCodeUnit.emit("    return PointerBuffer.wrap(getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/*      */           } 
/*      */         } else {
/* 2441 */           if (bool4) {
/* 2442 */             paramJavaCodeUnit.emitln("    return ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/*      */           } else {
/* 2444 */             paramJavaCodeUnit.emitln("    return ElementBuffer.wrap(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], 1)");
/*      */           } 
/* 2446 */           paramJavaCodeUnit.emit("             .getByteBuffer()");
/* 2447 */           if (!bool14) {
/* 2448 */             paramJavaCodeUnit.emit(".as" + str5 + "()");
/*      */           }
/*      */         } 
/* 2451 */         paramJavaCodeUnit.emitln(".get(0);");
/* 2452 */         paramJavaCodeUnit.emitln("  }");
/* 2453 */         paramJavaCodeUnit.emitln();
/*      */       } else {
/* 2455 */         boolean bool = false;
/* 2456 */         if (bool3 && bool14) {
/* 2457 */           generateGetterSignature(paramJavaCodeUnit, false, false, paramString1, type1, ownership, "String", str7 + (bool2 ? "" : "AsString"), null, bool7, bool12, str2, "@return element value of the corresponding field-array");
/*      */           
/* 2459 */           paramJavaCodeUnit.emitln(" {");
/* 2460 */           paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2461 */           if (bool4) {
/* 2462 */             paramJavaCodeUnit.emitln("    final ByteBuffer bb = ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount).getByteBuffer();");
/*      */           } else {
/* 2464 */             paramJavaCodeUnit.emitln("    final ByteBuffer bb = ElementBuffer.wrap(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount).getByteBuffer();");
/*      */           } 
/* 2466 */           paramJavaCodeUnit.emitln("    final byte[] ba = new byte[elemCount];");
/* 2467 */           paramJavaCodeUnit.emitln("    int i = -1;");
/* 2468 */           paramJavaCodeUnit.emitln("    while( ++i < elemCount ) {");
/* 2469 */           paramJavaCodeUnit.emitln("      ba[i] = bb.get(i);");
/* 2470 */           paramJavaCodeUnit.emitln("      if( (byte)0 == ba[i] ) break;");
/* 2471 */           paramJavaCodeUnit.emitln("    }");
/* 2472 */           paramJavaCodeUnit.emitln("    return new String(ba, 0, i, _charset);");
/* 2473 */           paramJavaCodeUnit.emitln("  }");
/* 2474 */           paramJavaCodeUnit.emitln();
/* 2475 */           bool = true;
/*      */         } 
/* 2477 */         if (bool && bool2) {
/* 2478 */           generateArrayFieldNote(paramJavaCodeUnit, "  /** SKIP getter for String alternative (ByteBuffer)", " */", paramString1, type1, ownership, bool7, bool12, str2, false, false);
/* 2479 */           paramJavaCodeUnit.emitln();
/* 2480 */         } else if (!bool10) {
/* 2481 */           generateGetterSignature(paramJavaCodeUnit, false, false, paramString1, type1, ownership, str5, str7, null, bool7, bool12, str2, "@return element value of the corresponding field-array");
/*      */           
/* 2483 */           paramJavaCodeUnit.emitln(" {");
/* 2484 */           if (bool4) {
/* 2485 */             paramJavaCodeUnit.emitln("    return ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], " + str8 + ")");
/*      */           } else {
/* 2487 */             paramJavaCodeUnit.emitln("    return ElementBuffer.wrap(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], " + str8 + ")");
/*      */           } 
/* 2489 */           paramJavaCodeUnit.emit("             .getByteBuffer()");
/* 2490 */           if (!bool14) {
/* 2491 */             paramJavaCodeUnit.emit(".as" + str5 + "()");
/*      */           }
/* 2493 */           paramJavaCodeUnit.emitln(";");
/* 2494 */           paramJavaCodeUnit.emitln("  }");
/* 2495 */           paramJavaCodeUnit.emitln();
/*      */         } 
/* 2497 */         if (!bool) {
/* 2498 */           generateGetterSignature(paramJavaCodeUnit, false, false, paramString1, type1, ownership, str3 + "[]", str7, "final int srcPos, " + str3 + " dest[], " + "final int destPos, final int length", bool7, bool12, str2, "@return element value of the corresponding field-array");
/*      */           
/* 2500 */           paramJavaCodeUnit.emitln(" {");
/* 2501 */           paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2502 */           if (bool10) {
/* 2503 */             if (bool4) {
/* 2504 */               paramJavaCodeUnit.emit("    PointerBuffer.derefPointer(getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount)");
/*      */             } else {
/* 2506 */               paramJavaCodeUnit.emit("    PointerBuffer.wrap(getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount)");
/*      */             }
/*      */           
/* 2509 */           } else if (bool4) {
/* 2510 */             paramJavaCodeUnit.emit("    ElementBuffer.derefPointer(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount)");
/*      */           } else {
/* 2512 */             paramJavaCodeUnit.emit("    ElementBuffer.wrap(" + str6 + ", getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount)");
/*      */           } 
/*      */           
/* 2515 */           paramJavaCodeUnit.emitln(".get(srcPos, dest, destPos, length);");
/* 2516 */           paramJavaCodeUnit.emitln("    return dest;");
/* 2517 */           paramJavaCodeUnit.emitln("  }");
/* 2518 */           paramJavaCodeUnit.emitln();
/*      */         }
/*      */       
/*      */       }
/*      */     
/* 2523 */     } else if (bool12) {
/* 2524 */       generateGetterSignature(paramJavaCodeUnit, false, false, paramString1, type1, ownership, str3, str7, null, bool7, bool12, str2, "@return element value of the corresponding field-array");
/*      */       
/* 2526 */       paramJavaCodeUnit.emitln(" {");
/* 2527 */       paramJavaCodeUnit.emitln("    return " + str3 + ".create(");
/* 2528 */       if (bool4) {
/* 2529 */         paramJavaCodeUnit.emitln("             ElementBuffer.derefPointer(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], 1).getByteBuffer() );");
/*      */       } else {
/* 2531 */         paramJavaCodeUnit.emitln("             ElementBuffer.wrap(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], 1).getByteBuffer() );");
/*      */       } 
/* 2533 */       paramJavaCodeUnit.emitln("  }");
/* 2534 */       paramJavaCodeUnit.emitln();
/*      */     } else {
/* 2536 */       generateGetterSignature(paramJavaCodeUnit, false, false, paramString1, type1, ownership, str3 + "[]", str7, "final int srcPos, " + str3 + " dest[], " + "final int destPos, final int length", bool7, bool12, str2, "@return element value of the corresponding field-array");
/*      */       
/* 2538 */       paramJavaCodeUnit.emitln(" {");
/* 2539 */       paramJavaCodeUnit.emitln("    if( 0 > srcPos || 0 > destPos || 0 > length || destPos + length > dest.length ) { throw new IndexOutOfBoundsException(\"dest[pos \"+destPos+\", length \"+dest.length+\"], srcPos \"+srcPos+\", length \"+length); }");
/* 2540 */       paramJavaCodeUnit.emitln("    final int elemCount = " + str8 + ";");
/* 2541 */       paramJavaCodeUnit.emitln("    if( srcPos + length > elemCount ) { throw new IndexOutOfBoundsException(\"srcPos \"+srcPos+\" + length \"+length+\" > elemCount \"+elemCount); };");
/* 2542 */       if (bool4) {
/* 2543 */         paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.derefPointer(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */       } else {
/* 2545 */         paramJavaCodeUnit.emitln("    final ElementBuffer eb = ElementBuffer.wrap(" + str3 + ".size(), getBuffer(), " + paramString1 + "_offset[mdIdx], elemCount);");
/*      */       } 
/* 2547 */       paramJavaCodeUnit.emitln("    for(int i=0; i<length; ++i) {");
/* 2548 */       paramJavaCodeUnit.emitln("      dest[destPos+i] = " + str3 + ".create( eb.slice(srcPos+i, 1) );");
/* 2549 */       paramJavaCodeUnit.emitln("    }");
/* 2550 */       paramJavaCodeUnit.emitln("    return dest;");
/* 2551 */       paramJavaCodeUnit.emitln("  }");
/* 2552 */       paramJavaCodeUnit.emitln();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void emitSetElemCount(JavaCodeUnit paramJavaCodeUnit, String paramString1, String paramString2, boolean paramBoolean, String paramString3, Type paramType, String paramString4) {
/* 2557 */     if (null != paramString1) {
/* 2558 */       paramJavaCodeUnit.emitln(paramString4 + paramString1 + "( " + paramString2 + " );");
/* 2559 */     } else if (paramBoolean) {
/* 2560 */       String str = "Missing set" + paramString3 + "ElemCount( " + paramString2 + " )";
/* 2561 */       paramJavaCodeUnit.emitln(paramString4 + "// ERROR: " + str);
/* 2562 */       paramJavaCodeUnit.emitln();
/* 2563 */       this.LOG.log(Level.SEVERE, paramType.getASTLocusTag(), str);
/* 2564 */       throw new RuntimeException(str);
/*      */     } 
/*      */   }
/*      */   
/*      */   private JavaType typeToJavaType(Type paramType, MachineDataInfo paramMachineDataInfo) {
/* 2569 */     JavaType javaType = typeToJavaTypeImpl(paramType, paramMachineDataInfo);
/* 2570 */     this.LOG.log(Level.FINE, paramType.getASTLocusTag(), "typeToJavaType: {0} -> {1}", new Object[] { paramType, javaType });
/* 2571 */     return javaType;
/*      */   }
/*      */   private boolean isJNIEnvPointer(Type paramType) {
/* 2574 */     PointerType pointerType = paramType.asPointer();
/* 2575 */     return (pointerType != null && pointerType
/* 2576 */       .getTargetType().getName() != null && pointerType
/* 2577 */       .getTargetType().getName().equals("JNIEnv"));
/*      */   }
/*      */   
/*      */   private JavaType typeToJavaTypeImpl(Type paramType, MachineDataInfo paramMachineDataInfo) {
/* 2581 */     if (isJNIEnvPointer(paramType)) {
/* 2582 */       return JavaType.createForJNIEnv();
/*      */     }
/*      */ 
/*      */     
/* 2586 */     TypeInfo typeInfo = this.cfg.typeInfo(paramType);
/* 2587 */     if (typeInfo != null) {
/* 2588 */       boolean bool = false;
/* 2589 */       if (paramType.pointerDepth() > 0 || paramType.arrayDimension() > 0) {
/*      */         
/* 2591 */         Type type = paramType.getArrayBaseOrPointerTargetType();
/* 2592 */         if (paramType.pointerDepth() == 2 || paramType.arrayDimension() == 2)
/*      */         {
/*      */ 
/*      */           
/* 2596 */           if (type.isPointer()) {
/* 2597 */             bool = true;
/* 2598 */             if (GlueGen.debug()) {
/*      */               
/* 2600 */               Type type1 = type.asPointer().getTargetType();
/* 2601 */               this.LOG.log(Level.INFO, paramType.getASTLocusTag(), "Opaque Type: {0}, targetType: {1}, bottomType: {2} is ptr-ptr", new Object[] { paramType, type, type1 });
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */       
/* 2607 */       if (!bool) {
/* 2608 */         return typeInfo.javaType();
/*      */       }
/*      */     } 
/*      */     
/* 2612 */     if (paramType.isInt() || paramType.isEnum()) {
/* 2613 */       switch ((int)paramType.getSize(paramMachineDataInfo)) { case 1:
/* 2614 */           return javaType(byte.class);
/* 2615 */         case 2: return javaType(short.class);
/* 2616 */         case 4: return javaType(int.class);
/* 2617 */         case 8: return javaType(long.class); }
/* 2618 */        throw new GlueGenException("Unknown integer type of size " + paramType
/* 2619 */           .getSize(paramMachineDataInfo) + " and name " + paramType.getName(), paramType
/* 2620 */           .getASTLocusTag());
/*      */     } 
/* 2622 */     if (paramType.isFloat())
/* 2623 */       return javaType(float.class); 
/* 2624 */     if (paramType.isDouble())
/* 2625 */       return javaType(double.class); 
/* 2626 */     if (paramType.isVoid())
/* 2627 */       return javaType(void.class); 
/* 2628 */     if (paramType.pointerDepth() > 0 || paramType.arrayDimension() > 0) {
/*      */       
/* 2630 */       Type type = paramType.getArrayBaseOrPointerTargetType();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2635 */       if (paramType.pointerDepth() == 1 || paramType.arrayDimension() == 1) {
/* 2636 */         if (type.isVoid())
/* 2637 */           return JavaType.createForCVoidPointer(); 
/* 2638 */         if (type.isFunctionPointer())
/* 2639 */           return javaType(long.class); 
/* 2640 */         if (type.isInt()) {
/* 2641 */           SizeThunk sizeThunk = type.getSize();
/* 2642 */           if (null != sizeThunk && SizeThunk.POINTER == sizeThunk)
/*      */           {
/* 2644 */             return JavaType.forNIOPointerBufferClass();
/*      */           }
/* 2646 */           switch ((int)type.getSize(paramMachineDataInfo)) { case 1:
/* 2647 */               return JavaType.createForCCharPointer();
/* 2648 */             case 2: return JavaType.createForCShortPointer();
/* 2649 */             case 4: return JavaType.createForCInt32Pointer();
/* 2650 */             case 8: return JavaType.createForCInt64Pointer(); }
/* 2651 */            throw new GlueGenException("Unknown integer array type of size " + paramType
/* 2652 */               .getSize(paramMachineDataInfo) + " and name " + paramType.getName() + ", " + paramType.getDebugString() + ", target " + type
/* 2653 */               .getDebugString(), paramType
/* 2654 */               .getASTLocusTag());
/*      */         } 
/* 2656 */         if (type.isFloat())
/* 2657 */           return JavaType.createForCFloatPointer(); 
/* 2658 */         if (type.isDouble())
/* 2659 */           return JavaType.createForCDoublePointer(); 
/* 2660 */         if (type.isCompound()) {
/* 2661 */           String str; if (paramType.isArray()) {
/* 2662 */             return JavaType.createForCArray(type);
/*      */           }
/*      */           
/* 2665 */           if (paramType.getName() != null && paramType
/* 2666 */             .getName().equals("jobject")) {
/* 2667 */             return javaType(Object.class);
/*      */           }
/*      */ 
/*      */           
/* 2671 */           if (!type.isTypedef() && paramType.isTypedef()) {
/*      */             
/* 2673 */             str = paramType.getName();
/*      */           } else {
/*      */             
/* 2676 */             str = type.getName();
/* 2677 */             if (null == str) {
/*      */               
/* 2679 */               str = paramType.getName();
/* 2680 */               if (str == null) {
/* 2681 */                 throw new GlueGenException("Couldn't find a proper type name for pointer type " + paramType.getDebugString() + ", target " + type
/* 2682 */                     .getDebugString(), paramType
/* 2683 */                     .getASTLocusTag());
/*      */               }
/*      */             } 
/*      */           } 
/* 2687 */           return JavaType.createForCStruct(this.cfg.renameJavaType(str));
/*      */         } 
/* 2689 */         throw new GlueGenException("Don't know how to convert pointer/array type " + paramType
/* 2690 */             .getDebugString() + ", target " + type.getDebugString(), paramType
/* 2691 */             .getASTLocusTag());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2696 */       if (paramType.pointerDepth() == 2 || paramType.arrayDimension() == 2) {
/*      */         Type type1;
/*      */ 
/*      */ 
/*      */         
/* 2701 */         if (type.isPointer()) {
/*      */           
/* 2703 */           type1 = type.asPointer().getTargetType();
/* 2704 */           if (GlueGen.debug()) {
/* 2705 */             this.LOG.log(Level.INFO, paramType.getASTLocusTag(), "typeToJavaType(ptr-ptr): {0}, targetType: {1}, bottomType: {2}", new Object[] { paramType
/* 2706 */                   .getDebugString(), type.getDebugString(), type1.getDebugString() });
/*      */           }
/* 2708 */           return JavaType.forNIOPointerBufferClass();
/* 2709 */         }  if (type.isArray()) {
/*      */           
/* 2711 */           type1 = type.getBaseType();
/* 2712 */           if (GlueGen.debug()) {
/* 2713 */             this.LOG.log(Level.INFO, paramType.getASTLocusTag(), "typeToJavaType(ptr-ptr.array): {0}, targetType: {1}, bottomType: {2}", new Object[] { paramType
/* 2714 */                   .getDebugString(), type.getDebugString(), type1.getDebugString() });
/*      */           }
/*      */         } else {
/* 2717 */           type1 = type;
/* 2718 */           if (GlueGen.debug()) {
/* 2719 */             this.LOG.log(Level.INFO, paramType.getASTLocusTag(), "typeToJavaType(ptr-ptr.primitive): {0}, targetType: {1}, bottomType: {2}", new Object[] { paramType
/* 2720 */                   .getDebugString(), type.getDebugString(), type1.getDebugString() });
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2727 */         if (type1.isPrimitive()) {
/* 2728 */           if (type1.isInt()) {
/* 2729 */             switch ((int)type1.getSize(paramMachineDataInfo)) { case 1:
/* 2730 */                 return javaType(ArrayTypes.byteBufferArrayClass);
/* 2731 */               case 2: return javaType(ArrayTypes.shortBufferArrayClass);
/* 2732 */               case 4: return javaType(ArrayTypes.intBufferArrayClass);
/* 2733 */               case 8: return javaType(ArrayTypes.longBufferArrayClass); }
/* 2734 */              throw new GlueGenException("Unknown two-dimensional integer array type of element size " + type1
/* 2735 */                 .getSize(paramMachineDataInfo) + " and name " + type1.getName() + ", " + type1.getDebugString(), type1
/* 2736 */                 .getASTLocusTag());
/*      */           } 
/* 2738 */           if (type1.isFloat())
/* 2739 */             return javaType(ArrayTypes.floatBufferArrayClass); 
/* 2740 */           if (type1.isDouble()) {
/* 2741 */             return javaType(ArrayTypes.doubleBufferArrayClass);
/*      */           }
/* 2743 */           throw new GlueGenException("Unexpected primitive type " + type1.getDebugString() + " in two-dimensional array", type1
/* 2744 */               .getASTLocusTag());
/*      */         } 
/* 2746 */         if (type1.isVoid())
/* 2747 */           return javaType(ArrayTypes.bufferArrayClass); 
/* 2748 */         if (type.isPointer() && type.pointerDepth() == 1 && type
/* 2749 */           .asPointer().getTargetType().isCompound())
/*      */         {
/* 2751 */           return JavaType.createForCArray(type1);
/*      */         }
/* 2753 */         throw new GlueGenException("Could not convert C type " + paramType
/* 2754 */             .getDebugString() + " to appropriate Java type; need to add more support for depth=2 pointer/array types [debug info: targetType=" + type
/*      */ 
/*      */             
/* 2757 */             .getDebugString() + "]", paramType.getASTLocusTag());
/*      */       } 
/*      */ 
/*      */       
/* 2761 */       throw new GlueGenException("Could not convert C pointer/array " + paramType
/* 2762 */           .getDebugString() + " to appropriate Java type; types with pointer/array depth greater than 2 are not yet supported [debug info: pointerDepth=" + paramType
/*      */ 
/*      */           
/* 2765 */           .pointerDepth() + " arrayDimension=" + paramType
/* 2766 */           .arrayDimension() + " targetType=" + type.getDebugString() + "]", paramType
/* 2767 */           .getASTLocusTag());
/*      */     } 
/*      */     
/* 2770 */     if (paramType.isCompound()) {
/* 2771 */       String str = paramType.getName();
/* 2772 */       if (str == null) {
/* 2773 */         str = paramType.asCompound().getStructName();
/* 2774 */         if (str == null) {
/* 2775 */           throw new GlueGenException("Couldn't find a proper type name for pointer type " + paramType.getDebugString(), paramType
/* 2776 */               .getASTLocusTag());
/*      */         }
/*      */       } 
/* 2779 */       return JavaType.createForCStruct(this.cfg.renameJavaType(str));
/*      */     } 
/* 2781 */     throw new GlueGenException("Could not convert C type " + paramType
/* 2782 */         .getDebugString() + " (class " + paramType
/* 2783 */         .getClass().getName() + ") to appropriate Java type", paramType
/* 2784 */         .getASTLocusTag());
/*      */   }
/*      */ 
/*      */   
/*      */   private StructLayout getLayout() {
/* 2789 */     if (this.layout == null) {
/* 2790 */       this.layout = StructLayout.create(0);
/*      */     }
/* 2792 */     return this.layout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CCodeUnit openCUnit(String paramString1, String paramString2) throws IOException {
/* 2802 */     return new CCodeUnit(paramString1, paramString2, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaCodeUnit openJavaUnit(String paramString1, String paramString2, String paramString3) throws IOException {
/* 2813 */     return new JavaCodeUnit(paramString1, paramString2, paramString3, this);
/*      */   }
/*      */   
/*      */   private boolean isOpaque(Type paramType) {
/* 2817 */     return (null != this.cfg.typeInfo(paramType));
/*      */   }
/*      */ 
/*      */   
/*      */   private String compatiblePrimitiveJavaTypeName(Type paramType, MachineDataInfo paramMachineDataInfo) {
/* 2822 */     if (!paramType.isInt() && !paramType.isPointer() && !paramType.isArray()) {
/* 2823 */       throw new GlueGenException("Can't yet handle opaque definitions of structs' fields to non-integer types (byte, short, int, long, etc.): type: " + paramType, paramType
/* 2824 */           .getASTLocusTag());
/*      */     }
/* 2826 */     switch ((int)paramType.getSize(paramMachineDataInfo)) { case 1:
/* 2827 */         return "byte";
/* 2828 */       case 2: return "short";
/* 2829 */       case 4: return "int";
/* 2830 */       case 8: return "long"; }
/* 2831 */      throw new GlueGenException("Can't handle opaque definitions if the starting type isn't compatible with integral types, type " + paramType
/* 2832 */         .getDebugString(), paramType.getASTLocusTag());
/*      */   }
/*      */ 
/*      */   
/*      */   private void openCodeUnits() throws IOException {
/* 2837 */     String str1 = null;
/* 2838 */     if (this.cfg.allStatic() || this.cfg.emitInterface())
/*      */     {
/* 2840 */       str1 = this.cfg.javaOutputDir() + File.separator + CodeGenUtils.packageAsPath(this.cfg.packageName());
/*      */     }
/* 2842 */     String str2 = null;
/* 2843 */     if (!this.cfg.allStatic())
/*      */     {
/*      */       
/* 2846 */       str2 = this.cfg.javaOutputDir() + File.separator + CodeGenUtils.packageAsPath(this.cfg.implPackageName());
/*      */     }
/* 2848 */     String str3 = this.cfg.nativeOutputDir();
/* 2849 */     if (this.cfg.nativeOutputUsesJavaHierarchy())
/*      */     {
/*      */       
/* 2852 */       str3 = str3 + File.separator + CodeGenUtils.packageAsPath(this.cfg.packageName());
/*      */     }
/*      */     
/* 2855 */     if (this.cfg.allStatic() || this.cfg.emitInterface()) {
/* 2856 */       String str = str1 + File.separator + this.cfg.className() + ".java";
/* 2857 */       this.javaUnit = openJavaUnit(str, this.cfg.packageName(), this.cfg.className());
/*      */     } 
/* 2859 */     if (!this.cfg.allStatic() && this.cfg.emitImpl()) {
/* 2860 */       String str = str2 + File.separator + this.cfg.implClassName() + ".java";
/* 2861 */       this.javaImplUnit = openJavaUnit(str, this.cfg.implPackageName(), this.cfg.implClassName());
/*      */     } 
/* 2863 */     if (this.cfg.emitImpl()) {
/* 2864 */       String str4 = this.cfg.implClassName() + "_JNI.c";
/* 2865 */       String str5 = str3 + File.separator + str4;
/* 2866 */       this.cUnit = openCUnit(str5, str4);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected JavaCodeUnit javaUnit() {
/* 2871 */     if (!this.cfg.allStatic() && !this.cfg.emitInterface()) {
/* 2872 */       throw new InternalError("Should not call this");
/*      */     }
/* 2874 */     return this.javaUnit;
/*      */   }
/*      */   
/*      */   protected JavaCodeUnit javaImplUnit() {
/* 2878 */     if (this.cfg.allStatic() || !this.cfg.emitImpl()) {
/* 2879 */       throw new InternalError("Should not call this");
/*      */     }
/* 2881 */     return this.javaImplUnit;
/*      */   }
/*      */   
/*      */   protected CCodeUnit cUnit() {
/* 2885 */     if (!this.cfg.emitImpl()) {
/* 2886 */       throw new InternalError("Should not call this");
/*      */     }
/* 2888 */     return this.cUnit;
/*      */   }
/*      */   
/*      */   private void closeWriters() throws IOException {
/* 2892 */     if (this.javaUnit != null) {
/* 2893 */       this.javaUnit.close();
/* 2894 */       this.javaUnit = null;
/*      */     } 
/* 2896 */     if (this.javaImplUnit != null) {
/* 2897 */       this.javaImplUnit.close();
/* 2898 */       this.javaImplUnit = null;
/*      */     } 
/* 2900 */     if (this.cUnit != null) {
/* 2901 */       this.cUnit.close();
/* 2902 */       this.cUnit = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getJavaOutputDir() {
/* 2911 */     return this.cfg.javaOutputDir();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getJavaPackageName() {
/* 2919 */     return this.cfg.packageName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getImplPackageName() {
/* 2927 */     return this.cfg.implPackageName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void emitCustomJavaCode(CodeUnit paramCodeUnit, String paramString) throws Exception {
/* 2935 */     List<String> list = this.cfg.customJavaCodeForClass(paramString);
/* 2936 */     if (list.isEmpty()) {
/*      */       return;
/*      */     }
/* 2939 */     paramCodeUnit.emitln();
/* 2940 */     paramCodeUnit.emitln("  // --- Begin CustomJavaCode .cfg declarations");
/* 2941 */     for (String str : list) {
/* 2942 */       paramCodeUnit.emitln(str);
/*      */     }
/* 2944 */     paramCodeUnit.emitln("  // ---- End CustomJavaCode .cfg declarations");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void emitCustomJNICode(CodeUnit paramCodeUnit, String paramString) throws Exception {
/* 2952 */     List<String> list = this.cfg.customJNICodeForClass(paramString);
/* 2953 */     if (list.isEmpty()) {
/*      */       return;
/*      */     }
/* 2956 */     paramCodeUnit.emitln();
/* 2957 */     paramCodeUnit.emitln("  // --- Begin CustomJNICode .cfg declarations");
/* 2958 */     for (String str : list) {
/* 2959 */       paramCodeUnit.emitln(str);
/*      */     }
/* 2961 */     paramCodeUnit.emitln("  // ---- End CustomJNICode .cfg declarations");
/*      */   }
/*      */   
/*      */   public String[] getClassAccessModifiers(String paramString) {
/*      */     String[] arrayOfString;
/* 2966 */     MethodAccess methodAccess = this.cfg.accessControl(paramString);
/* 2967 */     if (MethodAccess.PUBLIC_ABSTRACT == methodAccess)
/* 2968 */     { arrayOfString = new String[] { MethodAccess.PUBLIC.getJavaName(), MethodAccess.PUBLIC_ABSTRACT.getJavaName() }; }
/* 2969 */     else if (MethodAccess.PACKAGE_PRIVATE == methodAccess)
/* 2970 */     { arrayOfString = new String[] { MethodAccess.PACKAGE_PRIVATE.getJavaName() }; }
/* 2971 */     else { if (MethodAccess.PRIVATE == methodAccess)
/* 2972 */         throw new IllegalArgumentException("Class access " + paramString + " cannot be private"); 
/* 2973 */       if (MethodAccess.PROTECTED == methodAccess) {
/* 2974 */         arrayOfString = new String[] { MethodAccess.PROTECTED.getJavaName() };
/*      */       } else {
/* 2976 */         arrayOfString = new String[] { MethodAccess.PUBLIC.getJavaName() };
/*      */       }  }
/* 2978 */      return arrayOfString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void emitAllFileHeaders() throws IOException {
/*      */     try {
/* 2987 */       ArrayList<String> arrayList = new ArrayList<>(this.cfg.imports());
/* 2988 */       arrayList.add(this.cfg.gluegenRuntimePackage() + ".*");
/* 2989 */       arrayList.add(DynamicLookupHelper.class.getPackage().getName() + ".*");
/* 2990 */       arrayList.add(Buffers.class.getPackage().getName() + ".*");
/* 2991 */       arrayList.add(Buffer.class.getPackage().getName() + ".*");
/* 2992 */       arrayList.add(HashUtil.class.getPackage().getName() + ".*");
/* 2993 */       arrayList.add("java.util.Set");
/* 2994 */       arrayList.add("java.util.Map");
/* 2995 */       arrayList.add("java.util.HashMap");
/* 2996 */       arrayList.add("java.nio.charset.Charset");
/* 2997 */       arrayList.add("java.nio.charset.StandardCharsets");
/*      */       
/* 2999 */       if (this.cfg.allStatic() || this.cfg.emitInterface()) {
/*      */ 
/*      */         
/* 3002 */         final List<String> implDocs = null;
/* 3003 */         if (this.cfg.emitInterface()) {
/* 3004 */           list1 = this.cfg.extendedInterfaces(this.cfg.className());
/*      */         } else {
/* 3006 */           list1 = this.cfg.implementedInterfaces(this.cfg.className());
/*      */         } 
/* 3008 */         String[] arrayOfString1 = new String[list1.size()];
/* 3009 */         list1.toArray(arrayOfString1);
/*      */         
/* 3011 */         final List<String> intfDocs = this.cfg.javadocForClass(this.cfg.className());
/* 3012 */         CodeGenUtils.EmissionCallback emissionCallback = new CodeGenUtils.EmissionCallback()
/*      */           {
/*      */             public void emit(PrintWriter param1PrintWriter)
/*      */             {
/* 3016 */               for (Iterator<String> iterator = intfDocs.iterator(); iterator.hasNext();) {
/* 3017 */                 param1PrintWriter.println(iterator.next());
/*      */               }
/*      */             }
/*      */           };
/*      */         
/* 3022 */         String[] arrayOfString2 = getClassAccessModifiers(this.cfg.className());
/* 3023 */         CodeGenUtils.emitJavaHeaders(
/* 3024 */             (javaUnit()).output, this.cfg
/* 3025 */             .packageName(), this.cfg
/* 3026 */             .className(), 
/* 3027 */             this.cfg.allStatic(), arrayList, arrayOfString2, arrayOfString1, this.cfg
/*      */ 
/*      */ 
/*      */             
/* 3031 */             .extendedParentClass(this.cfg.className()), emissionCallback);
/*      */       } 
/*      */ 
/*      */       
/* 3035 */       if (!this.cfg.allStatic() && this.cfg.emitImpl()) {
/* 3036 */         final List<String> implDocs = this.cfg.javadocForClass(this.cfg.implClassName());
/* 3037 */         CodeGenUtils.EmissionCallback emissionCallback = new CodeGenUtils.EmissionCallback()
/*      */           {
/*      */             public void emit(PrintWriter param1PrintWriter)
/*      */             {
/* 3041 */               for (Iterator<String> iterator = implDocs.iterator(); iterator.hasNext();) {
/* 3042 */                 param1PrintWriter.println(iterator.next());
/*      */               }
/*      */             }
/*      */           };
/*      */ 
/*      */         
/* 3048 */         final List<String> intfDocs = null;
/* 3049 */         list2 = this.cfg.implementedInterfaces(this.cfg.implClassName());
/* 3050 */         byte b = 0;
/* 3051 */         if (this.cfg.className() != null) {
/* 3052 */           b = 1;
/*      */         }
/* 3054 */         String[] arrayOfString1 = new String[b + list2.size()];
/* 3055 */         list2.toArray(arrayOfString1);
/* 3056 */         if (b == 1) {
/* 3057 */           arrayOfString1[list2.size()] = this.cfg.className();
/*      */         }
/*      */         
/* 3060 */         String[] arrayOfString2 = getClassAccessModifiers(this.cfg.implClassName());
/* 3061 */         CodeGenUtils.emitJavaHeaders(
/* 3062 */             (javaImplUnit()).output, this.cfg
/* 3063 */             .implPackageName(), this.cfg
/* 3064 */             .implClassName(), true, arrayList, arrayOfString2, arrayOfString1, this.cfg
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3069 */             .extendedParentClass(this.cfg.implClassName()), emissionCallback);
/*      */       } 
/*      */ 
/*      */       
/* 3073 */       if (this.cfg.emitImpl()) {
/* 3074 */         if (!this.cfg.getJavaCallbackList().isEmpty() && null == this.cfg.libraryOnLoadName()) {
/* 3075 */           this.LOG.log(Level.WARNING, "JavaCallback used, but no 'LibraryOnLoad' basename specified for JNI_OnLoad(..). Exactly one native code-unit for the library must specify 'LibraryOnLoad' basename");
/*      */         }
/* 3077 */         cUnit().emitHeader(getImplPackageName(), this.cfg.implClassName(), this.cfg.customCCode());
/*      */       } 
/* 3079 */     } catch (Exception exception) {
/* 3080 */       throw new RuntimeException("Error emitting all file headers: cfg.allStatic()=" + this.cfg
/* 3081 */           .allStatic() + " cfg.emitImpl()=" + this.cfg
/* 3082 */           .emitImpl() + " cfg.emitInterface()=" + this.cfg.emitInterface(), exception);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void emitAllFileFooters() {
/* 3092 */     if (this.cfg.allStatic() || this.cfg.emitInterface()) {
/* 3093 */       this.javaUnit.emitTailCode();
/* 3094 */       javaUnit().emitln("} // end of class " + this.cfg.className());
/*      */     } 
/* 3096 */     if (!this.cfg.allStatic() && this.cfg.emitImpl()) {
/* 3097 */       this.javaImplUnit.emitTailCode();
/* 3098 */       javaImplUnit().emitln("} // end of class " + this.cfg.implClassName());
/*      */     } 
/* 3100 */     if (this.cfg.emitImpl() && null != this.cfg.libraryOnLoadName()) {
/* 3101 */       this.cUnit.emitJNIOnLoadJNIEnvCode(this.cfg.libraryOnLoadName());
/*      */     }
/*      */   }
/*      */   
/*      */   private JavaType javaType(Class<?> paramClass) {
/* 3106 */     return JavaType.createForClass(paramClass);
/*      */   }
/*      */   private JavaType javaStringType(Class<?> paramClass, boolean paramBoolean) {
/* 3109 */     return JavaType.createForStringClass(paramClass, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MethodBinding bindFunction(FunctionSymbol paramFunctionSymbol, boolean paramBoolean, MachineDataInfo paramMachineDataInfo, JavaType paramJavaType, Type paramType) {
/*      */     JavaType javaType;
/* 3124 */     String str = (null == paramJavaType && null == paramType) ? this.cfg.getDelegatedImplementation((AliasedSymbol)paramFunctionSymbol) : null;
/* 3125 */     if (!paramBoolean && null != str) {
/*      */ 
/*      */       
/* 3128 */       paramFunctionSymbol = FunctionSymbol.cloneWithDeepAliases(paramFunctionSymbol);
/* 3129 */       paramFunctionSymbol.addAliasedName(str);
/*      */     } 
/*      */ 
/*      */     
/* 3133 */     if (this.cfg.returnsString((AliasedSymbol)paramFunctionSymbol)) {
/* 3134 */       PointerType pointerType = paramFunctionSymbol.getReturnType().asPointer();
/* 3135 */       if (pointerType == null || pointerType
/* 3136 */         .getTargetType().asInt() == null || pointerType
/* 3137 */         .getTargetType().getSize(paramMachineDataInfo) != 1L) {
/* 3138 */         throw new GlueGenException("Cannot apply ReturnsString configuration directive to \"" + paramFunctionSymbol + "\". ReturnsString requires native method to have return type \"char *\"", paramFunctionSymbol
/*      */ 
/*      */             
/* 3141 */             .getASTLocusTag());
/*      */       }
/* 3143 */       javaType = javaStringType(String.class, false);
/*      */     } else {
/* 3145 */       JavaType javaType1 = this.cfg.getOpaqueReturnType((AliasedSymbol)paramFunctionSymbol);
/* 3146 */       if (null != javaType1) {
/* 3147 */         javaType = javaType1;
/*      */       } else {
/* 3149 */         javaType = typeToJavaType(paramFunctionSymbol.getReturnType(), paramMachineDataInfo);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3155 */     ArrayList<JavaType> arrayList = new ArrayList();
/* 3156 */     List<Integer> list = this.cfg.stringArguments((AliasedSymbol)paramFunctionSymbol);
/* 3157 */     List<JavaConfiguration.PascalStringIdx> list1 = this.cfg.pascalStringArgument((AliasedSymbol)paramFunctionSymbol);
/* 3158 */     if (null != list1) {
/* 3159 */       list = JavaConfiguration.PascalStringIdx.pushValueIndex(list1, list);
/*      */     }
/* 3161 */     JavaConfiguration.JavaCallbackInfo javaCallbackInfo = this.cfg.setFuncToJavaCallbackMap.get(paramFunctionSymbol.getName());
/* 3162 */     byte b = -1;
/*      */     
/* 3164 */     for (byte b1 = 0; b1 < paramFunctionSymbol.getNumArguments(); b1++) {
/* 3165 */       Type type = paramFunctionSymbol.getArgumentType(b1);
/* 3166 */       String str1 = paramFunctionSymbol.getArgumentName(b1);
/* 3167 */       JavaType javaType1 = typeToJavaType(type, paramMachineDataInfo);
/* 3168 */       byte b2 = 0;
/*      */       
/* 3170 */       if (null != javaCallbackInfo && javaCallbackInfo.cbFuncTypeName.equals(type.getName()) && (!javaCallbackInfo.setFuncProcessed || b1 == javaCallbackInfo.setFuncCBParamIdx)) {
/*      */ 
/*      */ 
/*      */         
/* 3174 */         b = b1;
/* 3175 */         javaType1 = JavaType.createForNamedClass(javaCallbackInfo.cbFQClazzName);
/* 3176 */         b2 = 10;
/* 3177 */       } else if (null != javaCallbackInfo && b1 == javaCallbackInfo.setFuncUserParamIdx && type.isPointer()) {
/*      */         
/* 3179 */         if (type.getTargetType().isVoid()) {
/* 3180 */           if (javaCallbackInfo.cbFuncUserParamType.isCompound()) {
/* 3181 */             javaType1 = JavaType.createForClass(long.class);
/* 3182 */             b2 = 20;
/* 3183 */           } else if (null != javaCallbackInfo.userParamClassName) {
/* 3184 */             javaType1 = JavaType.createForNamedClass(javaCallbackInfo.userParamClassName);
/* 3185 */             b2 = 21;
/*      */           } else {
/* 3187 */             javaType1 = JavaType.forObjectClass();
/* 3188 */             b2 = 22;
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 3194 */       if (0 == b2 && list != null && list.contains(Integer.valueOf(b1)))
/*      */       {
/*      */         
/* 3197 */         if (javaType1.isCVoidPointerType() || javaType1
/* 3198 */           .isCCharPointerType() || javaType1
/* 3199 */           .isCShortPointerType() || javaType1
/* 3200 */           .isNIOPointerBuffer() || (javaType1
/* 3201 */           .isArray() && javaType1
/* 3202 */           .getJavaClass() == ArrayTypes.byteBufferArrayClass) || javaType1
/* 3203 */           .getJavaClass() == ArrayTypes.shortBufferArrayClass) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3208 */           boolean bool = (this.cfg.pascalStringLengthIndex((AliasedSymbol)paramFunctionSymbol, b1) >= 0) ? true : false;
/* 3209 */           if (javaType1.isArray() || javaType1.isNIOPointerBuffer()) {
/* 3210 */             javaType1 = javaStringType(ArrayTypes.stringArrayClass, bool);
/* 3211 */             b2 = 30;
/*      */           } else {
/* 3213 */             javaType1 = javaStringType(String.class, bool);
/* 3214 */             b2 = 31;
/*      */           } 
/*      */         } else {
/* 3217 */           b2 = 99;
/* 3218 */           throw new GlueGenException("Cannot apply ArgumentIsString configuration directive to argument " + b1 + " of \"" + paramFunctionSymbol + "\": argument type is not a \"void*\", \"char *\", \"short *\", \"char**\", or \"short**\" equivalent", paramFunctionSymbol
/*      */ 
/*      */ 
/*      */               
/* 3222 */               .getASTLocusTag());
/*      */         } 
/*      */       }
/* 3225 */       arrayList.add(javaType1);
/* 3226 */       this.LOG.log(Level.INFO, "BindFunc: {0}: added mapping ({1}) for {2} from C type: {3} to Java type: {4}", new Object[] { paramFunctionSymbol
/* 3227 */             .getName(), Integer.valueOf(b2), str1, type, javaType1 });
/*      */     } 
/* 3229 */     if (null != javaCallbackInfo) {
/* 3230 */       javaCallbackInfo.setFuncProcessed(paramFunctionSymbol.getType(), b);
/* 3231 */       this.LOG.log(Level.INFO, "BindFunc.JavaCallback: {0}: set[cbParamIdx {1}], {3}, {4}", new Object[] { paramFunctionSymbol
/* 3232 */             .getName(), Integer.valueOf(b), paramFunctionSymbol.getType().toString(paramFunctionSymbol.getName(), false, true), javaCallbackInfo });
/*      */     } 
/* 3234 */     MethodBinding methodBinding = new MethodBinding(paramFunctionSymbol, str, javaType, arrayList, paramJavaType, paramType);
/*      */ 
/*      */     
/* 3237 */     mangleBinding(methodBinding);
/* 3238 */     return methodBinding;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private MethodBinding lowerMethodBindingPointerTypes(MethodBinding paramMethodBinding, boolean paramBoolean, boolean[] paramArrayOfboolean) {
/* 3244 */     MethodBinding methodBinding = paramMethodBinding;
/* 3245 */     boolean bool = false;
/*      */ 
/*      */ 
/*      */     
/* 3249 */     for (byte b = 0; b < paramMethodBinding.getNumArguments(); b++) {
/* 3250 */       JavaType javaType1 = paramMethodBinding.getJavaArgumentType(b);
/* 3251 */       if (javaType1.isCPrimitivePointerType()) {
/* 3252 */         if (javaType1.isCVoidPointerType()) {
/*      */           
/* 3254 */           methodBinding = methodBinding.replaceJavaArgumentType(b, JavaType.forNIOBufferClass());
/* 3255 */         } else if (javaType1.isCCharPointerType()) {
/* 3256 */           bool = true;
/* 3257 */           if (paramBoolean) {
/* 3258 */             methodBinding = methodBinding.replaceJavaArgumentType(b, javaType(ArrayTypes.byteArrayClass));
/*      */           } else {
/* 3260 */             methodBinding = methodBinding.replaceJavaArgumentType(b, JavaType.forNIOByteBufferClass());
/*      */           } 
/* 3262 */         } else if (javaType1.isCShortPointerType()) {
/* 3263 */           bool = true;
/* 3264 */           if (paramBoolean) {
/* 3265 */             methodBinding = methodBinding.replaceJavaArgumentType(b, javaType(ArrayTypes.shortArrayClass));
/*      */           } else {
/* 3267 */             methodBinding = methodBinding.replaceJavaArgumentType(b, JavaType.forNIOShortBufferClass());
/*      */           } 
/* 3269 */         } else if (javaType1.isCInt32PointerType()) {
/* 3270 */           bool = true;
/* 3271 */           if (paramBoolean) {
/* 3272 */             methodBinding = methodBinding.replaceJavaArgumentType(b, javaType(ArrayTypes.intArrayClass));
/*      */           } else {
/* 3274 */             methodBinding = methodBinding.replaceJavaArgumentType(b, JavaType.forNIOIntBufferClass());
/*      */           } 
/* 3276 */         } else if (javaType1.isCInt64PointerType()) {
/* 3277 */           bool = true;
/* 3278 */           if (paramBoolean) {
/* 3279 */             methodBinding = methodBinding.replaceJavaArgumentType(b, javaType(ArrayTypes.longArrayClass));
/*      */           } else {
/* 3281 */             methodBinding = methodBinding.replaceJavaArgumentType(b, JavaType.forNIOLongBufferClass());
/*      */           } 
/* 3283 */         } else if (javaType1.isCFloatPointerType()) {
/* 3284 */           bool = true;
/* 3285 */           if (paramBoolean) {
/* 3286 */             methodBinding = methodBinding.replaceJavaArgumentType(b, javaType(ArrayTypes.floatArrayClass));
/*      */           } else {
/* 3288 */             methodBinding = methodBinding.replaceJavaArgumentType(b, JavaType.forNIOFloatBufferClass());
/*      */           } 
/* 3290 */         } else if (javaType1.isCDoublePointerType()) {
/* 3291 */           bool = true;
/* 3292 */           if (paramBoolean) {
/* 3293 */             methodBinding = methodBinding.replaceJavaArgumentType(b, javaType(ArrayTypes.doubleArrayClass));
/*      */           } else {
/* 3295 */             methodBinding = methodBinding.replaceJavaArgumentType(b, JavaType.forNIODoubleBufferClass());
/*      */           } 
/*      */         } else {
/* 3298 */           throw new GlueGenException("Unknown C pointer type " + javaType1);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3306 */     JavaType javaType = methodBinding.getJavaReturnType();
/* 3307 */     if (javaType.isCPrimitivePointerType()) {
/* 3308 */       if (javaType.isCVoidPointerType()) {
/* 3309 */         methodBinding = methodBinding.replaceJavaArgumentType(-1, JavaType.forNIOByteBufferClass());
/* 3310 */       } else if (javaType.isCCharPointerType()) {
/* 3311 */         methodBinding = methodBinding.replaceJavaArgumentType(-1, JavaType.forNIOByteBufferClass());
/* 3312 */       } else if (javaType.isCShortPointerType()) {
/* 3313 */         methodBinding = methodBinding.replaceJavaArgumentType(-1, JavaType.forNIOShortBufferClass());
/* 3314 */       } else if (javaType.isCInt32PointerType()) {
/* 3315 */         methodBinding = methodBinding.replaceJavaArgumentType(-1, JavaType.forNIOIntBufferClass());
/* 3316 */       } else if (javaType.isCInt64PointerType()) {
/* 3317 */         methodBinding = methodBinding.replaceJavaArgumentType(-1, JavaType.forNIOLongBufferClass());
/* 3318 */       } else if (javaType.isCFloatPointerType()) {
/* 3319 */         methodBinding = methodBinding.replaceJavaArgumentType(-1, JavaType.forNIOFloatBufferClass());
/* 3320 */       } else if (javaType.isCDoublePointerType()) {
/* 3321 */         methodBinding = methodBinding.replaceJavaArgumentType(-1, JavaType.forNIODoubleBufferClass());
/*      */       } else {
/* 3323 */         throw new GlueGenException("Unknown C pointer type " + javaType, methodBinding.getCReturnType().getASTLocusTag());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3329 */     if (paramArrayOfboolean != null) {
/* 3330 */       paramArrayOfboolean[0] = bool;
/*      */     }
/*      */     
/* 3333 */     return methodBinding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void mangleBinding(MethodBinding paramMethodBinding) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<MethodBinding> expandMethodBinding(MethodBinding paramMethodBinding) {
/* 3349 */     ArrayList<MethodBinding> arrayList = new ArrayList();
/*      */ 
/*      */     
/* 3352 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 3354 */     if (paramMethodBinding.signatureUsesCPrimitivePointers() || paramMethodBinding
/* 3355 */       .signatureUsesCVoidPointers() || paramMethodBinding
/* 3356 */       .signatureUsesCArrays()) {
/*      */       
/* 3358 */       arrayList.add(lowerMethodBindingPointerTypes(paramMethodBinding, false, arrayOfBoolean));
/*      */ 
/*      */       
/* 3361 */       if (arrayOfBoolean[0] && (paramMethodBinding.signatureUsesCPrimitivePointers() || paramMethodBinding.signatureUsesCArrays()) && 
/* 3362 */         !this.cfg.useNIOOnly(paramMethodBinding.getName())) {
/* 3363 */         arrayList.add(lowerMethodBindingPointerTypes(paramMethodBinding, true, null));
/*      */       }
/*      */     } else {
/* 3366 */       arrayList.add(paramMethodBinding);
/*      */     } 
/*      */     
/* 3369 */     return arrayList;
/*      */   }
/*      */   
/*      */   private Type canonicalize(Type paramType) {
/* 3373 */     Type type = this.canonMap.get(paramType);
/* 3374 */     if (type != null) {
/* 3375 */       return type;
/*      */     }
/* 3377 */     this.canonMap.put(paramType, paramType);
/* 3378 */     return paramType;
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/JavaEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */