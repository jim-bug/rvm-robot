package com.jogamp.gluegen;

import com.jogamp.gluegen.cgram.types.FunctionSymbol;
import java.util.List;

public interface SymbolFilter {
  void filterSymbols(List<ConstantDefinition> paramList, List<FunctionSymbol> paramList1);
  
  List<ConstantDefinition> getConstants();
  
  List<FunctionSymbol> getFunctions();
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/SymbolFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */