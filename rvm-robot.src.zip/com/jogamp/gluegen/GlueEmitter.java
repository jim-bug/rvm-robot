package com.jogamp.gluegen;

import com.jogamp.gluegen.cgram.types.CompoundType;
import com.jogamp.gluegen.cgram.types.FunctionSymbol;
import com.jogamp.gluegen.cgram.types.Type;
import com.jogamp.gluegen.cgram.types.TypeDictionary;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public interface GlueEmitter {
  void readConfigurationFile(String paramString) throws Exception;
  
  JavaConfiguration getConfig();
  
  void beginEmission(GlueEmitterControls paramGlueEmitterControls) throws Exception;
  
  void endEmission() throws Exception;
  
  void beginDefines() throws Exception;
  
  void emitDefine(ConstantDefinition paramConstantDefinition, String paramString) throws Exception;
  
  void endDefines() throws Exception;
  
  void beginFunctions(TypeDictionary paramTypeDictionary1, TypeDictionary paramTypeDictionary2, Map<Type, Type> paramMap, List<FunctionSymbol> paramList) throws Exception;
  
  Iterator<FunctionSymbol> emitFunctions(List<FunctionSymbol> paramList) throws Exception;
  
  void endFunctions() throws Exception;
  
  void beginStructLayout() throws Exception;
  
  void layoutStruct(CompoundType paramCompoundType) throws Exception;
  
  void endStructLayout() throws Exception;
  
  void beginStructs(TypeDictionary paramTypeDictionary1, TypeDictionary paramTypeDictionary2, Map<Type, Type> paramMap) throws Exception;
  
  void emitStruct(CompoundType paramCompoundType, Type paramType) throws Exception;
  
  void endStructs() throws Exception;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/GlueEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */