/*      */ package com.jogamp.gluegen;
/*      */ 
/*      */ import com.jogamp.common.os.MachineDataInfo;
/*      */ import com.jogamp.gluegen.cgram.types.AliasedSymbol;
/*      */ import com.jogamp.gluegen.cgram.types.ArrayType;
/*      */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*      */ import com.jogamp.gluegen.cgram.types.PointerType;
/*      */ import com.jogamp.gluegen.cgram.types.Type;
/*      */ import java.io.PrintWriter;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CMethodBindingEmitter
/*      */   extends FunctionEmitter
/*      */ {
/*   60 */   protected static final CommentEmitter defaultCommentEmitter = new DefaultCommentEmitter();
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String arrayResLength = "_array_res_length";
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String arrayRes = "_array_res";
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String arrayIdx = "_array_idx";
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Logging.LoggerIf LOG;
/*      */ 
/*      */ 
/*      */   
/*      */   private final String packageName;
/*      */ 
/*      */ 
/*      */   
/*      */   private final String className;
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isOverloadedBinding;
/*      */ 
/*      */   
/*      */   private final boolean isJavaMethodStatic;
/*      */ 
/*      */   
/*      */   protected boolean forImplementingMethodCall;
/*      */ 
/*      */   
/*      */   protected boolean forIndirectBufferAndArrayImplementation;
/*      */ 
/*      */   
/*      */   private List<String> temporaryCVariableDeclarations;
/*      */ 
/*      */   
/*      */   private List<String> temporaryCVariableAssignments;
/*      */ 
/*      */   
/*  106 */   private MessageFormat returnValueCapacityExpression = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  112 */   private MessageFormat returnValueLengthExpression = null;
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String STRING_CHARS_PREFIX = "_strchars_";
/*      */ 
/*      */ 
/*      */   
/*      */   protected MachineDataInfo machDesc;
/*      */ 
/*      */ 
/*      */   
/*      */   private final CMethodBindingEmitter jcbFuncCMethodEmitter;
/*      */ 
/*      */ 
/*      */   
/*      */   private final JavaCallbackEmitter javaCallbackEmitter;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isCStructFunctionPointer;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CMethodBindingEmitter(MethodBinding paramMethodBinding, CodeUnit paramCodeUnit, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, MachineDataInfo paramMachineDataInfo, JavaConfiguration paramJavaConfiguration) {
/*  138 */     super(paramMethodBinding, paramCodeUnit, false, paramJavaConfiguration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1000 */     this.isCStructFunctionPointer = false; this.LOG = Logging.getLogger(CMethodBindingEmitter.class.getPackage().getName(), CMethodBindingEmitter.class.getSimpleName()); assert paramMethodBinding != null; assert paramString2 != null; assert paramString1 != null; this.packageName = paramString1; this.className = paramString2; this.isOverloadedBinding = paramBoolean1; this.isJavaMethodStatic = paramBoolean2; this.forImplementingMethodCall = paramBoolean3; this.forIndirectBufferAndArrayImplementation = paramBoolean4; this.machDesc = paramMachineDataInfo; JavaConfiguration.JavaCallbackInfo javaCallbackInfo = this.cfg.setFuncToJavaCallbackMap.get(paramMethodBinding.getName()); if (null != javaCallbackInfo) { this.jcbFuncCMethodEmitter = new CMethodBindingEmitter(javaCallbackInfo.cbFuncBinding, paramCodeUnit, paramString1, paramString2, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramMachineDataInfo, paramJavaConfiguration); this.javaCallbackEmitter = new JavaCallbackEmitter(this.cfg, paramMethodBinding, javaCallbackInfo, null); } else { this.jcbFuncCMethodEmitter = null; this.javaCallbackEmitter = null; }  setCommentEmitter(defaultCommentEmitter);
/*      */   } public String getInterfaceName() { return this.binding.getInterfaceName(); } public String getImplName() { return this.binding.getImplName(); } public String getNativeName() { return this.binding.getNativeName(); } public FunctionSymbol getCSymbol() { return this.binding.getCSymbol(); } public final MessageFormat getReturnValueCapacityExpression() { return this.returnValueCapacityExpression; } public final void setReturnValueCapacityExpression(MessageFormat paramMessageFormat) { this.returnValueCapacityExpression = paramMessageFormat; if (!this.binding.getJavaReturnType().isNIOBuffer() && !this.binding.getJavaReturnType().isCompoundTypeWrapper()) throw new IllegalArgumentException("Cannot specify return value capacity for a method that does not return java.nio.Buffer or a compound type wrapper: \"" + this.binding + "\"");  } public final MessageFormat getReturnValueLengthExpression() { return this.returnValueLengthExpression; } public final void setReturnValueLengthExpression(MessageFormat paramMessageFormat) { this.returnValueLengthExpression = paramMessageFormat; if (!this.binding.getJavaReturnType().isArray() && !this.binding.getJavaReturnType().isArrayOfCompoundTypeWrappers()) throw new IllegalArgumentException("Cannot specify return value length for a method that does not return an array: \"" + this.binding + "\"");  } public final List<String> getTemporaryCVariableDeclarations() { return this.temporaryCVariableDeclarations; }
/*      */   public final void setTemporaryCVariableDeclarations(List<String> paramList) { this.temporaryCVariableDeclarations = paramList; }
/*      */   public final List<String> getTemporaryCVariableAssignments() { return this.temporaryCVariableAssignments; }
/*      */   public final void setTemporaryCVariableAssignments(List<String> paramList) { this.temporaryCVariableAssignments = paramList; }
/*      */   public String getJavaPackageName() { return this.packageName; }
/*      */   public String getJavaClassName() { return this.className; }
/*      */   public final boolean getIsOverloadedBinding() { return this.isOverloadedBinding; }
/* 1008 */   protected void setIsCStructFunctionPointer(boolean paramBoolean) { this.isCStructFunctionPointer = paramBoolean; } public final boolean getIsJavaMethodStatic() { return this.isJavaMethodStatic; } public final boolean forIndirectBufferAndArrayImplementation() { return this.forIndirectBufferAndArrayImplementation; } public final MachineDataInfo getMachineDataInfo() { return this.machDesc; }
/*      */   protected StringBuilder appendReturnType(StringBuilder paramStringBuilder) { paramStringBuilder.append("JNIEXPORT "); paramStringBuilder.append(this.binding.getJavaReturnType().jniTypeName()); paramStringBuilder.append(" JNICALL"); return paramStringBuilder; }
/*      */   protected StringBuilder appendName(StringBuilder paramStringBuilder) { paramStringBuilder.append(System.lineSeparator()); paramStringBuilder.append(JavaEmitter.getJNIMethodNamePrefix(getJavaPackageName(), getJavaClassName())); paramStringBuilder.append("_"); if (this.isOverloadedBinding) { paramStringBuilder.append(jniMangle(this.binding)); } else { paramStringBuilder.append(JavaEmitter.jniMangle(getImplName())); }  return paramStringBuilder; }
/*      */   protected String getImplSuffix() { if (this.forImplementingMethodCall) { if (this.forIndirectBufferAndArrayImplementation) return "1";  return "0"; }  return ""; }
/*      */   protected int appendArguments(StringBuilder paramStringBuilder) { paramStringBuilder.append("JNIEnv *env, "); int i = 1; if (this.isJavaMethodStatic && !this.binding.hasContainingType()) { paramStringBuilder.append("jclass"); } else { paramStringBuilder.append("jobject"); }  paramStringBuilder.append(" _unused"); i++; if (this.binding.isReturnCompoundByValue()) { paramStringBuilder.append(", jclass _clazzBuffers"); i++; }  if (this.binding.hasContainingType()) paramStringBuilder.append(", jobject " + JavaMethodBindingEmitter.javaThisArgumentName());  for (byte b = 0; b < this.binding.getNumArguments(); b++) { JavaType javaType = this.binding.getJavaArgumentType(b); if (javaType.isVoid()) { assert this.binding.getNumArguments() == 1; } else if (!javaType.isJNIEnv() && !this.binding.isArgumentThisPointer(b)) { paramStringBuilder.append(", "); paramStringBuilder.append(javaType.jniTypeName()); paramStringBuilder.append(" "); paramStringBuilder.append(this.binding.getArgumentName(b)); i++; if (javaType.isPrimitiveArray() || javaType.isNIOBuffer()) { paramStringBuilder.append(", jint " + byteOffsetArgName(b)); if (this.forIndirectBufferAndArrayImplementation) paramStringBuilder.append(", jboolean " + isNIOArgName(b));  } else if (javaType.isNIOBufferArray()) { paramStringBuilder.append(", jintArray " + byteOffsetArrayArgName(b)); }  }  }  if (null != this.javaCallbackEmitter) i += this.javaCallbackEmitter.appendCAdditionalParameter(paramStringBuilder);  return i; }
/* 1013 */   protected void emitBodyCallCFunction() { this.unit.emit("  ");
/*      */ 
/*      */ 
/*      */     
/* 1017 */     Type type = this.binding.getCReturnType();
/*      */     
/* 1019 */     if (!type.isVoid()) {
/*      */ 
/*      */ 
/*      */       
/* 1023 */       this.unit.emit("_res = (");
/* 1024 */       this.unit.emit(type.getCName(false));
/* 1025 */       this.unit.emit(") ");
/*      */     } 
/* 1027 */     if (this.isCStructFunctionPointer && this.binding.hasContainingType())
/*      */     {
/* 1029 */       this.unit.emit(cThisArgumentName() + "->");
/*      */     }
/* 1031 */     this.unit.emit(getNativeName());
/* 1032 */     this.unit.emit("(");
/* 1033 */     emitBodyPassCArguments();
/* 1034 */     this.unit.emitln(");"); } protected void emitAdditionalCode() { if (null != this.javaCallbackEmitter) this.javaCallbackEmitter.emitCAdditionalCode(this.unit, this.jcbFuncCMethodEmitter);  }
/*      */   protected void emitBody() { this.unit.emitln(" {"); emitBodyVariableDeclarations(); emitBodyUserVariableDeclarations(); emitBodyVariablePreCallSetup(); if (null != this.javaCallbackEmitter) this.javaCallbackEmitter.emitCSetFuncPreCall(this.unit);  emitBodyCallCFunction(); emitBodyUserVariableAssignments(); emitBodyVariablePostCallCleanup(); if (emitBodyMapCToJNIType(-1, true)) this.unit.emitln("  return _res_jni;");  this.unit.emitln("}"); this.unit.emitln(); }
/*      */   protected void emitBodyVariableDeclarations() { if (this.binding.hasContainingType()) emitPointerDeclaration(this.binding.getContainingType(), this.binding.getContainingCType(), cThisArgumentName(), (String)null);  boolean bool = false; for (byte b = 0; b < this.binding.getNumArguments(); b++) { JavaType javaType1 = this.binding.getJavaArgumentType(b); if (!javaType1.isJNIEnv() && !this.binding.isArgumentThisPointer(b)) if (javaType1.isArray() || javaType1.isNIOBuffer() || javaType1.isCompoundTypeWrapper() || javaType1.isArrayOfCompoundTypeWrappers()) { String str1 = this.binding.getArgumentName(b); String str2 = pointerConversionArgumentName(str1); boolean bool1 = emitPointerDeclaration(javaType1, this.binding.getCArgumentType(b), str2, str1); if (bool1 && !bool) { this.unit.emitln("  jobject _tmpObj;"); this.unit.emitln("  int _copyIndex;"); this.unit.emitln("  jsize _tmpArrayLen;"); if (javaType1.isNIOBufferArray()) this.unit.emitln("  int * _offsetHandle = NULL;");  bool = true; }  } else if (javaType1.isString()) { Type type1 = this.binding.getCArgumentType(b); if (isUTF8Type(type1)) { this.unit.emit("  const char* "); } else { this.unit.emit("  jchar* "); }  this.unit.emit("_strchars_"); this.unit.emit(this.binding.getArgumentName(b)); this.unit.emitln(" = NULL;"); }   }  Type type = this.binding.getCReturnType(); JavaType javaType = this.binding.getJavaReturnType(); if (!type.isVoid()) { this.unit.emit("  "); this.unit.emit(this.binding.getCSymbol().getReturnType().getCName(false)); this.unit.emitln(" _res;"); if (javaType.isNIOByteBufferArray() || javaType.isArrayOfCompoundTypeWrappers()) { this.unit.emit("  int "); this.unit.emit("_array_res_length"); this.unit.emitln(";"); this.unit.emit("  int "); this.unit.emit("_array_idx"); this.unit.emitln(";"); this.unit.emit("  jobjectArray "); this.unit.emit("_array_res"); this.unit.emitln(";"); } else if (javaType.isArray()) { this.unit.emit("  int "); this.unit.emit("_array_res_length"); this.unit.emitln(";"); Class<?> clazz = javaType.getJavaClass().getComponentType(); if (clazz.isArray())
/*      */           throw new RuntimeException("Multi-dimensional arrays not supported yet");  String str1 = clazz.getName(); String str2 = "j" + str1 + "Array"; this.unit.emit("  "); this.unit.emit(str2); this.unit.emit(" "); this.unit.emit("_array_res"); this.unit.emitln(";"); }  }  }
/*      */   protected void emitBodyUserVariableDeclarations() { if (this.temporaryCVariableDeclarations != null)
/*      */       for (String str : this.temporaryCVariableDeclarations) { this.unit.emit("  "); this.unit.emitln(str); }   }
/* 1040 */   protected void emitBodyUserVariableAssignments() { if (this.temporaryCVariableAssignments != null)
/* 1041 */       for (String str : this.temporaryCVariableAssignments)
/* 1042 */       { this.unit.emit("  ");
/* 1043 */         this.unit.emitln(str); }   }
/*      */   protected boolean isUTF8Type(Type paramType) { while (!paramType.isInt() && !paramType.isVoid()) { PointerType pointerType = paramType.asPointer(); if (pointerType != null) { paramType = pointerType.getTargetType(); continue; }  ArrayType arrayType = paramType.asArray(); if (arrayType == null)
/*      */         throw new IllegalArgumentException("Type " + paramType + " should have been a pointer or array type");  paramType = arrayType.getTargetType(); }  if (paramType.isVoid())
/*      */       return true;  if (!paramType.isInt())
/*      */       throw new IllegalArgumentException("Type " + paramType + " should have been a one- or two-dimensional integer pointer or array type");  if (paramType.getSize(this.machDesc) != 1L && paramType.getSize(this.machDesc) != 2L)
/*      */       throw new IllegalArgumentException("Type " + paramType + " should have been a one- or two-dimensional pointer to char or short");  return (paramType.getSize(this.machDesc) == 1L); }
/*      */   protected void emitBodyVariablePreCallSetup() { if (this.binding.hasContainingType())
/*      */       emitPointerConversion(this.binding, this.binding.getContainingType(), this.binding.getContainingCType(), JavaMethodBindingEmitter.javaThisArgumentName(), cThisArgumentName(), (String)null);  for (byte b = 0; b < this.binding.getNumArguments(); b++) { JavaType javaType = this.binding.getJavaArgumentType(b); if (!javaType.isJNIEnv() && !this.binding.isArgumentThisPointer(b)) { String str = this.binding.getArgumentName(b); if (javaType.isCompoundTypeWrapper() || (javaType.isNIOBuffer() && !this.forIndirectBufferAndArrayImplementation)) { emitPointerConversion(this.binding, javaType, this.binding.getCArgumentType(b), str, pointerConversionArgumentName(str), byteOffsetArgName(b)); } else if (javaType.isArray() || javaType.isArrayOfCompoundTypeWrappers() || (javaType.isNIOBuffer() && this.forIndirectBufferAndArrayImplementation)) { boolean bool = javaArgTypeNeedsDataCopy(javaType); this.unit.emitln("  if ( NULL != " + str + " ) {"); Type type = this.binding.getCArgumentType(b); String str1 = type.getCName(); String str2 = pointerConversionArgumentName(str); if (!bool) { this.unit.emit("    "); this.unit.emit(str2); this.unit.emit(" = ("); if (javaType.isStringArray())
/*      */               str1 = "jstring *";  this.unit.emit(str1); this.unit.emit(") ( JNI_TRUE == " + isNIOArgName(b) + " ? "); this.unit.emit(" (*env)->GetDirectBufferAddress(env, " + str + ") : "); this.unit.emit(" (*env)->GetPrimitiveArrayCritical(env, " + str + ", NULL) );"); } else { Type type1, type2; if (!type.isBaseTypeConst() && !javaType.isArrayOfCompoundTypeWrappers())
/*      */               throw new GlueGenException("Cannot copy data for ptr-to-ptr arg type \"" + type.getDebugString() + "\": support for non-const ptr-to-ptr types not implemented: " + this.binding, this.binding.getCSymbol().getASTLocusTag());  this.unit.emitln(); this.unit.emitln("    /* Copy contents of " + str + " into " + str2 + "_copy */"); this.unit.emit("    "); this.unit.emit("_tmpArrayLen"); this.unit.emit(" = (*env)->GetArrayLength(env, "); this.unit.emit(str); this.unit.emitln(");"); byte b1 = 0; if (type.isPointer()) { type1 = type.asPointer().getTargetType(); if (type1.isPointer()) { type2 = type1.asPointer().getTargetType(); if (type2.isPointer())
/*      */                   b1 = 1;  if (type.pointerDepth() != 2)
/*      */                   b1 = 2;  } else { type2 = null; if (type.pointerDepth() != 1)
/*      */                   b1 = 10;  }  } else if (type.isArray()) { type1 = type.getBaseType(); type2 = null; } else { type1 = null; type2 = null; b1 = 100; }  if (0 < b1)
/*      */               throw new GlueGenException("Could not copy data for type \"" + type.getDebugString() + "\"; currently only pointer- and array-types are supported. (error " + b1 + "): " + this.binding, this.binding.getCSymbol().getASTLocusTag());  emitMalloc(str2 + "_copy", type1.getCName(), type.isBaseTypeConst(), "_tmpArrayLen", "Could not allocate buffer for copying data in argument \\\"" + str + "\\\""); if (javaType.isNIOBufferArray())
/*      */               this.unit.emitln("    _offsetHandle = (int *) (*env)->GetPrimitiveArrayCritical(env, " + byteOffsetArrayArgName(b) + ", NULL);");  this.unit.emitln("    for (_copyIndex = 0; _copyIndex < _tmpArrayLen; ++_copyIndex) {"); this.unit.emitln("      /* get each element of the array argument \"" + str + "\" */"); this.unit.emit("      _tmpObj = (*env)->GetObjectArrayElement(env, "); this.unit.emit(str); this.unit.emitln(", _copyIndex);"); if (javaType.isStringArray()) { this.unit.emit("  "); emitGetStringChars("(jstring) _tmpObj", str2 + "_copy[_copyIndex]", isUTF8Type(type), true); } else if (javaType.isNIOBufferArray()) { emitGetDirectBufferAddress("_tmpObj", type1.getCName(), str2 + "_copy[_copyIndex]", true, "_offsetHandle[_copyIndex]", true); } else if (javaType.isArrayOfCompoundTypeWrappers()) { emitGetDirectBufferAddress("_tmpObj", type1.getCName(), "(" + str2 + "_copy + _copyIndex)", false, (String)null, true); }
/*      */             else { if (null == type2)
/*      */                 throw new GlueGenException("XXX: Type " + type.getDebugString() + " not properly handled as ptr-to-ptr: " + this.binding, this.binding.getCSymbol().getASTLocusTag());  this.unit.emit("      "); emitMalloc(str2 + "_copy[_copyIndex]", type2.getCName(), type.isBaseTypeConst(), "(*env)->GetArrayLength(env, _tmpObj)", "Could not allocate buffer during copying of data in argument \\\"" + str + "\\\""); throw new GlueGenException("Cannot yet handle type \"" + type.getDebugString() + "\"; need to add support for copying ptr-to-ptr-to-primitiveType subarrays: " + this.binding, this.binding.getCSymbol().getASTLocusTag()); }
/*      */              this.unit.emitln("    }"); if (javaType.isNIOBufferArray())
/*      */               this.unit.emitln("    (*env)->ReleasePrimitiveArrayCritical(env, " + byteOffsetArrayArgName(b) + ", _offsetHandle, JNI_ABORT);");  this.unit.emitln(); }
/*      */            this.unit.emitln("  }"); }
/*      */         else if (javaType.isString()) { emitGetStringChars(str, "_strchars_" + str, isUTF8Type(this.binding.getCArgumentType(b)), false); }
/*      */          }
/*      */        }
/* 1066 */      } public boolean emitBodyMapCToJNIType(int paramInt, boolean paramBoolean) { boolean bool; Type type; JavaType javaType; String str1; if (0 > paramInt) {
/* 1067 */       bool = true;
/* 1068 */       type = this.binding.getCReturnType();
/* 1069 */       javaType = this.binding.getJavaReturnType();
/* 1070 */       str1 = "_res";
/*      */     } else {
/* 1072 */       bool = false;
/* 1073 */       type = this.binding.getCArgumentType(paramInt);
/* 1074 */       javaType = this.binding.getJavaArgumentType(paramInt);
/* 1075 */       str1 = this.binding.getArgumentName(paramInt);
/*      */     } 
/* 1077 */     String str2 = str1 + "_jni";
/*      */     
/* 1079 */     if (type.isVoid())
/*      */     {
/* 1081 */       return false;
/*      */     }
/* 1083 */     if (javaType.isPrimitive())
/* 1084 */     { if (paramBoolean) {
/* 1085 */         this.unit.emit("  " + javaType.jniTypeName() + " " + str2 + " = ");
/*      */       } else {
/* 1087 */         this.unit.emit("  " + str2 + " = ");
/*      */       } 
/* 1089 */       if (type.isPointer())
/*      */       {
/*      */         
/* 1092 */         this.unit.emit("(" + javaType.jniTypeName() + ") (intptr_t) ");
/*      */       }
/* 1094 */       this.unit.emit(str1);
/* 1095 */       this.unit.emitln(";"); }
/* 1096 */     else if (!type.isPointer() && javaType.isCompoundTypeWrapper())
/* 1097 */     { String str; if (paramBoolean) {
/* 1098 */         this.unit.emit("  " + javaType.jniTypeName() + " " + str2 + " = ");
/*      */       } else {
/* 1100 */         this.unit.emit("  " + str2 + " = ");
/*      */       } 
/*      */       
/* 1103 */       if (bool && this.returnValueCapacityExpression != null) {
/* 1104 */         str = this.returnValueCapacityExpression.format(argumentNameArray());
/*      */       } else {
/* 1106 */         str = "sizeof(" + type.getCName() + ")";
/*      */       } 
/* 1108 */       this.unit.emitln("JVMUtil_NewDirectByteBufferCopy(env, _clazzBuffers, &" + str1 + ", " + str + ");");
/* 1109 */       this.unit.addTailCode("static const char * nameCopyNativeToDirectByteBuffer = \"copyNativeToDirectByteBuffer\";\nstatic const char * nameCopyNativeToDirectByteBufferSignature = \"(JJ)Ljava/nio/ByteBuffer;\";\n\nstatic jobject JVMUtil_NewDirectByteBufferCopy(JNIEnv *env, jclass clazzBuffers, void * source_address, size_t capacity) {\n    jmethodID cstrBuffersNew = (*env)->GetStaticMethodID(env, clazzBuffers, nameCopyNativeToDirectByteBuffer, nameCopyNativeToDirectByteBufferSignature);\n    if(NULL==cstrBuffersNew) {\n        fprintf(stderr, \"Can't get method Buffers.%s(%s)\\n\", nameCopyNativeToDirectByteBuffer, nameCopyNativeToDirectByteBufferSignature);\n        (*env)->FatalError(env, nameCopyNativeToDirectByteBuffer);\n        return JNI_FALSE;\n    }\n    jobject jbyteBuffer  = (*env)->CallStaticObjectMethod(env, clazzBuffers, cstrBuffersNew, (jlong)(intptr_t)source_address, (jlong)capacity);\n    if( (*env)->ExceptionCheck(env) ) {\n        (*env)->ExceptionDescribe(env);\n        (*env)->ExceptionClear(env);\n        (*env)->FatalError(env, \"Exception occurred\");\n        return NULL;\n    }\n    return jbyteBuffer;\n}\n"); }
/* 1110 */     else if (javaType.isNIOBuffer() || javaType.isCompoundTypeWrapper())
/* 1111 */     { if (paramBoolean) {
/* 1112 */         this.unit.emitln("  " + javaType.jniTypeName() + " " + str2 + ";");
/*      */       } else {
/* 1114 */         this.unit.emitln("  " + str2 + ";");
/*      */       } 
/* 1116 */       this.unit.emitln("  if(NULL == " + str1 + ") {");
/* 1117 */       this.unit.emitln("    " + str2 + " = NULL;");
/* 1118 */       this.unit.emitln("  } else {");
/* 1119 */       this.unit.emit("    " + str2 + " = (*env)->NewDirectByteBuffer(env, (void *)" + str1 + ", ");
/*      */ 
/*      */       
/* 1122 */       if (bool && this.returnValueCapacityExpression != null) {
/* 1123 */         this.unit.emitln(this.returnValueCapacityExpression.format(argumentNameArray()) + ");");
/*      */       } else {
/* 1125 */         Type type1 = type.isPointer() ? type.getTargetType() : null;
/* 1126 */         byte b = 0;
/* 1127 */         if (1 == type.pointerDepth() && null != type1) {
/* 1128 */           if (type1.isCompound()) {
/* 1129 */             if (!type1.isAnon() && type1
/* 1130 */               .asCompound().getNumFields() > 0) {
/*      */ 
/*      */               
/* 1133 */               if (type1.getSize() == null) {
/* 1134 */                 throw new GlueGenException("Error emitting code for compound type for function \"" + this.binding + "\": Structs to be emitted should have been laid out by this point (type " + type1
/*      */ 
/*      */ 
/*      */                     
/* 1138 */                     .getCName() + " / " + type1
/* 1139 */                     .getDebugString() + " was not) for " + this.binding.getCSymbol(), this.binding
/* 1140 */                     .getCSymbol().getASTLocusTag());
/*      */               }
/* 1142 */               this.unit.emitln("sizeof(" + type1.getCName() + ") );");
/* 1143 */               b = 10;
/* 1144 */             } else if (type1.asCompound().getNumFields() == 0) {
/*      */               
/* 1146 */               this.unit.emitln("sizeof(" + type.getCName() + ") );");
/* 1147 */               b = 11;
/*      */             } 
/*      */           }
/* 1150 */           if (0 == b) {
/* 1151 */             if (type1.isPrimitive()) {
/*      */               
/* 1153 */               this.unit.emitln("sizeof(" + type1.getCName() + ") );");
/* 1154 */               b = 20;
/* 1155 */             } else if (type1.isVoid()) {
/*      */               
/* 1157 */               this.unit.emitln("sizeof(" + type.getCName() + ") );");
/* 1158 */               b = 21;
/*      */             } 
/*      */           }
/*      */         } 
/* 1162 */         if (0 == b) {
/* 1163 */           if (null != this.cfg.typeInfo(type)) {
/*      */             
/* 1165 */             this.unit.emitln("sizeof(" + type.getCName() + ") );");
/* 1166 */             b = 88;
/*      */           } else {
/*      */             
/* 1169 */             this.unit.emitln("sizeof(" + type.getCName() + ") ); // WARNING: " + "Assumed return size of equivalent C return type");
/* 1170 */             b = 99;
/* 1171 */             this.LOG.warning(this.binding.getCSymbol().getASTLocusTag(), "No capacity specified for java.nio.Buffer return value for function \"" + this.binding
/*      */                 
/* 1173 */                 .getName() + "\". " + "Assumed return size of equivalent C return type" + " (sizeof(" + type.getCName() + ")): " + this.binding);
/*      */           } 
/*      */         }
/* 1176 */         this.unit.emitln("    /** ");
/* 1177 */         this.unit.emitln("     * mode: " + b + ", arg #" + paramInt);
/* 1178 */         this.unit.emitln("     * cType: " + type.getDebugString());
/* 1179 */         this.unit.emitln("     * cTargetType: " + type1.getDebugString());
/* 1180 */         this.unit.emitln("     * javaType: " + javaType.getDebugString());
/* 1181 */         this.unit.emitln("     */");
/*      */       } 
/* 1183 */       this.unit.emitln("  }"); }
/* 1184 */     else if (javaType.isString())
/* 1185 */     { String str; boolean bool1 = javaType.isPascalStringVariant();
/*      */       
/* 1187 */       if (bool1) {
/* 1188 */         int i = this.cfg.pascalStringLengthIndex((AliasedSymbol)getCSymbol(), paramInt);
/* 1189 */         str = (0 <= i) ? this.binding.getArgumentName(i) : null;
/*      */       } else {
/* 1191 */         str = null;
/*      */       } 
/* 1193 */       if (paramBoolean) {
/* 1194 */         this.unit.emitln("  " + javaType.jniTypeName() + " " + str2 + ";");
/*      */       }
/* 1196 */       if (null != str) {
/* 1197 */         this.unit.emitln("  if (NULL == " + str1 + " || 0 >= " + str + " ) {");
/*      */       } else {
/* 1199 */         this.unit.emitln("  if (NULL == " + str1 + ") {");
/*      */       } 
/* 1201 */       this.unit.emitln("    " + str2 + " = NULL;");
/* 1202 */       this.unit.emitln("  } else {");
/* 1203 */       if (null != str) {
/* 1204 */         this.unit.emitln("    char* " + str1 + "_cstr = calloc(" + str + "+1, sizeof(char)); // PascalString -> Add EOS");
/* 1205 */         this.unit.emitln("    memcpy(" + str1 + "_cstr, " + str1 + ", " + str + ");");
/*      */       } 
/* 1207 */       this.unit.emit("    " + str2 + " = ");
/* 1208 */       if (null != str) {
/* 1209 */         this.unit.emitln("(*env)->NewStringUTF(env, (const char *)" + str1 + "_cstr);");
/* 1210 */         this.unit.emitln("    free(" + str1 + "_cstr);");
/*      */       } else {
/* 1212 */         this.unit.emitln("(*env)->NewStringUTF(env, (const char *)" + str1 + ");");
/*      */       } 
/* 1214 */       this.unit.emitln("  }"); }
/* 1215 */     else if (javaType.isArrayOfCompoundTypeWrappers() || (javaType
/* 1216 */       .isArray() && javaType.isNIOByteBufferArray()))
/*      */     
/* 1218 */     { if (paramBoolean) {
/* 1219 */         this.unit.emitln("  " + javaType.jniTypeName() + " " + str2 + ";");
/*      */       }
/* 1221 */       this.unit.emitln("  if (NULL == " + str1 + ") { " + str2 + " = NULL; } else {");
/* 1222 */       if (!bool || this.returnValueLengthExpression == null) {
/* 1223 */         throw new GlueGenException("Error while generating C code: No length specified for array returned from function for arg #" + paramInt + ", " + type
/* 1224 */             .getDebugString() + ", for " + this.binding, this.binding
/* 1225 */             .getCSymbol().getASTLocusTag());
/*      */       }
/* 1227 */       this.unit.emitln("    _array_res_length = " + this.returnValueLengthExpression.format(argumentNameArray()) + ";");
/* 1228 */       this.unit.emitln("    _array_res = (*env)->NewObjectArray(env, _array_res_length, (*env)->FindClass(env, \"java/nio/ByteBuffer\"), NULL);");
/* 1229 */       this.unit.emitln("    for (_array_idx = 0; _array_idx < _array_res_length; _array_idx++) {");
/* 1230 */       Type type1 = this.binding.getCSymbol().getReturnType();
/* 1231 */       Type type2 = type1.getArrayBaseOrPointerTargetType();
/* 1232 */       this.unit.emitln("      (*env)->SetObjectArrayElement(env, _array_res, _array_idx, (*env)->NewDirectByteBuffer(env, (void *)" + str1 + "[" + "_array_idx" + "], sizeof(" + type2
/* 1233 */           .getCName() + ")));");
/* 1234 */       this.unit.emitln("    }");
/* 1235 */       this.unit.emitln("  " + str2 + " = " + "_array_res" + ";");
/* 1236 */       this.unit.emitln("  }"); }
/* 1237 */     else { if (javaType.isArray())
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1242 */         throw new GlueGenException("Could not emit native code for arg #" + paramInt + ", " + type
/* 1243 */             .getDebugString() + ", for " + this.binding + ": array return values for non-char types not implemented yet.", this.binding
/*      */             
/* 1245 */             .getCSymbol().getASTLocusTag());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1267 */       throw new GlueGenException("Unhandled return type: arg #" + paramInt + ", C " + type.getDebugString() + ", java " + javaType.getDebugString() + " for " + this.binding, this.binding
/* 1268 */           .getCSymbol().getReturnType().getASTLocusTag()); }
/*      */     
/* 1270 */     return true; }
/*      */   protected void emitBodyVariablePostCallCleanup() { for (byte b = 0; b < this.binding.getNumArguments(); b++) { JavaType javaType = this.binding.getJavaArgumentType(b); if (!javaType.isJNIEnv() && !this.binding.isArgumentThisPointer(b)) { Type type = this.binding.getCArgumentType(b); String str = this.binding.getArgumentName(b); if (javaType.isArray() || (javaType.isNIOBuffer() && this.forIndirectBufferAndArrayImplementation) || javaType.isArrayOfCompoundTypeWrappers()) { boolean bool = javaArgTypeNeedsDataCopy(javaType); String str1 = pointerConversionArgumentName(str); if (!bool) { this.unit.emitln("  if ( JNI_FALSE == " + isNIOArgName(b) + " && NULL != " + str + " ) {"); String str2 = type.isBaseTypeConst() ? "JNI_ABORT" : "0"; this.unit.emit("    (*env)->ReleasePrimitiveArrayCritical(env, " + str + ", " + str1 + ", " + str2 + ");"); } else { this.unit.emitln("  if ( NULL != " + str + " ) {"); if (!type.isBaseTypeConst()) if (javaType.isArrayOfCompoundTypeWrappers()) { this.unit.emitln("    _tmpArrayLen = (*env)->GetArrayLength(env, " + str + ");"); this.unit.emitln("    for (_copyIndex = 0; _copyIndex < _tmpArrayLen; ++_copyIndex) {"); this.unit.emitln("      _tmpObj = (*env)->GetObjectArrayElement(env, " + str + ", _copyIndex);"); emitReturnDirectBufferAddress("_tmpObj", type.getBaseType().getCName(), "(" + str1 + "_copy + _copyIndex)", false, (String)null); this.unit.emitln("    }"); } else { throw new GlueGenException("Cannot clean up copied data for ptr-to-ptr arg type \"" + type.getDebugString() + "\": support for cleaning up most non-const ptr-to-ptr types not implemented.", this.binding.getCSymbol().getASTLocusTag()); }   this.unit.emitln("    /* Clean up " + str1 + "_copy */"); if (!javaType.isNIOBufferArray() && !javaType.isArrayOfCompoundTypeWrappers()) { this.unit.emit("    "); this.unit.emit("_tmpArrayLen"); this.unit.emit(" = (*env)->GetArrayLength(env, "); this.unit.emit(str); this.unit.emitln(");"); PointerType pointerType = type.asPointer(); if (pointerType == null) throw new GlueGenException("Could not copy data for type \"" + type.getDebugString() + "\"; currently only pointer types supported.", this.binding.getCSymbol().getASTLocusTag());  this.unit.emitln("    for (_copyIndex = 0; _copyIndex < _tmpArrayLen; ++_copyIndex) {"); this.unit.emitln("      /* free each element of " + str1 + "_copy */"); this.unit.emit("      _tmpObj = (*env)->GetObjectArrayElement(env, "); this.unit.emit(str); this.unit.emitln(", _copyIndex);"); if (javaType.isStringArray()) { this.unit.emit("     (*env)->ReleaseStringUTFChars(env, "); this.unit.emit("(jstring) _tmpObj"); this.unit.emit(", "); this.unit.emit(str1 + "_copy[_copyIndex]"); this.unit.emitln(");"); } else { throw new GlueGenException("Cannot yet handle type \"" + type.getDebugString() + "\"; need to add support for cleaning up copied ptr-to-ptr-to-primitiveType subarrays", this.binding.getCSymbol().getASTLocusTag()); }  this.unit.emitln("    }"); }  this.unit.emit("    free((void*) "); this.unit.emit(str1 + "_copy"); this.unit.emitln(");"); }  this.unit.emitln("  }"); } else if (javaType.isString()) { this.unit.emitln("  if ( NULL != " + str + " ) {"); if (isUTF8Type(type)) { this.unit.emit("    (*env)->ReleaseStringUTFChars(env, "); this.unit.emit(str); this.unit.emit(", _strchars_"); this.unit.emit(str); this.unit.emitln(");"); } else { this.unit.emitln("    free((void*) _strchars_" + str + ");"); }  this.unit.emitln("  }"); }  }  }  }
/*      */   protected int emitBodyPassCArguments() { for (byte b = 0; b < this.binding.getNumArguments(); b++) { if (b != 0) this.unit.emit(", ");  JavaType javaType = this.binding.getJavaArgumentType(b); if (javaType.isVoid()) { assert this.binding.getNumArguments() == 1; } else if (javaType.isJNIEnv()) { this.unit.emit("env"); } else if (this.binding.isArgumentThisPointer(b)) { this.unit.emit(cThisArgumentName()); } else { this.unit.emit("("); Type type = this.binding.getCArgumentType(b); boolean bool = javaArgTypeNeedsDataCopy(javaType); boolean bool1 = (!bool && (javaType.isArray() || javaType.isArrayOfCompoundTypeWrappers() || (javaType.isNIOBuffer() && this.forIndirectBufferAndArrayImplementation))) ? true : false; this.unit.emit(type.getCName(true)); this.unit.emit(") "); if (type.isPointer() && javaType.isPrimitive()) this.unit.emit("(intptr_t) ");  if (javaType.isArray() || javaType.isNIOBuffer() || javaType.isCompoundTypeWrapper() || javaType.isArrayOfCompoundTypeWrappers()) { if (bool1) { this.unit.emit("(((char *) "); } else if (!type.isPointer() && javaType.isCompoundTypeWrapper()) { this.unit.emit("*"); }  this.unit.emit(pointerConversionArgumentName(this.binding.getArgumentName(b))); if (bool) this.unit.emit("_copy");  if (bool1) this.unit.emit(") + " + byteOffsetArgName(b) + ")");  } else { if (javaType.isString())
/*      */             this.unit.emit("_strchars_");  this.unit.emit(this.binding.getArgumentName(b)); if (!javaType.isString() && null != this.javaCallbackEmitter)
/* 1274 */             this.javaCallbackEmitter.emitCOptArgumentSuffix(this.unit, b);  }  }  }  return this.binding.getNumArguments(); } protected static String cThisArgumentName() { return "this0"; }
/*      */ 
/*      */   
/*      */   protected String jniMangle(MethodBinding paramMethodBinding) {
/* 1278 */     StringBuilder stringBuilder = new StringBuilder();
/* 1279 */     stringBuilder.append(JavaEmitter.jniMangle(getImplName()));
/* 1280 */     stringBuilder.append(getImplSuffix());
/* 1281 */     if (null == this.javaCallbackEmitter) {
/* 1282 */       stringBuilder.append("__");
/* 1283 */       appendJNIMangledArgs(paramMethodBinding, this.forIndirectBufferAndArrayImplementation, stringBuilder);
/* 1284 */       if (null != this.javaCallbackEmitter) {
/* 1285 */         this.javaCallbackEmitter.appendCAdditionalJNIDescriptor(stringBuilder);
/*      */       }
/*      */     } 
/* 1288 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringBuilder appendJNIMangledArgs(MethodBinding paramMethodBinding, boolean paramBoolean, StringBuilder paramStringBuilder) {
/* 1299 */     if (paramMethodBinding.isReturnCompoundByValue()) {
/* 1300 */       JavaType.appendJNIDescriptor(paramStringBuilder, Class.class, true);
/*      */     }
/* 1302 */     if (paramMethodBinding.hasContainingType())
/*      */     {
/* 1304 */       JavaType.appendJNIDescriptor(paramStringBuilder, ByteBuffer.class, true);
/*      */     }
/* 1306 */     for (byte b = 0; b < paramMethodBinding.getNumArguments(); b++) {
/* 1307 */       if (!paramMethodBinding.isArgumentThisPointer(b)) {
/*      */ 
/*      */         
/* 1310 */         JavaType javaType = paramMethodBinding.getJavaArgumentType(b);
/* 1311 */         if (javaType.isVoid()) {
/*      */ 
/*      */           
/* 1314 */           if (b != 0 || paramMethodBinding.getNumArguments() > 1) {
/* 1315 */             throw new GlueGenException("Saw illegal \"void\" argument while emitting arg " + b + " of " + paramMethodBinding, paramMethodBinding
/* 1316 */                 .getCArgumentType(b).getASTLocusTag());
/*      */           }
/*      */         } else {
/* 1319 */           Class<?> clazz = javaType.getJavaClass();
/* 1320 */           if (clazz != null) {
/* 1321 */             JavaType.appendJNIDescriptor(paramStringBuilder, clazz, false);
/*      */ 
/*      */             
/* 1324 */             if (javaType.isNIOBuffer()) {
/* 1325 */               JavaType.appendJNIDescriptor(paramStringBuilder, int.class, false);
/* 1326 */               if (paramBoolean) {
/* 1327 */                 JavaType.appendJNIDescriptor(paramStringBuilder, boolean.class, false);
/*      */               }
/* 1329 */             } else if (javaType.isNIOBufferArray()) {
/* 1330 */               int[] arrayOfInt = new int[0];
/* 1331 */               clazz = arrayOfInt.getClass();
/* 1332 */               JavaType.appendJNIDescriptor(paramStringBuilder, clazz, true);
/*      */             } 
/* 1334 */             if (javaType.isPrimitiveArray()) {
/* 1335 */               JavaType.appendJNIDescriptor(paramStringBuilder, int.class, false);
/*      */             }
/* 1337 */           } else if (javaType.isNamedClass()) {
/* 1338 */             paramStringBuilder.append(javaType.getJNIMethodDesciptor());
/* 1339 */           } else if (javaType.isCompoundTypeWrapper()) {
/*      */             
/* 1341 */             JavaType.appendJNIDescriptor(paramStringBuilder, ByteBuffer.class, true);
/* 1342 */           } else if (javaType.isArrayOfCompoundTypeWrappers()) {
/*      */             
/* 1344 */             ByteBuffer[] arrayOfByteBuffer = new ByteBuffer[0];
/* 1345 */             JavaType.appendJNIDescriptor(paramStringBuilder, arrayOfByteBuffer.getClass(), true);
/* 1346 */           } else if (!javaType.isJNIEnv()) {
/*      */ 
/*      */ 
/*      */             
/* 1350 */             throw new GlueGenException("Unknown kind of JavaType: arg " + b + ", name=" + javaType.getName() + " of " + paramMethodBinding, paramMethodBinding
/* 1351 */                 .getCArgumentType(b).getASTLocusTag());
/*      */           } 
/*      */         } 
/*      */       } 
/* 1355 */     }  return paramStringBuilder;
/*      */   }
/*      */   
/*      */   private void emitOutOfMemoryCheck(String paramString1, String paramString2) {
/* 1359 */     this.unit.emitln("  if ( NULL == " + paramString1 + " ) {");
/* 1360 */     this.unit.emitln("      (*env)->ThrowNew(env, (*env)->FindClass(env, \"java/lang/OutOfMemoryError\"),");
/* 1361 */     this.unit.emit("                       \"" + paramString2);
/* 1362 */     this.unit.emit(" in native dispatcher for \\\"");
/* 1363 */     this.unit.emit(getInterfaceName());
/* 1364 */     this.unit.emitln("\\\"\");");
/* 1365 */     this.unit.emit("      return");
/* 1366 */     if (!this.binding.getJavaReturnType().isVoid()) {
/* 1367 */       this.unit.emit(" 0");
/*      */     }
/* 1369 */     this.unit.emitln(";");
/* 1370 */     this.unit.emitln("    }");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void emitMalloc(String paramString1, String paramString2, boolean paramBoolean, String paramString3, String paramString4) {
/* 1378 */     this.unit.emit("    ");
/* 1379 */     this.unit.emit(paramString1);
/* 1380 */     this.unit.emit(" = (");
/* 1381 */     if (paramBoolean) {
/* 1382 */       this.unit.emit("const ");
/*      */     }
/* 1384 */     this.unit.emit(paramString2);
/* 1385 */     this.unit.emit(" *) malloc(");
/* 1386 */     this.unit.emit(paramString3);
/* 1387 */     this.unit.emit(" * sizeof(");
/* 1388 */     this.unit.emit(paramString2);
/* 1389 */     this.unit.emitln("));");
/*      */     
/* 1391 */     emitOutOfMemoryCheck(paramString1, paramString4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void emitCalloc(String paramString1, String paramString2, String paramString3, String paramString4) {
/* 1398 */     this.unit.emit("    ");
/* 1399 */     this.unit.emit(paramString1);
/* 1400 */     this.unit.emit(" = (");
/* 1401 */     this.unit.emit(paramString2);
/* 1402 */     this.unit.emit(" *) calloc(");
/* 1403 */     this.unit.emit(paramString3);
/* 1404 */     this.unit.emit(", sizeof(");
/* 1405 */     this.unit.emit(paramString2);
/* 1406 */     this.unit.emitln("));");
/*      */     
/* 1408 */     emitOutOfMemoryCheck(paramString1, paramString4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void emitGetStringChars(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) {
/* 1415 */     this.unit.emitln("  if ( NULL != " + paramString1 + " ) {");
/*      */     
/* 1417 */     if (paramBoolean1) {
/* 1418 */       this.unit.emit("    ");
/* 1419 */       this.unit.emit(paramString2);
/* 1420 */       this.unit.emit(" = (*env)->GetStringUTFChars(env, ");
/* 1421 */       this.unit.emit(paramString1);
/* 1422 */       this.unit.emitln(", (jboolean*)NULL);");
/*      */ 
/*      */       
/* 1425 */       emitOutOfMemoryCheck(paramString2, "Failed to get UTF-8 chars for argument \\\"" + paramString1 + "\\\"");
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 1434 */       emitCalloc(paramString2, "jchar", "(*env)->GetStringLength(env, " + paramString1 + ") + 1", "Could not allocate temporary buffer for copying string argument \\\"" + paramString1 + "\\\"");
/*      */ 
/*      */ 
/*      */       
/* 1438 */       this.unit.emitln("    (*env)->GetStringRegion(env, " + paramString1 + ", 0, (*env)->GetStringLength(env, " + paramString1 + "), " + paramString2 + ");");
/*      */     } 
/* 1440 */     this.unit.emit("  }");
/* 1441 */     if (paramBoolean2) {
/* 1442 */       this.unit.emit(" else {");
/* 1443 */       this.unit.emit("      ");
/* 1444 */       this.unit.emit(paramString2);
/* 1445 */       this.unit.emitln(" = NULL;");
/* 1446 */       this.unit.emitln("  }");
/*      */     } else {
/* 1448 */       this.unit.emitln();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void emitGetDirectBufferAddress(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, String paramString4, boolean paramBoolean2) {
/* 1457 */     this.unit.emitln("    if ( NULL != " + paramString1 + " ) {");
/* 1458 */     this.unit.emit("    ");
/* 1459 */     this.unit.emit("    ");
/* 1460 */     if (paramBoolean1) {
/* 1461 */       this.unit.emit(paramString3 + " = (" + paramString2 + ") (((char*) (*env)->GetDirectBufferAddress(env, " + paramString1 + "))");
/* 1462 */       this.unit.emitln(" + " + ((paramString4 != null) ? paramString4 : "0") + ");");
/*      */     } else {
/*      */       
/* 1465 */       this.unit.emitln("memcpy((void *)" + paramString3 + ", (*env)->GetDirectBufferAddress(env, " + paramString1 + "), sizeof(" + paramString2 + "));");
/*      */     } 
/*      */     
/* 1468 */     if (paramBoolean2) {
/* 1469 */       this.unit.emitln("    } else {");
/* 1470 */       this.unit.emit("    ");
/* 1471 */       this.unit.emit("    ");
/* 1472 */       if (paramBoolean1) {
/* 1473 */         this.unit.emit(paramString3);
/* 1474 */         this.unit.emitln(" = NULL;");
/*      */       } else {
/* 1476 */         this.unit.emitln("memset((void *)" + paramString3 + ", 0, sizeof(" + paramString2 + "));");
/*      */       } 
/*      */     } 
/* 1479 */     this.unit.emitln("    }");
/* 1480 */     this.unit.emitln();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void emitReturnDirectBufferAddress(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4) {
/* 1488 */     this.unit.emit("    ");
/* 1489 */     this.unit.emit("    ");
/* 1490 */     if (paramBoolean) {
/* 1491 */       this.unit.emit("(((char*) (*env)->GetDirectBufferAddress(env, " + paramString1 + "))");
/* 1492 */       this.unit.emitln(" + " + ((paramString4 != null) ? paramString4 : "0") + ") = " + paramString3 + ";");
/* 1493 */       throw new RuntimeException("incomplete implementation");
/*      */     } 
/*      */     
/* 1496 */     this.unit.emitln("memcpy((*env)->GetDirectBufferAddress(env, " + paramString1 + "), " + paramString3 + ", sizeof(" + paramString2 + "));");
/*      */     
/* 1498 */     this.unit.emitln();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean emitPointerDeclaration(JavaType paramJavaType, Type paramType, String paramString1, String paramString2) {
/* 1509 */     String str = null;
/* 1510 */     boolean bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1516 */     if (paramJavaType.isNIOBuffer()) {
/*      */       
/* 1518 */       str = paramType.getCName();
/* 1519 */     } else if (paramJavaType.isArray() || paramJavaType.isArrayOfCompoundTypeWrappers()) {
/* 1520 */       bool = javaArgTypeNeedsDataCopy(paramJavaType);
/* 1521 */       if (paramJavaType.isPrimitiveArray() || paramJavaType
/* 1522 */         .isNIOBufferArray() || paramJavaType
/* 1523 */         .isArrayOfCompoundTypeWrappers()) {
/* 1524 */         str = paramType.getCName();
/* 1525 */       } else if (!paramJavaType.isStringArray()) {
/* 1526 */         Class<?> clazz = paramJavaType.getJavaClass().getComponentType();
/* 1527 */         if (clazz.isArray()) {
/* 1528 */           Class<?> clazz1 = clazz.getComponentType();
/* 1529 */           if (clazz1.isPrimitive())
/*      */           {
/* 1531 */             str = paramType.getCName();
/*      */           }
/*      */           else
/*      */           {
/* 1535 */             throw new GlueGenException("Unsupported pointer type: \"" + paramType.getDebugString() + "\"", paramType.getASTLocusTag());
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1540 */           throw new GlueGenException("Unsupported pointer type: \"" + paramType.getDebugString() + "\"", paramType.getASTLocusTag());
/*      */         } 
/*      */       } 
/*      */     } else {
/* 1544 */       str = paramType.getCName();
/*      */     } 
/*      */     
/* 1547 */     this.unit.emit("  ");
/* 1548 */     if (!bool) {
/*      */       
/* 1550 */       this.unit.emit(str);
/* 1551 */       if (!paramType.isPointer() && paramJavaType.isCompoundTypeWrapper()) {
/* 1552 */         this.unit.emit(" * ");
/*      */       } else {
/* 1554 */         this.unit.emit(" ");
/*      */       } 
/* 1556 */       this.unit.emit(paramString1);
/* 1557 */       this.unit.emitln(" = NULL;");
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1562 */       if (paramJavaType.isStringArray()) {
/* 1563 */         String str1 = "char *";
/* 1564 */         PointerType pointerType = paramType.asPointer();
/* 1565 */         if (pointerType != null) {
/* 1566 */           str1 = pointerType.getTargetType().asPointer().getCName();
/*      */         }
/* 1568 */         if (paramType.isBaseTypeConst()) {
/* 1569 */           this.unit.emit("const ");
/*      */         }
/* 1571 */         this.unit.emit(str1 + " *");
/*      */       } else {
/* 1573 */         if (paramType.isBaseTypeConst()) {
/* 1574 */           this.unit.emit("const ");
/*      */         }
/* 1576 */         this.unit.emit(str);
/*      */       } 
/* 1578 */       this.unit.emit(" ");
/* 1579 */       this.unit.emit(paramString1);
/* 1580 */       this.unit.emit("_copy = NULL; /* copy of data in ");
/* 1581 */       this.unit.emit(paramString2);
/* 1582 */       this.unit.emitln(", laid out according to C memory model */");
/*      */     } 
/*      */     
/* 1585 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void emitPointerConversion(MethodBinding paramMethodBinding, JavaType paramJavaType, Type paramType, String paramString1, String paramString2, String paramString3) {
/*      */     String str;
/* 1595 */     if (paramJavaType.isCompoundTypeWrapper()) {
/* 1596 */       paramString3 = null;
/*      */     }
/*      */ 
/*      */     
/* 1600 */     if (!paramType.isPointer() && paramJavaType.isCompoundTypeWrapper()) {
/* 1601 */       str = paramType.getCName() + " *";
/*      */     } else {
/* 1603 */       str = paramType.getCName();
/*      */     } 
/* 1605 */     emitGetDirectBufferAddress(paramString1, str, paramString2, true, paramString3, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String byteOffsetArgName(int paramInt) {
/* 1613 */     return JavaMethodBindingEmitter.byteOffsetArgName(this.binding.getArgumentName(paramInt));
/*      */   }
/*      */   
/*      */   protected String isNIOArgName(int paramInt) {
/* 1617 */     return isNIOArgName(this.binding.getArgumentName(paramInt));
/*      */   }
/*      */   
/*      */   protected String isNIOArgName(String paramString) {
/* 1621 */     return paramString + "_is_nio";
/*      */   }
/*      */   
/*      */   protected String byteOffsetArrayArgName(int paramInt) {
/* 1625 */     return this.binding.getArgumentName(paramInt) + "_byte_offset_array";
/*      */   }
/*      */   
/*      */   protected String[] argumentNameArray() {
/* 1629 */     String[] arrayOfString = new String[this.binding.getNumArguments()];
/* 1630 */     for (byte b = 0; b < this.binding.getNumArguments(); b++) {
/* 1631 */       arrayOfString[b] = this.binding.getArgumentName(b);
/* 1632 */       if (this.binding.getJavaArgumentType(b).isPrimitiveArray())
/*      */       {
/* 1634 */         arrayOfString[b] = arrayOfString[b] + ", " + byteOffsetArgName(b);
/*      */       }
/*      */     } 
/* 1637 */     return arrayOfString;
/*      */   }
/*      */   
/*      */   protected String pointerConversionArgumentName(String paramString) {
/* 1641 */     return "_" + paramString + "_ptr";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class DefaultCommentEmitter
/*      */     implements CommentEmitter
/*      */   {
/*      */     public void emit(FunctionEmitter param1FunctionEmitter, PrintWriter param1PrintWriter) {
/* 1652 */       emitBeginning((CMethodBindingEmitter)param1FunctionEmitter, param1PrintWriter);
/* 1653 */       emitEnding((CMethodBindingEmitter)param1FunctionEmitter, param1PrintWriter);
/*      */     }
/*      */     protected void emitBeginning(CMethodBindingEmitter param1CMethodBindingEmitter, PrintWriter param1PrintWriter) {
/* 1656 */       param1PrintWriter.println("  Java->C glue code:");
/* 1657 */       param1PrintWriter.print(" *   Java package: ");
/* 1658 */       param1PrintWriter.print(param1CMethodBindingEmitter.getJavaPackageName());
/* 1659 */       param1PrintWriter.print(".");
/* 1660 */       param1PrintWriter.println(param1CMethodBindingEmitter.getJavaClassName());
/* 1661 */       param1PrintWriter.print(" *    Java method: ");
/* 1662 */       MethodBinding methodBinding = param1CMethodBindingEmitter.getBinding();
/* 1663 */       param1PrintWriter.println(methodBinding);
/* 1664 */       param1PrintWriter.println(" *     C function: " + methodBinding.getCSymbol());
/*      */     }
/*      */     
/*      */     protected void emitEnding(CMethodBindingEmitter param1CMethodBindingEmitter, PrintWriter param1PrintWriter) {}
/*      */   }
/*      */   
/*      */   protected boolean javaArgTypeNeedsDataCopy(JavaType paramJavaType) {
/* 1671 */     if (paramJavaType.isArray()) {
/* 1672 */       return (paramJavaType.isNIOBufferArray() || paramJavaType
/* 1673 */         .isStringArray() || paramJavaType
/* 1674 */         .getJavaClass().getComponentType().isArray());
/*      */     }
/* 1676 */     if (paramJavaType.isArrayOfCompoundTypeWrappers()) {
/* 1677 */       return true;
/*      */     }
/* 1679 */     return false;
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/CMethodBindingEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */