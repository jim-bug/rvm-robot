/*     */ package com.jogamp.gluegen;
/*     */ 
/*     */ import com.jogamp.gluegen.cgram.types.CompoundType;
/*     */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.Type;
/*     */ import com.jogamp.gluegen.cgram.types.TypeDictionary;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DebugEmitter
/*     */   implements GlueEmitter
/*     */ {
/*     */   protected JavaConfiguration cfg;
/*     */   
/*     */   public void readConfigurationFile(String paramString) throws IOException {
/*  54 */     this.cfg = createConfig();
/*  55 */     this.cfg.read(paramString);
/*     */   }
/*     */   
/*     */   public JavaConfiguration getConfig() {
/*  59 */     return this.cfg;
/*     */   }
/*     */   
/*     */   public void beginEmission(GlueEmitterControls paramGlueEmitterControls) {
/*  63 */     System.out.println("----- BEGIN EMISSION OF GLUE CODE -----");
/*     */   }
/*     */ 
/*     */   
/*     */   public void endEmission() {
/*  68 */     System.out.println("----- END EMISSION OF GLUE CODE -----");
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginDefines() {}
/*     */ 
/*     */   
/*     */   public void emitDefine(ConstantDefinition paramConstantDefinition, String paramString) {
/*  76 */     String str1 = paramConstantDefinition.getName();
/*  77 */     String str2 = paramConstantDefinition.getNativeExpr();
/*  78 */     System.out.println("#define " + str1 + " " + str2 + (
/*  79 */         (paramString != null) ? ("// " + paramString) : ""));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endDefines() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginFunctions(TypeDictionary paramTypeDictionary1, TypeDictionary paramTypeDictionary2, Map<Type, Type> paramMap, List<FunctionSymbol> paramList) {
/*  89 */     Set set = paramTypeDictionary1.keySet();
/*  90 */     for (String str : set) {
/*  91 */       Type type = paramTypeDictionary1.get(str);
/*  92 */       System.out.println("typedef " + type + " " + str + ";");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<FunctionSymbol> emitFunctions(List<FunctionSymbol> paramList) throws Exception {
/*  98 */     for (FunctionSymbol functionSymbol : paramList) {
/*  99 */       emitSingleFunction(functionSymbol);
/*     */     }
/* 101 */     return paramList.iterator();
/*     */   }
/*     */   public void emitSingleFunction(FunctionSymbol paramFunctionSymbol) {
/* 104 */     System.out.println(paramFunctionSymbol);
/* 105 */     System.out.println(" -> " + paramFunctionSymbol.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void endFunctions() {}
/*     */ 
/*     */   
/*     */   public void beginStructLayout() throws Exception {}
/*     */ 
/*     */   
/*     */   public void layoutStruct(CompoundType paramCompoundType) throws Exception {}
/*     */ 
/*     */   
/*     */   public void endStructLayout() throws Exception {}
/*     */   
/*     */   public void beginStructs(TypeDictionary paramTypeDictionary1, TypeDictionary paramTypeDictionary2, Map<Type, Type> paramMap) {}
/*     */   
/*     */   public void emitStruct(CompoundType paramCompoundType, Type paramType) {
/* 123 */     String str = paramCompoundType.getName();
/* 124 */     if (str == null && paramType != null) {
/* 125 */       str = paramType.getName();
/*     */     }
/*     */     
/* 128 */     System.out.println("Referenced type \"" + str + "\"");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endStructs() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaConfiguration createConfig() {
/* 139 */     return new JavaConfiguration();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/DebugEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */