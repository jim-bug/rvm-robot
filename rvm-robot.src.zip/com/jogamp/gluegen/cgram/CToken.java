/*    */ package com.jogamp.gluegen.cgram;
/*    */ 
/*    */ public class CToken extends CommonToken {
/*  4 */   String source = "";
/*    */   
/*    */   int tokenNumber;
/*    */   
/*    */   public String getSource() {
/*  9 */     return this.source;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setSource(String paramString) {
/* 14 */     this.source = paramString;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getTokenNumber() {
/* 19 */     return this.tokenNumber;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTokenNumber(int paramInt) {
/* 24 */     this.tokenNumber = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     return "CToken:(" + hashCode() + ")[" + getType() + "] " + getText() + " line:" + getLine() + " source:" + this.source;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/CToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */