package com.jogamp.gluegen.cgram;

public interface GnuCEmitterTokenTypes {
  public static final int EOF = 1;
  
  public static final int NULL_TREE_LOOKAHEAD = 3;
  
  public static final int LITERAL_typedef = 4;
  
  public static final int LITERAL_asm = 5;
  
  public static final int LITERAL_volatile = 6;
  
  public static final int LCURLY = 7;
  
  public static final int RCURLY = 8;
  
  public static final int SEMI = 9;
  
  public static final int LITERAL_struct = 10;
  
  public static final int LITERAL_union = 11;
  
  public static final int LITERAL_enum = 12;
  
  public static final int LITERAL_auto = 13;
  
  public static final int LITERAL_register = 14;
  
  public static final int LITERAL_extern = 15;
  
  public static final int LITERAL_static = 16;
  
  public static final int LITERAL_const = 17;
  
  public static final int LITERAL_void = 18;
  
  public static final int LITERAL_char = 19;
  
  public static final int LITERAL_short = 20;
  
  public static final int LITERAL_int = 21;
  
  public static final int LITERAL_long = 22;
  
  public static final int LITERAL_float = 23;
  
  public static final int LITERAL_double = 24;
  
  public static final int LITERAL_signed = 25;
  
  public static final int LITERAL_unsigned = 26;
  
  public static final int LITERAL_wchar_t = 33;
  
  public static final int LITERAL_ptrdiff_t = 38;
  
  public static final int LITERAL_intptr_t = 39;
  
  public static final int LITERAL_size_t = 40;
  
  public static final int LITERAL_uintptr_t = 41;
  
  public static final int ID = 42;
  
  public static final int COMMA = 43;
  
  public static final int COLON = 44;
  
  public static final int ASSIGN = 45;
  
  public static final int STAR = 46;
  
  public static final int LPAREN = 47;
  
  public static final int RPAREN = 48;
  
  public static final int LBRACKET = 49;
  
  public static final int RBRACKET = 50;
  
  public static final int VARARGS = 51;
  
  public static final int LITERAL_while = 52;
  
  public static final int LITERAL_do = 53;
  
  public static final int LITERAL_for = 54;
  
  public static final int LITERAL_goto = 55;
  
  public static final int LITERAL_continue = 56;
  
  public static final int LITERAL_break = 57;
  
  public static final int LITERAL_return = 58;
  
  public static final int LITERAL_case = 59;
  
  public static final int LITERAL_default = 60;
  
  public static final int LITERAL_if = 61;
  
  public static final int LITERAL_else = 62;
  
  public static final int LITERAL_switch = 63;
  
  public static final int DIV_ASSIGN = 64;
  
  public static final int PLUS_ASSIGN = 65;
  
  public static final int MINUS_ASSIGN = 66;
  
  public static final int STAR_ASSIGN = 67;
  
  public static final int MOD_ASSIGN = 68;
  
  public static final int RSHIFT_ASSIGN = 69;
  
  public static final int LSHIFT_ASSIGN = 70;
  
  public static final int BAND_ASSIGN = 71;
  
  public static final int BOR_ASSIGN = 72;
  
  public static final int BXOR_ASSIGN = 73;
  
  public static final int QUESTION = 74;
  
  public static final int LOR = 75;
  
  public static final int LAND = 76;
  
  public static final int BOR = 77;
  
  public static final int BXOR = 78;
  
  public static final int BAND = 79;
  
  public static final int EQUAL = 80;
  
  public static final int NOT_EQUAL = 81;
  
  public static final int LT = 82;
  
  public static final int LTE = 83;
  
  public static final int GT = 84;
  
  public static final int GTE = 85;
  
  public static final int LSHIFT = 86;
  
  public static final int RSHIFT = 87;
  
  public static final int PLUS = 88;
  
  public static final int MINUS = 89;
  
  public static final int DIV = 90;
  
  public static final int MOD = 91;
  
  public static final int INC = 92;
  
  public static final int DEC = 93;
  
  public static final int LITERAL_sizeof = 94;
  
  public static final int BNOT = 95;
  
  public static final int LNOT = 96;
  
  public static final int PTR = 97;
  
  public static final int DOT = 98;
  
  public static final int CharLiteral = 99;
  
  public static final int StringLiteral = 100;
  
  public static final int IntOctalConst = 101;
  
  public static final int LongOctalConst = 102;
  
  public static final int UnsignedOctalConst = 103;
  
  public static final int IntIntConst = 104;
  
  public static final int LongIntConst = 105;
  
  public static final int UnsignedIntConst = 106;
  
  public static final int IntHexConst = 107;
  
  public static final int LongHexConst = 108;
  
  public static final int UnsignedHexConst = 109;
  
  public static final int FloatDoubleConst = 110;
  
  public static final int DoubleDoubleConst = 111;
  
  public static final int LongDoubleConst = 112;
  
  public static final int NTypedefName = 113;
  
  public static final int NInitDecl = 114;
  
  public static final int NDeclarator = 115;
  
  public static final int NStructDeclarator = 116;
  
  public static final int NDeclaration = 117;
  
  public static final int NCast = 118;
  
  public static final int NPointerGroup = 119;
  
  public static final int NExpressionGroup = 120;
  
  public static final int NFunctionCallArgs = 121;
  
  public static final int NNonemptyAbstractDeclarator = 122;
  
  public static final int NInitializer = 123;
  
  public static final int NStatementExpr = 124;
  
  public static final int NEmptyExpression = 125;
  
  public static final int NParameterTypeList = 126;
  
  public static final int NFunctionDef = 127;
  
  public static final int NCompoundStatement = 128;
  
  public static final int NParameterDeclaration = 129;
  
  public static final int NCommaExpr = 130;
  
  public static final int NUnaryExpr = 131;
  
  public static final int NLabel = 132;
  
  public static final int NPostfixExpr = 133;
  
  public static final int NRangeExpr = 134;
  
  public static final int NStringSeq = 135;
  
  public static final int NInitializerElementLabel = 136;
  
  public static final int NLcurlyInitializer = 137;
  
  public static final int NAsmAttribute = 138;
  
  public static final int NGnuAsmExpr = 139;
  
  public static final int NTypeMissing = 140;
  
  public static final int Vocabulary = 141;
  
  public static final int Whitespace = 142;
  
  public static final int Comment = 143;
  
  public static final int CPPComment = 144;
  
  public static final int NonWhitespace = 145;
  
  public static final int PREPROC_DIRECTIVE = 146;
  
  public static final int DefineExpr = 147;
  
  public static final int DefineExpr2 = 148;
  
  public static final int Space = 149;
  
  public static final int LineDirective = 150;
  
  public static final int BadStringLiteral = 151;
  
  public static final int Escape = 152;
  
  public static final int Digit = 153;
  
  public static final int LongSuffix = 154;
  
  public static final int UnsignedSuffix = 155;
  
  public static final int FloatSuffix = 156;
  
  public static final int Exponent = 157;
  
  public static final int Number = 158;
  
  public static final int LITERAL___label__ = 159;
  
  public static final int LITERAL_inline = 160;
  
  public static final int LITERAL_typeof = 161;
  
  public static final int LITERAL___complex = 162;
  
  public static final int LITERAL___attribute = 163;
  
  public static final int LITERAL___alignof = 164;
  
  public static final int LITERAL___real = 165;
  
  public static final int LITERAL___imag = 166;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/GnuCEmitterTokenTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */