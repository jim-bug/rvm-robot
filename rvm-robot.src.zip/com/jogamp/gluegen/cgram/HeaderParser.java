/*      */ package com.jogamp.gluegen.cgram;
/*      */ import antlr.ASTNULLType;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import com.jogamp.gluegen.ASTLocusTag;
/*      */ import com.jogamp.gluegen.ConstantDefinition;
/*      */ import com.jogamp.gluegen.GlueGenException;
/*      */ import com.jogamp.gluegen.JavaConfiguration;
/*      */ import com.jogamp.gluegen.cgram.types.CompoundType;
/*      */ import com.jogamp.gluegen.cgram.types.CompoundTypeKind;
/*      */ import com.jogamp.gluegen.cgram.types.DoubleType;
/*      */ import com.jogamp.gluegen.cgram.types.EnumType;
/*      */ import com.jogamp.gluegen.cgram.types.Field;
/*      */ import com.jogamp.gluegen.cgram.types.FloatType;
/*      */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*      */ import com.jogamp.gluegen.cgram.types.FunctionType;
/*      */ import com.jogamp.gluegen.cgram.types.IntType;
/*      */ import com.jogamp.gluegen.cgram.types.PointerType;
/*      */ import com.jogamp.gluegen.cgram.types.SizeThunk;
/*      */ import com.jogamp.gluegen.cgram.types.Type;
/*      */ import com.jogamp.gluegen.cgram.types.TypeComparator;
/*      */ import com.jogamp.gluegen.cgram.types.TypeDictionary;
/*      */ import com.jogamp.gluegen.cgram.types.VoidType;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ 
/*      */ public class HeaderParser extends TreeParser implements HeaderParserTokenTypes {
/*      */   public static final String ANONYMOUS_ENUM_NAME = "<anonymous>";
/*      */   boolean debug = false;
/*      */   private JavaConfiguration cfg;
/*      */   private TypeDictionary typedefDictionary;
/*      */   private TypeDictionary structDictionary;
/*      */   
/*      */   public boolean getDebug() {
/*   40 */     return this.debug;
/*      */   }
/*      */   
/*      */   public void setDebug(boolean paramBoolean) {
/*   44 */     this.debug = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJavaConfiguration(JavaConfiguration paramJavaConfiguration) {
/*   50 */     this.cfg = paramJavaConfiguration;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTypedefDictionary(TypeDictionary paramTypeDictionary) {
/*   56 */     this.typedefDictionary = paramTypeDictionary;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeDictionary getTypedefDictionary() {
/*   61 */     return this.typedefDictionary;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDictionary(TypeDictionary paramTypeDictionary) {
/*   68 */     this.structDictionary = paramTypeDictionary;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeDictionary getStructDictionary() {
/*   73 */     return this.structDictionary;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getCanonMap() {
/*   81 */     return this.canonMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnums(List<EnumType> paramList) {
/*   91 */     throw new RuntimeException("setEnums is Unimplemented!");
/*      */   }
/*      */ 
/*      */   
/*      */   public List<EnumType> getEnums() {
/*   96 */     return new ArrayList<>(this.enumHash.values());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParsedFunctions() {
/*  103 */     this.functions.clear();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<FunctionSymbol> getParsedFunctions() {
/*  108 */     return this.functions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CompoundType lookupInStructDictionary(String paramString, CompoundTypeKind paramCompoundTypeKind, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  115 */     CompoundType compoundType = (CompoundType)this.structDictionary.get(paramString);
/*  116 */     if (compoundType == null) {
/*  117 */       compoundType = CompoundType.create(paramString, null, paramCompoundTypeKind, paramInt, paramASTLocusTag);
/*  118 */       this.structDictionary.put(paramString, (Type)compoundType);
/*  119 */       debugPrintln("Adding compound mapping: [" + paramString + "] -> " + getDebugTypeString((Type)compoundType) + " @ " + paramASTLocusTag);
/*  120 */       debugPrintln(compoundType.getStructString());
/*      */     } 
/*  122 */     return compoundType;
/*      */   }
/*      */   
/*      */   private Type lookupInTypedefDictionary(AST paramAST, String paramString) {
/*  126 */     Type type = this.typedefDictionary.get(paramString);
/*  127 */     if (type == null) {
/*  128 */       throwGlueGenException(paramAST, "Undefined reference to typedef name " + paramString);
/*      */     }
/*      */     
/*  131 */     return type;
/*      */   }
/*      */   
/*      */   static class ParameterDeclaration {
/*      */     private String id;
/*      */     private Type type;
/*      */     
/*      */     ParameterDeclaration(String param1String, Type param1Type) {
/*  139 */       this.id = param1String;
/*  140 */       this.type = param1Type;
/*      */     }
/*  142 */     String id() { return this.id; }
/*  143 */     Type type() { return this.type; }
/*  144 */     void setType(Type param1Type) { this.type = param1Type; } public String toString() {
/*  145 */       return "ParamDecl[" + this.id + ": " + this.type.getDebugString() + "]";
/*      */     }
/*      */   }
/*      */   
/*      */   static class TypeBox {
/*      */     private Type origType;
/*      */     private Type type;
/*      */     private boolean isTypedef;
/*      */     
/*      */     TypeBox(Type param1Type) {
/*  155 */       this(param1Type, false);
/*      */     }
/*      */     
/*      */     TypeBox(Type param1Type, boolean param1Boolean) {
/*  159 */       this.origType = param1Type;
/*  160 */       this.isTypedef = param1Boolean;
/*      */     }
/*      */     
/*      */     Type type() {
/*  164 */       if (this.type == null) {
/*  165 */         return this.origType;
/*      */       }
/*  167 */       return this.type;
/*      */     }
/*      */     void setType(Type param1Type) {
/*  170 */       this.type = param1Type;
/*      */     }
/*      */     void reset() {
/*  173 */       this.type = null;
/*      */     }
/*      */     boolean isTypedef() {
/*  176 */       return this.isTypedef;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  180 */       String str1 = "Type=NULL_REF";
/*  181 */       if (this.type == this.origType) {
/*  182 */         str1 = "Type=ORIG_TYPE";
/*  183 */       } else if (this.type != null) {
/*      */ 
/*      */         
/*  186 */         str1 = "Type: name=\"" + this.type.getCVAttributesString() + " " + this.type.getName() + "\"; signature=\"" + this.type + "\"; class " + this.type.getClass().getName();
/*      */       } 
/*  188 */       String str2 = "OrigType=NULL_REF";
/*  189 */       if (this.origType != null)
/*      */       {
/*      */         
/*  192 */         str2 = "OrigType: name=\"" + this.origType.getCVAttributesString() + " " + this.origType.getName() + "\"; signature=\"" + this.origType + "\"; class " + this.origType.getClass().getName();
/*      */       }
/*  194 */       return "<[" + str1 + "] [" + str2 + "]  isTypedef=" + this.isTypedef + ">";
/*      */     }
/*      */   }
/*      */   
/*      */   private String getDebugTypeString(Type paramType) {
/*  199 */     if (this.debug) {
/*  200 */       return getTypeString(paramType);
/*      */     }
/*  202 */     return null;
/*      */   }
/*      */   
/*      */   private String getTypeString(Type paramType) {
/*  206 */     StringBuilder stringBuilder = new StringBuilder();
/*  207 */     stringBuilder.append("[");
/*  208 */     if (null != paramType) {
/*  209 */       stringBuilder.append(paramType.getDebugString());
/*  210 */       stringBuilder.append(", opaque ").append(isOpaque(paramType)).append("]");
/*      */     } else {
/*  212 */       stringBuilder.append("nil]");
/*      */     } 
/*  214 */     return stringBuilder.toString();
/*      */   }
/*      */   private boolean isOpaque(Type paramType) {
/*  217 */     return (this.cfg.typeInfo(paramType) != null);
/*      */   }
/*      */   
/*      */   private void debugPrintln(String paramString) {
/*  221 */     if (this.debug) {
/*  222 */       System.err.println(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */   private void debugPrint(String paramString) {
/*  227 */     if (this.debug) {
/*  228 */       System.err.print(paramString);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  235 */   private List<FunctionSymbol> functions = new ArrayList<>();
/*      */   
/*  237 */   private HashMap<String, EnumType> enumHash = new HashMap<>();
/*  238 */   private HashMap<String, EnumType> enumMap = new HashMap<>();
/*      */   
/*      */   private static final int AUTO = 1;
/*      */   
/*      */   private static final int REGISTER = 2;
/*      */   
/*      */   private static final int TYPEDEF = 4;
/*      */   
/*      */   private static final int EXTERN = 8;
/*      */   
/*      */   private static final int STATIC = 16;
/*      */   private static final int INLINE = 32;
/*      */   private static final int CONST = 64;
/*      */   private static final int VOLATILE = 128;
/*      */   private static final int SIGNED = 256;
/*      */   private static final int UNSIGNED = 512;
/*      */   private boolean isFuncDeclaration;
/*      */   private String funcDeclName;
/*      */   private List<ParameterDeclaration> funcDeclParams;
/*      */   private ASTLocusTag funcLocusTag;
/*      */   
/*      */   private void resetFuncDeclaration() {
/*  260 */     this.isFuncDeclaration = false;
/*  261 */     this.funcDeclName = null;
/*  262 */     this.funcDeclParams = null;
/*  263 */     this.funcLocusTag = null;
/*      */   }
/*      */   private void setFuncDeclaration(String paramString, List<ParameterDeclaration> paramList, ASTLocusTag paramASTLocusTag) {
/*  266 */     this.isFuncDeclaration = true;
/*  267 */     this.funcDeclName = paramString;
/*  268 */     this.funcDeclParams = paramList;
/*  269 */     this.funcLocusTag = paramASTLocusTag;
/*      */   }
/*      */   
/*      */   private void processDeclaration(Type paramType) {
/*  273 */     if (this.isFuncDeclaration) {
/*  274 */       FunctionSymbol functionSymbol = new FunctionSymbol(this.funcDeclName, new FunctionType(null, null, paramType, 0, this.funcLocusTag), this.funcLocusTag);
/*      */ 
/*      */       
/*  277 */       debugPrintln("Function ... " + functionSymbol.toString() + " @ " + this.funcLocusTag);
/*  278 */       if (this.funcDeclParams != null) {
/*  279 */         for (ParameterDeclaration parameterDeclaration : this.funcDeclParams) {
/*      */           
/*  281 */           parameterDeclaration.setType(parameterDeclaration.type());
/*  282 */           debugPrintln(" add " + parameterDeclaration.toString());
/*  283 */           functionSymbol.addArgument(parameterDeclaration.type(), parameterDeclaration.id());
/*      */         } 
/*      */       }
/*  286 */       debugPrintln("Function Added " + functionSymbol.toString());
/*  287 */       this.functions.add(functionSymbol);
/*  288 */       resetFuncDeclaration();
/*      */     } 
/*      */   }
/*      */   
/*      */   private int attrs2CVAttrs(int paramInt) {
/*  293 */     int i = 0;
/*  294 */     if ((paramInt & 0x40) != 0) {
/*  295 */       i |= 0x1;
/*      */     }
/*  297 */     if ((paramInt & 0x80) != 0) {
/*  298 */       i |= 0x2;
/*      */     }
/*  300 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleArrayExpr(TypeBox paramTypeBox, AST paramAST, ASTLocusTag paramASTLocusTag) {
/*  306 */     if (paramAST != null) {
/*      */       try {
/*  308 */         int i = parseIntConstExpr(paramAST);
/*  309 */         paramTypeBox.setType(canonicalize((Type)new ArrayType(paramTypeBox.type(), SizeThunk.mul(SizeThunk.constant(i), paramTypeBox.type().getSize()), i, 0, paramASTLocusTag)));
/*      */         return;
/*  311 */       } catch (RecognitionException recognitionException) {}
/*      */     }
/*      */ 
/*      */     
/*  315 */     paramTypeBox.setType(canonicalize((Type)new PointerType(SizeThunk.POINTER, paramTypeBox
/*  316 */             .type(), 0, paramASTLocusTag)));
/*      */   }
/*      */   
/*      */   private int parseIntConstExpr(AST paramAST) throws RecognitionException {
/*  320 */     return intConstExpr(paramAST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private EnumType getEnumType(String paramString, ASTLocusTag paramASTLocusTag) {
/*  326 */     EnumType enumType = null;
/*  327 */     Iterator<EnumType> iterator = this.enumHash.values().iterator();
/*  328 */     while (iterator.hasNext()) {
/*  329 */       EnumType enumType1 = iterator.next();
/*  330 */       if (enumType1.getName().equals(paramString)) {
/*  331 */         enumType = enumType1;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  336 */     if (enumType == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  342 */       enumType = new EnumType(paramString, SizeThunk.INT32, paramASTLocusTag);
/*      */     }
/*      */     
/*  345 */     return enumType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  352 */   private Map<Type, Type> canonMap = new HashMap<>();
/*      */   private Type canonicalize(Type paramType) {
/*  354 */     Type type = this.canonMap.get(paramType);
/*  355 */     if (type != null) {
/*  356 */       return type;
/*      */     }
/*  358 */     this.canonMap.put(paramType, paramType);
/*  359 */     return paramType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwGlueGenException(AST paramAST, String paramString) throws GlueGenException {
/*  365 */     throw new GlueGenException(paramString, findASTLocusTag(paramAST));
/*      */   }
/*      */   
/*      */   private void throwGlueGenException(ASTLocusTag paramASTLocusTag, String paramString) throws GlueGenException {
/*  369 */     throw new GlueGenException(paramString, paramASTLocusTag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ASTLocusTag findASTLocusTag(AST paramAST) {
/*  376 */     AST aST = paramAST;
/*  377 */     while (null != aST) {
/*  378 */       if (aST instanceof TNode) {
/*  379 */         TNode tNode = (TNode)aST;
/*  380 */         ASTLocusTag aSTLocusTag = tNode.getASTLocusTag();
/*  381 */         if (null != aSTLocusTag) {
/*  382 */           return aSTLocusTag;
/*      */         }
/*      */       } 
/*  385 */       aST = aST.getFirstChild();
/*      */     } 
/*  387 */     return null;
/*      */   }
/*      */   private void dumpASTTree(String paramString, AST paramAST) {
/*  390 */     byte b = 0;
/*  391 */     AST aST = paramAST;
/*  392 */     while (null != aST) {
/*  393 */       aST = dumpAST(paramString + "." + b, aST);
/*  394 */       b++;
/*      */     } 
/*      */   }
/*      */   private AST dumpAST(String paramString, AST paramAST) {
/*  398 */     if (null == paramAST) {
/*  399 */       System.err.println(paramString + ".0: AST NULL");
/*  400 */       return null;
/*      */     } 
/*  402 */     System.err.println(paramString + ".0: AST Type: " + paramAST.getClass().getName());
/*  403 */     System.err.println(paramString + ".1: line:col " + paramAST.getLine() + ":" + paramAST.getColumn() + " -> " + paramAST.getText());
/*  404 */     if (paramAST instanceof TNode) {
/*  405 */       TNode tNode = (TNode)paramAST;
/*  406 */       ASTLocusTag aSTLocusTag = tNode.getASTLocusTag();
/*  407 */       System.err.println(paramString + ".TN.1: " + aSTLocusTag);
/*  408 */       Hashtable<String, Object> hashtable = tNode.getAttributesTable();
/*  409 */       System.err.println(paramString + ".TN.2: " + hashtable);
/*      */     } 
/*  411 */     return paramAST.getFirstChild();
/*      */   }
/*      */   
/*      */   public HeaderParser() {
/*  415 */     this.tokenNames = _tokenNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String declarator(AST paramAST, TypeBox paramTypeBox) throws RecognitionException {
/*      */     AST aST;
/*  423 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  424 */     TNode tNode2 = null;
/*  425 */     TNode tNode3 = null;
/*      */     
/*  427 */     resetFuncDeclaration();
/*  428 */     String str1 = null;
/*  429 */     List<ParameterDeclaration> list = null;
/*  430 */     String str2 = null;
/*  431 */     TypeBox typeBox = null;
/*  432 */     ASTLocusTag aSTLocusTag = findASTLocusTag((AST)tNode1); try {
/*      */       ASTNULLType aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/*      */       TNode tNode5, tNode6;
/*  436 */       AST aST2 = paramAST;
/*  437 */       TNode tNode4 = (TNode)paramAST;
/*  438 */       match(paramAST, 115);
/*  439 */       paramAST = paramAST.getFirstChild();
/*      */       
/*  441 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/*  442 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 119:
/*  445 */           pointerGroup((AST)aSTNULLType2, paramTypeBox);
/*  446 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  456 */           throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  461 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/*  462 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 42:
/*  465 */           tNode2 = (TNode)aSTNULLType1;
/*  466 */           match((AST)aSTNULLType1, 42);
/*  467 */           aST = aSTNULLType1.getNextSibling();
/*  468 */           if (this.inputState.guessing == 0) {
/*  469 */             str1 = tNode2.getText();
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/*  475 */           tNode5 = (TNode)aST;
/*  476 */           match(aST, 47);
/*  477 */           aST = aST.getNextSibling();
/*  478 */           str2 = declarator(aST, typeBox);
/*  479 */           aST = this._retTree;
/*  480 */           tNode6 = (TNode)aST;
/*  481 */           match(aST, 48);
/*  482 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  487 */           throw new NoViableAltException(aST);
/*      */       }  while (true) {
/*      */         ASTNULLType aSTNULLType7; AST aST7; ASTNULLType aSTNULLType6; AST aST6; ASTNULLType aSTNULLType5; AST aST5; ASTNULLType aSTNULLType4; AST aST4; ASTNULLType aSTNULLType3;
/*      */         AST aST3;
/*      */         ASTNULLType aSTNULLType8;
/*      */         TNode tNode7;
/*      */         TNode tNode8;
/*  494 */         if (aST == null) aSTNULLType7 = ASTNULL; 
/*  495 */         switch (aSTNULLType7.getType()) {
/*      */           
/*      */           case 126:
/*  498 */             aSTNULLType8 = aSTNULLType7;
/*  499 */             tNode6 = (TNode)aSTNULLType7;
/*  500 */             match((AST)aSTNULLType7, 126);
/*  501 */             aST7 = aSTNULLType7.getFirstChild();
/*      */             
/*  503 */             if (aST7 == null) aSTNULLType6 = ASTNULL; 
/*  504 */             switch (aSTNULLType6.getType()) {
/*      */               
/*      */               case 129:
/*  507 */                 list = parameterTypeList((AST)aSTNULLType6);
/*  508 */                 aST6 = this._retTree;
/*      */                 break;
/*      */ 
/*      */ 
/*      */               
/*      */               case 42:
/*      */               case 48:
/*  515 */                 if (aST6 == null) aSTNULLType5 = ASTNULL; 
/*  516 */                 switch (aSTNULLType5.getType()) {
/*      */                   
/*      */                   case 42:
/*  519 */                     idList((AST)aSTNULLType5);
/*  520 */                     aST5 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */                 } 
/*      */ 
/*      */                 
/*  529 */                 throw new NoViableAltException(aST5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               default:
/*  537 */                 throw new NoViableAltException(aST5);
/*      */             } 
/*      */ 
/*      */             
/*  541 */             tNode8 = (TNode)aST5;
/*  542 */             match(aST5, 48);
/*  543 */             aST5 = aST5.getNextSibling();
/*  544 */             aSTNULLType4 = aSTNULLType8;
/*  545 */             aST4 = aSTNULLType4.getNextSibling();
/*  546 */             if (this.inputState.guessing == 0) {
/*      */               
/*  548 */               if (tNode2 != null) {
/*  549 */                 setFuncDeclaration(tNode2.getText(), list, aSTLocusTag); continue;
/*  550 */               }  if (str2 != null) {
/*      */                 
/*  552 */                 FunctionType functionType = new FunctionType(null, null, paramTypeBox.type(), 0, aSTLocusTag);
/*  553 */                 if (list == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  559 */                   functionType.addArgument((Type)new VoidType(0, aSTLocusTag), "/*unnamed-void*/");
/*      */                 } else {
/*  561 */                   for (ParameterDeclaration parameterDeclaration : list)
/*      */                   {
/*  563 */                     functionType.addArgument(parameterDeclaration.type(), parameterDeclaration.id());
/*      */                   }
/*      */                 } 
/*  566 */                 paramTypeBox.setType(canonicalize((Type)new PointerType(SizeThunk.POINTER, (Type)functionType, 0, aSTLocusTag)));
/*      */                 
/*  568 */                 str1 = str2;
/*      */               } 
/*      */             } 
/*      */             continue;
/*      */ 
/*      */ 
/*      */           
/*      */           case 49:
/*  576 */             tNode7 = (TNode)aST4;
/*  577 */             match(aST4, 49);
/*  578 */             aST4 = aST4.getNextSibling();
/*      */             
/*  580 */             if (aST4 == null) aSTNULLType3 = ASTNULL; 
/*  581 */             switch (aSTNULLType3.getType()) {
/*      */               
/*      */               case 42:
/*      */               case 45:
/*      */               case 46:
/*      */               case 47:
/*      */               case 64:
/*      */               case 65:
/*      */               case 66:
/*      */               case 67:
/*      */               case 68:
/*      */               case 69:
/*      */               case 70:
/*      */               case 71:
/*      */               case 72:
/*      */               case 73:
/*      */               case 74:
/*      */               case 75:
/*      */               case 76:
/*      */               case 77:
/*      */               case 78:
/*      */               case 79:
/*      */               case 80:
/*      */               case 81:
/*      */               case 82:
/*      */               case 83:
/*      */               case 84:
/*      */               case 85:
/*      */               case 86:
/*      */               case 87:
/*      */               case 88:
/*      */               case 89:
/*      */               case 90:
/*      */               case 91:
/*      */               case 92:
/*      */               case 93:
/*      */               case 94:
/*      */               case 99:
/*      */               case 118:
/*      */               case 120:
/*      */               case 123:
/*      */               case 125:
/*      */               case 130:
/*      */               case 131:
/*      */               case 133:
/*      */               case 134:
/*      */               case 135:
/*      */               case 137:
/*      */               case 139:
/*      */               case 158:
/*      */               case 164:
/*  632 */                 tNode3 = (aSTNULLType3 == ASTNULL) ? null : (TNode)aSTNULLType3;
/*  633 */                 expr((AST)aSTNULLType3);
/*  634 */                 aST3 = this._retTree;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 50:
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/*  643 */                 throw new NoViableAltException(aST3);
/*      */             } 
/*      */ 
/*      */             
/*  647 */             tNode6 = (TNode)aST3;
/*  648 */             match(aST3, 50);
/*  649 */             aST3 = aST3.getNextSibling();
/*  650 */             if (this.inputState.guessing == 0) {
/*  651 */               handleArrayExpr(paramTypeBox, (AST)tNode3, aSTLocusTag);
/*      */             }
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  662 */       aST = aST2;
/*  663 */       aST = aST.getNextSibling();
/*      */     }
/*  665 */     catch (RecognitionException recognitionException) {
/*  666 */       if (this.inputState.guessing == 0) {
/*  667 */         reportError(recognitionException);
/*  668 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  670 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  673 */     this._retTree = aST;
/*  674 */     return str1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void pointerGroup(AST paramAST, TypeBox paramTypeBox) throws RecognitionException {
/*  681 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  682 */     int i = 0, j = 0;
/*      */     
/*      */     try {
/*  685 */       AST aST = paramAST;
/*  686 */       TNode tNode1 = (TNode)paramAST;
/*  687 */       match(paramAST, 119);
/*  688 */       paramAST = paramAST.getFirstChild();
/*      */       
/*  690 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/*  693 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  694 */         if (aSTNULLType.getType() == 46) {
/*  695 */           TNode tNode2 = (TNode)aSTNULLType;
/*  696 */           match((AST)aSTNULLType, 46);
/*  697 */           aST1 = aSTNULLType.getNextSibling();
/*  698 */           if (this.inputState.guessing == 0) {
/*  699 */             i = 0; j = 0;
/*      */           } 
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType1;
/*  704 */             if (aST1 == null) aSTNULLType1 = ASTNULL; 
/*  705 */             if (_tokenSet_0.member(aSTNULLType1.getType())) {
/*  706 */               j = typeQualifier((AST)aSTNULLType1);
/*  707 */               aST1 = this._retTree;
/*  708 */               if (this.inputState.guessing == 0) {
/*  709 */                 i |= j;
/*      */               }
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*  718 */           if (this.inputState.guessing == 0)
/*      */           {
/*  720 */             debugPrintln("IN PTR GROUP: TB=" + paramTypeBox);
/*  721 */             if (paramTypeBox != null) {
/*  722 */               paramTypeBox.setType(canonicalize((Type)new PointerType(SizeThunk.POINTER, paramTypeBox
/*  723 */                       .type(), 
/*  724 */                       attrs2CVAttrs(i), 
/*  725 */                       findASTLocusTag((AST)tNode))));
/*      */             }
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  731 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/*  734 */         b++;
/*      */       } 
/*      */       
/*  737 */       paramAST = aST;
/*  738 */       paramAST = paramAST.getNextSibling();
/*      */     }
/*  740 */     catch (RecognitionException recognitionException) {
/*  741 */       if (this.inputState.guessing == 0) {
/*  742 */         reportError(recognitionException);
/*  743 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/*  745 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  748 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final List<ParameterDeclaration> parameterTypeList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  754 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  755 */     ArrayList<ParameterDeclaration> arrayList = new ArrayList(); ParameterDeclaration parameterDeclaration = null; 
/*      */     try { AST aST1;
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/*  759 */       byte b = 0;
/*      */       
/*      */       while (true) {
/*  762 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  763 */         if (aSTNULLType.getType() == 129) {
/*  764 */           ASTNULLType aSTNULLType1; TNode tNode2; parameterDeclaration = parameterDeclaration((AST)aSTNULLType);
/*  765 */           AST aST2 = this._retTree;
/*  766 */           if (this.inputState.guessing == 0 && 
/*  767 */             parameterDeclaration != null) arrayList.add(parameterDeclaration);
/*      */ 
/*      */           
/*  770 */           if (aST2 == null) aSTNULLType1 = ASTNULL; 
/*  771 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 43:
/*  774 */               tNode2 = (TNode)aSTNULLType1;
/*  775 */               match((AST)aSTNULLType1, 43);
/*  776 */               aST1 = aSTNULLType1.getNextSibling();
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/*  781 */               tNode2 = (TNode)aST1;
/*  782 */               match(aST1, 9);
/*  783 */               aST1 = aST1.getNextSibling();
/*      */               break;
/*      */ 
/*      */             
/*      */             case 48:
/*      */             case 51:
/*      */             case 129:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/*  794 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*      */         } else {
/*  800 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/*  803 */         b++;
/*      */       } 
/*      */ 
/*      */       
/*  807 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/*  808 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 51:
/*  811 */           tNode1 = (TNode)aSTNULLType;
/*  812 */           match((AST)aSTNULLType, 51);
/*  813 */           aST = aSTNULLType.getNextSibling();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 48:
/*  835 */           this._retTree = aST;
/*  836 */           return arrayList;
/*      */       }  throw new NoViableAltException(aST); }
/*      */     catch (RecognitionException recognitionException) { if (this.inputState.guessing == 0) { reportError(recognitionException); if (aST != null)
/*      */           aST = aST.getNextSibling();  }
/*      */        throw recognitionException; }
/*  841 */      } public final void idList(AST paramAST) throws RecognitionException { AST aST; TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/*  844 */       TNode tNode1 = (TNode)paramAST;
/*  845 */       match(paramAST, 42);
/*  846 */       paramAST = paramAST.getNextSibling();
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*  850 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  851 */         if (aSTNULLType.getType() == 43) {
/*  852 */           TNode tNode2 = (TNode)aSTNULLType;
/*  853 */           match((AST)aSTNULLType, 43);
/*  854 */           aST = aSTNULLType.getNextSibling();
/*  855 */           TNode tNode3 = (TNode)aST;
/*  856 */           match(aST, 42);
/*  857 */           aST = aST.getNextSibling();
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  866 */     } catch (RecognitionException recognitionException) {
/*  867 */       if (this.inputState.guessing == 0) {
/*  868 */         reportError(recognitionException);
/*  869 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  871 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  874 */     this._retTree = aST; }
/*      */ 
/*      */   
/*      */   public final void expr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  879 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  882 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  883 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*  896 */           assignExpr((AST)aSTNULLType);
/*  897 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 74:
/*  902 */           conditionalExpr(aST);
/*  903 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 75:
/*  908 */           logicalOrExpr(aST);
/*  909 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 76:
/*  914 */           logicalAndExpr(aST);
/*  915 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 77:
/*  920 */           inclusiveOrExpr(aST);
/*  921 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 78:
/*  926 */           exclusiveOrExpr(aST);
/*  927 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 79:
/*  932 */           bitAndExpr(aST);
/*  933 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 80:
/*      */         case 81:
/*  939 */           equalityExpr(aST);
/*  940 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*  948 */           relationalExpr(aST);
/*  949 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 86:
/*      */         case 87:
/*  955 */           shiftExpr(aST);
/*  956 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 88:
/*      */         case 89:
/*  962 */           additiveExpr(aST);
/*  963 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/*      */         case 90:
/*      */         case 91:
/*  970 */           multExpr(aST);
/*  971 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 118:
/*  976 */           castExpr(aST);
/*  977 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 131:
/*      */         case 164:
/*  986 */           unaryExpr(aST);
/*  987 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 133:
/*  992 */           postfixExpr(aST);
/*  993 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 99:
/*      */         case 120:
/*      */         case 135:
/*      */         case 158:
/* 1002 */           primaryExpr(aST);
/* 1003 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 130:
/* 1008 */           commaExpr(aST);
/* 1009 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 125:
/* 1014 */           emptyExpr(aST);
/* 1015 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/* 1020 */           compoundStatementExpr(aST);
/* 1021 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 123:
/*      */         case 137:
/* 1027 */           initializer(aST);
/* 1028 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 134:
/* 1033 */           rangeExpr(aST);
/* 1034 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 139:
/* 1039 */           gnuAsmExpr(aST);
/* 1040 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1045 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1049 */     } catch (RecognitionException recognitionException) {
/* 1050 */       if (this.inputState.guessing == 0) {
/* 1051 */         reportError(recognitionException);
/* 1052 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1054 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1057 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typelessDeclaration(AST paramAST) throws RecognitionException {
/* 1062 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 1064 */     TypeBox typeBox = null;
/*      */ 
/*      */     
/*      */     try {
/* 1068 */       AST aST = paramAST;
/* 1069 */       TNode tNode1 = (TNode)paramAST;
/* 1070 */       match(paramAST, 140);
/* 1071 */       paramAST = paramAST.getFirstChild();
/* 1072 */       initDeclList(paramAST, typeBox);
/* 1073 */       paramAST = this._retTree;
/* 1074 */       TNode tNode2 = (TNode)paramAST;
/* 1075 */       match(paramAST, 9);
/* 1076 */       paramAST = paramAST.getNextSibling();
/* 1077 */       paramAST = aST;
/* 1078 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 1080 */     catch (RecognitionException recognitionException) {
/* 1081 */       if (this.inputState.guessing == 0) {
/* 1082 */         reportError(recognitionException);
/* 1083 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1085 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1088 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void initDeclList(AST paramAST, TypeBox paramTypeBox) throws RecognitionException {
/*      */     AST aST;
/* 1095 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 1099 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1102 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1103 */         if (aSTNULLType.getType() == 114) {
/* 1104 */           initDecl((AST)aSTNULLType, paramTypeBox);
/* 1105 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 1108 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 1111 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 1115 */     catch (RecognitionException recognitionException) {
/* 1116 */       if (this.inputState.guessing == 0) {
/* 1117 */         reportError(recognitionException);
/* 1118 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1120 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1123 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declaration(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1128 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 1130 */     TypeBox typeBox = null;
/*      */     
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1134 */       AST aST1 = paramAST;
/* 1135 */       TNode tNode1 = (TNode)paramAST;
/* 1136 */       match(paramAST, 117);
/* 1137 */       paramAST = paramAST.getFirstChild();
/* 1138 */       typeBox = declSpecifiers(paramAST);
/* 1139 */       paramAST = this._retTree;
/*      */       
/* 1141 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1142 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 114:
/* 1145 */           initDeclList((AST)aSTNULLType, typeBox);
/* 1146 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1155 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1160 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType1;
/*      */         AST aST2;
/* 1163 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/* 1164 */         if (aSTNULLType1.getType() == 9) {
/* 1165 */           TNode tNode2 = (TNode)aSTNULLType1;
/* 1166 */           match((AST)aSTNULLType1, 9);
/* 1167 */           aST2 = aSTNULLType1.getNextSibling();
/*      */         } else {
/*      */           
/* 1170 */           if (b >= 1) break;  throw new NoViableAltException(aST2);
/*      */         } 
/*      */         
/* 1173 */         b++;
/*      */       } 
/*      */       
/* 1176 */       aST = aST1;
/* 1177 */       aST = aST.getNextSibling();
/* 1178 */       if (this.inputState.guessing == 0) {
/* 1179 */         processDeclaration(typeBox.type());
/*      */       }
/*      */     }
/* 1182 */     catch (RecognitionException recognitionException) {
/* 1183 */       if (this.inputState.guessing == 0) {
/* 1184 */         reportError(recognitionException);
/* 1185 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1187 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1190 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final TypeBox declSpecifiers(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1196 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 1198 */     TypeBox typeBox = null;
/* 1199 */     Type type = null;
/* 1200 */     int i = 0;
/* 1201 */     int j = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1206 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1209 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1210 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 4:
/*      */           case 13:
/*      */           case 14:
/*      */           case 15:
/*      */           case 16:
/*      */           case 160:
/* 1218 */             j = storageClassSpecifier((AST)aSTNULLType);
/* 1219 */             aST = this._retTree;
/* 1220 */             if (this.inputState.guessing == 0) {
/* 1221 */               i |= j;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/*      */           case 25:
/*      */           case 26:
/* 1230 */             j = typeQualifier(aST);
/* 1231 */             aST = this._retTree;
/* 1232 */             if (this.inputState.guessing == 0) {
/* 1233 */               i |= j;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 1266 */             type = typeSpecifier(aST, i);
/* 1267 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1272 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 1275 */         b++;
/*      */       } 
/*      */       
/* 1278 */       if (this.inputState.guessing == 0) {
/*      */         IntType intType;
/* 1280 */         if (type == null && (i & 0x300) != 0)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1285 */           intType = new IntType("int", SizeThunk.INTxx, ((i & 0x200) != 0), attrs2CVAttrs(i), findASTLocusTag((AST)tNode));
/*      */         }
/* 1287 */         typeBox = new TypeBox((Type)intType, ((i & 0x4) != 0));
/*      */       }
/*      */     
/*      */     }
/* 1291 */     catch (RecognitionException recognitionException) {
/* 1292 */       if (this.inputState.guessing == 0) {
/* 1293 */         reportError(recognitionException);
/* 1294 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1296 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1299 */     this._retTree = aST;
/* 1300 */     return typeBox;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ParameterDeclaration parameterDeclaration(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1306 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 1308 */     Object object = null;
/* 1309 */     String str = null;
/* 1310 */     ParameterDeclaration parameterDeclaration = null;
/* 1311 */     TypeBox typeBox = null;
/*      */     
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1315 */       AST aST1 = paramAST;
/* 1316 */       TNode tNode1 = (TNode)paramAST;
/* 1317 */       match(paramAST, 129);
/* 1318 */       paramAST = paramAST.getFirstChild();
/* 1319 */       typeBox = declSpecifiers(paramAST);
/* 1320 */       paramAST = this._retTree;
/*      */       
/* 1322 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1323 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 115:
/* 1326 */           str = declarator((AST)aSTNULLType, typeBox);
/* 1327 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 122:
/* 1332 */           nonemptyAbstractDeclarator(aST, typeBox);
/* 1333 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1342 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 1346 */       aST = aST1;
/* 1347 */       aST = aST.getNextSibling();
/* 1348 */       if (this.inputState.guessing == 0)
/*      */       {
/* 1350 */         if (null == typeBox) {
/* 1351 */           throwGlueGenException((AST)tNode, 
/* 1352 */               String.format("Undefined type for declaration '%s'", new Object[] { str }));
/*      */         }
/* 1354 */         parameterDeclaration = new ParameterDeclaration(str, typeBox.type());
/*      */       }
/*      */     
/*      */     }
/* 1358 */     catch (RecognitionException recognitionException) {
/* 1359 */       if (this.inputState.guessing == 0) {
/* 1360 */         reportError(recognitionException);
/* 1361 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1363 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1366 */     this._retTree = aST;
/* 1367 */     return parameterDeclaration;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void nonemptyAbstractDeclarator(AST paramAST, TypeBox paramTypeBox) throws RecognitionException {
/*      */     AST aST;
/* 1374 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1375 */     TNode tNode2 = null;
/* 1376 */     TNode tNode3 = null;
/*      */     
/* 1378 */     ASTLocusTag aSTLocusTag = findASTLocusTag((AST)tNode1);
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*      */       byte b;
/* 1382 */       AST aST1 = paramAST;
/* 1383 */       TNode tNode = (TNode)paramAST;
/* 1384 */       match(paramAST, 122);
/* 1385 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 1387 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1388 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 119:
/* 1391 */           pointerGroup((AST)aSTNULLType, paramTypeBox);
/* 1392 */           aST = this._retTree; while (true) {
/*      */             ASTNULLType aSTNULLType3; AST aST3; ASTNULLType aSTNULLType2; AST aST2; ASTNULLType aSTNULLType1;
/*      */             TNode tNode4;
/*      */             TNode tNode5;
/* 1396 */             if (aST == null) aSTNULLType3 = ASTNULL; 
/* 1397 */             switch (aSTNULLType3.getType()) {
/*      */ 
/*      */               
/*      */               case 47:
/* 1401 */                 tNode4 = (TNode)aSTNULLType3;
/* 1402 */                 match((AST)aSTNULLType3, 47);
/* 1403 */                 aST3 = aSTNULLType3.getNextSibling();
/*      */                 
/* 1405 */                 if (aST3 == null) aSTNULLType2 = ASTNULL; 
/* 1406 */                 switch (aSTNULLType2.getType()) {
/*      */                   
/*      */                   case 122:
/* 1409 */                     nonemptyAbstractDeclarator((AST)aSTNULLType2, paramTypeBox);
/* 1410 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 129:
/* 1415 */                     parameterTypeList(aST2);
/* 1416 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 1425 */                     throw new NoViableAltException(aST2);
/*      */                 } 
/*      */ 
/*      */                 
/* 1429 */                 tNode5 = (TNode)aST2;
/* 1430 */                 match(aST2, 48);
/* 1431 */                 aST2 = aST2.getNextSibling();
/*      */                 continue;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 1438 */                 tNode4 = (TNode)aST2;
/* 1439 */                 match(aST2, 49);
/* 1440 */                 aST2 = aST2.getNextSibling();
/*      */                 
/* 1442 */                 if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 1443 */                 switch (aSTNULLType1.getType()) {
/*      */                   
/*      */                   case 42:
/*      */                   case 45:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 64:
/*      */                   case 65:
/*      */                   case 66:
/*      */                   case 67:
/*      */                   case 68:
/*      */                   case 69:
/*      */                   case 70:
/*      */                   case 71:
/*      */                   case 72:
/*      */                   case 73:
/*      */                   case 74:
/*      */                   case 75:
/*      */                   case 76:
/*      */                   case 77:
/*      */                   case 78:
/*      */                   case 79:
/*      */                   case 80:
/*      */                   case 81:
/*      */                   case 82:
/*      */                   case 83:
/*      */                   case 84:
/*      */                   case 85:
/*      */                   case 86:
/*      */                   case 87:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 90:
/*      */                   case 91:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 99:
/*      */                   case 118:
/*      */                   case 120:
/*      */                   case 123:
/*      */                   case 125:
/*      */                   case 130:
/*      */                   case 131:
/*      */                   case 133:
/*      */                   case 134:
/*      */                   case 135:
/*      */                   case 137:
/*      */                   case 139:
/*      */                   case 158:
/*      */                   case 164:
/* 1494 */                     tNode2 = (aSTNULLType1 == ASTNULL) ? null : (TNode)aSTNULLType1;
/* 1495 */                     expr((AST)aSTNULLType1);
/* 1496 */                     aST = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 1505 */                     throw new NoViableAltException(aST);
/*      */                 } 
/*      */ 
/*      */                 
/* 1509 */                 tNode5 = (TNode)aST;
/* 1510 */                 match(aST, 50);
/* 1511 */                 aST = aST.getNextSibling();
/*      */                 
/* 1513 */                 if (this.inputState.guessing == 0) {
/* 1514 */                   handleArrayExpr(paramTypeBox, (AST)tNode2, aSTLocusTag);
/*      */                 }
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 47:
/*      */         case 49:
/* 1531 */           b = 0; while (true) {
/*      */             ASTNULLType aSTNULLType3; AST aST3; ASTNULLType aSTNULLType2; AST aST2; ASTNULLType aSTNULLType1;
/*      */             TNode tNode4, tNode5;
/* 1534 */             if (aST == null) aSTNULLType3 = ASTNULL; 
/* 1535 */             switch (aSTNULLType3.getType()) {
/*      */ 
/*      */               
/*      */               case 47:
/* 1539 */                 tNode4 = (TNode)aSTNULLType3;
/* 1540 */                 match((AST)aSTNULLType3, 47);
/* 1541 */                 aST3 = aSTNULLType3.getNextSibling();
/*      */                 
/* 1543 */                 if (aST3 == null) aSTNULLType2 = ASTNULL; 
/* 1544 */                 switch (aSTNULLType2.getType()) {
/*      */                   
/*      */                   case 122:
/* 1547 */                     nonemptyAbstractDeclarator((AST)aSTNULLType2, paramTypeBox);
/* 1548 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 129:
/* 1553 */                     parameterTypeList(aST2);
/* 1554 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 1563 */                     throw new NoViableAltException(aST2);
/*      */                 } 
/*      */ 
/*      */                 
/* 1567 */                 tNode5 = (TNode)aST2;
/* 1568 */                 match(aST2, 48);
/* 1569 */                 aST2 = aST2.getNextSibling();
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 1576 */                 tNode4 = (TNode)aST2;
/* 1577 */                 match(aST2, 49);
/* 1578 */                 aST2 = aST2.getNextSibling();
/*      */                 
/* 1580 */                 if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 1581 */                 switch (aSTNULLType1.getType()) {
/*      */                   
/*      */                   case 42:
/*      */                   case 45:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 64:
/*      */                   case 65:
/*      */                   case 66:
/*      */                   case 67:
/*      */                   case 68:
/*      */                   case 69:
/*      */                   case 70:
/*      */                   case 71:
/*      */                   case 72:
/*      */                   case 73:
/*      */                   case 74:
/*      */                   case 75:
/*      */                   case 76:
/*      */                   case 77:
/*      */                   case 78:
/*      */                   case 79:
/*      */                   case 80:
/*      */                   case 81:
/*      */                   case 82:
/*      */                   case 83:
/*      */                   case 84:
/*      */                   case 85:
/*      */                   case 86:
/*      */                   case 87:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 90:
/*      */                   case 91:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 99:
/*      */                   case 118:
/*      */                   case 120:
/*      */                   case 123:
/*      */                   case 125:
/*      */                   case 130:
/*      */                   case 131:
/*      */                   case 133:
/*      */                   case 134:
/*      */                   case 135:
/*      */                   case 137:
/*      */                   case 139:
/*      */                   case 158:
/*      */                   case 164:
/* 1632 */                     tNode3 = (aSTNULLType1 == ASTNULL) ? null : (TNode)aSTNULLType1;
/* 1633 */                     expr((AST)aSTNULLType1);
/* 1634 */                     aST = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 1643 */                     throw new NoViableAltException(aST);
/*      */                 } 
/*      */ 
/*      */                 
/* 1647 */                 tNode5 = (TNode)aST;
/* 1648 */                 match(aST, 50);
/* 1649 */                 aST = aST.getNextSibling();
/*      */                 
/* 1651 */                 if (this.inputState.guessing == 0) {
/* 1652 */                   handleArrayExpr(paramTypeBox, (AST)tNode3, aSTLocusTag);
/*      */                 }
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1658 */                 if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */             } 
/*      */             
/* 1661 */             b++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1668 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 1672 */       aST = aST1;
/* 1673 */       aST = aST.getNextSibling();
/*      */     }
/* 1675 */     catch (RecognitionException recognitionException) {
/* 1676 */       if (this.inputState.guessing == 0) {
/* 1677 */         reportError(recognitionException);
/* 1678 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1680 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1683 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void functionDef(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1688 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 1690 */     TypeBox typeBox = null;
/*      */     
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1694 */       AST aST1 = paramAST;
/* 1695 */       TNode tNode1 = (TNode)paramAST;
/* 1696 */       match(paramAST, 127);
/* 1697 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 1699 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1700 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 6:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/*      */         case 18:
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 113:
/*      */         case 160:
/*      */         case 161:
/*      */         case 162:
/* 1737 */           functionDeclSpecifiers((AST)aSTNULLType);
/* 1738 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 115:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1747 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 1751 */       declarator(aST, typeBox);
/* 1752 */       aST = this._retTree;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType1;
/*      */         TNode tNode2;
/* 1756 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/* 1757 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 117:
/* 1760 */             declaration((AST)aSTNULLType1);
/* 1761 */             aST = this._retTree;
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 51:
/* 1766 */             tNode2 = (TNode)aST;
/* 1767 */             match(aST, 51);
/* 1768 */             aST = aST.getNextSibling();
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1778 */       compoundStatement(aST);
/* 1779 */       aST = this._retTree;
/* 1780 */       aST = aST1;
/* 1781 */       aST = aST.getNextSibling();
/*      */     }
/* 1783 */     catch (RecognitionException recognitionException) {
/* 1784 */       if (this.inputState.guessing == 0) {
/* 1785 */         reportError(recognitionException);
/* 1786 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1788 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1791 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void functionDeclSpecifiers(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1796 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 1800 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1803 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1804 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 15:
/*      */           case 16:
/*      */           case 160:
/* 1809 */             functionStorageClassSpecifier((AST)aSTNULLType);
/* 1810 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/*      */           case 25:
/*      */           case 26:
/* 1818 */             typeQualifier(aST);
/* 1819 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 1851 */             typeSpecifier(aST, 0);
/* 1852 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1857 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 1860 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 1864 */     catch (RecognitionException recognitionException) {
/* 1865 */       if (this.inputState.guessing == 0) {
/* 1866 */         reportError(recognitionException);
/* 1867 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1869 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1872 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void compoundStatement(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1877 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       AST aST1;
/*      */       ASTNULLType aSTNULLType;
/* 1880 */       AST aST2 = paramAST;
/* 1881 */       TNode tNode1 = (TNode)paramAST;
/* 1882 */       match(paramAST, 128);
/* 1883 */       paramAST = paramAST.getFirstChild();
/*      */ 
/*      */       
/*      */       while (true) {
/* 1887 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1888 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 117:
/*      */           case 159:
/* 1892 */             declarationList((AST)aSTNULLType);
/* 1893 */             aST1 = this._retTree;
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 127:
/* 1898 */             functionDef(aST1);
/* 1899 */             aST1 = this._retTree;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1910 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/* 1911 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 9:
/*      */         case 52:
/*      */         case 53:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 63:
/*      */         case 124:
/*      */         case 128:
/*      */         case 132:
/* 1928 */           statementList((AST)aSTNULLType);
/* 1929 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1938 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 1942 */       TNode tNode2 = (TNode)aST;
/* 1943 */       match(aST, 8);
/* 1944 */       aST = aST.getNextSibling();
/* 1945 */       aST = aST2;
/* 1946 */       aST = aST.getNextSibling();
/*      */     }
/* 1948 */     catch (RecognitionException recognitionException) {
/* 1949 */       if (this.inputState.guessing == 0) {
/* 1950 */         reportError(recognitionException);
/* 1951 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1953 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1956 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int storageClassSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1962 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1963 */     int i = 0; 
/*      */     try { ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 1966 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1967 */       switch (aSTNULLType.getType())
/*      */       
/*      */       { case 13:
/* 1970 */           tNode1 = (TNode)aSTNULLType;
/* 1971 */           match((AST)aSTNULLType, 13);
/* 1972 */           aST = aSTNULLType.getNextSibling();
/* 1973 */           if (this.inputState.guessing == 0) {
/* 1974 */             i |= 0x1;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2020 */           this._retTree = aST;
/* 2021 */           return i;case 14: tNode1 = (TNode)aST; match(aST, 14); aST = aST.getNextSibling(); if (this.inputState.guessing == 0) i |= 0x2;  this._retTree = aST; return i;case 4: tNode1 = (TNode)aST; match(aST, 4); aST = aST.getNextSibling(); if (this.inputState.guessing == 0) i |= 0x4;  this._retTree = aST; return i;case 15: case 16: case 160: i = functionStorageClassSpecifier(aST); aST = this._retTree; this._retTree = aST; return i; }  throw new NoViableAltException(aST); } catch (RecognitionException recognitionException) { if (this.inputState.guessing == 0) { reportError(recognitionException); if (aST != null) aST = aST.getNextSibling();  } else { throw recognitionException; }  }  this._retTree = aST; return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int typeQualifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2027 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2028 */     int i = 0; 
/*      */     try { ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 2031 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2032 */       switch (aSTNULLType.getType())
/*      */       
/*      */       { case 17:
/* 2035 */           tNode1 = (TNode)aSTNULLType;
/* 2036 */           match((AST)aSTNULLType, 17);
/* 2037 */           aST = aSTNULLType.getNextSibling();
/* 2038 */           if (this.inputState.guessing == 0) {
/* 2039 */             i |= 0x40;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2087 */           this._retTree = aST;
/* 2088 */           return i;case 6: tNode1 = (TNode)aST; match(aST, 6); aST = aST.getNextSibling(); if (this.inputState.guessing == 0) i |= 0x80;  this._retTree = aST; return i;case 25: tNode1 = (TNode)aST; match(aST, 25); aST = aST.getNextSibling(); if (this.inputState.guessing == 0) i |= 0x100;  this._retTree = aST; return i;case 26: tNode1 = (TNode)aST; match(aST, 26); aST = aST.getNextSibling(); if (this.inputState.guessing == 0) i |= 0x200;  this._retTree = aST; return i; }  throw new NoViableAltException(aST); } catch (RecognitionException recognitionException) { if (this.inputState.guessing == 0) { reportError(recognitionException); if (aST != null) aST = aST.getNextSibling();  } else { throw recognitionException; }  }  this._retTree = aST; return i;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Type typeSpecifier(AST paramAST, int paramInt) throws RecognitionException {
/*      */     AST aST;
/*      */     Type type;
/* 2096 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 2098 */     VoidType voidType = null;
/* 2099 */     int i = attrs2CVAttrs(paramInt);
/* 2100 */     boolean bool = ((paramInt & 0x200) != 0) ? true : false;
/* 2101 */     ASTLocusTag aSTLocusTag = findASTLocusTag((AST)tNode); 
/*      */     try { ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; IntType intType2; FloatType floatType; DoubleType doubleType; IntType intType1; TNode tNode2; AST aST2; TNode tNode1; TNode tNode3;
/*      */       TNode tNode4;
/*      */       TNode tNode5;
/* 2105 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 2106 */       switch (aSTNULLType2.getType())
/*      */       
/*      */       { case 18:
/* 2109 */           tNode2 = (TNode)aSTNULLType2;
/* 2110 */           match((AST)aSTNULLType2, 18);
/* 2111 */           aST1 = aSTNULLType2.getNextSibling();
/* 2112 */           if (this.inputState.guessing == 0) {
/* 2113 */             voidType = new VoidType(i, aSTLocusTag);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2516 */           this._retTree = aST1;
/* 2517 */           return (Type)voidType;case 19: tNode2 = (TNode)aST1; match(aST1, 19); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType2 = new IntType("char", SizeThunk.INT8, bool, i, false, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType2;case 20: tNode2 = (TNode)aST1; match(aST1, 20); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType2 = new IntType("short", SizeThunk.INT16, bool, i, false, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType2;case 21: tNode2 = (TNode)aST1; match(aST1, 21); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType2 = new IntType("int", SizeThunk.INTxx, bool, i, false, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType2;case 22: tNode2 = (TNode)aST1; match(aST1, 22); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType2 = new IntType("long", SizeThunk.LONG, bool, i, false, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType2;case 23: tNode2 = (TNode)aST1; match(aST1, 23); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) floatType = new FloatType("float", SizeThunk.FLOAT, i, aSTLocusTag);  this._retTree = aST1; return (Type)floatType;case 24: tNode2 = (TNode)aST1; match(aST1, 24); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) doubleType = new DoubleType("double", SizeThunk.DOUBLE, i, aSTLocusTag);  this._retTree = aST1; return (Type)doubleType;case 31: tNode2 = (TNode)aST1; match(aST1, 31); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("__int32", SizeThunk.INT32, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 35: tNode2 = (TNode)aST1; match(aST1, 35); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("__int64", SizeThunk.INT64, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 27: tNode2 = (TNode)aST1; match(aST1, 27); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("int8_t", SizeThunk.INT8, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 28: tNode2 = (TNode)aST1; match(aST1, 28); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("uint8_t", SizeThunk.INT8, bool, i, true, true, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 29: tNode2 = (TNode)aST1; match(aST1, 29); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("int16_t", SizeThunk.INT16, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 30: tNode2 = (TNode)aST1; match(aST1, 30); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("uint16_t", SizeThunk.INT16, bool, i, true, true, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 32: tNode2 = (TNode)aST1; match(aST1, 32); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("int32_t", SizeThunk.INT32, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 33: tNode2 = (TNode)aST1; match(aST1, 33); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("wchar_t", SizeThunk.INT32, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 34: tNode2 = (TNode)aST1; match(aST1, 34); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("uint32_t", SizeThunk.INT32, bool, i, true, true, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 36: tNode2 = (TNode)aST1; match(aST1, 36); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("int64_t", SizeThunk.INT64, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 37: tNode2 = (TNode)aST1; match(aST1, 37); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("uint64_t", SizeThunk.INT64, bool, i, true, true, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 38: tNode2 = (TNode)aST1; match(aST1, 38); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("ptrdiff_t", SizeThunk.POINTER, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 39: tNode2 = (TNode)aST1; match(aST1, 39); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("intptr_t", SizeThunk.POINTER, bool, i, true, false, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 40: tNode2 = (TNode)aST1; match(aST1, 40); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("size_t", SizeThunk.POINTER, bool, i, true, true, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 41: tNode2 = (TNode)aST1; match(aST1, 41); aST1 = aST1.getNextSibling(); if (this.inputState.guessing == 0) intType1 = new IntType("uintptr_t", SizeThunk.POINTER, bool, i, true, true, aSTLocusTag);  this._retTree = aST1; return (Type)intType1;case 10: type = structSpecifier(aST1, i); aST1 = this._retTree; while (true) { if (aST1 == null) aSTNULLType1 = ASTNULL;  if (aSTNULLType1.getType() == 138 || aSTNULLType1.getType() == 163) { attributeDecl((AST)aSTNULLType1); aST1 = this._retTree; continue; }  break; }  this._retTree = aST1; return type;case 11: type = unionSpecifier(aST1, i); aST1 = this._retTree; while (true) { if (aST1 == null) aSTNULLType1 = ASTNULL;  if (aSTNULLType1.getType() == 138 || aSTNULLType1.getType() == 163) { attributeDecl((AST)aSTNULLType1); aST1 = this._retTree; continue; }  break; }  this._retTree = aST1; return type;case 12: type = enumSpecifier(aST1, i); aST1 = this._retTree; this._retTree = aST1; return type;case 113: type = typedefName(aST1, i); aST1 = this._retTree; this._retTree = aST1; return type;case 161: aST2 = aST1; tNode3 = (TNode)aST1; match(aST1, 161); aST1 = aST1.getFirstChild(); tNode4 = (TNode)aST1; match(aST1, 47); aST1 = aST1.getNextSibling(); if (aST1 == null) aSTNULLType1 = ASTNULL;  switch (aSTNULLType1.getType()) { case 6: case 10: case 11: case 12: case 17: case 18: case 19: case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 113: case 161: case 162: typeName((AST)aSTNULLType1); aST = this._retTree; break;case 42: case 45: case 46: case 47: case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 78: case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 87: case 88: case 89: case 90: case 91: case 92: case 93: case 94: case 99: case 118: case 120: case 123: case 125: case 130: case 131: case 133: case 134: case 135: case 137: case 139: case 158: case 164: expr(aST); aST = this._retTree; break;default: throw new NoViableAltException(aST); }  tNode5 = (TNode)aST; match(aST, 48); aST = aST.getNextSibling(); aST = aST2; aST = aST.getNextSibling(); this._retTree = aST; return type;case 162: tNode1 = (TNode)aST; match(aST, 162); aST = aST.getNextSibling(); this._retTree = aST; return type; }  throw new NoViableAltException(aST); } catch (RecognitionException recognitionException) { if (this.inputState.guessing == 0) { reportError(recognitionException); if (aST != null) aST = aST.getNextSibling();  } else { throw recognitionException; }  }  this._retTree = aST; return type;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int functionStorageClassSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2523 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2524 */     int i = 0; 
/*      */     try { ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 2527 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2528 */       switch (aSTNULLType.getType())
/*      */       
/*      */       { case 15:
/* 2531 */           tNode1 = (TNode)aSTNULLType;
/* 2532 */           match((AST)aSTNULLType, 15);
/* 2533 */           aST = aSTNULLType.getNextSibling();
/* 2534 */           if (this.inputState.guessing == 0) {
/* 2535 */             i |= 0x8;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2573 */           this._retTree = aST;
/* 2574 */           return i;case 16: tNode1 = (TNode)aST; match(aST, 16); aST = aST.getNextSibling(); if (this.inputState.guessing == 0) i |= 0x10;  this._retTree = aST; return i;case 160: tNode1 = (TNode)aST; match(aST, 160); aST = aST.getNextSibling(); if (this.inputState.guessing == 0) i |= 0x20;  this._retTree = aST; return i; }  throw new NoViableAltException(aST); } catch (RecognitionException recognitionException) { if (this.inputState.guessing == 0) { reportError(recognitionException); if (aST != null) aST = aST.getNextSibling();  } else { throw recognitionException; }  }  this._retTree = aST; return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Type structSpecifier(AST paramAST, int paramInt) throws RecognitionException {
/* 2582 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2583 */     CompoundType compoundType = null;
/*      */     
/*      */     try {
/* 2586 */       AST aST = paramAST;
/* 2587 */       TNode tNode1 = (TNode)paramAST;
/* 2588 */       match(paramAST, 10);
/* 2589 */       paramAST = paramAST.getFirstChild();
/* 2590 */       compoundType = structOrUnionBody(paramAST, CompoundTypeKind.STRUCT, paramInt);
/* 2591 */       paramAST = this._retTree;
/* 2592 */       paramAST = aST;
/* 2593 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 2595 */     catch (RecognitionException recognitionException) {
/* 2596 */       if (this.inputState.guessing == 0) {
/* 2597 */         reportError(recognitionException);
/* 2598 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 2600 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2603 */     this._retTree = paramAST;
/* 2604 */     return (Type)compoundType;
/*      */   }
/*      */   
/*      */   public final void attributeDecl(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2609 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2; TNode tNode1; TNode tNode2;
/*      */       TNode tNode3;
/* 2612 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 2613 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 163:
/* 2616 */           aSTNULLType3 = aSTNULLType2;
/* 2617 */           tNode1 = (TNode)aSTNULLType2;
/* 2618 */           match((AST)aSTNULLType2, 163);
/* 2619 */           aST1 = aSTNULLType2.getFirstChild();
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType;
/* 2623 */             if (aST1 == null) aSTNULLType = ASTNULL; 
/* 2624 */             if (aSTNULLType.getType() >= 4 && aSTNULLType.getType() <= 166) {
/* 2625 */               TNode tNode4 = (TNode)aSTNULLType;
/* 2626 */               if (aSTNULLType == null) throw new MismatchedTokenException(); 
/* 2627 */               AST aST3 = aSTNULLType.getNextSibling();
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/* 2635 */           aSTNULLType1 = aSTNULLType3;
/* 2636 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 138:
/* 2641 */           aST2 = aST;
/* 2642 */           tNode1 = (TNode)aST;
/* 2643 */           match(aST, 138);
/* 2644 */           aST = aST.getFirstChild();
/* 2645 */           tNode2 = (TNode)aST;
/* 2646 */           match(aST, 47);
/* 2647 */           aST = aST.getNextSibling();
/* 2648 */           expr(aST);
/* 2649 */           aST = this._retTree;
/* 2650 */           tNode3 = (TNode)aST;
/* 2651 */           match(aST, 48);
/* 2652 */           aST = aST.getNextSibling();
/* 2653 */           aST = aST2;
/* 2654 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2659 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 2663 */     } catch (RecognitionException recognitionException) {
/* 2664 */       if (this.inputState.guessing == 0) {
/* 2665 */         reportError(recognitionException);
/* 2666 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2668 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2671 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Type unionSpecifier(AST paramAST, int paramInt) throws RecognitionException {
/* 2679 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2680 */     CompoundType compoundType = null;
/*      */     
/*      */     try {
/* 2683 */       AST aST = paramAST;
/* 2684 */       TNode tNode1 = (TNode)paramAST;
/* 2685 */       match(paramAST, 11);
/* 2686 */       paramAST = paramAST.getFirstChild();
/* 2687 */       compoundType = structOrUnionBody(paramAST, CompoundTypeKind.UNION, paramInt);
/* 2688 */       paramAST = this._retTree;
/* 2689 */       paramAST = aST;
/* 2690 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 2692 */     catch (RecognitionException recognitionException) {
/* 2693 */       if (this.inputState.guessing == 0) {
/* 2694 */         reportError(recognitionException);
/* 2695 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 2697 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2700 */     this._retTree = paramAST;
/* 2701 */     return (Type)compoundType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Type enumSpecifier(AST paramAST, int paramInt) throws RecognitionException {
/*      */     AST aST;
/* 2709 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2710 */     TNode tNode2 = null;
/*      */     
/* 2712 */     EnumType enumType1 = null;
/* 2713 */     EnumType enumType2 = null;
/* 2714 */     ASTLocusTag aSTLocusTag = findASTLocusTag((AST)tNode1);
/*      */     
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 2718 */       AST aST1 = paramAST;
/* 2719 */       TNode tNode = (TNode)paramAST;
/* 2720 */       match(paramAST, 12);
/* 2721 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 2723 */       boolean bool = false;
/* 2724 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2725 */       if (aSTNULLType.getType() == 42) {
/* 2726 */         ASTNULLType aSTNULLType1 = aSTNULLType;
/* 2727 */         bool = true;
/* 2728 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 2731 */           TNode tNode3 = (TNode)aSTNULLType;
/* 2732 */           match((AST)aSTNULLType, 42);
/* 2733 */           aST = aSTNULLType.getNextSibling();
/* 2734 */           TNode tNode4 = (TNode)aST;
/* 2735 */           match(aST, 7);
/* 2736 */           aST = aST.getNextSibling();
/*      */         
/*      */         }
/* 2739 */         catch (RecognitionException recognitionException) {
/* 2740 */           bool = false;
/*      */         } 
/* 2742 */         aSTNULLType = aSTNULLType1;
/* 2743 */         this.inputState.guessing--;
/*      */       } 
/* 2745 */       if (bool) {
/* 2746 */         tNode2 = (TNode)aSTNULLType;
/* 2747 */         match((AST)aSTNULLType, 42);
/* 2748 */         aST = aSTNULLType.getNextSibling();
/* 2749 */         TNode tNode3 = (TNode)aST;
/* 2750 */         match(aST, 7);
/* 2751 */         aST = aST.getNextSibling();
/* 2752 */         enumList(aST, enumType2 = getEnumType(tNode2.getText(), aSTLocusTag));
/* 2753 */         aST = this._retTree;
/* 2754 */         TNode tNode4 = (TNode)aST;
/* 2755 */         match(aST, 8);
/* 2756 */         aST = aST.getNextSibling();
/*      */       }
/* 2758 */       else if (aST.getType() == 7) {
/* 2759 */         TNode tNode3 = (TNode)aST;
/* 2760 */         match(aST, 7);
/* 2761 */         aST = aST.getNextSibling();
/* 2762 */         enumList(aST, enumType2 = getEnumType("<anonymous>", aSTLocusTag));
/* 2763 */         aST = this._retTree;
/* 2764 */         TNode tNode4 = (TNode)aST;
/* 2765 */         match(aST, 8);
/* 2766 */         aST = aST.getNextSibling();
/*      */       }
/* 2768 */       else if (aST.getType() == 42) {
/* 2769 */         TNode tNode3 = (TNode)aST;
/* 2770 */         match(aST, 42);
/* 2771 */         aST = aST.getNextSibling();
/* 2772 */         if (this.inputState.guessing == 0) {
/* 2773 */           enumType2 = getEnumType(tNode2.getText(), aSTLocusTag);
/*      */         }
/*      */       } else {
/*      */         
/* 2777 */         throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 2781 */       if (this.inputState.guessing == 0) {
/*      */         
/* 2783 */         debugPrintln("Adding enum mapping: " + getDebugTypeString((Type)enumType2));
/* 2784 */         if (null != enumType2) {
/* 2785 */           String str = enumType2.getName();
/* 2786 */           if (null != str && !str.equals("<anonymous>")) {
/* 2787 */             EnumType enumType = this.enumMap.get(str);
/* 2788 */             if (null != enumType && !enumType.equalSemantics((TypeComparator.SemanticEqualityOp)enumType2))
/* 2789 */               throwGlueGenException((AST)tNode1, 
/* 2790 */                   String.format("Duplicate enum w/ incompatible type:%n  this '%s',%n  have '%s',%n  %s: previous definition is here", new Object[] {
/* 2791 */                       getTypeString((Type)enumType2), getTypeString((Type)enumType), enumType.getASTLocusTag().toString(new StringBuilder(), "note", true)
/*      */                     })); 
/* 2793 */             this.enumMap.put(str, (EnumType)enumType2.clone(aSTLocusTag));
/*      */           } 
/*      */         } 
/* 2796 */         enumType1 = enumType2;
/*      */       } 
/*      */       
/* 2799 */       aST = aST1;
/* 2800 */       aST = aST.getNextSibling();
/*      */     }
/* 2802 */     catch (RecognitionException recognitionException) {
/* 2803 */       if (this.inputState.guessing == 0) {
/* 2804 */         reportError(recognitionException);
/* 2805 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2807 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2810 */     this._retTree = aST;
/* 2811 */     return (Type)enumType1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Type typedefName(AST paramAST, int paramInt) throws RecognitionException {
/* 2819 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2820 */     TNode tNode2 = null;
/* 2821 */     Type type = null;
/*      */     
/*      */     try {
/* 2824 */       AST aST = paramAST;
/* 2825 */       TNode tNode = (TNode)paramAST;
/* 2826 */       match(paramAST, 113);
/* 2827 */       paramAST = paramAST.getFirstChild();
/* 2828 */       tNode2 = (TNode)paramAST;
/* 2829 */       match(paramAST, 42);
/* 2830 */       paramAST = paramAST.getNextSibling();
/* 2831 */       paramAST = aST;
/* 2832 */       paramAST = paramAST.getNextSibling();
/* 2833 */       if (this.inputState.guessing == 0)
/*      */       {
/* 2835 */         Type type1 = lookupInTypedefDictionary((AST)tNode1, tNode2.getText());
/* 2836 */         debugPrint("Adding typedef lookup: [" + tNode2.getText() + "] -> " + getDebugTypeString(type1));
/* 2837 */         Type type2 = type1.newCVVariant(paramInt);
/* 2838 */         debugPrintln(" - cvvar -> " + getDebugTypeString(type2));
/* 2839 */         type = canonicalize(type2);
/* 2840 */         debugPrintln(" - canon -> " + getDebugTypeString(type));
/*      */       }
/*      */     
/*      */     }
/* 2844 */     catch (RecognitionException recognitionException) {
/* 2845 */       if (this.inputState.guessing == 0) {
/* 2846 */         reportError(recognitionException);
/* 2847 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 2849 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2852 */     this._retTree = paramAST;
/* 2853 */     return type;
/*      */   }
/*      */   
/*      */   public final void typeName(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2858 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 2860 */     TypeBox typeBox = null;
/*      */     
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 2864 */       specifierQualifierList(paramAST);
/* 2865 */       paramAST = this._retTree;
/*      */       
/* 2867 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2868 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 122:
/* 2871 */           nonemptyAbstractDeclarator((AST)aSTNULLType, typeBox);
/* 2872 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2881 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 2886 */     } catch (RecognitionException recognitionException) {
/* 2887 */       if (this.inputState.guessing == 0) {
/* 2888 */         reportError(recognitionException);
/* 2889 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2891 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2894 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final CompoundType structOrUnionBody(AST paramAST, CompoundTypeKind paramCompoundTypeKind, int paramInt) throws RecognitionException {
/*      */     AST aST;
/* 2902 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2903 */     TNode tNode2 = null;
/* 2904 */     TNode tNode3 = null;
/*      */     
/* 2906 */     CompoundType compoundType = null;
/* 2907 */     boolean bool = false;
/* 2908 */     ASTLocusTag aSTLocusTag = findASTLocusTag((AST)tNode1);
/*      */     
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*      */       
/* 2913 */       boolean bool1 = false;
/* 2914 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2915 */       if (aSTNULLType.getType() == 42) {
/* 2916 */         ASTNULLType aSTNULLType1 = aSTNULLType;
/* 2917 */         bool1 = true;
/* 2918 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 2921 */           TNode tNode4 = (TNode)aSTNULLType;
/* 2922 */           match((AST)aSTNULLType, 42);
/* 2923 */           aST = aSTNULLType.getNextSibling();
/* 2924 */           TNode tNode5 = (TNode)aST;
/* 2925 */           match(aST, 7);
/* 2926 */           aST = aST.getNextSibling();
/*      */         
/*      */         }
/* 2929 */         catch (RecognitionException recognitionException) {
/* 2930 */           bool1 = false;
/*      */         } 
/* 2932 */         aSTNULLType = aSTNULLType1;
/* 2933 */         this.inputState.guessing--;
/*      */       } 
/* 2935 */       if (bool1) {
/* 2936 */         ASTNULLType aSTNULLType1; tNode2 = (TNode)aSTNULLType;
/* 2937 */         match((AST)aSTNULLType, 42);
/* 2938 */         AST aST1 = aSTNULLType.getNextSibling();
/* 2939 */         TNode tNode4 = (TNode)aST1;
/* 2940 */         match(aST1, 7);
/* 2941 */         aST1 = aST1.getNextSibling();
/* 2942 */         if (this.inputState.guessing == 0)
/*      */         {
/*      */           
/* 2945 */           compoundType = (CompoundType)canonicalize((Type)lookupInStructDictionary(tNode2.getText(), paramCompoundTypeKind, paramInt, aSTLocusTag));
/*      */         }
/*      */ 
/*      */         
/* 2949 */         if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 2950 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 2984 */             bool = structDeclarationList((AST)aSTNULLType1, compoundType);
/* 2985 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2994 */             throw new NoViableAltException(aST);
/*      */         } 
/*      */ 
/*      */         
/* 2998 */         TNode tNode5 = (TNode)aST;
/* 2999 */         match(aST, 8);
/* 3000 */         aST = aST.getNextSibling();
/* 3001 */         if (this.inputState.guessing == 0) {
/* 3002 */           compoundType.setBodyParsed();
/*      */         }
/*      */       }
/* 3005 */       else if (aST.getType() == 7) {
/* 3006 */         ASTNULLType aSTNULLType1; TNode tNode4 = (TNode)aST;
/* 3007 */         match(aST, 7);
/* 3008 */         aST = aST.getNextSibling();
/* 3009 */         if (this.inputState.guessing == 0)
/*      */         {
/*      */           
/* 3012 */           compoundType = CompoundType.create(null, null, paramCompoundTypeKind, paramInt, aSTLocusTag);
/*      */         }
/*      */ 
/*      */         
/* 3016 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/* 3017 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 3051 */             structDeclarationList((AST)aSTNULLType1, compoundType);
/* 3052 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 3061 */             throw new NoViableAltException(aST);
/*      */         } 
/*      */ 
/*      */         
/* 3065 */         TNode tNode5 = (TNode)aST;
/* 3066 */         match(aST, 8);
/* 3067 */         aST = aST.getNextSibling();
/* 3068 */         if (this.inputState.guessing == 0) {
/* 3069 */           compoundType.setBodyParsed();
/*      */         }
/*      */       }
/* 3072 */       else if (aST.getType() == 42) {
/* 3073 */         tNode3 = (TNode)aST;
/* 3074 */         match(aST, 42);
/* 3075 */         aST = aST.getNextSibling();
/* 3076 */         if (this.inputState.guessing == 0)
/*      */         {
/*      */           
/* 3079 */           compoundType = (CompoundType)canonicalize((Type)lookupInStructDictionary(tNode3.getText(), paramCompoundTypeKind, paramInt, aSTLocusTag));
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 3084 */         throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3088 */       if (this.inputState.guessing == 0)
/*      */       {
/* 3090 */         debugPrintln("Adding compound body: [" + compoundType.getName() + "] -> " + getDebugTypeString((Type)compoundType) + " @ " + aSTLocusTag);
/* 3091 */         debugPrintln(compoundType.getStructString());
/*      */       }
/*      */     
/*      */     }
/* 3095 */     catch (RecognitionException recognitionException) {
/* 3096 */       if (this.inputState.guessing == 0) {
/* 3097 */         reportError(recognitionException);
/* 3098 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3100 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3103 */     this._retTree = aST;
/* 3104 */     return compoundType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean structDeclarationList(AST paramAST, CompoundType paramCompoundType) throws RecognitionException {
/*      */     AST aST;
/* 3112 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 3114 */     boolean bool1 = false;
/* 3115 */     boolean bool2 = false;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3120 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3123 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3124 */         if (_tokenSet_1.member(aSTNULLType.getType())) {
/* 3125 */           bool2 = structDeclaration((AST)aSTNULLType, paramCompoundType);
/* 3126 */           aST = this._retTree;
/* 3127 */           if (this.inputState.guessing == 0) {
/* 3128 */             bool1 |= bool2;
/*      */           }
/*      */         } else {
/*      */           
/* 3132 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3135 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3139 */     catch (RecognitionException recognitionException) {
/* 3140 */       if (this.inputState.guessing == 0) {
/* 3141 */         reportError(recognitionException);
/* 3142 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3144 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3147 */     this._retTree = aST;
/* 3148 */     return bool1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean structDeclaration(AST paramAST, CompoundType paramCompoundType) throws RecognitionException {
/* 3156 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 3158 */     boolean bool = false;
/* 3159 */     Type type = null;
/*      */ 
/*      */     
/*      */     try {
/* 3163 */       type = specifierQualifierList(paramAST);
/* 3164 */       paramAST = this._retTree;
/* 3165 */       bool = structDeclaratorList(paramAST, paramCompoundType, type);
/* 3166 */       paramAST = this._retTree;
/* 3167 */       if (this.inputState.guessing == 0)
/*      */       {
/* 3169 */         if (!bool && 
/* 3170 */           type != null) {
/* 3171 */           CompoundType compoundType = type.asCompound();
/* 3172 */           if (null == compoundType)
/* 3173 */             throwGlueGenException((AST)tNode, 
/* 3174 */                 String.format("Anonymous compound, w/ NULL type:%n  containing '%s'", new Object[] {
/* 3175 */                     getTypeString((Type)paramCompoundType)
/*      */                   })); 
/* 3177 */           if (compoundType.isUnion())
/*      */           {
/* 3179 */             paramCompoundType.addField(new Field(null, type, null));
/*      */           
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */     }
/* 3186 */     catch (RecognitionException recognitionException) {
/* 3187 */       if (this.inputState.guessing == 0) {
/* 3188 */         reportError(recognitionException);
/* 3189 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 3191 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3194 */     this._retTree = paramAST;
/* 3195 */     return bool;
/*      */   }
/*      */   
/*      */   public final Type specifierQualifierList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*      */     IntType intType;
/* 3201 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 3203 */     Type type = null; int i = 0, j = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3208 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3211 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3212 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 3242 */             type = typeSpecifier((AST)aSTNULLType, i);
/* 3243 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/*      */           case 25:
/*      */           case 26:
/* 3251 */             j = typeQualifier(aST);
/* 3252 */             aST = this._retTree;
/* 3253 */             if (this.inputState.guessing == 0) {
/* 3254 */               i |= j;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 3260 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3263 */         b++;
/*      */       } 
/*      */       
/* 3266 */       if (this.inputState.guessing == 0)
/*      */       {
/* 3268 */         if (type == null && (i & 0x300) != 0)
/*      */         {
/*      */           
/* 3271 */           intType = new IntType("int", SizeThunk.INTxx, ((i & 0x200) != 0), attrs2CVAttrs(i), findASTLocusTag((AST)tNode));
/*      */         
/*      */         }
/*      */       }
/*      */     }
/* 3276 */     catch (RecognitionException recognitionException) {
/* 3277 */       if (this.inputState.guessing == 0) {
/* 3278 */         reportError(recognitionException);
/* 3279 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3281 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3284 */     this._retTree = aST;
/* 3285 */     return (Type)intType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean structDeclaratorList(AST paramAST, CompoundType paramCompoundType, Type paramType) throws RecognitionException {
/*      */     AST aST;
/* 3293 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 3295 */     boolean bool1 = false;
/* 3296 */     boolean bool2 = false;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3301 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3304 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3305 */         if (aSTNULLType.getType() == 116) {
/* 3306 */           bool2 = structDeclarator((AST)aSTNULLType, paramCompoundType, paramType);
/* 3307 */           aST = this._retTree;
/* 3308 */           if (this.inputState.guessing == 0) {
/* 3309 */             bool1 = bool2;
/*      */           }
/*      */         } else {
/*      */           
/* 3313 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3316 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3320 */     catch (RecognitionException recognitionException) {
/* 3321 */       if (this.inputState.guessing == 0) {
/* 3322 */         reportError(recognitionException);
/* 3323 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3325 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3328 */     this._retTree = aST;
/* 3329 */     return bool1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean structDeclarator(AST paramAST, CompoundType paramCompoundType, Type paramType) throws RecognitionException {
/*      */     AST aST;
/* 3337 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 3339 */     boolean bool = false;
/* 3340 */     String str = null;
/* 3341 */     TypeBox typeBox = new TypeBox(paramType); try {
/*      */       ASTNULLType aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/*      */       TNode tNode2;
/* 3345 */       AST aST2 = paramAST;
/* 3346 */       TNode tNode1 = (TNode)paramAST;
/* 3347 */       match(paramAST, 116);
/* 3348 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 3350 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 3351 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 115:
/* 3354 */           str = declarator((AST)aSTNULLType2, typeBox);
/* 3355 */           aST1 = this._retTree;
/* 3356 */           if (this.inputState.guessing == 0) {
/* 3357 */             paramCompoundType.addField(new Field(str, typeBox.type(), null)); bool = true;
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */         case 44:
/*      */         case 138:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3370 */           throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3375 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 3376 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 44:
/* 3379 */           tNode2 = (TNode)aSTNULLType1;
/* 3380 */           match((AST)aSTNULLType1, 44);
/* 3381 */           aST = aSTNULLType1.getNextSibling();
/* 3382 */           expr(aST);
/* 3383 */           aST = this._retTree;
/* 3384 */           if (this.inputState.guessing == 0);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/*      */         case 138:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 3397 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3404 */         if (aST == null) aSTNULLType = ASTNULL; 
/* 3405 */         if (aSTNULLType.getType() == 138 || aSTNULLType.getType() == 163) {
/* 3406 */           attributeDecl((AST)aSTNULLType);
/* 3407 */           AST aST3 = this._retTree;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 3415 */       aST = aST2;
/* 3416 */       aST = aST.getNextSibling();
/*      */     }
/* 3418 */     catch (RecognitionException recognitionException) {
/* 3419 */       if (this.inputState.guessing == 0) {
/* 3420 */         reportError(recognitionException);
/* 3421 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3423 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3426 */     this._retTree = aST;
/* 3427 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void enumList(AST paramAST, EnumType paramEnumType) throws RecognitionException {
/*      */     AST aST;
/* 3434 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 3436 */     ConstantDefinition constantDefinition = new ConstantDefinition("def", "0", new ConstantDefinition.CNumber(true, false, 0L), findASTLocusTag((AST)tNode));
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3441 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3444 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3445 */         if (aSTNULLType.getType() == 42) {
/* 3446 */           constantDefinition = enumerator((AST)aSTNULLType, paramEnumType, constantDefinition);
/* 3447 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 3450 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3453 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3457 */     catch (RecognitionException recognitionException) {
/* 3458 */       if (this.inputState.guessing == 0) {
/* 3459 */         reportError(recognitionException);
/* 3460 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3462 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3465 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ConstantDefinition enumerator(AST paramAST, EnumType paramEnumType, ConstantDefinition paramConstantDefinition) throws RecognitionException {
/*      */     AST aST;
/* 3473 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 3474 */     TNode tNode2 = null;
/* 3475 */     TNode tNode3 = null;
/*      */     
/* 3477 */     ConstantDefinition constantDefinition = paramConstantDefinition;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode;
/* 3481 */       tNode2 = (TNode)paramAST;
/* 3482 */       match(paramAST, 42);
/* 3483 */       paramAST = paramAST.getNextSibling();
/*      */       
/* 3485 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3486 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/* 3489 */           tNode = (TNode)aSTNULLType;
/* 3490 */           match((AST)aSTNULLType, 45);
/* 3491 */           aST = aSTNULLType.getNextSibling();
/* 3492 */           tNode3 = (aST == ASTNULL) ? null : (TNode)aST;
/* 3493 */           expr(aST);
/* 3494 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 42:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3504 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3508 */       if (this.inputState.guessing == 0) {
/*      */         EnumType.Enumerator enumerator;
/* 3510 */         String str = tNode2.getText();
/*      */         
/* 3512 */         if (tNode3 != null) {
/* 3513 */           String str1 = tNode3.getAllChildrenText(str);
/* 3514 */           if (this.enumHash.containsKey(str1)) {
/* 3515 */             EnumType enumType = this.enumHash.get(str1);
/* 3516 */             EnumType.Enumerator enumerator1 = enumType.getEnum(str1);
/* 3517 */             enumerator = enumerator1;
/*      */           } else {
/* 3519 */             enumerator = new EnumType.Enumerator(str, str1);
/*      */           } 
/* 3521 */         } else if (paramConstantDefinition.hasNumber()) {
/* 3522 */           enumerator = new EnumType.Enumerator(str, paramConstantDefinition.getNumber());
/*      */         } else {
/* 3524 */           enumerator = new EnumType.Enumerator(str, paramConstantDefinition.getNativeExpr());
/*      */         } 
/* 3526 */         ASTLocusTag aSTLocusTag = findASTLocusTag((AST)tNode1);
/* 3527 */         ConstantDefinition.CNumber cNumber = enumerator.getNumber();
/* 3528 */         if (null != cNumber && cNumber.isInteger) {
/* 3529 */           long l = cNumber.i + 1L;
/* 3530 */           constantDefinition = new ConstantDefinition("def", String.valueOf(l), new ConstantDefinition.CNumber(cNumber.isLong, cNumber.isUnsigned, l), aSTLocusTag);
/*      */         } else {
/* 3532 */           constantDefinition = new ConstantDefinition("def", "(" + enumerator.getExpr() + ")+1", null, aSTLocusTag);
/*      */         } 
/* 3534 */         if (this.enumHash.containsKey(str)) {
/* 3535 */           EnumType enumType = this.enumHash.get(str);
/* 3536 */           EnumType.Enumerator enumerator1 = enumType.getEnum(str);
/* 3537 */           String str1 = enumerator1.getExpr();
/* 3538 */           if (!str1.equals(enumerator.getExpr())) {
/* 3539 */             throwGlueGenException((AST)tNode1, 
/* 3540 */                 String.format("Duplicate enum value '%s.%s' w/ diff value:%n  this %s,%n  have %s", new Object[] {
/* 3541 */                     enumType.getName(), str, enumerator, enumerator1
/*      */                   }));
/*      */           }
/* 3544 */           enumType.removeEnumerate(str);
/*      */         } 
/*      */         
/* 3547 */         paramEnumType.addEnum(str, enumerator);
/* 3548 */         this.enumHash.put(str, paramEnumType);
/* 3549 */         debugPrintln("ENUM [" + paramEnumType.getName() + "]: " + str + " = " + enumerator + " (new default = " + constantDefinition + ")");
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 3554 */     catch (RecognitionException recognitionException) {
/* 3555 */       if (this.inputState.guessing == 0) {
/* 3556 */         reportError(recognitionException);
/* 3557 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3559 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3562 */     this._retTree = aST;
/* 3563 */     return constantDefinition;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void initDecl(AST paramAST, TypeBox paramTypeBox) throws RecognitionException {
/*      */     AST aST;
/* 3570 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/* 3572 */     String str = null;
/* 3573 */     ASTLocusTag aSTLocusTag = findASTLocusTag((AST)tNode); try {
/*      */       AST aST1;
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode2;
/* 3577 */       AST aST2 = paramAST;
/* 3578 */       TNode tNode1 = (TNode)paramAST;
/* 3579 */       match(paramAST, 114);
/* 3580 */       paramAST = paramAST.getFirstChild();
/* 3581 */       str = declarator(paramAST, paramTypeBox);
/* 3582 */       paramAST = this._retTree;
/* 3583 */       if (this.inputState.guessing == 0)
/*      */       {
/* 3585 */         debugPrintln("GOT declName: " + str + " TB=" + paramTypeBox);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/* 3591 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3592 */         if (aSTNULLType.getType() == 138 || aSTNULLType.getType() == 163) {
/* 3593 */           attributeDecl((AST)aSTNULLType);
/* 3594 */           aST1 = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 3603 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/* 3604 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/* 3607 */           tNode2 = (TNode)aSTNULLType;
/* 3608 */           match((AST)aSTNULLType, 45);
/* 3609 */           aST = aSTNULLType.getNextSibling();
/* 3610 */           initializer(aST);
/* 3611 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/* 3616 */           tNode2 = (TNode)aST;
/* 3617 */           match(aST, 44);
/* 3618 */           aST = aST.getNextSibling();
/* 3619 */           expr(aST);
/* 3620 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3629 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3633 */       aST = aST2;
/* 3634 */       aST = aST.getNextSibling();
/* 3635 */       if (this.inputState.guessing == 0)
/*      */       {
/* 3637 */         if (str != null && paramTypeBox != null && paramTypeBox.isTypedef()) {
/* 3638 */           Type type1 = paramTypeBox.type();
/* 3639 */           debugPrintln("Adding typedef mapping: [" + str + "] -> " + getDebugTypeString(type1));
/*      */           
/* 3641 */           if (type1.isPointer()) {
/* 3642 */             Type type = type1.getTargetType();
/* 3643 */             debugPrintln("  - has target: " + getDebugTypeString(type));
/*      */           } else {
/* 3645 */             Object object = null;
/*      */           } 
/*      */ 
/*      */           
/* 3649 */           if (!type1.isTypedef()) {
/* 3650 */             if (type1.isCompound() || type1.isEnum()) {
/*      */ 
/*      */               
/* 3653 */               type1.setTypedefName(str);
/* 3654 */               debugPrintln(" - alias.11 -> " + getDebugTypeString(type1));
/*      */             } else {
/*      */               
/* 3657 */               type1 = type1.clone(aSTLocusTag);
/* 3658 */               type1.setTypedefName(str);
/* 3659 */               debugPrintln(" - newdefine.12 -> " + getDebugTypeString(type1));
/*      */             } 
/*      */           } else {
/*      */             
/* 3663 */             this.cfg.addTypeInfo(str, type1);
/*      */             
/* 3665 */             if (type1.isCompound()) {
/*      */               
/* 3667 */               debugPrintln(" - alias.21 -> " + getDebugTypeString(type1));
/*      */             } else {
/*      */               
/* 3670 */               type1 = type1.clone(aSTLocusTag);
/* 3671 */               type1.setTypedefName(str);
/* 3672 */               debugPrintln(" - copy.22 -> " + getDebugTypeString(type1));
/*      */             } 
/*      */           } 
/* 3675 */           Type type2 = this.typedefDictionary.get(str);
/* 3676 */           if (null != type2 && !type2.equalSemantics((TypeComparator.SemanticEqualityOp)type1))
/* 3677 */             throwGlueGenException(aSTLocusTag, 
/* 3678 */                 String.format("Duplicate typedef w/ incompatible type:%n  this '%s',%n  have '%s',%n  %s: previous definition is here", new Object[] {
/* 3679 */                     getTypeString(type1), getTypeString(type2), type2.getASTLocusTag().toString(new StringBuilder(), "note", true)
/*      */                   })); 
/* 3681 */           type1 = canonicalize(type1);
/* 3682 */           debugPrintln(" - canon -> " + getDebugTypeString(type1));
/* 3683 */           this.typedefDictionary.put(str, type1);
/*      */           
/* 3685 */           paramTypeBox.reset();
/*      */         }
/*      */       
/*      */       }
/*      */     }
/* 3690 */     catch (RecognitionException recognitionException) {
/* 3691 */       if (this.inputState.guessing == 0) {
/* 3692 */         reportError(recognitionException);
/* 3693 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3695 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3698 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void initializer(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3703 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType4;
/*      */       TNode tNode1;
/* 3706 */       if (paramAST == null) aSTNULLType3 = ASTNULL; 
/* 3707 */       switch (aSTNULLType3.getType()) {
/*      */         
/*      */         case 123:
/* 3710 */           aSTNULLType4 = aSTNULLType3;
/* 3711 */           tNode1 = (TNode)aSTNULLType3;
/* 3712 */           match((AST)aSTNULLType3, 123);
/* 3713 */           aST2 = aSTNULLType3.getFirstChild();
/*      */           
/* 3715 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 3716 */           switch (aSTNULLType2.getType()) {
/*      */             
/*      */             case 136:
/* 3719 */               initializerElementLabel((AST)aSTNULLType2);
/* 3720 */               aST1 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 42:
/*      */             case 45:
/*      */             case 46:
/*      */             case 47:
/*      */             case 64:
/*      */             case 65:
/*      */             case 66:
/*      */             case 67:
/*      */             case 68:
/*      */             case 69:
/*      */             case 70:
/*      */             case 71:
/*      */             case 72:
/*      */             case 73:
/*      */             case 74:
/*      */             case 75:
/*      */             case 76:
/*      */             case 77:
/*      */             case 78:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/*      */             case 82:
/*      */             case 83:
/*      */             case 84:
/*      */             case 85:
/*      */             case 86:
/*      */             case 87:
/*      */             case 88:
/*      */             case 89:
/*      */             case 90:
/*      */             case 91:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 99:
/*      */             case 118:
/*      */             case 120:
/*      */             case 123:
/*      */             case 125:
/*      */             case 130:
/*      */             case 131:
/*      */             case 133:
/*      */             case 134:
/*      */             case 135:
/*      */             case 137:
/*      */             case 139:
/*      */             case 158:
/*      */             case 164:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3777 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 3781 */           expr(aST1);
/* 3782 */           aST1 = this._retTree;
/* 3783 */           aSTNULLType1 = aSTNULLType4;
/* 3784 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 137:
/* 3789 */           lcurlyInitializer(aST);
/* 3790 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3795 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 3799 */     } catch (RecognitionException recognitionException) {
/* 3800 */       if (this.inputState.guessing == 0) {
/* 3801 */         reportError(recognitionException);
/* 3802 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3804 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3807 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int intConstExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3813 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 3814 */     TNode tNode2 = null;
/* 3815 */     TNode tNode3 = null;
/* 3816 */     byte b = -1;
/*      */     
/*      */     try { ASTNULLType aSTNULLType;
/* 3819 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3820 */       switch (aSTNULLType.getType())
/*      */       
/*      */       { case 158:
/* 3823 */           tNode2 = (TNode)aSTNULLType;
/* 3824 */           match((AST)aSTNULLType, 158);
/* 3825 */           aST = aSTNULLType.getNextSibling();
/* 3826 */           if (this.inputState.guessing == 0) {
/* 3827 */             return Integer.parseInt(tNode2.getText());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3871 */           this._retTree = aST;
/* 3872 */           return b;case 42: tNode3 = (TNode)aST; match(aST, 42); aST = aST.getNextSibling(); if (this.inputState.guessing == 0) { String str = tNode3.getText(); EnumType enumType = this.enumHash.get(str); if (null == enumType) throwGlueGenException((AST)tNode1, "Error: intConstExpr ID " + str + " recognized, but no containing enum-type found");  EnumType.Enumerator enumerator = enumType.getEnum(str); ConstantDefinition.CNumber cNumber = enumerator.getNumber(); if (null != cNumber && cNumber.isInteger && !cNumber.isLong) { debugPrintln("INFO: intConstExpr: enum[Type " + enumType.getName() + ", " + enumerator + "]"); } else { throwGlueGenException((AST)tNode1, "Error: intConstExpr ID " + str + " enum " + enumerator + " not an int32_t"); }  return (int)cNumber.i; }  this._retTree = aST; return b; }  throw new NoViableAltException(aST); } catch (RecognitionException recognitionException) { if (this.inputState.guessing == 0) { reportError(recognitionException); if (aST != null) aST = aST.getNextSibling();  } else { throw recognitionException; }  }  this._retTree = aST; return b;
/*      */   }
/*      */   public final void translationUnit(AST paramAST) throws RecognitionException {
/*      */     ASTNULLType aSTNULLType;
/*      */     AST aST;
/* 3877 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/* 3880 */     if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3881 */     switch (aSTNULLType.getType()) {
/*      */       
/*      */       case 5:
/*      */       case 9:
/*      */       case 117:
/*      */       case 127:
/*      */       case 140:
/* 3888 */         externalList((AST)aSTNULLType);
/* 3889 */         aST = this._retTree;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 3898 */         throw new NoViableAltException(aST);
/*      */     } 
/*      */ 
/*      */     
/* 3902 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void externalList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3907 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 3911 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3914 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3915 */         if (_tokenSet_2.member(aSTNULLType.getType())) {
/* 3916 */           externalDef((AST)aSTNULLType);
/* 3917 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 3920 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3923 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3927 */     catch (RecognitionException recognitionException) {
/* 3928 */       if (this.inputState.guessing == 0) {
/* 3929 */         reportError(recognitionException);
/* 3930 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3932 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3935 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void externalDef(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3940 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 3943 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3944 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 117:
/* 3947 */           declaration((AST)aSTNULLType);
/* 3948 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 127:
/* 3953 */           functionDef(aST);
/* 3954 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/* 3959 */           asm_expr(aST);
/* 3960 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/* 3965 */           tNode1 = (TNode)aST;
/* 3966 */           match(aST, 9);
/* 3967 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 140:
/* 3972 */           typelessDeclaration(aST);
/* 3973 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3978 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 3982 */     } catch (RecognitionException recognitionException) {
/* 3983 */       if (this.inputState.guessing == 0) {
/* 3984 */         reportError(recognitionException);
/* 3985 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3987 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3990 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void asm_expr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3995 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 3998 */       AST aST1 = paramAST;
/* 3999 */       TNode tNode1 = (TNode)paramAST;
/* 4000 */       match(paramAST, 5);
/* 4001 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 4003 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4004 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 6:
/* 4007 */           tNode2 = (TNode)aSTNULLType;
/* 4008 */           match((AST)aSTNULLType, 6);
/* 4009 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4018 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 4022 */       TNode tNode2 = (TNode)aST;
/* 4023 */       match(aST, 7);
/* 4024 */       aST = aST.getNextSibling();
/* 4025 */       expr(aST);
/* 4026 */       aST = this._retTree;
/* 4027 */       TNode tNode3 = (TNode)aST;
/* 4028 */       match(aST, 8);
/* 4029 */       aST = aST.getNextSibling();
/*      */       
/* 4031 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType1;
/*      */         AST aST2;
/* 4034 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/* 4035 */         if (aSTNULLType1.getType() == 9) {
/* 4036 */           TNode tNode4 = (TNode)aSTNULLType1;
/* 4037 */           match((AST)aSTNULLType1, 9);
/* 4038 */           aST2 = aSTNULLType1.getNextSibling();
/*      */         } else {
/*      */           
/* 4041 */           if (b >= 1) break;  throw new NoViableAltException(aST2);
/*      */         } 
/*      */         
/* 4044 */         b++;
/*      */       } 
/*      */       
/* 4047 */       aST = aST1;
/* 4048 */       aST = aST.getNextSibling();
/*      */     }
/* 4050 */     catch (RecognitionException recognitionException) {
/* 4051 */       if (this.inputState.guessing == 0) {
/* 4052 */         reportError(recognitionException);
/* 4053 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4055 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4058 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void initializerElementLabel(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4063 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1;
/*      */       TNode tNode2, tNode3, tNode4;
/* 4066 */       AST aST2 = paramAST;
/* 4067 */       TNode tNode1 = (TNode)paramAST;
/* 4068 */       match(paramAST, 136);
/* 4069 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 4071 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4072 */       switch (aSTNULLType2.getType()) {
/*      */ 
/*      */         
/*      */         case 49:
/* 4076 */           tNode2 = (TNode)aSTNULLType2;
/* 4077 */           match((AST)aSTNULLType2, 49);
/* 4078 */           aST1 = aSTNULLType2.getNextSibling();
/* 4079 */           expr(aST1);
/* 4080 */           aST1 = this._retTree;
/* 4081 */           tNode3 = (TNode)aST1;
/* 4082 */           match(aST1, 50);
/* 4083 */           aST1 = aST1.getNextSibling();
/*      */           
/* 4085 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 4086 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 45:
/* 4089 */               tNode4 = (TNode)aSTNULLType1;
/* 4090 */               match((AST)aSTNULLType1, 45);
/* 4091 */               aST = aSTNULLType1.getNextSibling();
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/* 4100 */           throw new NoViableAltException(aST);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 42:
/* 4109 */           tNode2 = (TNode)aST;
/* 4110 */           match(aST, 42);
/* 4111 */           aST = aST.getNextSibling();
/* 4112 */           tNode3 = (TNode)aST;
/* 4113 */           match(aST, 44);
/* 4114 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 98:
/* 4119 */           tNode2 = (TNode)aST;
/* 4120 */           match(aST, 98);
/* 4121 */           aST = aST.getNextSibling();
/* 4122 */           tNode3 = (TNode)aST;
/* 4123 */           match(aST, 42);
/* 4124 */           aST = aST.getNextSibling();
/* 4125 */           tNode4 = (TNode)aST;
/* 4126 */           match(aST, 45);
/* 4127 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4132 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 4136 */       aST = aST2;
/* 4137 */       aST = aST.getNextSibling();
/*      */     }
/* 4139 */     catch (RecognitionException recognitionException) {
/* 4140 */       if (this.inputState.guessing == 0) {
/* 4141 */         reportError(recognitionException);
/* 4142 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4144 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4147 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void lcurlyInitializer(AST paramAST) throws RecognitionException {
/* 4152 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4155 */       AST aST = paramAST;
/* 4156 */       TNode tNode1 = (TNode)paramAST;
/* 4157 */       match(paramAST, 137);
/* 4158 */       paramAST = paramAST.getFirstChild();
/* 4159 */       initializerList(paramAST);
/* 4160 */       paramAST = this._retTree;
/* 4161 */       TNode tNode2 = (TNode)paramAST;
/* 4162 */       match(paramAST, 8);
/* 4163 */       paramAST = paramAST.getNextSibling();
/* 4164 */       paramAST = aST;
/* 4165 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4167 */     catch (RecognitionException recognitionException) {
/* 4168 */       if (this.inputState.guessing == 0) {
/* 4169 */         reportError(recognitionException);
/* 4170 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4172 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4175 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void initializerList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4180 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         
/* 4186 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4187 */         if (aSTNULLType.getType() == 123 || aSTNULLType.getType() == 137) {
/* 4188 */           initializer((AST)aSTNULLType);
/* 4189 */           aST = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 4198 */     } catch (RecognitionException recognitionException) {
/* 4199 */       if (this.inputState.guessing == 0) {
/* 4200 */         reportError(recognitionException);
/* 4201 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4203 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4206 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declarationList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4211 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 4215 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 4218 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4219 */         if (aSTNULLType.getType() == 159) {
/* 4220 */           localLabelDecl((AST)aSTNULLType);
/* 4221 */           aST = this._retTree;
/*      */         }
/* 4223 */         else if (aST.getType() == 117) {
/* 4224 */           declaration(aST);
/* 4225 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 4228 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 4231 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 4235 */     catch (RecognitionException recognitionException) {
/* 4236 */       if (this.inputState.guessing == 0) {
/* 4237 */         reportError(recognitionException);
/* 4238 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4240 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4243 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void localLabelDecl(AST paramAST) throws RecognitionException {
/* 4248 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4251 */       AST aST = paramAST;
/* 4252 */       TNode tNode1 = (TNode)paramAST;
/* 4253 */       match(paramAST, 159);
/* 4254 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 4256 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/* 4259 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4260 */         if (aSTNULLType.getType() == 42) {
/* 4261 */           TNode tNode2 = (TNode)aSTNULLType;
/* 4262 */           match((AST)aSTNULLType, 42);
/* 4263 */           aST1 = aSTNULLType.getNextSibling();
/*      */         } else {
/*      */           
/* 4266 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 4269 */         b++;
/*      */       } 
/*      */       
/* 4272 */       paramAST = aST;
/* 4273 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4275 */     catch (RecognitionException recognitionException) {
/* 4276 */       if (this.inputState.guessing == 0) {
/* 4277 */         reportError(recognitionException);
/* 4278 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4280 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4283 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void statementList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4288 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 4292 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 4295 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4296 */         if (_tokenSet_3.member(aSTNULLType.getType())) {
/* 4297 */           statement((AST)aSTNULLType);
/* 4298 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 4301 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 4304 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 4308 */     catch (RecognitionException recognitionException) {
/* 4309 */       if (this.inputState.guessing == 0) {
/* 4310 */         reportError(recognitionException);
/* 4311 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4313 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4316 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void statement(AST paramAST) throws RecognitionException {
/* 4321 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4324 */       statementBody(paramAST);
/* 4325 */       paramAST = this._retTree;
/*      */     }
/* 4327 */     catch (RecognitionException recognitionException) {
/* 4328 */       if (this.inputState.guessing == 0) {
/* 4329 */         reportError(recognitionException);
/* 4330 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4332 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4335 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void statementBody(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4340 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType6; AST aST5; ASTNULLType aSTNULLType5; AST aST4; ASTNULLType aSTNULLType4; AST aST3; ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; TNode tNode2; AST aST7; TNode tNode1; AST aST6; TNode tNode3;
/*      */       TNode tNode4;
/* 4343 */       if (paramAST == null) aSTNULLType6 = ASTNULL; 
/* 4344 */       switch (aSTNULLType6.getType()) {
/*      */         
/*      */         case 9:
/* 4347 */           tNode2 = (TNode)aSTNULLType6;
/* 4348 */           match((AST)aSTNULLType6, 9);
/* 4349 */           aST5 = aSTNULLType6.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 128:
/* 4354 */           compoundStatement(aST5);
/* 4355 */           aST5 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 124:
/* 4360 */           aST7 = aST5;
/* 4361 */           tNode3 = (TNode)aST5;
/* 4362 */           match(aST5, 124);
/* 4363 */           aST5 = aST5.getFirstChild();
/* 4364 */           expr(aST5);
/* 4365 */           aST5 = this._retTree;
/* 4366 */           aST5 = aST7;
/* 4367 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 52:
/* 4372 */           aST7 = aST5;
/* 4373 */           tNode3 = (TNode)aST5;
/* 4374 */           match(aST5, 52);
/* 4375 */           aST5 = aST5.getFirstChild();
/* 4376 */           expr(aST5);
/* 4377 */           aST5 = this._retTree;
/* 4378 */           statement(aST5);
/* 4379 */           aST5 = this._retTree;
/* 4380 */           aST5 = aST7;
/* 4381 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 53:
/* 4386 */           aST7 = aST5;
/* 4387 */           tNode3 = (TNode)aST5;
/* 4388 */           match(aST5, 53);
/* 4389 */           aST5 = aST5.getFirstChild();
/* 4390 */           statement(aST5);
/* 4391 */           aST5 = this._retTree;
/* 4392 */           expr(aST5);
/* 4393 */           aST5 = this._retTree;
/* 4394 */           aST5 = aST7;
/* 4395 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 54:
/* 4400 */           aST7 = aST5;
/* 4401 */           tNode3 = (TNode)aST5;
/* 4402 */           match(aST5, 54);
/* 4403 */           aST5 = aST5.getFirstChild();
/* 4404 */           expr(aST5);
/* 4405 */           aST5 = this._retTree;
/* 4406 */           expr(aST5);
/* 4407 */           aST5 = this._retTree;
/* 4408 */           expr(aST5);
/* 4409 */           aST5 = this._retTree;
/* 4410 */           statement(aST5);
/* 4411 */           aST5 = this._retTree;
/* 4412 */           aST5 = aST7;
/* 4413 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 55:
/* 4418 */           aST7 = aST5;
/* 4419 */           tNode3 = (TNode)aST5;
/* 4420 */           match(aST5, 55);
/* 4421 */           aST5 = aST5.getFirstChild();
/* 4422 */           expr(aST5);
/* 4423 */           aST5 = this._retTree;
/* 4424 */           aST5 = aST7;
/* 4425 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 56:
/* 4430 */           tNode1 = (TNode)aST5;
/* 4431 */           match(aST5, 56);
/* 4432 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 57:
/* 4437 */           tNode1 = (TNode)aST5;
/* 4438 */           match(aST5, 57);
/* 4439 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 58:
/* 4444 */           aST6 = aST5;
/* 4445 */           tNode3 = (TNode)aST5;
/* 4446 */           match(aST5, 58);
/* 4447 */           aST5 = aST5.getFirstChild();
/*      */           
/* 4449 */           if (aST5 == null) aSTNULLType5 = ASTNULL; 
/* 4450 */           switch (aSTNULLType5.getType()) {
/*      */             
/*      */             case 42:
/*      */             case 45:
/*      */             case 46:
/*      */             case 47:
/*      */             case 64:
/*      */             case 65:
/*      */             case 66:
/*      */             case 67:
/*      */             case 68:
/*      */             case 69:
/*      */             case 70:
/*      */             case 71:
/*      */             case 72:
/*      */             case 73:
/*      */             case 74:
/*      */             case 75:
/*      */             case 76:
/*      */             case 77:
/*      */             case 78:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/*      */             case 82:
/*      */             case 83:
/*      */             case 84:
/*      */             case 85:
/*      */             case 86:
/*      */             case 87:
/*      */             case 88:
/*      */             case 89:
/*      */             case 90:
/*      */             case 91:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 99:
/*      */             case 118:
/*      */             case 120:
/*      */             case 123:
/*      */             case 125:
/*      */             case 130:
/*      */             case 131:
/*      */             case 133:
/*      */             case 134:
/*      */             case 135:
/*      */             case 137:
/*      */             case 139:
/*      */             case 158:
/*      */             case 164:
/* 4501 */               expr((AST)aSTNULLType5);
/* 4502 */               aST4 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4511 */               throw new NoViableAltException(aST4);
/*      */           } 
/*      */ 
/*      */           
/* 4515 */           aST4 = aST6;
/* 4516 */           aST4 = aST4.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 132:
/* 4521 */           aST6 = aST4;
/* 4522 */           tNode3 = (TNode)aST4;
/* 4523 */           match(aST4, 132);
/* 4524 */           aST4 = aST4.getFirstChild();
/* 4525 */           tNode4 = (TNode)aST4;
/* 4526 */           match(aST4, 42);
/* 4527 */           aST4 = aST4.getNextSibling();
/*      */           
/* 4529 */           if (aST4 == null) aSTNULLType4 = ASTNULL; 
/* 4530 */           switch (aSTNULLType4.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 4547 */               statement((AST)aSTNULLType4);
/* 4548 */               aST3 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4557 */               throw new NoViableAltException(aST3);
/*      */           } 
/*      */ 
/*      */           
/* 4561 */           aST3 = aST6;
/* 4562 */           aST3 = aST3.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 59:
/* 4567 */           aST6 = aST3;
/* 4568 */           tNode3 = (TNode)aST3;
/* 4569 */           match(aST3, 59);
/* 4570 */           aST3 = aST3.getFirstChild();
/* 4571 */           expr(aST3);
/* 4572 */           aST3 = this._retTree;
/*      */           
/* 4574 */           if (aST3 == null) aSTNULLType3 = ASTNULL; 
/* 4575 */           switch (aSTNULLType3.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 4592 */               statement((AST)aSTNULLType3);
/* 4593 */               aST2 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4602 */               throw new NoViableAltException(aST2);
/*      */           } 
/*      */ 
/*      */           
/* 4606 */           aST2 = aST6;
/* 4607 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 60:
/* 4612 */           aST6 = aST2;
/* 4613 */           tNode3 = (TNode)aST2;
/* 4614 */           match(aST2, 60);
/* 4615 */           aST2 = aST2.getFirstChild();
/*      */           
/* 4617 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 4618 */           switch (aSTNULLType2.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 4635 */               statement((AST)aSTNULLType2);
/* 4636 */               aST1 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4645 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 4649 */           aST1 = aST6;
/* 4650 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 61:
/* 4655 */           aST6 = aST1;
/* 4656 */           tNode3 = (TNode)aST1;
/* 4657 */           match(aST1, 61);
/* 4658 */           aST1 = aST1.getFirstChild();
/* 4659 */           expr(aST1);
/* 4660 */           aST1 = this._retTree;
/* 4661 */           statement(aST1);
/* 4662 */           aST1 = this._retTree;
/*      */           
/* 4664 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 4665 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 62:
/* 4668 */               tNode4 = (TNode)aSTNULLType1;
/* 4669 */               match((AST)aSTNULLType1, 62);
/* 4670 */               aST = aSTNULLType1.getNextSibling();
/* 4671 */               statement(aST);
/* 4672 */               aST = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4681 */               throw new NoViableAltException(aST);
/*      */           } 
/*      */ 
/*      */           
/* 4685 */           aST = aST6;
/* 4686 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 63:
/* 4691 */           aST6 = aST;
/* 4692 */           tNode3 = (TNode)aST;
/* 4693 */           match(aST, 63);
/* 4694 */           aST = aST.getFirstChild();
/* 4695 */           expr(aST);
/* 4696 */           aST = this._retTree;
/* 4697 */           statement(aST);
/* 4698 */           aST = this._retTree;
/* 4699 */           aST = aST6;
/* 4700 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4705 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4709 */     } catch (RecognitionException recognitionException) {
/* 4710 */       if (this.inputState.guessing == 0) {
/* 4711 */         reportError(recognitionException);
/* 4712 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4714 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4717 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void assignExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4722 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 4725 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4726 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 45:
/* 4729 */           aSTNULLType3 = aSTNULLType2;
/* 4730 */           tNode1 = (TNode)aSTNULLType2;
/* 4731 */           match((AST)aSTNULLType2, 45);
/* 4732 */           aST1 = aSTNULLType2.getFirstChild();
/* 4733 */           expr(aST1);
/* 4734 */           aST1 = this._retTree;
/* 4735 */           expr(aST1);
/* 4736 */           aST1 = this._retTree;
/* 4737 */           aSTNULLType1 = aSTNULLType3;
/* 4738 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 64:
/* 4743 */           aST2 = aST;
/* 4744 */           tNode1 = (TNode)aST;
/* 4745 */           match(aST, 64);
/* 4746 */           aST = aST.getFirstChild();
/* 4747 */           expr(aST);
/* 4748 */           aST = this._retTree;
/* 4749 */           expr(aST);
/* 4750 */           aST = this._retTree;
/* 4751 */           aST = aST2;
/* 4752 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 65:
/* 4757 */           aST2 = aST;
/* 4758 */           tNode1 = (TNode)aST;
/* 4759 */           match(aST, 65);
/* 4760 */           aST = aST.getFirstChild();
/* 4761 */           expr(aST);
/* 4762 */           aST = this._retTree;
/* 4763 */           expr(aST);
/* 4764 */           aST = this._retTree;
/* 4765 */           aST = aST2;
/* 4766 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 66:
/* 4771 */           aST2 = aST;
/* 4772 */           tNode1 = (TNode)aST;
/* 4773 */           match(aST, 66);
/* 4774 */           aST = aST.getFirstChild();
/* 4775 */           expr(aST);
/* 4776 */           aST = this._retTree;
/* 4777 */           expr(aST);
/* 4778 */           aST = this._retTree;
/* 4779 */           aST = aST2;
/* 4780 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 67:
/* 4785 */           aST2 = aST;
/* 4786 */           tNode1 = (TNode)aST;
/* 4787 */           match(aST, 67);
/* 4788 */           aST = aST.getFirstChild();
/* 4789 */           expr(aST);
/* 4790 */           aST = this._retTree;
/* 4791 */           expr(aST);
/* 4792 */           aST = this._retTree;
/* 4793 */           aST = aST2;
/* 4794 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 68:
/* 4799 */           aST2 = aST;
/* 4800 */           tNode1 = (TNode)aST;
/* 4801 */           match(aST, 68);
/* 4802 */           aST = aST.getFirstChild();
/* 4803 */           expr(aST);
/* 4804 */           aST = this._retTree;
/* 4805 */           expr(aST);
/* 4806 */           aST = this._retTree;
/* 4807 */           aST = aST2;
/* 4808 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 69:
/* 4813 */           aST2 = aST;
/* 4814 */           tNode1 = (TNode)aST;
/* 4815 */           match(aST, 69);
/* 4816 */           aST = aST.getFirstChild();
/* 4817 */           expr(aST);
/* 4818 */           aST = this._retTree;
/* 4819 */           expr(aST);
/* 4820 */           aST = this._retTree;
/* 4821 */           aST = aST2;
/* 4822 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 70:
/* 4827 */           aST2 = aST;
/* 4828 */           tNode1 = (TNode)aST;
/* 4829 */           match(aST, 70);
/* 4830 */           aST = aST.getFirstChild();
/* 4831 */           expr(aST);
/* 4832 */           aST = this._retTree;
/* 4833 */           expr(aST);
/* 4834 */           aST = this._retTree;
/* 4835 */           aST = aST2;
/* 4836 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 71:
/* 4841 */           aST2 = aST;
/* 4842 */           tNode1 = (TNode)aST;
/* 4843 */           match(aST, 71);
/* 4844 */           aST = aST.getFirstChild();
/* 4845 */           expr(aST);
/* 4846 */           aST = this._retTree;
/* 4847 */           expr(aST);
/* 4848 */           aST = this._retTree;
/* 4849 */           aST = aST2;
/* 4850 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 72:
/* 4855 */           aST2 = aST;
/* 4856 */           tNode1 = (TNode)aST;
/* 4857 */           match(aST, 72);
/* 4858 */           aST = aST.getFirstChild();
/* 4859 */           expr(aST);
/* 4860 */           aST = this._retTree;
/* 4861 */           expr(aST);
/* 4862 */           aST = this._retTree;
/* 4863 */           aST = aST2;
/* 4864 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 73:
/* 4869 */           aST2 = aST;
/* 4870 */           tNode1 = (TNode)aST;
/* 4871 */           match(aST, 73);
/* 4872 */           aST = aST.getFirstChild();
/* 4873 */           expr(aST);
/* 4874 */           aST = this._retTree;
/* 4875 */           expr(aST);
/* 4876 */           aST = this._retTree;
/* 4877 */           aST = aST2;
/* 4878 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4883 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4887 */     } catch (RecognitionException recognitionException) {
/* 4888 */       if (this.inputState.guessing == 0) {
/* 4889 */         reportError(recognitionException);
/* 4890 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4892 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4895 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void conditionalExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4900 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 4903 */       AST aST1 = paramAST;
/* 4904 */       TNode tNode1 = (TNode)paramAST;
/* 4905 */       match(paramAST, 74);
/* 4906 */       paramAST = paramAST.getFirstChild();
/* 4907 */       expr(paramAST);
/* 4908 */       paramAST = this._retTree;
/*      */       
/* 4910 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4911 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 42:
/*      */         case 45:
/*      */         case 46:
/*      */         case 47:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 99:
/*      */         case 118:
/*      */         case 120:
/*      */         case 123:
/*      */         case 125:
/*      */         case 130:
/*      */         case 131:
/*      */         case 133:
/*      */         case 134:
/*      */         case 135:
/*      */         case 137:
/*      */         case 139:
/*      */         case 158:
/*      */         case 164:
/* 4962 */           expr((AST)aSTNULLType);
/* 4963 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4972 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 4976 */       TNode tNode2 = (TNode)aST;
/* 4977 */       match(aST, 44);
/* 4978 */       aST = aST.getNextSibling();
/* 4979 */       expr(aST);
/* 4980 */       aST = this._retTree;
/* 4981 */       aST = aST1;
/* 4982 */       aST = aST.getNextSibling();
/*      */     }
/* 4984 */     catch (RecognitionException recognitionException) {
/* 4985 */       if (this.inputState.guessing == 0) {
/* 4986 */         reportError(recognitionException);
/* 4987 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4989 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4992 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalOrExpr(AST paramAST) throws RecognitionException {
/* 4997 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5000 */       AST aST = paramAST;
/* 5001 */       TNode tNode1 = (TNode)paramAST;
/* 5002 */       match(paramAST, 75);
/* 5003 */       paramAST = paramAST.getFirstChild();
/* 5004 */       expr(paramAST);
/* 5005 */       paramAST = this._retTree;
/* 5006 */       expr(paramAST);
/* 5007 */       paramAST = this._retTree;
/* 5008 */       paramAST = aST;
/* 5009 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5011 */     catch (RecognitionException recognitionException) {
/* 5012 */       if (this.inputState.guessing == 0) {
/* 5013 */         reportError(recognitionException);
/* 5014 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5016 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5019 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalAndExpr(AST paramAST) throws RecognitionException {
/* 5024 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5027 */       AST aST = paramAST;
/* 5028 */       TNode tNode1 = (TNode)paramAST;
/* 5029 */       match(paramAST, 76);
/* 5030 */       paramAST = paramAST.getFirstChild();
/* 5031 */       expr(paramAST);
/* 5032 */       paramAST = this._retTree;
/* 5033 */       expr(paramAST);
/* 5034 */       paramAST = this._retTree;
/* 5035 */       paramAST = aST;
/* 5036 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5038 */     catch (RecognitionException recognitionException) {
/* 5039 */       if (this.inputState.guessing == 0) {
/* 5040 */         reportError(recognitionException);
/* 5041 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5043 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5046 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void inclusiveOrExpr(AST paramAST) throws RecognitionException {
/* 5051 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5054 */       AST aST = paramAST;
/* 5055 */       TNode tNode1 = (TNode)paramAST;
/* 5056 */       match(paramAST, 77);
/* 5057 */       paramAST = paramAST.getFirstChild();
/* 5058 */       expr(paramAST);
/* 5059 */       paramAST = this._retTree;
/* 5060 */       expr(paramAST);
/* 5061 */       paramAST = this._retTree;
/* 5062 */       paramAST = aST;
/* 5063 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5065 */     catch (RecognitionException recognitionException) {
/* 5066 */       if (this.inputState.guessing == 0) {
/* 5067 */         reportError(recognitionException);
/* 5068 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5070 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5073 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void exclusiveOrExpr(AST paramAST) throws RecognitionException {
/* 5078 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5081 */       AST aST = paramAST;
/* 5082 */       TNode tNode1 = (TNode)paramAST;
/* 5083 */       match(paramAST, 78);
/* 5084 */       paramAST = paramAST.getFirstChild();
/* 5085 */       expr(paramAST);
/* 5086 */       paramAST = this._retTree;
/* 5087 */       expr(paramAST);
/* 5088 */       paramAST = this._retTree;
/* 5089 */       paramAST = aST;
/* 5090 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5092 */     catch (RecognitionException recognitionException) {
/* 5093 */       if (this.inputState.guessing == 0) {
/* 5094 */         reportError(recognitionException);
/* 5095 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5097 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5100 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void bitAndExpr(AST paramAST) throws RecognitionException {
/* 5105 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5108 */       AST aST = paramAST;
/* 5109 */       TNode tNode1 = (TNode)paramAST;
/* 5110 */       match(paramAST, 79);
/* 5111 */       paramAST = paramAST.getFirstChild();
/* 5112 */       expr(paramAST);
/* 5113 */       paramAST = this._retTree;
/* 5114 */       expr(paramAST);
/* 5115 */       paramAST = this._retTree;
/* 5116 */       paramAST = aST;
/* 5117 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5119 */     catch (RecognitionException recognitionException) {
/* 5120 */       if (this.inputState.guessing == 0) {
/* 5121 */         reportError(recognitionException);
/* 5122 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5124 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5127 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void equalityExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5132 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 5135 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 5136 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 80:
/* 5139 */           aSTNULLType3 = aSTNULLType2;
/* 5140 */           tNode1 = (TNode)aSTNULLType2;
/* 5141 */           match((AST)aSTNULLType2, 80);
/* 5142 */           aST1 = aSTNULLType2.getFirstChild();
/* 5143 */           expr(aST1);
/* 5144 */           aST1 = this._retTree;
/* 5145 */           expr(aST1);
/* 5146 */           aST1 = this._retTree;
/* 5147 */           aSTNULLType1 = aSTNULLType3;
/* 5148 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 81:
/* 5153 */           aST2 = aST;
/* 5154 */           tNode1 = (TNode)aST;
/* 5155 */           match(aST, 81);
/* 5156 */           aST = aST.getFirstChild();
/* 5157 */           expr(aST);
/* 5158 */           aST = this._retTree;
/* 5159 */           expr(aST);
/* 5160 */           aST = this._retTree;
/* 5161 */           aST = aST2;
/* 5162 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5167 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5171 */     } catch (RecognitionException recognitionException) {
/* 5172 */       if (this.inputState.guessing == 0) {
/* 5173 */         reportError(recognitionException);
/* 5174 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5176 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5179 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void relationalExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5184 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 5187 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 5188 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 82:
/* 5191 */           aSTNULLType3 = aSTNULLType2;
/* 5192 */           tNode1 = (TNode)aSTNULLType2;
/* 5193 */           match((AST)aSTNULLType2, 82);
/* 5194 */           aST1 = aSTNULLType2.getFirstChild();
/* 5195 */           expr(aST1);
/* 5196 */           aST1 = this._retTree;
/* 5197 */           expr(aST1);
/* 5198 */           aST1 = this._retTree;
/* 5199 */           aSTNULLType1 = aSTNULLType3;
/* 5200 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 83:
/* 5205 */           aST2 = aST;
/* 5206 */           tNode1 = (TNode)aST;
/* 5207 */           match(aST, 83);
/* 5208 */           aST = aST.getFirstChild();
/* 5209 */           expr(aST);
/* 5210 */           aST = this._retTree;
/* 5211 */           expr(aST);
/* 5212 */           aST = this._retTree;
/* 5213 */           aST = aST2;
/* 5214 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 84:
/* 5219 */           aST2 = aST;
/* 5220 */           tNode1 = (TNode)aST;
/* 5221 */           match(aST, 84);
/* 5222 */           aST = aST.getFirstChild();
/* 5223 */           expr(aST);
/* 5224 */           aST = this._retTree;
/* 5225 */           expr(aST);
/* 5226 */           aST = this._retTree;
/* 5227 */           aST = aST2;
/* 5228 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 85:
/* 5233 */           aST2 = aST;
/* 5234 */           tNode1 = (TNode)aST;
/* 5235 */           match(aST, 85);
/* 5236 */           aST = aST.getFirstChild();
/* 5237 */           expr(aST);
/* 5238 */           aST = this._retTree;
/* 5239 */           expr(aST);
/* 5240 */           aST = this._retTree;
/* 5241 */           aST = aST2;
/* 5242 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5247 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5251 */     } catch (RecognitionException recognitionException) {
/* 5252 */       if (this.inputState.guessing == 0) {
/* 5253 */         reportError(recognitionException);
/* 5254 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5256 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5259 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void shiftExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5264 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 5267 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 5268 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 86:
/* 5271 */           aSTNULLType3 = aSTNULLType2;
/* 5272 */           tNode1 = (TNode)aSTNULLType2;
/* 5273 */           match((AST)aSTNULLType2, 86);
/* 5274 */           aST1 = aSTNULLType2.getFirstChild();
/* 5275 */           expr(aST1);
/* 5276 */           aST1 = this._retTree;
/* 5277 */           expr(aST1);
/* 5278 */           aST1 = this._retTree;
/* 5279 */           aSTNULLType1 = aSTNULLType3;
/* 5280 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 87:
/* 5285 */           aST2 = aST;
/* 5286 */           tNode1 = (TNode)aST;
/* 5287 */           match(aST, 87);
/* 5288 */           aST = aST.getFirstChild();
/* 5289 */           expr(aST);
/* 5290 */           aST = this._retTree;
/* 5291 */           expr(aST);
/* 5292 */           aST = this._retTree;
/* 5293 */           aST = aST2;
/* 5294 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5299 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5303 */     } catch (RecognitionException recognitionException) {
/* 5304 */       if (this.inputState.guessing == 0) {
/* 5305 */         reportError(recognitionException);
/* 5306 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5308 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5311 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void additiveExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5316 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 5319 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 5320 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 88:
/* 5323 */           aSTNULLType3 = aSTNULLType2;
/* 5324 */           tNode1 = (TNode)aSTNULLType2;
/* 5325 */           match((AST)aSTNULLType2, 88);
/* 5326 */           aST1 = aSTNULLType2.getFirstChild();
/* 5327 */           expr(aST1);
/* 5328 */           aST1 = this._retTree;
/* 5329 */           expr(aST1);
/* 5330 */           aST1 = this._retTree;
/* 5331 */           aSTNULLType1 = aSTNULLType3;
/* 5332 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 5337 */           aST2 = aST;
/* 5338 */           tNode1 = (TNode)aST;
/* 5339 */           match(aST, 89);
/* 5340 */           aST = aST.getFirstChild();
/* 5341 */           expr(aST);
/* 5342 */           aST = this._retTree;
/* 5343 */           expr(aST);
/* 5344 */           aST = this._retTree;
/* 5345 */           aST = aST2;
/* 5346 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5351 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5355 */     } catch (RecognitionException recognitionException) {
/* 5356 */       if (this.inputState.guessing == 0) {
/* 5357 */         reportError(recognitionException);
/* 5358 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5360 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5363 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void multExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5368 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 5371 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 5372 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 46:
/* 5375 */           aSTNULLType3 = aSTNULLType2;
/* 5376 */           tNode1 = (TNode)aSTNULLType2;
/* 5377 */           match((AST)aSTNULLType2, 46);
/* 5378 */           aST1 = aSTNULLType2.getFirstChild();
/* 5379 */           expr(aST1);
/* 5380 */           aST1 = this._retTree;
/* 5381 */           expr(aST1);
/* 5382 */           aST1 = this._retTree;
/* 5383 */           aSTNULLType1 = aSTNULLType3;
/* 5384 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 90:
/* 5389 */           aST2 = aST;
/* 5390 */           tNode1 = (TNode)aST;
/* 5391 */           match(aST, 90);
/* 5392 */           aST = aST.getFirstChild();
/* 5393 */           expr(aST);
/* 5394 */           aST = this._retTree;
/* 5395 */           expr(aST);
/* 5396 */           aST = this._retTree;
/* 5397 */           aST = aST2;
/* 5398 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 91:
/* 5403 */           aST2 = aST;
/* 5404 */           tNode1 = (TNode)aST;
/* 5405 */           match(aST, 91);
/* 5406 */           aST = aST.getFirstChild();
/* 5407 */           expr(aST);
/* 5408 */           aST = this._retTree;
/* 5409 */           expr(aST);
/* 5410 */           aST = this._retTree;
/* 5411 */           aST = aST2;
/* 5412 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5417 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5421 */     } catch (RecognitionException recognitionException) {
/* 5422 */       if (this.inputState.guessing == 0) {
/* 5423 */         reportError(recognitionException);
/* 5424 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5426 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5429 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void castExpr(AST paramAST) throws RecognitionException {
/* 5434 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5437 */       AST aST = paramAST;
/* 5438 */       TNode tNode1 = (TNode)paramAST;
/* 5439 */       match(paramAST, 118);
/* 5440 */       paramAST = paramAST.getFirstChild();
/* 5441 */       typeName(paramAST);
/* 5442 */       paramAST = this._retTree;
/* 5443 */       TNode tNode2 = (TNode)paramAST;
/* 5444 */       match(paramAST, 48);
/* 5445 */       paramAST = paramAST.getNextSibling();
/* 5446 */       expr(paramAST);
/* 5447 */       paramAST = this._retTree;
/* 5448 */       paramAST = aST;
/* 5449 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5451 */     catch (RecognitionException recognitionException) {
/* 5452 */       if (this.inputState.guessing == 0) {
/* 5453 */         reportError(recognitionException);
/* 5454 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5456 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5459 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void unaryExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5464 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType4; AST aST3; ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType5; AST aST4; TNode tNode1;
/*      */       boolean bool;
/* 5467 */       if (paramAST == null) aSTNULLType4 = ASTNULL; 
/* 5468 */       switch (aSTNULLType4.getType()) {
/*      */         
/*      */         case 92:
/* 5471 */           aSTNULLType5 = aSTNULLType4;
/* 5472 */           tNode1 = (TNode)aSTNULLType4;
/* 5473 */           match((AST)aSTNULLType4, 92);
/* 5474 */           aST3 = aSTNULLType4.getFirstChild();
/* 5475 */           expr(aST3);
/* 5476 */           aST3 = this._retTree;
/* 5477 */           aSTNULLType3 = aSTNULLType5;
/* 5478 */           aST2 = aSTNULLType3.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 93:
/* 5483 */           aST4 = aST2;
/* 5484 */           tNode1 = (TNode)aST2;
/* 5485 */           match(aST2, 93);
/* 5486 */           aST2 = aST2.getFirstChild();
/* 5487 */           expr(aST2);
/* 5488 */           aST2 = this._retTree;
/* 5489 */           aST2 = aST4;
/* 5490 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 131:
/* 5495 */           aST4 = aST2;
/* 5496 */           tNode1 = (TNode)aST2;
/* 5497 */           match(aST2, 131);
/* 5498 */           aST2 = aST2.getFirstChild();
/* 5499 */           unaryOperator(aST2);
/* 5500 */           aST2 = this._retTree;
/* 5501 */           expr(aST2);
/* 5502 */           aST2 = this._retTree;
/* 5503 */           aST2 = aST4;
/* 5504 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 94:
/* 5509 */           aST4 = aST2;
/* 5510 */           tNode1 = (TNode)aST2;
/* 5511 */           match(aST2, 94);
/* 5512 */           aST2 = aST2.getFirstChild();
/*      */           
/* 5514 */           bool = false;
/* 5515 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 5516 */           if (aSTNULLType2.getType() == 47) {
/* 5517 */             ASTNULLType aSTNULLType = aSTNULLType2;
/* 5518 */             bool = true;
/* 5519 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 5522 */               TNode tNode2 = (TNode)aSTNULLType2;
/* 5523 */               match((AST)aSTNULLType2, 47);
/* 5524 */               aST1 = aSTNULLType2.getNextSibling();
/* 5525 */               typeName(aST1);
/* 5526 */               aST1 = this._retTree;
/*      */             
/*      */             }
/* 5529 */             catch (RecognitionException recognitionException) {
/* 5530 */               bool = false;
/*      */             } 
/* 5532 */             aSTNULLType2 = aSTNULLType;
/* 5533 */             this.inputState.guessing--;
/*      */           } 
/* 5535 */           if (bool) {
/* 5536 */             TNode tNode2 = (TNode)aSTNULLType2;
/* 5537 */             match((AST)aSTNULLType2, 47);
/* 5538 */             aST1 = aSTNULLType2.getNextSibling();
/* 5539 */             typeName(aST1);
/* 5540 */             aST1 = this._retTree;
/* 5541 */             TNode tNode3 = (TNode)aST1;
/* 5542 */             match(aST1, 48);
/* 5543 */             aST1 = aST1.getNextSibling();
/*      */           }
/* 5545 */           else if (_tokenSet_4.member(aST1.getType())) {
/* 5546 */             expr(aST1);
/* 5547 */             aST1 = this._retTree;
/*      */           } else {
/*      */             
/* 5550 */             throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 5554 */           aST1 = aST4;
/* 5555 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 164:
/* 5560 */           aST4 = aST1;
/* 5561 */           tNode1 = (TNode)aST1;
/* 5562 */           match(aST1, 164);
/* 5563 */           aST1 = aST1.getFirstChild();
/*      */           
/* 5565 */           bool = false;
/* 5566 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 5567 */           if (aSTNULLType1.getType() == 47) {
/* 5568 */             ASTNULLType aSTNULLType = aSTNULLType1;
/* 5569 */             bool = true;
/* 5570 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 5573 */               TNode tNode2 = (TNode)aSTNULLType1;
/* 5574 */               match((AST)aSTNULLType1, 47);
/* 5575 */               aST = aSTNULLType1.getNextSibling();
/* 5576 */               typeName(aST);
/* 5577 */               aST = this._retTree;
/*      */             
/*      */             }
/* 5580 */             catch (RecognitionException recognitionException) {
/* 5581 */               bool = false;
/*      */             } 
/* 5583 */             aSTNULLType1 = aSTNULLType;
/* 5584 */             this.inputState.guessing--;
/*      */           } 
/* 5586 */           if (bool) {
/* 5587 */             TNode tNode2 = (TNode)aSTNULLType1;
/* 5588 */             match((AST)aSTNULLType1, 47);
/* 5589 */             aST = aSTNULLType1.getNextSibling();
/* 5590 */             typeName(aST);
/* 5591 */             aST = this._retTree;
/* 5592 */             TNode tNode3 = (TNode)aST;
/* 5593 */             match(aST, 48);
/* 5594 */             aST = aST.getNextSibling();
/*      */           }
/* 5596 */           else if (_tokenSet_4.member(aST.getType())) {
/* 5597 */             expr(aST);
/* 5598 */             aST = this._retTree;
/*      */           } else {
/*      */             
/* 5601 */             throw new NoViableAltException(aST);
/*      */           } 
/*      */ 
/*      */           
/* 5605 */           aST = aST4;
/* 5606 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5611 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5615 */     } catch (RecognitionException recognitionException) {
/* 5616 */       if (this.inputState.guessing == 0) {
/* 5617 */         reportError(recognitionException);
/* 5618 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5620 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5623 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void postfixExpr(AST paramAST) throws RecognitionException {
/* 5628 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5631 */       AST aST = paramAST;
/* 5632 */       TNode tNode1 = (TNode)paramAST;
/* 5633 */       match(paramAST, 133);
/* 5634 */       paramAST = paramAST.getFirstChild();
/* 5635 */       primaryExpr(paramAST);
/* 5636 */       paramAST = this._retTree;
/*      */       
/* 5638 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType2; AST aST2; ASTNULLType aSTNULLType1; AST aST1; TNode tNode3; AST aST3;
/*      */         TNode tNode2, tNode4, tNode5;
/* 5641 */         if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 5642 */         switch (aSTNULLType2.getType()) {
/*      */           
/*      */           case 97:
/* 5645 */             tNode3 = (TNode)aSTNULLType2;
/* 5646 */             match((AST)aSTNULLType2, 97);
/* 5647 */             aST2 = aSTNULLType2.getNextSibling();
/* 5648 */             tNode4 = (TNode)aST2;
/* 5649 */             match(aST2, 42);
/* 5650 */             aST2 = aST2.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 98:
/* 5655 */             tNode3 = (TNode)aST2;
/* 5656 */             match(aST2, 98);
/* 5657 */             aST2 = aST2.getNextSibling();
/* 5658 */             tNode4 = (TNode)aST2;
/* 5659 */             match(aST2, 42);
/* 5660 */             aST2 = aST2.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 121:
/* 5665 */             aST3 = aST2;
/* 5666 */             tNode4 = (TNode)aST2;
/* 5667 */             match(aST2, 121);
/* 5668 */             aST2 = aST2.getFirstChild();
/*      */             
/* 5670 */             if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 5671 */             switch (aSTNULLType1.getType()) {
/*      */               
/*      */               case 42:
/*      */               case 45:
/*      */               case 46:
/*      */               case 47:
/*      */               case 64:
/*      */               case 65:
/*      */               case 66:
/*      */               case 67:
/*      */               case 68:
/*      */               case 69:
/*      */               case 70:
/*      */               case 71:
/*      */               case 72:
/*      */               case 73:
/*      */               case 74:
/*      */               case 75:
/*      */               case 76:
/*      */               case 77:
/*      */               case 78:
/*      */               case 79:
/*      */               case 80:
/*      */               case 81:
/*      */               case 82:
/*      */               case 83:
/*      */               case 84:
/*      */               case 85:
/*      */               case 86:
/*      */               case 87:
/*      */               case 88:
/*      */               case 89:
/*      */               case 90:
/*      */               case 91:
/*      */               case 92:
/*      */               case 93:
/*      */               case 94:
/*      */               case 99:
/*      */               case 118:
/*      */               case 120:
/*      */               case 123:
/*      */               case 125:
/*      */               case 130:
/*      */               case 131:
/*      */               case 133:
/*      */               case 134:
/*      */               case 135:
/*      */               case 137:
/*      */               case 139:
/*      */               case 158:
/*      */               case 164:
/* 5722 */                 argExprList((AST)aSTNULLType1);
/* 5723 */                 aST1 = this._retTree;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 48:
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 5732 */                 throw new NoViableAltException(aST1);
/*      */             } 
/*      */ 
/*      */             
/* 5736 */             tNode5 = (TNode)aST1;
/* 5737 */             match(aST1, 48);
/* 5738 */             aST1 = aST1.getNextSibling();
/* 5739 */             aST1 = aST3;
/* 5740 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 49:
/* 5745 */             tNode2 = (TNode)aST1;
/* 5746 */             match(aST1, 49);
/* 5747 */             aST1 = aST1.getNextSibling();
/* 5748 */             expr(aST1);
/* 5749 */             aST1 = this._retTree;
/* 5750 */             tNode4 = (TNode)aST1;
/* 5751 */             match(aST1, 50);
/* 5752 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 92:
/* 5757 */             tNode2 = (TNode)aST1;
/* 5758 */             match(aST1, 92);
/* 5759 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 93:
/* 5764 */             tNode2 = (TNode)aST1;
/* 5765 */             match(aST1, 93);
/* 5766 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 5771 */             if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 5774 */         b++;
/*      */       } 
/*      */       
/* 5777 */       paramAST = aST;
/* 5778 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5780 */     catch (RecognitionException recognitionException) {
/* 5781 */       if (this.inputState.guessing == 0) {
/* 5782 */         reportError(recognitionException);
/* 5783 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5785 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5788 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void primaryExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5793 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType; TNode tNode1; AST aST1;
/*      */       TNode tNode2;
/* 5796 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5797 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 42:
/* 5800 */           tNode1 = (TNode)aSTNULLType;
/* 5801 */           match((AST)aSTNULLType, 42);
/* 5802 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 158:
/* 5807 */           tNode1 = (TNode)aST;
/* 5808 */           match(aST, 158);
/* 5809 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 99:
/* 5814 */           charConst(aST);
/* 5815 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 135:
/* 5820 */           stringConst(aST);
/* 5821 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 120:
/* 5826 */           aST1 = aST;
/* 5827 */           tNode2 = (TNode)aST;
/* 5828 */           match(aST, 120);
/* 5829 */           aST = aST.getFirstChild();
/* 5830 */           expr(aST);
/* 5831 */           aST = this._retTree;
/* 5832 */           aST = aST1;
/* 5833 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5838 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5842 */     } catch (RecognitionException recognitionException) {
/* 5843 */       if (this.inputState.guessing == 0) {
/* 5844 */         reportError(recognitionException);
/* 5845 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5847 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5850 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void commaExpr(AST paramAST) throws RecognitionException {
/* 5855 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5858 */       AST aST = paramAST;
/* 5859 */       TNode tNode1 = (TNode)paramAST;
/* 5860 */       match(paramAST, 130);
/* 5861 */       paramAST = paramAST.getFirstChild();
/* 5862 */       expr(paramAST);
/* 5863 */       paramAST = this._retTree;
/* 5864 */       expr(paramAST);
/* 5865 */       paramAST = this._retTree;
/* 5866 */       paramAST = aST;
/* 5867 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5869 */     catch (RecognitionException recognitionException) {
/* 5870 */       if (this.inputState.guessing == 0) {
/* 5871 */         reportError(recognitionException);
/* 5872 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5874 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5877 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void emptyExpr(AST paramAST) throws RecognitionException {
/* 5882 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5885 */       TNode tNode1 = (TNode)paramAST;
/* 5886 */       match(paramAST, 125);
/* 5887 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5889 */     catch (RecognitionException recognitionException) {
/* 5890 */       if (this.inputState.guessing == 0) {
/* 5891 */         reportError(recognitionException);
/* 5892 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5894 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5897 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void compoundStatementExpr(AST paramAST) throws RecognitionException {
/* 5902 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5905 */       AST aST = paramAST;
/* 5906 */       TNode tNode1 = (TNode)paramAST;
/* 5907 */       match(paramAST, 47);
/* 5908 */       paramAST = paramAST.getFirstChild();
/* 5909 */       compoundStatement(paramAST);
/* 5910 */       paramAST = this._retTree;
/* 5911 */       TNode tNode2 = (TNode)paramAST;
/* 5912 */       match(paramAST, 48);
/* 5913 */       paramAST = paramAST.getNextSibling();
/* 5914 */       paramAST = aST;
/* 5915 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5917 */     catch (RecognitionException recognitionException) {
/* 5918 */       if (this.inputState.guessing == 0) {
/* 5919 */         reportError(recognitionException);
/* 5920 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5922 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5925 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void rangeExpr(AST paramAST) throws RecognitionException {
/* 5930 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5933 */       AST aST = paramAST;
/* 5934 */       TNode tNode1 = (TNode)paramAST;
/* 5935 */       match(paramAST, 134);
/* 5936 */       paramAST = paramAST.getFirstChild();
/* 5937 */       expr(paramAST);
/* 5938 */       paramAST = this._retTree;
/* 5939 */       TNode tNode2 = (TNode)paramAST;
/* 5940 */       match(paramAST, 51);
/* 5941 */       paramAST = paramAST.getNextSibling();
/* 5942 */       expr(paramAST);
/* 5943 */       paramAST = this._retTree;
/* 5944 */       paramAST = aST;
/* 5945 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5947 */     catch (RecognitionException recognitionException) {
/* 5948 */       if (this.inputState.guessing == 0) {
/* 5949 */         reportError(recognitionException);
/* 5950 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5952 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5955 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void gnuAsmExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5960 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType3, aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/* 5963 */       AST aST3 = paramAST;
/* 5964 */       TNode tNode1 = (TNode)paramAST;
/* 5965 */       match(paramAST, 139);
/* 5966 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 5968 */       if (paramAST == null) aSTNULLType3 = ASTNULL; 
/* 5969 */       switch (aSTNULLType3.getType()) {
/*      */         
/*      */         case 6:
/* 5972 */           tNode2 = (TNode)aSTNULLType3;
/* 5973 */           match((AST)aSTNULLType3, 6);
/* 5974 */           aST2 = aSTNULLType3.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5983 */           throw new NoViableAltException(aST2);
/*      */       } 
/*      */ 
/*      */       
/* 5987 */       TNode tNode2 = (TNode)aST2;
/* 5988 */       match(aST2, 47);
/* 5989 */       AST aST2 = aST2.getNextSibling();
/* 5990 */       stringConst(aST2);
/* 5991 */       aST2 = this._retTree;
/*      */       
/* 5993 */       if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 5994 */       if (aSTNULLType2.getType() == 44) {
/* 5995 */         ASTNULLType aSTNULLType; AST aST4; TNode tNode4 = (TNode)aSTNULLType2;
/* 5996 */         match((AST)aSTNULLType2, 44);
/* 5997 */         AST aST5 = aSTNULLType2.getNextSibling();
/*      */         
/* 5999 */         if (aST5 == null) aSTNULLType = ASTNULL; 
/* 6000 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 135:
/* 6003 */             strOptExprPair((AST)aSTNULLType);
/* 6004 */             aST4 = this._retTree;
/*      */ 
/*      */             
/*      */             while (true) {
/* 6008 */               if (aST4 == null) aSTNULLType1 = ASTNULL; 
/* 6009 */               if (aSTNULLType1.getType() == 43) {
/* 6010 */                 TNode tNode5 = (TNode)aSTNULLType1;
/* 6011 */                 match((AST)aSTNULLType1, 43);
/* 6012 */                 aST4 = aSTNULLType1.getNextSibling();
/* 6013 */                 strOptExprPair(aST4);
/* 6014 */                 aST4 = this._retTree;
/*      */                 continue;
/*      */               } 
/*      */               break;
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 44:
/*      */           case 48:
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 6031 */             throw new NoViableAltException(aST4);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 6036 */         if (aST4 == null) aSTNULLType1 = ASTNULL; 
/* 6037 */         if (aSTNULLType1.getType() == 44) {
/* 6038 */           ASTNULLType aSTNULLType4; TNode tNode5 = (TNode)aSTNULLType1;
/* 6039 */           match((AST)aSTNULLType1, 44);
/* 6040 */           AST aST6 = aSTNULLType1.getNextSibling();
/*      */           
/* 6042 */           if (aST6 == null) aSTNULLType4 = ASTNULL; 
/* 6043 */           switch (aSTNULLType4.getType()) {
/*      */             
/*      */             case 135:
/* 6046 */               strOptExprPair((AST)aSTNULLType4);
/* 6047 */               aST1 = this._retTree;
/*      */               
/*      */               while (true) {
/*      */                 ASTNULLType aSTNULLType5;
/* 6051 */                 if (aST1 == null) aSTNULLType5 = ASTNULL; 
/* 6052 */                 if (aSTNULLType5.getType() == 43) {
/* 6053 */                   TNode tNode6 = (TNode)aSTNULLType5;
/* 6054 */                   match((AST)aSTNULLType5, 43);
/* 6055 */                   aST1 = aSTNULLType5.getNextSibling();
/* 6056 */                   strOptExprPair(aST1);
/* 6057 */                   aST1 = this._retTree;
/*      */                   continue;
/*      */                 } 
/*      */                 break;
/*      */               } 
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 44:
/*      */             case 48:
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             default:
/* 6074 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/* 6079 */         } else if (aST1.getType() != 44 && aST1.getType() != 48) {
/*      */ 
/*      */           
/* 6082 */           throw new NoViableAltException(aST1);
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 6087 */       else if (aST1.getType() != 44 && aST1.getType() != 48) {
/*      */ 
/*      */         
/* 6090 */         throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 6095 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 6096 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 44:
/* 6099 */           tNode3 = (TNode)aSTNULLType1;
/* 6100 */           match((AST)aSTNULLType1, 44);
/* 6101 */           aST = aSTNULLType1.getNextSibling();
/* 6102 */           stringConst(aST);
/* 6103 */           aST = this._retTree;
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType;
/* 6107 */             if (aST == null) aSTNULLType = ASTNULL; 
/* 6108 */             if (aSTNULLType.getType() == 43) {
/* 6109 */               TNode tNode4 = (TNode)aSTNULLType;
/* 6110 */               match((AST)aSTNULLType, 43);
/* 6111 */               aST = aSTNULLType.getNextSibling();
/* 6112 */               stringConst(aST);
/* 6113 */               aST = this._retTree;
/*      */               continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 6129 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 6133 */       TNode tNode3 = (TNode)aST;
/* 6134 */       match(aST, 48);
/* 6135 */       aST = aST.getNextSibling();
/* 6136 */       aST = aST3;
/* 6137 */       aST = aST.getNextSibling();
/*      */     }
/* 6139 */     catch (RecognitionException recognitionException) {
/* 6140 */       if (this.inputState.guessing == 0) {
/* 6141 */         reportError(recognitionException);
/* 6142 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6144 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6147 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void stringConst(AST paramAST) throws RecognitionException {
/* 6152 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 6155 */       AST aST = paramAST;
/* 6156 */       TNode tNode1 = (TNode)paramAST;
/* 6157 */       match(paramAST, 135);
/* 6158 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 6160 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/* 6163 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 6164 */         if (aSTNULLType.getType() == 100) {
/* 6165 */           TNode tNode2 = (TNode)aSTNULLType;
/* 6166 */           match((AST)aSTNULLType, 100);
/* 6167 */           aST1 = aSTNULLType.getNextSibling();
/*      */         } else {
/*      */           
/* 6170 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 6173 */         b++;
/*      */       } 
/*      */       
/* 6176 */       paramAST = aST;
/* 6177 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 6179 */     catch (RecognitionException recognitionException) {
/* 6180 */       if (this.inputState.guessing == 0) {
/* 6181 */         reportError(recognitionException);
/* 6182 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 6184 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6187 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void strOptExprPair(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6192 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1, tNode2;
/* 6195 */       stringConst(paramAST);
/* 6196 */       paramAST = this._retTree;
/*      */       
/* 6198 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 6199 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 47:
/* 6202 */           tNode1 = (TNode)aSTNULLType;
/* 6203 */           match((AST)aSTNULLType, 47);
/* 6204 */           aST = aSTNULLType.getNextSibling();
/* 6205 */           expr(aST);
/* 6206 */           aST = this._retTree;
/* 6207 */           tNode2 = (TNode)aST;
/* 6208 */           match(aST, 48);
/* 6209 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 43:
/*      */         case 44:
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6220 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 6225 */     } catch (RecognitionException recognitionException) {
/* 6226 */       if (this.inputState.guessing == 0) {
/* 6227 */         reportError(recognitionException);
/* 6228 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6230 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6233 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void unaryOperator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6238 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 6241 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 6242 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 79:
/* 6245 */           tNode1 = (TNode)aSTNULLType;
/* 6246 */           match((AST)aSTNULLType, 79);
/* 6247 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/* 6252 */           tNode1 = (TNode)aST;
/* 6253 */           match(aST, 46);
/* 6254 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 88:
/* 6259 */           tNode1 = (TNode)aST;
/* 6260 */           match(aST, 88);
/* 6261 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 6266 */           tNode1 = (TNode)aST;
/* 6267 */           match(aST, 89);
/* 6268 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 95:
/* 6273 */           tNode1 = (TNode)aST;
/* 6274 */           match(aST, 95);
/* 6275 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 96:
/* 6280 */           tNode1 = (TNode)aST;
/* 6281 */           match(aST, 96);
/* 6282 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 76:
/* 6287 */           tNode1 = (TNode)aST;
/* 6288 */           match(aST, 76);
/* 6289 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 165:
/* 6294 */           tNode1 = (TNode)aST;
/* 6295 */           match(aST, 165);
/* 6296 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 166:
/* 6301 */           tNode1 = (TNode)aST;
/* 6302 */           match(aST, 166);
/* 6303 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6308 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 6312 */     } catch (RecognitionException recognitionException) {
/* 6313 */       if (this.inputState.guessing == 0) {
/* 6314 */         reportError(recognitionException);
/* 6315 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6317 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6320 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void argExprList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6325 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 6329 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 6332 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 6333 */         if (_tokenSet_4.member(aSTNULLType.getType())) {
/* 6334 */           expr((AST)aSTNULLType);
/* 6335 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 6338 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 6341 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 6345 */     catch (RecognitionException recognitionException) {
/* 6346 */       if (this.inputState.guessing == 0) {
/* 6347 */         reportError(recognitionException);
/* 6348 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6350 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6353 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void charConst(AST paramAST) throws RecognitionException {
/* 6358 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 6361 */       TNode tNode1 = (TNode)paramAST;
/* 6362 */       match(paramAST, 99);
/* 6363 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 6365 */     catch (RecognitionException recognitionException) {
/* 6366 */       if (this.inputState.guessing == 0) {
/* 6367 */         reportError(recognitionException);
/* 6368 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 6370 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6373 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   protected final void intConst(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6378 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 6381 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 6382 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 101:
/* 6385 */           tNode1 = (TNode)aSTNULLType;
/* 6386 */           match((AST)aSTNULLType, 101);
/* 6387 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 102:
/* 6392 */           tNode1 = (TNode)aST;
/* 6393 */           match(aST, 102);
/* 6394 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 103:
/* 6399 */           tNode1 = (TNode)aST;
/* 6400 */           match(aST, 103);
/* 6401 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 104:
/* 6406 */           tNode1 = (TNode)aST;
/* 6407 */           match(aST, 104);
/* 6408 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 105:
/* 6413 */           tNode1 = (TNode)aST;
/* 6414 */           match(aST, 105);
/* 6415 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 106:
/* 6420 */           tNode1 = (TNode)aST;
/* 6421 */           match(aST, 106);
/* 6422 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 107:
/* 6427 */           tNode1 = (TNode)aST;
/* 6428 */           match(aST, 107);
/* 6429 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 108:
/* 6434 */           tNode1 = (TNode)aST;
/* 6435 */           match(aST, 108);
/* 6436 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 109:
/* 6441 */           tNode1 = (TNode)aST;
/* 6442 */           match(aST, 109);
/* 6443 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6448 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 6452 */     } catch (RecognitionException recognitionException) {
/* 6453 */       if (this.inputState.guessing == 0) {
/* 6454 */         reportError(recognitionException);
/* 6455 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6457 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6460 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   protected final void floatConst(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6465 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 6468 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 6469 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 110:
/* 6472 */           tNode1 = (TNode)aSTNULLType;
/* 6473 */           match((AST)aSTNULLType, 110);
/* 6474 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 111:
/* 6479 */           tNode1 = (TNode)aST;
/* 6480 */           match(aST, 111);
/* 6481 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 112:
/* 6486 */           tNode1 = (TNode)aST;
/* 6487 */           match(aST, 112);
/* 6488 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6493 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 6497 */     } catch (RecognitionException recognitionException) {
/* 6498 */       if (this.inputState.guessing == 0) {
/* 6499 */         reportError(recognitionException);
/* 6500 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6502 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6505 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/* 6509 */   public static final String[] _tokenNames = new String[] { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"typedef\"", "\"asm\"", "\"volatile\"", "LCURLY", "RCURLY", "SEMI", "\"struct\"", "\"union\"", "\"enum\"", "\"auto\"", "\"register\"", "\"extern\"", "\"static\"", "\"const\"", "\"void\"", "\"char\"", "\"short\"", "\"int\"", "\"long\"", "\"float\"", "\"double\"", "\"signed\"", "\"unsigned\"", "\"int8_t\"", "\"uint8_t\"", "\"int16_t\"", "\"uint16_t\"", "\"__int32\"", "\"int32_t\"", "\"wchar_t\"", "\"uint32_t\"", "\"__int64\"", "\"int64_t\"", "\"uint64_t\"", "\"ptrdiff_t\"", "\"intptr_t\"", "\"size_t\"", "\"uintptr_t\"", "ID", "COMMA", "COLON", "ASSIGN", "STAR", "LPAREN", "RPAREN", "LBRACKET", "RBRACKET", "VARARGS", "\"while\"", "\"do\"", "\"for\"", "\"goto\"", "\"continue\"", "\"break\"", "\"return\"", "\"case\"", "\"default\"", "\"if\"", "\"else\"", "\"switch\"", "DIV_ASSIGN", "PLUS_ASSIGN", "MINUS_ASSIGN", "STAR_ASSIGN", "MOD_ASSIGN", "RSHIFT_ASSIGN", "LSHIFT_ASSIGN", "BAND_ASSIGN", "BOR_ASSIGN", "BXOR_ASSIGN", "QUESTION", "LOR", "LAND", "BOR", "BXOR", "BAND", "EQUAL", "NOT_EQUAL", "LT", "LTE", "GT", "GTE", "LSHIFT", "RSHIFT", "PLUS", "MINUS", "DIV", "MOD", "INC", "DEC", "\"sizeof\"", "BNOT", "LNOT", "PTR", "DOT", "CharLiteral", "StringLiteral", "IntOctalConst", "LongOctalConst", "UnsignedOctalConst", "IntIntConst", "LongIntConst", "UnsignedIntConst", "IntHexConst", "LongHexConst", "UnsignedHexConst", "FloatDoubleConst", "DoubleDoubleConst", "LongDoubleConst", "NTypedefName", "NInitDecl", "NDeclarator", "NStructDeclarator", "NDeclaration", "NCast", "NPointerGroup", "NExpressionGroup", "NFunctionCallArgs", "NNonemptyAbstractDeclarator", "NInitializer", "NStatementExpr", "NEmptyExpression", "NParameterTypeList", "NFunctionDef", "NCompoundStatement", "NParameterDeclaration", "NCommaExpr", "NUnaryExpr", "NLabel", "NPostfixExpr", "NRangeExpr", "NStringSeq", "NInitializerElementLabel", "NLcurlyInitializer", "NAsmAttribute", "NGnuAsmExpr", "NTypeMissing", "Vocabulary", "Whitespace", "Comment", "CPPComment", "NonWhitespace", "a line directive", "DefineExpr", "DefineExpr2", "Space", "LineDirective", "BadStringLiteral", "Escape", "Digit", "LongSuffix", "UnsignedSuffix", "FloatSuffix", "Exponent", "Number", "\"__label__\"", "\"inline\"", "\"typeof\"", "\"__complex\"", "\"__attribute\"", "\"__alignof\"", "\"__real\"", "\"__imag\"" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 6680 */     return new long[] { 100794432L, 0L, 0L };
/*      */   }
/*      */   
/* 6683 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 6685 */     return new long[] { 4398046387264L, 562949953421312L, 25769803776L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 6688 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 6690 */     return new long[] { 544L, -9214364837600034816L, 4096L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 6693 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 6695 */     return new long[] { -4616189618054757888L, 1152921504606846976L, 17L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 6698 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 6700 */     return new long[] { 250688651132928L, 2972375790571749375L, 69793221356L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 6703 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/HeaderParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */