/*      */ package com.jogamp.gluegen.cgram;
/*      */ 
/*      */ import antlr.ASTNULLType;
/*      */ import antlr.MismatchedTokenException;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.TreeParser;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.BitSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GnuCTreeParser
/*      */   extends TreeParser
/*      */   implements GnuCTreeParserTokenTypes
/*      */ {
/*   26 */   int traceDepth = 0;
/*      */   public void reportError(RecognitionException paramRecognitionException) {
/*   28 */     if (paramRecognitionException != null) {
/*   29 */       System.err.println("ANTLR Tree Parsing RecognitionException Error: " + paramRecognitionException.getClass().getName() + " " + paramRecognitionException);
/*   30 */       paramRecognitionException.printStackTrace(System.err);
/*      */     } 
/*      */   }
/*      */   public void reportError(NoViableAltException paramNoViableAltException) {
/*   34 */     System.err.println("ANTLR Tree Parsing NoViableAltException Error: " + paramNoViableAltException.toString());
/*   35 */     TNode.printTree(paramNoViableAltException.node);
/*   36 */     paramNoViableAltException.printStackTrace(System.err);
/*      */   }
/*      */   public void reportError(MismatchedTokenException paramMismatchedTokenException) {
/*   39 */     if (paramMismatchedTokenException != null) {
/*   40 */       TNode.printTree(paramMismatchedTokenException.node);
/*   41 */       System.err.println("ANTLR Tree Parsing MismatchedTokenException Error: " + paramMismatchedTokenException);
/*   42 */       paramMismatchedTokenException.printStackTrace(System.err);
/*      */     } 
/*      */   }
/*      */   public void reportError(String paramString) {
/*   46 */     System.err.println("ANTLR Error from String: " + paramString);
/*      */   }
/*      */   public void reportWarning(String paramString) {
/*   49 */     System.err.println("ANTLR Warning from String: " + paramString);
/*      */   }
/*      */   
/*      */   protected void match(AST paramAST, int paramInt) throws MismatchedTokenException {
/*   53 */     super.match(paramAST, paramInt);
/*      */   }
/*      */   
/*      */   public void match(AST paramAST, BitSet paramBitSet) throws MismatchedTokenException {
/*   57 */     super.match(paramAST, paramBitSet);
/*      */   }
/*      */   
/*      */   protected void matchNot(AST paramAST, int paramInt) throws MismatchedTokenException {
/*   61 */     super.matchNot(paramAST, paramInt);
/*      */   }
/*      */   public void traceIn(String paramString, AST paramAST) {
/*   64 */     this.traceDepth++;
/*   65 */     for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*   66 */      super.traceIn(paramString, paramAST);
/*      */   }
/*      */   public void traceOut(String paramString, AST paramAST) {
/*   69 */     for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*   70 */      super.traceOut(paramString, paramAST);
/*   71 */     this.traceDepth--;
/*      */   }
/*      */ 
/*      */   
/*      */   public GnuCTreeParser() {
/*   76 */     this.tokenNames = _tokenNames;
/*      */   }
/*      */   public final void translationUnit(AST paramAST) throws RecognitionException {
/*      */     ASTNULLType aSTNULLType;
/*      */     AST aST;
/*   81 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*   84 */     if (paramAST == null) aSTNULLType = ASTNULL; 
/*   85 */     switch (aSTNULLType.getType()) {
/*      */       
/*      */       case 5:
/*      */       case 9:
/*      */       case 117:
/*      */       case 127:
/*      */       case 140:
/*   92 */         externalList((AST)aSTNULLType);
/*   93 */         aST = this._retTree;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  102 */         throw new NoViableAltException(aST);
/*      */     } 
/*      */ 
/*      */     
/*  106 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void externalList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  111 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/*  115 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*  118 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  119 */         if (_tokenSet_0.member(aSTNULLType.getType())) {
/*  120 */           externalDef((AST)aSTNULLType);
/*  121 */           aST = this._retTree;
/*      */         } else {
/*      */           
/*  124 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/*  127 */         b++;
/*      */       }
/*      */     
/*      */     }
/*  131 */     catch (RecognitionException recognitionException) {
/*  132 */       if (this.inputState.guessing == 0) {
/*  133 */         reportError(recognitionException);
/*  134 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  136 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  139 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void externalDef(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  144 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/*  147 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  148 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 117:
/*  151 */           declaration((AST)aSTNULLType);
/*  152 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 127:
/*  157 */           functionDef(aST);
/*  158 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*  163 */           asm_expr(aST);
/*  164 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*  169 */           tNode1 = (TNode)aST;
/*  170 */           match(aST, 9);
/*  171 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 140:
/*  176 */           typelessDeclaration(aST);
/*  177 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  182 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/*  186 */     } catch (RecognitionException recognitionException) {
/*  187 */       if (this.inputState.guessing == 0) {
/*  188 */         reportError(recognitionException);
/*  189 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  191 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  194 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declaration(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  199 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  202 */       AST aST1 = paramAST;
/*  203 */       TNode tNode1 = (TNode)paramAST;
/*  204 */       match(paramAST, 117);
/*  205 */       paramAST = paramAST.getFirstChild();
/*  206 */       declSpecifiers(paramAST);
/*  207 */       paramAST = this._retTree;
/*      */       
/*  209 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  210 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 114:
/*  213 */           initDeclList((AST)aSTNULLType);
/*  214 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  223 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  228 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType1;
/*      */         AST aST2;
/*  231 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/*  232 */         if (aSTNULLType1.getType() == 9) {
/*  233 */           TNode tNode2 = (TNode)aSTNULLType1;
/*  234 */           match((AST)aSTNULLType1, 9);
/*  235 */           aST2 = aSTNULLType1.getNextSibling();
/*      */         } else {
/*      */           
/*  238 */           if (b >= 1) break;  throw new NoViableAltException(aST2);
/*      */         } 
/*      */         
/*  241 */         b++;
/*      */       } 
/*      */       
/*  244 */       aST = aST1;
/*  245 */       aST = aST.getNextSibling();
/*      */     }
/*  247 */     catch (RecognitionException recognitionException) {
/*  248 */       if (this.inputState.guessing == 0) {
/*  249 */         reportError(recognitionException);
/*  250 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  252 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  255 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void functionDef(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  260 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  263 */       AST aST1 = paramAST;
/*  264 */       TNode tNode1 = (TNode)paramAST;
/*  265 */       match(paramAST, 127);
/*  266 */       paramAST = paramAST.getFirstChild();
/*      */       
/*  268 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  269 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 6:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/*      */         case 18:
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 113:
/*      */         case 160:
/*      */         case 161:
/*      */         case 162:
/*  306 */           functionDeclSpecifiers((AST)aSTNULLType);
/*  307 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 115:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  316 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/*  320 */       declarator(aST);
/*  321 */       aST = this._retTree;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType1;
/*      */         TNode tNode2;
/*  325 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/*  326 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 117:
/*  329 */             declaration((AST)aSTNULLType1);
/*  330 */             aST = this._retTree;
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 51:
/*  335 */             tNode2 = (TNode)aST;
/*  336 */             match(aST, 51);
/*  337 */             aST = aST.getNextSibling();
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  347 */       compoundStatement(aST);
/*  348 */       aST = this._retTree;
/*  349 */       aST = aST1;
/*  350 */       aST = aST.getNextSibling();
/*      */     }
/*  352 */     catch (RecognitionException recognitionException) {
/*  353 */       if (this.inputState.guessing == 0) {
/*  354 */         reportError(recognitionException);
/*  355 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  357 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  360 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void asm_expr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  365 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  368 */       AST aST1 = paramAST;
/*  369 */       TNode tNode1 = (TNode)paramAST;
/*  370 */       match(paramAST, 5);
/*  371 */       paramAST = paramAST.getFirstChild();
/*      */       
/*  373 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  374 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 6:
/*  377 */           tNode2 = (TNode)aSTNULLType;
/*  378 */           match((AST)aSTNULLType, 6);
/*  379 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  388 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/*  392 */       TNode tNode2 = (TNode)aST;
/*  393 */       match(aST, 7);
/*  394 */       aST = aST.getNextSibling();
/*  395 */       expr(aST);
/*  396 */       aST = this._retTree;
/*  397 */       TNode tNode3 = (TNode)aST;
/*  398 */       match(aST, 8);
/*  399 */       aST = aST.getNextSibling();
/*      */       
/*  401 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType1;
/*      */         AST aST2;
/*  404 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/*  405 */         if (aSTNULLType1.getType() == 9) {
/*  406 */           TNode tNode4 = (TNode)aSTNULLType1;
/*  407 */           match((AST)aSTNULLType1, 9);
/*  408 */           aST2 = aSTNULLType1.getNextSibling();
/*      */         } else {
/*      */           
/*  411 */           if (b >= 1) break;  throw new NoViableAltException(aST2);
/*      */         } 
/*      */         
/*  414 */         b++;
/*      */       } 
/*      */       
/*  417 */       aST = aST1;
/*  418 */       aST = aST.getNextSibling();
/*      */     }
/*  420 */     catch (RecognitionException recognitionException) {
/*  421 */       if (this.inputState.guessing == 0) {
/*  422 */         reportError(recognitionException);
/*  423 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  425 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  428 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typelessDeclaration(AST paramAST) throws RecognitionException {
/*  433 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/*  436 */       AST aST = paramAST;
/*  437 */       TNode tNode1 = (TNode)paramAST;
/*  438 */       match(paramAST, 140);
/*  439 */       paramAST = paramAST.getFirstChild();
/*  440 */       initDeclList(paramAST);
/*  441 */       paramAST = this._retTree;
/*  442 */       TNode tNode2 = (TNode)paramAST;
/*  443 */       match(paramAST, 9);
/*  444 */       paramAST = paramAST.getNextSibling();
/*  445 */       paramAST = aST;
/*  446 */       paramAST = paramAST.getNextSibling();
/*      */     }
/*  448 */     catch (RecognitionException recognitionException) {
/*  449 */       if (this.inputState.guessing == 0) {
/*  450 */         reportError(recognitionException);
/*  451 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/*  453 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  456 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void initDeclList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  461 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/*  465 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*  468 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  469 */         if (aSTNULLType.getType() == 114) {
/*  470 */           initDecl((AST)aSTNULLType);
/*  471 */           aST = this._retTree;
/*      */         } else {
/*      */           
/*  474 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/*  477 */         b++;
/*      */       }
/*      */     
/*      */     }
/*  481 */     catch (RecognitionException recognitionException) {
/*  482 */       if (this.inputState.guessing == 0) {
/*  483 */         reportError(recognitionException);
/*  484 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  486 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  489 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void expr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  494 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  497 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  498 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*  511 */           assignExpr((AST)aSTNULLType);
/*  512 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 74:
/*  517 */           conditionalExpr(aST);
/*  518 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 75:
/*  523 */           logicalOrExpr(aST);
/*  524 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 76:
/*  529 */           logicalAndExpr(aST);
/*  530 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 77:
/*  535 */           inclusiveOrExpr(aST);
/*  536 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 78:
/*  541 */           exclusiveOrExpr(aST);
/*  542 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 79:
/*  547 */           bitAndExpr(aST);
/*  548 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 80:
/*      */         case 81:
/*  554 */           equalityExpr(aST);
/*  555 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*  563 */           relationalExpr(aST);
/*  564 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 86:
/*      */         case 87:
/*  570 */           shiftExpr(aST);
/*  571 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 88:
/*      */         case 89:
/*  577 */           additiveExpr(aST);
/*  578 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/*      */         case 90:
/*      */         case 91:
/*  585 */           multExpr(aST);
/*  586 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 118:
/*  591 */           castExpr(aST);
/*  592 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 131:
/*      */         case 164:
/*  601 */           unaryExpr(aST);
/*  602 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 133:
/*  607 */           postfixExpr(aST);
/*  608 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 99:
/*      */         case 120:
/*      */         case 135:
/*      */         case 158:
/*  617 */           primaryExpr(aST);
/*  618 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 130:
/*  623 */           commaExpr(aST);
/*  624 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 125:
/*  629 */           emptyExpr(aST);
/*  630 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/*  635 */           compoundStatementExpr(aST);
/*  636 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 123:
/*      */         case 137:
/*  642 */           initializer(aST);
/*  643 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 134:
/*  648 */           rangeExpr(aST);
/*  649 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 139:
/*  654 */           gnuAsmExpr(aST);
/*  655 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  660 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/*  664 */     } catch (RecognitionException recognitionException) {
/*  665 */       if (this.inputState.guessing == 0) {
/*  666 */         reportError(recognitionException);
/*  667 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  669 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  672 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declSpecifiers(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  677 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/*  681 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*  684 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  685 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 4:
/*      */           case 13:
/*      */           case 14:
/*      */           case 15:
/*      */           case 16:
/*      */           case 160:
/*  693 */             storageClassSpecifier((AST)aSTNULLType);
/*  694 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/*  700 */             typeQualifier(aST);
/*  701 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/*  735 */             typeSpecifier(aST);
/*  736 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  741 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/*  744 */         b++;
/*      */       }
/*      */     
/*      */     }
/*  748 */     catch (RecognitionException recognitionException) {
/*  749 */       if (this.inputState.guessing == 0) {
/*  750 */         reportError(recognitionException);
/*  751 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  753 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  756 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void storageClassSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  761 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/*  764 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  765 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 13:
/*  768 */           tNode1 = (TNode)aSTNULLType;
/*  769 */           match((AST)aSTNULLType, 13);
/*  770 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 14:
/*  775 */           tNode1 = (TNode)aST;
/*  776 */           match(aST, 14);
/*  777 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/*  782 */           tNode1 = (TNode)aST;
/*  783 */           match(aST, 4);
/*  784 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 15:
/*      */         case 16:
/*      */         case 160:
/*  791 */           functionStorageClassSpecifier(aST);
/*  792 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  797 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/*  801 */     } catch (RecognitionException recognitionException) {
/*  802 */       if (this.inputState.guessing == 0) {
/*  803 */         reportError(recognitionException);
/*  804 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  806 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  809 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void typeQualifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  814 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/*  817 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  818 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 17:
/*  821 */           tNode1 = (TNode)aSTNULLType;
/*  822 */           match((AST)aSTNULLType, 17);
/*  823 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 6:
/*  828 */           tNode1 = (TNode)aST;
/*  829 */           match(aST, 6);
/*  830 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  835 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/*  839 */     } catch (RecognitionException recognitionException) {
/*  840 */       if (this.inputState.guessing == 0) {
/*  841 */         reportError(recognitionException);
/*  842 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  844 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  847 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void typeSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  852 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; TNode tNode2; AST aST2; TNode tNode1; TNode tNode3; TNode tNode4;
/*      */       TNode tNode5;
/*  855 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/*  856 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 18:
/*  859 */           tNode2 = (TNode)aSTNULLType2;
/*  860 */           match((AST)aSTNULLType2, 18);
/*  861 */           aST1 = aSTNULLType2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 19:
/*  866 */           tNode2 = (TNode)aST1;
/*  867 */           match(aST1, 19);
/*  868 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 20:
/*  873 */           tNode2 = (TNode)aST1;
/*  874 */           match(aST1, 20);
/*  875 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 21:
/*  880 */           tNode2 = (TNode)aST1;
/*  881 */           match(aST1, 21);
/*  882 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 22:
/*  887 */           tNode2 = (TNode)aST1;
/*  888 */           match(aST1, 22);
/*  889 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 23:
/*  894 */           tNode2 = (TNode)aST1;
/*  895 */           match(aST1, 23);
/*  896 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 24:
/*  901 */           tNode2 = (TNode)aST1;
/*  902 */           match(aST1, 24);
/*  903 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 25:
/*  908 */           tNode2 = (TNode)aST1;
/*  909 */           match(aST1, 25);
/*  910 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 26:
/*  915 */           tNode2 = (TNode)aST1;
/*  916 */           match(aST1, 26);
/*  917 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 27:
/*  922 */           tNode2 = (TNode)aST1;
/*  923 */           match(aST1, 27);
/*  924 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 28:
/*  929 */           tNode2 = (TNode)aST1;
/*  930 */           match(aST1, 28);
/*  931 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 29:
/*  936 */           tNode2 = (TNode)aST1;
/*  937 */           match(aST1, 29);
/*  938 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 30:
/*  943 */           tNode2 = (TNode)aST1;
/*  944 */           match(aST1, 30);
/*  945 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 31:
/*  950 */           tNode2 = (TNode)aST1;
/*  951 */           match(aST1, 31);
/*  952 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 32:
/*  957 */           tNode2 = (TNode)aST1;
/*  958 */           match(aST1, 32);
/*  959 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 33:
/*  964 */           tNode2 = (TNode)aST1;
/*  965 */           match(aST1, 33);
/*  966 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 34:
/*  971 */           tNode2 = (TNode)aST1;
/*  972 */           match(aST1, 34);
/*  973 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 35:
/*  978 */           tNode2 = (TNode)aST1;
/*  979 */           match(aST1, 35);
/*  980 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 36:
/*  985 */           tNode2 = (TNode)aST1;
/*  986 */           match(aST1, 36);
/*  987 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 37:
/*  992 */           tNode2 = (TNode)aST1;
/*  993 */           match(aST1, 37);
/*  994 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 38:
/*  999 */           tNode2 = (TNode)aST1;
/* 1000 */           match(aST1, 38);
/* 1001 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 39:
/* 1006 */           tNode2 = (TNode)aST1;
/* 1007 */           match(aST1, 39);
/* 1008 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 40:
/* 1013 */           tNode2 = (TNode)aST1;
/* 1014 */           match(aST1, 40);
/* 1015 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 41:
/* 1020 */           tNode2 = (TNode)aST1;
/* 1021 */           match(aST1, 41);
/* 1022 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 10:
/* 1027 */           structSpecifier(aST1);
/* 1028 */           aST1 = this._retTree;
/*      */ 
/*      */           
/*      */           while (true) {
/* 1032 */             if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1033 */             if (aSTNULLType1.getType() == 138 || aSTNULLType1.getType() == 163) {
/* 1034 */               attributeDecl((AST)aSTNULLType1);
/* 1035 */               aST1 = this._retTree;
/*      */               continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 11:
/* 1047 */           unionSpecifier(aST1);
/* 1048 */           aST1 = this._retTree;
/*      */ 
/*      */           
/*      */           while (true) {
/* 1052 */             if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1053 */             if (aSTNULLType1.getType() == 138 || aSTNULLType1.getType() == 163) {
/* 1054 */               attributeDecl((AST)aSTNULLType1);
/* 1055 */               aST1 = this._retTree;
/*      */               continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 12:
/* 1067 */           enumSpecifier(aST1);
/* 1068 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 113:
/* 1073 */           typedefName(aST1);
/* 1074 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 161:
/* 1079 */           aST2 = aST1;
/* 1080 */           tNode3 = (TNode)aST1;
/* 1081 */           match(aST1, 161);
/* 1082 */           aST1 = aST1.getFirstChild();
/* 1083 */           tNode4 = (TNode)aST1;
/* 1084 */           match(aST1, 47);
/* 1085 */           aST1 = aST1.getNextSibling();
/*      */           
/* 1087 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1088 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 6:
/*      */             case 10:
/*      */             case 11:
/*      */             case 12:
/*      */             case 17:
/*      */             case 18:
/*      */             case 19:
/*      */             case 20:
/*      */             case 21:
/*      */             case 22:
/*      */             case 23:
/*      */             case 24:
/*      */             case 25:
/*      */             case 26:
/*      */             case 27:
/*      */             case 28:
/*      */             case 29:
/*      */             case 30:
/*      */             case 31:
/*      */             case 32:
/*      */             case 33:
/*      */             case 34:
/*      */             case 35:
/*      */             case 36:
/*      */             case 37:
/*      */             case 38:
/*      */             case 39:
/*      */             case 40:
/*      */             case 41:
/*      */             case 113:
/*      */             case 161:
/*      */             case 162:
/* 1122 */               typeName((AST)aSTNULLType1);
/* 1123 */               aST = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 42:
/*      */             case 45:
/*      */             case 46:
/*      */             case 47:
/*      */             case 64:
/*      */             case 65:
/*      */             case 66:
/*      */             case 67:
/*      */             case 68:
/*      */             case 69:
/*      */             case 70:
/*      */             case 71:
/*      */             case 72:
/*      */             case 73:
/*      */             case 74:
/*      */             case 75:
/*      */             case 76:
/*      */             case 77:
/*      */             case 78:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/*      */             case 82:
/*      */             case 83:
/*      */             case 84:
/*      */             case 85:
/*      */             case 86:
/*      */             case 87:
/*      */             case 88:
/*      */             case 89:
/*      */             case 90:
/*      */             case 91:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 99:
/*      */             case 118:
/*      */             case 120:
/*      */             case 123:
/*      */             case 125:
/*      */             case 130:
/*      */             case 131:
/*      */             case 133:
/*      */             case 134:
/*      */             case 135:
/*      */             case 137:
/*      */             case 139:
/*      */             case 158:
/*      */             case 164:
/* 1176 */               expr(aST);
/* 1177 */               aST = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1182 */               throw new NoViableAltException(aST);
/*      */           } 
/*      */ 
/*      */           
/* 1186 */           tNode5 = (TNode)aST;
/* 1187 */           match(aST, 48);
/* 1188 */           aST = aST.getNextSibling();
/* 1189 */           aST = aST2;
/* 1190 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 162:
/* 1195 */           tNode1 = (TNode)aST;
/* 1196 */           match(aST, 162);
/* 1197 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1202 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1206 */     } catch (RecognitionException recognitionException) {
/* 1207 */       if (this.inputState.guessing == 0) {
/* 1208 */         reportError(recognitionException);
/* 1209 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1211 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1214 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void functionStorageClassSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1219 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 1222 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1223 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 15:
/* 1226 */           tNode1 = (TNode)aSTNULLType;
/* 1227 */           match((AST)aSTNULLType, 15);
/* 1228 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 16:
/* 1233 */           tNode1 = (TNode)aST;
/* 1234 */           match(aST, 16);
/* 1235 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 160:
/* 1240 */           tNode1 = (TNode)aST;
/* 1241 */           match(aST, 160);
/* 1242 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1247 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1251 */     } catch (RecognitionException recognitionException) {
/* 1252 */       if (this.inputState.guessing == 0) {
/* 1253 */         reportError(recognitionException);
/* 1254 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1256 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1259 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structSpecifier(AST paramAST) throws RecognitionException {
/* 1264 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 1267 */       AST aST = paramAST;
/* 1268 */       TNode tNode1 = (TNode)paramAST;
/* 1269 */       match(paramAST, 10);
/* 1270 */       paramAST = paramAST.getFirstChild();
/* 1271 */       structOrUnionBody(paramAST);
/* 1272 */       paramAST = this._retTree;
/* 1273 */       paramAST = aST;
/* 1274 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 1276 */     catch (RecognitionException recognitionException) {
/* 1277 */       if (this.inputState.guessing == 0) {
/* 1278 */         reportError(recognitionException);
/* 1279 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1281 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1284 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void attributeDecl(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1289 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2; TNode tNode1; TNode tNode2;
/*      */       TNode tNode3;
/* 1292 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 1293 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 163:
/* 1296 */           aSTNULLType3 = aSTNULLType2;
/* 1297 */           tNode1 = (TNode)aSTNULLType2;
/* 1298 */           match((AST)aSTNULLType2, 163);
/* 1299 */           aST1 = aSTNULLType2.getFirstChild();
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType;
/* 1303 */             if (aST1 == null) aSTNULLType = ASTNULL; 
/* 1304 */             if (aSTNULLType.getType() >= 4 && aSTNULLType.getType() <= 166) {
/* 1305 */               TNode tNode4 = (TNode)aSTNULLType;
/* 1306 */               if (aSTNULLType == null) throw new MismatchedTokenException(); 
/* 1307 */               AST aST3 = aSTNULLType.getNextSibling();
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/* 1315 */           aSTNULLType1 = aSTNULLType3;
/* 1316 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 138:
/* 1321 */           aST2 = aST;
/* 1322 */           tNode1 = (TNode)aST;
/* 1323 */           match(aST, 138);
/* 1324 */           aST = aST.getFirstChild();
/* 1325 */           tNode2 = (TNode)aST;
/* 1326 */           match(aST, 47);
/* 1327 */           aST = aST.getNextSibling();
/* 1328 */           expr(aST);
/* 1329 */           aST = this._retTree;
/* 1330 */           tNode3 = (TNode)aST;
/* 1331 */           match(aST, 48);
/* 1332 */           aST = aST.getNextSibling();
/* 1333 */           aST = aST2;
/* 1334 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1339 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1343 */     } catch (RecognitionException recognitionException) {
/* 1344 */       if (this.inputState.guessing == 0) {
/* 1345 */         reportError(recognitionException);
/* 1346 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1348 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1351 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void unionSpecifier(AST paramAST) throws RecognitionException {
/* 1356 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 1359 */       AST aST = paramAST;
/* 1360 */       TNode tNode1 = (TNode)paramAST;
/* 1361 */       match(paramAST, 11);
/* 1362 */       paramAST = paramAST.getFirstChild();
/* 1363 */       structOrUnionBody(paramAST);
/* 1364 */       paramAST = this._retTree;
/* 1365 */       paramAST = aST;
/* 1366 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 1368 */     catch (RecognitionException recognitionException) {
/* 1369 */       if (this.inputState.guessing == 0) {
/* 1370 */         reportError(recognitionException);
/* 1371 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1373 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1376 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void enumSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1381 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1;
/*      */       TNode tNode2, tNode3;
/* 1384 */       AST aST2 = paramAST;
/* 1385 */       TNode tNode1 = (TNode)paramAST;
/* 1386 */       match(paramAST, 12);
/* 1387 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 1389 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 1390 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 42:
/* 1393 */           tNode2 = (TNode)aSTNULLType2;
/* 1394 */           match((AST)aSTNULLType2, 42);
/* 1395 */           aST1 = aSTNULLType2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */         case 7:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1405 */           throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1410 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1411 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 7:
/* 1414 */           tNode2 = (TNode)aSTNULLType1;
/* 1415 */           match((AST)aSTNULLType1, 7);
/* 1416 */           aST = aSTNULLType1.getNextSibling();
/* 1417 */           enumList(aST);
/* 1418 */           aST = this._retTree;
/* 1419 */           tNode3 = (TNode)aST;
/* 1420 */           match(aST, 8);
/* 1421 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1430 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 1434 */       aST = aST2;
/* 1435 */       aST = aST.getNextSibling();
/*      */     }
/* 1437 */     catch (RecognitionException recognitionException) {
/* 1438 */       if (this.inputState.guessing == 0) {
/* 1439 */         reportError(recognitionException);
/* 1440 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1442 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1445 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typedefName(AST paramAST) throws RecognitionException {
/* 1450 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 1453 */       AST aST = paramAST;
/* 1454 */       TNode tNode1 = (TNode)paramAST;
/* 1455 */       match(paramAST, 113);
/* 1456 */       paramAST = paramAST.getFirstChild();
/* 1457 */       TNode tNode2 = (TNode)paramAST;
/* 1458 */       match(paramAST, 42);
/* 1459 */       paramAST = paramAST.getNextSibling();
/* 1460 */       paramAST = aST;
/* 1461 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 1463 */     catch (RecognitionException recognitionException) {
/* 1464 */       if (this.inputState.guessing == 0) {
/* 1465 */         reportError(recognitionException);
/* 1466 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1468 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1471 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void typeName(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1476 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1479 */       specifierQualifierList(paramAST);
/* 1480 */       paramAST = this._retTree;
/*      */       
/* 1482 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1483 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 122:
/* 1486 */           nonemptyAbstractDeclarator((AST)aSTNULLType);
/* 1487 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1496 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 1501 */     } catch (RecognitionException recognitionException) {
/* 1502 */       if (this.inputState.guessing == 0) {
/* 1503 */         reportError(recognitionException);
/* 1504 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1506 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1509 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void structOrUnionBody(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1514 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1518 */       boolean bool = false;
/* 1519 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1520 */       if (aSTNULLType.getType() == 42) {
/* 1521 */         ASTNULLType aSTNULLType1 = aSTNULLType;
/* 1522 */         bool = true;
/* 1523 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 1526 */           TNode tNode1 = (TNode)aSTNULLType;
/* 1527 */           match((AST)aSTNULLType, 42);
/* 1528 */           aST = aSTNULLType.getNextSibling();
/* 1529 */           TNode tNode2 = (TNode)aST;
/* 1530 */           match(aST, 7);
/* 1531 */           aST = aST.getNextSibling();
/*      */         
/*      */         }
/* 1534 */         catch (RecognitionException recognitionException) {
/* 1535 */           bool = false;
/*      */         } 
/* 1537 */         aSTNULLType = aSTNULLType1;
/* 1538 */         this.inputState.guessing--;
/*      */       } 
/* 1540 */       if (bool) {
/* 1541 */         ASTNULLType aSTNULLType1; TNode tNode1 = (TNode)aSTNULLType;
/* 1542 */         match((AST)aSTNULLType, 42);
/* 1543 */         AST aST1 = aSTNULLType.getNextSibling();
/* 1544 */         TNode tNode2 = (TNode)aST1;
/* 1545 */         match(aST1, 7);
/* 1546 */         aST1 = aST1.getNextSibling();
/*      */         
/* 1548 */         if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1549 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 1583 */             structDeclarationList((AST)aSTNULLType1);
/* 1584 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1593 */             throw new NoViableAltException(aST);
/*      */         } 
/*      */ 
/*      */         
/* 1597 */         TNode tNode3 = (TNode)aST;
/* 1598 */         match(aST, 8);
/* 1599 */         aST = aST.getNextSibling();
/*      */       }
/* 1601 */       else if (aST.getType() == 7) {
/* 1602 */         ASTNULLType aSTNULLType1; TNode tNode1 = (TNode)aST;
/* 1603 */         match(aST, 7);
/* 1604 */         aST = aST.getNextSibling();
/*      */         
/* 1606 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/* 1607 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 1641 */             structDeclarationList((AST)aSTNULLType1);
/* 1642 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1651 */             throw new NoViableAltException(aST);
/*      */         } 
/*      */ 
/*      */         
/* 1655 */         TNode tNode2 = (TNode)aST;
/* 1656 */         match(aST, 8);
/* 1657 */         aST = aST.getNextSibling();
/*      */       }
/* 1659 */       else if (aST.getType() == 42) {
/* 1660 */         TNode tNode1 = (TNode)aST;
/* 1661 */         match(aST, 42);
/* 1662 */         aST = aST.getNextSibling();
/*      */       } else {
/*      */         
/* 1665 */         throw new NoViableAltException(aST);
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1670 */     catch (RecognitionException recognitionException) {
/* 1671 */       if (this.inputState.guessing == 0) {
/* 1672 */         reportError(recognitionException);
/* 1673 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1675 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1678 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void structDeclarationList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1683 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 1687 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1690 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1691 */         if (_tokenSet_1.member(aSTNULLType.getType())) {
/* 1692 */           structDeclaration((AST)aSTNULLType);
/* 1693 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 1696 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 1699 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 1703 */     catch (RecognitionException recognitionException) {
/* 1704 */       if (this.inputState.guessing == 0) {
/* 1705 */         reportError(recognitionException);
/* 1706 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1708 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1711 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclaration(AST paramAST) throws RecognitionException {
/* 1716 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 1719 */       specifierQualifierList(paramAST);
/* 1720 */       paramAST = this._retTree;
/* 1721 */       structDeclaratorList(paramAST);
/* 1722 */       paramAST = this._retTree;
/*      */     }
/* 1724 */     catch (RecognitionException recognitionException) {
/* 1725 */       if (this.inputState.guessing == 0) {
/* 1726 */         reportError(recognitionException);
/* 1727 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1729 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1732 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void specifierQualifierList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1737 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 1741 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1744 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1745 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 1777 */             typeSpecifier((AST)aSTNULLType);
/* 1778 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/* 1784 */             typeQualifier(aST);
/* 1785 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1790 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 1793 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 1797 */     catch (RecognitionException recognitionException) {
/* 1798 */       if (this.inputState.guessing == 0) {
/* 1799 */         reportError(recognitionException);
/* 1800 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1802 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1805 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void structDeclaratorList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1810 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 1814 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1817 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1818 */         if (aSTNULLType.getType() == 116) {
/* 1819 */           structDeclarator((AST)aSTNULLType);
/* 1820 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 1823 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 1826 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 1830 */     catch (RecognitionException recognitionException) {
/* 1831 */       if (this.inputState.guessing == 0) {
/* 1832 */         reportError(recognitionException);
/* 1833 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1835 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1838 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void structDeclarator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1843 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1;
/*      */       TNode tNode2;
/* 1846 */       AST aST2 = paramAST;
/* 1847 */       TNode tNode1 = (TNode)paramAST;
/* 1848 */       match(paramAST, 116);
/* 1849 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 1851 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 1852 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 115:
/* 1855 */           declarator((AST)aSTNULLType2);
/* 1856 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */         case 44:
/*      */         case 138:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1868 */           throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1873 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1874 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 44:
/* 1877 */           tNode2 = (TNode)aSTNULLType1;
/* 1878 */           match((AST)aSTNULLType1, 44);
/* 1879 */           aST = aSTNULLType1.getNextSibling();
/* 1880 */           expr(aST);
/* 1881 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */         case 138:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1892 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1899 */         if (aST == null) aSTNULLType = ASTNULL; 
/* 1900 */         if (aSTNULLType.getType() == 138 || aSTNULLType.getType() == 163) {
/* 1901 */           attributeDecl((AST)aSTNULLType);
/* 1902 */           AST aST3 = this._retTree;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1910 */       aST = aST2;
/* 1911 */       aST = aST.getNextSibling();
/*      */     }
/* 1913 */     catch (RecognitionException recognitionException) {
/* 1914 */       if (this.inputState.guessing == 0) {
/* 1915 */         reportError(recognitionException);
/* 1916 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1918 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1921 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declarator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1926 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1927 */     TNode tNode2 = null; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1;
/*      */       TNode tNode4, tNode5;
/* 1930 */       AST aST2 = paramAST;
/* 1931 */       TNode tNode3 = (TNode)paramAST;
/* 1932 */       match(paramAST, 115);
/* 1933 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 1935 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 1936 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 119:
/* 1939 */           pointerGroup((AST)aSTNULLType2);
/* 1940 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1950 */           throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1955 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1956 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 42:
/* 1959 */           tNode2 = (TNode)aSTNULLType1;
/* 1960 */           match((AST)aSTNULLType1, 42);
/* 1961 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/* 1966 */           tNode4 = (TNode)aST;
/* 1967 */           match(aST, 47);
/* 1968 */           aST = aST.getNextSibling();
/* 1969 */           declarator(aST);
/* 1970 */           aST = this._retTree;
/* 1971 */           tNode5 = (TNode)aST;
/* 1972 */           match(aST, 48);
/* 1973 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1978 */           throw new NoViableAltException(aST);
/*      */       }  while (true) {
/*      */         ASTNULLType aSTNULLType7; AST aST7; ASTNULLType aSTNULLType6; AST aST6; ASTNULLType aSTNULLType5; AST aST5; ASTNULLType aSTNULLType4; AST aST4; ASTNULLType aSTNULLType3;
/*      */         AST aST3;
/*      */         ASTNULLType aSTNULLType8;
/*      */         TNode tNode6;
/*      */         TNode tNode7;
/* 1985 */         if (aST == null) aSTNULLType7 = ASTNULL; 
/* 1986 */         switch (aSTNULLType7.getType()) {
/*      */           
/*      */           case 126:
/* 1989 */             aSTNULLType8 = aSTNULLType7;
/* 1990 */             tNode5 = (TNode)aSTNULLType7;
/* 1991 */             match((AST)aSTNULLType7, 126);
/* 1992 */             aST7 = aSTNULLType7.getFirstChild();
/*      */             
/* 1994 */             if (aST7 == null) aSTNULLType6 = ASTNULL; 
/* 1995 */             switch (aSTNULLType6.getType()) {
/*      */               
/*      */               case 129:
/* 1998 */                 parameterTypeList((AST)aSTNULLType6);
/* 1999 */                 aST6 = this._retTree;
/*      */                 break;
/*      */ 
/*      */ 
/*      */               
/*      */               case 42:
/*      */               case 48:
/* 2006 */                 if (aST6 == null) aSTNULLType5 = ASTNULL; 
/* 2007 */                 switch (aSTNULLType5.getType()) {
/*      */                   
/*      */                   case 42:
/* 2010 */                     idList((AST)aSTNULLType5);
/* 2011 */                     aST5 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */                 } 
/*      */ 
/*      */                 
/* 2020 */                 throw new NoViableAltException(aST5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               default:
/* 2028 */                 throw new NoViableAltException(aST5);
/*      */             } 
/*      */ 
/*      */             
/* 2032 */             tNode7 = (TNode)aST5;
/* 2033 */             match(aST5, 48);
/* 2034 */             aST5 = aST5.getNextSibling();
/* 2035 */             aSTNULLType4 = aSTNULLType8;
/* 2036 */             aST4 = aSTNULLType4.getNextSibling();
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 49:
/* 2041 */             tNode6 = (TNode)aST4;
/* 2042 */             match(aST4, 49);
/* 2043 */             aST4 = aST4.getNextSibling();
/*      */             
/* 2045 */             if (aST4 == null) aSTNULLType3 = ASTNULL; 
/* 2046 */             switch (aSTNULLType3.getType()) {
/*      */               
/*      */               case 42:
/*      */               case 45:
/*      */               case 46:
/*      */               case 47:
/*      */               case 64:
/*      */               case 65:
/*      */               case 66:
/*      */               case 67:
/*      */               case 68:
/*      */               case 69:
/*      */               case 70:
/*      */               case 71:
/*      */               case 72:
/*      */               case 73:
/*      */               case 74:
/*      */               case 75:
/*      */               case 76:
/*      */               case 77:
/*      */               case 78:
/*      */               case 79:
/*      */               case 80:
/*      */               case 81:
/*      */               case 82:
/*      */               case 83:
/*      */               case 84:
/*      */               case 85:
/*      */               case 86:
/*      */               case 87:
/*      */               case 88:
/*      */               case 89:
/*      */               case 90:
/*      */               case 91:
/*      */               case 92:
/*      */               case 93:
/*      */               case 94:
/*      */               case 99:
/*      */               case 118:
/*      */               case 120:
/*      */               case 123:
/*      */               case 125:
/*      */               case 130:
/*      */               case 131:
/*      */               case 133:
/*      */               case 134:
/*      */               case 135:
/*      */               case 137:
/*      */               case 139:
/*      */               case 158:
/*      */               case 164:
/* 2097 */                 expr((AST)aSTNULLType3);
/* 2098 */                 aST3 = this._retTree;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 50:
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 2107 */                 throw new NoViableAltException(aST3);
/*      */             } 
/*      */ 
/*      */             
/* 2111 */             tNode5 = (TNode)aST3;
/* 2112 */             match(aST3, 50);
/* 2113 */             aST3 = aST3.getNextSibling();
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2123 */       aST = aST2;
/* 2124 */       aST = aST.getNextSibling();
/*      */     }
/* 2126 */     catch (RecognitionException recognitionException) {
/* 2127 */       if (this.inputState.guessing == 0) {
/* 2128 */         reportError(recognitionException);
/* 2129 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2131 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2134 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void enumList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2139 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 2143 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 2146 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2147 */         if (aSTNULLType.getType() == 42) {
/* 2148 */           enumerator((AST)aSTNULLType);
/* 2149 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 2152 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 2155 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 2159 */     catch (RecognitionException recognitionException) {
/* 2160 */       if (this.inputState.guessing == 0) {
/* 2161 */         reportError(recognitionException);
/* 2162 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2164 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2167 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void enumerator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2172 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 2175 */       TNode tNode2, tNode1 = (TNode)paramAST;
/* 2176 */       match(paramAST, 42);
/* 2177 */       paramAST = paramAST.getNextSibling();
/*      */       
/* 2179 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2180 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/* 2183 */           tNode2 = (TNode)aSTNULLType;
/* 2184 */           match((AST)aSTNULLType, 45);
/* 2185 */           aST = aSTNULLType.getNextSibling();
/* 2186 */           expr(aST);
/* 2187 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 42:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2197 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 2202 */     } catch (RecognitionException recognitionException) {
/* 2203 */       if (this.inputState.guessing == 0) {
/* 2204 */         reportError(recognitionException);
/* 2205 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2207 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2210 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void initDecl(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2215 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2216 */     String str = ""; try {
/*      */       AST aST1; ASTNULLType aSTNULLType;
/*      */       TNode tNode2;
/* 2219 */       AST aST2 = paramAST;
/* 2220 */       TNode tNode1 = (TNode)paramAST;
/* 2221 */       match(paramAST, 114);
/* 2222 */       paramAST = paramAST.getFirstChild();
/* 2223 */       declarator(paramAST);
/* 2224 */       paramAST = this._retTree;
/*      */ 
/*      */       
/*      */       while (true) {
/* 2228 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2229 */         if (aSTNULLType.getType() == 138 || aSTNULLType.getType() == 163) {
/* 2230 */           attributeDecl((AST)aSTNULLType);
/* 2231 */           aST1 = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 2240 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/* 2241 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/* 2244 */           tNode2 = (TNode)aSTNULLType;
/* 2245 */           match((AST)aSTNULLType, 45);
/* 2246 */           aST = aSTNULLType.getNextSibling();
/* 2247 */           initializer(aST);
/* 2248 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/* 2253 */           tNode2 = (TNode)aST;
/* 2254 */           match(aST, 44);
/* 2255 */           aST = aST.getNextSibling();
/* 2256 */           expr(aST);
/* 2257 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2266 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 2270 */       aST = aST2;
/* 2271 */       aST = aST.getNextSibling();
/*      */     }
/* 2273 */     catch (RecognitionException recognitionException) {
/* 2274 */       if (this.inputState.guessing == 0) {
/* 2275 */         reportError(recognitionException);
/* 2276 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2278 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2281 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void initializer(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2286 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType4;
/*      */       TNode tNode1;
/* 2289 */       if (paramAST == null) aSTNULLType3 = ASTNULL; 
/* 2290 */       switch (aSTNULLType3.getType()) {
/*      */         
/*      */         case 123:
/* 2293 */           aSTNULLType4 = aSTNULLType3;
/* 2294 */           tNode1 = (TNode)aSTNULLType3;
/* 2295 */           match((AST)aSTNULLType3, 123);
/* 2296 */           aST2 = aSTNULLType3.getFirstChild();
/*      */           
/* 2298 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 2299 */           switch (aSTNULLType2.getType()) {
/*      */             
/*      */             case 136:
/* 2302 */               initializerElementLabel((AST)aSTNULLType2);
/* 2303 */               aST1 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 42:
/*      */             case 45:
/*      */             case 46:
/*      */             case 47:
/*      */             case 64:
/*      */             case 65:
/*      */             case 66:
/*      */             case 67:
/*      */             case 68:
/*      */             case 69:
/*      */             case 70:
/*      */             case 71:
/*      */             case 72:
/*      */             case 73:
/*      */             case 74:
/*      */             case 75:
/*      */             case 76:
/*      */             case 77:
/*      */             case 78:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/*      */             case 82:
/*      */             case 83:
/*      */             case 84:
/*      */             case 85:
/*      */             case 86:
/*      */             case 87:
/*      */             case 88:
/*      */             case 89:
/*      */             case 90:
/*      */             case 91:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 99:
/*      */             case 118:
/*      */             case 120:
/*      */             case 123:
/*      */             case 125:
/*      */             case 130:
/*      */             case 131:
/*      */             case 133:
/*      */             case 134:
/*      */             case 135:
/*      */             case 137:
/*      */             case 139:
/*      */             case 158:
/*      */             case 164:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 2360 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 2364 */           expr(aST1);
/* 2365 */           aST1 = this._retTree;
/* 2366 */           aSTNULLType1 = aSTNULLType4;
/* 2367 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 137:
/* 2372 */           lcurlyInitializer(aST);
/* 2373 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2378 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 2382 */     } catch (RecognitionException recognitionException) {
/* 2383 */       if (this.inputState.guessing == 0) {
/* 2384 */         reportError(recognitionException);
/* 2385 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2387 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2390 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void pointerGroup(AST paramAST) throws RecognitionException {
/* 2395 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 2398 */       AST aST = paramAST;
/* 2399 */       TNode tNode1 = (TNode)paramAST;
/* 2400 */       match(paramAST, 119);
/* 2401 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 2403 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/* 2406 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2407 */         if (aSTNULLType.getType() == 46) {
/* 2408 */           TNode tNode2 = (TNode)aSTNULLType;
/* 2409 */           match((AST)aSTNULLType, 46);
/* 2410 */           aST1 = aSTNULLType.getNextSibling();
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType1;
/* 2414 */             if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 2415 */             if (aSTNULLType1.getType() == 6 || aSTNULLType1.getType() == 17) {
/* 2416 */               typeQualifier((AST)aSTNULLType1);
/* 2417 */               aST1 = this._retTree;
/*      */ 
/*      */               
/*      */               continue;
/*      */             } 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } else {
/* 2427 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 2430 */         b++;
/*      */       } 
/*      */       
/* 2433 */       paramAST = aST;
/* 2434 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 2436 */     catch (RecognitionException recognitionException) {
/* 2437 */       if (this.inputState.guessing == 0) {
/* 2438 */         reportError(recognitionException);
/* 2439 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 2441 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2444 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void idList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2449 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 2452 */       TNode tNode1 = (TNode)paramAST;
/* 2453 */       match(paramAST, 42);
/* 2454 */       paramAST = paramAST.getNextSibling();
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 2458 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2459 */         if (aSTNULLType.getType() == 43) {
/* 2460 */           TNode tNode2 = (TNode)aSTNULLType;
/* 2461 */           match((AST)aSTNULLType, 43);
/* 2462 */           aST = aSTNULLType.getNextSibling();
/* 2463 */           TNode tNode3 = (TNode)aST;
/* 2464 */           match(aST, 42);
/* 2465 */           aST = aST.getNextSibling();
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2474 */     } catch (RecognitionException recognitionException) {
/* 2475 */       if (this.inputState.guessing == 0) {
/* 2476 */         reportError(recognitionException);
/* 2477 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2479 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2482 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void initializerElementLabel(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2487 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1;
/*      */       TNode tNode2, tNode3, tNode4;
/* 2490 */       AST aST2 = paramAST;
/* 2491 */       TNode tNode1 = (TNode)paramAST;
/* 2492 */       match(paramAST, 136);
/* 2493 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 2495 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 2496 */       switch (aSTNULLType2.getType()) {
/*      */ 
/*      */         
/*      */         case 49:
/* 2500 */           tNode2 = (TNode)aSTNULLType2;
/* 2501 */           match((AST)aSTNULLType2, 49);
/* 2502 */           aST1 = aSTNULLType2.getNextSibling();
/* 2503 */           expr(aST1);
/* 2504 */           aST1 = this._retTree;
/* 2505 */           tNode3 = (TNode)aST1;
/* 2506 */           match(aST1, 50);
/* 2507 */           aST1 = aST1.getNextSibling();
/*      */           
/* 2509 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 2510 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 45:
/* 2513 */               tNode4 = (TNode)aSTNULLType1;
/* 2514 */               match((AST)aSTNULLType1, 45);
/* 2515 */               aST = aSTNULLType1.getNextSibling();
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/* 2524 */           throw new NoViableAltException(aST);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 42:
/* 2533 */           tNode2 = (TNode)aST;
/* 2534 */           match(aST, 42);
/* 2535 */           aST = aST.getNextSibling();
/* 2536 */           tNode3 = (TNode)aST;
/* 2537 */           match(aST, 44);
/* 2538 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 98:
/* 2543 */           tNode2 = (TNode)aST;
/* 2544 */           match(aST, 98);
/* 2545 */           aST = aST.getNextSibling();
/* 2546 */           tNode3 = (TNode)aST;
/* 2547 */           match(aST, 42);
/* 2548 */           aST = aST.getNextSibling();
/* 2549 */           tNode4 = (TNode)aST;
/* 2550 */           match(aST, 45);
/* 2551 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2556 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 2560 */       aST = aST2;
/* 2561 */       aST = aST.getNextSibling();
/*      */     }
/* 2563 */     catch (RecognitionException recognitionException) {
/* 2564 */       if (this.inputState.guessing == 0) {
/* 2565 */         reportError(recognitionException);
/* 2566 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2568 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2571 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void lcurlyInitializer(AST paramAST) throws RecognitionException {
/* 2576 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 2579 */       AST aST = paramAST;
/* 2580 */       TNode tNode1 = (TNode)paramAST;
/* 2581 */       match(paramAST, 137);
/* 2582 */       paramAST = paramAST.getFirstChild();
/* 2583 */       initializerList(paramAST);
/* 2584 */       paramAST = this._retTree;
/* 2585 */       TNode tNode2 = (TNode)paramAST;
/* 2586 */       match(paramAST, 8);
/* 2587 */       paramAST = paramAST.getNextSibling();
/* 2588 */       paramAST = aST;
/* 2589 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 2591 */     catch (RecognitionException recognitionException) {
/* 2592 */       if (this.inputState.guessing == 0) {
/* 2593 */         reportError(recognitionException);
/* 2594 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 2596 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2599 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void initializerList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2604 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         
/* 2610 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2611 */         if (aSTNULLType.getType() == 123 || aSTNULLType.getType() == 137) {
/* 2612 */           initializer((AST)aSTNULLType);
/* 2613 */           aST = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2622 */     } catch (RecognitionException recognitionException) {
/* 2623 */       if (this.inputState.guessing == 0) {
/* 2624 */         reportError(recognitionException);
/* 2625 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2627 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2630 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void parameterTypeList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2635 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       AST aST1;
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 2639 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 2642 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2643 */         if (aSTNULLType.getType() == 129) {
/* 2644 */           ASTNULLType aSTNULLType1; TNode tNode2; parameterDeclaration((AST)aSTNULLType);
/* 2645 */           AST aST2 = this._retTree;
/*      */           
/* 2647 */           if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 2648 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 43:
/* 2651 */               tNode2 = (TNode)aSTNULLType1;
/* 2652 */               match((AST)aSTNULLType1, 43);
/* 2653 */               aST1 = aSTNULLType1.getNextSibling();
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/* 2658 */               tNode2 = (TNode)aST1;
/* 2659 */               match(aST1, 9);
/* 2660 */               aST1 = aST1.getNextSibling();
/*      */               break;
/*      */ 
/*      */             
/*      */             case 48:
/*      */             case 51:
/*      */             case 129:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 2671 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*      */         } else {
/* 2677 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 2680 */         b++;
/*      */       } 
/*      */ 
/*      */       
/* 2684 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/* 2685 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 51:
/* 2688 */           tNode1 = (TNode)aSTNULLType;
/* 2689 */           match((AST)aSTNULLType, 51);
/* 2690 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2699 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 2704 */     } catch (RecognitionException recognitionException) {
/* 2705 */       if (this.inputState.guessing == 0) {
/* 2706 */         reportError(recognitionException);
/* 2707 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2709 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2712 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void parameterDeclaration(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2717 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 2720 */       AST aST1 = paramAST;
/* 2721 */       TNode tNode1 = (TNode)paramAST;
/* 2722 */       match(paramAST, 129);
/* 2723 */       paramAST = paramAST.getFirstChild();
/* 2724 */       declSpecifiers(paramAST);
/* 2725 */       paramAST = this._retTree;
/*      */       
/* 2727 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2728 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 115:
/* 2731 */           declarator((AST)aSTNULLType);
/* 2732 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 122:
/* 2737 */           nonemptyAbstractDeclarator(aST);
/* 2738 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2747 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 2751 */       aST = aST1;
/* 2752 */       aST = aST.getNextSibling();
/*      */     }
/* 2754 */     catch (RecognitionException recognitionException) {
/* 2755 */       if (this.inputState.guessing == 0) {
/* 2756 */         reportError(recognitionException);
/* 2757 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2759 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2762 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void nonemptyAbstractDeclarator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2767 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       byte b;
/* 2770 */       AST aST1 = paramAST;
/* 2771 */       TNode tNode1 = (TNode)paramAST;
/* 2772 */       match(paramAST, 122);
/* 2773 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 2775 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2776 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 119:
/* 2779 */           pointerGroup((AST)aSTNULLType);
/* 2780 */           aST = this._retTree; while (true) {
/*      */             ASTNULLType aSTNULLType3; AST aST3; ASTNULLType aSTNULLType2; AST aST2; ASTNULLType aSTNULLType1;
/*      */             TNode tNode2;
/*      */             TNode tNode3;
/* 2784 */             if (aST == null) aSTNULLType3 = ASTNULL; 
/* 2785 */             switch (aSTNULLType3.getType()) {
/*      */ 
/*      */               
/*      */               case 47:
/* 2789 */                 tNode2 = (TNode)aSTNULLType3;
/* 2790 */                 match((AST)aSTNULLType3, 47);
/* 2791 */                 aST3 = aSTNULLType3.getNextSibling();
/*      */                 
/* 2793 */                 if (aST3 == null) aSTNULLType2 = ASTNULL; 
/* 2794 */                 switch (aSTNULLType2.getType()) {
/*      */                   
/*      */                   case 122:
/* 2797 */                     nonemptyAbstractDeclarator((AST)aSTNULLType2);
/* 2798 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 129:
/* 2803 */                     parameterTypeList(aST2);
/* 2804 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 2813 */                     throw new NoViableAltException(aST2);
/*      */                 } 
/*      */ 
/*      */                 
/* 2817 */                 tNode3 = (TNode)aST2;
/* 2818 */                 match(aST2, 48);
/* 2819 */                 aST2 = aST2.getNextSibling();
/*      */                 continue;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 2826 */                 tNode2 = (TNode)aST2;
/* 2827 */                 match(aST2, 49);
/* 2828 */                 aST2 = aST2.getNextSibling();
/*      */                 
/* 2830 */                 if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 2831 */                 switch (aSTNULLType1.getType()) {
/*      */                   
/*      */                   case 42:
/*      */                   case 45:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 64:
/*      */                   case 65:
/*      */                   case 66:
/*      */                   case 67:
/*      */                   case 68:
/*      */                   case 69:
/*      */                   case 70:
/*      */                   case 71:
/*      */                   case 72:
/*      */                   case 73:
/*      */                   case 74:
/*      */                   case 75:
/*      */                   case 76:
/*      */                   case 77:
/*      */                   case 78:
/*      */                   case 79:
/*      */                   case 80:
/*      */                   case 81:
/*      */                   case 82:
/*      */                   case 83:
/*      */                   case 84:
/*      */                   case 85:
/*      */                   case 86:
/*      */                   case 87:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 90:
/*      */                   case 91:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 99:
/*      */                   case 118:
/*      */                   case 120:
/*      */                   case 123:
/*      */                   case 125:
/*      */                   case 130:
/*      */                   case 131:
/*      */                   case 133:
/*      */                   case 134:
/*      */                   case 135:
/*      */                   case 137:
/*      */                   case 139:
/*      */                   case 158:
/*      */                   case 164:
/* 2882 */                     expr((AST)aSTNULLType1);
/* 2883 */                     aST = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 2892 */                     throw new NoViableAltException(aST);
/*      */                 } 
/*      */ 
/*      */                 
/* 2896 */                 tNode3 = (TNode)aST;
/* 2897 */                 match(aST, 50);
/* 2898 */                 aST = aST.getNextSibling();
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 47:
/*      */         case 49:
/* 2915 */           b = 0; while (true) {
/*      */             ASTNULLType aSTNULLType3; AST aST3; ASTNULLType aSTNULLType2; AST aST2; ASTNULLType aSTNULLType1;
/*      */             TNode tNode2, tNode3;
/* 2918 */             if (aST == null) aSTNULLType3 = ASTNULL; 
/* 2919 */             switch (aSTNULLType3.getType()) {
/*      */ 
/*      */               
/*      */               case 47:
/* 2923 */                 tNode2 = (TNode)aSTNULLType3;
/* 2924 */                 match((AST)aSTNULLType3, 47);
/* 2925 */                 aST3 = aSTNULLType3.getNextSibling();
/*      */                 
/* 2927 */                 if (aST3 == null) aSTNULLType2 = ASTNULL; 
/* 2928 */                 switch (aSTNULLType2.getType()) {
/*      */                   
/*      */                   case 122:
/* 2931 */                     nonemptyAbstractDeclarator((AST)aSTNULLType2);
/* 2932 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 129:
/* 2937 */                     parameterTypeList(aST2);
/* 2938 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 2947 */                     throw new NoViableAltException(aST2);
/*      */                 } 
/*      */ 
/*      */                 
/* 2951 */                 tNode3 = (TNode)aST2;
/* 2952 */                 match(aST2, 48);
/* 2953 */                 aST2 = aST2.getNextSibling();
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 2960 */                 tNode2 = (TNode)aST2;
/* 2961 */                 match(aST2, 49);
/* 2962 */                 aST2 = aST2.getNextSibling();
/*      */                 
/* 2964 */                 if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 2965 */                 switch (aSTNULLType1.getType()) {
/*      */                   
/*      */                   case 42:
/*      */                   case 45:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 64:
/*      */                   case 65:
/*      */                   case 66:
/*      */                   case 67:
/*      */                   case 68:
/*      */                   case 69:
/*      */                   case 70:
/*      */                   case 71:
/*      */                   case 72:
/*      */                   case 73:
/*      */                   case 74:
/*      */                   case 75:
/*      */                   case 76:
/*      */                   case 77:
/*      */                   case 78:
/*      */                   case 79:
/*      */                   case 80:
/*      */                   case 81:
/*      */                   case 82:
/*      */                   case 83:
/*      */                   case 84:
/*      */                   case 85:
/*      */                   case 86:
/*      */                   case 87:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 90:
/*      */                   case 91:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 99:
/*      */                   case 118:
/*      */                   case 120:
/*      */                   case 123:
/*      */                   case 125:
/*      */                   case 130:
/*      */                   case 131:
/*      */                   case 133:
/*      */                   case 134:
/*      */                   case 135:
/*      */                   case 137:
/*      */                   case 139:
/*      */                   case 158:
/*      */                   case 164:
/* 3016 */                     expr((AST)aSTNULLType1);
/* 3017 */                     aST = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 3026 */                     throw new NoViableAltException(aST);
/*      */                 } 
/*      */ 
/*      */                 
/* 3030 */                 tNode3 = (TNode)aST;
/* 3031 */                 match(aST, 50);
/* 3032 */                 aST = aST.getNextSibling();
/*      */                 break;
/*      */ 
/*      */ 
/*      */               
/*      */               default:
/* 3038 */                 if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */             } 
/*      */             
/* 3041 */             b++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 3048 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3052 */       aST = aST1;
/* 3053 */       aST = aST.getNextSibling();
/*      */     }
/* 3055 */     catch (RecognitionException recognitionException) {
/* 3056 */       if (this.inputState.guessing == 0) {
/* 3057 */         reportError(recognitionException);
/* 3058 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3060 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3063 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void functionDeclSpecifiers(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3068 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 3072 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3075 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3076 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 15:
/*      */           case 16:
/*      */           case 160:
/* 3081 */             functionStorageClassSpecifier((AST)aSTNULLType);
/* 3082 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/* 3088 */             typeQualifier(aST);
/* 3089 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 3123 */             typeSpecifier(aST);
/* 3124 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 3129 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3132 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3136 */     catch (RecognitionException recognitionException) {
/* 3137 */       if (this.inputState.guessing == 0) {
/* 3138 */         reportError(recognitionException);
/* 3139 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3141 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3144 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void compoundStatement(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3149 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       AST aST1;
/*      */       ASTNULLType aSTNULLType;
/* 3152 */       AST aST2 = paramAST;
/* 3153 */       TNode tNode1 = (TNode)paramAST;
/* 3154 */       match(paramAST, 128);
/* 3155 */       paramAST = paramAST.getFirstChild();
/*      */ 
/*      */       
/*      */       while (true) {
/* 3159 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3160 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 117:
/*      */           case 159:
/* 3164 */             declarationList((AST)aSTNULLType);
/* 3165 */             aST1 = this._retTree;
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 127:
/* 3170 */             functionDef(aST1);
/* 3171 */             aST1 = this._retTree;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 3182 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/* 3183 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 9:
/*      */         case 52:
/*      */         case 53:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 63:
/*      */         case 124:
/*      */         case 128:
/*      */         case 132:
/* 3200 */           statementList((AST)aSTNULLType);
/* 3201 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3210 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3214 */       TNode tNode2 = (TNode)aST;
/* 3215 */       match(aST, 8);
/* 3216 */       aST = aST.getNextSibling();
/* 3217 */       aST = aST2;
/* 3218 */       aST = aST.getNextSibling();
/*      */     }
/* 3220 */     catch (RecognitionException recognitionException) {
/* 3221 */       if (this.inputState.guessing == 0) {
/* 3222 */         reportError(recognitionException);
/* 3223 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3225 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3228 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declarationList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3233 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 3237 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3240 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3241 */         if (aSTNULLType.getType() == 159) {
/* 3242 */           localLabelDecl((AST)aSTNULLType);
/* 3243 */           aST = this._retTree;
/*      */         }
/* 3245 */         else if (aST.getType() == 117) {
/* 3246 */           declaration(aST);
/* 3247 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 3250 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3253 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3257 */     catch (RecognitionException recognitionException) {
/* 3258 */       if (this.inputState.guessing == 0) {
/* 3259 */         reportError(recognitionException);
/* 3260 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3262 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3265 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void localLabelDecl(AST paramAST) throws RecognitionException {
/* 3270 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 3273 */       AST aST = paramAST;
/* 3274 */       TNode tNode1 = (TNode)paramAST;
/* 3275 */       match(paramAST, 159);
/* 3276 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 3278 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/* 3281 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3282 */         if (aSTNULLType.getType() == 42) {
/* 3283 */           TNode tNode2 = (TNode)aSTNULLType;
/* 3284 */           match((AST)aSTNULLType, 42);
/* 3285 */           aST1 = aSTNULLType.getNextSibling();
/*      */         } else {
/*      */           
/* 3288 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 3291 */         b++;
/*      */       } 
/*      */       
/* 3294 */       paramAST = aST;
/* 3295 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 3297 */     catch (RecognitionException recognitionException) {
/* 3298 */       if (this.inputState.guessing == 0) {
/* 3299 */         reportError(recognitionException);
/* 3300 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 3302 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3305 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void statementList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3310 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 3314 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3317 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3318 */         if (_tokenSet_2.member(aSTNULLType.getType())) {
/* 3319 */           statement((AST)aSTNULLType);
/* 3320 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 3323 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3326 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3330 */     catch (RecognitionException recognitionException) {
/* 3331 */       if (this.inputState.guessing == 0) {
/* 3332 */         reportError(recognitionException);
/* 3333 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3335 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3338 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void statement(AST paramAST) throws RecognitionException {
/* 3343 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 3346 */       statementBody(paramAST);
/* 3347 */       paramAST = this._retTree;
/*      */     }
/* 3349 */     catch (RecognitionException recognitionException) {
/* 3350 */       if (this.inputState.guessing == 0) {
/* 3351 */         reportError(recognitionException);
/* 3352 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 3354 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3357 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void statementBody(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3362 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType6; AST aST5; ASTNULLType aSTNULLType5; AST aST4; ASTNULLType aSTNULLType4; AST aST3; ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; TNode tNode2; AST aST7; TNode tNode1; AST aST6; TNode tNode3;
/*      */       TNode tNode4;
/* 3365 */       if (paramAST == null) aSTNULLType6 = ASTNULL; 
/* 3366 */       switch (aSTNULLType6.getType()) {
/*      */         
/*      */         case 9:
/* 3369 */           tNode2 = (TNode)aSTNULLType6;
/* 3370 */           match((AST)aSTNULLType6, 9);
/* 3371 */           aST5 = aSTNULLType6.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 128:
/* 3376 */           compoundStatement(aST5);
/* 3377 */           aST5 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 124:
/* 3382 */           aST7 = aST5;
/* 3383 */           tNode3 = (TNode)aST5;
/* 3384 */           match(aST5, 124);
/* 3385 */           aST5 = aST5.getFirstChild();
/* 3386 */           expr(aST5);
/* 3387 */           aST5 = this._retTree;
/* 3388 */           aST5 = aST7;
/* 3389 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 52:
/* 3394 */           aST7 = aST5;
/* 3395 */           tNode3 = (TNode)aST5;
/* 3396 */           match(aST5, 52);
/* 3397 */           aST5 = aST5.getFirstChild();
/* 3398 */           expr(aST5);
/* 3399 */           aST5 = this._retTree;
/* 3400 */           statement(aST5);
/* 3401 */           aST5 = this._retTree;
/* 3402 */           aST5 = aST7;
/* 3403 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 53:
/* 3408 */           aST7 = aST5;
/* 3409 */           tNode3 = (TNode)aST5;
/* 3410 */           match(aST5, 53);
/* 3411 */           aST5 = aST5.getFirstChild();
/* 3412 */           statement(aST5);
/* 3413 */           aST5 = this._retTree;
/* 3414 */           expr(aST5);
/* 3415 */           aST5 = this._retTree;
/* 3416 */           aST5 = aST7;
/* 3417 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 54:
/* 3422 */           aST7 = aST5;
/* 3423 */           tNode3 = (TNode)aST5;
/* 3424 */           match(aST5, 54);
/* 3425 */           aST5 = aST5.getFirstChild();
/* 3426 */           expr(aST5);
/* 3427 */           aST5 = this._retTree;
/* 3428 */           expr(aST5);
/* 3429 */           aST5 = this._retTree;
/* 3430 */           expr(aST5);
/* 3431 */           aST5 = this._retTree;
/* 3432 */           statement(aST5);
/* 3433 */           aST5 = this._retTree;
/* 3434 */           aST5 = aST7;
/* 3435 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 55:
/* 3440 */           aST7 = aST5;
/* 3441 */           tNode3 = (TNode)aST5;
/* 3442 */           match(aST5, 55);
/* 3443 */           aST5 = aST5.getFirstChild();
/* 3444 */           expr(aST5);
/* 3445 */           aST5 = this._retTree;
/* 3446 */           aST5 = aST7;
/* 3447 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 56:
/* 3452 */           tNode1 = (TNode)aST5;
/* 3453 */           match(aST5, 56);
/* 3454 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 57:
/* 3459 */           tNode1 = (TNode)aST5;
/* 3460 */           match(aST5, 57);
/* 3461 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 58:
/* 3466 */           aST6 = aST5;
/* 3467 */           tNode3 = (TNode)aST5;
/* 3468 */           match(aST5, 58);
/* 3469 */           aST5 = aST5.getFirstChild();
/*      */           
/* 3471 */           if (aST5 == null) aSTNULLType5 = ASTNULL; 
/* 3472 */           switch (aSTNULLType5.getType()) {
/*      */             
/*      */             case 42:
/*      */             case 45:
/*      */             case 46:
/*      */             case 47:
/*      */             case 64:
/*      */             case 65:
/*      */             case 66:
/*      */             case 67:
/*      */             case 68:
/*      */             case 69:
/*      */             case 70:
/*      */             case 71:
/*      */             case 72:
/*      */             case 73:
/*      */             case 74:
/*      */             case 75:
/*      */             case 76:
/*      */             case 77:
/*      */             case 78:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/*      */             case 82:
/*      */             case 83:
/*      */             case 84:
/*      */             case 85:
/*      */             case 86:
/*      */             case 87:
/*      */             case 88:
/*      */             case 89:
/*      */             case 90:
/*      */             case 91:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 99:
/*      */             case 118:
/*      */             case 120:
/*      */             case 123:
/*      */             case 125:
/*      */             case 130:
/*      */             case 131:
/*      */             case 133:
/*      */             case 134:
/*      */             case 135:
/*      */             case 137:
/*      */             case 139:
/*      */             case 158:
/*      */             case 164:
/* 3523 */               expr((AST)aSTNULLType5);
/* 3524 */               aST4 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3533 */               throw new NoViableAltException(aST4);
/*      */           } 
/*      */ 
/*      */           
/* 3537 */           aST4 = aST6;
/* 3538 */           aST4 = aST4.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 132:
/* 3543 */           aST6 = aST4;
/* 3544 */           tNode3 = (TNode)aST4;
/* 3545 */           match(aST4, 132);
/* 3546 */           aST4 = aST4.getFirstChild();
/* 3547 */           tNode4 = (TNode)aST4;
/* 3548 */           match(aST4, 42);
/* 3549 */           aST4 = aST4.getNextSibling();
/*      */           
/* 3551 */           if (aST4 == null) aSTNULLType4 = ASTNULL; 
/* 3552 */           switch (aSTNULLType4.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 3569 */               statement((AST)aSTNULLType4);
/* 3570 */               aST3 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3579 */               throw new NoViableAltException(aST3);
/*      */           } 
/*      */ 
/*      */           
/* 3583 */           aST3 = aST6;
/* 3584 */           aST3 = aST3.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 59:
/* 3589 */           aST6 = aST3;
/* 3590 */           tNode3 = (TNode)aST3;
/* 3591 */           match(aST3, 59);
/* 3592 */           aST3 = aST3.getFirstChild();
/* 3593 */           expr(aST3);
/* 3594 */           aST3 = this._retTree;
/*      */           
/* 3596 */           if (aST3 == null) aSTNULLType3 = ASTNULL; 
/* 3597 */           switch (aSTNULLType3.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 3614 */               statement((AST)aSTNULLType3);
/* 3615 */               aST2 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3624 */               throw new NoViableAltException(aST2);
/*      */           } 
/*      */ 
/*      */           
/* 3628 */           aST2 = aST6;
/* 3629 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 60:
/* 3634 */           aST6 = aST2;
/* 3635 */           tNode3 = (TNode)aST2;
/* 3636 */           match(aST2, 60);
/* 3637 */           aST2 = aST2.getFirstChild();
/*      */           
/* 3639 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 3640 */           switch (aSTNULLType2.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 3657 */               statement((AST)aSTNULLType2);
/* 3658 */               aST1 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3667 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 3671 */           aST1 = aST6;
/* 3672 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 61:
/* 3677 */           aST6 = aST1;
/* 3678 */           tNode3 = (TNode)aST1;
/* 3679 */           match(aST1, 61);
/* 3680 */           aST1 = aST1.getFirstChild();
/* 3681 */           expr(aST1);
/* 3682 */           aST1 = this._retTree;
/* 3683 */           statement(aST1);
/* 3684 */           aST1 = this._retTree;
/*      */           
/* 3686 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 3687 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 62:
/* 3690 */               tNode4 = (TNode)aSTNULLType1;
/* 3691 */               match((AST)aSTNULLType1, 62);
/* 3692 */               aST = aSTNULLType1.getNextSibling();
/* 3693 */               statement(aST);
/* 3694 */               aST = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3703 */               throw new NoViableAltException(aST);
/*      */           } 
/*      */ 
/*      */           
/* 3707 */           aST = aST6;
/* 3708 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 63:
/* 3713 */           aST6 = aST;
/* 3714 */           tNode3 = (TNode)aST;
/* 3715 */           match(aST, 63);
/* 3716 */           aST = aST.getFirstChild();
/* 3717 */           expr(aST);
/* 3718 */           aST = this._retTree;
/* 3719 */           statement(aST);
/* 3720 */           aST = this._retTree;
/* 3721 */           aST = aST6;
/* 3722 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3727 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 3731 */     } catch (RecognitionException recognitionException) {
/* 3732 */       if (this.inputState.guessing == 0) {
/* 3733 */         reportError(recognitionException);
/* 3734 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3736 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3739 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void assignExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3744 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 3747 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 3748 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 45:
/* 3751 */           aSTNULLType3 = aSTNULLType2;
/* 3752 */           tNode1 = (TNode)aSTNULLType2;
/* 3753 */           match((AST)aSTNULLType2, 45);
/* 3754 */           aST1 = aSTNULLType2.getFirstChild();
/* 3755 */           expr(aST1);
/* 3756 */           aST1 = this._retTree;
/* 3757 */           expr(aST1);
/* 3758 */           aST1 = this._retTree;
/* 3759 */           aSTNULLType1 = aSTNULLType3;
/* 3760 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 64:
/* 3765 */           aST2 = aST;
/* 3766 */           tNode1 = (TNode)aST;
/* 3767 */           match(aST, 64);
/* 3768 */           aST = aST.getFirstChild();
/* 3769 */           expr(aST);
/* 3770 */           aST = this._retTree;
/* 3771 */           expr(aST);
/* 3772 */           aST = this._retTree;
/* 3773 */           aST = aST2;
/* 3774 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 65:
/* 3779 */           aST2 = aST;
/* 3780 */           tNode1 = (TNode)aST;
/* 3781 */           match(aST, 65);
/* 3782 */           aST = aST.getFirstChild();
/* 3783 */           expr(aST);
/* 3784 */           aST = this._retTree;
/* 3785 */           expr(aST);
/* 3786 */           aST = this._retTree;
/* 3787 */           aST = aST2;
/* 3788 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 66:
/* 3793 */           aST2 = aST;
/* 3794 */           tNode1 = (TNode)aST;
/* 3795 */           match(aST, 66);
/* 3796 */           aST = aST.getFirstChild();
/* 3797 */           expr(aST);
/* 3798 */           aST = this._retTree;
/* 3799 */           expr(aST);
/* 3800 */           aST = this._retTree;
/* 3801 */           aST = aST2;
/* 3802 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 67:
/* 3807 */           aST2 = aST;
/* 3808 */           tNode1 = (TNode)aST;
/* 3809 */           match(aST, 67);
/* 3810 */           aST = aST.getFirstChild();
/* 3811 */           expr(aST);
/* 3812 */           aST = this._retTree;
/* 3813 */           expr(aST);
/* 3814 */           aST = this._retTree;
/* 3815 */           aST = aST2;
/* 3816 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 68:
/* 3821 */           aST2 = aST;
/* 3822 */           tNode1 = (TNode)aST;
/* 3823 */           match(aST, 68);
/* 3824 */           aST = aST.getFirstChild();
/* 3825 */           expr(aST);
/* 3826 */           aST = this._retTree;
/* 3827 */           expr(aST);
/* 3828 */           aST = this._retTree;
/* 3829 */           aST = aST2;
/* 3830 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 69:
/* 3835 */           aST2 = aST;
/* 3836 */           tNode1 = (TNode)aST;
/* 3837 */           match(aST, 69);
/* 3838 */           aST = aST.getFirstChild();
/* 3839 */           expr(aST);
/* 3840 */           aST = this._retTree;
/* 3841 */           expr(aST);
/* 3842 */           aST = this._retTree;
/* 3843 */           aST = aST2;
/* 3844 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 70:
/* 3849 */           aST2 = aST;
/* 3850 */           tNode1 = (TNode)aST;
/* 3851 */           match(aST, 70);
/* 3852 */           aST = aST.getFirstChild();
/* 3853 */           expr(aST);
/* 3854 */           aST = this._retTree;
/* 3855 */           expr(aST);
/* 3856 */           aST = this._retTree;
/* 3857 */           aST = aST2;
/* 3858 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 71:
/* 3863 */           aST2 = aST;
/* 3864 */           tNode1 = (TNode)aST;
/* 3865 */           match(aST, 71);
/* 3866 */           aST = aST.getFirstChild();
/* 3867 */           expr(aST);
/* 3868 */           aST = this._retTree;
/* 3869 */           expr(aST);
/* 3870 */           aST = this._retTree;
/* 3871 */           aST = aST2;
/* 3872 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 72:
/* 3877 */           aST2 = aST;
/* 3878 */           tNode1 = (TNode)aST;
/* 3879 */           match(aST, 72);
/* 3880 */           aST = aST.getFirstChild();
/* 3881 */           expr(aST);
/* 3882 */           aST = this._retTree;
/* 3883 */           expr(aST);
/* 3884 */           aST = this._retTree;
/* 3885 */           aST = aST2;
/* 3886 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 73:
/* 3891 */           aST2 = aST;
/* 3892 */           tNode1 = (TNode)aST;
/* 3893 */           match(aST, 73);
/* 3894 */           aST = aST.getFirstChild();
/* 3895 */           expr(aST);
/* 3896 */           aST = this._retTree;
/* 3897 */           expr(aST);
/* 3898 */           aST = this._retTree;
/* 3899 */           aST = aST2;
/* 3900 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3905 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 3909 */     } catch (RecognitionException recognitionException) {
/* 3910 */       if (this.inputState.guessing == 0) {
/* 3911 */         reportError(recognitionException);
/* 3912 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3914 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3917 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void conditionalExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3922 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 3925 */       AST aST1 = paramAST;
/* 3926 */       TNode tNode1 = (TNode)paramAST;
/* 3927 */       match(paramAST, 74);
/* 3928 */       paramAST = paramAST.getFirstChild();
/* 3929 */       expr(paramAST);
/* 3930 */       paramAST = this._retTree;
/*      */       
/* 3932 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3933 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 42:
/*      */         case 45:
/*      */         case 46:
/*      */         case 47:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 99:
/*      */         case 118:
/*      */         case 120:
/*      */         case 123:
/*      */         case 125:
/*      */         case 130:
/*      */         case 131:
/*      */         case 133:
/*      */         case 134:
/*      */         case 135:
/*      */         case 137:
/*      */         case 139:
/*      */         case 158:
/*      */         case 164:
/* 3984 */           expr((AST)aSTNULLType);
/* 3985 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3994 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3998 */       TNode tNode2 = (TNode)aST;
/* 3999 */       match(aST, 44);
/* 4000 */       aST = aST.getNextSibling();
/* 4001 */       expr(aST);
/* 4002 */       aST = this._retTree;
/* 4003 */       aST = aST1;
/* 4004 */       aST = aST.getNextSibling();
/*      */     }
/* 4006 */     catch (RecognitionException recognitionException) {
/* 4007 */       if (this.inputState.guessing == 0) {
/* 4008 */         reportError(recognitionException);
/* 4009 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4011 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4014 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalOrExpr(AST paramAST) throws RecognitionException {
/* 4019 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4022 */       AST aST = paramAST;
/* 4023 */       TNode tNode1 = (TNode)paramAST;
/* 4024 */       match(paramAST, 75);
/* 4025 */       paramAST = paramAST.getFirstChild();
/* 4026 */       expr(paramAST);
/* 4027 */       paramAST = this._retTree;
/* 4028 */       expr(paramAST);
/* 4029 */       paramAST = this._retTree;
/* 4030 */       paramAST = aST;
/* 4031 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4033 */     catch (RecognitionException recognitionException) {
/* 4034 */       if (this.inputState.guessing == 0) {
/* 4035 */         reportError(recognitionException);
/* 4036 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4038 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4041 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalAndExpr(AST paramAST) throws RecognitionException {
/* 4046 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4049 */       AST aST = paramAST;
/* 4050 */       TNode tNode1 = (TNode)paramAST;
/* 4051 */       match(paramAST, 76);
/* 4052 */       paramAST = paramAST.getFirstChild();
/* 4053 */       expr(paramAST);
/* 4054 */       paramAST = this._retTree;
/* 4055 */       expr(paramAST);
/* 4056 */       paramAST = this._retTree;
/* 4057 */       paramAST = aST;
/* 4058 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4060 */     catch (RecognitionException recognitionException) {
/* 4061 */       if (this.inputState.guessing == 0) {
/* 4062 */         reportError(recognitionException);
/* 4063 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4065 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4068 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void inclusiveOrExpr(AST paramAST) throws RecognitionException {
/* 4073 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4076 */       AST aST = paramAST;
/* 4077 */       TNode tNode1 = (TNode)paramAST;
/* 4078 */       match(paramAST, 77);
/* 4079 */       paramAST = paramAST.getFirstChild();
/* 4080 */       expr(paramAST);
/* 4081 */       paramAST = this._retTree;
/* 4082 */       expr(paramAST);
/* 4083 */       paramAST = this._retTree;
/* 4084 */       paramAST = aST;
/* 4085 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4087 */     catch (RecognitionException recognitionException) {
/* 4088 */       if (this.inputState.guessing == 0) {
/* 4089 */         reportError(recognitionException);
/* 4090 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4092 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4095 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void exclusiveOrExpr(AST paramAST) throws RecognitionException {
/* 4100 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4103 */       AST aST = paramAST;
/* 4104 */       TNode tNode1 = (TNode)paramAST;
/* 4105 */       match(paramAST, 78);
/* 4106 */       paramAST = paramAST.getFirstChild();
/* 4107 */       expr(paramAST);
/* 4108 */       paramAST = this._retTree;
/* 4109 */       expr(paramAST);
/* 4110 */       paramAST = this._retTree;
/* 4111 */       paramAST = aST;
/* 4112 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4114 */     catch (RecognitionException recognitionException) {
/* 4115 */       if (this.inputState.guessing == 0) {
/* 4116 */         reportError(recognitionException);
/* 4117 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4119 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4122 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void bitAndExpr(AST paramAST) throws RecognitionException {
/* 4127 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4130 */       AST aST = paramAST;
/* 4131 */       TNode tNode1 = (TNode)paramAST;
/* 4132 */       match(paramAST, 79);
/* 4133 */       paramAST = paramAST.getFirstChild();
/* 4134 */       expr(paramAST);
/* 4135 */       paramAST = this._retTree;
/* 4136 */       expr(paramAST);
/* 4137 */       paramAST = this._retTree;
/* 4138 */       paramAST = aST;
/* 4139 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4141 */     catch (RecognitionException recognitionException) {
/* 4142 */       if (this.inputState.guessing == 0) {
/* 4143 */         reportError(recognitionException);
/* 4144 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4146 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4149 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void equalityExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4154 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 4157 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4158 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 80:
/* 4161 */           aSTNULLType3 = aSTNULLType2;
/* 4162 */           tNode1 = (TNode)aSTNULLType2;
/* 4163 */           match((AST)aSTNULLType2, 80);
/* 4164 */           aST1 = aSTNULLType2.getFirstChild();
/* 4165 */           expr(aST1);
/* 4166 */           aST1 = this._retTree;
/* 4167 */           expr(aST1);
/* 4168 */           aST1 = this._retTree;
/* 4169 */           aSTNULLType1 = aSTNULLType3;
/* 4170 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 81:
/* 4175 */           aST2 = aST;
/* 4176 */           tNode1 = (TNode)aST;
/* 4177 */           match(aST, 81);
/* 4178 */           aST = aST.getFirstChild();
/* 4179 */           expr(aST);
/* 4180 */           aST = this._retTree;
/* 4181 */           expr(aST);
/* 4182 */           aST = this._retTree;
/* 4183 */           aST = aST2;
/* 4184 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4189 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4193 */     } catch (RecognitionException recognitionException) {
/* 4194 */       if (this.inputState.guessing == 0) {
/* 4195 */         reportError(recognitionException);
/* 4196 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4198 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4201 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void relationalExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4206 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 4209 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4210 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 82:
/* 4213 */           aSTNULLType3 = aSTNULLType2;
/* 4214 */           tNode1 = (TNode)aSTNULLType2;
/* 4215 */           match((AST)aSTNULLType2, 82);
/* 4216 */           aST1 = aSTNULLType2.getFirstChild();
/* 4217 */           expr(aST1);
/* 4218 */           aST1 = this._retTree;
/* 4219 */           expr(aST1);
/* 4220 */           aST1 = this._retTree;
/* 4221 */           aSTNULLType1 = aSTNULLType3;
/* 4222 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 83:
/* 4227 */           aST2 = aST;
/* 4228 */           tNode1 = (TNode)aST;
/* 4229 */           match(aST, 83);
/* 4230 */           aST = aST.getFirstChild();
/* 4231 */           expr(aST);
/* 4232 */           aST = this._retTree;
/* 4233 */           expr(aST);
/* 4234 */           aST = this._retTree;
/* 4235 */           aST = aST2;
/* 4236 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 84:
/* 4241 */           aST2 = aST;
/* 4242 */           tNode1 = (TNode)aST;
/* 4243 */           match(aST, 84);
/* 4244 */           aST = aST.getFirstChild();
/* 4245 */           expr(aST);
/* 4246 */           aST = this._retTree;
/* 4247 */           expr(aST);
/* 4248 */           aST = this._retTree;
/* 4249 */           aST = aST2;
/* 4250 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 85:
/* 4255 */           aST2 = aST;
/* 4256 */           tNode1 = (TNode)aST;
/* 4257 */           match(aST, 85);
/* 4258 */           aST = aST.getFirstChild();
/* 4259 */           expr(aST);
/* 4260 */           aST = this._retTree;
/* 4261 */           expr(aST);
/* 4262 */           aST = this._retTree;
/* 4263 */           aST = aST2;
/* 4264 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4269 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4273 */     } catch (RecognitionException recognitionException) {
/* 4274 */       if (this.inputState.guessing == 0) {
/* 4275 */         reportError(recognitionException);
/* 4276 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4278 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4281 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void shiftExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4286 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 4289 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4290 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 86:
/* 4293 */           aSTNULLType3 = aSTNULLType2;
/* 4294 */           tNode1 = (TNode)aSTNULLType2;
/* 4295 */           match((AST)aSTNULLType2, 86);
/* 4296 */           aST1 = aSTNULLType2.getFirstChild();
/* 4297 */           expr(aST1);
/* 4298 */           aST1 = this._retTree;
/* 4299 */           expr(aST1);
/* 4300 */           aST1 = this._retTree;
/* 4301 */           aSTNULLType1 = aSTNULLType3;
/* 4302 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 87:
/* 4307 */           aST2 = aST;
/* 4308 */           tNode1 = (TNode)aST;
/* 4309 */           match(aST, 87);
/* 4310 */           aST = aST.getFirstChild();
/* 4311 */           expr(aST);
/* 4312 */           aST = this._retTree;
/* 4313 */           expr(aST);
/* 4314 */           aST = this._retTree;
/* 4315 */           aST = aST2;
/* 4316 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4321 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4325 */     } catch (RecognitionException recognitionException) {
/* 4326 */       if (this.inputState.guessing == 0) {
/* 4327 */         reportError(recognitionException);
/* 4328 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4330 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4333 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void additiveExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4338 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 4341 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4342 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 88:
/* 4345 */           aSTNULLType3 = aSTNULLType2;
/* 4346 */           tNode1 = (TNode)aSTNULLType2;
/* 4347 */           match((AST)aSTNULLType2, 88);
/* 4348 */           aST1 = aSTNULLType2.getFirstChild();
/* 4349 */           expr(aST1);
/* 4350 */           aST1 = this._retTree;
/* 4351 */           expr(aST1);
/* 4352 */           aST1 = this._retTree;
/* 4353 */           aSTNULLType1 = aSTNULLType3;
/* 4354 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 4359 */           aST2 = aST;
/* 4360 */           tNode1 = (TNode)aST;
/* 4361 */           match(aST, 89);
/* 4362 */           aST = aST.getFirstChild();
/* 4363 */           expr(aST);
/* 4364 */           aST = this._retTree;
/* 4365 */           expr(aST);
/* 4366 */           aST = this._retTree;
/* 4367 */           aST = aST2;
/* 4368 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4373 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4377 */     } catch (RecognitionException recognitionException) {
/* 4378 */       if (this.inputState.guessing == 0) {
/* 4379 */         reportError(recognitionException);
/* 4380 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4382 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4385 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void multExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4390 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 4393 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4394 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 46:
/* 4397 */           aSTNULLType3 = aSTNULLType2;
/* 4398 */           tNode1 = (TNode)aSTNULLType2;
/* 4399 */           match((AST)aSTNULLType2, 46);
/* 4400 */           aST1 = aSTNULLType2.getFirstChild();
/* 4401 */           expr(aST1);
/* 4402 */           aST1 = this._retTree;
/* 4403 */           expr(aST1);
/* 4404 */           aST1 = this._retTree;
/* 4405 */           aSTNULLType1 = aSTNULLType3;
/* 4406 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 90:
/* 4411 */           aST2 = aST;
/* 4412 */           tNode1 = (TNode)aST;
/* 4413 */           match(aST, 90);
/* 4414 */           aST = aST.getFirstChild();
/* 4415 */           expr(aST);
/* 4416 */           aST = this._retTree;
/* 4417 */           expr(aST);
/* 4418 */           aST = this._retTree;
/* 4419 */           aST = aST2;
/* 4420 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 91:
/* 4425 */           aST2 = aST;
/* 4426 */           tNode1 = (TNode)aST;
/* 4427 */           match(aST, 91);
/* 4428 */           aST = aST.getFirstChild();
/* 4429 */           expr(aST);
/* 4430 */           aST = this._retTree;
/* 4431 */           expr(aST);
/* 4432 */           aST = this._retTree;
/* 4433 */           aST = aST2;
/* 4434 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4439 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4443 */     } catch (RecognitionException recognitionException) {
/* 4444 */       if (this.inputState.guessing == 0) {
/* 4445 */         reportError(recognitionException);
/* 4446 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4448 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4451 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void castExpr(AST paramAST) throws RecognitionException {
/* 4456 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4459 */       AST aST = paramAST;
/* 4460 */       TNode tNode1 = (TNode)paramAST;
/* 4461 */       match(paramAST, 118);
/* 4462 */       paramAST = paramAST.getFirstChild();
/* 4463 */       typeName(paramAST);
/* 4464 */       paramAST = this._retTree;
/* 4465 */       TNode tNode2 = (TNode)paramAST;
/* 4466 */       match(paramAST, 48);
/* 4467 */       paramAST = paramAST.getNextSibling();
/* 4468 */       expr(paramAST);
/* 4469 */       paramAST = this._retTree;
/* 4470 */       paramAST = aST;
/* 4471 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4473 */     catch (RecognitionException recognitionException) {
/* 4474 */       if (this.inputState.guessing == 0) {
/* 4475 */         reportError(recognitionException);
/* 4476 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4478 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4481 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void unaryExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4486 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType4; AST aST3; ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType5; AST aST4; TNode tNode1;
/*      */       boolean bool;
/* 4489 */       if (paramAST == null) aSTNULLType4 = ASTNULL; 
/* 4490 */       switch (aSTNULLType4.getType()) {
/*      */         
/*      */         case 92:
/* 4493 */           aSTNULLType5 = aSTNULLType4;
/* 4494 */           tNode1 = (TNode)aSTNULLType4;
/* 4495 */           match((AST)aSTNULLType4, 92);
/* 4496 */           aST3 = aSTNULLType4.getFirstChild();
/* 4497 */           expr(aST3);
/* 4498 */           aST3 = this._retTree;
/* 4499 */           aSTNULLType3 = aSTNULLType5;
/* 4500 */           aST2 = aSTNULLType3.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 93:
/* 4505 */           aST4 = aST2;
/* 4506 */           tNode1 = (TNode)aST2;
/* 4507 */           match(aST2, 93);
/* 4508 */           aST2 = aST2.getFirstChild();
/* 4509 */           expr(aST2);
/* 4510 */           aST2 = this._retTree;
/* 4511 */           aST2 = aST4;
/* 4512 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 131:
/* 4517 */           aST4 = aST2;
/* 4518 */           tNode1 = (TNode)aST2;
/* 4519 */           match(aST2, 131);
/* 4520 */           aST2 = aST2.getFirstChild();
/* 4521 */           unaryOperator(aST2);
/* 4522 */           aST2 = this._retTree;
/* 4523 */           expr(aST2);
/* 4524 */           aST2 = this._retTree;
/* 4525 */           aST2 = aST4;
/* 4526 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 94:
/* 4531 */           aST4 = aST2;
/* 4532 */           tNode1 = (TNode)aST2;
/* 4533 */           match(aST2, 94);
/* 4534 */           aST2 = aST2.getFirstChild();
/*      */           
/* 4536 */           bool = false;
/* 4537 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 4538 */           if (aSTNULLType2.getType() == 47) {
/* 4539 */             ASTNULLType aSTNULLType = aSTNULLType2;
/* 4540 */             bool = true;
/* 4541 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 4544 */               TNode tNode2 = (TNode)aSTNULLType2;
/* 4545 */               match((AST)aSTNULLType2, 47);
/* 4546 */               aST1 = aSTNULLType2.getNextSibling();
/* 4547 */               typeName(aST1);
/* 4548 */               aST1 = this._retTree;
/*      */             
/*      */             }
/* 4551 */             catch (RecognitionException recognitionException) {
/* 4552 */               bool = false;
/*      */             } 
/* 4554 */             aSTNULLType2 = aSTNULLType;
/* 4555 */             this.inputState.guessing--;
/*      */           } 
/* 4557 */           if (bool) {
/* 4558 */             TNode tNode2 = (TNode)aSTNULLType2;
/* 4559 */             match((AST)aSTNULLType2, 47);
/* 4560 */             aST1 = aSTNULLType2.getNextSibling();
/* 4561 */             typeName(aST1);
/* 4562 */             aST1 = this._retTree;
/* 4563 */             TNode tNode3 = (TNode)aST1;
/* 4564 */             match(aST1, 48);
/* 4565 */             aST1 = aST1.getNextSibling();
/*      */           }
/* 4567 */           else if (_tokenSet_3.member(aST1.getType())) {
/* 4568 */             expr(aST1);
/* 4569 */             aST1 = this._retTree;
/*      */           } else {
/*      */             
/* 4572 */             throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 4576 */           aST1 = aST4;
/* 4577 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 164:
/* 4582 */           aST4 = aST1;
/* 4583 */           tNode1 = (TNode)aST1;
/* 4584 */           match(aST1, 164);
/* 4585 */           aST1 = aST1.getFirstChild();
/*      */           
/* 4587 */           bool = false;
/* 4588 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 4589 */           if (aSTNULLType1.getType() == 47) {
/* 4590 */             ASTNULLType aSTNULLType = aSTNULLType1;
/* 4591 */             bool = true;
/* 4592 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 4595 */               TNode tNode2 = (TNode)aSTNULLType1;
/* 4596 */               match((AST)aSTNULLType1, 47);
/* 4597 */               aST = aSTNULLType1.getNextSibling();
/* 4598 */               typeName(aST);
/* 4599 */               aST = this._retTree;
/*      */             
/*      */             }
/* 4602 */             catch (RecognitionException recognitionException) {
/* 4603 */               bool = false;
/*      */             } 
/* 4605 */             aSTNULLType1 = aSTNULLType;
/* 4606 */             this.inputState.guessing--;
/*      */           } 
/* 4608 */           if (bool) {
/* 4609 */             TNode tNode2 = (TNode)aSTNULLType1;
/* 4610 */             match((AST)aSTNULLType1, 47);
/* 4611 */             aST = aSTNULLType1.getNextSibling();
/* 4612 */             typeName(aST);
/* 4613 */             aST = this._retTree;
/* 4614 */             TNode tNode3 = (TNode)aST;
/* 4615 */             match(aST, 48);
/* 4616 */             aST = aST.getNextSibling();
/*      */           }
/* 4618 */           else if (_tokenSet_3.member(aST.getType())) {
/* 4619 */             expr(aST);
/* 4620 */             aST = this._retTree;
/*      */           } else {
/*      */             
/* 4623 */             throw new NoViableAltException(aST);
/*      */           } 
/*      */ 
/*      */           
/* 4627 */           aST = aST4;
/* 4628 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4633 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4637 */     } catch (RecognitionException recognitionException) {
/* 4638 */       if (this.inputState.guessing == 0) {
/* 4639 */         reportError(recognitionException);
/* 4640 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4642 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4645 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void postfixExpr(AST paramAST) throws RecognitionException {
/* 4650 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4653 */       AST aST = paramAST;
/* 4654 */       TNode tNode1 = (TNode)paramAST;
/* 4655 */       match(paramAST, 133);
/* 4656 */       paramAST = paramAST.getFirstChild();
/* 4657 */       primaryExpr(paramAST);
/* 4658 */       paramAST = this._retTree;
/*      */       
/* 4660 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType2; AST aST2; ASTNULLType aSTNULLType1; AST aST1; TNode tNode3; AST aST3;
/*      */         TNode tNode2, tNode4, tNode5;
/* 4663 */         if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4664 */         switch (aSTNULLType2.getType()) {
/*      */           
/*      */           case 97:
/* 4667 */             tNode3 = (TNode)aSTNULLType2;
/* 4668 */             match((AST)aSTNULLType2, 97);
/* 4669 */             aST2 = aSTNULLType2.getNextSibling();
/* 4670 */             tNode4 = (TNode)aST2;
/* 4671 */             match(aST2, 42);
/* 4672 */             aST2 = aST2.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 98:
/* 4677 */             tNode3 = (TNode)aST2;
/* 4678 */             match(aST2, 98);
/* 4679 */             aST2 = aST2.getNextSibling();
/* 4680 */             tNode4 = (TNode)aST2;
/* 4681 */             match(aST2, 42);
/* 4682 */             aST2 = aST2.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 121:
/* 4687 */             aST3 = aST2;
/* 4688 */             tNode4 = (TNode)aST2;
/* 4689 */             match(aST2, 121);
/* 4690 */             aST2 = aST2.getFirstChild();
/*      */             
/* 4692 */             if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 4693 */             switch (aSTNULLType1.getType()) {
/*      */               
/*      */               case 42:
/*      */               case 45:
/*      */               case 46:
/*      */               case 47:
/*      */               case 64:
/*      */               case 65:
/*      */               case 66:
/*      */               case 67:
/*      */               case 68:
/*      */               case 69:
/*      */               case 70:
/*      */               case 71:
/*      */               case 72:
/*      */               case 73:
/*      */               case 74:
/*      */               case 75:
/*      */               case 76:
/*      */               case 77:
/*      */               case 78:
/*      */               case 79:
/*      */               case 80:
/*      */               case 81:
/*      */               case 82:
/*      */               case 83:
/*      */               case 84:
/*      */               case 85:
/*      */               case 86:
/*      */               case 87:
/*      */               case 88:
/*      */               case 89:
/*      */               case 90:
/*      */               case 91:
/*      */               case 92:
/*      */               case 93:
/*      */               case 94:
/*      */               case 99:
/*      */               case 118:
/*      */               case 120:
/*      */               case 123:
/*      */               case 125:
/*      */               case 130:
/*      */               case 131:
/*      */               case 133:
/*      */               case 134:
/*      */               case 135:
/*      */               case 137:
/*      */               case 139:
/*      */               case 158:
/*      */               case 164:
/* 4744 */                 argExprList((AST)aSTNULLType1);
/* 4745 */                 aST1 = this._retTree;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 48:
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 4754 */                 throw new NoViableAltException(aST1);
/*      */             } 
/*      */ 
/*      */             
/* 4758 */             tNode5 = (TNode)aST1;
/* 4759 */             match(aST1, 48);
/* 4760 */             aST1 = aST1.getNextSibling();
/* 4761 */             aST1 = aST3;
/* 4762 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 49:
/* 4767 */             tNode2 = (TNode)aST1;
/* 4768 */             match(aST1, 49);
/* 4769 */             aST1 = aST1.getNextSibling();
/* 4770 */             expr(aST1);
/* 4771 */             aST1 = this._retTree;
/* 4772 */             tNode4 = (TNode)aST1;
/* 4773 */             match(aST1, 50);
/* 4774 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 92:
/* 4779 */             tNode2 = (TNode)aST1;
/* 4780 */             match(aST1, 92);
/* 4781 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 93:
/* 4786 */             tNode2 = (TNode)aST1;
/* 4787 */             match(aST1, 93);
/* 4788 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4793 */             if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 4796 */         b++;
/*      */       } 
/*      */       
/* 4799 */       paramAST = aST;
/* 4800 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4802 */     catch (RecognitionException recognitionException) {
/* 4803 */       if (this.inputState.guessing == 0) {
/* 4804 */         reportError(recognitionException);
/* 4805 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4807 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4810 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void primaryExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4815 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType; TNode tNode1; AST aST1;
/*      */       TNode tNode2;
/* 4818 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4819 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 42:
/* 4822 */           tNode1 = (TNode)aSTNULLType;
/* 4823 */           match((AST)aSTNULLType, 42);
/* 4824 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 158:
/* 4829 */           tNode1 = (TNode)aST;
/* 4830 */           match(aST, 158);
/* 4831 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 99:
/* 4836 */           charConst(aST);
/* 4837 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 135:
/* 4842 */           stringConst(aST);
/* 4843 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 120:
/* 4848 */           aST1 = aST;
/* 4849 */           tNode2 = (TNode)aST;
/* 4850 */           match(aST, 120);
/* 4851 */           aST = aST.getFirstChild();
/* 4852 */           expr(aST);
/* 4853 */           aST = this._retTree;
/* 4854 */           aST = aST1;
/* 4855 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4860 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4864 */     } catch (RecognitionException recognitionException) {
/* 4865 */       if (this.inputState.guessing == 0) {
/* 4866 */         reportError(recognitionException);
/* 4867 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4869 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4872 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void commaExpr(AST paramAST) throws RecognitionException {
/* 4877 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4880 */       AST aST = paramAST;
/* 4881 */       TNode tNode1 = (TNode)paramAST;
/* 4882 */       match(paramAST, 130);
/* 4883 */       paramAST = paramAST.getFirstChild();
/* 4884 */       expr(paramAST);
/* 4885 */       paramAST = this._retTree;
/* 4886 */       expr(paramAST);
/* 4887 */       paramAST = this._retTree;
/* 4888 */       paramAST = aST;
/* 4889 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4891 */     catch (RecognitionException recognitionException) {
/* 4892 */       if (this.inputState.guessing == 0) {
/* 4893 */         reportError(recognitionException);
/* 4894 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4896 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4899 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void emptyExpr(AST paramAST) throws RecognitionException {
/* 4904 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4907 */       TNode tNode1 = (TNode)paramAST;
/* 4908 */       match(paramAST, 125);
/* 4909 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4911 */     catch (RecognitionException recognitionException) {
/* 4912 */       if (this.inputState.guessing == 0) {
/* 4913 */         reportError(recognitionException);
/* 4914 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4916 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4919 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void compoundStatementExpr(AST paramAST) throws RecognitionException {
/* 4924 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4927 */       AST aST = paramAST;
/* 4928 */       TNode tNode1 = (TNode)paramAST;
/* 4929 */       match(paramAST, 47);
/* 4930 */       paramAST = paramAST.getFirstChild();
/* 4931 */       compoundStatement(paramAST);
/* 4932 */       paramAST = this._retTree;
/* 4933 */       TNode tNode2 = (TNode)paramAST;
/* 4934 */       match(paramAST, 48);
/* 4935 */       paramAST = paramAST.getNextSibling();
/* 4936 */       paramAST = aST;
/* 4937 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4939 */     catch (RecognitionException recognitionException) {
/* 4940 */       if (this.inputState.guessing == 0) {
/* 4941 */         reportError(recognitionException);
/* 4942 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4944 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4947 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void rangeExpr(AST paramAST) throws RecognitionException {
/* 4952 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4955 */       AST aST = paramAST;
/* 4956 */       TNode tNode1 = (TNode)paramAST;
/* 4957 */       match(paramAST, 134);
/* 4958 */       paramAST = paramAST.getFirstChild();
/* 4959 */       expr(paramAST);
/* 4960 */       paramAST = this._retTree;
/* 4961 */       TNode tNode2 = (TNode)paramAST;
/* 4962 */       match(paramAST, 51);
/* 4963 */       paramAST = paramAST.getNextSibling();
/* 4964 */       expr(paramAST);
/* 4965 */       paramAST = this._retTree;
/* 4966 */       paramAST = aST;
/* 4967 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4969 */     catch (RecognitionException recognitionException) {
/* 4970 */       if (this.inputState.guessing == 0) {
/* 4971 */         reportError(recognitionException);
/* 4972 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4974 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4977 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void gnuAsmExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4982 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType3, aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/* 4985 */       AST aST3 = paramAST;
/* 4986 */       TNode tNode1 = (TNode)paramAST;
/* 4987 */       match(paramAST, 139);
/* 4988 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 4990 */       if (paramAST == null) aSTNULLType3 = ASTNULL; 
/* 4991 */       switch (aSTNULLType3.getType()) {
/*      */         
/*      */         case 6:
/* 4994 */           tNode2 = (TNode)aSTNULLType3;
/* 4995 */           match((AST)aSTNULLType3, 6);
/* 4996 */           aST2 = aSTNULLType3.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5005 */           throw new NoViableAltException(aST2);
/*      */       } 
/*      */ 
/*      */       
/* 5009 */       TNode tNode2 = (TNode)aST2;
/* 5010 */       match(aST2, 47);
/* 5011 */       AST aST2 = aST2.getNextSibling();
/* 5012 */       stringConst(aST2);
/* 5013 */       aST2 = this._retTree;
/*      */       
/* 5015 */       if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 5016 */       if (aSTNULLType2.getType() == 44) {
/* 5017 */         ASTNULLType aSTNULLType; AST aST4; TNode tNode4 = (TNode)aSTNULLType2;
/* 5018 */         match((AST)aSTNULLType2, 44);
/* 5019 */         AST aST5 = aSTNULLType2.getNextSibling();
/*      */         
/* 5021 */         if (aST5 == null) aSTNULLType = ASTNULL; 
/* 5022 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 135:
/* 5025 */             strOptExprPair((AST)aSTNULLType);
/* 5026 */             aST4 = this._retTree;
/*      */ 
/*      */             
/*      */             while (true) {
/* 5030 */               if (aST4 == null) aSTNULLType1 = ASTNULL; 
/* 5031 */               if (aSTNULLType1.getType() == 43) {
/* 5032 */                 TNode tNode5 = (TNode)aSTNULLType1;
/* 5033 */                 match((AST)aSTNULLType1, 43);
/* 5034 */                 aST4 = aSTNULLType1.getNextSibling();
/* 5035 */                 strOptExprPair(aST4);
/* 5036 */                 aST4 = this._retTree;
/*      */                 continue;
/*      */               } 
/*      */               break;
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 44:
/*      */           case 48:
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 5053 */             throw new NoViableAltException(aST4);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 5058 */         if (aST4 == null) aSTNULLType1 = ASTNULL; 
/* 5059 */         if (aSTNULLType1.getType() == 44) {
/* 5060 */           ASTNULLType aSTNULLType4; TNode tNode5 = (TNode)aSTNULLType1;
/* 5061 */           match((AST)aSTNULLType1, 44);
/* 5062 */           AST aST6 = aSTNULLType1.getNextSibling();
/*      */           
/* 5064 */           if (aST6 == null) aSTNULLType4 = ASTNULL; 
/* 5065 */           switch (aSTNULLType4.getType()) {
/*      */             
/*      */             case 135:
/* 5068 */               strOptExprPair((AST)aSTNULLType4);
/* 5069 */               aST1 = this._retTree;
/*      */               
/*      */               while (true) {
/*      */                 ASTNULLType aSTNULLType5;
/* 5073 */                 if (aST1 == null) aSTNULLType5 = ASTNULL; 
/* 5074 */                 if (aSTNULLType5.getType() == 43) {
/* 5075 */                   TNode tNode6 = (TNode)aSTNULLType5;
/* 5076 */                   match((AST)aSTNULLType5, 43);
/* 5077 */                   aST1 = aSTNULLType5.getNextSibling();
/* 5078 */                   strOptExprPair(aST1);
/* 5079 */                   aST1 = this._retTree;
/*      */                   continue;
/*      */                 } 
/*      */                 break;
/*      */               } 
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 44:
/*      */             case 48:
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             default:
/* 5096 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/* 5101 */         } else if (aST1.getType() != 44 && aST1.getType() != 48) {
/*      */ 
/*      */           
/* 5104 */           throw new NoViableAltException(aST1);
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 5109 */       else if (aST1.getType() != 44 && aST1.getType() != 48) {
/*      */ 
/*      */         
/* 5112 */         throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 5117 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 5118 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 44:
/* 5121 */           tNode3 = (TNode)aSTNULLType1;
/* 5122 */           match((AST)aSTNULLType1, 44);
/* 5123 */           aST = aSTNULLType1.getNextSibling();
/* 5124 */           stringConst(aST);
/* 5125 */           aST = this._retTree;
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType;
/* 5129 */             if (aST == null) aSTNULLType = ASTNULL; 
/* 5130 */             if (aSTNULLType.getType() == 43) {
/* 5131 */               TNode tNode4 = (TNode)aSTNULLType;
/* 5132 */               match((AST)aSTNULLType, 43);
/* 5133 */               aST = aSTNULLType.getNextSibling();
/* 5134 */               stringConst(aST);
/* 5135 */               aST = this._retTree;
/*      */               continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 5151 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 5155 */       TNode tNode3 = (TNode)aST;
/* 5156 */       match(aST, 48);
/* 5157 */       aST = aST.getNextSibling();
/* 5158 */       aST = aST3;
/* 5159 */       aST = aST.getNextSibling();
/*      */     }
/* 5161 */     catch (RecognitionException recognitionException) {
/* 5162 */       if (this.inputState.guessing == 0) {
/* 5163 */         reportError(recognitionException);
/* 5164 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5166 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5169 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void stringConst(AST paramAST) throws RecognitionException {
/* 5174 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5177 */       AST aST = paramAST;
/* 5178 */       TNode tNode1 = (TNode)paramAST;
/* 5179 */       match(paramAST, 135);
/* 5180 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 5182 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/* 5185 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5186 */         if (aSTNULLType.getType() == 100) {
/* 5187 */           TNode tNode2 = (TNode)aSTNULLType;
/* 5188 */           match((AST)aSTNULLType, 100);
/* 5189 */           aST1 = aSTNULLType.getNextSibling();
/*      */         } else {
/*      */           
/* 5192 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 5195 */         b++;
/*      */       } 
/*      */       
/* 5198 */       paramAST = aST;
/* 5199 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5201 */     catch (RecognitionException recognitionException) {
/* 5202 */       if (this.inputState.guessing == 0) {
/* 5203 */         reportError(recognitionException);
/* 5204 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5206 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5209 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void strOptExprPair(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5214 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1, tNode2;
/* 5217 */       stringConst(paramAST);
/* 5218 */       paramAST = this._retTree;
/*      */       
/* 5220 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5221 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 47:
/* 5224 */           tNode1 = (TNode)aSTNULLType;
/* 5225 */           match((AST)aSTNULLType, 47);
/* 5226 */           aST = aSTNULLType.getNextSibling();
/* 5227 */           expr(aST);
/* 5228 */           aST = this._retTree;
/* 5229 */           tNode2 = (TNode)aST;
/* 5230 */           match(aST, 48);
/* 5231 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 43:
/*      */         case 44:
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5242 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 5247 */     } catch (RecognitionException recognitionException) {
/* 5248 */       if (this.inputState.guessing == 0) {
/* 5249 */         reportError(recognitionException);
/* 5250 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5252 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5255 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void unaryOperator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5260 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 5263 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5264 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 79:
/* 5267 */           tNode1 = (TNode)aSTNULLType;
/* 5268 */           match((AST)aSTNULLType, 79);
/* 5269 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/* 5274 */           tNode1 = (TNode)aST;
/* 5275 */           match(aST, 46);
/* 5276 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 88:
/* 5281 */           tNode1 = (TNode)aST;
/* 5282 */           match(aST, 88);
/* 5283 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 5288 */           tNode1 = (TNode)aST;
/* 5289 */           match(aST, 89);
/* 5290 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 95:
/* 5295 */           tNode1 = (TNode)aST;
/* 5296 */           match(aST, 95);
/* 5297 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 96:
/* 5302 */           tNode1 = (TNode)aST;
/* 5303 */           match(aST, 96);
/* 5304 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 76:
/* 5309 */           tNode1 = (TNode)aST;
/* 5310 */           match(aST, 76);
/* 5311 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 165:
/* 5316 */           tNode1 = (TNode)aST;
/* 5317 */           match(aST, 165);
/* 5318 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 166:
/* 5323 */           tNode1 = (TNode)aST;
/* 5324 */           match(aST, 166);
/* 5325 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5330 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5334 */     } catch (RecognitionException recognitionException) {
/* 5335 */       if (this.inputState.guessing == 0) {
/* 5336 */         reportError(recognitionException);
/* 5337 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5339 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5342 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void argExprList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5347 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 5351 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 5354 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5355 */         if (_tokenSet_3.member(aSTNULLType.getType())) {
/* 5356 */           expr((AST)aSTNULLType);
/* 5357 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 5360 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 5363 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 5367 */     catch (RecognitionException recognitionException) {
/* 5368 */       if (this.inputState.guessing == 0) {
/* 5369 */         reportError(recognitionException);
/* 5370 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5372 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5375 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void charConst(AST paramAST) throws RecognitionException {
/* 5380 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5383 */       TNode tNode1 = (TNode)paramAST;
/* 5384 */       match(paramAST, 99);
/* 5385 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5387 */     catch (RecognitionException recognitionException) {
/* 5388 */       if (this.inputState.guessing == 0) {
/* 5389 */         reportError(recognitionException);
/* 5390 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5392 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5395 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   protected final void intConst(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5400 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 5403 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5404 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 101:
/* 5407 */           tNode1 = (TNode)aSTNULLType;
/* 5408 */           match((AST)aSTNULLType, 101);
/* 5409 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 102:
/* 5414 */           tNode1 = (TNode)aST;
/* 5415 */           match(aST, 102);
/* 5416 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 103:
/* 5421 */           tNode1 = (TNode)aST;
/* 5422 */           match(aST, 103);
/* 5423 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 104:
/* 5428 */           tNode1 = (TNode)aST;
/* 5429 */           match(aST, 104);
/* 5430 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 105:
/* 5435 */           tNode1 = (TNode)aST;
/* 5436 */           match(aST, 105);
/* 5437 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 106:
/* 5442 */           tNode1 = (TNode)aST;
/* 5443 */           match(aST, 106);
/* 5444 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 107:
/* 5449 */           tNode1 = (TNode)aST;
/* 5450 */           match(aST, 107);
/* 5451 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 108:
/* 5456 */           tNode1 = (TNode)aST;
/* 5457 */           match(aST, 108);
/* 5458 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 109:
/* 5463 */           tNode1 = (TNode)aST;
/* 5464 */           match(aST, 109);
/* 5465 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5470 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5474 */     } catch (RecognitionException recognitionException) {
/* 5475 */       if (this.inputState.guessing == 0) {
/* 5476 */         reportError(recognitionException);
/* 5477 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5479 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5482 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   protected final void floatConst(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5487 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 5490 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5491 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 110:
/* 5494 */           tNode1 = (TNode)aSTNULLType;
/* 5495 */           match((AST)aSTNULLType, 110);
/* 5496 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 111:
/* 5501 */           tNode1 = (TNode)aST;
/* 5502 */           match(aST, 111);
/* 5503 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 112:
/* 5508 */           tNode1 = (TNode)aST;
/* 5509 */           match(aST, 112);
/* 5510 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5515 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5519 */     } catch (RecognitionException recognitionException) {
/* 5520 */       if (this.inputState.guessing == 0) {
/* 5521 */         reportError(recognitionException);
/* 5522 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5524 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5527 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/* 5531 */   public static final String[] _tokenNames = new String[] { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"typedef\"", "\"asm\"", "\"volatile\"", "LCURLY", "RCURLY", "SEMI", "\"struct\"", "\"union\"", "\"enum\"", "\"auto\"", "\"register\"", "\"extern\"", "\"static\"", "\"const\"", "\"void\"", "\"char\"", "\"short\"", "\"int\"", "\"long\"", "\"float\"", "\"double\"", "\"signed\"", "\"unsigned\"", "\"int8_t\"", "\"uint8_t\"", "\"int16_t\"", "\"uint16_t\"", "\"__int32\"", "\"int32_t\"", "\"wchar_t\"", "\"uint32_t\"", "\"__int64\"", "\"int64_t\"", "\"uint64_t\"", "\"ptrdiff_t\"", "\"intptr_t\"", "\"size_t\"", "\"uintptr_t\"", "ID", "COMMA", "COLON", "ASSIGN", "STAR", "LPAREN", "RPAREN", "LBRACKET", "RBRACKET", "VARARGS", "\"while\"", "\"do\"", "\"for\"", "\"goto\"", "\"continue\"", "\"break\"", "\"return\"", "\"case\"", "\"default\"", "\"if\"", "\"else\"", "\"switch\"", "DIV_ASSIGN", "PLUS_ASSIGN", "MINUS_ASSIGN", "STAR_ASSIGN", "MOD_ASSIGN", "RSHIFT_ASSIGN", "LSHIFT_ASSIGN", "BAND_ASSIGN", "BOR_ASSIGN", "BXOR_ASSIGN", "QUESTION", "LOR", "LAND", "BOR", "BXOR", "BAND", "EQUAL", "NOT_EQUAL", "LT", "LTE", "GT", "GTE", "LSHIFT", "RSHIFT", "PLUS", "MINUS", "DIV", "MOD", "INC", "DEC", "\"sizeof\"", "BNOT", "LNOT", "PTR", "DOT", "CharLiteral", "StringLiteral", "IntOctalConst", "LongOctalConst", "UnsignedOctalConst", "IntIntConst", "LongIntConst", "UnsignedIntConst", "IntHexConst", "LongHexConst", "UnsignedHexConst", "FloatDoubleConst", "DoubleDoubleConst", "LongDoubleConst", "NTypedefName", "NInitDecl", "NDeclarator", "NStructDeclarator", "NDeclaration", "NCast", "NPointerGroup", "NExpressionGroup", "NFunctionCallArgs", "NNonemptyAbstractDeclarator", "NInitializer", "NStatementExpr", "NEmptyExpression", "NParameterTypeList", "NFunctionDef", "NCompoundStatement", "NParameterDeclaration", "NCommaExpr", "NUnaryExpr", "NLabel", "NPostfixExpr", "NRangeExpr", "NStringSeq", "NInitializerElementLabel", "NLcurlyInitializer", "NAsmAttribute", "NGnuAsmExpr", "NTypeMissing", "Vocabulary", "Whitespace", "Comment", "CPPComment", "NonWhitespace", "a line directive", "DefineExpr", "DefineExpr2", "Space", "LineDirective", "BadStringLiteral", "Escape", "Digit", "LongSuffix", "UnsignedSuffix", "FloatSuffix", "Exponent", "Number", "\"__label__\"", "\"inline\"", "\"typeof\"", "\"__complex\"", "\"__attribute\"", "\"__alignof\"", "\"__real\"", "\"__imag\"" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 5702 */     return new long[] { 544L, -9214364837600034816L, 4096L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5705 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 5707 */     return new long[] { 4398046387264L, 562949953421312L, 25769803776L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5710 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 5712 */     return new long[] { -4616189618054757888L, 1152921504606846976L, 17L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5715 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 5717 */     return new long[] { 250688651132928L, 2972375790571749375L, 69793221356L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 5720 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/GnuCTreeParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */