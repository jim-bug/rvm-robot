package com.jogamp.gluegen.cgram.types;

public interface TypeVisitor {
  void visitType(Type paramType);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/TypeVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */