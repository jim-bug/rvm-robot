/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ import com.jogamp.gluegen.ConstantDefinition;
/*     */ import java.util.ArrayList;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumType
/*     */   extends IntType
/*     */   implements Cloneable
/*     */ {
/*     */   private final IntType underlyingType;
/*     */   private ArrayList<Enumerator> enums;
/*     */   
/*     */   public static class Enumerator
/*     */     implements TypeComparator.SemanticEqualityOp
/*     */   {
/*     */     private final String name;
/*     */     private final String expr;
/*     */     private final ConstantDefinition.CNumber number;
/*     */     
/*     */     public Enumerator(String param1String, long param1Long) {
/*  62 */       this.name = param1String;
/*  63 */       this.number = new ConstantDefinition.CNumber(false, false, param1Long);
/*  64 */       this.expr = this.number.toJavaString();
/*     */     }
/*     */     public Enumerator(String param1String, ConstantDefinition.CNumber param1CNumber) {
/*  67 */       this.name = param1String;
/*  68 */       this.number = param1CNumber;
/*  69 */       this.expr = this.number.toJavaString();
/*     */     }
/*     */     public Enumerator(String param1String1, String param1String2) {
/*  72 */       this.name = param1String1;
/*  73 */       this.expr = param1String2;
/*  74 */       this.number = ConstantDefinition.decodeIntegerNumber(param1String2);
/*     */     }
/*     */     
/*  77 */     public String getName() { return this.name; }
/*  78 */     public String getExpr() { return this.expr; }
/*  79 */     public ConstantDefinition.CNumber getNumber() { return this.number; } public boolean hasNumber() {
/*  80 */       return (null != this.number);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  85 */       int i = this.name.hashCode();
/*  86 */       return (i << 5) - i + this.expr.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*  91 */       if (param1Object == this)
/*  92 */         return true; 
/*  93 */       if (!(param1Object instanceof Enumerator)) {
/*  94 */         return false;
/*     */       }
/*  96 */       Enumerator enumerator = (Enumerator)param1Object;
/*  97 */       return (this.name.equals(enumerator.name) && this.expr
/*  98 */         .equals(enumerator.expr));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCodeSemantics() {
/* 103 */       return hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equalSemantics(TypeComparator.SemanticEqualityOp param1SemanticEqualityOp) {
/* 108 */       return equals(param1SemanticEqualityOp);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 112 */       return "[" + this.name + " = [" + this.expr + ", " + this.number + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumType(String paramString) {
/* 119 */     super(paramString, SizeThunk.LONG, false, 1);
/* 120 */     this.underlyingType = new IntType(paramString, SizeThunk.LONG, false, 1);
/*     */   }
/*     */   
/*     */   public EnumType(String paramString, SizeThunk paramSizeThunk, ASTLocusTag paramASTLocusTag) {
/* 124 */     super(paramString, paramSizeThunk, false, 1, paramASTLocusTag);
/* 125 */     this.underlyingType = new IntType(paramString, paramSizeThunk, false, 1, paramASTLocusTag);
/*     */   }
/*     */   
/*     */   private EnumType(EnumType paramEnumType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 129 */     super(paramEnumType, paramInt, paramASTLocusTag);
/* 130 */     this.underlyingType = paramEnumType.underlyingType;
/* 131 */     if (null != paramEnumType.enums) {
/* 132 */       this.enums = new ArrayList<>(paramEnumType.enums);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 138 */     return new EnumType(this, paramInt, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeImpl() {
/* 144 */     int i = super.hashCodeImpl();
/* 145 */     i = (i << 5) - i + this.underlyingType.hashCode();
/* 146 */     return (i << 5) - i + TypeComparator.<Enumerator>listsHashCode(this.enums);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalsImpl(Type paramType) {
/* 151 */     EnumType enumType = (EnumType)paramType;
/* 152 */     return (super.equalsImpl(paramType) && this.underlyingType
/* 153 */       .equals(enumType.underlyingType) && 
/* 154 */       TypeComparator.listsEqual(this.enums, enumType.enums));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeSemanticsImpl() {
/* 160 */     int i = super.hashCodeSemanticsImpl();
/* 161 */     i = (i << 5) - i + this.underlyingType.hashCodeSemantics();
/* 162 */     return (i << 5) - i + TypeComparator.<Enumerator>listsHashCodeSemantics(this.enums);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalSemanticsImpl(Type paramType) {
/* 167 */     EnumType enumType = (EnumType)paramType;
/* 168 */     return (super.equalSemanticsImpl(paramType) && this.underlyingType
/* 169 */       .equalSemantics(enumType.underlyingType) && 
/* 170 */       TypeComparator.listsEqualSemantics(this.enums, enumType.enums));
/*     */   }
/*     */ 
/*     */   
/*     */   public EnumType asEnum() {
/* 175 */     return this;
/*     */   }
/*     */   public Type getUnderlyingType() {
/* 178 */     return this.underlyingType;
/*     */   }
/*     */   public void addEnum(String paramString, Enumerator paramEnumerator) {
/* 181 */     if (this.enums == null) {
/* 182 */       this.enums = new ArrayList<>();
/*     */     }
/* 184 */     this.enums.add(paramEnumerator);
/* 185 */     clearCache();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumEnumerates() {
/* 190 */     return this.enums.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumerator getEnum(int paramInt) {
/* 195 */     return this.enums.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumerator getEnum(String paramString) {
/* 200 */     for (byte b = 0; b < this.enums.size(); b++) {
/* 201 */       Enumerator enumerator = this.enums.get(b);
/* 202 */       if (enumerator.getName().equals(paramString)) {
/* 203 */         return enumerator;
/*     */       }
/*     */     } 
/* 206 */     throw new NoSuchElementException("No enumerate named \"" + paramString + "\" in EnumType \"" + 
/*     */         
/* 208 */         getName() + "\"");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsEnumerate(String paramString) {
/* 213 */     for (byte b = 0; b < this.enums.size(); b++) {
/* 214 */       if (((Enumerator)this.enums.get(b)).getName().equals(paramString)) {
/* 215 */         return true;
/*     */       }
/*     */     } 
/* 218 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeEnumerate(String paramString) {
/* 225 */     for (byte b = 0; b < this.enums.size(); b++) {
/* 226 */       Enumerator enumerator = this.enums.get(b);
/* 227 */       if (enumerator.getName().equals(paramString)) {
/* 228 */         this.enums.remove(enumerator);
/* 229 */         clearCache();
/* 230 */         return true;
/*     */       } 
/*     */     } 
/* 233 */     return false;
/*     */   }
/*     */   
/*     */   public StringBuilder appendEnums(StringBuilder paramStringBuilder, boolean paramBoolean) {
/* 237 */     for (byte b = 0; b < this.enums.size(); b++) {
/* 238 */       paramStringBuilder.append(this.enums.get(b)).append(", ");
/* 239 */       if (paramBoolean) {
/* 240 */         paramStringBuilder.append(String.format("%n", new Object[0]));
/*     */       }
/*     */     } 
/* 243 */     paramStringBuilder.append("}");
/* 244 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(TypeVisitor paramTypeVisitor) {
/* 249 */     super.visit(paramTypeVisitor);
/* 250 */     this.underlyingType.visit(paramTypeVisitor);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/EnumType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */