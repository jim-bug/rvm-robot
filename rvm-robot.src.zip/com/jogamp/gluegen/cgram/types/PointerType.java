/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PointerType
/*     */   extends Type
/*     */   implements Cloneable
/*     */ {
/*     */   private final Type targetType;
/*     */   
/*     */   public PointerType(SizeThunk paramSizeThunk, Type paramType, int paramInt) {
/*  49 */     this(paramSizeThunk, paramType, paramInt, (ASTLocusTag)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerType(SizeThunk paramSizeThunk, Type paramType, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  54 */     super(paramType.getName() + " *", paramSizeThunk, paramInt, paramASTLocusTag);
/*  55 */     this.targetType = paramType;
/*     */   }
/*     */   
/*     */   private PointerType(PointerType paramPointerType, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  59 */     super(paramPointerType, paramInt, paramASTLocusTag);
/*  60 */     this.targetType = paramPointerType.targetType;
/*     */   }
/*     */ 
/*     */   
/*     */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  65 */     return new PointerType(this, paramInt, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int hashCodeImpl() {
/*  70 */     return this.targetType.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalsImpl(Type paramType) {
/*  75 */     PointerType pointerType = (PointerType)paramType;
/*  76 */     return this.targetType.equals(pointerType.targetType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int hashCodeSemanticsImpl() {
/*  81 */     return this.targetType.hashCodeSemantics();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalSemanticsImpl(Type paramType) {
/*  86 */     PointerType pointerType = (PointerType)paramType;
/*  87 */     return this.targetType.equalSemantics(pointerType.targetType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnon() {
/*  92 */     if (isTypedef()) {
/*  93 */       return super.isAnon();
/*     */     }
/*  95 */     return this.targetType.isAnon();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(boolean paramBoolean) {
/* 101 */     if (isTypedef())
/* 102 */       return super.getName(paramBoolean); 
/* 103 */     if (!paramBoolean) {
/* 104 */       return this.targetType.getName(paramBoolean) + " *";
/*     */     }
/* 106 */     return this.targetType.getName(paramBoolean) + " * " + getCVAttributesString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCName(boolean paramBoolean) {
/* 112 */     if (isTypedef())
/* 113 */       return super.getCName(paramBoolean); 
/* 114 */     if (!paramBoolean) {
/* 115 */       return this.targetType.getCName(paramBoolean) + " *";
/*     */     }
/* 117 */     return this.targetType.getCName(paramBoolean) + " * " + getCVAttributesString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final PointerType asPointer() {
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Type getTargetType() {
/* 128 */     if (isFunctionPointer()) {
/* 129 */       return this;
/*     */     }
/* 131 */     return this.targetType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Type getBaseType() {
/* 137 */     if (isFunctionPointer()) {
/* 138 */       return this;
/*     */     }
/* 140 */     return this.targetType.getBaseType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getArrayBaseOrPointerTargetType() {
/* 146 */     return getTargetType();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunctionType getTargetFunction() {
/* 151 */     if (isFunctionPointer()) {
/* 152 */       return this.targetType.asFunction();
/*     */     }
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isFunctionPointer() {
/* 159 */     return this.targetType.isFunction();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int pointerDepth() {
/* 164 */     return 1 + this.targetType.pointerDepth();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 169 */     if (isTypedef()) {
/* 170 */       return super.getCName(true);
/*     */     }
/* 172 */     return toStringInt();
/*     */   }
/*     */   
/*     */   private String toStringInt() {
/* 176 */     if (!isFunctionPointer()) {
/* 177 */       return this.targetType.getCName(true) + " * " + getCVAttributesString();
/*     */     }
/*     */     
/* 180 */     return ((FunctionType)this.targetType).toString(null, null, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(String paramString1, String paramString2) {
/* 188 */     if (!isFunctionPointer()) {
/* 189 */       throw new RuntimeException("<Internal error or misuse> This method is only for use when printing function pointers");
/*     */     }
/* 191 */     return ((FunctionType)this.targetType).toString(paramString1, paramString2, false, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(TypeVisitor paramTypeVisitor) {
/* 196 */     super.visit(paramTypeVisitor);
/* 197 */     this.targetType.visit(paramTypeVisitor);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/PointerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */