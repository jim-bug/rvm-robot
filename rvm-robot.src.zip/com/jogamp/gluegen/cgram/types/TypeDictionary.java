/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.GlueGen;
/*     */ import com.jogamp.gluegen.JavaConfiguration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeDictionary
/*     */ {
/*  52 */   private final HashMap<String, Type> map = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type put(String paramString, Type paramType) {
/*  60 */     return this.map.put(paramString, paramType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Type get(String paramString) {
/*  66 */     return this.map.get(paramString);
/*     */   }
/*     */   
/*     */   public List<Type> getEqualSemantics(Type paramType, JavaConfiguration paramJavaConfiguration, boolean paramBoolean) {
/*  70 */     ArrayList<Type> arrayList = new ArrayList();
/*  71 */     if (!paramBoolean || null == paramJavaConfiguration.typeInfo(paramType)) {
/*  72 */       Set<Map.Entry<String, Type>> set = entrySet();
/*  73 */       for (Map.Entry<String, Type> entry : set) {
/*     */         
/*  75 */         Type type = (Type)entry.getValue();
/*  76 */         if (paramType.equalSemantics(type) && (
/*  77 */           !paramBoolean || null == paramJavaConfiguration.typeInfo(type))) {
/*  78 */           if (GlueGen.debug()) {
/*  79 */             System.err.println(" tls[" + arrayList.size() + "]: -> " + (String)entry.getKey() + " -> " + type.getDebugString());
/*     */           }
/*  81 */           arrayList.add(type);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  86 */     return arrayList;
/*     */   }
/*     */   public Type getEqualSemantics1(Type paramType, JavaConfiguration paramJavaConfiguration, boolean paramBoolean) {
/*  89 */     List<Type> list = getEqualSemantics(paramType, paramJavaConfiguration, paramBoolean);
/*  90 */     if (list.size() > 0) {
/*  91 */       Type type = list.get(0);
/*  92 */       if (GlueGen.debug()) {
/*  93 */         System.err.println(" tls.0: " + type.getDebugString());
/*     */       }
/*  95 */       return type;
/*     */     } 
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type remove(String paramString) {
/* 118 */     return this.map.remove(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 125 */     return this.map.keySet();
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<String, Type>> entrySet() {
/* 129 */     return this.map.entrySet();
/*     */   }
/*     */   
/*     */   public boolean containsKey(String paramString) {
/* 133 */     return this.map.containsKey(paramString);
/*     */   }
/*     */   
/*     */   public boolean containsValue(Type paramType) {
/* 137 */     return this.map.containsValue(paramType);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 141 */     return this.map.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Type> values() {
/* 146 */     return this.map.values();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/TypeDictionary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */