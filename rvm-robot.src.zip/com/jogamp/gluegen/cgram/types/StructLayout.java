/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.common.os.MachineDataInfo;
/*     */ import com.jogamp.gluegen.GlueGen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructLayout
/*     */ {
/*     */   private final int baseOffset;
/*     */   
/*     */   protected StructLayout(int paramInt) {
/*  57 */     this.baseOffset = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void layout(CompoundType paramCompoundType) {
/*     */     MachineDataInfo machineDataInfo;
/*  66 */     int i = paramCompoundType.getNumFields();
/*  67 */     SizeThunk sizeThunk1 = SizeThunk.constant(this.baseOffset);
/*  68 */     SizeThunk sizeThunk2 = SizeThunk.constant(0);
/*     */ 
/*     */     
/*  71 */     if (GlueGen.debug()) {
/*  72 */       machineDataInfo = MachineDataInfo.StaticConfig.LP64_UNIX.md;
/*  73 */       System.err.printf("SL.__: o %03d, s %03d, t %s{%d}%n", new Object[] { Long.valueOf(sizeThunk1.computeSize(machineDataInfo)), Integer.valueOf(0), paramCompoundType, Integer.valueOf(paramCompoundType.getNumFields()) });
/*     */     } else {
/*  75 */       machineDataInfo = null;
/*     */     } 
/*     */     
/*  78 */     for (byte b = 0; b < i; b++) {
/*  79 */       Field field = paramCompoundType.getField(b);
/*  80 */       Type type = field.getType();
/*  81 */       if (type.isInt() || type.isFloat() || type.isDouble() || type.isPointer()) {
/*  82 */         SizeThunk sizeThunk = type.getSize();
/*  83 */         sizeThunk1 = SizeThunk.align(sizeThunk1, sizeThunk);
/*  84 */         field.setOffset(sizeThunk1);
/*  85 */         if (paramCompoundType.isUnion()) {
/*  86 */           sizeThunk2 = SizeThunk.max(sizeThunk2, sizeThunk);
/*     */         } else {
/*  88 */           sizeThunk1 = SizeThunk.add(sizeThunk1, sizeThunk);
/*     */         } 
/*  90 */       } else if (type.isCompound()) {
/*  91 */         CompoundType compoundType = type.asCompound();
/*  92 */         if (!compoundType.isLayouted()) {
/*  93 */           layout(0, compoundType);
/*     */         }
/*  95 */         SizeThunk sizeThunk = compoundType.getSize();
/*  96 */         sizeThunk1 = SizeThunk.align(sizeThunk1, sizeThunk);
/*  97 */         field.setOffset(sizeThunk1);
/*  98 */         if (paramCompoundType.isUnion()) {
/*  99 */           sizeThunk2 = SizeThunk.max(sizeThunk2, sizeThunk);
/*     */         } else {
/* 101 */           sizeThunk1 = SizeThunk.add(sizeThunk1, sizeThunk);
/*     */         } 
/* 103 */       } else if (type.isArray()) {
/* 104 */         ArrayType arrayType = type.asArray();
/* 105 */         if (!arrayType.isLayouted()) {
/* 106 */           CompoundType compoundType = arrayType.getBaseType().asCompound();
/* 107 */           if (compoundType != null) {
/* 108 */             if (!compoundType.isLayouted()) {
/* 109 */               layout(0, compoundType);
/*     */             }
/* 111 */             arrayType.recomputeSize();
/*     */           } 
/* 113 */           arrayType.setLayouted();
/*     */         } 
/* 115 */         SizeThunk sizeThunk = type.getSize();
/* 116 */         sizeThunk1 = SizeThunk.align(sizeThunk1, sizeThunk);
/* 117 */         field.setOffset(sizeThunk1);
/* 118 */         sizeThunk1 = SizeThunk.add(sizeThunk1, sizeThunk);
/*     */       } else {
/*     */         
/* 121 */         String str = paramCompoundType.getName();
/* 122 */         if (str == null) {
/* 123 */           str = paramCompoundType.toString();
/*     */         }
/* 125 */         throw new RuntimeException("Complicated field types (" + type + " " + field
/* 126 */             .getName() + " in type " + str + ") not implemented yet");
/*     */       } 
/*     */ 
/*     */       
/* 130 */       if (GlueGen.debug()) {
/* 131 */         System.err.printf("SL.%02d: o %03d, s %03d: %s, %s%n", new Object[] { Integer.valueOf(b + 1), Long.valueOf(field.getOffset(machineDataInfo)), Long.valueOf(type.getSize(machineDataInfo)), field, type.getDebugString() });
/*     */       }
/*     */     } 
/* 134 */     if (paramCompoundType.isUnion()) {
/* 135 */       paramCompoundType.setSize(sizeThunk2);
/*     */     } else {
/*     */       
/* 138 */       sizeThunk1 = SizeThunk.align(sizeThunk1, sizeThunk1);
/* 139 */       paramCompoundType.setSize(sizeThunk1);
/*     */     } 
/* 141 */     if (GlueGen.debug()) {
/* 142 */       System.err.printf("SL.XX: o %03d, s %03d, t %s{%d}%n%n", new Object[] { Long.valueOf(sizeThunk1.computeSize(machineDataInfo)), Long.valueOf(paramCompoundType.getSize(machineDataInfo)), paramCompoundType, Integer.valueOf(paramCompoundType.getNumFields()) });
/*     */     }
/* 144 */     paramCompoundType.setLayouted();
/*     */   }
/*     */   
/*     */   public static StructLayout create(int paramInt) {
/* 148 */     return new StructLayout(paramInt);
/*     */   }
/*     */   
/*     */   public static void layout(int paramInt, CompoundType paramCompoundType) {
/* 152 */     create(paramInt).layout(paramCompoundType);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/StructLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */