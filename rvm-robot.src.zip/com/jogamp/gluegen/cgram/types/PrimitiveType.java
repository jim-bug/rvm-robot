/*    */ package com.jogamp.gluegen.cgram.types;
/*    */ 
/*    */ import com.jogamp.gluegen.ASTLocusTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PrimitiveType
/*    */   extends Type
/*    */   implements Cloneable
/*    */ {
/*    */   protected PrimitiveType(String paramString, SizeThunk paramSizeThunk, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 47 */     super(paramString, paramSizeThunk, paramInt, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   PrimitiveType(PrimitiveType paramPrimitiveType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 51 */     super(paramPrimitiveType, paramInt, paramASTLocusTag);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPrimitive() {
/* 56 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/PrimitiveType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */