/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitType
/*     */   extends IntType
/*     */   implements Cloneable
/*     */ {
/*     */   private final IntType underlyingType;
/*     */   private final int sizeInBits;
/*     */   private final int offset;
/*     */   
/*     */   public BitType(IntType paramIntType, int paramInt1, int paramInt2, int paramInt3, ASTLocusTag paramASTLocusTag) {
/*  54 */     super(paramIntType.getName(), paramIntType.getSize(), paramIntType.isUnsigned(), paramInt3, paramASTLocusTag);
/*  55 */     this.underlyingType = paramIntType;
/*  56 */     this.sizeInBits = paramInt1;
/*  57 */     this.offset = paramInt2;
/*     */   }
/*     */   
/*     */   private BitType(BitType paramBitType, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  61 */     super(paramBitType, paramInt, paramASTLocusTag);
/*  62 */     this.underlyingType = paramBitType.underlyingType;
/*  63 */     this.sizeInBits = paramBitType.sizeInBits;
/*  64 */     this.offset = paramBitType.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  69 */     return new BitType(this, paramInt, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeImpl() {
/*  75 */     int i = super.hashCodeImpl();
/*  76 */     i = (i << 5) - i + this.underlyingType.hashCode();
/*  77 */     i = (i << 5) - i + this.sizeInBits;
/*  78 */     return (i << 5) - i + this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalsImpl(Type paramType) {
/*  83 */     BitType bitType = (BitType)paramType;
/*  84 */     return (super.equalsImpl(paramType) && this.underlyingType
/*  85 */       .equals(bitType.underlyingType) && this.sizeInBits == bitType.sizeInBits && this.offset == bitType.offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeSemanticsImpl() {
/*  93 */     int i = super.hashCodeSemanticsImpl();
/*  94 */     i = (i << 5) - i + this.underlyingType.hashCodeSemantics();
/*  95 */     i = (i << 5) - i + this.sizeInBits;
/*  96 */     return (i << 5) - i + this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalSemanticsImpl(Type paramType) {
/* 101 */     BitType bitType = (BitType)paramType;
/* 102 */     return (super.equalSemanticsImpl(paramType) && this.underlyingType
/* 103 */       .equalSemantics(bitType.underlyingType) && this.sizeInBits == bitType.sizeInBits && this.offset == bitType.offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BitType asBit() {
/* 109 */     return this;
/*     */   }
/*     */   
/*     */   public int getSizeInBits() {
/* 113 */     return this.sizeInBits;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 119 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(TypeVisitor paramTypeVisitor) {
/* 124 */     super.visit(paramTypeVisitor);
/* 125 */     this.underlyingType.visit(paramTypeVisitor);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/BitType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */