/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CompoundType
/*     */   extends MemoryLayoutType
/*     */   implements Cloneable, AliasedSymbol
/*     */ {
/*     */   private final String structName;
/*     */   private ArrayList<Field> fields;
/*     */   private boolean visiting;
/*     */   private boolean bodyParsed;
/*     */   
/*     */   public void rename(String paramString) {
/*  60 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void addAliasedName(String paramString) {
/*  64 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean hasAliases() {
/*  68 */     return false;
/*     */   }
/*     */   
/*     */   public Set<String> getAliasedNames() {
/*  72 */     return null;
/*     */   }
/*     */   
/*     */   public String getAliasedString() {
/*  76 */     return toString();
/*     */   }
/*     */   
/*     */   public String getOrigName() {
/*  80 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CompoundType create(String paramString, SizeThunk paramSizeThunk, CompoundTypeKind paramCompoundTypeKind, int paramInt, ASTLocusTag paramASTLocusTag) {
/*     */     StructType structType;
/*  95 */     switch (paramCompoundTypeKind) {
/*     */       case STRUCT:
/*  97 */         return new StructType(null, paramSizeThunk, paramInt, paramString, paramASTLocusTag);
/*     */       
/*     */       case UNION:
/* 100 */         return new UnionType(null, paramSizeThunk, paramInt, paramString, paramASTLocusTag);
/*     */     } 
/*     */     
/* 103 */     throw new RuntimeException("OO relation " + paramCompoundTypeKind + " / Compount not yet supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CompoundType(String paramString1, SizeThunk paramSizeThunk, int paramInt, String paramString2, ASTLocusTag paramASTLocusTag) {
/* 110 */     super((null == paramString1) ? paramString2 : paramString1, paramSizeThunk, paramInt, paramASTLocusTag);
/* 111 */     this.structName = paramString2;
/*     */   }
/*     */   
/*     */   CompoundType(CompoundType paramCompoundType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 115 */     super(paramCompoundType, paramInt, paramASTLocusTag);
/* 116 */     this.structName = paramCompoundType.structName;
/* 117 */     if (null != paramCompoundType.fields) {
/* 118 */       this.fields = new ArrayList<>(paramCompoundType.fields);
/*     */     }
/* 120 */     this.bodyParsed = paramCompoundType.bodyParsed;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeImpl() {
/* 126 */     int i = 31 + ((null != this.structName) ? this.structName.hashCode() : 0);
/* 127 */     return (i << 5) - i + TypeComparator.<Field>listsHashCode(this.fields);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalsImpl(Type paramType) {
/* 132 */     CompoundType compoundType = (CompoundType)paramType;
/* 133 */     return ((((this.structName == null) ? (compoundType.structName == null) : this.structName.equals(compoundType.structName)) || (this.structName != null && this.structName
/* 134 */       .equals(compoundType.structName))) && 
/*     */       
/* 136 */       TypeComparator.listsEqual(this.fields, compoundType.fields));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeSemanticsImpl() {
/* 142 */     return TypeComparator.listsHashCodeSemantics(this.fields);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalSemanticsImpl(Type paramType) {
/* 147 */     CompoundType compoundType = (CompoundType)paramType;
/* 148 */     return TypeComparator.listsEqualSemantics(this.fields, compoundType.fields);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStructName() {
/* 154 */     return this.structName;
/*     */   }
/*     */   
/*     */   public CompoundType asCompound() {
/* 158 */     return this;
/*     */   }
/*     */   
/*     */   public String getCName(boolean paramBoolean) {
/* 162 */     if (isTypedef()) {
/* 163 */       return getName(paramBoolean);
/*     */     }
/* 165 */     return (isStruct() ? "struct " : "union ") + getName(paramBoolean);
/*     */   }
/*     */   
/*     */   ArrayList<Field> getFields() {
/* 169 */     return this.fields; } void setFields(ArrayList<Field> paramArrayList) {
/* 170 */     this.fields = paramArrayList; clearCache();
/*     */   }
/*     */   
/*     */   public int getNumFields() {
/* 174 */     return (this.fields == null) ? 0 : this.fields.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Field getField(int paramInt) {
/* 179 */     return this.fields.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Field getField(String paramString) {
/* 184 */     for (Field field : this.fields) {
/* 185 */       if (field.getName().equals(paramString)) {
/* 186 */         return field;
/*     */       }
/*     */     } 
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addField(Field paramField) {
/* 194 */     if (this.bodyParsed) {
/* 195 */       throw new IllegalStateException(String.format("Body of this CompoundType (%s) has been already closed (Field supplied %s)", new Object[] { this, paramField }));
/*     */     }
/*     */ 
/*     */     
/* 199 */     if (this.fields == null) {
/* 200 */       this.fields = new ArrayList<>();
/*     */     }
/* 202 */     this.fields.add(paramField);
/* 203 */     clearCache();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBodyParsed() throws IllegalStateException {
/* 212 */     if (this.bodyParsed) {
/* 213 */       throw new IllegalStateException(String.format("Body of this CompoundType (%s) has been already closed", new Object[] { this }));
/*     */     }
/*     */ 
/*     */     
/* 217 */     this.bodyParsed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract boolean isStruct();
/*     */ 
/*     */   
/*     */   public abstract boolean isUnion();
/*     */   
/*     */   public String toString() {
/* 227 */     String str1 = getCVAttributesString();
/* 228 */     String str2 = getCName();
/* 229 */     if (null != str2)
/* 230 */       return str1 + str2; 
/* 231 */     if (getStructName() != null) {
/* 232 */       return str1 + "struct " + getStructName();
/*     */     }
/* 234 */     return str1 + getStructString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(TypeVisitor paramTypeVisitor) {
/* 240 */     if (this.visiting) {
/*     */       return;
/*     */     }
/*     */     try {
/* 244 */       this.visiting = true;
/* 245 */       super.visit(paramTypeVisitor);
/* 246 */       int i = getNumFields();
/* 247 */       for (byte b = 0; b < i; b++) {
/* 248 */         getField(b).getType().visit(paramTypeVisitor);
/*     */       }
/*     */     } finally {
/* 251 */       this.visiting = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStructString() {
/* 257 */     if (this.visiting) {
/* 258 */       if (getName() != null) {
/* 259 */         return getName();
/*     */       }
/* 261 */       return "struct {/*Recursive type reference*/}";
/*     */     } 
/*     */     
/*     */     try {
/* 265 */       this.visiting = true;
/* 266 */       String str = isStruct() ? "struct {" : "union {";
/* 267 */       StringBuilder stringBuilder = new StringBuilder();
/* 268 */       stringBuilder.append(str);
/* 269 */       int i = getNumFields();
/* 270 */       for (byte b = 0; b < i; b++) {
/* 271 */         stringBuilder.append(" ");
/* 272 */         stringBuilder.append(getField(b));
/*     */       } 
/* 274 */       stringBuilder.append(" }");
/* 275 */       return stringBuilder.toString();
/*     */     } finally {
/* 277 */       this.visiting = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/CompoundType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */