/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayType
/*     */   extends MemoryLayoutType
/*     */   implements Cloneable
/*     */ {
/*     */   private final Type elementType;
/*     */   private final int length;
/*     */   
/*     */   public ArrayType(Type paramType, SizeThunk paramSizeThunk, int paramInt1, int paramInt2) {
/*  56 */     this(paramType, paramSizeThunk, paramInt1, paramInt2, null);
/*     */   }
/*     */   
/*     */   public ArrayType(Type paramType, SizeThunk paramSizeThunk, int paramInt1, int paramInt2, ASTLocusTag paramASTLocusTag) {
/*  60 */     super(paramType.getName() + " *", paramSizeThunk, paramInt2, paramASTLocusTag);
/*  61 */     this.elementType = paramType;
/*  62 */     this.length = paramInt1;
/*     */   }
/*     */   private ArrayType(ArrayType paramArrayType, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  65 */     super(paramArrayType, paramInt, paramASTLocusTag);
/*  66 */     this.elementType = paramArrayType.elementType;
/*  67 */     this.length = paramArrayType.length;
/*     */   }
/*     */ 
/*     */   
/*     */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  72 */     return new ArrayType(this, paramInt, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeImpl() {
/*  78 */     int i = this.elementType.hashCode();
/*  79 */     return (i << 5) - i + this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalsImpl(Type paramType) {
/*  84 */     ArrayType arrayType = (ArrayType)paramType;
/*  85 */     return (this.elementType.equals(arrayType.elementType) && this.length == arrayType.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeSemanticsImpl() {
/*  92 */     int i = this.elementType.hashCodeSemantics();
/*  93 */     return (i << 5) - i + this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalSemanticsImpl(Type paramType) {
/*  98 */     ArrayType arrayType = (ArrayType)paramType;
/*  99 */     return (this.elementType.equalSemantics(arrayType.elementType) && this.length == arrayType.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnon() {
/* 104 */     return this.elementType.isAnon();
/*     */   }
/*     */   
/*     */   public String getName(boolean paramBoolean) {
/* 108 */     return this.elementType.getName() + " *";
/*     */   }
/*     */   
/*     */   public final ArrayType asArray() {
/* 112 */     return this;
/*     */   }
/*     */   
/* 115 */   public final Type getTargetType() { return this.elementType; }
/* 116 */   public int getLength() { return this.length; } public boolean hasLength() {
/* 117 */     return (this.length >= 0);
/*     */   }
/*     */   
/*     */   public final Type getBaseType() {
/* 121 */     return this.elementType.getBaseType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getArrayBaseOrPointerTargetType() {
/* 126 */     if (this.elementType.isPointer()) {
/* 127 */       return getTargetType();
/*     */     }
/* 129 */     return getBaseType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int arrayDimension() {
/* 135 */     return 1 + this.elementType.arrayDimension();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void recomputeSize() {
/* 141 */     ArrayType arrayType = getTargetType().asArray();
/* 142 */     if (arrayType != null) {
/* 143 */       arrayType.recomputeSize();
/*     */     }
/* 145 */     setSize(SizeThunk.mul(SizeThunk.constant(getLength()), this.elementType.getSize()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     return toString(null);
/*     */   }
/*     */   
/*     */   public String toString(String paramString) {
/* 154 */     StringBuilder stringBuilder = new StringBuilder();
/* 155 */     if (this.elementType.isConst()) {
/* 156 */       stringBuilder.append("const ");
/*     */     }
/* 158 */     stringBuilder.append(this.elementType.getCName());
/* 159 */     if (paramString != null) {
/* 160 */       stringBuilder.append(" ");
/* 161 */       stringBuilder.append(paramString);
/*     */     } 
/* 163 */     stringBuilder.append("[");
/* 164 */     stringBuilder.append(this.length);
/* 165 */     stringBuilder.append("]");
/* 166 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(TypeVisitor paramTypeVisitor) {
/* 171 */     super.visit(paramTypeVisitor);
/* 172 */     this.elementType.visit(paramTypeVisitor);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/ArrayType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */