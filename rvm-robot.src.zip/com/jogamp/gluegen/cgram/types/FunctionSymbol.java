/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionSymbol
/*     */   extends AliasedSymbol.AliasedSymbolImpl
/*     */   implements TypeComparator.AliasedSemanticSymbol, ASTLocusTag.ASTLocusTagProvider
/*     */ {
/*     */   private final FunctionType type;
/*     */   private final ASTLocusTag astLocus;
/*     */   
/*     */   public FunctionSymbol(String paramString, FunctionType paramFunctionType) {
/*  69 */     this(paramString, paramFunctionType, (ASTLocusTag)null);
/*     */   }
/*     */   
/*     */   public FunctionSymbol(String paramString, FunctionType paramFunctionType, ASTLocusTag paramASTLocusTag) {
/*  73 */     super(paramString);
/*  74 */     this.type = paramFunctionType;
/*  75 */     this.astLocus = paramASTLocusTag;
/*  76 */     addAliasedName(paramFunctionType.getCName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static FunctionSymbol cloneWithDeepAliases(FunctionSymbol paramFunctionSymbol) {
/*  81 */     return new FunctionSymbol(paramFunctionSymbol);
/*     */   }
/*     */   
/*     */   private FunctionSymbol(FunctionSymbol paramFunctionSymbol) {
/*  85 */     super(paramFunctionSymbol);
/*  86 */     this.type = paramFunctionSymbol.type;
/*  87 */     this.astLocus = paramFunctionSymbol.astLocus;
/*     */   }
/*     */   
/*     */   public ASTLocusTag getASTLocusTag() {
/*  91 */     return this.astLocus;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunctionType getType() {
/*  96 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getReturnType() {
/* 101 */     return this.type.getReturnType();
/*     */   }
/*     */   
/*     */   public int getNumArguments() {
/* 105 */     return this.type.getNumArguments();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getArgumentName(int paramInt) {
/* 111 */     return this.type.getArgumentName(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getArgumentType(int paramInt) {
/* 116 */     return this.type.getArgumentType(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addArgument(Type paramType, String paramString) {
/* 122 */     this.type.addArgument(paramType, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 127 */     return getType().toString(getName(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(boolean paramBoolean) {
/* 132 */     return getType().toString(getName(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 137 */     if (getName() == null) {
/* 138 */       return 0;
/*     */     }
/* 140 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 145 */     if (paramObject == this) {
/* 146 */       return true;
/*     */     }
/* 148 */     if (!(paramObject instanceof FunctionSymbol)) {
/* 149 */       return false;
/*     */     }
/* 151 */     FunctionSymbol functionSymbol = (FunctionSymbol)paramObject;
/* 152 */     if (getName() == null && functionSymbol.getName() != null) {
/* 153 */       return false;
/*     */     }
/* 155 */     return getName().equals(functionSymbol.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCodeSemantics() {
/* 160 */     return this.type.hashCodeSemantics();
/*     */   }
/*     */   
/*     */   public final boolean equalSemantics(TypeComparator.SemanticEqualityOp paramSemanticEqualityOp) {
/* 164 */     if (paramSemanticEqualityOp == this) {
/* 165 */       return true;
/*     */     }
/* 167 */     if (!(paramSemanticEqualityOp instanceof FunctionSymbol)) {
/* 168 */       return false;
/*     */     }
/* 170 */     FunctionSymbol functionSymbol = (FunctionSymbol)paramSemanticEqualityOp;
/* 171 */     return this.type.equalSemantics(functionSymbol.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean containsExactly(List<FunctionSymbol> paramList, FunctionSymbol paramFunctionSymbol) {
/* 176 */     return (exactIndexOf(paramList, paramFunctionSymbol) >= 0);
/*     */   }
/*     */   
/*     */   public static int exactIndexOf(List<FunctionSymbol> paramList, FunctionSymbol paramFunctionSymbol) {
/* 180 */     int i = paramList.size();
/* 181 */     for (byte b = 0; b < i; b++) {
/* 182 */       FunctionSymbol functionSymbol = paramList.get(b);
/* 183 */       if ((null == paramFunctionSymbol && null == functionSymbol) || (paramFunctionSymbol
/* 184 */         .equals(functionSymbol) && paramFunctionSymbol.type.equals(functionSymbol.type))) {
/* 185 */         return b;
/*     */       }
/*     */     } 
/* 188 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exactlyEqual(Object paramObject) {
/* 196 */     if (!equals(paramObject)) {
/* 197 */       return false;
/*     */     }
/* 199 */     return this.type.equals(((FunctionSymbol)paramObject).type);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/FunctionSymbol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */