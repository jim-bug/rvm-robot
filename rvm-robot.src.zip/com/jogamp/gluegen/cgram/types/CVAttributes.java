package com.jogamp.gluegen.cgram.types;

public interface CVAttributes {
  public static final int CONST = 1;
  
  public static final int VOLATILE = 2;
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/CVAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */