/*    */ package com.jogamp.gluegen.cgram.types;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CompoundTypeKind
/*    */ {
/* 34 */   STRUCT(0), UNION(1);
/*    */   
/*    */   public final int id;
/*    */   
/*    */   CompoundTypeKind(int paramInt1) {
/* 39 */     this.id = paramInt1;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/CompoundTypeKind.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */