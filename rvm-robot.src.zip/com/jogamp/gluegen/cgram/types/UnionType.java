/*    */ package com.jogamp.gluegen.cgram.types;
/*    */ 
/*    */ import com.jogamp.gluegen.ASTLocusTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnionType
/*    */   extends CompoundType
/*    */ {
/*    */   UnionType(String paramString1, SizeThunk paramSizeThunk, int paramInt, String paramString2, ASTLocusTag paramASTLocusTag) {
/* 35 */     super(paramString1, paramSizeThunk, paramInt, paramString2, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   private UnionType(UnionType paramUnionType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 39 */     super(paramUnionType, paramInt, paramASTLocusTag);
/*    */   }
/*    */ 
/*    */   
/*    */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 44 */     return new UnionType(this, paramInt, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   public final boolean isStruct() {
/* 48 */     return false;
/*    */   } public final boolean isUnion() {
/* 50 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/UnionType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */