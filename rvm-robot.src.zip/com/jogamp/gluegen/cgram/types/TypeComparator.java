/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeComparator
/*     */ {
/*     */   static <C> boolean listsEqual(List<C> paramList1, List<C> paramList2) {
/*  56 */     if (paramList1 == null) {
/*  57 */       if (null != paramList2) {
/*  58 */         return false;
/*     */       }
/*  60 */       return true;
/*     */     } 
/*     */     
/*  63 */     if (paramList2 != null && paramList1.size() == paramList2.size()) {
/*  64 */       int i = paramList1.size();
/*  65 */       for (byte b = 0; b < i; b++) {
/*  66 */         C c1 = paramList1.get(b);
/*  67 */         C c2 = paramList2.get(b);
/*  68 */         if (null == c1) {
/*  69 */           if (null != c2) {
/*  70 */             return false;
/*     */           
/*     */           }
/*     */         
/*     */         }
/*  75 */         else if (!c1.equals(c2)) {
/*  76 */           return false;
/*     */         } 
/*     */       } 
/*  79 */       return true;
/*     */     } 
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static <C extends SemanticEqualityOp> int listsHashCode(List<C> paramList) {
/*  86 */     if (paramList == null) {
/*  87 */       return 0;
/*     */     }
/*  89 */     int i = paramList.size();
/*  90 */     int j = 31;
/*  91 */     for (byte b = 0; b < i; b++) {
/*  92 */       SemanticEqualityOp semanticEqualityOp = (SemanticEqualityOp)paramList.get(b);
/*  93 */       j = (j << 5) - j + ((null != semanticEqualityOp) ? semanticEqualityOp.hashCode() : 0);
/*     */     } 
/*  95 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <C extends SemanticEqualityOp> boolean listsEqualSemantics(List<C> paramList1, List<C> paramList2) {
/* 101 */     if (paramList1 == null) {
/* 102 */       if (null != paramList2) {
/* 103 */         return false;
/*     */       }
/* 105 */       return true;
/*     */     } 
/*     */     
/* 108 */     if (paramList2 != null && paramList1.size() == paramList2.size()) {
/* 109 */       int i = paramList1.size();
/* 110 */       for (byte b = 0; b < i; b++) {
/* 111 */         SemanticEqualityOp semanticEqualityOp1 = (SemanticEqualityOp)paramList1.get(b);
/* 112 */         SemanticEqualityOp semanticEqualityOp2 = (SemanticEqualityOp)paramList2.get(b);
/* 113 */         if (null == semanticEqualityOp1) {
/* 114 */           if (null != semanticEqualityOp2) {
/* 115 */             return false;
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 120 */         else if (!semanticEqualityOp1.equalSemantics(semanticEqualityOp2)) {
/* 121 */           return false;
/*     */         } 
/*     */       } 
/* 124 */       return true;
/*     */     } 
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static <C extends SemanticEqualityOp> int listsHashCodeSemantics(List<C> paramList) {
/* 131 */     if (paramList == null) {
/* 132 */       return 0;
/*     */     }
/* 134 */     int i = paramList.size();
/* 135 */     int j = 31;
/* 136 */     for (byte b = 0; b < i; b++) {
/* 137 */       SemanticEqualityOp semanticEqualityOp = (SemanticEqualityOp)paramList.get(b);
/* 138 */       j = (j << 5) - j + ((null != semanticEqualityOp) ? semanticEqualityOp.hashCodeSemantics() : 0);
/*     */     } 
/* 140 */     return j;
/*     */   }
/*     */   
/*     */   public static interface SemanticEqualityOp {
/*     */     int hashCodeSemantics();
/*     */     
/*     */     boolean equalSemantics(SemanticEqualityOp param1SemanticEqualityOp);
/*     */   }
/*     */   
/*     */   public static interface AliasedSemanticSymbol extends AliasedSymbol, SemanticEqualityOp {}
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/TypeComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */