/*    */ package com.jogamp.gluegen.cgram.types;
/*    */ 
/*    */ import com.jogamp.gluegen.ASTLocusTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StructType
/*    */   extends CompoundType
/*    */ {
/*    */   StructType(String paramString1, SizeThunk paramSizeThunk, int paramInt, String paramString2, ASTLocusTag paramASTLocusTag) {
/* 35 */     super(paramString1, paramSizeThunk, paramInt, paramString2, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   private StructType(StructType paramStructType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 39 */     super(paramStructType, paramInt, paramASTLocusTag);
/*    */   }
/*    */ 
/*    */   
/*    */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 44 */     return new StructType(this, paramInt, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   public final boolean isStruct() {
/* 48 */     return true;
/*    */   } public final boolean isUnion() {
/* 50 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/StructType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */