/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AliasedSymbol
/*     */ {
/*     */   void rename(String paramString);
/*     */   
/*     */   void addAliasedName(String paramString);
/*     */   
/*     */   boolean hasAliases();
/*     */   
/*     */   Set<String> getAliasedNames();
/*     */   
/*     */   String getOrigName();
/*     */   
/*     */   String getName();
/*     */   
/*     */   String getAliasedString();
/*     */   
/*     */   public static class AliasedSymbolImpl
/*     */     implements AliasedSymbol
/*     */   {
/*     */     private final String origName;
/*     */     private final HashSet<String> aliasedNames;
/*     */     private String name;
/*     */     
/*     */     public AliasedSymbolImpl(String param1String) {
/* 103 */       if (null == param1String) {
/* 104 */         throw new IllegalArgumentException("Null origName not allowed");
/*     */       }
/* 106 */       this.origName = param1String;
/* 107 */       this.aliasedNames = new HashSet<>();
/* 108 */       this.name = param1String;
/*     */     }
/*     */     public AliasedSymbolImpl(AliasedSymbolImpl param1AliasedSymbolImpl) {
/* 111 */       this.origName = param1AliasedSymbolImpl.origName;
/* 112 */       this.aliasedNames = new HashSet<>(param1AliasedSymbolImpl.aliasedNames);
/* 113 */       this.name = param1AliasedSymbolImpl.name;
/*     */     }
/*     */     
/*     */     public void rename(String param1String) {
/* 117 */       if (null != param1String && !this.name.equals(param1String)) {
/* 118 */         this.aliasedNames.add(this.name);
/* 119 */         this.aliasedNames.remove(param1String);
/* 120 */         this.name = param1String;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void addAliasedName(String param1String) {
/* 125 */       if (null != param1String && !this.name.equals(param1String)) {
/* 126 */         this.aliasedNames.add(param1String);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean hasAliases() {
/* 131 */       return (this.aliasedNames.size() > 0);
/*     */     }
/*     */     
/*     */     public Set<String> getAliasedNames() {
/* 135 */       return this.aliasedNames;
/*     */     }
/*     */     
/*     */     public String getOrigName() {
/* 139 */       return this.origName;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 143 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getAliasedString() {
/* 147 */       return "[" + this.name + ", aliases " + this.aliasedNames.toString() + ", " + toString() + "]";
/*     */     } }
/*     */   
/*     */   public static class NoneAliasedSymbol implements AliasedSymbol {
/*     */     private final String name;
/*     */     
/*     */     public NoneAliasedSymbol(String param1String) {
/* 154 */       this.name = param1String;
/*     */     }
/*     */     
/*     */     public void rename(String param1String) {
/* 158 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public void addAliasedName(String param1String) {
/* 162 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean hasAliases() {
/* 166 */       return false;
/*     */     }
/*     */     
/*     */     public Set<String> getAliasedNames() {
/* 170 */       return null;
/*     */     }
/*     */     
/*     */     public String getOrigName() {
/* 174 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 178 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getAliasedString() {
/* 182 */       return toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/AliasedSymbol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */