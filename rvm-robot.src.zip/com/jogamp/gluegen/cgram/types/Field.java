/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.common.os.MachineDataInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Field
/*     */   implements TypeComparator.SemanticEqualityOp
/*     */ {
/*     */   private final String name;
/*     */   private final Type type;
/*     */   private SizeThunk offset;
/*     */   
/*     */   public Field(String paramString, Type paramType, SizeThunk paramSizeThunk) {
/*  53 */     this.name = paramString;
/*  54 */     this.type = paramType;
/*  55 */     this.offset = paramSizeThunk;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  61 */     int i = 31 + ((null != this.name) ? this.name.hashCode() : 0);
/*  62 */     return (i << 5) - i + this.type.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  67 */     if (!(paramObject instanceof Field)) {
/*  68 */       return false;
/*     */     }
/*     */     
/*  71 */     Field field = (Field)paramObject;
/*     */ 
/*     */     
/*  74 */     return (((this.name != null && this.name.equals(field.name)) || (this.name == null && field.name == null)) && this.type
/*     */ 
/*     */       
/*  77 */       .equals(field.type));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCodeSemantics() {
/*  82 */     return this.type.hashCodeSemantics();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equalSemantics(TypeComparator.SemanticEqualityOp paramSemanticEqualityOp) {
/*  87 */     if (!(paramSemanticEqualityOp instanceof Field)) {
/*  88 */       return false;
/*     */     }
/*     */     
/*  91 */     Field field = (Field)paramSemanticEqualityOp;
/*     */ 
/*     */     
/*  94 */     return this.type.equalSemantics(field.type);
/*     */   }
/*     */   
/*     */   public String getName() {
/*  98 */     return this.name;
/*     */   }
/*     */   public Type getType() {
/* 101 */     return this.type;
/*     */   }
/*     */   public SizeThunk getOffset() {
/* 104 */     return this.offset;
/*     */   }
/*     */   
/*     */   public long getOffset(MachineDataInfo paramMachineDataInfo) {
/* 108 */     return this.offset.computeSize(paramMachineDataInfo);
/*     */   }
/*     */   public void setOffset(SizeThunk paramSizeThunk) {
/* 111 */     this.offset = paramSizeThunk;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 115 */     if (!getType().isFunctionPointer()) {
/* 116 */       if (getName() == null && 
/* 117 */         getType().asCompound() != null && 
/* 118 */         getType().asCompound().isUnion()) {
/* 119 */         return "" + getType() + ";";
/*     */       }
/* 121 */       return "" + getType() + " " + getName() + ";";
/*     */     } 
/* 123 */     FunctionType functionType = getType().getTargetFunction();
/*     */     
/* 125 */     return functionType.toString(getName(), null, false, true) + ";";
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/Field.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */