/*    */ package com.jogamp.gluegen.cgram.types;
/*    */ 
/*    */ import com.jogamp.gluegen.ASTLocusTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FloatType
/*    */   extends PrimitiveType
/*    */   implements Cloneable
/*    */ {
/*    */   public FloatType(String paramString, SizeThunk paramSizeThunk, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 49 */     super(paramString, paramSizeThunk, paramInt, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   private FloatType(FloatType paramFloatType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 53 */     super(paramFloatType, paramInt, paramASTLocusTag);
/*    */   }
/*    */ 
/*    */   
/*    */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 58 */     return new FloatType(this, paramInt, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   public FloatType asFloat() {
/* 62 */     return this;
/*    */   }
/*    */   
/*    */   protected int hashCodeImpl() {
/* 66 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean equalsImpl(Type paramType) {
/* 71 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int hashCodeSemanticsImpl() {
/* 76 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean equalSemanticsImpl(Type paramType) {
/* 81 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/FloatType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */