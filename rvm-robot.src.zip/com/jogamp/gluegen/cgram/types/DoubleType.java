/*    */ package com.jogamp.gluegen.cgram.types;
/*    */ 
/*    */ import com.jogamp.gluegen.ASTLocusTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleType
/*    */   extends PrimitiveType
/*    */   implements Cloneable
/*    */ {
/*    */   public DoubleType(String paramString, SizeThunk paramSizeThunk, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 48 */     super(paramString, paramSizeThunk, paramInt, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   private DoubleType(DoubleType paramDoubleType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 52 */     super(paramDoubleType, paramInt, paramASTLocusTag);
/*    */   }
/*    */ 
/*    */   
/*    */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 57 */     return new DoubleType(this, paramInt, paramASTLocusTag);
/*    */   }
/*    */ 
/*    */   
/*    */   public DoubleType asDouble() {
/* 62 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int hashCodeImpl() {
/* 67 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean equalsImpl(Type paramType) {
/* 72 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int hashCodeSemanticsImpl() {
/* 77 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean equalSemanticsImpl(Type paramType) {
/* 82 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/DoubleType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */