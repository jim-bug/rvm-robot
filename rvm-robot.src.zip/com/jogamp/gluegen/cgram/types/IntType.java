/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntType
/*     */   extends PrimitiveType
/*     */   implements Cloneable
/*     */ {
/*     */   private final boolean unsigned;
/*     */   private boolean typedefUnsigned;
/*     */   
/*     */   public IntType(String paramString, SizeThunk paramSizeThunk, boolean paramBoolean, int paramInt) {
/*  50 */     this(paramString, paramSizeThunk, paramBoolean, paramInt, (ASTLocusTag)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IntType(String paramString, SizeThunk paramSizeThunk, boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  56 */     super(paramString, paramSizeThunk, paramInt, paramASTLocusTag);
/*  57 */     this.unsigned = paramBoolean;
/*  58 */     this.typedefUnsigned = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntType(String paramString, SizeThunk paramSizeThunk, boolean paramBoolean1, int paramInt, boolean paramBoolean2, boolean paramBoolean3, ASTLocusTag paramASTLocusTag) {
/*  76 */     super(paramString, paramSizeThunk, paramInt, paramASTLocusTag);
/*  77 */     this.unsigned = paramBoolean1;
/*  78 */     if (paramBoolean2) {
/*     */       
/*  80 */       setTypedef(0);
/*  81 */       this.typedefUnsigned = paramBoolean3;
/*     */     } else {
/*  83 */       this.typedefUnsigned = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   IntType(IntType paramIntType, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  88 */     super(paramIntType, paramInt, paramASTLocusTag);
/*  89 */     this.unsigned = paramIntType.unsigned;
/*  90 */     this.typedefUnsigned = paramIntType.typedefUnsigned;
/*     */   }
/*     */ 
/*     */   
/*     */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  95 */     return new IntType(this, paramInt, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeImpl() {
/* 101 */     int i = 1;
/* 102 */     i = (i << 5) - i + (this.unsigned ? 1 : 0);
/* 103 */     return (i << 5) - i + (this.typedefUnsigned ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalsImpl(Type paramType) {
/* 108 */     IntType intType = (IntType)paramType;
/* 109 */     return (this.unsigned == intType.unsigned && this.typedefUnsigned == intType.typedefUnsigned);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeSemanticsImpl() {
/* 116 */     int i = 1;
/* 117 */     if (!this.relaxedEqSem) {
/* 118 */       i = (i << 5) - i + (this.unsigned ? 1 : 0);
/* 119 */       i = (i << 5) - i + (this.typedefUnsigned ? 1 : 0);
/*     */     } 
/* 121 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalSemanticsImpl(Type paramType) {
/* 126 */     IntType intType = (IntType)paramType;
/* 127 */     return (this.relaxedEqSem || (this.unsigned == intType.unsigned && this.typedefUnsigned == intType.typedefUnsigned));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntType asInt() {
/* 135 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUnsigned() {
/* 140 */     return this.unsigned;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCName(boolean paramBoolean) {
/* 145 */     if (!this.unsigned || this.typedefUnsigned) {
/* 146 */       return super.getCName(paramBoolean);
/*     */     }
/* 148 */     return "unsigned " + super.getCName(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 154 */     return getCVAttributesString() + ((this.unsigned && !this.typedefUnsigned) ? "unsigned " : "") + getCName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setTypedefName(String paramString) {
/* 159 */     if (super.setTypedefName(paramString)) {
/* 160 */       this.typedefUnsigned = this.unsigned;
/* 161 */       return true;
/*     */     } 
/* 163 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/IntType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */