/*    */ package com.jogamp.gluegen.cgram.types;
/*    */ 
/*    */ import com.jogamp.gluegen.ASTLocusTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MemoryLayoutType
/*    */   extends Type
/*    */ {
/*    */   private boolean isLayouted;
/*    */   
/*    */   protected MemoryLayoutType(String paramString, SizeThunk paramSizeThunk, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 36 */     super(paramString, paramSizeThunk, paramInt, paramASTLocusTag);
/* 37 */     this.isLayouted = false;
/*    */   }
/*    */   MemoryLayoutType(MemoryLayoutType paramMemoryLayoutType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 40 */     super(paramMemoryLayoutType, paramInt, paramASTLocusTag);
/* 41 */     this.isLayouted = paramMemoryLayoutType.isLayouted;
/*    */   }
/*    */   public boolean isLayouted() {
/* 44 */     return this.isLayouted;
/*    */   } public void setLayouted() {
/* 46 */     this.isLayouted = true;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/MemoryLayoutType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */