/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.common.os.MachineDataInfo;
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ import com.jogamp.gluegen.GlueGen;
/*     */ import com.jogamp.gluegen.TypeConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Type
/*     */   implements TypeComparator.SemanticEqualityOp, ASTLocusTag.ASTLocusTagProvider
/*     */ {
/*     */   public final boolean relaxedEqSem;
/*     */   private final int cvAttributes;
/*     */   final ASTLocusTag astLocus;
/*     */   private String name;
/*     */   private SizeThunk size;
/*     */   private int typedefCVAttributes;
/*     */   private boolean isTypedef;
/*     */   private boolean hasCachedHash;
/*     */   private int cachedHash;
/*     */   private boolean hasCachedSemanticHash;
/*     */   private int cachedSemanticHash;
/*     */   
/*     */   protected Type(String paramString, SizeThunk paramSizeThunk, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  68 */     setName(paramString);
/*  69 */     this.relaxedEqSem = TypeConfig.relaxedEqualSemanticsTest();
/*  70 */     this.cvAttributes = paramInt;
/*  71 */     this.astLocus = paramASTLocusTag;
/*  72 */     this.size = paramSizeThunk;
/*  73 */     this.typedefCVAttributes = 0;
/*  74 */     this.isTypedef = false;
/*     */   }
/*     */   Type(Type paramType, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  77 */     this.relaxedEqSem = paramType.relaxedEqSem;
/*  78 */     this.cvAttributes = paramInt;
/*  79 */     this.astLocus = paramASTLocusTag;
/*  80 */     this.name = paramType.name;
/*  81 */     this.size = paramType.size;
/*  82 */     this.typedefCVAttributes = paramType.typedefCVAttributes;
/*  83 */     this.isTypedef = paramType.isTypedef;
/*  84 */     clearCache();
/*     */   }
/*     */   
/*     */   protected final void clearCache() {
/*  88 */     this.hasCachedHash = false;
/*  89 */     this.cachedHash = 0;
/*  90 */     this.hasCachedSemanticHash = false;
/*  91 */     this.cachedSemanticHash = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Type newCVVariant(int paramInt) {
/*  99 */     if (this.cvAttributes == paramInt) {
/* 100 */       return this;
/*     */     }
/* 102 */     return newVariantImpl(true, paramInt, this.astLocus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type clone(ASTLocusTag paramASTLocusTag) {
/* 110 */     return newVariantImpl(true, this.cvAttributes, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ASTLocusTag getASTLocusTag() {
/* 125 */     return this.astLocus;
/*     */   } public boolean isAnon() {
/* 127 */     return (null == this.name);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getCName() {
/* 132 */     return getCName(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCName(boolean paramBoolean) {
/* 137 */     return getName(paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 142 */     return getName(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(boolean paramBoolean) {
/* 148 */     if (!paramBoolean) {
/* 149 */       return this.name;
/*     */     }
/* 151 */     return getCVAttributesString() + this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return getCName(true);
/*     */   }
/*     */ 
/*     */   
/*     */   private static StringBuilder append(StringBuilder paramStringBuilder, String paramString, boolean paramBoolean) {
/* 167 */     if (paramBoolean) {
/* 168 */       paramStringBuilder.append(", ");
/*     */     }
/* 170 */     paramStringBuilder.append(paramString);
/* 171 */     return paramStringBuilder;
/*     */   }
/*     */   public final StringBuilder getSignature(StringBuilder paramStringBuilder) {
/* 174 */     if (null == paramStringBuilder) {
/* 175 */       paramStringBuilder = new StringBuilder();
/*     */     }
/* 177 */     boolean bool = false;
/* 178 */     paramStringBuilder.append("(").append(getClass().getSimpleName()).append(") ");
/* 179 */     if (isTypedef()) {
/* 180 */       paramStringBuilder.append("typedef ");
/*     */     }
/* 182 */     if (null != this.name) {
/* 183 */       paramStringBuilder.append("'").append(this.name).append("'");
/*     */     } else {
/* 185 */       paramStringBuilder.append("ANON");
/*     */     } 
/* 187 */     if (isFunctionPointer()) {
/* 188 */       paramStringBuilder.append(" -> ");
/* 189 */       FunctionType functionType = getTargetFunction();
/* 190 */       paramStringBuilder.append(functionType.toString(null, null, false, true));
/*     */     } else {
/* 192 */       Type type = getTargetType();
/* 193 */       if (null != type && this != type) {
/* 194 */         paramStringBuilder.append(" -> ");
/* 195 */         paramStringBuilder.append("(" + type.toString() + ") * " + getCVAttributesString());
/*     */       } 
/*     */     } 
/*     */     
/* 199 */     if (GlueGen.debug()) {
/* 200 */       paramStringBuilder.append(", o=0x" + Integer.toHexString(objHash()));
/*     */     }
/* 202 */     paramStringBuilder.append(", size");
/* 203 */     bool = true;
/* 204 */     if (null != this.size) {
/*     */ 
/*     */       
/* 207 */       long l2 = -1L;
/*     */       try {
/* 209 */         l2 = this.size.computeSize(MachineDataInfo.StaticConfig.LP64_UNIX.md);
/* 210 */       } catch (Exception exception) {}
/* 211 */       long l1 = l2;
/*     */       
/* 213 */       paramStringBuilder.append("[fixed ").append(this.size.hasFixedNativeSize()).append(", lnx64 ").append(l1).append("]");
/*     */     } else {
/* 215 */       paramStringBuilder.append(" ZERO");
/*     */     } 
/*     */     
/* 218 */     append(paramStringBuilder, "const[", bool); bool = false;
/*     */     
/* 220 */     if (isConstTypedef()) {
/* 221 */       append(paramStringBuilder, "typedef", bool); bool = true;
/*     */     } 
/* 223 */     if (isConstRaw()) {
/* 224 */       append(paramStringBuilder, "native", bool); bool = true;
/*     */     } 
/* 226 */     if (isConst()) {
/* 227 */       append(paramStringBuilder, "true]", bool);
/*     */     } else {
/* 229 */       append(paramStringBuilder, "false]", bool);
/*     */     } 
/* 231 */     bool = true;
/*     */     
/* 233 */     append(paramStringBuilder, "is[", bool); bool = false;
/*     */     
/* 235 */     if (isVolatile()) {
/* 236 */       append(paramStringBuilder, "volatile ", bool); bool = true;
/*     */     } 
/* 238 */     if (isPrimitive()) {
/* 239 */       append(paramStringBuilder, "primitive", bool); bool = true;
/*     */     } 
/* 241 */     if (isPointer()) {
/* 242 */       append(paramStringBuilder, "pointer*" + pointerDepth(), bool); bool = true;
/*     */     } 
/* 244 */     if (isArray()) {
/* 245 */       append(paramStringBuilder, "array*" + arrayDimension(), bool); bool = true;
/*     */     } 
/* 247 */     if (isBit()) {
/* 248 */       append(paramStringBuilder, "bit", bool); bool = true;
/*     */     } 
/* 250 */     if (isCompound()) {
/* 251 */       append(paramStringBuilder, "struct{", bool).append(asCompound().getStructName()).append(": ").append(asCompound().getNumFields());
/* 252 */       append(paramStringBuilder, "}", bool); bool = true;
/*     */     } 
/* 254 */     if (isDouble()) {
/* 255 */       append(paramStringBuilder, "double", bool); bool = true;
/*     */     } 
/* 257 */     if (isEnum()) {
/* 258 */       EnumType enumType = asEnum();
/* 259 */       append(paramStringBuilder, "enum ", bool).append(" [").append(enumType.getUnderlyingType()).append("] {").append(enumType.getNumEnumerates()).append(": ");
/* 260 */       enumType.appendEnums(paramStringBuilder, false);
/* 261 */       bool = true;
/*     */     } 
/* 263 */     if (isFloat()) {
/* 264 */       append(paramStringBuilder, "float", bool); bool = true;
/*     */     } 
/* 266 */     if (isFunction()) {
/* 267 */       append(paramStringBuilder, "function", bool); bool = true;
/*     */     } 
/* 269 */     if (isFunctionPointer()) {
/* 270 */       append(paramStringBuilder, "funcPointer", bool); bool = true;
/*     */     } 
/* 272 */     if (isInt()) {
/* 273 */       append(paramStringBuilder, "int", bool); bool = true;
/*     */     } 
/* 275 */     if (isVoid()) {
/* 276 */       append(paramStringBuilder, "void", bool); bool = true;
/*     */     } 
/*     */     
/* 279 */     append(paramStringBuilder, "]", false); bool = true;
/*     */     
/* 281 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getDebugString() {
/* 286 */     StringBuilder stringBuilder = new StringBuilder();
/* 287 */     stringBuilder.append("CType[");
/* 288 */     getSignature(stringBuilder);
/* 289 */     stringBuilder.append("]");
/* 290 */     return stringBuilder.toString();
/*     */   } private final int objHash() {
/* 292 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean setName(String paramString) {
/* 309 */     clearCache();
/* 310 */     if (null == paramString || 0 == paramString.length()) {
/* 311 */       this.name = paramString;
/* 312 */       return false;
/*     */     } 
/* 314 */     this.name = paramString.intern();
/* 315 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setTypedefName(String paramString) {
/* 328 */     if (setName(paramString)) {
/*     */ 
/*     */       
/* 331 */       this.typedefCVAttributes = this.cvAttributes;
/* 332 */       this.isTypedef = true;
/* 333 */       return true;
/*     */     } 
/* 335 */     return false;
/*     */   }
/*     */   
/*     */   final void setTypedef(int paramInt) {
/* 339 */     this.name = this.name.intern();
/* 340 */     this.typedefCVAttributes = paramInt;
/* 341 */     this.isTypedef = true;
/* 342 */     clearCache();
/*     */   }
/*     */   final int getTypedefCVAttributes() {
/* 345 */     return this.typedefCVAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isTypedef() {
/* 353 */     return this.isTypedef;
/*     */   }
/*     */   
/*     */   public final boolean hasSize() {
/* 357 */     return (null != this.size);
/*     */   }
/*     */   public final SizeThunk getSize() {
/* 360 */     return this.size;
/*     */   }
/*     */   public final long getSize(MachineDataInfo paramMachineDataInfo) {
/* 363 */     SizeThunk sizeThunk = getSize();
/* 364 */     if (sizeThunk == null) {
/* 365 */       throw new RuntimeException("No size set for type \"" + getName() + "\"");
/*     */     }
/* 367 */     return sizeThunk.computeSize(paramMachineDataInfo);
/*     */   }
/*     */   
/*     */   final void setSize(SizeThunk paramSizeThunk) {
/* 371 */     this.size = paramSizeThunk;
/* 372 */     clearCache();
/*     */   }
/*     */   
/*     */   public BitType asBit() {
/* 376 */     return null;
/*     */   } public IntType asInt() {
/* 378 */     return null;
/*     */   } public EnumType asEnum() {
/* 380 */     return null;
/*     */   } public FloatType asFloat() {
/* 382 */     return null;
/*     */   } public DoubleType asDouble() {
/* 384 */     return null;
/*     */   } public PointerType asPointer() {
/* 386 */     return null;
/*     */   } public ArrayType asArray() {
/* 388 */     return null;
/*     */   } public CompoundType asCompound() {
/* 390 */     return null;
/*     */   } public FunctionType asFunction() {
/* 392 */     return null;
/*     */   } public VoidType asVoid() {
/* 394 */     return null;
/*     */   }
/*     */   public final boolean isBit() {
/* 397 */     return (asBit() != null);
/*     */   } public final boolean isInt() {
/* 399 */     return (asInt() != null);
/*     */   } public final boolean isEnum() {
/* 401 */     return (asEnum() != null);
/*     */   } public final boolean isFloat() {
/* 403 */     return (asFloat() != null);
/*     */   } public final boolean isDouble() {
/* 405 */     return (asDouble() != null);
/*     */   } public final boolean isPointer() {
/* 407 */     return (asPointer() != null);
/*     */   } public final boolean isArray() {
/* 409 */     return (asArray() != null);
/*     */   } public final boolean isCompound() {
/* 411 */     return (asCompound() != null);
/*     */   } public final boolean isFunction() {
/* 413 */     return (asFunction() != null);
/*     */   } public final boolean isVoid() {
/* 415 */     return (asVoid() != null);
/*     */   }
/*     */   public final boolean isVolatile() {
/* 418 */     return (0 != (this.cvAttributes & (this.typedefCVAttributes ^ 0xFFFFFFFF) & 0x2));
/*     */   } public final boolean isConst() {
/* 420 */     return (0 != (this.cvAttributes & (this.typedefCVAttributes ^ 0xFFFFFFFF) & 0x1));
/*     */   }
/* 422 */   private final boolean isConstTypedef() { return (0 != (this.typedefCVAttributes & 0x1)); } private final boolean isConstRaw() {
/* 423 */     return (0 != (this.cvAttributes & 0x1));
/*     */   }
/*     */   public boolean isPrimitive() {
/* 426 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFunctionPointer() {
/* 431 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isBaseTypeConst() {
/* 441 */     return getBaseType().isConst();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 447 */     if (!this.hasCachedHash) {
/*     */       
/* 449 */       int i = 31 + (this.isTypedef ? 1 : 0);
/* 450 */       i = (i << 5) - i + ((null != this.size) ? this.size.hashCode() : 0);
/* 451 */       i = (i << 5) - i + this.cvAttributes;
/* 452 */       i = (i << 5) - i + this.typedefCVAttributes;
/* 453 */       i = (i << 5) - i + ((null != this.name) ? this.name.hashCode() : 0);
/* 454 */       if (!this.isTypedef) {
/* 455 */         i = (i << 5) - i + hashCodeImpl();
/*     */       }
/* 457 */       this.cachedHash = i;
/* 458 */       this.hasCachedHash = true;
/*     */     } 
/* 460 */     return this.cachedHash;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int hashCodeImpl();
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 469 */     if (paramObject == this)
/* 470 */       return true; 
/* 471 */     if (!getClass().isInstance(paramObject)) {
/* 472 */       return false;
/*     */     }
/* 474 */     Type type = (Type)paramObject;
/* 475 */     if (this.isTypedef == type.isTypedef && ((null != this.size && this.size
/* 476 */       .equals(type.size)) || (null == this.size && null == type.size)) && this.cvAttributes == type.cvAttributes && this.typedefCVAttributes == type.typedefCVAttributes && ((null == this.name) ? (null == type.name) : this.name
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 481 */       .equals(type.name))) {
/*     */ 
/*     */       
/* 484 */       if (!this.isTypedef) {
/* 485 */         return equalsImpl(type);
/*     */       }
/* 487 */       return true;
/*     */     } 
/*     */     
/* 490 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract boolean equalsImpl(Type paramType);
/*     */ 
/*     */   
/*     */   public final int hashCodeSemantics() {
/* 498 */     if (!this.hasCachedSemanticHash) {
/*     */       
/* 500 */       int i = 31 + ((null != this.size) ? this.size.hashCodeSemantics() : 0);
/* 501 */       if (!this.relaxedEqSem) {
/* 502 */         i = (i << 5) - i + this.cvAttributes;
/* 503 */         i = (i << 5) - i + this.typedefCVAttributes;
/*     */       } 
/* 505 */       i = (i << 5) - i + hashCodeSemanticsImpl();
/* 506 */       this.cachedSemanticHash = i;
/* 507 */       this.hasCachedSemanticHash = true;
/*     */     } 
/* 509 */     return this.cachedSemanticHash;
/*     */   }
/*     */   
/*     */   protected abstract int hashCodeSemanticsImpl();
/*     */   
/*     */   public final boolean equalSemantics(TypeComparator.SemanticEqualityOp paramSemanticEqualityOp) {
/* 515 */     if (paramSemanticEqualityOp == this)
/* 516 */       return true; 
/* 517 */     if (!(paramSemanticEqualityOp instanceof Type) || 
/* 518 */       !getClass().isInstance(paramSemanticEqualityOp)) {
/* 519 */       return false;
/*     */     }
/* 521 */     Type type = (Type)paramSemanticEqualityOp;
/* 522 */     if (((null != this.size && this.size.equalSemantics(type.size)) || (null == this.size && null == type.size)) && (this.relaxedEqSem || (this.cvAttributes == type.cvAttributes && this.typedefCVAttributes == type.typedefCVAttributes)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 532 */       return equalSemanticsImpl(type);
/*     */     }
/* 534 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean equalSemanticsImpl(Type paramType);
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(TypeVisitor paramTypeVisitor) {
/* 545 */     paramTypeVisitor.visitType(this);
/*     */   }
/*     */   
/*     */   public final int getCVAttributes() {
/* 549 */     return this.cvAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getCVAttributesString() {
/* 555 */     if (isConst() && isVolatile()) return "const volatile "; 
/* 556 */     if (isConst()) return "const "; 
/* 557 */     if (isVolatile()) return "volatile "; 
/* 558 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int pointerDepth() {
/* 565 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int arrayDimension() {
/* 572 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getBaseType() {
/* 589 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getTargetType() {
/* 606 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getArrayBaseOrPointerTargetType() {
/* 613 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionType getTargetFunction() {
/* 619 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/Type.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */