/*     */ package com.jogamp.gluegen.cgram.types;
/*     */ 
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionType
/*     */   extends Type
/*     */   implements Cloneable
/*     */ {
/*     */   private final Type returnType;
/*     */   private ArrayList<Type> argumentTypes;
/*     */   private ArrayList<String> argumentNames;
/*     */   
/*     */   public FunctionType(String paramString, SizeThunk paramSizeThunk, Type paramType, int paramInt) {
/*  56 */     this(paramString, paramSizeThunk, paramType, paramInt, (ASTLocusTag)null);
/*     */   }
/*     */   
/*     */   public FunctionType(String paramString, SizeThunk paramSizeThunk, Type paramType, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  60 */     super(paramString, paramSizeThunk, paramInt, paramASTLocusTag);
/*  61 */     this.returnType = paramType;
/*     */   }
/*     */   
/*     */   private FunctionType(FunctionType paramFunctionType, ASTLocusTag paramASTLocusTag) {
/*  65 */     super(paramFunctionType, paramFunctionType.getCVAttributes(), paramASTLocusTag);
/*  66 */     this.returnType = paramFunctionType.returnType;
/*  67 */     if (null != paramFunctionType.argumentTypes) {
/*  68 */       this.argumentTypes = new ArrayList<>(paramFunctionType.argumentTypes);
/*     */     }
/*  70 */     if (null != paramFunctionType.argumentNames) {
/*  71 */       this.argumentNames = new ArrayList<>(paramFunctionType.argumentNames);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/*  77 */     if (paramBoolean)
/*     */     {
/*  79 */       return this;
/*     */     }
/*  81 */     return new FunctionType(this, paramASTLocusTag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeImpl() {
/*  88 */     int i = this.returnType.hashCode();
/*  89 */     return (i << 5) - i + TypeComparator.<Type>listsHashCode(this.argumentTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalsImpl(Type paramType) {
/*  94 */     FunctionType functionType = (FunctionType)paramType;
/*  95 */     return (this.returnType.equals(functionType.returnType) && 
/*  96 */       TypeComparator.listsEqual(this.argumentTypes, functionType.argumentTypes));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCodeSemanticsImpl() {
/* 102 */     int i = this.returnType.hashCodeSemantics();
/* 103 */     return (i << 5) - i + TypeComparator.<Type>listsHashCodeSemantics(this.argumentTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equalSemanticsImpl(Type paramType) {
/* 108 */     FunctionType functionType = (FunctionType)paramType;
/* 109 */     return (this.returnType.equalSemantics(functionType.returnType) && 
/* 110 */       TypeComparator.listsEqualSemantics(this.argumentTypes, functionType.argumentTypes));
/*     */   }
/*     */ 
/*     */   
/*     */   public FunctionType asFunction() {
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getReturnType() {
/* 120 */     return this.returnType;
/*     */   }
/*     */   
/*     */   public int getNumArguments() {
/* 124 */     return (this.argumentTypes == null) ? 0 : this.argumentTypes.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getArgumentName(int paramInt) {
/* 130 */     return this.argumentNames.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getArgumentType(int paramInt) {
/* 135 */     return this.argumentTypes.get(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getParameterList(StringBuilder paramStringBuilder, boolean paramBoolean, String paramString) {
/* 146 */     return getParameterList(paramStringBuilder, paramBoolean, paramString, (List<Integer>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getParameterList(StringBuilder paramStringBuilder, boolean paramBoolean, String paramString, List<Integer> paramList) {
/* 157 */     forEachParameter((paramInt1, paramInt2, paramType, paramString2) -> {
/*     */           if (!paramType.isVoid() && (null == paramList || !paramList.contains(Integer.valueOf(paramInt1)))) {
/*     */             if (0 < paramInt2) {
/*     */               paramStringBuilder.append(", ");
/*     */             }
/*     */             
/*     */             if (paramBoolean && paramType.isTypedef()) {
/*     */               paramStringBuilder.append(paramType.getName());
/*     */               if (paramString2 != null) {
/*     */                 paramStringBuilder.append(" ");
/*     */                 paramStringBuilder.append(paramString2);
/*     */               } 
/*     */             } else if (paramType.isFunctionPointer()) {
/*     */               FunctionType functionType = paramType.getTargetFunction();
/*     */               paramStringBuilder.append(functionType.toString(paramString2, paramString1, false, true));
/*     */             } else if (paramType.isArray()) {
/*     */               paramStringBuilder.append(paramType.asArray().toString(paramString2));
/*     */             } else {
/*     */               paramStringBuilder.append(paramType.getCName(true));
/*     */               if (paramString2 != null) {
/*     */                 paramStringBuilder.append(" ");
/*     */                 paramStringBuilder.append(paramString2);
/*     */               } 
/*     */             } 
/*     */             return true;
/*     */           } 
/*     */           return false;
/*     */         });
/* 185 */     return paramStringBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int forEachParameter(ParameterConsumer paramParameterConsumer) {
/* 202 */     int i = getNumArguments();
/* 203 */     byte b1 = 0;
/* 204 */     for (byte b2 = 0; b2 < i; b2++) {
/* 205 */       if (paramParameterConsumer.accept(b2, b1, getArgumentType(b2), getArgumentName(b2))) {
/* 206 */         b1++;
/*     */       }
/*     */     } 
/* 209 */     return b1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addArgument(Type paramType, String paramString) {
/* 216 */     if (this.argumentTypes == null) {
/* 217 */       this.argumentTypes = new ArrayList<>();
/* 218 */       this.argumentNames = new ArrayList<>();
/*     */     } 
/* 220 */     this.argumentTypes.add(paramType);
/* 221 */     this.argumentNames.add(paramString);
/* 222 */     clearCache();
/*     */   }
/*     */   
/*     */   public void setArgumentName(int paramInt, String paramString) {
/* 226 */     this.argumentNames.set(paramInt, paramString);
/* 227 */     clearCache();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 232 */     return toString((String)null, false);
/*     */   }
/*     */   
/*     */   public String toString(String paramString, boolean paramBoolean) {
/* 236 */     return toString(paramString, (String)null, paramBoolean, false);
/*     */   }
/*     */   public String toString(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 239 */     return toString(paramString, (String)null, paramBoolean1, paramBoolean2);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) {
/* 244 */     StringBuilder stringBuilder = new StringBuilder();
/* 245 */     stringBuilder.append(getReturnType().getCName(true));
/* 246 */     stringBuilder.append(" ");
/* 247 */     if (paramBoolean2) {
/* 248 */       stringBuilder.append("(");
/* 249 */       if (paramString2 != null) {
/* 250 */         stringBuilder.append(paramString2);
/*     */       }
/* 252 */       stringBuilder.append("*");
/*     */     } 
/* 254 */     if (paramString1 != null) {
/* 255 */       if (paramBoolean1)
/*     */       {
/* 257 */         stringBuilder.append("{@native ");
/*     */       }
/* 259 */       stringBuilder.append(paramString1);
/* 260 */       if (paramBoolean1) {
/* 261 */         stringBuilder.append("}");
/*     */       }
/*     */     } 
/* 264 */     if (paramBoolean2) {
/* 265 */       stringBuilder.append(")");
/*     */     }
/* 267 */     stringBuilder.append("(");
/* 268 */     getParameterList(stringBuilder, true, paramString2);
/* 269 */     stringBuilder.append(")");
/* 270 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(TypeVisitor paramTypeVisitor) {
/* 275 */     super.visit(paramTypeVisitor);
/* 276 */     this.returnType.visit(paramTypeVisitor);
/* 277 */     int i = getNumArguments();
/* 278 */     for (byte b = 0; b < i; b++)
/* 279 */       getArgumentType(b).visit(paramTypeVisitor); 
/*     */   }
/*     */   
/*     */   public static interface ParameterConsumer {
/*     */     boolean accept(int param1Int1, int param1Int2, Type param1Type, String param1String);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/FunctionType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */