/*    */ package com.jogamp.gluegen.cgram.types;
/*    */ 
/*    */ import com.jogamp.gluegen.ASTLocusTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidType
/*    */   extends Type
/*    */   implements Cloneable
/*    */ {
/*    */   public VoidType(int paramInt, ASTLocusTag paramASTLocusTag) {
/* 47 */     this("void", paramInt, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   private VoidType(String paramString, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 51 */     super(paramString, null, paramInt, paramASTLocusTag);
/*    */   }
/*    */   
/*    */   private VoidType(VoidType paramVoidType, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 55 */     super(paramVoidType, paramInt, paramASTLocusTag);
/*    */   }
/*    */ 
/*    */   
/*    */   Type newVariantImpl(boolean paramBoolean, int paramInt, ASTLocusTag paramASTLocusTag) {
/* 60 */     return new VoidType(this, paramInt, paramASTLocusTag);
/*    */   }
/*    */ 
/*    */   
/*    */   public VoidType asVoid() {
/* 65 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int hashCodeImpl() {
/* 70 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean equalsImpl(Type paramType) {
/* 75 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int hashCodeSemanticsImpl() {
/* 80 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean equalSemanticsImpl(Type paramType) {
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/types/VoidType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */