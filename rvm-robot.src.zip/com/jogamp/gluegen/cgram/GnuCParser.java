/*      */ package com.jogamp.gluegen.cgram;
/*      */ 
/*      */ import antlr.ASTFactory;
/*      */ import antlr.ASTPair;
/*      */ import antlr.LLkParser;
/*      */ import antlr.MismatchedTokenException;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.ParserSharedInputState;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.SemanticException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenBuffer;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.ASTArray;
/*      */ import antlr.collections.impl.BitSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GnuCParser
/*      */   extends LLkParser
/*      */   implements GNUCTokenTypes
/*      */ {
/*      */   public static boolean CPPComments = true;
/*   37 */   public CSymbolTable symbolTable = new CSymbolTable();
/*      */ 
/*      */   
/*   40 */   protected int unnamedScopeCounter = 0;
/*      */   
/*      */   public boolean isTypedefName(String paramString) {
/*   43 */     boolean bool = false;
/*   44 */     TNode tNode = this.symbolTable.lookupNameInCurrentScope(paramString);
/*   45 */     for (; tNode != null; tNode = (TNode)tNode.getNextSibling()) {
/*   46 */       if (tNode.getType() == 4) {
/*   47 */         bool = true;
/*      */         break;
/*      */       } 
/*      */     } 
/*   51 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAScopeName() {
/*   56 */     return "" + this.unnamedScopeCounter++;
/*      */   }
/*      */   
/*      */   public void pushScope(String paramString) {
/*   60 */     this.symbolTable.pushScope(paramString);
/*      */   }
/*      */   
/*      */   public void popScope() {
/*   64 */     this.symbolTable.popScope();
/*      */   }
/*      */   
/*      */   protected boolean debugging = false;
/*      */   
/*      */   public boolean getDebug() {
/*   70 */     return this.debugging;
/*      */   }
/*      */   
/*      */   public void setDebug(boolean paramBoolean) {
/*   74 */     this.debugging = paramBoolean;
/*      */   }
/*      */   
/*   77 */   int traceDepth = 0;
/*      */   public void reportError(RecognitionException paramRecognitionException) {
/*      */     try {
/*   80 */       System.err.println("ANTLR Parsing Error: " + paramRecognitionException + " token name:" + this.tokenNames[LA(1)]);
/*   81 */       paramRecognitionException.printStackTrace(System.err);
/*      */     }
/*   83 */     catch (TokenStreamException tokenStreamException) {
/*   84 */       System.err.println("ANTLR Parsing Error: " + paramRecognitionException);
/*   85 */       paramRecognitionException.printStackTrace(System.err);
/*      */     } 
/*      */   }
/*      */   public void reportError(String paramString) {
/*   89 */     System.err.println("ANTLR Parsing Error from String: " + paramString);
/*      */   }
/*      */   public void reportWarning(String paramString) {
/*   92 */     System.err.println("ANTLR Parsing Warning from String: " + paramString);
/*      */   }
/*      */   public void match(int paramInt) throws MismatchedTokenException {
/*   95 */     if (this.debugging) {
/*   96 */       for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*      */        try {
/*   98 */         System.out.println("Match(" + this.tokenNames[paramInt] + ") with LA(1)=" + this.tokenNames[
/*   99 */               LA(1)] + ((this.inputState.guessing > 0) ? (" [inputState.guessing " + this.inputState.guessing + "]") : ""));
/*      */       }
/*  101 */       catch (TokenStreamException tokenStreamException) {
/*  102 */         System.out.println("Match(" + this.tokenNames[paramInt] + ") " + ((this.inputState.guessing > 0) ? (" [inputState.guessing " + this.inputState.guessing + "]") : ""));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  108 */       if (LA(1) != paramInt) {
/*  109 */         if (this.debugging) {
/*  110 */           for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*  111 */            System.out.println("token mismatch: " + this.tokenNames[LA(1)] + "!=" + this.tokenNames[paramInt]);
/*      */         } 
/*      */         
/*  114 */         throw new MismatchedTokenException(this.tokenNames, LT(1), paramInt, false, getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  118 */       consume();
/*      */     
/*      */     }
/*  121 */     catch (TokenStreamException tokenStreamException) {}
/*      */   }
/*      */ 
/*      */   
/*      */   public void traceIn(String paramString) {
/*  126 */     this.traceDepth++;
/*  127 */     for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*      */      try {
/*  129 */       System.out.println("> " + paramString + "; LA(1)==(" + this.tokenNames[LT(1).getType()] + ") " + 
/*  130 */           LT(1).getText() + " [inputState.guessing " + this.inputState.guessing + "]");
/*      */     }
/*  132 */     catch (TokenStreamException tokenStreamException) {}
/*      */   }
/*      */   
/*      */   public void traceOut(String paramString) {
/*  136 */     for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*      */      try {
/*  138 */       System.out.println("< " + paramString + "; LA(1)==(" + this.tokenNames[LT(1).getType()] + ") " + 
/*  139 */           LT(1).getText() + " [inputState.guessing " + this.inputState.guessing + "]");
/*      */     }
/*  141 */     catch (TokenStreamException tokenStreamException) {}
/*      */     
/*  143 */     this.traceDepth--;
/*      */   }
/*      */ 
/*      */   
/*      */   protected GnuCParser(TokenBuffer paramTokenBuffer, int paramInt) {
/*  148 */     super(paramTokenBuffer, paramInt);
/*  149 */     this.tokenNames = _tokenNames;
/*  150 */     buildTokenTypeASTClassMap();
/*  151 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public GnuCParser(TokenBuffer paramTokenBuffer) {
/*  155 */     this(paramTokenBuffer, 2);
/*      */   }
/*      */   
/*      */   protected GnuCParser(TokenStream paramTokenStream, int paramInt) {
/*  159 */     super(paramTokenStream, paramInt);
/*  160 */     this.tokenNames = _tokenNames;
/*  161 */     buildTokenTypeASTClassMap();
/*  162 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public GnuCParser(TokenStream paramTokenStream) {
/*  166 */     this(paramTokenStream, 2);
/*      */   }
/*      */   
/*      */   public GnuCParser(ParserSharedInputState paramParserSharedInputState) {
/*  170 */     super(paramParserSharedInputState, 2);
/*  171 */     this.tokenNames = _tokenNames;
/*  172 */     buildTokenTypeASTClassMap();
/*  173 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */ 
/*      */   
/*      */   public final void translationUnit() throws RecognitionException, TokenStreamException {
/*  178 */     this.returnAST = null;
/*  179 */     ASTPair aSTPair = new ASTPair();
/*  180 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/*  184 */       switch (LA(1)) {
/*      */         
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 9:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 13:
/*      */         case 14:
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/*      */         case 18:
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*      */         case 160:
/*      */         case 161:
/*      */         case 162:
/*  228 */           externalList();
/*  229 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  238 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  242 */       tNode = (TNode)aSTPair.root;
/*      */     }
/*  244 */     catch (RecognitionException recognitionException) {
/*  245 */       if (this.inputState.guessing == 0) {
/*  246 */         reportError(recognitionException);
/*  247 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/*  249 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  252 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void externalList() throws RecognitionException, TokenStreamException {
/*  257 */     this.returnAST = null;
/*  258 */     ASTPair aSTPair = new ASTPair();
/*  259 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/*  263 */       byte b = 0;
/*      */       
/*      */       while (true) {
/*  266 */         if (_tokenSet_1.member(LA(1))) {
/*  267 */           externalDef();
/*  268 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/*  271 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/*  274 */         b++;
/*      */       } 
/*      */       
/*  277 */       tNode = (TNode)aSTPair.root;
/*      */     }
/*  279 */     catch (RecognitionException recognitionException) {
/*  280 */       if (this.inputState.guessing == 0) {
/*  281 */         reportError(recognitionException);
/*  282 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/*  284 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  287 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void asm_expr() throws RecognitionException, TokenStreamException {
/*  292 */     this.returnAST = null;
/*  293 */     ASTPair aSTPair = new ASTPair();
/*  294 */     TNode tNode = null;
/*      */     
/*      */     try {
/*  297 */       TNode tNode1 = null;
/*  298 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/*  299 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/*  300 */       match(5);
/*      */       
/*  302 */       switch (LA(1)) {
/*      */         
/*      */         case 6:
/*  305 */           tNode2 = null;
/*  306 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/*  307 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/*  308 */           match(6);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  317 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  321 */       TNode tNode2 = null;
/*  322 */       tNode2 = (TNode)this.astFactory.create(LT(1));
/*  323 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/*  324 */       match(7);
/*  325 */       expr();
/*  326 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  327 */       TNode tNode3 = null;
/*  328 */       tNode3 = (TNode)this.astFactory.create(LT(1));
/*  329 */       this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/*  330 */       match(8);
/*      */       
/*  332 */       byte b = 0;
/*      */       
/*      */       while (true) {
/*  335 */         if (LA(1) == 9 && _tokenSet_2.member(LA(2))) {
/*  336 */           TNode tNode4 = null;
/*  337 */           tNode4 = (TNode)this.astFactory.create(LT(1));
/*  338 */           this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/*  339 */           match(9);
/*      */         } else {
/*      */           
/*  342 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/*  345 */         b++;
/*      */       } 
/*      */       
/*  348 */       tNode = (TNode)aSTPair.root;
/*      */     }
/*  350 */     catch (RecognitionException recognitionException) {
/*  351 */       if (this.inputState.guessing == 0) {
/*  352 */         reportError(recognitionException);
/*  353 */         recover(recognitionException, _tokenSet_2);
/*      */       } else {
/*  355 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  358 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void expr() throws RecognitionException, TokenStreamException {
/*  363 */     this.returnAST = null;
/*  364 */     ASTPair aSTPair = new ASTPair();
/*  365 */     TNode tNode1 = null;
/*  366 */     Token token = null;
/*  367 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/*  370 */       assignExpr();
/*  371 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/*  375 */       while (LA(1) == 43 && _tokenSet_3.member(LA(2))) {
/*  376 */         token = LT(1);
/*  377 */         tNode2 = (TNode)this.astFactory.create(token);
/*  378 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode2);
/*  379 */         match(43);
/*  380 */         if (this.inputState.guessing == 0) {
/*  381 */           tNode2.setType(130);
/*      */         }
/*  383 */         assignExpr();
/*  384 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  392 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  394 */     catch (RecognitionException recognitionException) {
/*  395 */       if (this.inputState.guessing == 0) {
/*  396 */         reportError(recognitionException);
/*  397 */         recover(recognitionException, _tokenSet_4);
/*      */       } else {
/*  399 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  402 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void idList() throws RecognitionException, TokenStreamException {
/*  407 */     this.returnAST = null;
/*  408 */     ASTPair aSTPair = new ASTPair();
/*  409 */     TNode tNode = null;
/*      */     
/*      */     try {
/*  412 */       TNode tNode1 = null;
/*  413 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/*  414 */       this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  415 */       match(42);
/*      */ 
/*      */ 
/*      */       
/*  419 */       while (LA(1) == 43 && LA(2) == 42) {
/*  420 */         TNode tNode2 = null;
/*  421 */         tNode2 = (TNode)this.astFactory.create(LT(1));
/*  422 */         this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/*  423 */         match(43);
/*  424 */         TNode tNode3 = null;
/*  425 */         tNode3 = (TNode)this.astFactory.create(LT(1));
/*  426 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/*  427 */         match(42);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  435 */       tNode = (TNode)aSTPair.root;
/*      */     }
/*  437 */     catch (RecognitionException recognitionException) {
/*  438 */       if (this.inputState.guessing == 0) {
/*  439 */         reportError(recognitionException);
/*  440 */         recover(recognitionException, _tokenSet_5);
/*      */       } else {
/*  442 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  445 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void externalDef() throws RecognitionException, TokenStreamException {
/*  450 */     this.returnAST = null;
/*  451 */     ASTPair aSTPair = new ASTPair();
/*  452 */     TNode tNode = null; try {
/*      */       TNode tNode1; boolean bool1;
/*      */       boolean bool2;
/*  455 */       switch (LA(1)) {
/*      */         
/*      */         case 5:
/*  458 */           asm_expr();
/*  459 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  460 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*  465 */           tNode1 = null;
/*  466 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  467 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  468 */           match(9);
/*  469 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */         
/*      */         default:
/*  473 */           bool1 = false;
/*  474 */           if (_tokenSet_6.member(LA(1)) && _tokenSet_7.member(LA(2))) {
/*  475 */             int i = mark();
/*  476 */             bool1 = true;
/*  477 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/*  480 */               if (LA(1) == 4) {
/*  481 */                 match(4);
/*      */               }
/*  483 */               else if (_tokenSet_6.member(LA(1)) && _tokenSet_7.member(LA(2))) {
/*  484 */                 declaration();
/*      */               } else {
/*      */                 
/*  487 */                 throw new NoViableAltException(LT(1), getFilename());
/*      */               
/*      */               }
/*      */             
/*      */             }
/*  492 */             catch (RecognitionException recognitionException) {
/*  493 */               bool1 = false;
/*      */             } 
/*  495 */             rewind(i);
/*  496 */             this.inputState.guessing--;
/*      */           } 
/*  498 */           if (bool1) {
/*  499 */             declaration();
/*  500 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  501 */             tNode = (TNode)aSTPair.root;
/*      */             break;
/*      */           } 
/*  504 */           bool2 = false;
/*  505 */           if (_tokenSet_8.member(LA(1)) && _tokenSet_9.member(LA(2))) {
/*  506 */             int i = mark();
/*  507 */             bool2 = true;
/*  508 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/*  511 */               functionPrefix();
/*      */             
/*      */             }
/*  514 */             catch (RecognitionException recognitionException) {
/*  515 */               bool2 = false;
/*      */             } 
/*  517 */             rewind(i);
/*  518 */             this.inputState.guessing--;
/*      */           } 
/*  520 */           if (bool2) {
/*  521 */             functionDef();
/*  522 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  523 */             tNode = (TNode)aSTPair.root; break;
/*      */           } 
/*  525 */           if (_tokenSet_10.member(LA(1)) && _tokenSet_11.member(LA(2))) {
/*  526 */             typelessDeclaration();
/*  527 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  528 */             tNode = (TNode)aSTPair.root;
/*      */             break;
/*      */           } 
/*  531 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/*  535 */     } catch (RecognitionException recognitionException) {
/*  536 */       if (this.inputState.guessing == 0) {
/*  537 */         reportError(recognitionException);
/*  538 */         recover(recognitionException, _tokenSet_2);
/*      */       } else {
/*  540 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  543 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void declaration() throws RecognitionException, TokenStreamException {
/*  548 */     this.returnAST = null;
/*  549 */     ASTPair aSTPair = new ASTPair();
/*  550 */     TNode tNode1 = null;
/*  551 */     TNode tNode2 = null;
/*  552 */     AST aST = null;
/*      */     
/*      */     try {
/*  555 */       declSpecifiers();
/*  556 */       tNode2 = (TNode)this.returnAST;
/*  557 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  558 */       if (this.inputState.guessing == 0) {
/*  559 */         aST = this.astFactory.dupList((AST)tNode2);
/*      */       }
/*      */       
/*  562 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*  567 */           initDeclList(aST);
/*  568 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  577 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  582 */       byte b = 0;
/*      */       
/*      */       while (true) {
/*  585 */         if (LA(1) == 9 && _tokenSet_12.member(LA(2))) {
/*  586 */           TNode tNode = null;
/*  587 */           tNode = (TNode)this.astFactory.create(LT(1));
/*  588 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/*  589 */           match(9);
/*      */         } else {
/*      */           
/*  592 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/*  595 */         b++;
/*      */       } 
/*      */       
/*  598 */       if (this.inputState.guessing == 0) {
/*  599 */         tNode1 = (TNode)aSTPair.root;
/*  600 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(117)).add((AST)tNode1));
/*  601 */         aSTPair.root = (AST)tNode1;
/*  602 */         aSTPair
/*  603 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/*  604 */         aSTPair.advanceChildToEnd();
/*      */       } 
/*  606 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  608 */     catch (RecognitionException recognitionException) {
/*  609 */       if (this.inputState.guessing == 0) {
/*  610 */         reportError(recognitionException);
/*  611 */         recover(recognitionException, _tokenSet_12);
/*      */       } else {
/*  613 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  616 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionPrefix() throws RecognitionException, TokenStreamException {
/*  621 */     this.returnAST = null;
/*  622 */     ASTPair aSTPair = new ASTPair();
/*  623 */     TNode tNode1 = null;
/*  624 */     TNode tNode2 = null;
/*  625 */     TNode tNode3 = null;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  630 */       boolean bool = false;
/*  631 */       if (_tokenSet_13.member(LA(1)) && _tokenSet_14.member(LA(2))) {
/*  632 */         int i = mark();
/*  633 */         bool = true;
/*  634 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/*  637 */           functionDeclSpecifiers();
/*      */         
/*      */         }
/*  640 */         catch (RecognitionException recognitionException) {
/*  641 */           bool = false;
/*      */         } 
/*  643 */         rewind(i);
/*  644 */         this.inputState.guessing--;
/*      */       } 
/*  646 */       if (bool) {
/*  647 */         functionDeclSpecifiers();
/*  648 */         tNode2 = (TNode)this.returnAST;
/*  649 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       }
/*  651 */       else if (!_tokenSet_10.member(LA(1)) || !_tokenSet_9.member(LA(2))) {
/*      */ 
/*      */         
/*  654 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  658 */       String str = declarator(true);
/*  659 */       tNode3 = (TNode)this.returnAST;
/*  660 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/*  664 */       while (_tokenSet_6.member(LA(1))) {
/*  665 */         declaration();
/*  666 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  675 */       switch (LA(1)) {
/*      */         
/*      */         case 51:
/*  678 */           tNode = null;
/*  679 */           tNode = (TNode)this.astFactory.create(LT(1));
/*  680 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/*  681 */           match(51);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  691 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  698 */       while (LA(1) == 9) {
/*  699 */         tNode = null;
/*  700 */         tNode = (TNode)this.astFactory.create(LT(1));
/*  701 */         this.astFactory.addASTChild(aSTPair, (AST)tNode);
/*  702 */         match(9);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  710 */       TNode tNode = null;
/*  711 */       tNode = (TNode)this.astFactory.create(LT(1));
/*  712 */       this.astFactory.addASTChild(aSTPair, (AST)tNode);
/*  713 */       match(7);
/*  714 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  716 */     catch (RecognitionException recognitionException) {
/*  717 */       if (this.inputState.guessing == 0) {
/*  718 */         reportError(recognitionException);
/*  719 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/*  721 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  724 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionDef() throws RecognitionException, TokenStreamException {
/*  729 */     this.returnAST = null;
/*  730 */     ASTPair aSTPair = new ASTPair();
/*  731 */     TNode tNode1 = null;
/*  732 */     TNode tNode2 = null;
/*  733 */     TNode tNode3 = null;
/*      */     
/*      */     try {
/*      */       TNode tNode;
/*      */       
/*  738 */       boolean bool = false;
/*  739 */       if (_tokenSet_13.member(LA(1)) && _tokenSet_14.member(LA(2))) {
/*  740 */         int i = mark();
/*  741 */         bool = true;
/*  742 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/*  745 */           functionDeclSpecifiers();
/*      */         
/*      */         }
/*  748 */         catch (RecognitionException recognitionException) {
/*  749 */           bool = false;
/*      */         } 
/*  751 */         rewind(i);
/*  752 */         this.inputState.guessing--;
/*      */       } 
/*  754 */       if (bool) {
/*  755 */         functionDeclSpecifiers();
/*  756 */         tNode2 = (TNode)this.returnAST;
/*  757 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       }
/*  759 */       else if (!_tokenSet_10.member(LA(1)) || !_tokenSet_9.member(LA(2))) {
/*      */ 
/*      */         
/*  762 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  766 */       String str = declarator(true);
/*  767 */       tNode3 = (TNode)this.returnAST;
/*  768 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  769 */       if (this.inputState.guessing == 0) {
/*      */ 
/*      */         
/*  772 */         AST aST1 = this.astFactory.dupList((AST)tNode3);
/*  773 */         AST aST2 = this.astFactory.dupList((AST)tNode2);
/*  774 */         this.symbolTable.add(str, (TNode)this.astFactory.make((new ASTArray(3)).add(null).add(aST2).add(aST1)));
/*  775 */         pushScope(str);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  781 */       while (_tokenSet_6.member(LA(1))) {
/*  782 */         declaration();
/*  783 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  792 */       switch (LA(1)) {
/*      */         
/*      */         case 51:
/*  795 */           tNode = null;
/*  796 */           tNode = (TNode)this.astFactory.create(LT(1));
/*  797 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/*  798 */           match(51);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  808 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  815 */       while (LA(1) == 9) {
/*  816 */         match(9);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  824 */       if (this.inputState.guessing == 0) {
/*  825 */         popScope();
/*      */       }
/*  827 */       compoundStatement(str);
/*  828 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  829 */       if (this.inputState.guessing == 0) {
/*  830 */         tNode1 = (TNode)aSTPair.root;
/*  831 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(127)).add((AST)tNode1));
/*  832 */         aSTPair.root = (AST)tNode1;
/*  833 */         aSTPair
/*  834 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/*  835 */         aSTPair.advanceChildToEnd();
/*      */       } 
/*  837 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  839 */     catch (RecognitionException recognitionException) {
/*  840 */       if (this.inputState.guessing == 0) {
/*  841 */         reportError(recognitionException);
/*  842 */         recover(recognitionException, _tokenSet_2);
/*      */       } else {
/*  844 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  847 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typelessDeclaration() throws RecognitionException, TokenStreamException {
/*  852 */     this.returnAST = null;
/*  853 */     ASTPair aSTPair = new ASTPair();
/*  854 */     TNode tNode1 = null;
/*  855 */     TNode tNode2 = (TNode)this.astFactory.create(140);
/*      */     
/*      */     try {
/*  858 */       initDeclList((AST)tNode2);
/*  859 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  860 */       TNode tNode = null;
/*  861 */       tNode = (TNode)this.astFactory.create(LT(1));
/*  862 */       this.astFactory.addASTChild(aSTPair, (AST)tNode);
/*  863 */       match(9);
/*  864 */       if (this.inputState.guessing == 0) {
/*  865 */         tNode1 = (TNode)aSTPair.root;
/*  866 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(140)).add((AST)tNode1));
/*  867 */         aSTPair.root = (AST)tNode1;
/*  868 */         aSTPair
/*  869 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/*  870 */         aSTPair.advanceChildToEnd();
/*      */       } 
/*  872 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  874 */     catch (RecognitionException recognitionException) {
/*  875 */       if (this.inputState.guessing == 0) {
/*  876 */         reportError(recognitionException);
/*  877 */         recover(recognitionException, _tokenSet_2);
/*      */       } else {
/*  879 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  882 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionDeclSpecifiers() throws RecognitionException, TokenStreamException {
/*  887 */     this.returnAST = null;
/*  888 */     ASTPair aSTPair = new ASTPair();
/*  889 */     TNode tNode = null;
/*  890 */     int i = 0;
/*      */ 
/*      */     
/*      */     try {
/*  894 */       byte b = 0;
/*      */       while (true) {
/*      */         boolean bool;
/*  897 */         switch (LA(1)) {
/*      */           
/*      */           case 15:
/*      */           case 16:
/*      */           case 160:
/*  902 */             functionStorageClassSpecifier();
/*  903 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/*  909 */             typeQualifier();
/*  910 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */           
/*      */           default:
/*  914 */             bool = false;
/*  915 */             if (_tokenSet_15.member(LA(1)) && _tokenSet_14.member(LA(2))) {
/*  916 */               int j = mark();
/*  917 */               bool = true;
/*  918 */               this.inputState.guessing++;
/*      */               
/*      */               try {
/*  921 */                 if (LA(1) == 10) {
/*  922 */                   match(10);
/*      */                 }
/*  924 */                 else if (LA(1) == 11) {
/*  925 */                   match(11);
/*      */                 }
/*  927 */                 else if (LA(1) == 12) {
/*  928 */                   match(12);
/*      */                 }
/*  930 */                 else if (_tokenSet_15.member(LA(1))) {
/*  931 */                   typeSpecifier(i);
/*      */                 } else {
/*      */                   
/*  934 */                   throw new NoViableAltException(LT(1), getFilename());
/*      */                 
/*      */                 }
/*      */               
/*      */               }
/*  939 */               catch (RecognitionException recognitionException) {
/*  940 */                 bool = false;
/*      */               } 
/*  942 */               rewind(j);
/*  943 */               this.inputState.guessing--;
/*      */             } 
/*  945 */             if (bool) {
/*  946 */               i = typeSpecifier(i);
/*  947 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */             } 
/*  950 */             if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/*  953 */         b++;
/*      */       } 
/*      */       
/*  956 */       tNode = (TNode)aSTPair.root;
/*      */     }
/*  958 */     catch (RecognitionException recognitionException) {
/*  959 */       if (this.inputState.guessing == 0) {
/*  960 */         reportError(recognitionException);
/*  961 */         recover(recognitionException, _tokenSet_10);
/*      */       } else {
/*  963 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  966 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String declarator(boolean paramBoolean) throws RecognitionException, TokenStreamException {
/*  974 */     this.returnAST = null;
/*  975 */     ASTPair aSTPair = new ASTPair();
/*  976 */     TNode tNode1 = null;
/*  977 */     Token token = null;
/*  978 */     TNode tNode2 = null;
/*  979 */     String str = "";
/*      */     
/*      */     try {
/*      */       TNode tNode3, tNode4;
/*  983 */       switch (LA(1)) {
/*      */         
/*      */         case 46:
/*  986 */           pointerGroup();
/*  987 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  997 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1002 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/* 1005 */           token = LT(1);
/* 1006 */           tNode2 = (TNode)this.astFactory.create(token);
/* 1007 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1008 */           match(42);
/* 1009 */           if (this.inputState.guessing == 0) {
/* 1010 */             str = token.getText();
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/* 1016 */           tNode3 = null;
/* 1017 */           tNode3 = (TNode)this.astFactory.create(LT(1));
/* 1018 */           this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 1019 */           match(47);
/* 1020 */           str = declarator(false);
/* 1021 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1022 */           tNode4 = null;
/* 1023 */           tNode4 = (TNode)this.astFactory.create(LT(1));
/* 1024 */           this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 1025 */           match(48);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1030 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/* 1037 */         switch (LA(1)) {
/*      */           
/*      */           case 47:
/* 1040 */             declaratorParamaterList(paramBoolean, str);
/* 1041 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 49:
/* 1046 */             tNode3 = null;
/* 1047 */             tNode3 = (TNode)this.astFactory.create(LT(1));
/* 1048 */             this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 1049 */             match(49);
/*      */             
/* 1051 */             switch (LA(1)) {
/*      */               
/*      */               case 5:
/*      */               case 42:
/*      */               case 46:
/*      */               case 47:
/*      */               case 76:
/*      */               case 79:
/*      */               case 88:
/*      */               case 89:
/*      */               case 92:
/*      */               case 93:
/*      */               case 94:
/*      */               case 95:
/*      */               case 96:
/*      */               case 99:
/*      */               case 100:
/*      */               case 158:
/*      */               case 164:
/*      */               case 165:
/*      */               case 166:
/* 1072 */                 expr();
/* 1073 */                 this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 50:
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1082 */                 throw new NoViableAltException(LT(1), getFilename());
/*      */             } 
/*      */ 
/*      */             
/* 1086 */             tNode4 = null;
/* 1087 */             tNode4 = (TNode)this.astFactory.create(LT(1));
/* 1088 */             this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 1089 */             match(50);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1099 */       if (this.inputState.guessing == 0) {
/* 1100 */         tNode1 = (TNode)aSTPair.root;
/* 1101 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(115)).add((AST)tNode1));
/* 1102 */         aSTPair.root = (AST)tNode1;
/* 1103 */         aSTPair
/* 1104 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 1105 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 1107 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 1109 */     catch (RecognitionException recognitionException) {
/* 1110 */       if (this.inputState.guessing == 0) {
/* 1111 */         reportError(recognitionException);
/* 1112 */         recover(recognitionException, _tokenSet_16);
/*      */       } else {
/* 1114 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1117 */     this.returnAST = (AST)tNode1;
/* 1118 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void initDeclList(AST paramAST) throws RecognitionException, TokenStreamException {
/* 1125 */     this.returnAST = null;
/* 1126 */     ASTPair aSTPair = new ASTPair();
/* 1127 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1130 */       initDecl(paramAST);
/* 1131 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 1135 */       while (LA(1) == 43 && _tokenSet_10.member(LA(2))) {
/* 1136 */         match(43);
/* 1137 */         initDecl(paramAST);
/* 1138 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1147 */       switch (LA(1)) {
/*      */         
/*      */         case 43:
/* 1150 */           match(43);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1159 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1163 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1165 */     catch (RecognitionException recognitionException) {
/* 1166 */       if (this.inputState.guessing == 0) {
/* 1167 */         reportError(recognitionException);
/* 1168 */         recover(recognitionException, _tokenSet_17);
/*      */       } else {
/* 1170 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1173 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void initializer() throws RecognitionException, TokenStreamException {
/* 1178 */     this.returnAST = null;
/* 1179 */     ASTPair aSTPair = new ASTPair();
/* 1180 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 1184 */       if (_tokenSet_18.member(LA(1)) && _tokenSet_19.member(LA(2))) {
/*      */ 
/*      */         
/* 1187 */         boolean bool = false;
/* 1188 */         if (_tokenSet_20.member(LA(1)) && _tokenSet_21.member(LA(2))) {
/* 1189 */           int i = mark();
/* 1190 */           bool = true;
/* 1191 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 1194 */             initializerElementLabel();
/*      */           
/*      */           }
/* 1197 */           catch (RecognitionException recognitionException) {
/* 1198 */             bool = false;
/*      */           } 
/* 1200 */           rewind(i);
/* 1201 */           this.inputState.guessing--;
/*      */         } 
/* 1203 */         if (bool) {
/* 1204 */           initializerElementLabel();
/* 1205 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         }
/* 1207 */         else if (!_tokenSet_22.member(LA(1)) || !_tokenSet_23.member(LA(2))) {
/*      */ 
/*      */           
/* 1210 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1215 */         switch (LA(1)) {
/*      */           
/*      */           case 5:
/*      */           case 42:
/*      */           case 46:
/*      */           case 47:
/*      */           case 76:
/*      */           case 79:
/*      */           case 88:
/*      */           case 89:
/*      */           case 92:
/*      */           case 93:
/*      */           case 94:
/*      */           case 95:
/*      */           case 96:
/*      */           case 99:
/*      */           case 100:
/*      */           case 158:
/*      */           case 164:
/*      */           case 165:
/*      */           case 166:
/* 1236 */             assignExpr();
/* 1237 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 7:
/* 1242 */             lcurlyInitializer();
/* 1243 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1248 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 1252 */         if (this.inputState.guessing == 0) {
/* 1253 */           tNode = (TNode)aSTPair.root;
/* 1254 */           tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(123)).add((AST)tNode));
/* 1255 */           aSTPair.root = (AST)tNode;
/* 1256 */           aSTPair
/* 1257 */             .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 1258 */           aSTPair.advanceChildToEnd();
/*      */         }
/*      */       
/*      */       }
/* 1262 */       else if (LA(1) == 7 && _tokenSet_24.member(LA(2))) {
/* 1263 */         lcurlyInitializer();
/* 1264 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } else {
/*      */         
/* 1267 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1271 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1273 */     catch (RecognitionException recognitionException) {
/* 1274 */       if (this.inputState.guessing == 0) {
/* 1275 */         reportError(recognitionException);
/* 1276 */         recover(recognitionException, _tokenSet_25);
/*      */       } else {
/* 1278 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1281 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void initializerElementLabel() throws RecognitionException, TokenStreamException {
/* 1286 */     this.returnAST = null;
/* 1287 */     ASTPair aSTPair = new ASTPair();
/* 1288 */     TNode tNode = null; try {
/*      */       TNode tNode1;
/*      */       boolean bool;
/*      */       TNode tNode2, tNode3;
/* 1292 */       switch (LA(1)) {
/*      */ 
/*      */         
/*      */         case 49:
/* 1296 */           tNode1 = null;
/* 1297 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1298 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1299 */           match(49);
/*      */           
/* 1301 */           bool = false;
/* 1302 */           if (_tokenSet_3.member(LA(1)) && _tokenSet_26.member(LA(2))) {
/* 1303 */             int i = mark();
/* 1304 */             bool = true;
/* 1305 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 1308 */               constExpr();
/* 1309 */               match(51);
/*      */             
/*      */             }
/* 1312 */             catch (RecognitionException recognitionException) {
/* 1313 */               bool = false;
/*      */             } 
/* 1315 */             rewind(i);
/* 1316 */             this.inputState.guessing--;
/*      */           } 
/* 1318 */           if (bool) {
/* 1319 */             rangeExpr();
/* 1320 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           }
/* 1322 */           else if (_tokenSet_3.member(LA(1)) && _tokenSet_27.member(LA(2))) {
/* 1323 */             constExpr();
/* 1324 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } else {
/*      */             
/* 1327 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 1331 */           tNode2 = null;
/* 1332 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 1333 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1334 */           match(50);
/*      */           
/* 1336 */           switch (LA(1)) {
/*      */             
/*      */             case 45:
/* 1339 */               tNode3 = null;
/* 1340 */               tNode3 = (TNode)this.astFactory.create(LT(1));
/* 1341 */               this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 1342 */               match(45);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 5:
/*      */             case 7:
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 76:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 158:
/*      */             case 164:
/*      */             case 165:
/*      */             case 166:
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/* 1370 */           throw new NoViableAltException(LT(1), getFilename());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 42:
/* 1379 */           tNode1 = null;
/* 1380 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1381 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1382 */           match(42);
/* 1383 */           tNode2 = null;
/* 1384 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 1385 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1386 */           match(44);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 98:
/* 1391 */           tNode1 = null;
/* 1392 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1393 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1394 */           match(98);
/* 1395 */           tNode2 = null;
/* 1396 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 1397 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1398 */           match(42);
/* 1399 */           tNode3 = null;
/* 1400 */           tNode3 = (TNode)this.astFactory.create(LT(1));
/* 1401 */           this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 1402 */           match(45);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1407 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1411 */       if (this.inputState.guessing == 0) {
/* 1412 */         tNode = (TNode)aSTPair.root;
/* 1413 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(136)).add((AST)tNode));
/* 1414 */         aSTPair.root = (AST)tNode;
/* 1415 */         aSTPair
/* 1416 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 1417 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 1419 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1421 */     catch (RecognitionException recognitionException) {
/* 1422 */       if (this.inputState.guessing == 0) {
/* 1423 */         reportError(recognitionException);
/* 1424 */         recover(recognitionException, _tokenSet_22);
/*      */       } else {
/* 1426 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1429 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void assignExpr() throws RecognitionException, TokenStreamException {
/* 1434 */     this.returnAST = null;
/* 1435 */     ASTPair aSTPair = new ASTPair();
/* 1436 */     TNode tNode1 = null;
/* 1437 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 1440 */       conditionalExpr();
/* 1441 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 1443 */       switch (LA(1)) {
/*      */         
/*      */         case 45:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/* 1456 */           assignOperator();
/* 1457 */           tNode2 = (TNode)this.returnAST;
/* 1458 */           assignExpr();
/* 1459 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1460 */           if (this.inputState.guessing == 0) {
/* 1461 */             tNode1 = (TNode)aSTPair.root;
/* 1462 */             tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add((AST)tNode2).add((AST)tNode1));
/* 1463 */             aSTPair.root = (AST)tNode1;
/* 1464 */             aSTPair
/* 1465 */               .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 1466 */             aSTPair.advanceChildToEnd();
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 9:
/*      */         case 43:
/*      */         case 44:
/*      */         case 48:
/*      */         case 50:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1481 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1485 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 1487 */     catch (RecognitionException recognitionException) {
/* 1488 */       if (this.inputState.guessing == 0) {
/* 1489 */         reportError(recognitionException);
/* 1490 */         recover(recognitionException, _tokenSet_4);
/*      */       } else {
/* 1492 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1495 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void lcurlyInitializer() throws RecognitionException, TokenStreamException {
/* 1500 */     this.returnAST = null;
/* 1501 */     ASTPair aSTPair = new ASTPair();
/* 1502 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1505 */       TNode tNode1 = null;
/* 1506 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1507 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 1508 */       match(7);
/*      */       
/* 1510 */       switch (LA(1)) {
/*      */         
/*      */         case 5:
/*      */         case 7:
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*      */         case 49:
/*      */         case 76:
/*      */         case 79:
/*      */         case 88:
/*      */         case 89:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 98:
/*      */         case 99:
/*      */         case 100:
/*      */         case 158:
/*      */         case 164:
/*      */         case 165:
/*      */         case 166:
/* 1534 */           initializerList();
/* 1535 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           
/* 1537 */           switch (LA(1)) {
/*      */             
/*      */             case 43:
/* 1540 */               match(43);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 8:
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/* 1549 */           throw new NoViableAltException(LT(1), getFilename());
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 8:
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1561 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1565 */       TNode tNode2 = null;
/* 1566 */       tNode2 = (TNode)this.astFactory.create(LT(1));
/* 1567 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1568 */       match(8);
/* 1569 */       if (this.inputState.guessing == 0) {
/* 1570 */         tNode = (TNode)aSTPair.root;
/* 1571 */         tNode.setType(137);
/*      */       } 
/* 1573 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1575 */     catch (RecognitionException recognitionException) {
/* 1576 */       if (this.inputState.guessing == 0) {
/* 1577 */         reportError(recognitionException);
/* 1578 */         recover(recognitionException, _tokenSet_28);
/*      */       } else {
/* 1580 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1583 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void constExpr() throws RecognitionException, TokenStreamException {
/* 1588 */     this.returnAST = null;
/* 1589 */     ASTPair aSTPair = new ASTPair();
/* 1590 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1593 */       conditionalExpr();
/* 1594 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1595 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1597 */     catch (RecognitionException recognitionException) {
/* 1598 */       if (this.inputState.guessing == 0) {
/* 1599 */         reportError(recognitionException);
/* 1600 */         recover(recognitionException, _tokenSet_29);
/*      */       } else {
/* 1602 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1605 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void rangeExpr() throws RecognitionException, TokenStreamException {
/* 1610 */     this.returnAST = null;
/* 1611 */     ASTPair aSTPair = new ASTPair();
/* 1612 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1615 */       constExpr();
/* 1616 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1617 */       TNode tNode1 = null;
/* 1618 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1619 */       this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1620 */       match(51);
/* 1621 */       constExpr();
/* 1622 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1623 */       if (this.inputState.guessing == 0) {
/* 1624 */         tNode = (TNode)aSTPair.root;
/* 1625 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(134)).add((AST)tNode));
/* 1626 */         aSTPair.root = (AST)tNode;
/* 1627 */         aSTPair
/* 1628 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 1629 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 1631 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1633 */     catch (RecognitionException recognitionException) {
/* 1634 */       if (this.inputState.guessing == 0) {
/* 1635 */         reportError(recognitionException);
/* 1636 */         recover(recognitionException, _tokenSet_30);
/*      */       } else {
/* 1638 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1641 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void initializerList() throws RecognitionException, TokenStreamException {
/* 1646 */     this.returnAST = null;
/* 1647 */     ASTPair aSTPair = new ASTPair();
/* 1648 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1651 */       initializer();
/* 1652 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 1656 */       while (LA(1) == 43 && _tokenSet_18.member(LA(2))) {
/* 1657 */         match(43);
/* 1658 */         initializer();
/* 1659 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1667 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1669 */     catch (RecognitionException recognitionException) {
/* 1670 */       if (this.inputState.guessing == 0) {
/* 1671 */         reportError(recognitionException);
/* 1672 */         recover(recognitionException, _tokenSet_31);
/*      */       } else {
/* 1674 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1677 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void pointerGroup() throws RecognitionException, TokenStreamException {
/* 1682 */     this.returnAST = null;
/* 1683 */     ASTPair aSTPair = new ASTPair();
/* 1684 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 1688 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 1691 */         if (LA(1) == 46) {
/* 1692 */           TNode tNode1 = null;
/* 1693 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1694 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1695 */           match(46);
/*      */ 
/*      */ 
/*      */           
/* 1699 */           while (LA(1) == 6 || LA(1) == 17) {
/* 1700 */             typeQualifier();
/* 1701 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1711 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 1714 */         b++;
/*      */       } 
/*      */       
/* 1717 */       if (this.inputState.guessing == 0) {
/* 1718 */         tNode = (TNode)aSTPair.root;
/* 1719 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(119)).add((AST)tNode));
/* 1720 */         aSTPair.root = (AST)tNode;
/* 1721 */         aSTPair
/* 1722 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 1723 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 1725 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1727 */     catch (RecognitionException recognitionException) {
/* 1728 */       if (this.inputState.guessing == 0) {
/* 1729 */         reportError(recognitionException);
/* 1730 */         recover(recognitionException, _tokenSet_32);
/*      */       } else {
/* 1732 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1735 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void declaratorParamaterList(boolean paramBoolean, String paramString) throws RecognitionException, TokenStreamException {
/* 1742 */     this.returnAST = null;
/* 1743 */     ASTPair aSTPair = new ASTPair();
/* 1744 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1747 */       TNode tNode1 = null;
/* 1748 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1749 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 1750 */       match(47);
/* 1751 */       if (this.inputState.guessing == 0)
/*      */       {
/* 1753 */         if (paramBoolean) {
/* 1754 */           pushScope(paramString);
/*      */         } else {
/*      */           
/* 1757 */           pushScope("!" + paramString);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1762 */       boolean bool = false;
/* 1763 */       if (_tokenSet_6.member(LA(1)) && _tokenSet_33.member(LA(2))) {
/* 1764 */         int i = mark();
/* 1765 */         bool = true;
/* 1766 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 1769 */           declSpecifiers();
/*      */         
/*      */         }
/* 1772 */         catch (RecognitionException recognitionException) {
/* 1773 */           bool = false;
/*      */         } 
/* 1775 */         rewind(i);
/* 1776 */         this.inputState.guessing--;
/*      */       } 
/* 1778 */       if (bool) {
/* 1779 */         parameterTypeList();
/* 1780 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       }
/* 1782 */       else if (_tokenSet_34.member(LA(1)) && _tokenSet_35.member(LA(2))) {
/*      */         
/* 1784 */         switch (LA(1)) {
/*      */           
/*      */           case 42:
/* 1787 */             idList();
/* 1788 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 43:
/*      */           case 48:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1798 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } else {
/* 1804 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1808 */       if (this.inputState.guessing == 0)
/*      */       {
/* 1810 */         popScope();
/*      */       }
/*      */ 
/*      */       
/* 1814 */       switch (LA(1)) {
/*      */         
/*      */         case 43:
/* 1817 */           match(43);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1826 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1830 */       TNode tNode2 = null;
/* 1831 */       tNode2 = (TNode)this.astFactory.create(LT(1));
/* 1832 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1833 */       match(48);
/* 1834 */       if (this.inputState.guessing == 0) {
/* 1835 */         tNode = (TNode)aSTPair.root;
/* 1836 */         tNode.setType(126);
/*      */       } 
/* 1838 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1840 */     catch (RecognitionException recognitionException) {
/* 1841 */       if (this.inputState.guessing == 0) {
/* 1842 */         reportError(recognitionException);
/* 1843 */         recover(recognitionException, _tokenSet_35);
/*      */       } else {
/* 1845 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1848 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void declSpecifiers() throws RecognitionException, TokenStreamException {
/* 1853 */     this.returnAST = null;
/* 1854 */     ASTPair aSTPair = new ASTPair();
/* 1855 */     TNode tNode1 = null;
/* 1856 */     TNode tNode2 = null;
/* 1857 */     int i = 0;
/*      */ 
/*      */     
/*      */     try {
/* 1861 */       byte b = 0;
/*      */       while (true) {
/*      */         boolean bool;
/* 1864 */         switch (LA(1)) {
/*      */           
/*      */           case 4:
/*      */           case 13:
/*      */           case 14:
/*      */           case 15:
/*      */           case 16:
/*      */           case 160:
/* 1872 */             storageClassSpecifier();
/* 1873 */             tNode2 = (TNode)this.returnAST;
/* 1874 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/* 1880 */             typeQualifier();
/* 1881 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */           
/*      */           default:
/* 1885 */             bool = false;
/* 1886 */             if (_tokenSet_15.member(LA(1)) && _tokenSet_33.member(LA(2))) {
/* 1887 */               int j = mark();
/* 1888 */               bool = true;
/* 1889 */               this.inputState.guessing++;
/*      */               
/*      */               try {
/* 1892 */                 if (LA(1) == 10) {
/* 1893 */                   match(10);
/*      */                 }
/* 1895 */                 else if (LA(1) == 11) {
/* 1896 */                   match(11);
/*      */                 }
/* 1898 */                 else if (LA(1) == 12) {
/* 1899 */                   match(12);
/*      */                 }
/* 1901 */                 else if (_tokenSet_15.member(LA(1))) {
/* 1902 */                   typeSpecifier(i);
/*      */                 } else {
/*      */                   
/* 1905 */                   throw new NoViableAltException(LT(1), getFilename());
/*      */                 
/*      */                 }
/*      */               
/*      */               }
/* 1910 */               catch (RecognitionException recognitionException) {
/* 1911 */                 bool = false;
/*      */               } 
/* 1913 */               rewind(j);
/* 1914 */               this.inputState.guessing--;
/*      */             } 
/* 1916 */             if (bool) {
/* 1917 */               i = typeSpecifier(i);
/* 1918 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */             } 
/* 1921 */             if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 1924 */         b++;
/*      */       } 
/*      */       
/* 1927 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 1929 */     catch (RecognitionException recognitionException) {
/* 1930 */       if (this.inputState.guessing == 0) {
/* 1931 */         reportError(recognitionException);
/* 1932 */         recover(recognitionException, _tokenSet_36);
/*      */       } else {
/* 1934 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1937 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void parameterTypeList() throws RecognitionException, TokenStreamException {
/* 1942 */     this.returnAST = null;
/* 1943 */     ASTPair aSTPair = new ASTPair();
/* 1944 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1947 */       parameterDeclaration();
/* 1948 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 1952 */       while ((LA(1) == 9 || LA(1) == 43) && _tokenSet_6.member(LA(2))) {
/*      */         TNode tNode1;
/* 1954 */         switch (LA(1)) {
/*      */           
/*      */           case 43:
/* 1957 */             tNode1 = null;
/* 1958 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1959 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1960 */             match(43);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 9:
/* 1965 */             tNode1 = null;
/* 1966 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1967 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1968 */             match(9);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1973 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 1977 */         parameterDeclaration();
/* 1978 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1987 */       if ((LA(1) == 9 || LA(1) == 43) && LA(2) == 51) {
/*      */         
/* 1989 */         switch (LA(1)) {
/*      */           
/*      */           case 43:
/* 1992 */             tNode1 = null;
/* 1993 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1994 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1995 */             match(43);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 9:
/* 2000 */             tNode1 = null;
/* 2001 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2002 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2003 */             match(9);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2008 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 2012 */         TNode tNode1 = null;
/* 2013 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2014 */         this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2015 */         match(51);
/*      */       }
/* 2017 */       else if ((LA(1) != 43 && LA(1) != 48) || !_tokenSet_35.member(LA(2))) {
/*      */ 
/*      */         
/* 2020 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2024 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2026 */     catch (RecognitionException recognitionException) {
/* 2027 */       if (this.inputState.guessing == 0) {
/* 2028 */         reportError(recognitionException);
/* 2029 */         recover(recognitionException, _tokenSet_5);
/*      */       } else {
/* 2031 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2034 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void parameterDeclaration() throws RecognitionException, TokenStreamException {
/* 2039 */     this.returnAST = null;
/* 2040 */     ASTPair aSTPair = new ASTPair();
/* 2041 */     TNode tNode1 = null;
/* 2042 */     TNode tNode2 = null;
/* 2043 */     TNode tNode3 = null;
/*      */ 
/*      */     
/*      */     try {
/* 2047 */       declSpecifiers();
/* 2048 */       tNode2 = (TNode)this.returnAST;
/* 2049 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 2051 */       boolean bool = false;
/* 2052 */       if (_tokenSet_10.member(LA(1)) && _tokenSet_37.member(LA(2))) {
/* 2053 */         int i = mark();
/* 2054 */         bool = true;
/* 2055 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 2058 */           declarator(false);
/*      */         
/*      */         }
/* 2061 */         catch (RecognitionException recognitionException) {
/* 2062 */           bool = false;
/*      */         } 
/* 2064 */         rewind(i);
/* 2065 */         this.inputState.guessing--;
/*      */       } 
/* 2067 */       if (bool) {
/* 2068 */         String str = declarator(false);
/* 2069 */         tNode3 = (TNode)this.returnAST;
/* 2070 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2071 */         if (this.inputState.guessing == 0)
/*      */         {
/*      */           
/* 2074 */           AST aST1 = this.astFactory.dupList((AST)tNode3);
/* 2075 */           AST aST2 = this.astFactory.dupList((AST)tNode2);
/* 2076 */           this.symbolTable.add(str, (TNode)this.astFactory.make((new ASTArray(3)).add(null).add(aST2).add(aST1)));
/*      */         }
/*      */       
/*      */       }
/* 2080 */       else if (_tokenSet_38.member(LA(1)) && _tokenSet_39.member(LA(2))) {
/* 2081 */         nonemptyAbstractDeclarator();
/* 2082 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       }
/* 2084 */       else if (!_tokenSet_40.member(LA(1))) {
/*      */ 
/*      */         
/* 2087 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2091 */       if (this.inputState.guessing == 0) {
/* 2092 */         tNode1 = (TNode)aSTPair.root;
/*      */         
/* 2094 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(129)).add((AST)tNode1));
/*      */         
/* 2096 */         aSTPair.root = (AST)tNode1;
/* 2097 */         aSTPair
/* 2098 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 2099 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 2101 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 2103 */     catch (RecognitionException recognitionException) {
/* 2104 */       if (this.inputState.guessing == 0) {
/* 2105 */         reportError(recognitionException);
/* 2106 */         recover(recognitionException, _tokenSet_40);
/*      */       } else {
/* 2108 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2111 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void declarationList() throws RecognitionException, TokenStreamException {
/* 2116 */     this.returnAST = null;
/* 2117 */     ASTPair aSTPair = new ASTPair();
/* 2118 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 2122 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 2125 */         if (LA(1) == 159 && LA(2) == 42) {
/* 2126 */           localLabelDeclaration();
/* 2127 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/* 2130 */           boolean bool = false;
/* 2131 */           if (_tokenSet_6.member(LA(1)) && _tokenSet_7.member(LA(2))) {
/* 2132 */             int i = mark();
/* 2133 */             bool = true;
/* 2134 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 2137 */               declarationPredictor();
/*      */             
/*      */             }
/* 2140 */             catch (RecognitionException recognitionException) {
/* 2141 */               bool = false;
/*      */             } 
/* 2143 */             rewind(i);
/* 2144 */             this.inputState.guessing--;
/*      */           } 
/* 2146 */           if (bool) {
/* 2147 */             declaration();
/* 2148 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } else {
/*      */             
/* 2151 */             if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */         } 
/* 2154 */         b++;
/*      */       } 
/*      */       
/* 2157 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2159 */     catch (RecognitionException recognitionException) {
/* 2160 */       if (this.inputState.guessing == 0) {
/* 2161 */         reportError(recognitionException);
/* 2162 */         recover(recognitionException, _tokenSet_41);
/*      */       } else {
/* 2164 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2167 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void localLabelDeclaration() throws RecognitionException, TokenStreamException {
/* 2172 */     this.returnAST = null;
/* 2173 */     ASTPair aSTPair = new ASTPair();
/* 2174 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 2178 */       TNode tNode1 = null;
/* 2179 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2180 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 2181 */       match(159);
/* 2182 */       TNode tNode2 = null;
/* 2183 */       tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2184 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2185 */       match(42);
/*      */ 
/*      */ 
/*      */       
/* 2189 */       while (LA(1) == 43 && LA(2) == 42) {
/* 2190 */         match(43);
/* 2191 */         TNode tNode3 = null;
/* 2192 */         tNode3 = (TNode)this.astFactory.create(LT(1));
/* 2193 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 2194 */         match(42);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2203 */       switch (LA(1)) {
/*      */         
/*      */         case 43:
/* 2206 */           match(43);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2215 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2220 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 2223 */         if (LA(1) == 9 && _tokenSet_41.member(LA(2))) {
/* 2224 */           match(9);
/*      */         } else {
/*      */           
/* 2227 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 2230 */         b++;
/*      */       } 
/*      */ 
/*      */       
/* 2234 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2236 */     catch (RecognitionException recognitionException) {
/* 2237 */       if (this.inputState.guessing == 0) {
/* 2238 */         reportError(recognitionException);
/* 2239 */         recover(recognitionException, _tokenSet_41);
/*      */       } else {
/* 2241 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2244 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void declarationPredictor() throws RecognitionException, TokenStreamException {
/* 2249 */     this.returnAST = null;
/* 2250 */     ASTPair aSTPair = new ASTPair();
/* 2251 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 2255 */       if (LA(1) == 4 && LA(2) == 1) {
/* 2256 */         TNode tNode1 = null;
/* 2257 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2258 */         this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2259 */         match(4);
/*      */       }
/* 2261 */       else if (_tokenSet_6.member(LA(1)) && _tokenSet_7.member(LA(2))) {
/* 2262 */         declaration();
/* 2263 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } else {
/*      */         
/* 2266 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2270 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2272 */     catch (RecognitionException recognitionException) {
/* 2273 */       if (this.inputState.guessing == 0) {
/* 2274 */         reportError(recognitionException);
/* 2275 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/* 2277 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2280 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionStorageClassSpecifier() throws RecognitionException, TokenStreamException {
/* 2285 */     this.returnAST = null;
/* 2286 */     ASTPair aSTPair = new ASTPair();
/* 2287 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 2290 */       switch (LA(1)) {
/*      */         
/*      */         case 15:
/* 2293 */           tNode1 = null;
/* 2294 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2295 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2296 */           match(15);
/* 2297 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 16:
/* 2302 */           tNode1 = null;
/* 2303 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2304 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2305 */           match(16);
/* 2306 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 160:
/* 2311 */           tNode1 = null;
/* 2312 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2313 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2314 */           match(160);
/* 2315 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2320 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 2324 */     } catch (RecognitionException recognitionException) {
/* 2325 */       if (this.inputState.guessing == 0) {
/* 2326 */         reportError(recognitionException);
/* 2327 */         recover(recognitionException, _tokenSet_42);
/*      */       } else {
/* 2329 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2332 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int typeSpecifier(int paramInt) throws RecognitionException, TokenStreamException {
/* 2340 */     this.returnAST = null;
/* 2341 */     ASTPair aSTPair = new ASTPair();
/* 2342 */     TNode tNode = null;
/* 2343 */     int i = paramInt + 1; try {
/*      */       TNode tNode1, tNode2;
/*      */       boolean bool;
/*      */       TNode tNode3;
/* 2347 */       switch (LA(1)) {
/*      */         
/*      */         case 18:
/* 2350 */           tNode1 = null;
/* 2351 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2352 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2353 */           match(18);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 19:
/* 2358 */           tNode1 = null;
/* 2359 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2360 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2361 */           match(19);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 20:
/* 2366 */           tNode1 = null;
/* 2367 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2368 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2369 */           match(20);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 21:
/* 2374 */           tNode1 = null;
/* 2375 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2376 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2377 */           match(21);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 22:
/* 2382 */           tNode1 = null;
/* 2383 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2384 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2385 */           match(22);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 23:
/* 2390 */           tNode1 = null;
/* 2391 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2392 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2393 */           match(23);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 24:
/* 2398 */           tNode1 = null;
/* 2399 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2400 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2401 */           match(24);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 25:
/* 2406 */           tNode1 = null;
/* 2407 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2408 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2409 */           match(25);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 26:
/* 2414 */           tNode1 = null;
/* 2415 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2416 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2417 */           match(26);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 27:
/* 2422 */           tNode1 = null;
/* 2423 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2424 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2425 */           match(27);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 28:
/* 2430 */           tNode1 = null;
/* 2431 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2432 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2433 */           match(28);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 29:
/* 2438 */           tNode1 = null;
/* 2439 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2440 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2441 */           match(29);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 30:
/* 2446 */           tNode1 = null;
/* 2447 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2448 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2449 */           match(30);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 31:
/* 2454 */           tNode1 = null;
/* 2455 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2456 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2457 */           match(31);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 32:
/* 2462 */           tNode1 = null;
/* 2463 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2464 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2465 */           match(32);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 33:
/* 2470 */           tNode1 = null;
/* 2471 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2472 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2473 */           match(33);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 34:
/* 2478 */           tNode1 = null;
/* 2479 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2480 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2481 */           match(34);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 35:
/* 2486 */           tNode1 = null;
/* 2487 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2488 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2489 */           match(35);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 36:
/* 2494 */           tNode1 = null;
/* 2495 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2496 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2497 */           match(36);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 37:
/* 2502 */           tNode1 = null;
/* 2503 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2504 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2505 */           match(37);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 38:
/* 2510 */           tNode1 = null;
/* 2511 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2512 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2513 */           match(38);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 39:
/* 2518 */           tNode1 = null;
/* 2519 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2520 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2521 */           match(39);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 40:
/* 2526 */           tNode1 = null;
/* 2527 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2528 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2529 */           match(40);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 41:
/* 2534 */           tNode1 = null;
/* 2535 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2536 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2537 */           match(41);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 10:
/*      */         case 11:
/* 2543 */           structOrUnionSpecifier();
/* 2544 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */           
/* 2548 */           while ((LA(1) == 5 || LA(1) == 163) && LA(2) == 47) {
/* 2549 */             attributeDecl();
/* 2550 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 12:
/* 2562 */           enumSpecifier();
/* 2563 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 161:
/* 2568 */           tNode1 = null;
/* 2569 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2570 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 2571 */           match(161);
/* 2572 */           tNode2 = null;
/* 2573 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2574 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2575 */           match(47);
/*      */           
/* 2577 */           bool = false;
/* 2578 */           if (_tokenSet_43.member(LA(1)) && _tokenSet_44.member(LA(2))) {
/* 2579 */             int j = mark();
/* 2580 */             bool = true;
/* 2581 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 2584 */               typeName();
/*      */             
/*      */             }
/* 2587 */             catch (RecognitionException recognitionException) {
/* 2588 */               bool = false;
/*      */             } 
/* 2590 */             rewind(j);
/* 2591 */             this.inputState.guessing--;
/*      */           } 
/* 2593 */           if (bool) {
/* 2594 */             typeName();
/* 2595 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           }
/* 2597 */           else if (_tokenSet_3.member(LA(1)) && _tokenSet_45.member(LA(2))) {
/* 2598 */             expr();
/* 2599 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } else {
/*      */             
/* 2602 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 2606 */           tNode3 = null;
/* 2607 */           tNode3 = (TNode)this.astFactory.create(LT(1));
/* 2608 */           this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 2609 */           match(48);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 162:
/* 2614 */           tNode1 = null;
/* 2615 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2616 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2617 */           match(162);
/*      */           break;
/*      */         
/*      */         default:
/* 2621 */           if (LA(1) == 42 && paramInt == 0) {
/* 2622 */             typedefName();
/* 2623 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */           } 
/* 2626 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2630 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2632 */     catch (RecognitionException recognitionException) {
/* 2633 */       if (this.inputState.guessing == 0) {
/* 2634 */         reportError(recognitionException);
/* 2635 */         recover(recognitionException, _tokenSet_46);
/*      */       } else {
/* 2637 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2640 */     this.returnAST = (AST)tNode;
/* 2641 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structOrUnionSpecifier() throws RecognitionException, TokenStreamException {
/* 2646 */     this.returnAST = null;
/* 2647 */     ASTPair aSTPair = new ASTPair();
/* 2648 */     TNode tNode1 = null;
/* 2649 */     TNode tNode2 = null;
/* 2650 */     Token token1 = null;
/* 2651 */     TNode tNode3 = null;
/* 2652 */     Token token2 = null;
/* 2653 */     TNode tNode4 = null;
/* 2654 */     Token token3 = null;
/* 2655 */     TNode tNode5 = null;
/*      */ 
/*      */     
/*      */     try {
/* 2659 */       structOrUnion();
/* 2660 */       tNode2 = (TNode)this.returnAST;
/*      */       
/* 2662 */       boolean bool = false;
/* 2663 */       if (LA(1) == 42 && LA(2) == 7) {
/* 2664 */         int i = mark();
/* 2665 */         bool = true;
/* 2666 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 2669 */           match(42);
/* 2670 */           match(7);
/*      */         
/*      */         }
/* 2673 */         catch (RecognitionException recognitionException) {
/* 2674 */           bool = false;
/*      */         } 
/* 2676 */         rewind(i);
/* 2677 */         this.inputState.guessing--;
/*      */       } 
/* 2679 */       if (bool) {
/* 2680 */         token1 = LT(1);
/* 2681 */         tNode3 = (TNode)this.astFactory.create(token1);
/* 2682 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 2683 */         match(42);
/* 2684 */         token2 = LT(1);
/* 2685 */         tNode4 = (TNode)this.astFactory.create(token2);
/* 2686 */         this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 2687 */         match(7);
/* 2688 */         if (this.inputState.guessing == 0) {
/*      */           
/* 2690 */           String str = tNode2.getText() + " " + tNode3.getText();
/* 2691 */           tNode4.setText(str);
/* 2692 */           pushScope(str);
/*      */         } 
/*      */ 
/*      */         
/* 2696 */         switch (LA(1)) {
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 42:
/*      */           case 161:
/*      */           case 162:
/* 2730 */             structDeclarationList();
/* 2731 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2740 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 2744 */         if (this.inputState.guessing == 0) {
/* 2745 */           popScope();
/*      */         }
/* 2747 */         TNode tNode = null;
/* 2748 */         tNode = (TNode)this.astFactory.create(LT(1));
/* 2749 */         this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 2750 */         match(8);
/*      */       }
/* 2752 */       else if (LA(1) == 7) {
/* 2753 */         token3 = LT(1);
/* 2754 */         tNode5 = (TNode)this.astFactory.create(token3);
/* 2755 */         this.astFactory.addASTChild(aSTPair, (AST)tNode5);
/* 2756 */         match(7);
/* 2757 */         if (this.inputState.guessing == 0) {
/*      */           
/* 2759 */           String str = getAScopeName();
/* 2760 */           tNode5.setText(str);
/* 2761 */           pushScope(str);
/*      */         } 
/*      */ 
/*      */         
/* 2765 */         switch (LA(1)) {
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*      */           case 34:
/*      */           case 35:
/*      */           case 36:
/*      */           case 37:
/*      */           case 38:
/*      */           case 39:
/*      */           case 40:
/*      */           case 41:
/*      */           case 42:
/*      */           case 161:
/*      */           case 162:
/* 2799 */             structDeclarationList();
/* 2800 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2809 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 2813 */         if (this.inputState.guessing == 0) {
/* 2814 */           popScope();
/*      */         }
/* 2816 */         TNode tNode = null;
/* 2817 */         tNode = (TNode)this.astFactory.create(LT(1));
/* 2818 */         this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 2819 */         match(8);
/*      */       }
/* 2821 */       else if (LA(1) == 42 && _tokenSet_46.member(LA(2))) {
/* 2822 */         TNode tNode = null;
/* 2823 */         tNode = (TNode)this.astFactory.create(LT(1));
/* 2824 */         this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 2825 */         match(42);
/*      */       } else {
/*      */         
/* 2828 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2832 */       if (this.inputState.guessing == 0) {
/* 2833 */         tNode1 = (TNode)aSTPair.root;
/*      */         
/* 2835 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add((AST)tNode2).add((AST)tNode1));
/*      */         
/* 2837 */         aSTPair.root = (AST)tNode1;
/* 2838 */         aSTPair
/* 2839 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 2840 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 2842 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 2844 */     catch (RecognitionException recognitionException) {
/* 2845 */       if (this.inputState.guessing == 0) {
/* 2846 */         reportError(recognitionException);
/* 2847 */         recover(recognitionException, _tokenSet_46);
/*      */       } else {
/* 2849 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2852 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void attributeDecl() throws RecognitionException, TokenStreamException {
/* 2857 */     this.returnAST = null;
/* 2858 */     ASTPair aSTPair = new ASTPair();
/* 2859 */     TNode tNode = null; try {
/*      */       TNode tNode1; TNode tNode2; TNode tNode3; TNode tNode4;
/*      */       TNode tNode5;
/* 2862 */       switch (LA(1)) {
/*      */         
/*      */         case 163:
/* 2865 */           tNode1 = null;
/* 2866 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2867 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 2868 */           match(163);
/* 2869 */           tNode2 = null;
/* 2870 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2871 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2872 */           match(47);
/* 2873 */           tNode3 = null;
/* 2874 */           tNode3 = (TNode)this.astFactory.create(LT(1));
/* 2875 */           this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 2876 */           match(47);
/* 2877 */           attributeList();
/* 2878 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2879 */           tNode4 = null;
/* 2880 */           tNode4 = (TNode)this.astFactory.create(LT(1));
/* 2881 */           this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 2882 */           match(48);
/* 2883 */           tNode5 = null;
/* 2884 */           tNode5 = (TNode)this.astFactory.create(LT(1));
/* 2885 */           this.astFactory.addASTChild(aSTPair, (AST)tNode5);
/* 2886 */           match(48);
/* 2887 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/* 2892 */           tNode1 = null;
/* 2893 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2894 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 2895 */           match(5);
/* 2896 */           tNode2 = null;
/* 2897 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2898 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2899 */           match(47);
/* 2900 */           stringConst();
/* 2901 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2902 */           tNode3 = null;
/* 2903 */           tNode3 = (TNode)this.astFactory.create(LT(1));
/* 2904 */           this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 2905 */           match(48);
/* 2906 */           if (this.inputState.guessing == 0) {
/* 2907 */             tNode = (TNode)aSTPair.root;
/* 2908 */             tNode.setType(138);
/*      */           } 
/* 2910 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2915 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 2919 */     } catch (RecognitionException recognitionException) {
/* 2920 */       if (this.inputState.guessing == 0) {
/* 2921 */         reportError(recognitionException);
/* 2922 */         recover(recognitionException, _tokenSet_47);
/*      */       } else {
/* 2924 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2927 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void enumSpecifier() throws RecognitionException, TokenStreamException {
/* 2932 */     this.returnAST = null;
/* 2933 */     ASTPair aSTPair = new ASTPair();
/* 2934 */     TNode tNode1 = null;
/* 2935 */     Token token = null;
/* 2936 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 2939 */       TNode tNode = null;
/* 2940 */       tNode = (TNode)this.astFactory.create(LT(1));
/* 2941 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 2942 */       match(12);
/*      */       
/* 2944 */       boolean bool = false;
/* 2945 */       if (LA(1) == 42 && LA(2) == 7) {
/* 2946 */         int i = mark();
/* 2947 */         bool = true;
/* 2948 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 2951 */           match(42);
/* 2952 */           match(7);
/*      */         
/*      */         }
/* 2955 */         catch (RecognitionException recognitionException) {
/* 2956 */           bool = false;
/*      */         } 
/* 2958 */         rewind(i);
/* 2959 */         this.inputState.guessing--;
/*      */       } 
/* 2961 */       if (bool) {
/* 2962 */         token = LT(1);
/* 2963 */         tNode2 = (TNode)this.astFactory.create(token);
/* 2964 */         this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2965 */         match(42);
/* 2966 */         TNode tNode3 = null;
/* 2967 */         tNode3 = (TNode)this.astFactory.create(LT(1));
/* 2968 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 2969 */         match(7);
/* 2970 */         enumList(token.getText());
/* 2971 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2972 */         TNode tNode4 = null;
/* 2973 */         tNode4 = (TNode)this.astFactory.create(LT(1));
/* 2974 */         this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 2975 */         match(8);
/*      */       }
/* 2977 */       else if (LA(1) == 7) {
/* 2978 */         TNode tNode3 = null;
/* 2979 */         tNode3 = (TNode)this.astFactory.create(LT(1));
/* 2980 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 2981 */         match(7);
/* 2982 */         enumList("anonymous");
/* 2983 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2984 */         TNode tNode4 = null;
/* 2985 */         tNode4 = (TNode)this.astFactory.create(LT(1));
/* 2986 */         this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 2987 */         match(8);
/*      */       }
/* 2989 */       else if (LA(1) == 42 && _tokenSet_46.member(LA(2))) {
/* 2990 */         TNode tNode3 = null;
/* 2991 */         tNode3 = (TNode)this.astFactory.create(LT(1));
/* 2992 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 2993 */         match(42);
/*      */       } else {
/*      */         
/* 2996 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3000 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 3002 */     catch (RecognitionException recognitionException) {
/* 3003 */       if (this.inputState.guessing == 0) {
/* 3004 */         reportError(recognitionException);
/* 3005 */         recover(recognitionException, _tokenSet_46);
/*      */       } else {
/* 3007 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3010 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typedefName() throws RecognitionException, TokenStreamException {
/* 3015 */     this.returnAST = null;
/* 3016 */     ASTPair aSTPair = new ASTPair();
/* 3017 */     TNode tNode1 = null;
/* 3018 */     Token token = null;
/* 3019 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 3022 */       if (!isTypedefName(LT(1).getText()))
/* 3023 */         throw new SemanticException(" isTypedefName ( LT(1).getText() ) "); 
/* 3024 */       token = LT(1);
/* 3025 */       tNode2 = (TNode)this.astFactory.create(token);
/* 3026 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 3027 */       match(42);
/* 3028 */       if (this.inputState.guessing == 0) {
/* 3029 */         tNode1 = (TNode)aSTPair.root;
/* 3030 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(113)).add((AST)tNode2));
/* 3031 */         aSTPair.root = (AST)tNode1;
/* 3032 */         aSTPair
/* 3033 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 3034 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 3036 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 3038 */     catch (RecognitionException recognitionException) {
/* 3039 */       if (this.inputState.guessing == 0) {
/* 3040 */         reportError(recognitionException);
/* 3041 */         recover(recognitionException, _tokenSet_46);
/*      */       } else {
/* 3043 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3046 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typeName() throws RecognitionException, TokenStreamException {
/* 3051 */     this.returnAST = null;
/* 3052 */     ASTPair aSTPair = new ASTPair();
/* 3053 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3056 */       specifierQualifierList();
/* 3057 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 3059 */       switch (LA(1)) {
/*      */         
/*      */         case 46:
/*      */         case 47:
/*      */         case 49:
/* 3064 */           nonemptyAbstractDeclarator();
/* 3065 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3074 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3078 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3080 */     catch (RecognitionException recognitionException) {
/* 3081 */       if (this.inputState.guessing == 0) {
/* 3082 */         reportError(recognitionException);
/* 3083 */         recover(recognitionException, _tokenSet_48);
/*      */       } else {
/* 3085 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3088 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structOrUnion() throws RecognitionException, TokenStreamException {
/* 3093 */     this.returnAST = null;
/* 3094 */     ASTPair aSTPair = new ASTPair();
/* 3095 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 3098 */       switch (LA(1)) {
/*      */         
/*      */         case 10:
/* 3101 */           tNode1 = null;
/* 3102 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3103 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3104 */           match(10);
/* 3105 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 11:
/* 3110 */           tNode1 = null;
/* 3111 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3112 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3113 */           match(11);
/* 3114 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3119 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 3123 */     } catch (RecognitionException recognitionException) {
/* 3124 */       if (this.inputState.guessing == 0) {
/* 3125 */         reportError(recognitionException);
/* 3126 */         recover(recognitionException, _tokenSet_49);
/*      */       } else {
/* 3128 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3131 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclarationList() throws RecognitionException, TokenStreamException {
/* 3136 */     this.returnAST = null;
/* 3137 */     ASTPair aSTPair = new ASTPair();
/* 3138 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 3142 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 3145 */         if (_tokenSet_43.member(LA(1))) {
/* 3146 */           structDeclaration();
/* 3147 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/* 3150 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 3153 */         b++;
/*      */       } 
/*      */       
/* 3156 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3158 */     catch (RecognitionException recognitionException) {
/* 3159 */       if (this.inputState.guessing == 0) {
/* 3160 */         reportError(recognitionException);
/* 3161 */         recover(recognitionException, _tokenSet_50);
/*      */       } else {
/* 3163 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3166 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclaration() throws RecognitionException, TokenStreamException {
/* 3171 */     this.returnAST = null;
/* 3172 */     ASTPair aSTPair = new ASTPair();
/* 3173 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3176 */       specifierQualifierList();
/* 3177 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3178 */       structDeclaratorList();
/* 3179 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 3181 */       switch (LA(1)) {
/*      */         
/*      */         case 43:
/* 3184 */           match(43);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3193 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3198 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 3201 */         if (LA(1) == 9) {
/* 3202 */           match(9);
/*      */         } else {
/*      */           
/* 3205 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 3208 */         b++;
/*      */       } 
/*      */       
/* 3211 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3213 */     catch (RecognitionException recognitionException) {
/* 3214 */       if (this.inputState.guessing == 0) {
/* 3215 */         reportError(recognitionException);
/* 3216 */         recover(recognitionException, _tokenSet_51);
/*      */       } else {
/* 3218 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3221 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void specifierQualifierList() throws RecognitionException, TokenStreamException {
/* 3226 */     this.returnAST = null;
/* 3227 */     ASTPair aSTPair = new ASTPair();
/* 3228 */     TNode tNode = null;
/* 3229 */     int i = 0;
/*      */ 
/*      */     
/*      */     try {
/* 3233 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 3236 */         boolean bool = false;
/* 3237 */         if (_tokenSet_15.member(LA(1)) && _tokenSet_52.member(LA(2))) {
/* 3238 */           int j = mark();
/* 3239 */           bool = true;
/* 3240 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 3243 */             if (LA(1) == 10) {
/* 3244 */               match(10);
/*      */             }
/* 3246 */             else if (LA(1) == 11) {
/* 3247 */               match(11);
/*      */             }
/* 3249 */             else if (LA(1) == 12) {
/* 3250 */               match(12);
/*      */             }
/* 3252 */             else if (_tokenSet_15.member(LA(1))) {
/* 3253 */               typeSpecifier(i);
/*      */             } else {
/*      */               
/* 3256 */               throw new NoViableAltException(LT(1), getFilename());
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 3261 */           catch (RecognitionException recognitionException) {
/* 3262 */             bool = false;
/*      */           } 
/* 3264 */           rewind(j);
/* 3265 */           this.inputState.guessing--;
/*      */         } 
/* 3267 */         if (bool) {
/* 3268 */           i = typeSpecifier(i);
/* 3269 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         }
/* 3271 */         else if (LA(1) == 6 || LA(1) == 17) {
/* 3272 */           typeQualifier();
/* 3273 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/* 3276 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 3279 */         b++;
/*      */       } 
/*      */       
/* 3282 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3284 */     catch (RecognitionException recognitionException) {
/* 3285 */       if (this.inputState.guessing == 0) {
/* 3286 */         reportError(recognitionException);
/* 3287 */         recover(recognitionException, _tokenSet_53);
/*      */       } else {
/* 3289 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3292 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclaratorList() throws RecognitionException, TokenStreamException {
/* 3297 */     this.returnAST = null;
/* 3298 */     ASTPair aSTPair = new ASTPair();
/* 3299 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3302 */       structDeclarator();
/* 3303 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 3307 */       while (LA(1) == 43 && _tokenSet_54.member(LA(2))) {
/* 3308 */         match(43);
/* 3309 */         structDeclarator();
/* 3310 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3318 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3320 */     catch (RecognitionException recognitionException) {
/* 3321 */       if (this.inputState.guessing == 0) {
/* 3322 */         reportError(recognitionException);
/* 3323 */         recover(recognitionException, _tokenSet_55);
/*      */       } else {
/* 3325 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3328 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclarator() throws RecognitionException, TokenStreamException {
/* 3333 */     this.returnAST = null;
/* 3334 */     ASTPair aSTPair = new ASTPair();
/* 3335 */     TNode tNode = null;
/*      */     
/*      */     try {
/*      */       TNode tNode1;
/* 3339 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/* 3344 */           declarator(false);
/* 3345 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*      */         case 9:
/*      */         case 43:
/*      */         case 44:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3358 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3363 */       switch (LA(1)) {
/*      */         
/*      */         case 44:
/* 3366 */           tNode1 = null;
/* 3367 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3368 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3369 */           match(44);
/* 3370 */           constExpr();
/* 3371 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*      */         case 9:
/*      */         case 43:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3383 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3390 */       while (LA(1) == 5 || LA(1) == 163) {
/* 3391 */         attributeDecl();
/* 3392 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3400 */       if (this.inputState.guessing == 0) {
/* 3401 */         tNode = (TNode)aSTPair.root;
/* 3402 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(116)).add((AST)tNode));
/* 3403 */         aSTPair.root = (AST)tNode;
/* 3404 */         aSTPair
/* 3405 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 3406 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 3408 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3410 */     catch (RecognitionException recognitionException) {
/* 3411 */       if (this.inputState.guessing == 0) {
/* 3412 */         reportError(recognitionException);
/* 3413 */         recover(recognitionException, _tokenSet_55);
/*      */       } else {
/* 3415 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3418 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void enumList(String paramString) throws RecognitionException, TokenStreamException {
/* 3425 */     this.returnAST = null;
/* 3426 */     ASTPair aSTPair = new ASTPair();
/* 3427 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3430 */       enumerator(paramString);
/* 3431 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 3435 */       while (LA(1) == 43 && LA(2) == 42) {
/* 3436 */         match(43);
/* 3437 */         enumerator(paramString);
/* 3438 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3447 */       switch (LA(1)) {
/*      */         
/*      */         case 43:
/* 3450 */           match(43);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3459 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3463 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3465 */     catch (RecognitionException recognitionException) {
/* 3466 */       if (this.inputState.guessing == 0) {
/* 3467 */         reportError(recognitionException);
/* 3468 */         recover(recognitionException, _tokenSet_50);
/*      */       } else {
/* 3470 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3473 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void enumerator(String paramString) throws RecognitionException, TokenStreamException {
/* 3480 */     this.returnAST = null;
/* 3481 */     ASTPair aSTPair = new ASTPair();
/* 3482 */     TNode tNode1 = null;
/* 3483 */     Token token = null;
/* 3484 */     TNode tNode2 = null;
/*      */     try {
/*      */       TNode tNode;
/* 3487 */       token = LT(1);
/* 3488 */       tNode2 = (TNode)this.astFactory.create(token);
/* 3489 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 3490 */       match(42);
/* 3491 */       if (this.inputState.guessing == 0) {
/* 3492 */         this.symbolTable.add(token.getText(), (TNode)this.astFactory
/* 3493 */             .make((new ASTArray(3)).add(null).add(this.astFactory.create(12, "enum")).add(this.astFactory.create(42, paramString))));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3498 */       switch (LA(1)) {
/*      */         
/*      */         case 45:
/* 3501 */           tNode = null;
/* 3502 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 3503 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 3504 */           match(45);
/* 3505 */           constExpr();
/* 3506 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 43:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3516 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3520 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 3522 */     catch (RecognitionException recognitionException) {
/* 3523 */       if (this.inputState.guessing == 0) {
/* 3524 */         reportError(recognitionException);
/* 3525 */         recover(recognitionException, _tokenSet_31);
/*      */       } else {
/* 3527 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3530 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void initDecl(AST paramAST) throws RecognitionException, TokenStreamException {
/* 3537 */     this.returnAST = null;
/* 3538 */     ASTPair aSTPair = new ASTPair();
/* 3539 */     TNode tNode1 = null;
/* 3540 */     TNode tNode2 = null;
/* 3541 */     String str = "";
/*      */     try {
/*      */       TNode tNode;
/* 3544 */       str = declarator(false);
/* 3545 */       tNode2 = (TNode)this.returnAST;
/* 3546 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3547 */       if (this.inputState.guessing == 0) {
/*      */         
/* 3549 */         AST aST1 = this.astFactory.dupList(paramAST);
/* 3550 */         AST aST2 = this.astFactory.dupList((AST)tNode2);
/* 3551 */         this.symbolTable.add(str, (TNode)this.astFactory.make((new ASTArray(3)).add(null).add(aST1).add(aST2)));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3557 */       while (LA(1) == 5 || LA(1) == 163) {
/* 3558 */         attributeDecl();
/* 3559 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3568 */       switch (LA(1)) {
/*      */         
/*      */         case 45:
/* 3571 */           tNode = null;
/* 3572 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 3573 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 3574 */           match(45);
/* 3575 */           initializer();
/* 3576 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/* 3581 */           tNode = null;
/* 3582 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 3583 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 3584 */           match(44);
/* 3585 */           expr();
/* 3586 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */         case 43:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3596 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3600 */       if (this.inputState.guessing == 0) {
/* 3601 */         tNode1 = (TNode)aSTPair.root;
/* 3602 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(114)).add((AST)tNode1));
/* 3603 */         aSTPair.root = (AST)tNode1;
/* 3604 */         aSTPair
/* 3605 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 3606 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 3608 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 3610 */     catch (RecognitionException recognitionException) {
/* 3611 */       if (this.inputState.guessing == 0) {
/* 3612 */         reportError(recognitionException);
/* 3613 */         recover(recognitionException, _tokenSet_55);
/*      */       } else {
/* 3615 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3618 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void attributeList() throws RecognitionException, TokenStreamException {
/* 3623 */     this.returnAST = null;
/* 3624 */     ASTPair aSTPair = new ASTPair();
/* 3625 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 3628 */       attribute();
/* 3629 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 3633 */       while (LA(1) == 43 && LA(2) >= 4 && LA(2) <= 166) {
/* 3634 */         TNode tNode2 = null;
/* 3635 */         tNode2 = (TNode)this.astFactory.create(LT(1));
/* 3636 */         this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 3637 */         match(43);
/* 3638 */         attribute();
/* 3639 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3648 */       switch (LA(1)) {
/*      */         
/*      */         case 43:
/* 3651 */           tNode1 = null;
/* 3652 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3653 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3654 */           match(43);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3663 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3667 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3669 */     catch (RecognitionException recognitionException) {
/* 3670 */       if (this.inputState.guessing == 0) {
/* 3671 */         reportError(recognitionException);
/* 3672 */         recover(recognitionException, _tokenSet_48);
/*      */       } else {
/* 3674 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3677 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void stringConst() throws RecognitionException, TokenStreamException {
/* 3682 */     this.returnAST = null;
/* 3683 */     ASTPair aSTPair = new ASTPair();
/* 3684 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 3688 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 3691 */         if (LA(1) == 100) {
/* 3692 */           TNode tNode1 = null;
/* 3693 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3694 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3695 */           match(100);
/*      */         } else {
/*      */           
/* 3698 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 3701 */         b++;
/*      */       } 
/*      */       
/* 3704 */       if (this.inputState.guessing == 0) {
/* 3705 */         tNode = (TNode)aSTPair.root;
/* 3706 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(135)).add((AST)tNode));
/* 3707 */         aSTPair.root = (AST)tNode;
/* 3708 */         aSTPair
/* 3709 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 3710 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 3712 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3714 */     catch (RecognitionException recognitionException) {
/* 3715 */       if (this.inputState.guessing == 0) {
/* 3716 */         reportError(recognitionException);
/* 3717 */         recover(recognitionException, _tokenSet_56);
/*      */       } else {
/* 3719 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3722 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void attribute() throws RecognitionException, TokenStreamException {
/* 3727 */     this.returnAST = null;
/* 3728 */     ASTPair aSTPair = new ASTPair();
/* 3729 */     TNode tNode = null;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */       while (true) {
/* 3735 */         while (_tokenSet_57.member(LA(1))) {
/*      */           
/* 3737 */           TNode tNode1 = null;
/* 3738 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3739 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3740 */           match(_tokenSet_57);
/*      */         } 
/*      */         
/* 3743 */         if (LA(1) == 47) {
/* 3744 */           TNode tNode1 = null;
/* 3745 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3746 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3747 */           match(47);
/* 3748 */           attributeList();
/* 3749 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3750 */           TNode tNode2 = null;
/* 3751 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 3752 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 3753 */           match(48);
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 3761 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3763 */     catch (RecognitionException recognitionException) {
/* 3764 */       if (this.inputState.guessing == 0) {
/* 3765 */         reportError(recognitionException);
/* 3766 */         recover(recognitionException, _tokenSet_5);
/*      */       } else {
/* 3768 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3771 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void compoundStatement(String paramString) throws RecognitionException, TokenStreamException {
/* 3778 */     this.returnAST = null;
/* 3779 */     ASTPair aSTPair = new ASTPair();
/* 3780 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3783 */       TNode tNode1 = null;
/* 3784 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3785 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 3786 */       match(7);
/* 3787 */       if (this.inputState.guessing == 0)
/*      */       {
/* 3789 */         pushScope(paramString);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/* 3795 */         boolean bool1 = false;
/* 3796 */         if (_tokenSet_58.member(LA(1)) && _tokenSet_7.member(LA(2))) {
/* 3797 */           int i = mark();
/* 3798 */           bool1 = true;
/* 3799 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 3802 */             if (LA(1) == 4) {
/* 3803 */               match(4);
/*      */             }
/* 3805 */             else if (LA(1) == 159) {
/* 3806 */               match(159);
/*      */             }
/* 3808 */             else if (_tokenSet_6.member(LA(1)) && _tokenSet_7.member(LA(2))) {
/* 3809 */               declaration();
/*      */             } else {
/*      */               
/* 3812 */               throw new NoViableAltException(LT(1), getFilename());
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 3817 */           catch (RecognitionException recognitionException) {
/* 3818 */             bool1 = false;
/*      */           } 
/* 3820 */           rewind(i);
/* 3821 */           this.inputState.guessing--;
/*      */         } 
/* 3823 */         if (bool1) {
/* 3824 */           declarationList();
/* 3825 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           continue;
/*      */         } 
/* 3828 */         boolean bool2 = false;
/* 3829 */         if (_tokenSet_59.member(LA(1)) && _tokenSet_60.member(LA(2))) {
/* 3830 */           int i = mark();
/* 3831 */           bool2 = true;
/* 3832 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 3835 */             nestedFunctionDef();
/*      */           
/*      */           }
/* 3838 */           catch (RecognitionException recognitionException) {
/* 3839 */             bool2 = false;
/*      */           } 
/* 3841 */           rewind(i);
/* 3842 */           this.inputState.guessing--;
/*      */         } 
/* 3844 */         if (bool2) {
/* 3845 */           nestedFunctionDef();
/* 3846 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 3855 */       switch (LA(1)) {
/*      */         
/*      */         case 5:
/*      */         case 7:
/*      */         case 9:
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*      */         case 52:
/*      */         case 53:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 63:
/*      */         case 76:
/*      */         case 79:
/*      */         case 88:
/*      */         case 89:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 99:
/*      */         case 100:
/*      */         case 158:
/*      */         case 164:
/*      */         case 165:
/*      */         case 166:
/* 3889 */           statementList();
/* 3890 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3899 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3903 */       if (this.inputState.guessing == 0) {
/* 3904 */         popScope();
/*      */       }
/* 3906 */       TNode tNode2 = null;
/* 3907 */       tNode2 = (TNode)this.astFactory.create(LT(1));
/* 3908 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 3909 */       match(8);
/* 3910 */       if (this.inputState.guessing == 0) {
/* 3911 */         tNode = (TNode)aSTPair.root;
/* 3912 */         tNode.setType(128); tNode.setAttribute("scopeName", paramString);
/*      */       } 
/* 3914 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3916 */     catch (RecognitionException recognitionException) {
/* 3917 */       if (this.inputState.guessing == 0) {
/* 3918 */         reportError(recognitionException);
/* 3919 */         recover(recognitionException, _tokenSet_61);
/*      */       } else {
/* 3921 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3924 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void nestedFunctionDef() throws RecognitionException, TokenStreamException {
/* 3929 */     this.returnAST = null;
/* 3930 */     ASTPair aSTPair = new ASTPair();
/* 3931 */     TNode tNode1 = null;
/* 3932 */     TNode tNode2 = null;
/* 3933 */     TNode tNode3 = null;
/*      */     
/*      */     try {
/*      */       TNode tNode;
/*      */       
/* 3938 */       switch (LA(1)) {
/*      */         
/*      */         case 13:
/* 3941 */           tNode = null;
/* 3942 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 3943 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 3944 */           match(13);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 6:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/*      */         case 18:
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*      */         case 160:
/*      */         case 161:
/*      */         case 162:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3989 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3994 */       boolean bool = false;
/* 3995 */       if (_tokenSet_13.member(LA(1)) && _tokenSet_14.member(LA(2))) {
/* 3996 */         int i = mark();
/* 3997 */         bool = true;
/* 3998 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 4001 */           functionDeclSpecifiers();
/*      */         
/*      */         }
/* 4004 */         catch (RecognitionException recognitionException) {
/* 4005 */           bool = false;
/*      */         } 
/* 4007 */         rewind(i);
/* 4008 */         this.inputState.guessing--;
/*      */       } 
/* 4010 */       if (bool) {
/* 4011 */         functionDeclSpecifiers();
/* 4012 */         tNode2 = (TNode)this.returnAST;
/* 4013 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       }
/* 4015 */       else if (!_tokenSet_10.member(LA(1)) || !_tokenSet_60.member(LA(2))) {
/*      */ 
/*      */         
/* 4018 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 4022 */       String str = declarator(false);
/* 4023 */       tNode3 = (TNode)this.returnAST;
/* 4024 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4025 */       if (this.inputState.guessing == 0) {
/*      */ 
/*      */         
/* 4028 */         AST aST1 = this.astFactory.dupList((AST)tNode3);
/* 4029 */         AST aST2 = this.astFactory.dupList((AST)tNode2);
/* 4030 */         this.symbolTable.add(str, (TNode)this.astFactory.make((new ASTArray(3)).add(null).add(aST2).add(aST1)));
/* 4031 */         pushScope(str);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4037 */       while (_tokenSet_6.member(LA(1))) {
/* 4038 */         declaration();
/* 4039 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4047 */       if (this.inputState.guessing == 0) {
/* 4048 */         popScope();
/*      */       }
/* 4050 */       compoundStatement(str);
/* 4051 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4052 */       if (this.inputState.guessing == 0) {
/* 4053 */         tNode1 = (TNode)aSTPair.root;
/* 4054 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(127)).add((AST)tNode1));
/* 4055 */         aSTPair.root = (AST)tNode1;
/* 4056 */         aSTPair
/* 4057 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 4058 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 4060 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 4062 */     catch (RecognitionException recognitionException) {
/* 4063 */       if (this.inputState.guessing == 0) {
/* 4064 */         reportError(recognitionException);
/* 4065 */         recover(recognitionException, _tokenSet_41);
/*      */       } else {
/* 4067 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4070 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void statementList() throws RecognitionException, TokenStreamException {
/* 4075 */     this.returnAST = null;
/* 4076 */     ASTPair aSTPair = new ASTPair();
/* 4077 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 4081 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 4084 */         if (_tokenSet_62.member(LA(1))) {
/* 4085 */           statement();
/* 4086 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/* 4089 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 4092 */         b++;
/*      */       } 
/*      */       
/* 4095 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4097 */     catch (RecognitionException recognitionException) {
/* 4098 */       if (this.inputState.guessing == 0) {
/* 4099 */         reportError(recognitionException);
/* 4100 */         recover(recognitionException, _tokenSet_50);
/*      */       } else {
/* 4102 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4105 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void statement() throws RecognitionException, TokenStreamException {
/* 4110 */     this.returnAST = null;
/* 4111 */     ASTPair aSTPair = new ASTPair();
/* 4112 */     TNode tNode1 = null;
/* 4113 */     TNode tNode2 = null;
/* 4114 */     TNode tNode3 = null;
/* 4115 */     TNode tNode4 = null;
/* 4116 */     TNode tNode5 = null; try {
/*      */       TNode tNode6; TNode tNode7; boolean bool; TNode tNode8;
/*      */       TNode tNode9;
/* 4119 */       switch (LA(1)) {
/*      */         
/*      */         case 9:
/* 4122 */           tNode6 = null;
/* 4123 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4124 */           this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 4125 */           match(9);
/* 4126 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/* 4131 */           compoundStatement(getAScopeName());
/* 4132 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4133 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 52:
/* 4138 */           tNode6 = null;
/* 4139 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4140 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 4141 */           match(52);
/* 4142 */           match(47);
/* 4143 */           expr();
/* 4144 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4145 */           match(48);
/* 4146 */           statement();
/* 4147 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4148 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 53:
/* 4153 */           tNode6 = null;
/* 4154 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4155 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 4156 */           match(53);
/* 4157 */           statement();
/* 4158 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4159 */           match(52);
/* 4160 */           match(47);
/* 4161 */           expr();
/* 4162 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4163 */           match(48);
/* 4164 */           match(9);
/* 4165 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 54:
/* 4170 */           match(54);
/* 4171 */           tNode6 = null;
/* 4172 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4173 */           match(47);
/*      */           
/* 4175 */           switch (LA(1)) {
/*      */             
/*      */             case 5:
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 76:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 158:
/*      */             case 164:
/*      */             case 165:
/*      */             case 166:
/* 4196 */               expr();
/* 4197 */               tNode2 = (TNode)this.returnAST;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4206 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4210 */           tNode7 = null;
/* 4211 */           tNode7 = (TNode)this.astFactory.create(LT(1));
/* 4212 */           match(9);
/*      */           
/* 4214 */           switch (LA(1)) {
/*      */             
/*      */             case 5:
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 76:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 158:
/*      */             case 164:
/*      */             case 165:
/*      */             case 166:
/* 4235 */               expr();
/* 4236 */               tNode3 = (TNode)this.returnAST;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4245 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4249 */           tNode8 = null;
/* 4250 */           tNode8 = (TNode)this.astFactory.create(LT(1));
/* 4251 */           match(9);
/*      */           
/* 4253 */           switch (LA(1)) {
/*      */             
/*      */             case 5:
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 76:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 158:
/*      */             case 164:
/*      */             case 165:
/*      */             case 166:
/* 4274 */               expr();
/* 4275 */               tNode4 = (TNode)this.returnAST;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 48:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4284 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4288 */           tNode9 = null;
/* 4289 */           tNode9 = (TNode)this.astFactory.create(LT(1));
/* 4290 */           match(48);
/* 4291 */           statement();
/* 4292 */           tNode5 = (TNode)this.returnAST;
/* 4293 */           if (this.inputState.guessing == 0) {
/* 4294 */             tNode1 = (TNode)aSTPair.root;
/*      */             
/* 4296 */             if (tNode2 == null) tNode2 = (TNode)this.astFactory.create(125); 
/* 4297 */             if (tNode3 == null) tNode3 = (TNode)this.astFactory.create(125); 
/* 4298 */             if (tNode4 == null) tNode4 = (TNode)this.astFactory.create(125); 
/* 4299 */             tNode1 = (TNode)this.astFactory.make((new ASTArray(5)).add(this.astFactory.create(54, "for")).add((AST)tNode2).add((AST)tNode3).add((AST)tNode4).add((AST)tNode5));
/*      */             
/* 4301 */             aSTPair.root = (AST)tNode1;
/* 4302 */             aSTPair
/* 4303 */               .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 4304 */             aSTPair.advanceChildToEnd();
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 55:
/* 4310 */           tNode6 = null;
/* 4311 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4312 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 4313 */           match(55);
/* 4314 */           expr();
/* 4315 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4316 */           match(9);
/* 4317 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 56:
/* 4322 */           tNode6 = null;
/* 4323 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4324 */           this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 4325 */           match(56);
/* 4326 */           match(9);
/* 4327 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 57:
/* 4332 */           tNode6 = null;
/* 4333 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4334 */           this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 4335 */           match(57);
/* 4336 */           match(9);
/* 4337 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 58:
/* 4342 */           tNode6 = null;
/* 4343 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4344 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 4345 */           match(58);
/*      */           
/* 4347 */           switch (LA(1)) {
/*      */             
/*      */             case 5:
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 76:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 158:
/*      */             case 164:
/*      */             case 165:
/*      */             case 166:
/* 4368 */               expr();
/* 4369 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4378 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4382 */           match(9);
/* 4383 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 59:
/* 4388 */           tNode6 = null;
/* 4389 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4390 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 4391 */           match(59);
/*      */           
/* 4393 */           bool = false;
/* 4394 */           if (_tokenSet_3.member(LA(1)) && _tokenSet_26.member(LA(2))) {
/* 4395 */             int i = mark();
/* 4396 */             bool = true;
/* 4397 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 4400 */               constExpr();
/* 4401 */               match(51);
/*      */             
/*      */             }
/* 4404 */             catch (RecognitionException recognitionException) {
/* 4405 */               bool = false;
/*      */             } 
/* 4407 */             rewind(i);
/* 4408 */             this.inputState.guessing--;
/*      */           } 
/* 4410 */           if (bool) {
/* 4411 */             rangeExpr();
/* 4412 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           }
/* 4414 */           else if (_tokenSet_3.member(LA(1)) && _tokenSet_63.member(LA(2))) {
/* 4415 */             constExpr();
/* 4416 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } else {
/*      */             
/* 4419 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4423 */           match(44);
/*      */           
/* 4425 */           if (_tokenSet_62.member(LA(1)) && _tokenSet_64.member(LA(2))) {
/* 4426 */             statement();
/* 4427 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           }
/* 4429 */           else if (!_tokenSet_65.member(LA(1)) || !_tokenSet_66.member(LA(2))) {
/*      */ 
/*      */             
/* 4432 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4436 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 60:
/* 4441 */           tNode6 = null;
/* 4442 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4443 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 4444 */           match(60);
/* 4445 */           match(44);
/*      */           
/* 4447 */           if (_tokenSet_62.member(LA(1)) && _tokenSet_64.member(LA(2))) {
/* 4448 */             statement();
/* 4449 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           }
/* 4451 */           else if (!_tokenSet_65.member(LA(1)) || !_tokenSet_66.member(LA(2))) {
/*      */ 
/*      */             
/* 4454 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4458 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 61:
/* 4463 */           tNode6 = null;
/* 4464 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4465 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 4466 */           match(61);
/* 4467 */           match(47);
/* 4468 */           expr();
/* 4469 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4470 */           match(48);
/* 4471 */           statement();
/* 4472 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           
/* 4474 */           if (LA(1) == 62 && _tokenSet_62.member(LA(2))) {
/* 4475 */             TNode tNode = null;
/* 4476 */             tNode = (TNode)this.astFactory.create(LT(1));
/* 4477 */             this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 4478 */             match(62);
/* 4479 */             statement();
/* 4480 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           }
/* 4482 */           else if (!_tokenSet_65.member(LA(1)) || !_tokenSet_66.member(LA(2))) {
/*      */ 
/*      */             
/* 4485 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4489 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 63:
/* 4494 */           tNode6 = null;
/* 4495 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4496 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 4497 */           match(63);
/* 4498 */           match(47);
/* 4499 */           expr();
/* 4500 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4501 */           match(48);
/* 4502 */           statement();
/* 4503 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4504 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */         
/*      */         default:
/* 4508 */           if (_tokenSet_3.member(LA(1)) && _tokenSet_67.member(LA(2))) {
/* 4509 */             expr();
/* 4510 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4511 */             match(9);
/* 4512 */             if (this.inputState.guessing == 0) {
/* 4513 */               tNode1 = (TNode)aSTPair.root;
/* 4514 */               tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(124)).add((AST)tNode1));
/* 4515 */               aSTPair.root = (AST)tNode1;
/* 4516 */               aSTPair
/* 4517 */                 .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 4518 */               aSTPair.advanceChildToEnd();
/*      */             } 
/* 4520 */             tNode1 = (TNode)aSTPair.root; break;
/*      */           } 
/* 4522 */           if (LA(1) == 42 && LA(2) == 44) {
/* 4523 */             tNode6 = null;
/* 4524 */             tNode6 = (TNode)this.astFactory.create(LT(1));
/* 4525 */             this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 4526 */             match(42);
/* 4527 */             match(44);
/*      */             
/* 4529 */             if (_tokenSet_62.member(LA(1)) && _tokenSet_64.member(LA(2))) {
/* 4530 */               statement();
/* 4531 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             }
/* 4533 */             else if (!_tokenSet_65.member(LA(1)) || !_tokenSet_66.member(LA(2))) {
/*      */ 
/*      */               
/* 4536 */               throw new NoViableAltException(LT(1), getFilename());
/*      */             } 
/*      */ 
/*      */             
/* 4540 */             if (this.inputState.guessing == 0) {
/* 4541 */               tNode1 = (TNode)aSTPair.root;
/* 4542 */               tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(132)).add((AST)tNode1));
/* 4543 */               aSTPair.root = (AST)tNode1;
/* 4544 */               aSTPair
/* 4545 */                 .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 4546 */               aSTPair.advanceChildToEnd();
/*      */             } 
/* 4548 */             tNode1 = (TNode)aSTPair.root;
/*      */             break;
/*      */           } 
/* 4551 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 4555 */     } catch (RecognitionException recognitionException) {
/* 4556 */       if (this.inputState.guessing == 0) {
/* 4557 */         reportError(recognitionException);
/* 4558 */         recover(recognitionException, _tokenSet_65);
/*      */       } else {
/* 4560 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4563 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void conditionalExpr() throws RecognitionException, TokenStreamException {
/* 4568 */     this.returnAST = null;
/* 4569 */     ASTPair aSTPair = new ASTPair();
/* 4570 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1, tNode2;
/* 4573 */       logicalOrExpr();
/* 4574 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 4576 */       switch (LA(1)) {
/*      */         
/*      */         case 74:
/* 4579 */           tNode1 = null;
/* 4580 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4581 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4582 */           match(74);
/*      */           
/* 4584 */           switch (LA(1)) {
/*      */             
/*      */             case 5:
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 76:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 158:
/*      */             case 164:
/*      */             case 165:
/*      */             case 166:
/* 4605 */               expr();
/* 4606 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 44:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4615 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4619 */           tNode2 = null;
/* 4620 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 4621 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 4622 */           match(44);
/* 4623 */           conditionalExpr();
/* 4624 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*      */         case 8:
/*      */         case 9:
/*      */         case 43:
/*      */         case 44:
/*      */         case 45:
/*      */         case 48:
/*      */         case 50:
/*      */         case 51:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4652 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 4656 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4658 */     catch (RecognitionException recognitionException) {
/* 4659 */       if (this.inputState.guessing == 0) {
/* 4660 */         reportError(recognitionException);
/* 4661 */         recover(recognitionException, _tokenSet_68);
/*      */       } else {
/* 4663 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4666 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalOrExpr() throws RecognitionException, TokenStreamException {
/* 4671 */     this.returnAST = null;
/* 4672 */     ASTPair aSTPair = new ASTPair();
/* 4673 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4676 */       logicalAndExpr();
/* 4677 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 4681 */       while (LA(1) == 75) {
/* 4682 */         TNode tNode1 = null;
/* 4683 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4684 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4685 */         match(75);
/* 4686 */         logicalAndExpr();
/* 4687 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4695 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4697 */     catch (RecognitionException recognitionException) {
/* 4698 */       if (this.inputState.guessing == 0) {
/* 4699 */         reportError(recognitionException);
/* 4700 */         recover(recognitionException, _tokenSet_69);
/*      */       } else {
/* 4702 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4705 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void castExpr() throws RecognitionException, TokenStreamException {
/* 4710 */     this.returnAST = null;
/* 4711 */     ASTPair aSTPair = new ASTPair();
/* 4712 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4715 */       boolean bool = false;
/* 4716 */       if (LA(1) == 47 && _tokenSet_43.member(LA(2))) {
/* 4717 */         int i = mark();
/* 4718 */         bool = true;
/* 4719 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 4722 */           match(47);
/* 4723 */           typeName();
/* 4724 */           match(48);
/*      */         
/*      */         }
/* 4727 */         catch (RecognitionException recognitionException) {
/* 4728 */           bool = false;
/*      */         } 
/* 4730 */         rewind(i);
/* 4731 */         this.inputState.guessing--;
/*      */       } 
/* 4733 */       if (bool) {
/* 4734 */         TNode tNode1 = null;
/* 4735 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4736 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4737 */         match(47);
/* 4738 */         typeName();
/* 4739 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4740 */         TNode tNode2 = null;
/* 4741 */         tNode2 = (TNode)this.astFactory.create(LT(1));
/* 4742 */         this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 4743 */         match(48);
/*      */         
/* 4745 */         switch (LA(1)) {
/*      */           
/*      */           case 5:
/*      */           case 42:
/*      */           case 46:
/*      */           case 47:
/*      */           case 76:
/*      */           case 79:
/*      */           case 88:
/*      */           case 89:
/*      */           case 92:
/*      */           case 93:
/*      */           case 94:
/*      */           case 95:
/*      */           case 96:
/*      */           case 99:
/*      */           case 100:
/*      */           case 158:
/*      */           case 164:
/*      */           case 165:
/*      */           case 166:
/* 4766 */             castExpr();
/* 4767 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 7:
/* 4772 */             lcurlyInitializer();
/* 4773 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4778 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 4782 */         if (this.inputState.guessing == 0) {
/* 4783 */           tNode = (TNode)aSTPair.root;
/* 4784 */           tNode.setType(118);
/*      */         } 
/* 4786 */         tNode = (TNode)aSTPair.root;
/*      */       }
/* 4788 */       else if (_tokenSet_3.member(LA(1)) && _tokenSet_70.member(LA(2))) {
/* 4789 */         unaryExpr();
/* 4790 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4791 */         tNode = (TNode)aSTPair.root;
/*      */       } else {
/*      */         
/* 4794 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     
/*      */     }
/* 4798 */     catch (RecognitionException recognitionException) {
/* 4799 */       if (this.inputState.guessing == 0) {
/* 4800 */         reportError(recognitionException);
/* 4801 */         recover(recognitionException, _tokenSet_28);
/*      */       } else {
/* 4803 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4806 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void unaryExpr() throws RecognitionException, TokenStreamException {
/* 4811 */     this.returnAST = null;
/* 4812 */     ASTPair aSTPair = new ASTPair();
/* 4813 */     TNode tNode1 = null;
/* 4814 */     TNode tNode2 = null; try {
/*      */       TNode tNode;
/*      */       boolean bool;
/* 4817 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/*      */         case 47:
/*      */         case 99:
/*      */         case 100:
/*      */         case 158:
/* 4824 */           postfixExpr();
/* 4825 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4826 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 92:
/* 4831 */           tNode = null;
/* 4832 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 4833 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 4834 */           match(92);
/* 4835 */           castExpr();
/* 4836 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4837 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 93:
/* 4842 */           tNode = null;
/* 4843 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 4844 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 4845 */           match(93);
/* 4846 */           castExpr();
/* 4847 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4848 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/*      */         case 76:
/*      */         case 79:
/*      */         case 88:
/*      */         case 89:
/*      */         case 95:
/*      */         case 96:
/*      */         case 165:
/*      */         case 166:
/* 4861 */           unaryOperator();
/* 4862 */           tNode2 = (TNode)this.returnAST;
/* 4863 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4864 */           castExpr();
/* 4865 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4866 */           if (this.inputState.guessing == 0) {
/* 4867 */             tNode1 = (TNode)aSTPair.root;
/* 4868 */             tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(131)).add((AST)tNode1));
/* 4869 */             aSTPair.root = (AST)tNode1;
/* 4870 */             aSTPair
/* 4871 */               .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 4872 */             aSTPair.advanceChildToEnd();
/*      */           } 
/* 4874 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 94:
/* 4879 */           tNode = null;
/* 4880 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 4881 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 4882 */           match(94);
/*      */           
/* 4884 */           bool = false;
/* 4885 */           if (LA(1) == 47 && _tokenSet_43.member(LA(2))) {
/* 4886 */             int i = mark();
/* 4887 */             bool = true;
/* 4888 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 4891 */               match(47);
/* 4892 */               typeName();
/*      */             
/*      */             }
/* 4895 */             catch (RecognitionException recognitionException) {
/* 4896 */               bool = false;
/*      */             } 
/* 4898 */             rewind(i);
/* 4899 */             this.inputState.guessing--;
/*      */           } 
/* 4901 */           if (bool) {
/* 4902 */             TNode tNode3 = null;
/* 4903 */             tNode3 = (TNode)this.astFactory.create(LT(1));
/* 4904 */             this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 4905 */             match(47);
/* 4906 */             typeName();
/* 4907 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4908 */             TNode tNode4 = null;
/* 4909 */             tNode4 = (TNode)this.astFactory.create(LT(1));
/* 4910 */             this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 4911 */             match(48);
/*      */           }
/* 4913 */           else if (_tokenSet_3.member(LA(1)) && _tokenSet_70.member(LA(2))) {
/* 4914 */             unaryExpr();
/* 4915 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } else {
/*      */             
/* 4918 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4922 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 164:
/* 4927 */           tNode = null;
/* 4928 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 4929 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 4930 */           match(164);
/*      */           
/* 4932 */           bool = false;
/* 4933 */           if (LA(1) == 47 && _tokenSet_43.member(LA(2))) {
/* 4934 */             int i = mark();
/* 4935 */             bool = true;
/* 4936 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 4939 */               match(47);
/* 4940 */               typeName();
/*      */             
/*      */             }
/* 4943 */             catch (RecognitionException recognitionException) {
/* 4944 */               bool = false;
/*      */             } 
/* 4946 */             rewind(i);
/* 4947 */             this.inputState.guessing--;
/*      */           } 
/* 4949 */           if (bool) {
/* 4950 */             TNode tNode3 = null;
/* 4951 */             tNode3 = (TNode)this.astFactory.create(LT(1));
/* 4952 */             this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 4953 */             match(47);
/* 4954 */             typeName();
/* 4955 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4956 */             TNode tNode4 = null;
/* 4957 */             tNode4 = (TNode)this.astFactory.create(LT(1));
/* 4958 */             this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 4959 */             match(48);
/*      */           }
/* 4961 */           else if (_tokenSet_3.member(LA(1)) && _tokenSet_70.member(LA(2))) {
/* 4962 */             unaryExpr();
/* 4963 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } else {
/*      */             
/* 4966 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4970 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/* 4975 */           gnuAsmExpr();
/* 4976 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4977 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4982 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 4986 */     } catch (RecognitionException recognitionException) {
/* 4987 */       if (this.inputState.guessing == 0) {
/* 4988 */         reportError(recognitionException);
/* 4989 */         recover(recognitionException, _tokenSet_28);
/*      */       } else {
/* 4991 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4994 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void nonemptyAbstractDeclarator() throws RecognitionException, TokenStreamException {
/* 4999 */     this.returnAST = null;
/* 5000 */     ASTPair aSTPair = new ASTPair();
/* 5001 */     TNode tNode = null;
/*      */     
/*      */     try {
/*      */       byte b;
/* 5005 */       switch (LA(1)) {
/*      */         
/*      */         case 46:
/* 5008 */           pointerGroup();
/* 5009 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           while (true) {
/*      */             TNode tNode1;
/*      */             TNode tNode2;
/* 5013 */             switch (LA(1)) {
/*      */ 
/*      */               
/*      */               case 47:
/* 5017 */                 tNode1 = null;
/* 5018 */                 tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5019 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5020 */                 match(47);
/*      */                 
/* 5022 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 49:
/* 5027 */                     nonemptyAbstractDeclarator();
/* 5028 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 4:
/*      */                   case 6:
/*      */                   case 10:
/*      */                   case 11:
/*      */                   case 12:
/*      */                   case 13:
/*      */                   case 14:
/*      */                   case 15:
/*      */                   case 16:
/*      */                   case 17:
/*      */                   case 18:
/*      */                   case 19:
/*      */                   case 20:
/*      */                   case 21:
/*      */                   case 22:
/*      */                   case 23:
/*      */                   case 24:
/*      */                   case 25:
/*      */                   case 26:
/*      */                   case 27:
/*      */                   case 28:
/*      */                   case 29:
/*      */                   case 30:
/*      */                   case 31:
/*      */                   case 32:
/*      */                   case 33:
/*      */                   case 34:
/*      */                   case 35:
/*      */                   case 36:
/*      */                   case 37:
/*      */                   case 38:
/*      */                   case 39:
/*      */                   case 40:
/*      */                   case 41:
/*      */                   case 42:
/*      */                   case 160:
/*      */                   case 161:
/*      */                   case 162:
/* 5070 */                     parameterTypeList();
/* 5071 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 43:
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 5081 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/* 5086 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 43:
/* 5089 */                     match(43);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 5098 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */                 
/* 5102 */                 tNode2 = null;
/* 5103 */                 tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5104 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 5105 */                 match(48);
/*      */                 continue;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 5112 */                 tNode1 = null;
/* 5113 */                 tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5114 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5115 */                 match(49);
/*      */                 
/* 5117 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 5:
/*      */                   case 42:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 76:
/*      */                   case 79:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 95:
/*      */                   case 96:
/*      */                   case 99:
/*      */                   case 100:
/*      */                   case 158:
/*      */                   case 164:
/*      */                   case 165:
/*      */                   case 166:
/* 5138 */                     expr();
/* 5139 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 5148 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */                 
/* 5152 */                 tNode2 = null;
/* 5153 */                 tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5154 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 5155 */                 match(50);
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 47:
/*      */         case 49:
/* 5172 */           b = 0;
/*      */           while (true) {
/*      */             TNode tNode1, tNode2;
/* 5175 */             switch (LA(1)) {
/*      */ 
/*      */               
/*      */               case 47:
/* 5179 */                 tNode1 = null;
/* 5180 */                 tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5181 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5182 */                 match(47);
/*      */                 
/* 5184 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 49:
/* 5189 */                     nonemptyAbstractDeclarator();
/* 5190 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 4:
/*      */                   case 6:
/*      */                   case 10:
/*      */                   case 11:
/*      */                   case 12:
/*      */                   case 13:
/*      */                   case 14:
/*      */                   case 15:
/*      */                   case 16:
/*      */                   case 17:
/*      */                   case 18:
/*      */                   case 19:
/*      */                   case 20:
/*      */                   case 21:
/*      */                   case 22:
/*      */                   case 23:
/*      */                   case 24:
/*      */                   case 25:
/*      */                   case 26:
/*      */                   case 27:
/*      */                   case 28:
/*      */                   case 29:
/*      */                   case 30:
/*      */                   case 31:
/*      */                   case 32:
/*      */                   case 33:
/*      */                   case 34:
/*      */                   case 35:
/*      */                   case 36:
/*      */                   case 37:
/*      */                   case 38:
/*      */                   case 39:
/*      */                   case 40:
/*      */                   case 41:
/*      */                   case 42:
/*      */                   case 160:
/*      */                   case 161:
/*      */                   case 162:
/* 5232 */                     parameterTypeList();
/* 5233 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 43:
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 5243 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/* 5248 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 43:
/* 5251 */                     match(43);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 5260 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */                 
/* 5264 */                 tNode2 = null;
/* 5265 */                 tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5266 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 5267 */                 match(48);
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 5274 */                 tNode1 = null;
/* 5275 */                 tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5276 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5277 */                 match(49);
/*      */                 
/* 5279 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 5:
/*      */                   case 42:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 76:
/*      */                   case 79:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 95:
/*      */                   case 96:
/*      */                   case 99:
/*      */                   case 100:
/*      */                   case 158:
/*      */                   case 164:
/*      */                   case 165:
/*      */                   case 166:
/* 5300 */                     expr();
/* 5301 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 5310 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */                 
/* 5314 */                 tNode2 = null;
/* 5315 */                 tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5316 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 5317 */                 match(50);
/*      */                 break;
/*      */ 
/*      */ 
/*      */               
/*      */               default:
/* 5323 */                 if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */             } 
/*      */             
/* 5326 */             b++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 5333 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 5337 */       if (this.inputState.guessing == 0) {
/* 5338 */         tNode = (TNode)aSTPair.root;
/* 5339 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(122)).add((AST)tNode));
/* 5340 */         aSTPair.root = (AST)tNode;
/* 5341 */         aSTPair
/* 5342 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 5343 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 5345 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 5347 */     catch (RecognitionException recognitionException) {
/* 5348 */       if (this.inputState.guessing == 0) {
/* 5349 */         reportError(recognitionException);
/* 5350 */         recover(recognitionException, _tokenSet_40);
/*      */       } else {
/* 5352 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5355 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void postfixExpr() throws RecognitionException, TokenStreamException {
/* 5360 */     this.returnAST = null;
/* 5361 */     ASTPair aSTPair = new ASTPair();
/* 5362 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 5365 */       primaryExpr();
/* 5366 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 5368 */       switch (LA(1)) {
/*      */         
/*      */         case 47:
/*      */         case 49:
/*      */         case 92:
/*      */         case 93:
/*      */         case 97:
/*      */         case 98:
/* 5376 */           postfixSuffix();
/* 5377 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 5378 */           if (this.inputState.guessing == 0) {
/* 5379 */             tNode = (TNode)aSTPair.root;
/* 5380 */             tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(133)).add((AST)tNode));
/* 5381 */             aSTPair.root = (AST)tNode;
/* 5382 */             aSTPair
/* 5383 */               .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 5384 */             aSTPair.advanceChildToEnd();
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*      */         case 8:
/*      */         case 9:
/*      */         case 43:
/*      */         case 44:
/*      */         case 45:
/*      */         case 46:
/*      */         case 48:
/*      */         case 50:
/*      */         case 51:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5432 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 5436 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 5438 */     catch (RecognitionException recognitionException) {
/* 5439 */       if (this.inputState.guessing == 0) {
/* 5440 */         reportError(recognitionException);
/* 5441 */         recover(recognitionException, _tokenSet_28);
/*      */       } else {
/* 5443 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5446 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void unaryOperator() throws RecognitionException, TokenStreamException {
/* 5451 */     this.returnAST = null;
/* 5452 */     ASTPair aSTPair = new ASTPair();
/* 5453 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 5456 */       switch (LA(1)) {
/*      */         
/*      */         case 79:
/* 5459 */           tNode1 = null;
/* 5460 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5461 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5462 */           match(79);
/* 5463 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/* 5468 */           tNode1 = null;
/* 5469 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5470 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5471 */           match(46);
/* 5472 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 88:
/* 5477 */           tNode1 = null;
/* 5478 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5479 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5480 */           match(88);
/* 5481 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 5486 */           tNode1 = null;
/* 5487 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5488 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5489 */           match(89);
/* 5490 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 95:
/* 5495 */           tNode1 = null;
/* 5496 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5497 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5498 */           match(95);
/* 5499 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 96:
/* 5504 */           tNode1 = null;
/* 5505 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5506 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5507 */           match(96);
/* 5508 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 76:
/* 5513 */           tNode1 = null;
/* 5514 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5515 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5516 */           match(76);
/* 5517 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 165:
/* 5522 */           tNode1 = null;
/* 5523 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5524 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5525 */           match(165);
/* 5526 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 166:
/* 5531 */           tNode1 = null;
/* 5532 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5533 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5534 */           match(166);
/* 5535 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5540 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 5544 */     } catch (RecognitionException recognitionException) {
/* 5545 */       if (this.inputState.guessing == 0) {
/* 5546 */         reportError(recognitionException);
/* 5547 */         recover(recognitionException, _tokenSet_3);
/*      */       } else {
/* 5549 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5552 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void gnuAsmExpr() throws RecognitionException, TokenStreamException {
/* 5557 */     this.returnAST = null;
/* 5558 */     ASTPair aSTPair = new ASTPair();
/* 5559 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 5562 */       TNode tNode1 = null;
/* 5563 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5564 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 5565 */       match(5);
/*      */       
/* 5567 */       switch (LA(1)) {
/*      */         
/*      */         case 6:
/* 5570 */           tNode2 = null;
/* 5571 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5572 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 5573 */           match(6);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5582 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 5586 */       TNode tNode2 = null;
/* 5587 */       tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5588 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 5589 */       match(47);
/* 5590 */       stringConst();
/* 5591 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 5593 */       if (LA(1) == 44 && _tokenSet_71.member(LA(2))) {
/* 5594 */         TNode tNode4 = null;
/* 5595 */         tNode4 = (TNode)this.astFactory.create(LT(1));
/* 5596 */         this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 5597 */         match(44);
/*      */         
/* 5599 */         switch (LA(1)) {
/*      */           
/*      */           case 100:
/* 5602 */             strOptExprPair();
/* 5603 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */             
/* 5607 */             while (LA(1) == 43) {
/* 5608 */               TNode tNode5 = null;
/* 5609 */               tNode5 = (TNode)this.astFactory.create(LT(1));
/* 5610 */               this.astFactory.addASTChild(aSTPair, (AST)tNode5);
/* 5611 */               match(43);
/* 5612 */               strOptExprPair();
/* 5613 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 44:
/*      */           case 48:
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 5630 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 5635 */         if (LA(1) == 44 && _tokenSet_71.member(LA(2))) {
/* 5636 */           TNode tNode5 = null;
/* 5637 */           tNode5 = (TNode)this.astFactory.create(LT(1));
/* 5638 */           this.astFactory.addASTChild(aSTPair, (AST)tNode5);
/* 5639 */           match(44);
/*      */           
/* 5641 */           switch (LA(1)) {
/*      */             
/*      */             case 100:
/* 5644 */               strOptExprPair();
/* 5645 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */               
/* 5649 */               while (LA(1) == 43) {
/* 5650 */                 TNode tNode6 = null;
/* 5651 */                 tNode6 = (TNode)this.astFactory.create(LT(1));
/* 5652 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 5653 */                 match(43);
/* 5654 */                 strOptExprPair();
/* 5655 */                 this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               } 
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 44:
/*      */             case 48:
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             default:
/* 5672 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/* 5677 */         } else if ((LA(1) != 44 && LA(1) != 48) || !_tokenSet_72.member(LA(2))) {
/*      */ 
/*      */           
/* 5680 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 5685 */       else if ((LA(1) != 44 && LA(1) != 48) || !_tokenSet_72.member(LA(2))) {
/*      */ 
/*      */         
/* 5688 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 5693 */       switch (LA(1)) {
/*      */         
/*      */         case 44:
/* 5696 */           tNode3 = null;
/* 5697 */           tNode3 = (TNode)this.astFactory.create(LT(1));
/* 5698 */           this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 5699 */           match(44);
/* 5700 */           stringConst();
/* 5701 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */           
/* 5705 */           while (LA(1) == 43) {
/* 5706 */             TNode tNode4 = null;
/* 5707 */             tNode4 = (TNode)this.astFactory.create(LT(1));
/* 5708 */             this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 5709 */             match(43);
/* 5710 */             stringConst();
/* 5711 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 5727 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 5731 */       TNode tNode3 = null;
/* 5732 */       tNode3 = (TNode)this.astFactory.create(LT(1));
/* 5733 */       this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 5734 */       match(48);
/* 5735 */       if (this.inputState.guessing == 0) {
/* 5736 */         tNode = (TNode)aSTPair.root;
/* 5737 */         tNode.setType(139);
/*      */       } 
/* 5739 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 5741 */     catch (RecognitionException recognitionException) {
/* 5742 */       if (this.inputState.guessing == 0) {
/* 5743 */         reportError(recognitionException);
/* 5744 */         recover(recognitionException, _tokenSet_28);
/*      */       } else {
/* 5746 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5749 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void strOptExprPair() throws RecognitionException, TokenStreamException {
/* 5754 */     this.returnAST = null;
/* 5755 */     ASTPair aSTPair = new ASTPair();
/* 5756 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1, tNode2;
/* 5759 */       stringConst();
/* 5760 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 5762 */       switch (LA(1)) {
/*      */         
/*      */         case 47:
/* 5765 */           tNode1 = null;
/* 5766 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5767 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5768 */           match(47);
/* 5769 */           expr();
/* 5770 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 5771 */           tNode2 = null;
/* 5772 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5773 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 5774 */           match(48);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 43:
/*      */         case 44:
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5785 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 5789 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 5791 */     catch (RecognitionException recognitionException) {
/* 5792 */       if (this.inputState.guessing == 0) {
/* 5793 */         reportError(recognitionException);
/* 5794 */         recover(recognitionException, _tokenSet_73);
/*      */       } else {
/* 5796 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5799 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void primaryExpr() throws RecognitionException, TokenStreamException {
/* 5804 */     this.returnAST = null;
/* 5805 */     ASTPair aSTPair = new ASTPair();
/* 5806 */     TNode tNode = null; try {
/*      */       TNode tNode1;
/*      */       boolean bool;
/* 5809 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/* 5812 */           tNode1 = null;
/* 5813 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5814 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5815 */           match(42);
/* 5816 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 158:
/* 5821 */           tNode1 = null;
/* 5822 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5823 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5824 */           match(158);
/* 5825 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 99:
/* 5830 */           charConst();
/* 5831 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 5832 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 100:
/* 5837 */           stringConst();
/* 5838 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 5839 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */         
/*      */         default:
/* 5843 */           bool = false;
/* 5844 */           if (LA(1) == 47 && LA(2) == 7) {
/* 5845 */             int i = mark();
/* 5846 */             bool = true;
/* 5847 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 5850 */               match(47);
/* 5851 */               match(7);
/*      */             
/*      */             }
/* 5854 */             catch (RecognitionException recognitionException) {
/* 5855 */               bool = false;
/*      */             } 
/* 5857 */             rewind(i);
/* 5858 */             this.inputState.guessing--;
/*      */           } 
/* 5860 */           if (bool) {
/* 5861 */             TNode tNode2 = null;
/* 5862 */             tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5863 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode2);
/* 5864 */             match(47);
/* 5865 */             compoundStatement(getAScopeName());
/* 5866 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 5867 */             TNode tNode3 = null;
/* 5868 */             tNode3 = (TNode)this.astFactory.create(LT(1));
/* 5869 */             this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 5870 */             match(48);
/* 5871 */             tNode = (TNode)aSTPair.root; break;
/*      */           } 
/* 5873 */           if (LA(1) == 47 && _tokenSet_3.member(LA(2))) {
/* 5874 */             TNode tNode2 = null;
/* 5875 */             tNode2 = (TNode)this.astFactory.create(LT(1));
/* 5876 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode2);
/* 5877 */             match(47);
/* 5878 */             expr();
/* 5879 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 5880 */             TNode tNode3 = null;
/* 5881 */             tNode3 = (TNode)this.astFactory.create(LT(1));
/* 5882 */             this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 5883 */             match(48);
/* 5884 */             if (this.inputState.guessing == 0) {
/* 5885 */               tNode = (TNode)aSTPair.root;
/* 5886 */               tNode.setType(120);
/*      */             } 
/* 5888 */             tNode = (TNode)aSTPair.root;
/*      */             break;
/*      */           } 
/* 5891 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 5895 */     } catch (RecognitionException recognitionException) {
/* 5896 */       if (this.inputState.guessing == 0) {
/* 5897 */         reportError(recognitionException);
/* 5898 */         recover(recognitionException, _tokenSet_56);
/*      */       } else {
/* 5900 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5903 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void charConst() throws RecognitionException, TokenStreamException {
/* 5908 */     this.returnAST = null;
/* 5909 */     ASTPair aSTPair = new ASTPair();
/* 5910 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 5913 */       TNode tNode1 = null;
/* 5914 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5915 */       this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5916 */       match(99);
/* 5917 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 5919 */     catch (RecognitionException recognitionException) {
/* 5920 */       if (this.inputState.guessing == 0) {
/* 5921 */         reportError(recognitionException);
/* 5922 */         recover(recognitionException, _tokenSet_56);
/*      */       } else {
/* 5924 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5927 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void storageClassSpecifier() throws RecognitionException, TokenStreamException {
/* 5932 */     this.returnAST = null;
/* 5933 */     ASTPair aSTPair = new ASTPair();
/* 5934 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 5937 */       switch (LA(1)) {
/*      */         
/*      */         case 13:
/* 5940 */           tNode1 = null;
/* 5941 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5942 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5943 */           match(13);
/* 5944 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 14:
/* 5949 */           tNode1 = null;
/* 5950 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5951 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5952 */           match(14);
/* 5953 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/* 5958 */           tNode1 = null;
/* 5959 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5960 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5961 */           match(4);
/* 5962 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 15:
/*      */         case 16:
/*      */         case 160:
/* 5969 */           functionStorageClassSpecifier();
/* 5970 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 5971 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5976 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 5980 */     } catch (RecognitionException recognitionException) {
/* 5981 */       if (this.inputState.guessing == 0) {
/* 5982 */         reportError(recognitionException);
/* 5983 */         recover(recognitionException, _tokenSet_42);
/*      */       } else {
/* 5985 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5988 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typeQualifier() throws RecognitionException, TokenStreamException {
/* 5993 */     this.returnAST = null;
/* 5994 */     ASTPair aSTPair = new ASTPair();
/* 5995 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 5998 */       switch (LA(1)) {
/*      */         
/*      */         case 17:
/* 6001 */           tNode1 = null;
/* 6002 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6003 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6004 */           match(17);
/* 6005 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 6:
/* 6010 */           tNode1 = null;
/* 6011 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6012 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6013 */           match(6);
/* 6014 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6019 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 6023 */     } catch (RecognitionException recognitionException) {
/* 6024 */       if (this.inputState.guessing == 0) {
/* 6025 */         reportError(recognitionException);
/* 6026 */         recover(recognitionException, _tokenSet_46);
/*      */       } else {
/* 6028 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6031 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void assignOperator() throws RecognitionException, TokenStreamException {
/* 6036 */     this.returnAST = null;
/* 6037 */     ASTPair aSTPair = new ASTPair();
/* 6038 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 6041 */       switch (LA(1)) {
/*      */         
/*      */         case 45:
/* 6044 */           tNode1 = null;
/* 6045 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6046 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6047 */           match(45);
/* 6048 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 64:
/* 6053 */           tNode1 = null;
/* 6054 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6055 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6056 */           match(64);
/* 6057 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 65:
/* 6062 */           tNode1 = null;
/* 6063 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6064 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6065 */           match(65);
/* 6066 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 66:
/* 6071 */           tNode1 = null;
/* 6072 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6073 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6074 */           match(66);
/* 6075 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 67:
/* 6080 */           tNode1 = null;
/* 6081 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6082 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6083 */           match(67);
/* 6084 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 68:
/* 6089 */           tNode1 = null;
/* 6090 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6091 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6092 */           match(68);
/* 6093 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 69:
/* 6098 */           tNode1 = null;
/* 6099 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6100 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6101 */           match(69);
/* 6102 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 70:
/* 6107 */           tNode1 = null;
/* 6108 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6109 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6110 */           match(70);
/* 6111 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 71:
/* 6116 */           tNode1 = null;
/* 6117 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6118 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6119 */           match(71);
/* 6120 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 72:
/* 6125 */           tNode1 = null;
/* 6126 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6127 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6128 */           match(72);
/* 6129 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 73:
/* 6134 */           tNode1 = null;
/* 6135 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6136 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6137 */           match(73);
/* 6138 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6143 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 6147 */     } catch (RecognitionException recognitionException) {
/* 6148 */       if (this.inputState.guessing == 0) {
/* 6149 */         reportError(recognitionException);
/* 6150 */         recover(recognitionException, _tokenSet_3);
/*      */       } else {
/* 6152 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6155 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalAndExpr() throws RecognitionException, TokenStreamException {
/* 6160 */     this.returnAST = null;
/* 6161 */     ASTPair aSTPair = new ASTPair();
/* 6162 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6165 */       inclusiveOrExpr();
/* 6166 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6170 */       while (LA(1) == 76) {
/* 6171 */         TNode tNode1 = null;
/* 6172 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6173 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6174 */         match(76);
/* 6175 */         inclusiveOrExpr();
/* 6176 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6184 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6186 */     catch (RecognitionException recognitionException) {
/* 6187 */       if (this.inputState.guessing == 0) {
/* 6188 */         reportError(recognitionException);
/* 6189 */         recover(recognitionException, _tokenSet_74);
/*      */       } else {
/* 6191 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6194 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void inclusiveOrExpr() throws RecognitionException, TokenStreamException {
/* 6199 */     this.returnAST = null;
/* 6200 */     ASTPair aSTPair = new ASTPair();
/* 6201 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6204 */       exclusiveOrExpr();
/* 6205 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6209 */       while (LA(1) == 77) {
/* 6210 */         TNode tNode1 = null;
/* 6211 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6212 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6213 */         match(77);
/* 6214 */         exclusiveOrExpr();
/* 6215 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6223 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6225 */     catch (RecognitionException recognitionException) {
/* 6226 */       if (this.inputState.guessing == 0) {
/* 6227 */         reportError(recognitionException);
/* 6228 */         recover(recognitionException, _tokenSet_75);
/*      */       } else {
/* 6230 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6233 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void exclusiveOrExpr() throws RecognitionException, TokenStreamException {
/* 6238 */     this.returnAST = null;
/* 6239 */     ASTPair aSTPair = new ASTPair();
/* 6240 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6243 */       bitAndExpr();
/* 6244 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6248 */       while (LA(1) == 78) {
/* 6249 */         TNode tNode1 = null;
/* 6250 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6251 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6252 */         match(78);
/* 6253 */         bitAndExpr();
/* 6254 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6262 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6264 */     catch (RecognitionException recognitionException) {
/* 6265 */       if (this.inputState.guessing == 0) {
/* 6266 */         reportError(recognitionException);
/* 6267 */         recover(recognitionException, _tokenSet_76);
/*      */       } else {
/* 6269 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6272 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void bitAndExpr() throws RecognitionException, TokenStreamException {
/* 6277 */     this.returnAST = null;
/* 6278 */     ASTPair aSTPair = new ASTPair();
/* 6279 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6282 */       equalityExpr();
/* 6283 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6287 */       while (LA(1) == 79) {
/* 6288 */         TNode tNode1 = null;
/* 6289 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6290 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6291 */         match(79);
/* 6292 */         equalityExpr();
/* 6293 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6301 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6303 */     catch (RecognitionException recognitionException) {
/* 6304 */       if (this.inputState.guessing == 0) {
/* 6305 */         reportError(recognitionException);
/* 6306 */         recover(recognitionException, _tokenSet_77);
/*      */       } else {
/* 6308 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6311 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void equalityExpr() throws RecognitionException, TokenStreamException {
/* 6316 */     this.returnAST = null;
/* 6317 */     ASTPair aSTPair = new ASTPair();
/* 6318 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6321 */       relationalExpr();
/* 6322 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6326 */       while (LA(1) == 80 || LA(1) == 81) {
/*      */         TNode tNode1;
/* 6328 */         switch (LA(1)) {
/*      */           
/*      */           case 80:
/* 6331 */             tNode1 = null;
/* 6332 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6333 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6334 */             match(80);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 81:
/* 6339 */             tNode1 = null;
/* 6340 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6341 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6342 */             match(81);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 6347 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 6351 */         relationalExpr();
/* 6352 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6360 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6362 */     catch (RecognitionException recognitionException) {
/* 6363 */       if (this.inputState.guessing == 0) {
/* 6364 */         reportError(recognitionException);
/* 6365 */         recover(recognitionException, _tokenSet_78);
/*      */       } else {
/* 6367 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6370 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void relationalExpr() throws RecognitionException, TokenStreamException {
/* 6375 */     this.returnAST = null;
/* 6376 */     ASTPair aSTPair = new ASTPair();
/* 6377 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6380 */       shiftExpr();
/* 6381 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6385 */       while (LA(1) >= 82 && LA(1) <= 85) {
/*      */         TNode tNode1;
/* 6387 */         switch (LA(1)) {
/*      */           
/*      */           case 82:
/* 6390 */             tNode1 = null;
/* 6391 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6392 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6393 */             match(82);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 83:
/* 6398 */             tNode1 = null;
/* 6399 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6400 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6401 */             match(83);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 84:
/* 6406 */             tNode1 = null;
/* 6407 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6408 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6409 */             match(84);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 85:
/* 6414 */             tNode1 = null;
/* 6415 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6416 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6417 */             match(85);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 6422 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 6426 */         shiftExpr();
/* 6427 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6435 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6437 */     catch (RecognitionException recognitionException) {
/* 6438 */       if (this.inputState.guessing == 0) {
/* 6439 */         reportError(recognitionException);
/* 6440 */         recover(recognitionException, _tokenSet_79);
/*      */       } else {
/* 6442 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6445 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void shiftExpr() throws RecognitionException, TokenStreamException {
/* 6450 */     this.returnAST = null;
/* 6451 */     ASTPair aSTPair = new ASTPair();
/* 6452 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6455 */       additiveExpr();
/* 6456 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6460 */       while (LA(1) == 86 || LA(1) == 87) {
/*      */         TNode tNode1;
/* 6462 */         switch (LA(1)) {
/*      */           
/*      */           case 86:
/* 6465 */             tNode1 = null;
/* 6466 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6467 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6468 */             match(86);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 87:
/* 6473 */             tNode1 = null;
/* 6474 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6475 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6476 */             match(87);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 6481 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 6485 */         additiveExpr();
/* 6486 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6494 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6496 */     catch (RecognitionException recognitionException) {
/* 6497 */       if (this.inputState.guessing == 0) {
/* 6498 */         reportError(recognitionException);
/* 6499 */         recover(recognitionException, _tokenSet_80);
/*      */       } else {
/* 6501 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6504 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void additiveExpr() throws RecognitionException, TokenStreamException {
/* 6509 */     this.returnAST = null;
/* 6510 */     ASTPair aSTPair = new ASTPair();
/* 6511 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6514 */       multExpr();
/* 6515 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6519 */       while (LA(1) == 88 || LA(1) == 89) {
/*      */         TNode tNode1;
/* 6521 */         switch (LA(1)) {
/*      */           
/*      */           case 88:
/* 6524 */             tNode1 = null;
/* 6525 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6526 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6527 */             match(88);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 89:
/* 6532 */             tNode1 = null;
/* 6533 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6534 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6535 */             match(89);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 6540 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 6544 */         multExpr();
/* 6545 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6553 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6555 */     catch (RecognitionException recognitionException) {
/* 6556 */       if (this.inputState.guessing == 0) {
/* 6557 */         reportError(recognitionException);
/* 6558 */         recover(recognitionException, _tokenSet_81);
/*      */       } else {
/* 6560 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6563 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void multExpr() throws RecognitionException, TokenStreamException {
/* 6568 */     this.returnAST = null;
/* 6569 */     ASTPair aSTPair = new ASTPair();
/* 6570 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6573 */       castExpr();
/* 6574 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6578 */       while (_tokenSet_82.member(LA(1))) {
/*      */         TNode tNode1;
/* 6580 */         switch (LA(1)) {
/*      */           
/*      */           case 46:
/* 6583 */             tNode1 = null;
/* 6584 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6585 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6586 */             match(46);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 90:
/* 6591 */             tNode1 = null;
/* 6592 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6593 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6594 */             match(90);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 91:
/* 6599 */             tNode1 = null;
/* 6600 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6601 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 6602 */             match(91);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 6607 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 6611 */         castExpr();
/* 6612 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6620 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6622 */     catch (RecognitionException recognitionException) {
/* 6623 */       if (this.inputState.guessing == 0) {
/* 6624 */         reportError(recognitionException);
/* 6625 */         recover(recognitionException, _tokenSet_83);
/*      */       } else {
/* 6627 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6630 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void postfixSuffix() throws RecognitionException, TokenStreamException {
/* 6635 */     this.returnAST = null;
/* 6636 */     ASTPair aSTPair = new ASTPair();
/* 6637 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 6641 */       byte b = 0;
/*      */       while (true) {
/*      */         TNode tNode1, tNode2;
/* 6644 */         switch (LA(1)) {
/*      */           
/*      */           case 97:
/* 6647 */             tNode1 = null;
/* 6648 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6649 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6650 */             match(97);
/* 6651 */             tNode2 = null;
/* 6652 */             tNode2 = (TNode)this.astFactory.create(LT(1));
/* 6653 */             this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 6654 */             match(42);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 98:
/* 6659 */             tNode1 = null;
/* 6660 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6661 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6662 */             match(98);
/* 6663 */             tNode2 = null;
/* 6664 */             tNode2 = (TNode)this.astFactory.create(LT(1));
/* 6665 */             this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 6666 */             match(42);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 47:
/* 6671 */             functionCall();
/* 6672 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 49:
/* 6677 */             tNode1 = null;
/* 6678 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6679 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6680 */             match(49);
/* 6681 */             expr();
/* 6682 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 6683 */             tNode2 = null;
/* 6684 */             tNode2 = (TNode)this.astFactory.create(LT(1));
/* 6685 */             this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 6686 */             match(50);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 92:
/* 6691 */             tNode1 = null;
/* 6692 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6693 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6694 */             match(92);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 93:
/* 6699 */             tNode1 = null;
/* 6700 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6701 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6702 */             match(93);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 6707 */             if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 6710 */         b++;
/*      */       } 
/*      */       
/* 6713 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6715 */     catch (RecognitionException recognitionException) {
/* 6716 */       if (this.inputState.guessing == 0) {
/* 6717 */         reportError(recognitionException);
/* 6718 */         recover(recognitionException, _tokenSet_28);
/*      */       } else {
/* 6720 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6723 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionCall() throws RecognitionException, TokenStreamException {
/* 6728 */     this.returnAST = null;
/* 6729 */     ASTPair aSTPair = new ASTPair();
/* 6730 */     TNode tNode1 = null;
/* 6731 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 6734 */       TNode tNode3 = null;
/* 6735 */       tNode3 = (TNode)this.astFactory.create(LT(1));
/* 6736 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode3);
/* 6737 */       match(47);
/*      */       
/* 6739 */       switch (LA(1)) {
/*      */         
/*      */         case 5:
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*      */         case 76:
/*      */         case 79:
/*      */         case 88:
/*      */         case 89:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 99:
/*      */         case 100:
/*      */         case 158:
/*      */         case 164:
/*      */         case 165:
/*      */         case 166:
/* 6760 */           argExprList();
/* 6761 */           tNode2 = (TNode)this.returnAST;
/* 6762 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6771 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 6775 */       TNode tNode4 = null;
/* 6776 */       tNode4 = (TNode)this.astFactory.create(LT(1));
/* 6777 */       this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 6778 */       match(48);
/* 6779 */       if (this.inputState.guessing == 0) {
/* 6780 */         tNode1 = (TNode)aSTPair.root;
/*      */         
/* 6782 */         tNode1.setType(121);
/*      */       } 
/*      */       
/* 6785 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 6787 */     catch (RecognitionException recognitionException) {
/* 6788 */       if (this.inputState.guessing == 0) {
/* 6789 */         reportError(recognitionException);
/* 6790 */         recover(recognitionException, _tokenSet_56);
/*      */       } else {
/* 6792 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6795 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void argExprList() throws RecognitionException, TokenStreamException {
/* 6800 */     this.returnAST = null;
/* 6801 */     ASTPair aSTPair = new ASTPair();
/* 6802 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 6805 */       assignExpr();
/* 6806 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 6810 */       while (LA(1) == 43) {
/* 6811 */         match(43);
/* 6812 */         assignExpr();
/* 6813 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6821 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 6823 */     catch (RecognitionException recognitionException) {
/* 6824 */       if (this.inputState.guessing == 0) {
/* 6825 */         reportError(recognitionException);
/* 6826 */         recover(recognitionException, _tokenSet_48);
/*      */       } else {
/* 6828 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6831 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void intConst() throws RecognitionException, TokenStreamException {
/* 6836 */     this.returnAST = null;
/* 6837 */     ASTPair aSTPair = new ASTPair();
/* 6838 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 6841 */       switch (LA(1)) {
/*      */         
/*      */         case 101:
/* 6844 */           tNode1 = null;
/* 6845 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6846 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6847 */           match(101);
/* 6848 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 102:
/* 6853 */           tNode1 = null;
/* 6854 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6855 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6856 */           match(102);
/* 6857 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 103:
/* 6862 */           tNode1 = null;
/* 6863 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6864 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6865 */           match(103);
/* 6866 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 104:
/* 6871 */           tNode1 = null;
/* 6872 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6873 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6874 */           match(104);
/* 6875 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 105:
/* 6880 */           tNode1 = null;
/* 6881 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6882 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6883 */           match(105);
/* 6884 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 106:
/* 6889 */           tNode1 = null;
/* 6890 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6891 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6892 */           match(106);
/* 6893 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 107:
/* 6898 */           tNode1 = null;
/* 6899 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6900 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6901 */           match(107);
/* 6902 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 108:
/* 6907 */           tNode1 = null;
/* 6908 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6909 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6910 */           match(108);
/* 6911 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 109:
/* 6916 */           tNode1 = null;
/* 6917 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6918 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6919 */           match(109);
/* 6920 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6925 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 6929 */     } catch (RecognitionException recognitionException) {
/* 6930 */       if (this.inputState.guessing == 0) {
/* 6931 */         reportError(recognitionException);
/* 6932 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/* 6934 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6937 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void floatConst() throws RecognitionException, TokenStreamException {
/* 6942 */     this.returnAST = null;
/* 6943 */     ASTPair aSTPair = new ASTPair();
/* 6944 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 6947 */       switch (LA(1)) {
/*      */         
/*      */         case 110:
/* 6950 */           tNode1 = null;
/* 6951 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6952 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6953 */           match(110);
/* 6954 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 111:
/* 6959 */           tNode1 = null;
/* 6960 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6961 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6962 */           match(111);
/* 6963 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 112:
/* 6968 */           tNode1 = null;
/* 6969 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 6970 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 6971 */           match(112);
/* 6972 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6977 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 6981 */     } catch (RecognitionException recognitionException) {
/* 6982 */       if (this.inputState.guessing == 0) {
/* 6983 */         reportError(recognitionException);
/* 6984 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/* 6986 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6989 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void dummy() throws RecognitionException, TokenStreamException {
/* 6994 */     this.returnAST = null;
/* 6995 */     ASTPair aSTPair = new ASTPair();
/* 6996 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 6999 */       switch (LA(1)) {
/*      */         
/*      */         case 113:
/* 7002 */           tNode1 = null;
/* 7003 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7004 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7005 */           match(113);
/* 7006 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 114:
/* 7011 */           tNode1 = null;
/* 7012 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7013 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7014 */           match(114);
/* 7015 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 115:
/* 7020 */           tNode1 = null;
/* 7021 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7022 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7023 */           match(115);
/* 7024 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 116:
/* 7029 */           tNode1 = null;
/* 7030 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7031 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7032 */           match(116);
/* 7033 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 117:
/* 7038 */           tNode1 = null;
/* 7039 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7040 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7041 */           match(117);
/* 7042 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 118:
/* 7047 */           tNode1 = null;
/* 7048 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7049 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7050 */           match(118);
/* 7051 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 119:
/* 7056 */           tNode1 = null;
/* 7057 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7058 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7059 */           match(119);
/* 7060 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 120:
/* 7065 */           tNode1 = null;
/* 7066 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7067 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7068 */           match(120);
/* 7069 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 121:
/* 7074 */           tNode1 = null;
/* 7075 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7076 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7077 */           match(121);
/* 7078 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 122:
/* 7083 */           tNode1 = null;
/* 7084 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7085 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7086 */           match(122);
/* 7087 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 123:
/* 7092 */           tNode1 = null;
/* 7093 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7094 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7095 */           match(123);
/* 7096 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 124:
/* 7101 */           tNode1 = null;
/* 7102 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7103 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7104 */           match(124);
/* 7105 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 125:
/* 7110 */           tNode1 = null;
/* 7111 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7112 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7113 */           match(125);
/* 7114 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 126:
/* 7119 */           tNode1 = null;
/* 7120 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7121 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7122 */           match(126);
/* 7123 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 127:
/* 7128 */           tNode1 = null;
/* 7129 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7130 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7131 */           match(127);
/* 7132 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 128:
/* 7137 */           tNode1 = null;
/* 7138 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7139 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7140 */           match(128);
/* 7141 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 129:
/* 7146 */           tNode1 = null;
/* 7147 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7148 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7149 */           match(129);
/* 7150 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 130:
/* 7155 */           tNode1 = null;
/* 7156 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7157 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7158 */           match(130);
/* 7159 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 131:
/* 7164 */           tNode1 = null;
/* 7165 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7166 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7167 */           match(131);
/* 7168 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 132:
/* 7173 */           tNode1 = null;
/* 7174 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7175 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7176 */           match(132);
/* 7177 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 133:
/* 7182 */           tNode1 = null;
/* 7183 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7184 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7185 */           match(133);
/* 7186 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 134:
/* 7191 */           tNode1 = null;
/* 7192 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7193 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7194 */           match(134);
/* 7195 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 135:
/* 7200 */           tNode1 = null;
/* 7201 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7202 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7203 */           match(135);
/* 7204 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 136:
/* 7209 */           tNode1 = null;
/* 7210 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7211 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7212 */           match(136);
/* 7213 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 137:
/* 7218 */           tNode1 = null;
/* 7219 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7220 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7221 */           match(137);
/* 7222 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 138:
/* 7227 */           tNode1 = null;
/* 7228 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7229 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7230 */           match(138);
/* 7231 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 139:
/* 7236 */           tNode1 = null;
/* 7237 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7238 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7239 */           match(139);
/* 7240 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 140:
/* 7245 */           tNode1 = null;
/* 7246 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 7247 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 7248 */           match(140);
/* 7249 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 7254 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 7258 */     } catch (RecognitionException recognitionException) {
/* 7259 */       if (this.inputState.guessing == 0) {
/* 7260 */         reportError(recognitionException);
/* 7261 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/* 7263 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 7266 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/* 7270 */   public static final String[] _tokenNames = new String[] { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"typedef\"", "\"asm\"", "\"volatile\"", "LCURLY", "RCURLY", "SEMI", "\"struct\"", "\"union\"", "\"enum\"", "\"auto\"", "\"register\"", "\"extern\"", "\"static\"", "\"const\"", "\"void\"", "\"char\"", "\"short\"", "\"int\"", "\"long\"", "\"float\"", "\"double\"", "\"signed\"", "\"unsigned\"", "\"int8_t\"", "\"uint8_t\"", "\"int16_t\"", "\"uint16_t\"", "\"__int32\"", "\"int32_t\"", "\"wchar_t\"", "\"uint32_t\"", "\"__int64\"", "\"int64_t\"", "\"uint64_t\"", "\"ptrdiff_t\"", "\"intptr_t\"", "\"size_t\"", "\"uintptr_t\"", "ID", "COMMA", "COLON", "ASSIGN", "STAR", "LPAREN", "RPAREN", "LBRACKET", "RBRACKET", "VARARGS", "\"while\"", "\"do\"", "\"for\"", "\"goto\"", "\"continue\"", "\"break\"", "\"return\"", "\"case\"", "\"default\"", "\"if\"", "\"else\"", "\"switch\"", "DIV_ASSIGN", "PLUS_ASSIGN", "MINUS_ASSIGN", "STAR_ASSIGN", "MOD_ASSIGN", "RSHIFT_ASSIGN", "LSHIFT_ASSIGN", "BAND_ASSIGN", "BOR_ASSIGN", "BXOR_ASSIGN", "QUESTION", "LOR", "LAND", "BOR", "BXOR", "BAND", "EQUAL", "NOT_EQUAL", "LT", "LTE", "GT", "GTE", "LSHIFT", "RSHIFT", "PLUS", "MINUS", "DIV", "MOD", "INC", "DEC", "\"sizeof\"", "BNOT", "LNOT", "PTR", "DOT", "CharLiteral", "StringLiteral", "IntOctalConst", "LongOctalConst", "UnsignedOctalConst", "IntIntConst", "LongIntConst", "UnsignedIntConst", "IntHexConst", "LongHexConst", "UnsignedHexConst", "FloatDoubleConst", "DoubleDoubleConst", "LongDoubleConst", "NTypedefName", "NInitDecl", "NDeclarator", "NStructDeclarator", "NDeclaration", "NCast", "NPointerGroup", "NExpressionGroup", "NFunctionCallArgs", "NNonemptyAbstractDeclarator", "NInitializer", "NStatementExpr", "NEmptyExpression", "NParameterTypeList", "NFunctionDef", "NCompoundStatement", "NParameterDeclaration", "NCommaExpr", "NUnaryExpr", "NLabel", "NPostfixExpr", "NRangeExpr", "NStringSeq", "NInitializerElementLabel", "NLcurlyInitializer", "NAsmAttribute", "NGnuAsmExpr", "NTypeMissing", "Vocabulary", "Whitespace", "Comment", "CPPComment", "NonWhitespace", "a line directive", "DefineExpr", "DefineExpr2", "Space", "LineDirective", "BadStringLiteral", "Escape", "Digit", "LongSuffix", "UnsignedSuffix", "FloatSuffix", "Exponent", "Number", "\"__label__\"", "\"inline\"", "\"typeof\"", "\"__complex\"", "\"__attribute\"", "\"__alignof\"", "\"__real\"", "\"__imag\"" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void buildTokenTypeASTClassMap() {
/* 7441 */     this.tokenTypeToASTClassMap = null;
/*      */   }
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 7445 */     return new long[] { 2L, 0L, 0L };
/*      */   }
/*      */   
/* 7448 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 7450 */     return new long[] { 219902325554800L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7453 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 7455 */     return new long[] { 219902325554802L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7458 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 7460 */     return new long[] { 215504279044128L, 111451082752L, 482110078976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7463 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 7465 */     return new long[] { 1433763162620672L, 0L, 0L };
/*      */   }
/*      */   
/* 7468 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 7470 */     return new long[] { 290271069732864L, 0L, 0L };
/*      */   }
/*      */   
/* 7473 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 7475 */     return new long[] { 8796093021264L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7478 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 7480 */     return new long[] { 219902325554896L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7483 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 7485 */     return new long[] { 219902325529664L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7488 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 7490 */     return new long[] { 3034652092661456L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7493 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 7495 */     return new long[] { 215504279044096L, 0L, 0L };
/*      */   }
/*      */   
/* 7498 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 7500 */     return new long[] { 840026883752544L, 0L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7503 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 7505 */     return new long[] { -4613717915915517966L, 111451082752L, 514322333696L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7508 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 7510 */     return new long[] { 8796092996672L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7513 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 7515 */     return new long[] { 219902325529792L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7518 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 7520 */     return new long[] { 8796092767232L, 0L, 25769803776L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7523 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 7525 */     return new long[] { 2603643534573296L, 0L, 64424509440L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7528 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 7530 */     return new long[] { 512L, 0L, 0L };
/*      */   }
/*      */   
/* 7533 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 7535 */     return new long[] { 778454232465568L, 128630951936L, 482110078976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7538 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 7540 */     return new long[] { 844424930009056L, 137438953471L, 507879882752L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7543 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 7545 */     return new long[] { 567347999932416L, 17179869184L, 0L, 0L };
/*      */   }
/*      */   
/* 7548 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 7550 */     return new long[] { 233096465088544L, 111451082752L, 482110078976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7553 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 7555 */     return new long[] { 215504279044256L, 111451082752L, 482110078976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7558 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */   private static final long[] mk_tokenSet_23() {
/* 7560 */     return new long[] { 826832743964640L, 137438953471L, 507879882752L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7563 */   public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
/*      */   private static final long[] mk_tokenSet_24() {
/* 7565 */     return new long[] { 778454232465824L, 128630951936L, 482110078976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7568 */   public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
/*      */   private static final long[] mk_tokenSet_25() {
/* 7570 */     return new long[] { 8796093022976L, 0L, 0L };
/*      */   }
/*      */   
/* 7573 */   public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
/*      */   private static final long[] mk_tokenSet_26() {
/* 7575 */     return new long[] { 3034652092538080L, 137438952448L, 507879882752L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7578 */   public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
/*      */   private static final long[] mk_tokenSet_27() {
/* 7580 */     return new long[] { 1908752185695456L, 137438952448L, 507879882752L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7583 */   public static final BitSet _tokenSet_27 = new BitSet(mk_tokenSet_27());
/*      */   private static final long[] mk_tokenSet_28() {
/* 7585 */     return new long[] { 3791116092572448L, 268435455L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7588 */   public static final BitSet _tokenSet_28 = new BitSet(mk_tokenSet_28());
/*      */   private static final long[] mk_tokenSet_29() {
/* 7590 */     return new long[] { 3404087999595296L, 0L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7593 */   public static final BitSet _tokenSet_29 = new BitSet(mk_tokenSet_29());
/*      */   private static final long[] mk_tokenSet_30() {
/* 7595 */     return new long[] { 1143492092887040L, 0L, 0L };
/*      */   }
/*      */   
/* 7598 */   public static final BitSet _tokenSet_30 = new BitSet(mk_tokenSet_30());
/*      */   private static final long[] mk_tokenSet_31() {
/* 7600 */     return new long[] { 8796093022464L, 0L, 0L };
/*      */   }
/*      */   
/* 7603 */   public static final BitSet _tokenSet_31 = new BitSet(mk_tokenSet_31());
/*      */   private static final long[] mk_tokenSet_32() {
/* 7605 */     return new long[] { 998356558021120L, 0L, 0L };
/*      */   }
/*      */   
/* 7608 */   public static final BitSet _tokenSet_32 = new BitSet(mk_tokenSet_32());
/*      */   private static final long[] mk_tokenSet_33() {
/* 7610 */     return new long[] { 1073123348709072L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7613 */   public static final BitSet _tokenSet_33 = new BitSet(mk_tokenSet_33());
/*      */   private static final long[] mk_tokenSet_34() {
/* 7615 */     return new long[] { 294669116243968L, 0L, 0L };
/*      */   }
/*      */   
/* 7618 */   public static final BitSet _tokenSet_34 = new BitSet(mk_tokenSet_34());
/*      */   private static final long[] mk_tokenSet_35() {
/* 7620 */     return new long[] { 3307330976349936L, 0L, 64424509440L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7623 */   public static final BitSet _tokenSet_35 = new BitSet(mk_tokenSet_35());
/*      */   private static final long[] mk_tokenSet_36() {
/* 7625 */     return new long[] { 1068725302198784L, 0L, 0L };
/*      */   }
/*      */   
/* 7628 */   public static final BitSet _tokenSet_36 = new BitSet(mk_tokenSet_36());
/*      */   private static final long[] mk_tokenSet_37() {
/* 7630 */     return new long[] { 1068725302329920L, 0L, 0L };
/*      */   }
/*      */   
/* 7633 */   public static final BitSet _tokenSet_37 = new BitSet(mk_tokenSet_37());
/*      */   private static final long[] mk_tokenSet_38() {
/* 7635 */     return new long[] { 774056185954304L, 0L, 0L };
/*      */   }
/*      */   
/* 7638 */   public static final BitSet _tokenSet_38 = new BitSet(mk_tokenSet_38());
/*      */   private static final long[] mk_tokenSet_39() {
/* 7640 */     return new long[] { 2199023255551600L, 111451082752L, 512174850048L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7643 */   public static final BitSet _tokenSet_39 = new BitSet(mk_tokenSet_39());
/*      */   private static final long[] mk_tokenSet_40() {
/* 7645 */     return new long[] { 290271069733376L, 0L, 0L };
/*      */   }
/*      */   
/* 7648 */   public static final BitSet _tokenSet_40 = new BitSet(mk_tokenSet_40());
/*      */   private static final long[] mk_tokenSet_41() {
/* 7650 */     return new long[] { -4615969715729203216L, 111451082752L, 514322333696L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7653 */   public static final BitSet _tokenSet_41 = new BitSet(mk_tokenSet_41());
/*      */   private static final long[] mk_tokenSet_42() {
/* 7655 */     return new long[] { 1073123348708944L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7658 */   public static final BitSet _tokenSet_42 = new BitSet(mk_tokenSet_42());
/*      */   private static final long[] mk_tokenSet_43() {
/* 7660 */     return new long[] { 8796092898368L, 0L, 25769803776L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7663 */   public static final BitSet _tokenSet_43 = new BitSet(mk_tokenSet_43());
/*      */   private static final long[] mk_tokenSet_44() {
/* 7665 */     return new long[] { 1064327255563456L, 0L, 25769803776L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7668 */   public static final BitSet _tokenSet_44 = new BitSet(mk_tokenSet_44());
/*      */   private static final long[] mk_tokenSet_45() {
/* 7670 */     return new long[] { 1108307720674528L, 137438953471L, 507879882752L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7673 */   public static final BitSet _tokenSet_45 = new BitSet(mk_tokenSet_45());
/*      */   private static final long[] mk_tokenSet_46() {
/* 7675 */     return new long[] { 1090715534753392L, 0L, 64424509440L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7678 */   public static final BitSet _tokenSet_46 = new BitSet(mk_tokenSet_46());
/*      */   private static final long[] mk_tokenSet_47() {
/* 7680 */     return new long[] { 1125899906842224L, 0L, 64424509440L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7683 */   public static final BitSet _tokenSet_47 = new BitSet(mk_tokenSet_47());
/*      */   private static final long[] mk_tokenSet_48() {
/* 7685 */     return new long[] { 281474976710656L, 0L, 0L };
/*      */   }
/*      */   
/* 7688 */   public static final BitSet _tokenSet_48 = new BitSet(mk_tokenSet_48());
/*      */   private static final long[] mk_tokenSet_49() {
/* 7690 */     return new long[] { 4398046511232L, 0L, 0L };
/*      */   }
/*      */   
/* 7693 */   public static final BitSet _tokenSet_49 = new BitSet(mk_tokenSet_49());
/*      */   private static final long[] mk_tokenSet_50() {
/* 7695 */     return new long[] { 256L, 0L, 0L };
/*      */   }
/*      */   
/* 7698 */   public static final BitSet _tokenSet_50 = new BitSet(mk_tokenSet_50());
/*      */   private static final long[] mk_tokenSet_51() {
/* 7700 */     return new long[] { 8796092898624L, 0L, 25769803776L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7703 */   public static final BitSet _tokenSet_51 = new BitSet(mk_tokenSet_51());
/*      */   private static final long[] mk_tokenSet_52() {
/* 7705 */     return new long[] { 1090715534630624L, 0L, 60129542144L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7708 */   public static final BitSet _tokenSet_52 = new BitSet(mk_tokenSet_52());
/*      */   private static final long[] mk_tokenSet_53() {
/* 7710 */     return new long[] { 1086317488243232L, 0L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7713 */   public static final BitSet _tokenSet_53 = new BitSet(mk_tokenSet_53());
/*      */   private static final long[] mk_tokenSet_54() {
/* 7715 */     return new long[] { 241892558111264L, 0L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7718 */   public static final BitSet _tokenSet_54 = new BitSet(mk_tokenSet_54());
/*      */   private static final long[] mk_tokenSet_55() {
/* 7720 */     return new long[] { 8796093022720L, 0L, 0L };
/*      */   }
/*      */   
/* 7723 */   public static final BitSet _tokenSet_55 = new BitSet(mk_tokenSet_55());
/*      */   private static final long[] mk_tokenSet_56() {
/* 7725 */     return new long[] { 4494803534349088L, 26843545599L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7728 */   public static final BitSet _tokenSet_56 = new BitSet(mk_tokenSet_56());
/*      */   private static final long[] mk_tokenSet_57() {
/* 7730 */     return new long[] { -431008558088208L, -1L, 549755813887L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7733 */   public static final BitSet _tokenSet_57 = new BitSet(mk_tokenSet_57());
/*      */   private static final long[] mk_tokenSet_58() {
/* 7735 */     return new long[] { 8796093021264L, 0L, 32212254720L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7738 */   public static final BitSet _tokenSet_58 = new BitSet(mk_tokenSet_58());
/*      */   private static final long[] mk_tokenSet_59() {
/* 7740 */     return new long[] { 219902325537856L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7743 */   public static final BitSet _tokenSet_59 = new BitSet(mk_tokenSet_59());
/*      */   private static final long[] mk_tokenSet_60() {
/* 7745 */     return new long[] { 782852278975696L, 0L, 30064771072L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7748 */   public static final BitSet _tokenSet_60 = new BitSet(mk_tokenSet_60());
/*      */   private static final long[] mk_tokenSet_61() {
/* 7750 */     return new long[] { -4002222325104654L, 111451082752L, 514322333696L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7753 */   public static final BitSet _tokenSet_61 = new BitSet(mk_tokenSet_61());
/*      */   private static final long[] mk_tokenSet_62() {
/* 7755 */     return new long[] { -4615974113775713632L, 111451082752L, 482110078976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7758 */   public static final BitSet _tokenSet_62 = new BitSet(mk_tokenSet_62());
/*      */   private static final long[] mk_tokenSet_63() {
/* 7760 */     return new long[] { 800444464897248L, 137438952448L, 507879882752L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7763 */   public static final BitSet _tokenSet_63 = new BitSet(mk_tokenSet_63());
/*      */   private static final long[] mk_tokenSet_64() {
/* 7765 */     return new long[] { -3659174697238544L, 137438953471L, 514322333696L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7768 */   public static final BitSet _tokenSet_64 = new BitSet(mk_tokenSet_64());
/*      */   private static final long[] mk_tokenSet_65() {
/* 7770 */     return new long[] { -4288095348325472L, 111451082752L, 482110078976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7773 */   public static final BitSet _tokenSet_65 = new BitSet(mk_tokenSet_65());
/*      */   private static final long[] mk_tokenSet_66() {
/* 7775 */     return new long[] { -3377699720527886L, 137438953471L, 514322333696L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7778 */   public static final BitSet _tokenSet_66 = new BitSet(mk_tokenSet_66());
/*      */   private static final long[] mk_tokenSet_67() {
/* 7780 */     return new long[] { 826832743964384L, 137438953471L, 507879882752L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7783 */   public static final BitSet _tokenSet_67 = new BitSet(mk_tokenSet_67());
/*      */   private static final long[] mk_tokenSet_68() {
/* 7785 */     return new long[] { 3720747348394784L, 1023L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7788 */   public static final BitSet _tokenSet_68 = new BitSet(mk_tokenSet_68());
/*      */   private static final long[] mk_tokenSet_69() {
/* 7790 */     return new long[] { 3720747348394784L, 2047L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7793 */   public static final BitSet _tokenSet_69 = new BitSet(mk_tokenSet_69());
/*      */   private static final long[] mk_tokenSet_70() {
/* 7795 */     return new long[] { 4499201580860384L, 137438953471L, 516469817344L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7798 */   public static final BitSet _tokenSet_70 = new BitSet(mk_tokenSet_70());
/*      */   private static final long[] mk_tokenSet_71() {
/* 7800 */     return new long[] { 299067162755072L, 68719476736L, 0L, 0L };
/*      */   }
/*      */   
/* 7803 */   public static final BitSet _tokenSet_71 = new BitSet(mk_tokenSet_71());
/*      */   private static final long[] mk_tokenSet_72() {
/* 7805 */     return new long[] { 3791116092572448L, 68987912191L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7808 */   public static final BitSet _tokenSet_72 = new BitSet(mk_tokenSet_72());
/*      */   private static final long[] mk_tokenSet_73() {
/* 7810 */     return new long[] { 307863255777280L, 0L, 0L };
/*      */   }
/*      */   
/* 7813 */   public static final BitSet _tokenSet_73 = new BitSet(mk_tokenSet_73());
/*      */   private static final long[] mk_tokenSet_74() {
/* 7815 */     return new long[] { 3720747348394784L, 4095L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7818 */   public static final BitSet _tokenSet_74 = new BitSet(mk_tokenSet_74());
/*      */   private static final long[] mk_tokenSet_75() {
/* 7820 */     return new long[] { 3720747348394784L, 8191L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7823 */   public static final BitSet _tokenSet_75 = new BitSet(mk_tokenSet_75());
/*      */   private static final long[] mk_tokenSet_76() {
/* 7825 */     return new long[] { 3720747348394784L, 16383L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7828 */   public static final BitSet _tokenSet_76 = new BitSet(mk_tokenSet_76());
/*      */   private static final long[] mk_tokenSet_77() {
/* 7830 */     return new long[] { 3720747348394784L, 32767L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7833 */   public static final BitSet _tokenSet_77 = new BitSet(mk_tokenSet_77());
/*      */   private static final long[] mk_tokenSet_78() {
/* 7835 */     return new long[] { 3720747348394784L, 65535L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7838 */   public static final BitSet _tokenSet_78 = new BitSet(mk_tokenSet_78());
/*      */   private static final long[] mk_tokenSet_79() {
/* 7840 */     return new long[] { 3720747348394784L, 262143L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7843 */   public static final BitSet _tokenSet_79 = new BitSet(mk_tokenSet_79());
/*      */   private static final long[] mk_tokenSet_80() {
/* 7845 */     return new long[] { 3720747348394784L, 4194303L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7848 */   public static final BitSet _tokenSet_80 = new BitSet(mk_tokenSet_80());
/*      */   private static final long[] mk_tokenSet_81() {
/* 7850 */     return new long[] { 3720747348394784L, 16777215L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7853 */   public static final BitSet _tokenSet_81 = new BitSet(mk_tokenSet_81());
/*      */   private static final long[] mk_tokenSet_82() {
/* 7855 */     return new long[] { 70368744177664L, 201326592L, 0L, 0L };
/*      */   }
/*      */   
/* 7858 */   public static final BitSet _tokenSet_82 = new BitSet(mk_tokenSet_82());
/*      */   private static final long[] mk_tokenSet_83() {
/* 7860 */     return new long[] { 3720747348394784L, 67108863L, 34359738368L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 7863 */   public static final BitSet _tokenSet_83 = new BitSet(mk_tokenSet_83());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/GnuCParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */