/*      */ package com.jogamp.gluegen.cgram;
/*      */ 
/*      */ import antlr.ANTLRHashString;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StdCLexer
/*      */   extends CharScanner
/*      */   implements STDCTokenTypes, TokenStream
/*      */ {
/*   40 */   LineObject lineObject = new LineObject();
/*   41 */   String originalSource = "";
/*   42 */   PreprocessorInfoChannel preprocessorInfoChannel = new PreprocessorInfoChannel();
/*   43 */   int tokenNumber = 0;
/*      */   boolean countingTokens = true;
/*   45 */   int deferredLineCount = 0;
/*      */ 
/*      */   
/*      */   public void setCountingTokens(boolean paramBoolean) {
/*   49 */     this.countingTokens = paramBoolean;
/*   50 */     if (this.countingTokens) {
/*   51 */       this.tokenNumber = 0;
/*      */     } else {
/*      */       
/*   54 */       this.tokenNumber = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOriginalSource(String paramString) {
/*   60 */     this.originalSource = paramString;
/*   61 */     this.lineObject.setSource(paramString);
/*      */   }
/*      */   
/*      */   public void setSource(String paramString) {
/*   65 */     this.lineObject.setSource(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public PreprocessorInfoChannel getPreprocessorInfoChannel() {
/*   70 */     return this.preprocessorInfoChannel;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPreprocessingDirective(String paramString) {
/*   75 */     this.preprocessorInfoChannel.addLineForTokenNumber(paramString, new Integer(this.tokenNumber));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDefine(String paramString1, String paramString2) {}
/*      */ 
/*      */   
/*      */   protected Token makeToken(int paramInt) {
/*   84 */     if (paramInt != -1 && this.countingTokens) {
/*   85 */       this.tokenNumber++;
/*      */     }
/*   87 */     CToken cToken = (CToken)super.makeToken(paramInt);
/*   88 */     cToken.setLine(this.lineObject.line);
/*   89 */     cToken.setSource(this.lineObject.source);
/*   90 */     cToken.setTokenNumber(this.tokenNumber);
/*      */     
/*   92 */     this.lineObject.line += this.deferredLineCount;
/*   93 */     this.deferredLineCount = 0;
/*   94 */     return (Token)cToken;
/*      */   }
/*      */   
/*      */   public void deferredNewline() {
/*   98 */     this.deferredLineCount++;
/*      */   }
/*      */   
/*      */   public void newline() {
/*  102 */     this.lineObject.newline();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StdCLexer(InputStream paramInputStream) {
/*  111 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public StdCLexer(Reader paramReader) {
/*  114 */     this((InputBuffer)new CharBuffer(paramReader));
/*      */   }
/*      */   public StdCLexer(InputBuffer paramInputBuffer) {
/*  117 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public StdCLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  120 */     super(paramLexerSharedInputState);
/*  121 */     this.caseSensitiveLiterals = true;
/*  122 */     setCaseSensitive(true);
/*  123 */     this.literals = new Hashtable<>();
/*  124 */     this.literals.put(new ANTLRHashString("intptr_t", this), new Integer(39));
/*  125 */     this.literals.put(new ANTLRHashString("extern", this), new Integer(15));
/*  126 */     this.literals.put(new ANTLRHashString("case", this), new Integer(59));
/*  127 */     this.literals.put(new ANTLRHashString("short", this), new Integer(20));
/*  128 */     this.literals.put(new ANTLRHashString("break", this), new Integer(57));
/*  129 */     this.literals.put(new ANTLRHashString("while", this), new Integer(52));
/*  130 */     this.literals.put(new ANTLRHashString("uint32_t", this), new Integer(34));
/*  131 */     this.literals.put(new ANTLRHashString("int16_t", this), new Integer(29));
/*  132 */     this.literals.put(new ANTLRHashString("ptrdiff_t", this), new Integer(38));
/*  133 */     this.literals.put(new ANTLRHashString("unsigned", this), new Integer(26));
/*  134 */     this.literals.put(new ANTLRHashString("const", this), new Integer(17));
/*  135 */     this.literals.put(new ANTLRHashString("float", this), new Integer(23));
/*  136 */     this.literals.put(new ANTLRHashString("return", this), new Integer(58));
/*  137 */     this.literals.put(new ANTLRHashString("int64_t", this), new Integer(36));
/*  138 */     this.literals.put(new ANTLRHashString("sizeof", this), new Integer(94));
/*  139 */     this.literals.put(new ANTLRHashString("size_t", this), new Integer(40));
/*  140 */     this.literals.put(new ANTLRHashString("do", this), new Integer(53));
/*  141 */     this.literals.put(new ANTLRHashString("typedef", this), new Integer(4));
/*  142 */     this.literals.put(new ANTLRHashString("uint16_t", this), new Integer(30));
/*  143 */     this.literals.put(new ANTLRHashString("if", this), new Integer(61));
/*  144 */     this.literals.put(new ANTLRHashString("__int32", this), new Integer(31));
/*  145 */     this.literals.put(new ANTLRHashString("double", this), new Integer(24));
/*  146 */     this.literals.put(new ANTLRHashString("volatile", this), new Integer(6));
/*  147 */     this.literals.put(new ANTLRHashString("union", this), new Integer(11));
/*  148 */     this.literals.put(new ANTLRHashString("register", this), new Integer(14));
/*  149 */     this.literals.put(new ANTLRHashString("auto", this), new Integer(13));
/*  150 */     this.literals.put(new ANTLRHashString("goto", this), new Integer(55));
/*  151 */     this.literals.put(new ANTLRHashString("enum", this), new Integer(12));
/*  152 */     this.literals.put(new ANTLRHashString("int", this), new Integer(21));
/*  153 */     this.literals.put(new ANTLRHashString("for", this), new Integer(54));
/*  154 */     this.literals.put(new ANTLRHashString("int32_t", this), new Integer(32));
/*  155 */     this.literals.put(new ANTLRHashString("uint64_t", this), new Integer(37));
/*  156 */     this.literals.put(new ANTLRHashString("char", this), new Integer(19));
/*  157 */     this.literals.put(new ANTLRHashString("default", this), new Integer(60));
/*  158 */     this.literals.put(new ANTLRHashString("static", this), new Integer(16));
/*  159 */     this.literals.put(new ANTLRHashString("int8_t", this), new Integer(27));
/*  160 */     this.literals.put(new ANTLRHashString("uint8_t", this), new Integer(28));
/*  161 */     this.literals.put(new ANTLRHashString("continue", this), new Integer(56));
/*  162 */     this.literals.put(new ANTLRHashString("struct", this), new Integer(10));
/*  163 */     this.literals.put(new ANTLRHashString("__int64", this), new Integer(35));
/*  164 */     this.literals.put(new ANTLRHashString("signed", this), new Integer(25));
/*  165 */     this.literals.put(new ANTLRHashString("else", this), new Integer(62));
/*  166 */     this.literals.put(new ANTLRHashString("uintptr_t", this), new Integer(41));
/*  167 */     this.literals.put(new ANTLRHashString("void", this), new Integer(18));
/*  168 */     this.literals.put(new ANTLRHashString("wchar_t", this), new Integer(33));
/*  169 */     this.literals.put(new ANTLRHashString("switch", this), new Integer(63));
/*  170 */     this.literals.put(new ANTLRHashString("long", this), new Integer(22));
/*  171 */     this.literals.put(new ANTLRHashString("asm", this), new Integer(5));
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  175 */     Token token = null;
/*      */     
/*      */     while (true) {
/*  178 */       Object object = null;
/*  179 */       int i = 0;
/*  180 */       resetText();
/*      */       
/*      */       try {
/*  183 */         switch (LA(1)) {
/*      */           
/*      */           case ':':
/*  186 */             mCOLON(true);
/*  187 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ',':
/*  192 */             mCOMMA(true);
/*  193 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '?':
/*  198 */             mQUESTION(true);
/*  199 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ';':
/*  204 */             mSEMI(true);
/*  205 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*  210 */             mRPAREN(true);
/*  211 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '[':
/*  216 */             mLBRACKET(true);
/*  217 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ']':
/*  222 */             mRBRACKET(true);
/*  223 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '{':
/*  228 */             mLCURLY(true);
/*  229 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '}':
/*  234 */             mRCURLY(true);
/*  235 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '~':
/*  240 */             mBNOT(true);
/*  241 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '#':
/*  246 */             mPREPROC_DIRECTIVE(true);
/*  247 */             token = this._returnToken; break;
/*      */           case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/*  265 */             mID(true);
/*  266 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '"':
/*  271 */             mStringLiteral(true);
/*  272 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\'':
/*  277 */             mCharLiteral(true);
/*  278 */             token = this._returnToken;
/*      */             break;
/*      */           
/*      */           default:
/*  282 */             if (LA(1) == '>' && LA(2) == '>' && LA(3) == '=') {
/*  283 */               mRSHIFT_ASSIGN(true);
/*  284 */               token = this._returnToken; break;
/*      */             } 
/*  286 */             if (LA(1) == '<' && LA(2) == '<' && LA(3) == '=') {
/*  287 */               mLSHIFT_ASSIGN(true);
/*  288 */               token = this._returnToken; break;
/*      */             } 
/*  290 */             if (LA(1) == '-' && LA(2) == '>') {
/*  291 */               mPTR(true);
/*  292 */               token = this._returnToken; break;
/*      */             } 
/*  294 */             if (LA(1) == '=' && LA(2) == '=') {
/*  295 */               mEQUAL(true);
/*  296 */               token = this._returnToken; break;
/*      */             } 
/*  298 */             if (LA(1) == '!' && LA(2) == '=') {
/*  299 */               mNOT_EQUAL(true);
/*  300 */               token = this._returnToken; break;
/*      */             } 
/*  302 */             if (LA(1) == '<' && LA(2) == '=') {
/*  303 */               mLTE(true);
/*  304 */               token = this._returnToken; break;
/*      */             } 
/*  306 */             if (LA(1) == '>' && LA(2) == '=') {
/*  307 */               mGTE(true);
/*  308 */               token = this._returnToken; break;
/*      */             } 
/*  310 */             if (LA(1) == '/' && LA(2) == '=') {
/*  311 */               mDIV_ASSIGN(true);
/*  312 */               token = this._returnToken; break;
/*      */             } 
/*  314 */             if (LA(1) == '+' && LA(2) == '=') {
/*  315 */               mPLUS_ASSIGN(true);
/*  316 */               token = this._returnToken; break;
/*      */             } 
/*  318 */             if (LA(1) == '+' && LA(2) == '+') {
/*  319 */               mINC(true);
/*  320 */               token = this._returnToken; break;
/*      */             } 
/*  322 */             if (LA(1) == '-' && LA(2) == '=') {
/*  323 */               mMINUS_ASSIGN(true);
/*  324 */               token = this._returnToken; break;
/*      */             } 
/*  326 */             if (LA(1) == '-' && LA(2) == '-') {
/*  327 */               mDEC(true);
/*  328 */               token = this._returnToken; break;
/*      */             } 
/*  330 */             if (LA(1) == '*' && LA(2) == '=') {
/*  331 */               mSTAR_ASSIGN(true);
/*  332 */               token = this._returnToken; break;
/*      */             } 
/*  334 */             if (LA(1) == '%' && LA(2) == '=') {
/*  335 */               mMOD_ASSIGN(true);
/*  336 */               token = this._returnToken; break;
/*      */             } 
/*  338 */             if (LA(1) == '>' && LA(2) == '>') {
/*  339 */               mRSHIFT(true);
/*  340 */               token = this._returnToken; break;
/*      */             } 
/*  342 */             if (LA(1) == '<' && LA(2) == '<') {
/*  343 */               mLSHIFT(true);
/*  344 */               token = this._returnToken; break;
/*      */             } 
/*  346 */             if (LA(1) == '&' && LA(2) == '&') {
/*  347 */               mLAND(true);
/*  348 */               token = this._returnToken; break;
/*      */             } 
/*  350 */             if (LA(1) == '|' && LA(2) == '|') {
/*  351 */               mLOR(true);
/*  352 */               token = this._returnToken; break;
/*      */             } 
/*  354 */             if (LA(1) == '&' && LA(2) == '=') {
/*  355 */               mBAND_ASSIGN(true);
/*  356 */               token = this._returnToken; break;
/*      */             } 
/*  358 */             if (LA(1) == '|' && LA(2) == '=') {
/*  359 */               mBOR_ASSIGN(true);
/*  360 */               token = this._returnToken; break;
/*      */             } 
/*  362 */             if (LA(1) == '^' && LA(2) == '=') {
/*  363 */               mBXOR_ASSIGN(true);
/*  364 */               token = this._returnToken; break;
/*      */             } 
/*  366 */             if (LA(1) == '/' && LA(2) == '*') {
/*  367 */               mComment(true);
/*  368 */               token = this._returnToken; break;
/*      */             } 
/*  370 */             if (LA(1) == '/' && LA(2) == '/') {
/*  371 */               mCPPComment(true);
/*  372 */               token = this._returnToken; break;
/*      */             } 
/*  374 */             if (LA(1) == '=') {
/*  375 */               mASSIGN(true);
/*  376 */               token = this._returnToken; break;
/*      */             } 
/*  378 */             if (LA(1) == '(') {
/*  379 */               mLPAREN(true);
/*  380 */               token = this._returnToken; break;
/*      */             } 
/*  382 */             if (LA(1) == '<') {
/*  383 */               mLT(true);
/*  384 */               token = this._returnToken; break;
/*      */             } 
/*  386 */             if (LA(1) == '>') {
/*  387 */               mGT(true);
/*  388 */               token = this._returnToken; break;
/*      */             } 
/*  390 */             if (LA(1) == '/') {
/*  391 */               mDIV(true);
/*  392 */               token = this._returnToken; break;
/*      */             } 
/*  394 */             if (LA(1) == '+') {
/*  395 */               mPLUS(true);
/*  396 */               token = this._returnToken; break;
/*      */             } 
/*  398 */             if (LA(1) == '-') {
/*  399 */               mMINUS(true);
/*  400 */               token = this._returnToken; break;
/*      */             } 
/*  402 */             if (LA(1) == '*') {
/*  403 */               mSTAR(true);
/*  404 */               token = this._returnToken; break;
/*      */             } 
/*  406 */             if (LA(1) == '%') {
/*  407 */               mMOD(true);
/*  408 */               token = this._returnToken; break;
/*      */             } 
/*  410 */             if (LA(1) == '!') {
/*  411 */               mLNOT(true);
/*  412 */               token = this._returnToken; break;
/*      */             } 
/*  414 */             if (LA(1) == '&') {
/*  415 */               mBAND(true);
/*  416 */               token = this._returnToken; break;
/*      */             } 
/*  418 */             if (LA(1) == '|') {
/*  419 */               mBOR(true);
/*  420 */               token = this._returnToken; break;
/*      */             } 
/*  422 */             if (LA(1) == '^') {
/*  423 */               mBXOR(true);
/*  424 */               token = this._returnToken; break;
/*      */             } 
/*  426 */             if (_tokenSet_0.member(LA(1))) {
/*  427 */               mWhitespace(true);
/*  428 */               token = this._returnToken; break;
/*      */             } 
/*  430 */             if (_tokenSet_1.member(LA(1))) {
/*  431 */               mDefineExpr(true);
/*  432 */               token = this._returnToken; break;
/*      */             } 
/*  434 */             if (_tokenSet_2.member(LA(1))) {
/*  435 */               mDefineExpr2(true);
/*  436 */               token = this._returnToken; break;
/*      */             } 
/*  438 */             if (_tokenSet_2.member(LA(1))) {
/*  439 */               mNumber(true);
/*  440 */               token = this._returnToken;
/*      */               break;
/*      */             } 
/*  443 */             if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); break; }
/*  444 */              throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */         
/*  447 */         if (this._returnToken == null)
/*  448 */           continue;  i = this._returnToken.getType();
/*  449 */         this._returnToken.setType(i);
/*  450 */         return this._returnToken;
/*      */       }
/*  452 */       catch (RecognitionException recognitionException) {
/*  453 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  456 */       catch (CharStreamException charStreamException) {
/*  457 */         if (charStreamException instanceof CharStreamIOException) {
/*  458 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  461 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void mVocabulary(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  468 */     Token token = null; int i = this.text.length();
/*  469 */     char c = '';
/*      */ 
/*      */     
/*  472 */     matchRange('\003', 'ÿ');
/*  473 */     if (paramBoolean && token == null && c != -1) {
/*  474 */       token = makeToken(c);
/*  475 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  477 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  481 */     Token token = null; int i = this.text.length();
/*  482 */     byte b = 45;
/*      */ 
/*      */     
/*  485 */     match('=');
/*  486 */     if (paramBoolean && token == null && b != -1) {
/*  487 */       token = makeToken(b);
/*  488 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  490 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOLON(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  494 */     Token token = null; int i = this.text.length();
/*  495 */     byte b = 44;
/*      */ 
/*      */     
/*  498 */     match(':');
/*  499 */     if (paramBoolean && token == null && b != -1) {
/*  500 */       token = makeToken(b);
/*  501 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  503 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOMMA(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  507 */     Token token = null; int i = this.text.length();
/*  508 */     byte b = 43;
/*      */ 
/*      */     
/*  511 */     match(',');
/*  512 */     if (paramBoolean && token == null && b != -1) {
/*  513 */       token = makeToken(b);
/*  514 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  516 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mQUESTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  520 */     Token token = null; int i = this.text.length();
/*  521 */     byte b = 74;
/*      */ 
/*      */     
/*  524 */     match('?');
/*  525 */     if (paramBoolean && token == null && b != -1) {
/*  526 */       token = makeToken(b);
/*  527 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  529 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSEMI(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  533 */     Token token = null; int i = this.text.length();
/*  534 */     byte b = 9;
/*      */ 
/*      */     
/*  537 */     match(';');
/*  538 */     if (paramBoolean && token == null && b != -1) {
/*  539 */       token = makeToken(b);
/*  540 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  542 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPTR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  546 */     Token token = null; int i = this.text.length();
/*  547 */     byte b = 97;
/*      */ 
/*      */     
/*  550 */     match("->");
/*  551 */     if (paramBoolean && token == null && b != -1) {
/*  552 */       token = makeToken(b);
/*  553 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  555 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDOT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  559 */     Token token = null; int i = this.text.length();
/*  560 */     byte b = 98;
/*      */ 
/*      */     
/*  563 */     if (paramBoolean && token == null && b != -1) {
/*  564 */       token = makeToken(b);
/*  565 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  567 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mVARARGS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  571 */     Token token = null; int i = this.text.length();
/*  572 */     byte b = 51;
/*      */ 
/*      */     
/*  575 */     if (paramBoolean && token == null && b != -1) {
/*  576 */       token = makeToken(b);
/*  577 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  579 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  583 */     Token token = null; int i = this.text.length();
/*  584 */     byte b = 47;
/*      */ 
/*      */     
/*  587 */     match('(');
/*  588 */     if (paramBoolean && token == null && b != -1) {
/*  589 */       token = makeToken(b);
/*  590 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  592 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  596 */     Token token = null; int i = this.text.length();
/*  597 */     byte b = 48;
/*      */ 
/*      */     
/*  600 */     match(')');
/*  601 */     if (paramBoolean && token == null && b != -1) {
/*  602 */       token = makeToken(b);
/*  603 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  605 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLBRACKET(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  609 */     Token token = null; int i = this.text.length();
/*  610 */     byte b = 49;
/*      */ 
/*      */     
/*  613 */     match('[');
/*  614 */     if (paramBoolean && token == null && b != -1) {
/*  615 */       token = makeToken(b);
/*  616 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  618 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRBRACKET(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  622 */     Token token = null; int i = this.text.length();
/*  623 */     byte b = 50;
/*      */ 
/*      */     
/*  626 */     match(']');
/*  627 */     if (paramBoolean && token == null && b != -1) {
/*  628 */       token = makeToken(b);
/*  629 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  631 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLCURLY(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  635 */     Token token = null; int i = this.text.length();
/*  636 */     byte b = 7;
/*      */ 
/*      */     
/*  639 */     match('{');
/*  640 */     if (paramBoolean && token == null && b != -1) {
/*  641 */       token = makeToken(b);
/*  642 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  644 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRCURLY(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  648 */     Token token = null; int i = this.text.length();
/*  649 */     byte b = 8;
/*      */ 
/*      */     
/*  652 */     match('}');
/*  653 */     if (paramBoolean && token == null && b != -1) {
/*  654 */       token = makeToken(b);
/*  655 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  657 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mEQUAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  661 */     Token token = null; int i = this.text.length();
/*  662 */     byte b = 80;
/*      */ 
/*      */     
/*  665 */     match("==");
/*  666 */     if (paramBoolean && token == null && b != -1) {
/*  667 */       token = makeToken(b);
/*  668 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  670 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mNOT_EQUAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  674 */     Token token = null; int i = this.text.length();
/*  675 */     byte b = 81;
/*      */ 
/*      */     
/*  678 */     match("!=");
/*  679 */     if (paramBoolean && token == null && b != -1) {
/*  680 */       token = makeToken(b);
/*  681 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  683 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLTE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  687 */     Token token = null; int i = this.text.length();
/*  688 */     byte b = 83;
/*      */ 
/*      */     
/*  691 */     match("<=");
/*  692 */     if (paramBoolean && token == null && b != -1) {
/*  693 */       token = makeToken(b);
/*  694 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  696 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  700 */     Token token = null; int i = this.text.length();
/*  701 */     byte b = 82;
/*      */ 
/*      */     
/*  704 */     match("<");
/*  705 */     if (paramBoolean && token == null && b != -1) {
/*  706 */       token = makeToken(b);
/*  707 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  709 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mGTE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  713 */     Token token = null; int i = this.text.length();
/*  714 */     byte b = 85;
/*      */ 
/*      */     
/*  717 */     match(">=");
/*  718 */     if (paramBoolean && token == null && b != -1) {
/*  719 */       token = makeToken(b);
/*  720 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  722 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mGT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  726 */     Token token = null; int i = this.text.length();
/*  727 */     byte b = 84;
/*      */ 
/*      */     
/*  730 */     match(">");
/*  731 */     if (paramBoolean && token == null && b != -1) {
/*  732 */       token = makeToken(b);
/*  733 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  735 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDIV(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  739 */     Token token = null; int i = this.text.length();
/*  740 */     byte b = 90;
/*      */ 
/*      */     
/*  743 */     match('/');
/*  744 */     if (paramBoolean && token == null && b != -1) {
/*  745 */       token = makeToken(b);
/*  746 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  748 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDIV_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  752 */     Token token = null; int i = this.text.length();
/*  753 */     byte b = 64;
/*      */ 
/*      */     
/*  756 */     match("/=");
/*  757 */     if (paramBoolean && token == null && b != -1) {
/*  758 */       token = makeToken(b);
/*  759 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  761 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPLUS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  765 */     Token token = null; int i = this.text.length();
/*  766 */     byte b = 88;
/*      */ 
/*      */     
/*  769 */     match('+');
/*  770 */     if (paramBoolean && token == null && b != -1) {
/*  771 */       token = makeToken(b);
/*  772 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  774 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPLUS_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  778 */     Token token = null; int i = this.text.length();
/*  779 */     byte b = 65;
/*      */ 
/*      */     
/*  782 */     match("+=");
/*  783 */     if (paramBoolean && token == null && b != -1) {
/*  784 */       token = makeToken(b);
/*  785 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  787 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mINC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  791 */     Token token = null; int i = this.text.length();
/*  792 */     byte b = 92;
/*      */ 
/*      */     
/*  795 */     match("++");
/*  796 */     if (paramBoolean && token == null && b != -1) {
/*  797 */       token = makeToken(b);
/*  798 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  800 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMINUS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  804 */     Token token = null; int i = this.text.length();
/*  805 */     byte b = 89;
/*      */ 
/*      */     
/*  808 */     match('-');
/*  809 */     if (paramBoolean && token == null && b != -1) {
/*  810 */       token = makeToken(b);
/*  811 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  813 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMINUS_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  817 */     Token token = null; int i = this.text.length();
/*  818 */     byte b = 66;
/*      */ 
/*      */     
/*  821 */     match("-=");
/*  822 */     if (paramBoolean && token == null && b != -1) {
/*  823 */       token = makeToken(b);
/*  824 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  826 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDEC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  830 */     Token token = null; int i = this.text.length();
/*  831 */     byte b = 93;
/*      */ 
/*      */     
/*  834 */     match("--");
/*  835 */     if (paramBoolean && token == null && b != -1) {
/*  836 */       token = makeToken(b);
/*  837 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  839 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTAR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  843 */     Token token = null; int i = this.text.length();
/*  844 */     byte b = 46;
/*      */ 
/*      */     
/*  847 */     match('*');
/*  848 */     if (paramBoolean && token == null && b != -1) {
/*  849 */       token = makeToken(b);
/*  850 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  852 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTAR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  856 */     Token token = null; int i = this.text.length();
/*  857 */     byte b = 67;
/*      */ 
/*      */     
/*  860 */     match("*=");
/*  861 */     if (paramBoolean && token == null && b != -1) {
/*  862 */       token = makeToken(b);
/*  863 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  865 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMOD(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  869 */     Token token = null; int i = this.text.length();
/*  870 */     byte b = 91;
/*      */ 
/*      */     
/*  873 */     match('%');
/*  874 */     if (paramBoolean && token == null && b != -1) {
/*  875 */       token = makeToken(b);
/*  876 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  878 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMOD_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  882 */     Token token = null; int i = this.text.length();
/*  883 */     byte b = 68;
/*      */ 
/*      */     
/*  886 */     match("%=");
/*  887 */     if (paramBoolean && token == null && b != -1) {
/*  888 */       token = makeToken(b);
/*  889 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  891 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRSHIFT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  895 */     Token token = null; int i = this.text.length();
/*  896 */     byte b = 87;
/*      */ 
/*      */     
/*  899 */     match(">>");
/*  900 */     if (paramBoolean && token == null && b != -1) {
/*  901 */       token = makeToken(b);
/*  902 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  904 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRSHIFT_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  908 */     Token token = null; int i = this.text.length();
/*  909 */     byte b = 69;
/*      */ 
/*      */     
/*  912 */     match(">>=");
/*  913 */     if (paramBoolean && token == null && b != -1) {
/*  914 */       token = makeToken(b);
/*  915 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  917 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLSHIFT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  921 */     Token token = null; int i = this.text.length();
/*  922 */     byte b = 86;
/*      */ 
/*      */     
/*  925 */     match("<<");
/*  926 */     if (paramBoolean && token == null && b != -1) {
/*  927 */       token = makeToken(b);
/*  928 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  930 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLSHIFT_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  934 */     Token token = null; int i = this.text.length();
/*  935 */     byte b = 70;
/*      */ 
/*      */     
/*  938 */     match("<<=");
/*  939 */     if (paramBoolean && token == null && b != -1) {
/*  940 */       token = makeToken(b);
/*  941 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  943 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLAND(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  947 */     Token token = null; int i = this.text.length();
/*  948 */     byte b = 76;
/*      */ 
/*      */     
/*  951 */     match("&&");
/*  952 */     if (paramBoolean && token == null && b != -1) {
/*  953 */       token = makeToken(b);
/*  954 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  956 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLNOT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  960 */     Token token = null; int i = this.text.length();
/*  961 */     byte b = 96;
/*      */ 
/*      */     
/*  964 */     match('!');
/*  965 */     if (paramBoolean && token == null && b != -1) {
/*  966 */       token = makeToken(b);
/*  967 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  969 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  973 */     Token token = null; int i = this.text.length();
/*  974 */     byte b = 75;
/*      */ 
/*      */     
/*  977 */     match("||");
/*  978 */     if (paramBoolean && token == null && b != -1) {
/*  979 */       token = makeToken(b);
/*  980 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  982 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBAND(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  986 */     Token token = null; int i = this.text.length();
/*  987 */     byte b = 79;
/*      */ 
/*      */     
/*  990 */     match('&');
/*  991 */     if (paramBoolean && token == null && b != -1) {
/*  992 */       token = makeToken(b);
/*  993 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  995 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBAND_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  999 */     Token token = null; int i = this.text.length();
/* 1000 */     byte b = 71;
/*      */ 
/*      */     
/* 1003 */     match("&=");
/* 1004 */     if (paramBoolean && token == null && b != -1) {
/* 1005 */       token = makeToken(b);
/* 1006 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1008 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBNOT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1012 */     Token token = null; int i = this.text.length();
/* 1013 */     byte b = 95;
/*      */ 
/*      */     
/* 1016 */     match('~');
/* 1017 */     if (paramBoolean && token == null && b != -1) {
/* 1018 */       token = makeToken(b);
/* 1019 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1021 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1025 */     Token token = null; int i = this.text.length();
/* 1026 */     byte b = 77;
/*      */ 
/*      */     
/* 1029 */     match('|');
/* 1030 */     if (paramBoolean && token == null && b != -1) {
/* 1031 */       token = makeToken(b);
/* 1032 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1034 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBOR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1038 */     Token token = null; int i = this.text.length();
/* 1039 */     byte b = 72;
/*      */ 
/*      */     
/* 1042 */     match("|=");
/* 1043 */     if (paramBoolean && token == null && b != -1) {
/* 1044 */       token = makeToken(b);
/* 1045 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1047 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBXOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1051 */     Token token = null; int i = this.text.length();
/* 1052 */     byte b = 78;
/*      */ 
/*      */     
/* 1055 */     match('^');
/* 1056 */     if (paramBoolean && token == null && b != -1) {
/* 1057 */       token = makeToken(b);
/* 1058 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1060 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBXOR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1064 */     Token token = null; int i = this.text.length();
/* 1065 */     byte b = 73;
/*      */ 
/*      */     
/* 1068 */     match("^=");
/* 1069 */     if (paramBoolean && token == null && b != -1) {
/* 1070 */       token = makeToken(b);
/* 1071 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1073 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mWhitespace(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1077 */     Token token = null; int i = this.text.length();
/* 1078 */     short s = 142;
/*      */ 
/*      */ 
/*      */     
/* 1082 */     if (LA(1) == '\r' && LA(2) == '\n') {
/* 1083 */       match("\r\n");
/* 1084 */       if (this.inputState.guessing == 0) {
/* 1085 */         newline();
/*      */       }
/*      */     }
/* 1088 */     else if (_tokenSet_3.member(LA(1))) {
/*      */       
/* 1090 */       switch (LA(1)) { case '\003': case '\004': case '\005':
/*      */         case '\006':
/*      */         case '\007':
/*      */         case '\b':
/* 1094 */           matchRange('\003', '\b');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\t':
/* 1099 */           match('\t');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\013':
/* 1104 */           match('\013');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\f':
/* 1109 */           match('\f'); break;
/*      */         case '\016': case '\017': case '\020': case '\021': case '\022': case '\023': case '\024': case '\025': case '\026': case '\027': case '\030':
/*      */         case '\031':
/*      */         case '\032':
/*      */         case '\033':
/*      */         case '\034':
/*      */         case '\035':
/*      */         case '\036':
/*      */         case '\037':
/* 1118 */           matchRange('\016', '\037');
/*      */           break;
/*      */ 
/*      */         
/*      */         case ' ':
/* 1123 */           match(' ');
/*      */           break;
/*      */         
/*      */         default:
/* 1127 */           if (LA(1) >= '' && LA(1) <= 'ÿ') {
/* 1128 */             matchRange('', 'ÿ');
/*      */             break;
/*      */           } 
/* 1131 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1136 */     } else if (LA(1) == '\n' || LA(1) == '\r') {
/*      */       
/* 1138 */       switch (LA(1)) {
/*      */         
/*      */         case '\n':
/* 1141 */           match('\n');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\r':
/* 1146 */           match('\r');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1151 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */       
/* 1155 */       if (this.inputState.guessing == 0) {
/* 1156 */         newline();
/*      */       }
/*      */     } else {
/*      */       
/* 1160 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1164 */     if (this.inputState.guessing == 0) {
/* 1165 */       s = -1;
/*      */     }
/* 1167 */     if (paramBoolean && token == null && s != -1) {
/* 1168 */       token = makeToken(s);
/* 1169 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1171 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mComment(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1175 */     Token token = null; int i = this.text.length();
/* 1176 */     short s = 143;
/*      */ 
/*      */     
/* 1179 */     match("/*");
/*      */ 
/*      */     
/*      */     while (true) {
/* 1183 */       if (LA(1) == '*' && LA(2) >= '\000' && LA(2) <= 'ÿ' && LA(3) >= '\000' && LA(3) <= 'ÿ' && LA(2) != '/') {
/* 1184 */         match('*'); continue;
/*      */       } 
/* 1186 */       if (LA(1) == '\r' && LA(2) == '\n' && LA(3) >= '\000' && LA(3) <= 'ÿ') {
/* 1187 */         match("\r\n");
/* 1188 */         if (this.inputState.guessing == 0)
/* 1189 */           deferredNewline(); 
/*      */         continue;
/*      */       } 
/* 1192 */       if ((LA(1) == '\n' || LA(1) == '\r') && LA(2) >= '\000' && LA(2) <= 'ÿ' && LA(3) >= '\000' && LA(3) <= 'ÿ') {
/*      */         
/* 1194 */         switch (LA(1)) {
/*      */           
/*      */           case '\r':
/* 1197 */             match('\r');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\n':
/* 1202 */             match('\n');
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1207 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */         
/* 1211 */         if (this.inputState.guessing == 0)
/* 1212 */           deferredNewline(); 
/*      */         continue;
/*      */       } 
/* 1215 */       if (_tokenSet_4.member(LA(1))) {
/*      */         
/* 1217 */         match(_tokenSet_4);
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1226 */     match("*/");
/* 1227 */     if (this.inputState.guessing == 0) {
/* 1228 */       s = -1;
/*      */     }
/*      */     
/* 1231 */     if (paramBoolean && token == null && s != -1) {
/* 1232 */       token = makeToken(s);
/* 1233 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1235 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCPPComment(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1239 */     Token token = null; int i = this.text.length();
/* 1240 */     short s = 144;
/*      */ 
/*      */     
/* 1243 */     match("//");
/*      */ 
/*      */ 
/*      */     
/* 1247 */     while (_tokenSet_5.member(LA(1)))
/*      */     {
/* 1249 */       match(_tokenSet_5);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1258 */     if (this.inputState.guessing == 0)
/*      */     {
/* 1260 */       s = -1;
/*      */     }
/*      */     
/* 1263 */     if (paramBoolean && token == null && s != -1) {
/* 1264 */       token = makeToken(s);
/* 1265 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1267 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mNonWhitespace(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1271 */     Token token = null; int i = this.text.length();
/* 1272 */     char c = '';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1278 */     while (_tokenSet_6.member(LA(1)))
/*      */     {
/* 1280 */       match(_tokenSet_6);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1289 */     if (paramBoolean && token == null && c != -1) {
/* 1290 */       token = makeToken(c);
/* 1291 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1293 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPREPROC_DIRECTIVE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1297 */     Token token1 = null; int i = this.text.length();
/* 1298 */     short s = 146;
/*      */     
/* 1300 */     Token token2 = null;
/* 1301 */     Token token3 = null;
/* 1302 */     Token token4 = null;
/*      */     
/* 1304 */     match('#');
/*      */     
/* 1306 */     boolean bool = false;
/* 1307 */     if (_tokenSet_7.member(LA(1)) && _tokenSet_8.member(LA(2)) && _tokenSet_9.member(LA(3))) {
/* 1308 */       int j = mark();
/* 1309 */       bool = true;
/* 1310 */       this.inputState.guessing++;
/*      */       try {
/*      */         byte b;
/* 1313 */         switch (LA(1)) {
/*      */           
/*      */           case 'l':
/* 1316 */             match("line");
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\t':
/*      */           case '\f':
/*      */           case ' ':
/* 1323 */             b = 0;
/*      */             
/*      */             while (true) {
/* 1326 */               switch (LA(1)) {
/*      */                 
/*      */                 case ' ':
/* 1329 */                   match(' ');
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case '\t':
/* 1334 */                   match('\t');
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case '\f':
/* 1339 */                   match('\f');
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 default:
/* 1344 */                   if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */               } 
/*      */               
/* 1347 */               b++;
/*      */             } 
/*      */             
/* 1350 */             matchRange('0', '9');
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1360 */       } catch (RecognitionException recognitionException) {
/* 1361 */         bool = false;
/*      */       } 
/* 1363 */       rewind(j);
/* 1364 */       this.inputState.guessing--;
/*      */     } 
/* 1366 */     if (bool) {
/* 1367 */       mLineDirective(false);
/*      */     }
/* 1369 */     else if (_tokenSet_10.member(LA(1)) && _tokenSet_11.member(LA(2)) && _tokenSet_12.member(LA(3))) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1374 */       while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 1375 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1383 */       match("define");
/*      */ 
/*      */ 
/*      */       
/* 1387 */       while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 1388 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1396 */       mID(true);
/* 1397 */       token2 = this._returnToken;
/*      */ 
/*      */ 
/*      */       
/* 1401 */       while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1402 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1411 */       if (_tokenSet_1.member(LA(1)) && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1412 */         mDefineExpr(true);
/* 1413 */         token3 = this._returnToken;
/*      */       }
/* 1415 */       else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */         
/* 1418 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */       
/* 1422 */       mNonWhitespace(true);
/* 1423 */       token4 = this._returnToken;
/*      */       
/* 1425 */       if (LA(1) == '\r' && LA(2) == '\n') {
/* 1426 */         match("\r\n");
/*      */       }
/* 1428 */       else if (LA(1) == '\r') {
/* 1429 */         match("\r");
/*      */       }
/* 1431 */       else if (LA(1) == '\n') {
/* 1432 */         match("\n");
/*      */       } else {
/*      */         
/* 1435 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1440 */       if (this.inputState.guessing == 0)
/*      */       {
/* 1442 */         if (token3 != null) {
/*      */           
/* 1444 */           addDefine(token2.getText(), token3.getText());
/*      */         } else {
/* 1446 */           setPreprocessingDirective("#define " + token2.getText() + " " + token4.getText());
/*      */         } 
/* 1448 */         deferredNewline();
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1456 */       while (_tokenSet_5.member(LA(1))) {
/* 1457 */         matchNot('\n');
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1465 */       if (this.inputState.guessing == 0) {
/* 1466 */         setPreprocessingDirective(getText());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1471 */     if (this.inputState.guessing == 0)
/*      */     {
/* 1473 */       s = -1;
/*      */     }
/*      */     
/* 1476 */     if (paramBoolean && token1 == null && s != -1) {
/* 1477 */       token1 = makeToken(s);
/* 1478 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1480 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mLineDirective(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1484 */     Token token1 = null; int i = this.text.length();
/* 1485 */     char c = '';
/*      */     
/* 1487 */     Token token2 = null;
/* 1488 */     Token token3 = null;
/* 1489 */     Token token4 = null;
/*      */     
/* 1491 */     boolean bool = this.countingTokens;
/* 1492 */     this.countingTokens = false;
/*      */ 
/*      */     
/* 1495 */     if (this.inputState.guessing == 0) {
/*      */       
/* 1497 */       this.lineObject = new LineObject();
/* 1498 */       this.deferredLineCount = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1502 */     switch (LA(1)) {
/*      */       
/*      */       case 'l':
/* 1505 */         match("line");
/*      */         break;
/*      */       
/*      */       case '\t':
/*      */       case '\f':
/*      */       case ' ':
/*      */         break;
/*      */       
/*      */       default:
/* 1514 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1519 */     byte b = 0;
/*      */     
/*      */     while (true) {
/* 1522 */       if (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 1523 */         mSpace(false);
/*      */       } else {
/*      */         
/* 1526 */         if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1529 */       b++;
/*      */     } 
/*      */     
/* 1532 */     mNumber(true);
/* 1533 */     token2 = this._returnToken;
/* 1534 */     if (this.inputState.guessing == 0)
/*      */     {
/* 1536 */       this.lineObject.setLine(Integer.parseInt(token2.getText()));
/*      */     }
/*      */ 
/*      */     
/* 1540 */     b = 0;
/*      */     
/*      */     while (true) {
/* 1543 */       if ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1544 */         mSpace(false);
/*      */       } else {
/*      */         
/* 1547 */         if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1550 */       b++;
/*      */     } 
/*      */ 
/*      */     
/* 1554 */     if (LA(1) == '"' && LA(2) >= '\000' && LA(2) <= 'ÿ' && LA(3) >= '\000' && LA(3) <= 'ÿ') {
/* 1555 */       mStringLiteral(true);
/* 1556 */       token3 = this._returnToken;
/* 1557 */       if (this.inputState.guessing == 0) {
/*      */         try {
/* 1559 */           String str = token3.getText().substring(1, token3.getText().length() - 1);
/*      */           
/* 1561 */           this.lineObject.setSource(str);
/*      */         }
/* 1563 */         catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
/*      */       
/*      */       }
/*      */     }
/* 1567 */     else if (_tokenSet_13.member(LA(1)) && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1568 */       mID(true);
/* 1569 */       token4 = this._returnToken;
/* 1570 */       if (this.inputState.guessing == 0) {
/* 1571 */         this.lineObject.setSource(token4.getText());
/*      */       }
/*      */     }
/* 1574 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 1577 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1584 */     while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1585 */       mSpace(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1594 */     if (LA(1) == '1' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1595 */       match("1");
/* 1596 */       if (this.inputState.guessing == 0) {
/* 1597 */         this.lineObject.setEnteringFile(true);
/*      */       }
/*      */     }
/* 1600 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 1603 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1610 */     while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1611 */       mSpace(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1620 */     if (LA(1) == '2' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1621 */       match("2");
/* 1622 */       if (this.inputState.guessing == 0) {
/* 1623 */         this.lineObject.setReturningToFile(true);
/*      */       }
/*      */     }
/* 1626 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 1629 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1636 */     while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1637 */       mSpace(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1646 */     if (LA(1) == '3' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1647 */       match("3");
/* 1648 */       if (this.inputState.guessing == 0) {
/* 1649 */         this.lineObject.setSystemHeader(true);
/*      */       }
/*      */     }
/* 1652 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 1655 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1662 */     while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1663 */       mSpace(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1672 */     if (LA(1) == '4' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 1673 */       match("4");
/* 1674 */       if (this.inputState.guessing == 0) {
/* 1675 */         this.lineObject.setTreatAsC(true);
/*      */       }
/*      */     }
/* 1678 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 1681 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1688 */     while (_tokenSet_6.member(LA(1)))
/*      */     {
/* 1690 */       match(_tokenSet_6);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1700 */     if (LA(1) == '\r' && LA(2) == '\n') {
/* 1701 */       match("\r\n");
/*      */     }
/* 1703 */     else if (LA(1) == '\r') {
/* 1704 */       match("\r");
/*      */     }
/* 1706 */     else if (LA(1) == '\n') {
/* 1707 */       match("\n");
/*      */     } else {
/*      */       
/* 1710 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1714 */     if (this.inputState.guessing == 0) {
/*      */       
/* 1716 */       this.preprocessorInfoChannel.addLineForTokenNumber(new LineObject(this.lineObject), new Integer(this.tokenNumber));
/* 1717 */       this.countingTokens = bool;
/*      */     } 
/*      */     
/* 1720 */     if (paramBoolean && token1 == null && c != -1) {
/* 1721 */       token1 = makeToken(c);
/* 1722 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1724 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mSpace(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1728 */     Token token = null; int i = this.text.length();
/* 1729 */     char c = '';
/*      */ 
/*      */ 
/*      */     
/* 1733 */     switch (LA(1)) {
/*      */       
/*      */       case ' ':
/* 1736 */         match(' ');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\t':
/* 1741 */         match('\t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\f':
/* 1746 */         match('\f');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1751 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1755 */     if (paramBoolean && token == null && c != -1) {
/* 1756 */       token = makeToken(c);
/* 1757 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1759 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mID(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1763 */     Token token = null; int j = this.text.length();
/* 1764 */     int i = 42;
/*      */ 
/*      */ 
/*      */     
/* 1768 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1777 */         matchRange('a', 'z'); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */       case 'R':
/*      */       case 'S':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       case 'Z':
/* 1788 */         matchRange('A', 'Z');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '_':
/* 1793 */         match('_');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1798 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1805 */       if (LA(1) >= 'a' && LA(1) <= 'z') {
/* 1806 */         matchRange('a', 'z'); continue;
/*      */       } 
/* 1808 */       if (LA(1) >= 'A' && LA(1) <= 'Z') {
/* 1809 */         matchRange('A', 'Z'); continue;
/*      */       } 
/* 1811 */       if (LA(1) == '_') {
/* 1812 */         match('_'); continue;
/*      */       } 
/* 1814 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 1815 */         matchRange('0', '9');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1823 */     i = testLiteralsTable(i);
/* 1824 */     if (paramBoolean && token == null && i != -1) {
/* 1825 */       token = makeToken(i);
/* 1826 */       token.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/* 1828 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDefineExpr(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1832 */     Token token = null; int i = this.text.length();
/* 1833 */     char c = '';
/*      */ 
/*      */     
/* 1836 */     switch (LA(1)) {
/*      */ 
/*      */ 
/*      */       
/*      */       case '(':
/* 1841 */         mLPAREN(false);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1846 */         while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 1847 */           mSpace(false);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1856 */         mDefineExpr2(false);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1861 */         while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 1862 */           mSpace(false);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1871 */         mRPAREN(false); break;
/*      */       case '.': case '0': case '1':
/*      */       case '2':
/*      */       case '3':
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1881 */         mDefineExpr2(false);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1887 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1890 */     if (paramBoolean && token == null && c != -1) {
/* 1891 */       token = makeToken(c);
/* 1892 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1894 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDefineExpr2(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1898 */     Token token = null; int i = this.text.length();
/* 1899 */     char c = '';
/*      */ 
/*      */ 
/*      */     
/* 1903 */     mNumber(false);
/*      */ 
/*      */     
/* 1906 */     if (_tokenSet_14.member(LA(1)) && _tokenSet_15.member(LA(2))) {
/*      */ 
/*      */ 
/*      */       
/* 1910 */       while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 1911 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1920 */       switch (LA(1)) {
/*      */         
/*      */         case '<':
/* 1923 */           mLSHIFT(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '>':
/* 1928 */           mRSHIFT(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '+':
/* 1933 */           mPLUS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '-':
/* 1938 */           mMINUS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '*':
/* 1943 */           mSTAR(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '/':
/* 1948 */           mDIV(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '%':
/* 1953 */           mMOD(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1958 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1965 */       while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 1966 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1975 */       mDefineExpr(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1982 */     if (paramBoolean && token == null && c != -1) {
/* 1983 */       token = makeToken(c);
/* 1984 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1986 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mNumber(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1990 */     Token token = null; int i = this.text.length();
/* 1991 */     char c = '';
/*      */ 
/*      */     
/* 1994 */     boolean bool = false;
/* 1995 */     if (LA(1) == '.' && LA(2) == '.' && LA(3) == '.') {
/* 1996 */       int j = mark();
/* 1997 */       bool = true;
/* 1998 */       this.inputState.guessing++;
/*      */       
/*      */       try {
/* 2001 */         match("...");
/*      */       
/*      */       }
/* 2004 */       catch (RecognitionException recognitionException) {
/* 2005 */         bool = false;
/*      */       } 
/* 2007 */       rewind(j);
/* 2008 */       this.inputState.guessing--;
/*      */     } 
/* 2010 */     if (bool) {
/* 2011 */       match("...");
/* 2012 */       if (this.inputState.guessing == 0) {
/* 2013 */         c = '3';
/*      */       }
/*      */     }
/* 2016 */     else if (LA(1) == '0' && (LA(2) == 'X' || LA(2) == 'x') && _tokenSet_16.member(LA(3))) {
/* 2017 */       match('0');
/*      */       
/* 2019 */       switch (LA(1)) {
/*      */         
/*      */         case 'x':
/* 2022 */           match('x');
/*      */           break;
/*      */ 
/*      */         
/*      */         case 'X':
/* 2027 */           match('X');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2032 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2037 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 2040 */         if (LA(1) >= 'a' && LA(1) <= 'f') {
/* 2041 */           matchRange('a', 'f');
/*      */         }
/* 2043 */         else if (LA(1) >= 'A' && LA(1) <= 'F') {
/* 2044 */           matchRange('A', 'F');
/*      */         }
/* 2046 */         else if (LA(1) >= '0' && LA(1) <= '9') {
/* 2047 */           mDigit(false);
/*      */         } else {
/*      */           
/* 2050 */           if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */         
/* 2053 */         b++;
/*      */       } 
/*      */       
/* 2056 */       if (this.inputState.guessing == 0) {
/* 2057 */         c = 'k';
/*      */       }
/*      */       
/* 2060 */       if (LA(1) == 'L' || LA(1) == 'l') {
/* 2061 */         mLongSuffix(false);
/* 2062 */         if (this.inputState.guessing == 0) {
/* 2063 */           c = 'l';
/*      */         }
/*      */       }
/* 2066 */       else if (LA(1) == 'U' || LA(1) == 'u') {
/* 2067 */         mUnsignedSuffix(false);
/* 2068 */         if (this.inputState.guessing == 0) {
/* 2069 */           c = 'm';
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2078 */       boolean bool1 = false;
/* 2079 */       if (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_17.member(LA(2))) {
/* 2080 */         int j = mark();
/* 2081 */         bool1 = true;
/* 2082 */         this.inputState.guessing++;
/*      */ 
/*      */         
/*      */         try {
/* 2086 */           byte b = 0;
/*      */           
/*      */           while (true) {
/* 2089 */             if (LA(1) >= '0' && LA(1) <= '9') {
/* 2090 */               mDigit(false);
/*      */             } else {
/*      */               
/* 2093 */               if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */             
/* 2096 */             b++;
/*      */           } 
/*      */ 
/*      */           
/* 2100 */           switch (LA(1)) {
/*      */             
/*      */             case '.':
/* 2103 */               match('.');
/*      */               break;
/*      */ 
/*      */             
/*      */             case 'e':
/* 2108 */               match('e');
/*      */               break;
/*      */ 
/*      */             
/*      */             case 'E':
/* 2113 */               match('E');
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 2118 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2124 */         } catch (RecognitionException recognitionException) {
/* 2125 */           bool1 = false;
/*      */         } 
/* 2127 */         rewind(j);
/* 2128 */         this.inputState.guessing--;
/*      */       } 
/* 2130 */       if (bool1) {
/*      */         
/* 2132 */         byte b = 0;
/*      */         
/*      */         while (true) {
/* 2135 */           if (LA(1) >= '0' && LA(1) <= '9') {
/* 2136 */             mDigit(false);
/*      */           } else {
/*      */             
/* 2139 */             if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 2142 */           b++;
/*      */         } 
/*      */ 
/*      */         
/* 2146 */         switch (LA(1)) {
/*      */           
/*      */           case '.':
/* 2149 */             match('.');
/*      */ 
/*      */ 
/*      */             
/* 2153 */             while (LA(1) >= '0' && LA(1) <= '9') {
/* 2154 */               mDigit(false);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2163 */             if ((LA(1) == 'E' || LA(1) == 'e') && _tokenSet_18.member(LA(2))) {
/* 2164 */               mExponent(false);
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 'E':
/*      */           case 'e':
/* 2174 */             mExponent(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2179 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */         
/* 2183 */         if (this.inputState.guessing == 0) {
/* 2184 */           c = 'o';
/*      */         }
/*      */         
/* 2187 */         if (LA(1) == 'F' || LA(1) == 'f') {
/* 2188 */           mFloatSuffix(false);
/* 2189 */           if (this.inputState.guessing == 0) {
/* 2190 */             c = 'n';
/*      */           }
/*      */         }
/* 2193 */         else if (LA(1) == 'L' || LA(1) == 'l') {
/* 2194 */           mLongSuffix(false);
/* 2195 */           if (this.inputState.guessing == 0) {
/* 2196 */             c = 'p';
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 2204 */       else if (LA(1) == '.') {
/* 2205 */         match('.');
/* 2206 */         if (this.inputState.guessing == 0) {
/* 2207 */           c = 'b';
/*      */         }
/*      */         
/* 2210 */         if (LA(1) >= '0' && LA(1) <= '9')
/*      */         {
/* 2212 */           byte b = 0;
/*      */           
/*      */           while (true) {
/* 2215 */             if (LA(1) >= '0' && LA(1) <= '9') {
/* 2216 */               mDigit(false);
/*      */             } else {
/*      */               
/* 2219 */               if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */             
/* 2222 */             b++;
/*      */           } 
/*      */ 
/*      */           
/* 2226 */           if ((LA(1) == 'E' || LA(1) == 'e') && _tokenSet_18.member(LA(2))) {
/* 2227 */             mExponent(false);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2233 */           if (this.inputState.guessing == 0) {
/* 2234 */             c = 'o';
/*      */           }
/*      */           
/* 2237 */           if (LA(1) == 'F' || LA(1) == 'f') {
/* 2238 */             mFloatSuffix(false);
/* 2239 */             if (this.inputState.guessing == 0) {
/* 2240 */               c = 'n';
/*      */             }
/*      */           }
/* 2243 */           else if (LA(1) == 'L' || LA(1) == 'l') {
/* 2244 */             mLongSuffix(false);
/* 2245 */             if (this.inputState.guessing == 0) {
/* 2246 */               c = 'p';
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 2259 */       else if (LA(1) == '0') {
/* 2260 */         match('0');
/*      */ 
/*      */ 
/*      */         
/* 2264 */         while (LA(1) >= '0' && LA(1) <= '7') {
/* 2265 */           matchRange('0', '7');
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2273 */         if (this.inputState.guessing == 0) {
/* 2274 */           c = 'e';
/*      */         }
/*      */         
/* 2277 */         if (LA(1) == 'L' || LA(1) == 'l') {
/* 2278 */           mLongSuffix(false);
/* 2279 */           if (this.inputState.guessing == 0) {
/* 2280 */             c = 'f';
/*      */           }
/*      */         }
/* 2283 */         else if (LA(1) == 'U' || LA(1) == 'u') {
/* 2284 */           mUnsignedSuffix(false);
/* 2285 */           if (this.inputState.guessing == 0) {
/* 2286 */             c = 'g';
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 2294 */       else if (LA(1) >= '1' && LA(1) <= '9') {
/* 2295 */         matchRange('1', '9');
/*      */ 
/*      */ 
/*      */         
/* 2299 */         while (LA(1) >= '0' && LA(1) <= '9') {
/* 2300 */           mDigit(false);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2308 */         if (this.inputState.guessing == 0) {
/* 2309 */           c = 'h';
/*      */         }
/*      */         
/* 2312 */         if (LA(1) == 'L' || LA(1) == 'l') {
/* 2313 */           mLongSuffix(false);
/* 2314 */           if (this.inputState.guessing == 0) {
/* 2315 */             c = 'i';
/*      */           }
/*      */         }
/* 2318 */         else if (LA(1) == 'U' || LA(1) == 'u') {
/* 2319 */           mUnsignedSuffix(false);
/* 2320 */           if (this.inputState.guessing == 0) {
/* 2321 */             c = 'j';
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2330 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */     } 
/* 2333 */     if (paramBoolean && token == null && c != -1) {
/* 2334 */       token = makeToken(c);
/* 2335 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2337 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mStringLiteral(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2341 */     Token token = null; int i = this.text.length();
/* 2342 */     char c = 'd';
/*      */ 
/*      */     
/* 2345 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/* 2349 */       if (LA(1) == '\\' && _tokenSet_19.member(LA(2)) && LA(3) >= '\000' && LA(3) <= 'ÿ') {
/* 2350 */         mEscape(false); continue;
/*      */       } 
/* 2352 */       if ((LA(1) == '\n' || LA(1) == '\r' || LA(1) == '\\') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/*      */         
/* 2354 */         switch (LA(1)) {
/*      */           
/*      */           case '\r':
/* 2357 */             match('\r');
/* 2358 */             if (this.inputState.guessing == 0) {
/* 2359 */               deferredNewline();
/*      */             }
/*      */             continue;
/*      */ 
/*      */           
/*      */           case '\n':
/* 2365 */             match('\n');
/* 2366 */             if (this.inputState.guessing == 0) {
/*      */               
/* 2368 */               deferredNewline();
/* 2369 */               c = '';
/*      */             } 
/*      */             continue;
/*      */ 
/*      */ 
/*      */           
/*      */           case '\\':
/* 2376 */             match('\\');
/* 2377 */             match('\n');
/* 2378 */             if (this.inputState.guessing == 0)
/*      */             {
/* 2380 */               deferredNewline();
/*      */             }
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2387 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2392 */       if (_tokenSet_20.member(LA(1))) {
/*      */         
/* 2394 */         match(_tokenSet_20);
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 2403 */     match('"');
/* 2404 */     if (paramBoolean && token == null && c != -1) {
/* 2405 */       token = makeToken(c);
/* 2406 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2408 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCharLiteral(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2412 */     Token token = null; int i = this.text.length();
/* 2413 */     byte b = 99;
/*      */ 
/*      */     
/* 2416 */     match('\'');
/*      */     
/* 2418 */     if (LA(1) == '\\' && _tokenSet_19.member(LA(2)) && _tokenSet_21.member(LA(3))) {
/* 2419 */       mEscape(false);
/*      */     }
/* 2421 */     else if (_tokenSet_22.member(LA(1)) && LA(2) == '\'') {
/*      */       
/* 2423 */       match(_tokenSet_22);
/*      */     }
/*      */     else {
/*      */       
/* 2427 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2431 */     match('\'');
/* 2432 */     if (paramBoolean && token == null && b != -1) {
/* 2433 */       token = makeToken(b);
/* 2434 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2436 */     this._returnToken = token;
/*      */   }
/*      */   protected final void mEscape(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     byte b;
/* 2440 */     Token token = null; int i = this.text.length();
/* 2441 */     char c = '';
/*      */ 
/*      */     
/* 2444 */     match('\\');
/*      */     
/* 2446 */     switch (LA(1)) {
/*      */       
/*      */       case 'a':
/* 2449 */         match('a');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'b':
/* 2454 */         match('b');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/* 2459 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'n':
/* 2464 */         match('n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'r':
/* 2469 */         match('r');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 't':
/* 2474 */         match('t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'v':
/* 2479 */         match('v');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 2484 */         match('"');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 2489 */         match('\'');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\\':
/* 2494 */         match('\\');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '?':
/* 2499 */         match('?');
/*      */         break;
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/* 2505 */         matchRange('0', '3');
/*      */ 
/*      */         
/* 2508 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2509 */           mDigit(false);
/*      */           
/* 2511 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2512 */             mDigit(false); break;
/*      */           } 
/* 2514 */           if (LA(1) >= '\000' && LA(1) <= 'ÿ') {
/*      */             break;
/*      */           }
/* 2517 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2522 */         if (LA(1) >= '\000' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2525 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/* 2534 */         matchRange('4', '7');
/*      */ 
/*      */         
/* 2537 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2538 */           mDigit(false); break;
/*      */         } 
/* 2540 */         if (LA(1) >= '\000' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2543 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 'x':
/* 2551 */         match('x');
/*      */         
/* 2553 */         b = 0;
/*      */         
/*      */         while (true) {
/* 2556 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2557 */             mDigit(false);
/*      */           }
/* 2559 */           else if (LA(1) >= 'a' && LA(1) <= 'f' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2560 */             matchRange('a', 'f');
/*      */           }
/* 2562 */           else if (LA(1) >= 'A' && LA(1) <= 'F' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2563 */             matchRange('A', 'F');
/*      */           } else {
/*      */             
/* 2566 */             if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 2569 */           b++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 2576 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2580 */     if (paramBoolean && token == null && c != -1) {
/* 2581 */       token = makeToken(c);
/* 2582 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2584 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mBadStringLiteral(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2588 */     Token token = null; int i = this.text.length();
/* 2589 */     char c = '';
/*      */ 
/*      */     
/* 2592 */     if (paramBoolean && token == null && c != -1) {
/* 2593 */       token = makeToken(c);
/* 2594 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2596 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDigit(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2600 */     Token token = null; int i = this.text.length();
/* 2601 */     char c = '';
/*      */ 
/*      */     
/* 2604 */     matchRange('0', '9');
/* 2605 */     if (paramBoolean && token == null && c != -1) {
/* 2606 */       token = makeToken(c);
/* 2607 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2609 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongSuffix(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2613 */     Token token = null; int i = this.text.length();
/* 2614 */     char c = '';
/*      */ 
/*      */     
/* 2617 */     switch (LA(1)) {
/*      */       
/*      */       case 'l':
/* 2620 */         match('l');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'L':
/* 2625 */         match('L');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2630 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 2633 */     if (paramBoolean && token == null && c != -1) {
/* 2634 */       token = makeToken(c);
/* 2635 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2637 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mUnsignedSuffix(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2641 */     Token token = null; int i = this.text.length();
/* 2642 */     char c = '';
/*      */ 
/*      */     
/* 2645 */     switch (LA(1)) {
/*      */       
/*      */       case 'u':
/* 2648 */         match('u');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'U':
/* 2653 */         match('U');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2658 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 2661 */     if (paramBoolean && token == null && c != -1) {
/* 2662 */       token = makeToken(c);
/* 2663 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2665 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mFloatSuffix(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2669 */     Token token = null; int i = this.text.length();
/* 2670 */     char c = '';
/*      */ 
/*      */     
/* 2673 */     switch (LA(1)) {
/*      */       
/*      */       case 'f':
/* 2676 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'F':
/* 2681 */         match('F');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2686 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 2689 */     if (paramBoolean && token == null && c != -1) {
/* 2690 */       token = makeToken(c);
/* 2691 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2693 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mExponent(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2697 */     Token token = null; int i = this.text.length();
/* 2698 */     char c = '';
/*      */ 
/*      */ 
/*      */     
/* 2702 */     switch (LA(1)) {
/*      */       
/*      */       case 'e':
/* 2705 */         match('e');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'E':
/* 2710 */         match('E');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2715 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2720 */     switch (LA(1)) {
/*      */       
/*      */       case '+':
/* 2723 */         match('+');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '-':
/* 2728 */         match('-'); break;
/*      */       case '0': case '1': case '2':
/*      */       case '3':
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/*      */         break;
/*      */       default:
/* 2739 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2744 */     byte b = 0;
/*      */     
/*      */     while (true) {
/* 2747 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 2748 */         mDigit(false);
/*      */       } else {
/*      */         
/* 2751 */         if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 2754 */       b++;
/*      */     } 
/*      */     
/* 2757 */     if (paramBoolean && token == null && c != -1) {
/* 2758 */       token = makeToken(c);
/* 2759 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2761 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDoubleDoubleConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2765 */     Token token = null; int i = this.text.length();
/* 2766 */     byte b = 111;
/*      */ 
/*      */     
/* 2769 */     if (paramBoolean && token == null && b != -1) {
/* 2770 */       token = makeToken(b);
/* 2771 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2773 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mFloatDoubleConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2777 */     Token token = null; int i = this.text.length();
/* 2778 */     byte b = 110;
/*      */ 
/*      */     
/* 2781 */     if (paramBoolean && token == null && b != -1) {
/* 2782 */       token = makeToken(b);
/* 2783 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2785 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongDoubleConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2789 */     Token token = null; int i = this.text.length();
/* 2790 */     byte b = 112;
/*      */ 
/*      */     
/* 2793 */     if (paramBoolean && token == null && b != -1) {
/* 2794 */       token = makeToken(b);
/* 2795 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2797 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mIntOctalConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2801 */     Token token = null; int i = this.text.length();
/* 2802 */     byte b = 101;
/*      */ 
/*      */     
/* 2805 */     if (paramBoolean && token == null && b != -1) {
/* 2806 */       token = makeToken(b);
/* 2807 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2809 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongOctalConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2813 */     Token token = null; int i = this.text.length();
/* 2814 */     byte b = 102;
/*      */ 
/*      */     
/* 2817 */     if (paramBoolean && token == null && b != -1) {
/* 2818 */       token = makeToken(b);
/* 2819 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2821 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mUnsignedOctalConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2825 */     Token token = null; int i = this.text.length();
/* 2826 */     byte b = 103;
/*      */ 
/*      */     
/* 2829 */     if (paramBoolean && token == null && b != -1) {
/* 2830 */       token = makeToken(b);
/* 2831 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2833 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mIntIntConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2837 */     Token token = null; int i = this.text.length();
/* 2838 */     byte b = 104;
/*      */ 
/*      */     
/* 2841 */     if (paramBoolean && token == null && b != -1) {
/* 2842 */       token = makeToken(b);
/* 2843 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2845 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongIntConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2849 */     Token token = null; int i = this.text.length();
/* 2850 */     byte b = 105;
/*      */ 
/*      */     
/* 2853 */     if (paramBoolean && token == null && b != -1) {
/* 2854 */       token = makeToken(b);
/* 2855 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2857 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mUnsignedIntConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2861 */     Token token = null; int i = this.text.length();
/* 2862 */     byte b = 106;
/*      */ 
/*      */     
/* 2865 */     if (paramBoolean && token == null && b != -1) {
/* 2866 */       token = makeToken(b);
/* 2867 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2869 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mIntHexConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2873 */     Token token = null; int i = this.text.length();
/* 2874 */     byte b = 107;
/*      */ 
/*      */     
/* 2877 */     if (paramBoolean && token == null && b != -1) {
/* 2878 */       token = makeToken(b);
/* 2879 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2881 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongHexConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2885 */     Token token = null; int i = this.text.length();
/* 2886 */     byte b = 108;
/*      */ 
/*      */     
/* 2889 */     if (paramBoolean && token == null && b != -1) {
/* 2890 */       token = makeToken(b);
/* 2891 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2893 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mUnsignedHexConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2897 */     Token token = null; int i = this.text.length();
/* 2898 */     byte b = 109;
/*      */ 
/*      */     
/* 2901 */     if (paramBoolean && token == null && b != -1) {
/* 2902 */       token = makeToken(b);
/* 2903 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2905 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 2910 */     long[] arrayOfLong = new long[8];
/* 2911 */     arrayOfLong[0] = 8589934584L;
/* 2912 */     arrayOfLong[1] = Long.MIN_VALUE;
/* 2913 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2914 */      return arrayOfLong;
/*      */   }
/* 2916 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 2918 */     return new long[] { 288020369430806528L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2921 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 2923 */     return new long[] { 288019269919178752L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2926 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 2928 */     long[] arrayOfLong = new long[8];
/* 2929 */     arrayOfLong[0] = 8589925368L;
/* 2930 */     arrayOfLong[1] = Long.MIN_VALUE;
/* 2931 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2932 */      return arrayOfLong;
/*      */   }
/* 2934 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 2936 */     long[] arrayOfLong = new long[8];
/* 2937 */     arrayOfLong[0] = -4398046520321L;
/* 2938 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2939 */      return arrayOfLong;
/*      */   }
/* 2941 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 2943 */     long[] arrayOfLong = new long[8];
/* 2944 */     arrayOfLong[0] = -1025L;
/* 2945 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2946 */      return arrayOfLong;
/*      */   }
/* 2948 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 2950 */     long[] arrayOfLong = new long[8];
/* 2951 */     arrayOfLong[0] = -9217L;
/* 2952 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2953 */      return arrayOfLong;
/*      */   }
/* 2955 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 2957 */     return new long[] { 4294971904L, 17592186044416L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2960 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 2962 */     return new long[] { 288019274214150656L, 2199023255552L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2965 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 2967 */     return new long[] { 288019274214150656L, 81152891680722976L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2970 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 2972 */     return new long[] { 4294971904L, 68719476736L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2975 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 2977 */     return new long[] { 4294971904L, 206158430208L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2980 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 2982 */     return new long[] { 4294971904L, 481036337152L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2985 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 2987 */     return new long[] { 0L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2990 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 2992 */     return new long[] { 5764796780768137728L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2995 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 2997 */     return new long[] { 6052817150198944256L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3000 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 3002 */     return new long[] { 287948901175001088L, 541165879422L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3005 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 3007 */     return new long[] { 288019269919178752L, 137438953504L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3010 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 3012 */     return new long[] { 287992881640112128L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3015 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 3017 */     return new long[] { -9151595350857875456L, 95772161741946880L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3020 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 3022 */     long[] arrayOfLong = new long[8];
/* 3023 */     arrayOfLong[0] = -17179878401L;
/* 3024 */     arrayOfLong[1] = -268435457L;
/* 3025 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 3026 */      return arrayOfLong;
/*      */   }
/* 3028 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 3030 */     return new long[] { 287949450930814976L, 541165879422L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3033 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 3035 */     long[] arrayOfLong = new long[8];
/* 3036 */     arrayOfLong[0] = -549755813889L;
/* 3037 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 3038 */      return arrayOfLong;
/*      */   }
/* 3040 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/StdCLexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */