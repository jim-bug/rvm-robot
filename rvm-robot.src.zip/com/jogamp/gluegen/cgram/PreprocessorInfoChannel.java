/*    */ package com.jogamp.gluegen.cgram;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class PreprocessorInfoChannel {
/*  7 */   Hashtable<Integer, Vector<Object>> lineLists = new Hashtable<>();
/*  8 */   int firstValidTokenNumber = 0;
/*  9 */   int maxTokenNumber = 0;
/*    */ 
/*    */   
/*    */   public void addLineForTokenNumber(Object paramObject, Integer paramInteger) {
/* 13 */     if (this.lineLists.containsKey(paramInteger)) {
/* 14 */       Vector<Object> vector = this.lineLists.get(paramInteger);
/* 15 */       vector.addElement(paramObject);
/*    */     } else {
/*    */       
/* 18 */       Vector<Object> vector = new Vector();
/* 19 */       vector.addElement(paramObject);
/* 20 */       this.lineLists.put(paramInteger, vector);
/* 21 */       if (this.maxTokenNumber < paramInteger.intValue()) {
/* 22 */         this.maxTokenNumber = paramInteger.intValue();
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int getMaxTokenNumber() {
/* 29 */     return this.maxTokenNumber;
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector<Object> extractLinesPrecedingTokenNumber(Integer paramInteger) {
/* 34 */     Vector<Object> vector = new Vector();
/* 35 */     if (paramInteger == null) return vector; 
/* 36 */     for (int i = this.firstValidTokenNumber; i < paramInteger.intValue(); i++) {
/* 37 */       Integer integer = new Integer(i);
/* 38 */       if (this.lineLists.containsKey(integer)) {
/* 39 */         Vector vector1 = this.lineLists.get(integer);
/* 40 */         if (vector1 != null) {
/* 41 */           Enumeration enumeration = vector1.elements();
/* 42 */           while (enumeration.hasMoreElements()) {
/* 43 */             vector.addElement(enumeration.nextElement());
/*    */           }
/* 45 */           this.lineLists.remove(integer);
/*    */         } 
/*    */       } 
/*    */     } 
/* 49 */     this.firstValidTokenNumber = paramInteger.intValue();
/* 50 */     return vector;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 56 */     StringBuilder stringBuilder = new StringBuilder("PreprocessorInfoChannel:\n");
/* 57 */     for (byte b = 0; b <= this.maxTokenNumber + 1; b++) {
/* 58 */       Integer integer = new Integer(b);
/* 59 */       if (this.lineLists.containsKey(integer)) {
/* 60 */         Vector vector = this.lineLists.get(integer);
/* 61 */         if (vector != null) {
/* 62 */           Enumeration<String> enumeration = vector.elements();
/* 63 */           while (enumeration.hasMoreElements()) {
/* 64 */             stringBuilder.append(integer + ":" + enumeration.nextElement() + '\n');
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/* 69 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/PreprocessorInfoChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */