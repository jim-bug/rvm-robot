/*     */ package com.jogamp.gluegen.cgram;
/*     */ 
/*     */ import antlr.BaseAST;
/*     */ import antlr.CommonAST;
/*     */ import antlr.Token;
/*     */ import antlr.collections.AST;
/*     */ import com.jogamp.gluegen.ASTLocusTag;
/*     */ import com.jogamp.gluegen.GlueGen;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TNode
/*     */   extends CommonAST
/*     */   implements ASTLocusTag.ASTLocusTagProvider
/*     */ {
/*     */   protected int ttype;
/*     */   protected String text;
/*  41 */   protected int lineNum = 0;
/*     */   protected TNode defNode;
/*     */   protected TNode up;
/*     */   protected TNode left;
/*     */   protected boolean marker = false;
/*  46 */   protected Hashtable<String, Object> attributes = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String tokenVocabulary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTLocusTag getASTLocusTag() {
/*  58 */     Object object = getAttribute("source");
/*  59 */     if (null != object) {
/*  60 */       return new ASTLocusTag(object, getLineNum(), -1, getText());
/*     */     }
/*  62 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setTokenVocabulary(String paramString) {
/*  71 */     tokenVocabulary = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(Token paramToken) {
/*  77 */     CToken cToken = (CToken)paramToken;
/*  78 */     setText(cToken.getText());
/*  79 */     setType(cToken.getType());
/*  80 */     setLineNum(cToken.getLine());
/*  81 */     setAttribute("source", cToken.getSource());
/*  82 */     setAttribute("tokenNumber", new Integer(cToken.getTokenNumber()));
/*     */   }
/*     */   
/*     */   public void initialize(AST paramAST) {
/*  86 */     TNode tNode = (TNode)paramAST;
/*  87 */     setText(tNode.getText());
/*  88 */     setType(tNode.getType());
/*  89 */     setLineNum(tNode.getLineNum());
/*  90 */     setDefNode(tNode.getDefNode());
/*  91 */     this.attributes = tNode.getAttributesTable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/*  97 */     return this.ttype;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(int paramInt) {
/* 102 */     this.ttype = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMarker() {
/* 108 */     return this.marker;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarker(boolean paramBoolean) {
/* 114 */     this.marker = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable<String, Object> getAttributesTable() {
/* 120 */     if (this.attributes == null)
/* 121 */       this.attributes = new Hashtable<>(7); 
/* 122 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String paramString, Object paramObject) {
/* 128 */     if (this.attributes == null)
/* 129 */       this.attributes = new Hashtable<>(7); 
/* 130 */     this.attributes.put(paramString, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String paramString) {
/* 137 */     if (this.attributes == null) {
/* 138 */       return null;
/*     */     }
/* 140 */     return this.attributes.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNum() {
/* 146 */     if (this.lineNum != 0) {
/* 147 */       return this.lineNum;
/*     */     }
/* 149 */     if (this.down == null) {
/* 150 */       return this.lineNum;
/*     */     }
/* 152 */     return ((TNode)this.down).getLocalLineNum();
/*     */   }
/*     */   
/*     */   public int getLocalLineNum() {
/* 156 */     if (this.lineNum != 0) {
/* 157 */       return this.lineNum;
/*     */     }
/* 159 */     if (this.down == null) {
/* 160 */       if (this.right == null) {
/* 161 */         return this.lineNum;
/*     */       }
/* 163 */       return ((TNode)this.right).getLocalLineNum();
/*     */     } 
/* 165 */     return ((TNode)this.down).getLocalLineNum();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLineNum(int paramInt) {
/* 170 */     this.lineNum = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 175 */     return this.text;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setText(String paramString) {
/* 180 */     this.text = paramString;
/*     */   }
/*     */   
/*     */   static class DebugASTVisitor
/*     */   {
/*     */     private String tabs(StringBuilder param1StringBuilder) {
/* 186 */       param1StringBuilder.setLength(0);
/* 187 */       for (byte b = 0; b < this.level; b++) {
/* 188 */         param1StringBuilder.append("   ");
/*     */       }
/* 190 */       return param1StringBuilder.toString();
/*     */     } protected int level;
/*     */     DebugASTVisitor(int param1Int) {
/* 193 */       this.level = param1Int;
/*     */     }
/*     */     void visit(AST param1AST) {
/* 196 */       StringBuilder stringBuilder = new StringBuilder();
/*     */       
/* 198 */       for (AST aST = param1AST; aST != null; aST = aST.getNextSibling()) {
/* 199 */         if (aST.getText() == null) {
/* 200 */           System.err.printf("%03d: %snil [%d]%n", new Object[] { Integer.valueOf(this.level), tabs(stringBuilder), Integer.valueOf(aST.getType()) });
/*     */         } else {
/* 202 */           System.err.printf("%03d: %s%s [%d]%n", new Object[] { Integer.valueOf(this.level), tabs(stringBuilder), aST.getText(), Integer.valueOf(aST.getType()) });
/*     */         } 
/* 204 */         if (aST.getFirstChild() != null) {
/* 205 */           this.level++;
/* 206 */           visit(aST.getFirstChild());
/* 207 */           this.level--;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllChildrenText(String paramString) {
/* 220 */     if (GlueGen.debug()) {
/* 221 */       System.err.println("TNode.XXX: " + paramString);
/* 222 */       (new DebugASTVisitor(1)).visit(getFirstChild());
/*     */     } 
/* 224 */     StringBuilder stringBuilder = new StringBuilder();
/* 225 */     TNode tNode = (TNode)getFirstChild();
/* 226 */     if (null == tNode) {
/* 227 */       stringBuilder.append(getText());
/*     */     } else {
/* 229 */       getAllChildrenText(stringBuilder, this, tNode);
/*     */     } 
/* 231 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   private static void getAllChildrenText(StringBuilder paramStringBuilder, TNode paramTNode1, TNode paramTNode2) {
/* 235 */     boolean bool = true;
/* 236 */     while (null != paramTNode2) {
/* 237 */       boolean bool1 = (48 == paramTNode2.getType()) ? true : false;
/* 238 */       boolean bool2 = (120 == paramTNode2.getType()) ? true : false;
/*     */       
/* 240 */       TNode tNode1 = (TNode)paramTNode2.getNextSibling();
/* 241 */       TNode tNode2 = (TNode)paramTNode2.getFirstChild();
/* 242 */       if (!bool1 && ((null == tNode2 && null == tNode1) || !bool))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 247 */         paramStringBuilder.append(" ").append(paramTNode1.getText());
/*     */       }
/* 249 */       if (null != tNode2) {
/* 250 */         if (!bool2) {
/* 251 */           paramStringBuilder.append(" (");
/*     */         }
/* 253 */         getAllChildrenText(paramStringBuilder, paramTNode2, tNode2);
/* 254 */         if (!bool2) {
/* 255 */           paramStringBuilder.append(" )");
/*     */         }
/* 257 */       } else if (!bool1) {
/* 258 */         paramStringBuilder.append(" ").append(paramTNode2.getText());
/*     */       } 
/* 260 */       paramTNode2 = tNode1;
/* 261 */       bool = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TNode getLastChild() {
/* 267 */     TNode tNode = (TNode)getFirstChild();
/* 268 */     if (tNode != null) {
/* 269 */       return tNode.getLastSibling();
/*     */     }
/* 271 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode getLastSibling() {
/* 277 */     TNode tNode = (TNode)getNextSibling();
/* 278 */     if (tNode != null) {
/* 279 */       return tNode.getLastSibling();
/*     */     }
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode getFirstSibling() {
/* 287 */     TNode tNode = this.left;
/* 288 */     if (tNode != null) {
/* 289 */       return tNode.getFirstSibling();
/*     */     }
/* 291 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode getParent() {
/* 297 */     return (getFirstSibling()).up;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSibling(AST paramAST) {
/* 307 */     if (paramAST == null)
/* 308 */       return;  TNode tNode1 = (TNode)this.right;
/* 309 */     this.right = (BaseAST)paramAST;
/* 310 */     ((TNode)paramAST).left = this;
/* 311 */     TNode tNode2 = ((TNode)paramAST).getLastSibling();
/* 312 */     tNode2.right = (BaseAST)tNode1;
/* 313 */     if (tNode1 != null) {
/* 314 */       tNode1.left = tNode2;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int numberOfChildren() {
/* 320 */     byte b = 0;
/* 321 */     AST aST = getFirstChild();
/* 322 */     while (aST != null) {
/* 323 */       b++;
/* 324 */       aST = aST.getNextSibling();
/*     */     } 
/* 326 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSelf() {
/* 333 */     TNode tNode1 = this.up;
/* 334 */     TNode tNode2 = this.left;
/* 335 */     TNode tNode3 = (TNode)this.right;
/*     */     
/* 337 */     if (tNode1 != null) {
/* 338 */       tNode1.down = (BaseAST)tNode3;
/* 339 */       if (tNode3 != null) {
/* 340 */         tNode3.up = tNode1;
/* 341 */         tNode3.left = tNode2;
/*     */       } 
/*     */     } else {
/*     */       
/* 345 */       if (tNode2 != null)
/* 346 */         tNode2.right = (BaseAST)tNode3; 
/* 347 */       if (tNode3 != null) {
/* 348 */         tNode3.left = tNode2;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TNode getDefNode() {
/* 355 */     return this.defNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefNode(TNode paramTNode) {
/* 360 */     this.defNode = paramTNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode deepCopy() {
/* 369 */     TNode tNode = new TNode();
/* 370 */     tNode.ttype = this.ttype;
/* 371 */     tNode.text = this.text;
/* 372 */     tNode.lineNum = this.lineNum;
/* 373 */     tNode.defNode = this.defNode;
/* 374 */     if (this.attributes != null)
/* 375 */       tNode.attributes = new Hashtable<>(this.attributes); 
/* 376 */     if (this.down != null)
/* 377 */       tNode.down = (BaseAST)((TNode)this.down).deepCopyWithRightSiblings(); 
/* 378 */     tNode.doubleLink();
/* 379 */     return tNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode deepCopyWithRightSiblings() {
/* 388 */     TNode tNode = new TNode();
/* 389 */     tNode.ttype = this.ttype;
/* 390 */     tNode.text = this.text;
/* 391 */     tNode.lineNum = this.lineNum;
/* 392 */     tNode.defNode = this.defNode;
/* 393 */     if (this.attributes != null)
/* 394 */       tNode.attributes = new Hashtable<>(this.attributes); 
/* 395 */     if (this.down != null)
/* 396 */       tNode.down = (BaseAST)((TNode)this.down).deepCopyWithRightSiblings(); 
/* 397 */     if (this.right != null)
/* 398 */       tNode.right = (BaseAST)((TNode)this.right).deepCopyWithRightSiblings(); 
/* 399 */     tNode.doubleLink();
/* 400 */     return tNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 408 */     StringBuilder stringBuilder = new StringBuilder(getNameForType(getType()) + "[" + getText() + ", ]");
/*     */     
/* 410 */     if (getLineNum() != 0) {
/* 411 */       stringBuilder.append(" line:" + getLineNum());
/*     */     }
/* 413 */     Enumeration<String> enumeration = getAttributesTable().keys();
/* 414 */     while (enumeration.hasMoreElements()) {
/* 415 */       String str = enumeration.nextElement();
/* 416 */       stringBuilder.append(" " + str + ":" + getAttribute(str));
/*     */     } 
/*     */     
/* 419 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printTree(AST paramAST) {
/* 425 */     if (paramAST == null)
/* 426 */       return;  printASTNode(paramAST, 0);
/* 427 */     System.out.print("\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void printASTNode(AST paramAST, int paramInt) {
/* 434 */     AST aST1 = paramAST.getFirstChild();
/*     */     
/* 436 */     System.out.print("\n");
/* 437 */     for (byte b = 0; b < paramInt; b++) {
/* 438 */       System.out.print("   ");
/*     */     }
/* 440 */     if (aST1 != null) {
/* 441 */       System.out.print("(");
/*     */     }
/* 443 */     String str = paramAST.getText();
/* 444 */     if (str != null && str.length() > 0) {
/* 445 */       System.out.print(getNameForType(paramAST.getType()));
/* 446 */       System.out.print(": \"" + str + "\"");
/*     */     } else {
/*     */       
/* 449 */       System.out.print(getNameForType(paramAST.getType()));
/* 450 */     }  if (((TNode)paramAST).getLineNum() != 0) {
/* 451 */       System.out.print(" line:" + ((TNode)paramAST).getLineNum());
/*     */     }
/* 453 */     Enumeration<String> enumeration = ((TNode)paramAST).getAttributesTable().keys();
/* 454 */     while (enumeration.hasMoreElements()) {
/* 455 */       String str1 = enumeration.nextElement();
/* 456 */       System.out.print(" " + str1 + ":" + ((TNode)paramAST).getAttribute(str1));
/*     */     } 
/* 458 */     TNode tNode = ((TNode)paramAST).getDefNode();
/* 459 */     if (tNode != null) {
/* 460 */       System.out.print("[" + getNameForType(tNode.getType()) + "]");
/*     */     }
/*     */     
/* 463 */     if (aST1 != null) {
/* 464 */       printASTNode(aST1, paramInt + 1);
/*     */       
/* 466 */       System.out.print("\n");
/* 467 */       for (byte b1 = 0; b1 < paramInt; b1++)
/* 468 */         System.out.print("   "); 
/* 469 */       System.out.print(")");
/*     */     } 
/*     */     
/* 472 */     AST aST2 = paramAST.getNextSibling();
/* 473 */     if (aST2 != null) {
/* 474 */       printASTNode(aST2, paramInt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getNameForType(int paramInt) {
/*     */     
/* 483 */     try { Class<?> clazz = Class.forName(tokenVocabulary);
/* 484 */       Field[] arrayOfField = clazz.getDeclaredFields();
/* 485 */       if (paramInt - 2 < arrayOfField.length)
/* 486 */         return arrayOfField[paramInt - 2].getName();  }
/* 487 */     catch (Exception exception) { System.out.println(exception); }
/* 488 */      return "unfoundtype: " + paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doubleLink() {
/* 495 */     TNode tNode1 = (TNode)getNextSibling();
/* 496 */     if (tNode1 != null) {
/* 497 */       tNode1.left = this;
/* 498 */       tNode1.doubleLink();
/*     */     } 
/* 500 */     TNode tNode2 = (TNode)getFirstChild();
/* 501 */     if (tNode2 != null) {
/* 502 */       tNode2.up = this;
/* 503 */       tNode2.doubleLink();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode parentOfType(int paramInt) {
/* 510 */     if (this.up == null) {
/* 511 */       if (this.left == null) {
/* 512 */         return null;
/*     */       }
/* 514 */       return this.left.parentOfType(paramInt);
/*     */     } 
/* 516 */     if (this.up.getType() == paramInt)
/* 517 */       return this.up; 
/* 518 */     return this.up.parentOfType(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode firstChildOfType(int paramInt) {
/* 524 */     TNode tNode = (TNode)getFirstChild();
/* 525 */     if (tNode == null)
/* 526 */       return null; 
/* 527 */     if (tNode.getType() == paramInt)
/* 528 */       return tNode; 
/* 529 */     return tNode.firstSiblingOfType(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode firstSiblingOfType(int paramInt) {
/* 535 */     TNode tNode = (TNode)getNextSibling();
/* 536 */     if (tNode == null)
/* 537 */       return null; 
/* 538 */     if (tNode.getType() == paramInt)
/* 539 */       return tNode; 
/* 540 */     return tNode.firstSiblingOfType(paramInt);
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/TNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */