/*     */ package com.jogamp.gluegen.cgram;
/*     */ 
/*     */ class LineObject {
/*   4 */   LineObject parent = null;
/*   5 */   String source = "";
/*   6 */   int line = 1;
/*     */   
/*     */   boolean enteringFile = false;
/*     */   
/*     */   boolean returningToFile = false;
/*     */   
/*     */   boolean systemHeader = false;
/*     */   
/*     */   boolean treatAsC = false;
/*     */   
/*     */   public LineObject() {}
/*     */   
/*     */   public LineObject(LineObject paramLineObject) {
/*  19 */     this.parent = paramLineObject.getParent();
/*  20 */     this.source = paramLineObject.getSource();
/*  21 */     this.line = paramLineObject.getLine();
/*  22 */     this.enteringFile = paramLineObject.getEnteringFile();
/*  23 */     this.returningToFile = paramLineObject.getReturningToFile();
/*  24 */     this.systemHeader = paramLineObject.getSystemHeader();
/*  25 */     this.treatAsC = paramLineObject.getTreatAsC();
/*     */   }
/*     */ 
/*     */   
/*     */   public LineObject(String paramString) {
/*  30 */     this.source = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSource(String paramString) {
/*  35 */     this.source = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSource() {
/*  40 */     return this.source;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParent(LineObject paramLineObject) {
/*  45 */     this.parent = paramLineObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public LineObject getParent() {
/*  50 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLine(int paramInt) {
/*  55 */     this.line = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLine() {
/*  60 */     return this.line;
/*     */   }
/*     */ 
/*     */   
/*     */   public void newline() {
/*  65 */     this.line++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnteringFile(boolean paramBoolean) {
/*  70 */     this.enteringFile = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getEnteringFile() {
/*  75 */     return this.enteringFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReturningToFile(boolean paramBoolean) {
/*  80 */     this.returningToFile = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getReturningToFile() {
/*  85 */     return this.returningToFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSystemHeader(boolean paramBoolean) {
/*  90 */     this.systemHeader = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getSystemHeader() {
/*  95 */     return this.systemHeader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTreatAsC(boolean paramBoolean) {
/* 100 */     this.treatAsC = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getTreatAsC() {
/* 105 */     return this.treatAsC;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     StringBuilder stringBuilder = new StringBuilder("# " + this.line + " \"" + this.source + "\"");
/* 112 */     if (this.enteringFile) {
/* 113 */       stringBuilder.append(" 1");
/*     */     }
/* 115 */     if (this.returningToFile) {
/* 116 */       stringBuilder.append(" 2");
/*     */     }
/* 118 */     if (this.systemHeader) {
/* 119 */       stringBuilder.append(" 3");
/*     */     }
/* 121 */     if (this.treatAsC) {
/* 122 */       stringBuilder.append(" 4");
/*     */     }
/* 124 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/LineObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */