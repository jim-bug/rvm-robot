/*      */ package com.jogamp.gluegen.cgram;
/*      */ 
/*      */ import antlr.ASTFactory;
/*      */ import antlr.ASTPair;
/*      */ import antlr.LLkParser;
/*      */ import antlr.MismatchedTokenException;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.ParserSharedInputState;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.SemanticException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenBuffer;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.ASTArray;
/*      */ import antlr.collections.impl.BitSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StdCParser
/*      */   extends LLkParser
/*      */   implements STDCTokenTypes
/*      */ {
/*      */   public static boolean CPPComments = true;
/*   36 */   public CSymbolTable symbolTable = new CSymbolTable();
/*      */ 
/*      */   
/*   39 */   protected int unnamedScopeCounter = 0;
/*      */   
/*      */   public boolean isTypedefName(String paramString) {
/*   42 */     boolean bool = false;
/*   43 */     TNode tNode = this.symbolTable.lookupNameInCurrentScope(paramString);
/*   44 */     for (; tNode != null; tNode = (TNode)tNode.getNextSibling()) {
/*   45 */       if (tNode.getType() == 4) {
/*   46 */         bool = true;
/*      */         break;
/*      */       } 
/*      */     } 
/*   50 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAScopeName() {
/*   55 */     return "" + this.unnamedScopeCounter++;
/*      */   }
/*      */   
/*      */   public void pushScope(String paramString) {
/*   59 */     this.symbolTable.pushScope(paramString);
/*      */   }
/*      */   
/*      */   public void popScope() {
/*   63 */     this.symbolTable.popScope();
/*      */   }
/*      */   
/*      */   protected boolean debugging = false;
/*      */   
/*      */   public boolean getDebug() {
/*   69 */     return this.debugging;
/*      */   }
/*      */   
/*      */   public void setDebug(boolean paramBoolean) {
/*   73 */     this.debugging = paramBoolean;
/*      */   }
/*      */   
/*   76 */   int traceDepth = 0;
/*      */   public void reportError(RecognitionException paramRecognitionException) {
/*      */     try {
/*   79 */       System.err.println("ANTLR Parsing Error: " + paramRecognitionException + " token name:" + this.tokenNames[LA(1)]);
/*   80 */       paramRecognitionException.printStackTrace(System.err);
/*      */     }
/*   82 */     catch (TokenStreamException tokenStreamException) {
/*   83 */       System.err.println("ANTLR Parsing Error: " + paramRecognitionException);
/*   84 */       paramRecognitionException.printStackTrace(System.err);
/*      */     } 
/*      */   }
/*      */   public void reportError(String paramString) {
/*   88 */     System.err.println("ANTLR Parsing Error from String: " + paramString);
/*      */   }
/*      */   public void reportWarning(String paramString) {
/*   91 */     System.err.println("ANTLR Parsing Warning from String: " + paramString);
/*      */   }
/*      */   public void match(int paramInt) throws MismatchedTokenException {
/*   94 */     if (this.debugging) {
/*   95 */       for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*      */        try {
/*   97 */         System.out.println("Match(" + this.tokenNames[paramInt] + ") with LA(1)=" + this.tokenNames[
/*   98 */               LA(1)] + ((this.inputState.guessing > 0) ? (" [inputState.guessing " + this.inputState.guessing + "]") : ""));
/*      */       }
/*  100 */       catch (TokenStreamException tokenStreamException) {
/*  101 */         System.out.println("Match(" + this.tokenNames[paramInt] + ") " + ((this.inputState.guessing > 0) ? (" [inputState.guessing " + this.inputState.guessing + "]") : ""));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  107 */       if (LA(1) != paramInt) {
/*  108 */         if (this.debugging) {
/*  109 */           for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*  110 */            System.out.println("token mismatch: " + this.tokenNames[LA(1)] + "!=" + this.tokenNames[paramInt]);
/*      */         } 
/*      */         
/*  113 */         throw new MismatchedTokenException(this.tokenNames, LT(1), paramInt, false, getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  117 */       consume();
/*      */     
/*      */     }
/*  120 */     catch (TokenStreamException tokenStreamException) {}
/*      */   }
/*      */ 
/*      */   
/*      */   public void traceIn(String paramString) {
/*  125 */     this.traceDepth++;
/*  126 */     for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*      */      try {
/*  128 */       System.out.println("> " + paramString + "; LA(1)==(" + this.tokenNames[LT(1).getType()] + ") " + 
/*  129 */           LT(1).getText() + " [inputState.guessing " + this.inputState.guessing + "]");
/*      */     }
/*  131 */     catch (TokenStreamException tokenStreamException) {}
/*      */   }
/*      */   
/*      */   public void traceOut(String paramString) {
/*  135 */     for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }
/*      */      try {
/*  137 */       System.out.println("< " + paramString + "; LA(1)==(" + this.tokenNames[LT(1).getType()] + ") " + 
/*  138 */           LT(1).getText() + " [inputState.guessing " + this.inputState.guessing + "]");
/*      */     }
/*  140 */     catch (TokenStreamException tokenStreamException) {}
/*      */     
/*  142 */     this.traceDepth--;
/*      */   }
/*      */ 
/*      */   
/*      */   protected StdCParser(TokenBuffer paramTokenBuffer, int paramInt) {
/*  147 */     super(paramTokenBuffer, paramInt);
/*  148 */     this.tokenNames = _tokenNames;
/*  149 */     buildTokenTypeASTClassMap();
/*  150 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public StdCParser(TokenBuffer paramTokenBuffer) {
/*  154 */     this(paramTokenBuffer, 2);
/*      */   }
/*      */   
/*      */   protected StdCParser(TokenStream paramTokenStream, int paramInt) {
/*  158 */     super(paramTokenStream, paramInt);
/*  159 */     this.tokenNames = _tokenNames;
/*  160 */     buildTokenTypeASTClassMap();
/*  161 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public StdCParser(TokenStream paramTokenStream) {
/*  165 */     this(paramTokenStream, 2);
/*      */   }
/*      */   
/*      */   public StdCParser(ParserSharedInputState paramParserSharedInputState) {
/*  169 */     super(paramParserSharedInputState, 2);
/*  170 */     this.tokenNames = _tokenNames;
/*  171 */     buildTokenTypeASTClassMap();
/*  172 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */ 
/*      */   
/*      */   public final void translationUnit() throws RecognitionException, TokenStreamException {
/*  177 */     this.returnAST = null;
/*  178 */     ASTPair aSTPair = new ASTPair();
/*  179 */     TNode tNode = null;
/*      */     
/*      */     try {
/*  182 */       switch (LA(1)) {
/*      */         
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 13:
/*      */         case 14:
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/*      */         case 18:
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*  222 */           externalList();
/*  223 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  224 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1:
/*  229 */           if (this.inputState.guessing == 0)
/*      */           {
/*  231 */             System.err.println("Empty source file!");
/*      */           }
/*      */           
/*  234 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  239 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/*  243 */     } catch (RecognitionException recognitionException) {
/*  244 */       if (this.inputState.guessing == 0) {
/*  245 */         reportError(recognitionException);
/*  246 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/*  248 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  251 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void externalList() throws RecognitionException, TokenStreamException {
/*  256 */     this.returnAST = null;
/*  257 */     ASTPair aSTPair = new ASTPair();
/*  258 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/*  262 */       byte b = 0;
/*      */       
/*      */       while (true) {
/*  265 */         if (_tokenSet_1.member(LA(1))) {
/*  266 */           externalDef();
/*  267 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/*  270 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/*  273 */         b++;
/*      */       } 
/*      */       
/*  276 */       tNode = (TNode)aSTPair.root;
/*      */     }
/*  278 */     catch (RecognitionException recognitionException) {
/*  279 */       if (this.inputState.guessing == 0) {
/*  280 */         reportError(recognitionException);
/*  281 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/*  283 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  286 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void externalDef() throws RecognitionException, TokenStreamException {
/*  291 */     this.returnAST = null;
/*  292 */     ASTPair aSTPair = new ASTPair();
/*  293 */     TNode tNode = null;
/*      */     
/*      */     try {
/*  296 */       boolean bool = false;
/*  297 */       if (_tokenSet_2.member(LA(1)) && _tokenSet_3.member(LA(2))) {
/*  298 */         int i = mark();
/*  299 */         bool = true;
/*  300 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/*  303 */           if (LA(1) == 4) {
/*  304 */             match(4);
/*      */           }
/*  306 */           else if (_tokenSet_2.member(LA(1)) && _tokenSet_3.member(LA(2))) {
/*  307 */             declaration();
/*      */           } else {
/*      */             
/*  310 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           
/*      */           }
/*      */         
/*      */         }
/*  315 */         catch (RecognitionException recognitionException) {
/*  316 */           bool = false;
/*      */         } 
/*  318 */         rewind(i);
/*  319 */         this.inputState.guessing--;
/*      */       } 
/*  321 */       if (bool) {
/*  322 */         declaration();
/*  323 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  324 */         tNode = (TNode)aSTPair.root;
/*      */       }
/*  326 */       else if (_tokenSet_4.member(LA(1)) && _tokenSet_5.member(LA(2))) {
/*  327 */         functionDef();
/*  328 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  329 */         tNode = (TNode)aSTPair.root;
/*      */       }
/*  331 */       else if (LA(1) == 5) {
/*  332 */         asm_expr();
/*  333 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  334 */         tNode = (TNode)aSTPair.root;
/*      */       } else {
/*      */         
/*  337 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     
/*      */     }
/*  341 */     catch (RecognitionException recognitionException) {
/*  342 */       if (this.inputState.guessing == 0) {
/*  343 */         reportError(recognitionException);
/*  344 */         recover(recognitionException, _tokenSet_6);
/*      */       } else {
/*  346 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  349 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void declaration() throws RecognitionException, TokenStreamException {
/*  354 */     this.returnAST = null;
/*  355 */     ASTPair aSTPair = new ASTPair();
/*  356 */     TNode tNode1 = null;
/*  357 */     TNode tNode2 = null;
/*  358 */     AST aST = null;
/*      */     
/*      */     try {
/*  361 */       declSpecifiers();
/*  362 */       tNode2 = (TNode)this.returnAST;
/*  363 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  364 */       if (this.inputState.guessing == 0) {
/*  365 */         aST = this.astFactory.dupList((AST)tNode2);
/*      */       }
/*      */       
/*  368 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*  373 */           initDeclList(aST);
/*  374 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  383 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  387 */       match(9);
/*  388 */       if (this.inputState.guessing == 0) {
/*  389 */         tNode1 = (TNode)aSTPair.root;
/*  390 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(117)).add((AST)tNode1));
/*  391 */         aSTPair.root = (AST)tNode1;
/*  392 */         aSTPair
/*  393 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/*  394 */         aSTPair.advanceChildToEnd();
/*      */       } 
/*  396 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  398 */     catch (RecognitionException recognitionException) {
/*  399 */       if (this.inputState.guessing == 0) {
/*  400 */         reportError(recognitionException);
/*  401 */         recover(recognitionException, _tokenSet_7);
/*      */       } else {
/*  403 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  406 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionDef() throws RecognitionException, TokenStreamException {
/*  411 */     this.returnAST = null;
/*  412 */     ASTPair aSTPair = new ASTPair();
/*  413 */     TNode tNode1 = null;
/*  414 */     TNode tNode2 = null;
/*  415 */     TNode tNode3 = null;
/*      */     
/*      */     try {
/*      */       TNode tNode;
/*      */       
/*  420 */       boolean bool = false;
/*  421 */       if (_tokenSet_8.member(LA(1)) && _tokenSet_9.member(LA(2))) {
/*  422 */         int i = mark();
/*  423 */         bool = true;
/*  424 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/*  427 */           functionDeclSpecifiers();
/*      */         
/*      */         }
/*  430 */         catch (RecognitionException recognitionException) {
/*  431 */           bool = false;
/*      */         } 
/*  433 */         rewind(i);
/*  434 */         this.inputState.guessing--;
/*      */       } 
/*  436 */       if (bool) {
/*  437 */         functionDeclSpecifiers();
/*  438 */         tNode2 = (TNode)this.returnAST;
/*  439 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       }
/*  441 */       else if (!_tokenSet_10.member(LA(1)) || !_tokenSet_5.member(LA(2))) {
/*      */ 
/*      */         
/*  444 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  448 */       String str = declarator(true);
/*  449 */       tNode3 = (TNode)this.returnAST;
/*  450 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  451 */       if (this.inputState.guessing == 0) {
/*      */ 
/*      */         
/*  454 */         AST aST1 = this.astFactory.dupList((AST)tNode3);
/*  455 */         AST aST2 = this.astFactory.dupList((AST)tNode2);
/*  456 */         this.symbolTable.add(str, (TNode)this.astFactory.make((new ASTArray(3)).add(null).add(aST2).add(aST1)));
/*  457 */         pushScope(str);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  463 */       while (_tokenSet_2.member(LA(1))) {
/*  464 */         declaration();
/*  465 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  474 */       switch (LA(1)) {
/*      */         
/*      */         case 51:
/*  477 */           tNode = null;
/*  478 */           tNode = (TNode)this.astFactory.create(LT(1));
/*  479 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/*  480 */           match(51);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  490 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  497 */       while (LA(1) == 9) {
/*  498 */         match(9);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  506 */       if (this.inputState.guessing == 0) {
/*  507 */         popScope();
/*      */       }
/*  509 */       compoundStatement(str);
/*  510 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  511 */       if (this.inputState.guessing == 0) {
/*  512 */         tNode1 = (TNode)aSTPair.root;
/*  513 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(127)).add((AST)tNode1));
/*  514 */         aSTPair.root = (AST)tNode1;
/*  515 */         aSTPair
/*  516 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/*  517 */         aSTPair.advanceChildToEnd();
/*      */       } 
/*  519 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  521 */     catch (RecognitionException recognitionException) {
/*  522 */       if (this.inputState.guessing == 0) {
/*  523 */         reportError(recognitionException);
/*  524 */         recover(recognitionException, _tokenSet_6);
/*      */       } else {
/*  526 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  529 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void asm_expr() throws RecognitionException, TokenStreamException {
/*  534 */     this.returnAST = null;
/*  535 */     ASTPair aSTPair = new ASTPair();
/*  536 */     TNode tNode = null;
/*      */     
/*      */     try {
/*  539 */       TNode tNode2, tNode1 = null;
/*  540 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/*  541 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/*  542 */       match(5);
/*      */       
/*  544 */       switch (LA(1)) {
/*      */         
/*      */         case 6:
/*  547 */           tNode2 = null;
/*  548 */           tNode2 = (TNode)this.astFactory.create(LT(1));
/*  549 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/*  550 */           match(6);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  559 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/*  563 */       match(7);
/*  564 */       expr();
/*  565 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  566 */       match(8);
/*  567 */       match(9);
/*  568 */       tNode = (TNode)aSTPair.root;
/*      */     }
/*  570 */     catch (RecognitionException recognitionException) {
/*  571 */       if (this.inputState.guessing == 0) {
/*  572 */         reportError(recognitionException);
/*  573 */         recover(recognitionException, _tokenSet_6);
/*      */       } else {
/*  575 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  578 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void expr() throws RecognitionException, TokenStreamException {
/*  583 */     this.returnAST = null;
/*  584 */     ASTPair aSTPair = new ASTPair();
/*  585 */     TNode tNode1 = null;
/*  586 */     Token token = null;
/*  587 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/*  590 */       assignExpr();
/*  591 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/*  595 */       while (LA(1) == 43 && _tokenSet_11.member(LA(2))) {
/*  596 */         token = LT(1);
/*  597 */         tNode2 = (TNode)this.astFactory.create(token);
/*  598 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode2);
/*  599 */         match(43);
/*  600 */         if (this.inputState.guessing == 0) {
/*  601 */           tNode2.setType(130);
/*      */         }
/*  603 */         assignExpr();
/*  604 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  612 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  614 */     catch (RecognitionException recognitionException) {
/*  615 */       if (this.inputState.guessing == 0) {
/*  616 */         reportError(recognitionException);
/*  617 */         recover(recognitionException, _tokenSet_12);
/*      */       } else {
/*  619 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  622 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void declSpecifiers() throws RecognitionException, TokenStreamException {
/*  627 */     this.returnAST = null;
/*  628 */     ASTPair aSTPair = new ASTPair();
/*  629 */     TNode tNode1 = null;
/*  630 */     TNode tNode2 = null;
/*  631 */     int i = 0;
/*      */ 
/*      */     
/*      */     try {
/*  635 */       byte b = 0;
/*      */       while (true) {
/*      */         boolean bool;
/*  638 */         switch (LA(1)) {
/*      */           
/*      */           case 4:
/*      */           case 13:
/*      */           case 14:
/*      */           case 15:
/*      */           case 16:
/*  645 */             storageClassSpecifier();
/*  646 */             tNode2 = (TNode)this.returnAST;
/*  647 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/*  653 */             typeQualifier();
/*  654 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */           
/*      */           default:
/*  658 */             bool = false;
/*  659 */             if (_tokenSet_13.member(LA(1)) && _tokenSet_14.member(LA(2))) {
/*  660 */               int j = mark();
/*  661 */               bool = true;
/*  662 */               this.inputState.guessing++;
/*      */               
/*      */               try {
/*  665 */                 if (LA(1) == 10) {
/*  666 */                   match(10);
/*      */                 }
/*  668 */                 else if (LA(1) == 11) {
/*  669 */                   match(11);
/*      */                 }
/*  671 */                 else if (LA(1) == 12) {
/*  672 */                   match(12);
/*      */                 }
/*  674 */                 else if (_tokenSet_13.member(LA(1))) {
/*  675 */                   typeSpecifier(i);
/*      */                 } else {
/*      */                   
/*  678 */                   throw new NoViableAltException(LT(1), getFilename());
/*      */                 
/*      */                 }
/*      */               
/*      */               }
/*  683 */               catch (RecognitionException recognitionException) {
/*  684 */                 bool = false;
/*      */               } 
/*  686 */               rewind(j);
/*  687 */               this.inputState.guessing--;
/*      */             } 
/*  689 */             if (bool) {
/*  690 */               i = typeSpecifier(i);
/*  691 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */             } 
/*  694 */             if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/*  697 */         b++;
/*      */       } 
/*      */       
/*  700 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/*  702 */     catch (RecognitionException recognitionException) {
/*  703 */       if (this.inputState.guessing == 0) {
/*  704 */         reportError(recognitionException);
/*  705 */         recover(recognitionException, _tokenSet_15);
/*      */       } else {
/*  707 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  710 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void initDeclList(AST paramAST) throws RecognitionException, TokenStreamException {
/*  717 */     this.returnAST = null;
/*  718 */     ASTPair aSTPair = new ASTPair();
/*  719 */     TNode tNode = null;
/*      */     
/*      */     try {
/*  722 */       initDecl(paramAST);
/*  723 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/*  727 */       while (LA(1) == 43) {
/*  728 */         match(43);
/*  729 */         initDecl(paramAST);
/*  730 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  738 */       tNode = (TNode)aSTPair.root;
/*      */     }
/*  740 */     catch (RecognitionException recognitionException) {
/*  741 */       if (this.inputState.guessing == 0) {
/*  742 */         reportError(recognitionException);
/*  743 */         recover(recognitionException, _tokenSet_16);
/*      */       } else {
/*  745 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  748 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void storageClassSpecifier() throws RecognitionException, TokenStreamException {
/*  753 */     this.returnAST = null;
/*  754 */     ASTPair aSTPair = new ASTPair();
/*  755 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/*  758 */       switch (LA(1)) {
/*      */         
/*      */         case 13:
/*  761 */           tNode1 = null;
/*  762 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  763 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  764 */           match(13);
/*  765 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 14:
/*  770 */           tNode1 = null;
/*  771 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  772 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  773 */           match(14);
/*  774 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/*  779 */           tNode1 = null;
/*  780 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  781 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  782 */           match(4);
/*  783 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 15:
/*      */         case 16:
/*  789 */           functionStorageClassSpecifier();
/*  790 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*  791 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  796 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/*  800 */     } catch (RecognitionException recognitionException) {
/*  801 */       if (this.inputState.guessing == 0) {
/*  802 */         reportError(recognitionException);
/*  803 */         recover(recognitionException, _tokenSet_17);
/*      */       } else {
/*  805 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  808 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typeQualifier() throws RecognitionException, TokenStreamException {
/*  813 */     this.returnAST = null;
/*  814 */     ASTPair aSTPair = new ASTPair();
/*  815 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/*  818 */       switch (LA(1)) {
/*      */         
/*      */         case 17:
/*  821 */           tNode1 = null;
/*  822 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  823 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  824 */           match(17);
/*  825 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 6:
/*  830 */           tNode1 = null;
/*  831 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  832 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  833 */           match(6);
/*  834 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  839 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/*  843 */     } catch (RecognitionException recognitionException) {
/*  844 */       if (this.inputState.guessing == 0) {
/*  845 */         reportError(recognitionException);
/*  846 */         recover(recognitionException, _tokenSet_18);
/*      */       } else {
/*  848 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  851 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int typeSpecifier(int paramInt) throws RecognitionException, TokenStreamException {
/*  859 */     this.returnAST = null;
/*  860 */     ASTPair aSTPair = new ASTPair();
/*  861 */     TNode tNode = null;
/*  862 */     int i = paramInt + 1;
/*      */     
/*      */     try {
/*      */       TNode tNode1;
/*  866 */       switch (LA(1)) {
/*      */         
/*      */         case 18:
/*  869 */           tNode1 = null;
/*  870 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  871 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  872 */           match(18);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 19:
/*  877 */           tNode1 = null;
/*  878 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  879 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  880 */           match(19);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 20:
/*  885 */           tNode1 = null;
/*  886 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  887 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  888 */           match(20);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 21:
/*  893 */           tNode1 = null;
/*  894 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  895 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  896 */           match(21);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 22:
/*  901 */           tNode1 = null;
/*  902 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  903 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  904 */           match(22);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 23:
/*  909 */           tNode1 = null;
/*  910 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  911 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  912 */           match(23);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 24:
/*  917 */           tNode1 = null;
/*  918 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  919 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  920 */           match(24);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 25:
/*  925 */           tNode1 = null;
/*  926 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  927 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  928 */           match(25);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 26:
/*  933 */           tNode1 = null;
/*  934 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  935 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  936 */           match(26);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 27:
/*  941 */           tNode1 = null;
/*  942 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  943 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  944 */           match(27);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 28:
/*  949 */           tNode1 = null;
/*  950 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  951 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  952 */           match(28);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 29:
/*  957 */           tNode1 = null;
/*  958 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  959 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  960 */           match(29);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 30:
/*  965 */           tNode1 = null;
/*  966 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  967 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  968 */           match(30);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 31:
/*  973 */           tNode1 = null;
/*  974 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  975 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  976 */           match(31);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 32:
/*  981 */           tNode1 = null;
/*  982 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  983 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  984 */           match(32);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 33:
/*  989 */           tNode1 = null;
/*  990 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  991 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/*  992 */           match(33);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 34:
/*  997 */           tNode1 = null;
/*  998 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/*  999 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1000 */           match(34);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 35:
/* 1005 */           tNode1 = null;
/* 1006 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1007 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1008 */           match(35);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 36:
/* 1013 */           tNode1 = null;
/* 1014 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1015 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1016 */           match(36);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 37:
/* 1021 */           tNode1 = null;
/* 1022 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1023 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1024 */           match(37);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 38:
/* 1029 */           tNode1 = null;
/* 1030 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1031 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1032 */           match(38);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 39:
/* 1037 */           tNode1 = null;
/* 1038 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1039 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1040 */           match(39);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 40:
/* 1045 */           tNode1 = null;
/* 1046 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1047 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1048 */           match(40);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 41:
/* 1053 */           tNode1 = null;
/* 1054 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1055 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1056 */           match(41);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 10:
/*      */         case 11:
/* 1062 */           structOrUnionSpecifier();
/* 1063 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 12:
/* 1068 */           enumSpecifier();
/* 1069 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */         
/*      */         default:
/* 1073 */           if (LA(1) == 42 && paramInt == 0) {
/* 1074 */             typedefName();
/* 1075 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */           } 
/* 1078 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1082 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1084 */     catch (RecognitionException recognitionException) {
/* 1085 */       if (this.inputState.guessing == 0) {
/* 1086 */         reportError(recognitionException);
/* 1087 */         recover(recognitionException, _tokenSet_18);
/*      */       } else {
/* 1089 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1092 */     this.returnAST = (AST)tNode;
/* 1093 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionStorageClassSpecifier() throws RecognitionException, TokenStreamException {
/* 1098 */     this.returnAST = null;
/* 1099 */     ASTPair aSTPair = new ASTPair();
/* 1100 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 1103 */       switch (LA(1)) {
/*      */         
/*      */         case 15:
/* 1106 */           tNode1 = null;
/* 1107 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1108 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1109 */           match(15);
/* 1110 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 16:
/* 1115 */           tNode1 = null;
/* 1116 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1117 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1118 */           match(16);
/* 1119 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1124 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 1128 */     } catch (RecognitionException recognitionException) {
/* 1129 */       if (this.inputState.guessing == 0) {
/* 1130 */         reportError(recognitionException);
/* 1131 */         recover(recognitionException, _tokenSet_17);
/*      */       } else {
/* 1133 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1136 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structOrUnionSpecifier() throws RecognitionException, TokenStreamException {
/* 1141 */     this.returnAST = null;
/* 1142 */     ASTPair aSTPair = new ASTPair();
/* 1143 */     TNode tNode1 = null;
/* 1144 */     TNode tNode2 = null;
/* 1145 */     Token token1 = null;
/* 1146 */     TNode tNode3 = null;
/* 1147 */     Token token2 = null;
/* 1148 */     TNode tNode4 = null;
/* 1149 */     Token token3 = null;
/* 1150 */     TNode tNode5 = null;
/*      */ 
/*      */     
/*      */     try {
/* 1154 */       structOrUnion();
/* 1155 */       tNode2 = (TNode)this.returnAST;
/*      */       
/* 1157 */       boolean bool = false;
/* 1158 */       if (LA(1) == 42 && LA(2) == 7) {
/* 1159 */         int i = mark();
/* 1160 */         bool = true;
/* 1161 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 1164 */           match(42);
/* 1165 */           match(7);
/*      */         
/*      */         }
/* 1168 */         catch (RecognitionException recognitionException) {
/* 1169 */           bool = false;
/*      */         } 
/* 1171 */         rewind(i);
/* 1172 */         this.inputState.guessing--;
/*      */       } 
/* 1174 */       if (bool) {
/* 1175 */         token1 = LT(1);
/* 1176 */         tNode3 = (TNode)this.astFactory.create(token1);
/* 1177 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 1178 */         match(42);
/* 1179 */         token2 = LT(1);
/* 1180 */         tNode4 = (TNode)this.astFactory.create(token2);
/* 1181 */         this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 1182 */         match(7);
/* 1183 */         if (this.inputState.guessing == 0) {
/*      */           
/* 1185 */           String str = tNode2.getText() + " " + tNode3.getText();
/* 1186 */           tNode4.setText(str);
/* 1187 */           pushScope(str);
/*      */         } 
/*      */         
/* 1190 */         structDeclarationList();
/* 1191 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1192 */         if (this.inputState.guessing == 0) {
/* 1193 */           popScope();
/*      */         }
/* 1195 */         match(8);
/*      */       }
/* 1197 */       else if (LA(1) == 7) {
/* 1198 */         token3 = LT(1);
/* 1199 */         tNode5 = (TNode)this.astFactory.create(token3);
/* 1200 */         this.astFactory.addASTChild(aSTPair, (AST)tNode5);
/* 1201 */         match(7);
/* 1202 */         if (this.inputState.guessing == 0) {
/*      */           
/* 1204 */           String str = getAScopeName();
/* 1205 */           tNode5.setText(str);
/* 1206 */           pushScope(str);
/*      */         } 
/*      */         
/* 1209 */         structDeclarationList();
/* 1210 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1211 */         if (this.inputState.guessing == 0) {
/* 1212 */           popScope();
/*      */         }
/* 1214 */         match(8);
/*      */       }
/* 1216 */       else if (LA(1) == 42 && _tokenSet_18.member(LA(2))) {
/* 1217 */         TNode tNode = null;
/* 1218 */         tNode = (TNode)this.astFactory.create(LT(1));
/* 1219 */         this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 1220 */         match(42);
/*      */       } else {
/*      */         
/* 1223 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1227 */       if (this.inputState.guessing == 0) {
/* 1228 */         tNode1 = (TNode)aSTPair.root;
/*      */         
/* 1230 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add((AST)tNode2).add((AST)tNode1));
/*      */         
/* 1232 */         aSTPair.root = (AST)tNode1;
/* 1233 */         aSTPair
/* 1234 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 1235 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 1237 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 1239 */     catch (RecognitionException recognitionException) {
/* 1240 */       if (this.inputState.guessing == 0) {
/* 1241 */         reportError(recognitionException);
/* 1242 */         recover(recognitionException, _tokenSet_18);
/*      */       } else {
/* 1244 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1247 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void enumSpecifier() throws RecognitionException, TokenStreamException {
/* 1252 */     this.returnAST = null;
/* 1253 */     ASTPair aSTPair = new ASTPair();
/* 1254 */     TNode tNode1 = null;
/* 1255 */     Token token = null;
/* 1256 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 1259 */       TNode tNode = null;
/* 1260 */       tNode = (TNode)this.astFactory.create(LT(1));
/* 1261 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 1262 */       match(12);
/*      */       
/* 1264 */       boolean bool = false;
/* 1265 */       if (LA(1) == 42 && LA(2) == 7) {
/* 1266 */         int i = mark();
/* 1267 */         bool = true;
/* 1268 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 1271 */           match(42);
/* 1272 */           match(7);
/*      */         
/*      */         }
/* 1275 */         catch (RecognitionException recognitionException) {
/* 1276 */           bool = false;
/*      */         } 
/* 1278 */         rewind(i);
/* 1279 */         this.inputState.guessing--;
/*      */       } 
/* 1281 */       if (bool) {
/* 1282 */         token = LT(1);
/* 1283 */         tNode2 = (TNode)this.astFactory.create(token);
/* 1284 */         this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1285 */         match(42);
/* 1286 */         TNode tNode3 = null;
/* 1287 */         tNode3 = (TNode)this.astFactory.create(LT(1));
/* 1288 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 1289 */         match(7);
/* 1290 */         enumList(token.getText());
/* 1291 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1292 */         match(8);
/*      */       }
/* 1294 */       else if (LA(1) == 7) {
/* 1295 */         TNode tNode3 = null;
/* 1296 */         tNode3 = (TNode)this.astFactory.create(LT(1));
/* 1297 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 1298 */         match(7);
/* 1299 */         enumList("anonymous");
/* 1300 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1301 */         match(8);
/*      */       }
/* 1303 */       else if (LA(1) == 42 && _tokenSet_18.member(LA(2))) {
/* 1304 */         TNode tNode3 = null;
/* 1305 */         tNode3 = (TNode)this.astFactory.create(LT(1));
/* 1306 */         this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 1307 */         match(42);
/*      */       } else {
/*      */         
/* 1310 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1314 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 1316 */     catch (RecognitionException recognitionException) {
/* 1317 */       if (this.inputState.guessing == 0) {
/* 1318 */         reportError(recognitionException);
/* 1319 */         recover(recognitionException, _tokenSet_18);
/*      */       } else {
/* 1321 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1324 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typedefName() throws RecognitionException, TokenStreamException {
/* 1329 */     this.returnAST = null;
/* 1330 */     ASTPair aSTPair = new ASTPair();
/* 1331 */     TNode tNode1 = null;
/* 1332 */     Token token = null;
/* 1333 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 1336 */       if (!isTypedefName(LT(1).getText()))
/* 1337 */         throw new SemanticException(" isTypedefName ( LT(1).getText() ) "); 
/* 1338 */       token = LT(1);
/* 1339 */       tNode2 = (TNode)this.astFactory.create(token);
/* 1340 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1341 */       match(42);
/* 1342 */       if (this.inputState.guessing == 0) {
/* 1343 */         tNode1 = (TNode)aSTPair.root;
/* 1344 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(113)).add((AST)tNode2));
/* 1345 */         aSTPair.root = (AST)tNode1;
/* 1346 */         aSTPair
/* 1347 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 1348 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 1350 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 1352 */     catch (RecognitionException recognitionException) {
/* 1353 */       if (this.inputState.guessing == 0) {
/* 1354 */         reportError(recognitionException);
/* 1355 */         recover(recognitionException, _tokenSet_18);
/*      */       } else {
/* 1357 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1360 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structOrUnion() throws RecognitionException, TokenStreamException {
/* 1365 */     this.returnAST = null;
/* 1366 */     ASTPair aSTPair = new ASTPair();
/* 1367 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 1370 */       switch (LA(1)) {
/*      */         
/*      */         case 10:
/* 1373 */           tNode1 = null;
/* 1374 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1375 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1376 */           match(10);
/* 1377 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 11:
/* 1382 */           tNode1 = null;
/* 1383 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1384 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1385 */           match(11);
/* 1386 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1391 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 1395 */     } catch (RecognitionException recognitionException) {
/* 1396 */       if (this.inputState.guessing == 0) {
/* 1397 */         reportError(recognitionException);
/* 1398 */         recover(recognitionException, _tokenSet_19);
/*      */       } else {
/* 1400 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1403 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclarationList() throws RecognitionException, TokenStreamException {
/* 1408 */     this.returnAST = null;
/* 1409 */     ASTPair aSTPair = new ASTPair();
/* 1410 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 1414 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 1417 */         if (_tokenSet_20.member(LA(1))) {
/* 1418 */           structDeclaration();
/* 1419 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/* 1422 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 1425 */         b++;
/*      */       } 
/*      */       
/* 1428 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1430 */     catch (RecognitionException recognitionException) {
/* 1431 */       if (this.inputState.guessing == 0) {
/* 1432 */         reportError(recognitionException);
/* 1433 */         recover(recognitionException, _tokenSet_21);
/*      */       } else {
/* 1435 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1438 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclaration() throws RecognitionException, TokenStreamException {
/* 1443 */     this.returnAST = null;
/* 1444 */     ASTPair aSTPair = new ASTPair();
/* 1445 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1448 */       specifierQualifierList();
/* 1449 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1450 */       structDeclaratorList();
/* 1451 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 1453 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 1456 */         if (LA(1) == 9) {
/* 1457 */           match(9);
/*      */         } else {
/*      */           
/* 1460 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 1463 */         b++;
/*      */       } 
/*      */       
/* 1466 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1468 */     catch (RecognitionException recognitionException) {
/* 1469 */       if (this.inputState.guessing == 0) {
/* 1470 */         reportError(recognitionException);
/* 1471 */         recover(recognitionException, _tokenSet_22);
/*      */       } else {
/* 1473 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1476 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void specifierQualifierList() throws RecognitionException, TokenStreamException {
/* 1481 */     this.returnAST = null;
/* 1482 */     ASTPair aSTPair = new ASTPair();
/* 1483 */     TNode tNode = null;
/* 1484 */     int i = 0;
/*      */ 
/*      */     
/*      */     try {
/* 1488 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 1491 */         boolean bool = false;
/* 1492 */         if (_tokenSet_13.member(LA(1)) && _tokenSet_23.member(LA(2))) {
/* 1493 */           int j = mark();
/* 1494 */           bool = true;
/* 1495 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 1498 */             if (LA(1) == 10) {
/* 1499 */               match(10);
/*      */             }
/* 1501 */             else if (LA(1) == 11) {
/* 1502 */               match(11);
/*      */             }
/* 1504 */             else if (LA(1) == 12) {
/* 1505 */               match(12);
/*      */             }
/* 1507 */             else if (_tokenSet_13.member(LA(1))) {
/* 1508 */               typeSpecifier(i);
/*      */             } else {
/*      */               
/* 1511 */               throw new NoViableAltException(LT(1), getFilename());
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1516 */           catch (RecognitionException recognitionException) {
/* 1517 */             bool = false;
/*      */           } 
/* 1519 */           rewind(j);
/* 1520 */           this.inputState.guessing--;
/*      */         } 
/* 1522 */         if (bool) {
/* 1523 */           i = typeSpecifier(i);
/* 1524 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         }
/* 1526 */         else if (LA(1) == 6 || LA(1) == 17) {
/* 1527 */           typeQualifier();
/* 1528 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/* 1531 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 1534 */         b++;
/*      */       } 
/*      */       
/* 1537 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1539 */     catch (RecognitionException recognitionException) {
/* 1540 */       if (this.inputState.guessing == 0) {
/* 1541 */         reportError(recognitionException);
/* 1542 */         recover(recognitionException, _tokenSet_24);
/*      */       } else {
/* 1544 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1547 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclaratorList() throws RecognitionException, TokenStreamException {
/* 1552 */     this.returnAST = null;
/* 1553 */     ASTPair aSTPair = new ASTPair();
/* 1554 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1557 */       structDeclarator();
/* 1558 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 1562 */       while (LA(1) == 43) {
/* 1563 */         match(43);
/* 1564 */         structDeclarator();
/* 1565 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1573 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1575 */     catch (RecognitionException recognitionException) {
/* 1576 */       if (this.inputState.guessing == 0) {
/* 1577 */         reportError(recognitionException);
/* 1578 */         recover(recognitionException, _tokenSet_16);
/*      */       } else {
/* 1580 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1583 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclarator() throws RecognitionException, TokenStreamException {
/* 1588 */     this.returnAST = null;
/* 1589 */     ASTPair aSTPair = new ASTPair();
/* 1590 */     TNode tNode = null;
/*      */     
/*      */     try {
/*      */       TNode tNode1;
/* 1594 */       switch (LA(1)) {
/*      */         
/*      */         case 44:
/* 1597 */           tNode1 = null;
/* 1598 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1599 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1600 */           match(44);
/* 1601 */           constExpr();
/* 1602 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/* 1609 */           declarator(false);
/* 1610 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           
/* 1612 */           switch (LA(1)) {
/*      */             
/*      */             case 44:
/* 1615 */               tNode1 = null;
/* 1616 */               tNode1 = (TNode)this.astFactory.create(LT(1));
/* 1617 */               this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 1618 */               match(44);
/* 1619 */               constExpr();
/* 1620 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/*      */             case 43:
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/* 1630 */           throw new NoViableAltException(LT(1), getFilename());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1638 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 1642 */       if (this.inputState.guessing == 0) {
/* 1643 */         tNode = (TNode)aSTPair.root;
/* 1644 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(116)).add((AST)tNode));
/* 1645 */         aSTPair.root = (AST)tNode;
/* 1646 */         aSTPair
/* 1647 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 1648 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 1650 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1652 */     catch (RecognitionException recognitionException) {
/* 1653 */       if (this.inputState.guessing == 0) {
/* 1654 */         reportError(recognitionException);
/* 1655 */         recover(recognitionException, _tokenSet_25);
/*      */       } else {
/* 1657 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1660 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void constExpr() throws RecognitionException, TokenStreamException {
/* 1665 */     this.returnAST = null;
/* 1666 */     ASTPair aSTPair = new ASTPair();
/* 1667 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1670 */       conditionalExpr();
/* 1671 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1672 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1674 */     catch (RecognitionException recognitionException) {
/* 1675 */       if (this.inputState.guessing == 0) {
/* 1676 */         reportError(recognitionException);
/* 1677 */         recover(recognitionException, _tokenSet_26);
/*      */       } else {
/* 1679 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1682 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String declarator(boolean paramBoolean) throws RecognitionException, TokenStreamException {
/* 1690 */     this.returnAST = null;
/* 1691 */     ASTPair aSTPair = new ASTPair();
/* 1692 */     TNode tNode1 = null;
/* 1693 */     Token token = null;
/* 1694 */     TNode tNode2 = null;
/* 1695 */     TNode tNode3 = null;
/* 1696 */     TNode tNode4 = null;
/* 1697 */     String str = "";
/*      */     
/*      */     try {
/*      */       TNode tNode5, tNode6;
/* 1701 */       switch (LA(1)) {
/*      */         
/*      */         case 46:
/* 1704 */           pointerGroup();
/* 1705 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1715 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1720 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/* 1723 */           token = LT(1);
/* 1724 */           tNode2 = (TNode)this.astFactory.create(token);
/* 1725 */           this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1726 */           match(42);
/* 1727 */           if (this.inputState.guessing == 0) {
/* 1728 */             str = token.getText();
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/* 1734 */           tNode5 = null;
/* 1735 */           tNode5 = (TNode)this.astFactory.create(LT(1));
/* 1736 */           this.astFactory.addASTChild(aSTPair, (AST)tNode5);
/* 1737 */           match(47);
/* 1738 */           str = declarator(false);
/* 1739 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 1740 */           tNode6 = null;
/* 1741 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 1742 */           this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 1743 */           match(48);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1748 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/*      */       while (true) {
/*      */         boolean bool;
/*      */         TNode tNode;
/* 1755 */         switch (LA(1)) {
/*      */           
/*      */           case 47:
/* 1758 */             tNode5 = null;
/* 1759 */             tNode5 = (TNode)this.astFactory.create(LT(1));
/* 1760 */             match(47);
/* 1761 */             if (this.inputState.guessing == 0)
/*      */             {
/* 1763 */               if (paramBoolean) {
/* 1764 */                 pushScope(str);
/*      */               } else {
/*      */                 
/* 1767 */                 pushScope("!" + str);
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/* 1772 */             bool = false;
/* 1773 */             if (_tokenSet_2.member(LA(1)) && _tokenSet_27.member(LA(2))) {
/* 1774 */               int i = mark();
/* 1775 */               bool = true;
/* 1776 */               this.inputState.guessing++;
/*      */               
/*      */               try {
/* 1779 */                 declSpecifiers();
/*      */               
/*      */               }
/* 1782 */               catch (RecognitionException recognitionException) {
/* 1783 */                 bool = false;
/*      */               } 
/* 1785 */               rewind(i);
/* 1786 */               this.inputState.guessing--;
/*      */             } 
/* 1788 */             if (bool) {
/* 1789 */               parameterTypeList();
/* 1790 */               tNode3 = (TNode)this.returnAST;
/* 1791 */               if (this.inputState.guessing == 0) {
/* 1792 */                 tNode1 = (TNode)aSTPair.root;
/*      */                 
/* 1794 */                 tNode1 = (TNode)this.astFactory.make((new ASTArray(3)).add(null).add((AST)tNode1).add(this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(126)).add((AST)tNode3))));
/*      */                 
/* 1796 */                 aSTPair.root = (AST)tNode1;
/* 1797 */                 aSTPair
/* 1798 */                   .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 1799 */                 aSTPair.advanceChildToEnd();
/*      */               }
/*      */             
/* 1802 */             } else if ((LA(1) == 42 || LA(1) == 48) && _tokenSet_28.member(LA(2))) {
/*      */               
/* 1804 */               switch (LA(1)) {
/*      */                 
/*      */                 case 42:
/* 1807 */                   idList();
/* 1808 */                   tNode4 = (TNode)this.returnAST;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 48:
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 default:
/* 1817 */                   throw new NoViableAltException(LT(1), getFilename());
/*      */               } 
/*      */ 
/*      */               
/* 1821 */               if (this.inputState.guessing == 0) {
/* 1822 */                 tNode1 = (TNode)aSTPair.root;
/*      */                 
/* 1824 */                 tNode1 = (TNode)this.astFactory.make((new ASTArray(3)).add(null).add((AST)tNode1).add(this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(126)).add((AST)tNode4))));
/*      */                 
/* 1826 */                 aSTPair.root = (AST)tNode1;
/* 1827 */                 aSTPair
/* 1828 */                   .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 1829 */                 aSTPair.advanceChildToEnd();
/*      */               } 
/*      */             } else {
/*      */               
/* 1833 */               throw new NoViableAltException(LT(1), getFilename());
/*      */             } 
/*      */ 
/*      */             
/* 1837 */             if (this.inputState.guessing == 0)
/*      */             {
/* 1839 */               popScope();
/*      */             }
/*      */             
/* 1842 */             tNode = null;
/* 1843 */             tNode = (TNode)this.astFactory.create(LT(1));
/* 1844 */             match(48);
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 49:
/* 1849 */             tNode5 = null;
/* 1850 */             tNode5 = (TNode)this.astFactory.create(LT(1));
/* 1851 */             this.astFactory.addASTChild(aSTPair, (AST)tNode5);
/* 1852 */             match(49);
/*      */             
/* 1854 */             switch (LA(1)) {
/*      */               
/*      */               case 42:
/*      */               case 46:
/*      */               case 47:
/*      */               case 79:
/*      */               case 88:
/*      */               case 89:
/*      */               case 92:
/*      */               case 93:
/*      */               case 94:
/*      */               case 95:
/*      */               case 96:
/*      */               case 99:
/*      */               case 100:
/*      */               case 101:
/*      */               case 102:
/*      */               case 103:
/*      */               case 104:
/*      */               case 105:
/*      */               case 106:
/*      */               case 107:
/*      */               case 108:
/*      */               case 109:
/*      */               case 110:
/*      */               case 111:
/*      */               case 112:
/* 1881 */                 constExpr();
/* 1882 */                 this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 50:
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1891 */                 throw new NoViableAltException(LT(1), getFilename());
/*      */             } 
/*      */ 
/*      */             
/* 1895 */             tNode = null;
/* 1896 */             tNode = (TNode)this.astFactory.create(LT(1));
/* 1897 */             this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 1898 */             match(50);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1908 */       if (this.inputState.guessing == 0) {
/* 1909 */         tNode1 = (TNode)aSTPair.root;
/* 1910 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(115)).add((AST)tNode1));
/* 1911 */         aSTPair.root = (AST)tNode1;
/* 1912 */         aSTPair
/* 1913 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 1914 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 1916 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 1918 */     catch (RecognitionException recognitionException) {
/* 1919 */       if (this.inputState.guessing == 0) {
/* 1920 */         reportError(recognitionException);
/* 1921 */         recover(recognitionException, _tokenSet_29);
/*      */       } else {
/* 1923 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1926 */     this.returnAST = (AST)tNode1;
/* 1927 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void enumList(String paramString) throws RecognitionException, TokenStreamException {
/* 1934 */     this.returnAST = null;
/* 1935 */     ASTPair aSTPair = new ASTPair();
/* 1936 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 1939 */       enumerator(paramString);
/* 1940 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 1944 */       while (LA(1) == 43) {
/* 1945 */         match(43);
/* 1946 */         enumerator(paramString);
/* 1947 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1955 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 1957 */     catch (RecognitionException recognitionException) {
/* 1958 */       if (this.inputState.guessing == 0) {
/* 1959 */         reportError(recognitionException);
/* 1960 */         recover(recognitionException, _tokenSet_21);
/*      */       } else {
/* 1962 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1965 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void enumerator(String paramString) throws RecognitionException, TokenStreamException {
/* 1972 */     this.returnAST = null;
/* 1973 */     ASTPair aSTPair = new ASTPair();
/* 1974 */     TNode tNode1 = null;
/* 1975 */     Token token = null;
/* 1976 */     TNode tNode2 = null;
/*      */     try {
/*      */       TNode tNode;
/* 1979 */       token = LT(1);
/* 1980 */       tNode2 = (TNode)this.astFactory.create(token);
/* 1981 */       this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 1982 */       match(42);
/* 1983 */       if (this.inputState.guessing == 0) {
/* 1984 */         this.symbolTable.add(token.getText(), (TNode)this.astFactory
/* 1985 */             .make((new ASTArray(3)).add(null).add(this.astFactory.create(12, "enum")).add(this.astFactory.create(42, paramString))));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1990 */       switch (LA(1)) {
/*      */         
/*      */         case 45:
/* 1993 */           tNode = null;
/* 1994 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 1995 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 1996 */           match(45);
/* 1997 */           constExpr();
/* 1998 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 43:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2008 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2012 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 2014 */     catch (RecognitionException recognitionException) {
/* 2015 */       if (this.inputState.guessing == 0) {
/* 2016 */         reportError(recognitionException);
/* 2017 */         recover(recognitionException, _tokenSet_30);
/*      */       } else {
/* 2019 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2022 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void initDecl(AST paramAST) throws RecognitionException, TokenStreamException {
/* 2029 */     this.returnAST = null;
/* 2030 */     ASTPair aSTPair = new ASTPair();
/* 2031 */     TNode tNode1 = null;
/* 2032 */     TNode tNode2 = null;
/* 2033 */     String str = "";
/*      */     try {
/*      */       TNode tNode;
/* 2036 */       str = declarator(false);
/* 2037 */       tNode2 = (TNode)this.returnAST;
/* 2038 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2039 */       if (this.inputState.guessing == 0) {
/*      */         
/* 2041 */         AST aST1 = this.astFactory.dupList(paramAST);
/* 2042 */         AST aST2 = this.astFactory.dupList((AST)tNode2);
/* 2043 */         this.symbolTable.add(str, (TNode)this.astFactory.make((new ASTArray(3)).add(null).add(aST1).add(aST2)));
/*      */       } 
/*      */ 
/*      */       
/* 2047 */       switch (LA(1)) {
/*      */         
/*      */         case 45:
/* 2050 */           tNode = null;
/* 2051 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 2052 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 2053 */           match(45);
/* 2054 */           initializer();
/* 2055 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/* 2060 */           tNode = null;
/* 2061 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 2062 */           this.astFactory.addASTChild(aSTPair, (AST)tNode);
/* 2063 */           match(44);
/* 2064 */           expr();
/* 2065 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */         case 43:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2075 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2079 */       if (this.inputState.guessing == 0) {
/* 2080 */         tNode1 = (TNode)aSTPair.root;
/* 2081 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(114)).add((AST)tNode1));
/* 2082 */         aSTPair.root = (AST)tNode1;
/* 2083 */         aSTPair
/* 2084 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 2085 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 2087 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 2089 */     catch (RecognitionException recognitionException) {
/* 2090 */       if (this.inputState.guessing == 0) {
/* 2091 */         reportError(recognitionException);
/* 2092 */         recover(recognitionException, _tokenSet_25);
/*      */       } else {
/* 2094 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2097 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void initializer() throws RecognitionException, TokenStreamException {
/* 2102 */     this.returnAST = null;
/* 2103 */     ASTPair aSTPair = new ASTPair();
/* 2104 */     TNode tNode = null;
/*      */     
/*      */     try {
/*      */       TNode tNode1;
/* 2108 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*      */         case 79:
/*      */         case 88:
/*      */         case 89:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 99:
/*      */         case 100:
/*      */         case 101:
/*      */         case 102:
/*      */         case 103:
/*      */         case 104:
/*      */         case 105:
/*      */         case 106:
/*      */         case 107:
/*      */         case 108:
/*      */         case 109:
/*      */         case 110:
/*      */         case 111:
/*      */         case 112:
/* 2135 */           assignExpr();
/* 2136 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/* 2141 */           tNode1 = null;
/* 2142 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2143 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2144 */           match(7);
/* 2145 */           initializerList();
/* 2146 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           
/* 2148 */           switch (LA(1)) {
/*      */             
/*      */             case 43:
/* 2151 */               match(43);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 8:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 2160 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 2164 */           match(8);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2169 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2173 */       if (this.inputState.guessing == 0) {
/* 2174 */         tNode = (TNode)aSTPair.root;
/* 2175 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(123)).add((AST)tNode));
/* 2176 */         aSTPair.root = (AST)tNode;
/* 2177 */         aSTPair
/* 2178 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 2179 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 2181 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2183 */     catch (RecognitionException recognitionException) {
/* 2184 */       if (this.inputState.guessing == 0) {
/* 2185 */         reportError(recognitionException);
/* 2186 */         recover(recognitionException, _tokenSet_31);
/*      */       } else {
/* 2188 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2191 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void pointerGroup() throws RecognitionException, TokenStreamException {
/* 2196 */     this.returnAST = null;
/* 2197 */     ASTPair aSTPair = new ASTPair();
/* 2198 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 2202 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 2205 */         if (LA(1) == 46) {
/* 2206 */           TNode tNode1 = null;
/* 2207 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2208 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2209 */           match(46);
/*      */ 
/*      */ 
/*      */           
/* 2213 */           while (LA(1) == 6 || LA(1) == 17) {
/* 2214 */             typeQualifier();
/* 2215 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 2225 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 2228 */         b++;
/*      */       } 
/*      */       
/* 2231 */       if (this.inputState.guessing == 0) {
/* 2232 */         tNode = (TNode)aSTPair.root;
/* 2233 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(119)).add((AST)tNode));
/* 2234 */         aSTPair.root = (AST)tNode;
/* 2235 */         aSTPair
/* 2236 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 2237 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 2239 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2241 */     catch (RecognitionException recognitionException) {
/* 2242 */       if (this.inputState.guessing == 0) {
/* 2243 */         reportError(recognitionException);
/* 2244 */         recover(recognitionException, _tokenSet_32);
/*      */       } else {
/* 2246 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2249 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void idList() throws RecognitionException, TokenStreamException {
/* 2254 */     this.returnAST = null;
/* 2255 */     ASTPair aSTPair = new ASTPair();
/* 2256 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 2259 */       TNode tNode1 = null;
/* 2260 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2261 */       this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2262 */       match(42);
/*      */ 
/*      */ 
/*      */       
/* 2266 */       while (LA(1) == 43) {
/* 2267 */         match(43);
/* 2268 */         TNode tNode2 = null;
/* 2269 */         tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2270 */         this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2271 */         match(42);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2279 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2281 */     catch (RecognitionException recognitionException) {
/* 2282 */       if (this.inputState.guessing == 0) {
/* 2283 */         reportError(recognitionException);
/* 2284 */         recover(recognitionException, _tokenSet_33);
/*      */       } else {
/* 2286 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2289 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void assignExpr() throws RecognitionException, TokenStreamException {
/* 2294 */     this.returnAST = null;
/* 2295 */     ASTPair aSTPair = new ASTPair();
/* 2296 */     TNode tNode1 = null;
/* 2297 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 2300 */       conditionalExpr();
/* 2301 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 2303 */       switch (LA(1)) {
/*      */         
/*      */         case 45:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/* 2316 */           assignOperator();
/* 2317 */           tNode2 = (TNode)this.returnAST;
/* 2318 */           assignExpr();
/* 2319 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2320 */           if (this.inputState.guessing == 0) {
/* 2321 */             tNode1 = (TNode)aSTPair.root;
/* 2322 */             tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add((AST)tNode2).add((AST)tNode1));
/* 2323 */             aSTPair.root = (AST)tNode1;
/* 2324 */             aSTPair
/* 2325 */               .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 2326 */             aSTPair.advanceChildToEnd();
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 9:
/*      */         case 43:
/*      */         case 44:
/*      */         case 48:
/*      */         case 50:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2341 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2345 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 2347 */     catch (RecognitionException recognitionException) {
/* 2348 */       if (this.inputState.guessing == 0) {
/* 2349 */         reportError(recognitionException);
/* 2350 */         recover(recognitionException, _tokenSet_12);
/*      */       } else {
/* 2352 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2355 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void initializerList() throws RecognitionException, TokenStreamException {
/* 2360 */     this.returnAST = null;
/* 2361 */     ASTPair aSTPair = new ASTPair();
/* 2362 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 2365 */       initializer();
/* 2366 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 2370 */       while (LA(1) == 43 && _tokenSet_34.member(LA(2))) {
/* 2371 */         match(43);
/* 2372 */         initializer();
/* 2373 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2381 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2383 */     catch (RecognitionException recognitionException) {
/* 2384 */       if (this.inputState.guessing == 0) {
/* 2385 */         reportError(recognitionException);
/* 2386 */         recover(recognitionException, _tokenSet_30);
/*      */       } else {
/* 2388 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2391 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void parameterTypeList() throws RecognitionException, TokenStreamException {
/* 2396 */     this.returnAST = null;
/* 2397 */     ASTPair aSTPair = new ASTPair();
/* 2398 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 2401 */       parameterDeclaration();
/* 2402 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 2406 */       while (LA(1) == 43 && _tokenSet_2.member(LA(2))) {
/* 2407 */         match(43);
/* 2408 */         parameterDeclaration();
/* 2409 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2418 */       switch (LA(1)) {
/*      */         
/*      */         case 43:
/* 2421 */           match(43);
/* 2422 */           tNode1 = null;
/* 2423 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2424 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2425 */           match(51);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2434 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2438 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2440 */     catch (RecognitionException recognitionException) {
/* 2441 */       if (this.inputState.guessing == 0) {
/* 2442 */         reportError(recognitionException);
/* 2443 */         recover(recognitionException, _tokenSet_33);
/*      */       } else {
/* 2445 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2448 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void parameterDeclaration() throws RecognitionException, TokenStreamException {
/* 2453 */     this.returnAST = null;
/* 2454 */     ASTPair aSTPair = new ASTPair();
/* 2455 */     TNode tNode1 = null;
/* 2456 */     TNode tNode2 = null;
/* 2457 */     TNode tNode3 = null;
/*      */ 
/*      */     
/*      */     try {
/* 2461 */       declSpecifiers();
/* 2462 */       tNode2 = (TNode)this.returnAST;
/* 2463 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 2465 */       boolean bool = false;
/* 2466 */       if (_tokenSet_10.member(LA(1)) && _tokenSet_35.member(LA(2))) {
/* 2467 */         int i = mark();
/* 2468 */         bool = true;
/* 2469 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 2472 */           declarator(false);
/*      */         
/*      */         }
/* 2475 */         catch (RecognitionException recognitionException) {
/* 2476 */           bool = false;
/*      */         } 
/* 2478 */         rewind(i);
/* 2479 */         this.inputState.guessing--;
/*      */       } 
/* 2481 */       if (bool) {
/* 2482 */         String str = declarator(false);
/* 2483 */         tNode3 = (TNode)this.returnAST;
/* 2484 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 2485 */         if (this.inputState.guessing == 0)
/*      */         {
/*      */           
/* 2488 */           AST aST1 = this.astFactory.dupList((AST)tNode3);
/* 2489 */           AST aST2 = this.astFactory.dupList((AST)tNode2);
/* 2490 */           this.symbolTable.add(str, (TNode)this.astFactory.make((new ASTArray(3)).add(null).add(aST2).add(aST1)));
/*      */         }
/*      */       
/*      */       }
/* 2494 */       else if (_tokenSet_36.member(LA(1)) && _tokenSet_37.member(LA(2))) {
/* 2495 */         nonemptyAbstractDeclarator();
/* 2496 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       }
/* 2498 */       else if (LA(1) != 43 && LA(1) != 48) {
/*      */ 
/*      */         
/* 2501 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2505 */       if (this.inputState.guessing == 0) {
/* 2506 */         tNode1 = (TNode)aSTPair.root;
/*      */         
/* 2508 */         tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(129)).add((AST)tNode1));
/*      */         
/* 2510 */         aSTPair.root = (AST)tNode1;
/* 2511 */         aSTPair
/* 2512 */           .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 2513 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 2515 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 2517 */     catch (RecognitionException recognitionException) {
/* 2518 */       if (this.inputState.guessing == 0) {
/* 2519 */         reportError(recognitionException);
/* 2520 */         recover(recognitionException, _tokenSet_38);
/*      */       } else {
/* 2522 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2525 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void nonemptyAbstractDeclarator() throws RecognitionException, TokenStreamException {
/* 2530 */     this.returnAST = null;
/* 2531 */     ASTPair aSTPair = new ASTPair();
/* 2532 */     TNode tNode = null;
/*      */     
/*      */     try {
/*      */       byte b;
/* 2536 */       switch (LA(1)) {
/*      */         
/*      */         case 46:
/* 2539 */           pointerGroup();
/* 2540 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           while (true) {
/*      */             TNode tNode1;
/*      */             TNode tNode2;
/* 2544 */             switch (LA(1)) {
/*      */ 
/*      */               
/*      */               case 47:
/* 2548 */                 tNode1 = null;
/* 2549 */                 tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2550 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2551 */                 match(47);
/*      */                 
/* 2553 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 49:
/* 2558 */                     nonemptyAbstractDeclarator();
/* 2559 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 4:
/*      */                   case 6:
/*      */                   case 10:
/*      */                   case 11:
/*      */                   case 12:
/*      */                   case 13:
/*      */                   case 14:
/*      */                   case 15:
/*      */                   case 16:
/*      */                   case 17:
/*      */                   case 18:
/*      */                   case 19:
/*      */                   case 20:
/*      */                   case 21:
/*      */                   case 22:
/*      */                   case 23:
/*      */                   case 24:
/*      */                   case 25:
/*      */                   case 26:
/*      */                   case 27:
/*      */                   case 28:
/*      */                   case 29:
/*      */                   case 30:
/*      */                   case 31:
/*      */                   case 32:
/*      */                   case 33:
/*      */                   case 34:
/*      */                   case 35:
/*      */                   case 36:
/*      */                   case 37:
/*      */                   case 38:
/*      */                   case 39:
/*      */                   case 40:
/*      */                   case 41:
/*      */                   case 42:
/* 2598 */                     parameterTypeList();
/* 2599 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 2608 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */                 
/* 2612 */                 tNode2 = null;
/* 2613 */                 tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2614 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2615 */                 match(48);
/*      */                 continue;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 2622 */                 tNode1 = null;
/* 2623 */                 tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2624 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2625 */                 match(49);
/*      */                 
/* 2627 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 42:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 79:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 95:
/*      */                   case 96:
/*      */                   case 99:
/*      */                   case 100:
/*      */                   case 101:
/*      */                   case 102:
/*      */                   case 103:
/*      */                   case 104:
/*      */                   case 105:
/*      */                   case 106:
/*      */                   case 107:
/*      */                   case 108:
/*      */                   case 109:
/*      */                   case 110:
/*      */                   case 111:
/*      */                   case 112:
/* 2654 */                     expr();
/* 2655 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 2664 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */                 
/* 2668 */                 tNode2 = null;
/* 2669 */                 tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2670 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2671 */                 match(50);
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 47:
/*      */         case 49:
/* 2688 */           b = 0;
/*      */           while (true) {
/*      */             TNode tNode1, tNode2;
/* 2691 */             switch (LA(1)) {
/*      */ 
/*      */               
/*      */               case 47:
/* 2695 */                 tNode1 = null;
/* 2696 */                 tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2697 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2698 */                 match(47);
/*      */                 
/* 2700 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 49:
/* 2705 */                     nonemptyAbstractDeclarator();
/* 2706 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 4:
/*      */                   case 6:
/*      */                   case 10:
/*      */                   case 11:
/*      */                   case 12:
/*      */                   case 13:
/*      */                   case 14:
/*      */                   case 15:
/*      */                   case 16:
/*      */                   case 17:
/*      */                   case 18:
/*      */                   case 19:
/*      */                   case 20:
/*      */                   case 21:
/*      */                   case 22:
/*      */                   case 23:
/*      */                   case 24:
/*      */                   case 25:
/*      */                   case 26:
/*      */                   case 27:
/*      */                   case 28:
/*      */                   case 29:
/*      */                   case 30:
/*      */                   case 31:
/*      */                   case 32:
/*      */                   case 33:
/*      */                   case 34:
/*      */                   case 35:
/*      */                   case 36:
/*      */                   case 37:
/*      */                   case 38:
/*      */                   case 39:
/*      */                   case 40:
/*      */                   case 41:
/*      */                   case 42:
/* 2745 */                     parameterTypeList();
/* 2746 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 2755 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */                 
/* 2759 */                 tNode2 = null;
/* 2760 */                 tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2761 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2762 */                 match(48);
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 2769 */                 tNode1 = null;
/* 2770 */                 tNode1 = (TNode)this.astFactory.create(LT(1));
/* 2771 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 2772 */                 match(49);
/*      */                 
/* 2774 */                 switch (LA(1)) {
/*      */                   
/*      */                   case 42:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 79:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 95:
/*      */                   case 96:
/*      */                   case 99:
/*      */                   case 100:
/*      */                   case 101:
/*      */                   case 102:
/*      */                   case 103:
/*      */                   case 104:
/*      */                   case 105:
/*      */                   case 106:
/*      */                   case 107:
/*      */                   case 108:
/*      */                   case 109:
/*      */                   case 110:
/*      */                   case 111:
/*      */                   case 112:
/* 2801 */                     expr();
/* 2802 */                     this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 2811 */                     throw new NoViableAltException(LT(1), getFilename());
/*      */                 } 
/*      */ 
/*      */                 
/* 2815 */                 tNode2 = null;
/* 2816 */                 tNode2 = (TNode)this.astFactory.create(LT(1));
/* 2817 */                 this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 2818 */                 match(50);
/*      */                 break;
/*      */ 
/*      */ 
/*      */               
/*      */               default:
/* 2824 */                 if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */             } 
/*      */             
/* 2827 */             b++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 2834 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 2838 */       if (this.inputState.guessing == 0) {
/* 2839 */         tNode = (TNode)aSTPair.root;
/* 2840 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(122)).add((AST)tNode));
/* 2841 */         aSTPair.root = (AST)tNode;
/* 2842 */         aSTPair
/* 2843 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 2844 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 2846 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2848 */     catch (RecognitionException recognitionException) {
/* 2849 */       if (this.inputState.guessing == 0) {
/* 2850 */         reportError(recognitionException);
/* 2851 */         recover(recognitionException, _tokenSet_38);
/*      */       } else {
/* 2853 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2856 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionDeclSpecifiers() throws RecognitionException, TokenStreamException {
/* 2861 */     this.returnAST = null;
/* 2862 */     ASTPair aSTPair = new ASTPair();
/* 2863 */     TNode tNode = null;
/* 2864 */     int i = 0;
/*      */ 
/*      */     
/*      */     try {
/* 2868 */       byte b = 0;
/*      */       while (true) {
/*      */         boolean bool;
/* 2871 */         switch (LA(1)) {
/*      */           
/*      */           case 15:
/*      */           case 16:
/* 2875 */             functionStorageClassSpecifier();
/* 2876 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/* 2882 */             typeQualifier();
/* 2883 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */           
/*      */           default:
/* 2887 */             bool = false;
/* 2888 */             if (_tokenSet_13.member(LA(1)) && _tokenSet_9.member(LA(2))) {
/* 2889 */               int j = mark();
/* 2890 */               bool = true;
/* 2891 */               this.inputState.guessing++;
/*      */               
/*      */               try {
/* 2894 */                 if (LA(1) == 10) {
/* 2895 */                   match(10);
/*      */                 }
/* 2897 */                 else if (LA(1) == 11) {
/* 2898 */                   match(11);
/*      */                 }
/* 2900 */                 else if (LA(1) == 12) {
/* 2901 */                   match(12);
/*      */                 }
/* 2903 */                 else if (_tokenSet_13.member(LA(1))) {
/* 2904 */                   typeSpecifier(i);
/*      */                 } else {
/*      */                   
/* 2907 */                   throw new NoViableAltException(LT(1), getFilename());
/*      */                 
/*      */                 }
/*      */               
/*      */               }
/* 2912 */               catch (RecognitionException recognitionException) {
/* 2913 */                 bool = false;
/*      */               } 
/* 2915 */               rewind(j);
/* 2916 */               this.inputState.guessing--;
/*      */             } 
/* 2918 */             if (bool) {
/* 2919 */               i = typeSpecifier(i);
/* 2920 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */             } 
/* 2923 */             if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 2926 */         b++;
/*      */       } 
/*      */       
/* 2929 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 2931 */     catch (RecognitionException recognitionException) {
/* 2932 */       if (this.inputState.guessing == 0) {
/* 2933 */         reportError(recognitionException);
/* 2934 */         recover(recognitionException, _tokenSet_10);
/*      */       } else {
/* 2936 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2939 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void compoundStatement(String paramString) throws RecognitionException, TokenStreamException {
/* 2946 */     this.returnAST = null;
/* 2947 */     ASTPair aSTPair = new ASTPair();
/* 2948 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 2951 */       match(7);
/* 2952 */       if (this.inputState.guessing == 0)
/*      */       {
/* 2954 */         pushScope(paramString);
/*      */       }
/*      */ 
/*      */       
/* 2958 */       boolean bool = false;
/* 2959 */       if (_tokenSet_2.member(LA(1)) && _tokenSet_3.member(LA(2))) {
/* 2960 */         int i = mark();
/* 2961 */         bool = true;
/* 2962 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 2965 */           declarationPredictor();
/*      */         
/*      */         }
/* 2968 */         catch (RecognitionException recognitionException) {
/* 2969 */           bool = false;
/*      */         } 
/* 2971 */         rewind(i);
/* 2972 */         this.inputState.guessing--;
/*      */       } 
/* 2974 */       if (bool) {
/* 2975 */         declarationList();
/* 2976 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       }
/* 2978 */       else if (!_tokenSet_39.member(LA(1)) || !_tokenSet_40.member(LA(2))) {
/*      */ 
/*      */         
/* 2981 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2986 */       switch (LA(1)) {
/*      */         
/*      */         case 7:
/*      */         case 9:
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*      */         case 52:
/*      */         case 53:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 63:
/*      */         case 79:
/*      */         case 88:
/*      */         case 89:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 99:
/*      */         case 100:
/*      */         case 101:
/*      */         case 102:
/*      */         case 103:
/*      */         case 104:
/*      */         case 105:
/*      */         case 106:
/*      */         case 107:
/*      */         case 108:
/*      */         case 109:
/*      */         case 110:
/*      */         case 111:
/*      */         case 112:
/* 3026 */           statementList();
/* 3027 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3036 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3040 */       if (this.inputState.guessing == 0) {
/* 3041 */         popScope();
/*      */       }
/* 3043 */       match(8);
/* 3044 */       if (this.inputState.guessing == 0) {
/* 3045 */         tNode = (TNode)aSTPair.root;
/* 3046 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(128, paramString)).add((AST)tNode));
/* 3047 */         aSTPair.root = (AST)tNode;
/* 3048 */         aSTPair
/* 3049 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 3050 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 3052 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3054 */     catch (RecognitionException recognitionException) {
/* 3055 */       if (this.inputState.guessing == 0) {
/* 3056 */         reportError(recognitionException);
/* 3057 */         recover(recognitionException, _tokenSet_41);
/*      */       } else {
/* 3059 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3062 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void declarationList() throws RecognitionException, TokenStreamException {
/* 3067 */     this.returnAST = null;
/* 3068 */     ASTPair aSTPair = new ASTPair();
/* 3069 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 3073 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 3076 */         boolean bool = false;
/* 3077 */         if (_tokenSet_2.member(LA(1)) && _tokenSet_3.member(LA(2))) {
/* 3078 */           int i = mark();
/* 3079 */           bool = true;
/* 3080 */           this.inputState.guessing++;
/*      */           
/*      */           try {
/* 3083 */             declarationPredictor();
/*      */           
/*      */           }
/* 3086 */           catch (RecognitionException recognitionException) {
/* 3087 */             bool = false;
/*      */           } 
/* 3089 */           rewind(i);
/* 3090 */           this.inputState.guessing--;
/*      */         } 
/* 3092 */         if (bool) {
/* 3093 */           declaration();
/* 3094 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/* 3097 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 3100 */         b++;
/*      */       } 
/*      */       
/* 3103 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3105 */     catch (RecognitionException recognitionException) {
/* 3106 */       if (this.inputState.guessing == 0) {
/* 3107 */         reportError(recognitionException);
/* 3108 */         recover(recognitionException, _tokenSet_39);
/*      */       } else {
/* 3110 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3113 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void declarationPredictor() throws RecognitionException, TokenStreamException {
/* 3118 */     this.returnAST = null;
/* 3119 */     ASTPair aSTPair = new ASTPair();
/* 3120 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 3124 */       if (LA(1) == 4 && LA(2) == 1) {
/* 3125 */         TNode tNode1 = null;
/* 3126 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3127 */         this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3128 */         match(4);
/*      */       }
/* 3130 */       else if (_tokenSet_2.member(LA(1)) && _tokenSet_3.member(LA(2))) {
/* 3131 */         declaration();
/* 3132 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } else {
/*      */         
/* 3135 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3139 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3141 */     catch (RecognitionException recognitionException) {
/* 3142 */       if (this.inputState.guessing == 0) {
/* 3143 */         reportError(recognitionException);
/* 3144 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/* 3146 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3149 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void statementList() throws RecognitionException, TokenStreamException {
/* 3154 */     this.returnAST = null;
/* 3155 */     ASTPair aSTPair = new ASTPair();
/* 3156 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 3160 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 3163 */         if (_tokenSet_42.member(LA(1))) {
/* 3164 */           statement();
/* 3165 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         } else {
/*      */           
/* 3168 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 3171 */         b++;
/*      */       } 
/*      */       
/* 3174 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3176 */     catch (RecognitionException recognitionException) {
/* 3177 */       if (this.inputState.guessing == 0) {
/* 3178 */         reportError(recognitionException);
/* 3179 */         recover(recognitionException, _tokenSet_21);
/*      */       } else {
/* 3181 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3184 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void statement() throws RecognitionException, TokenStreamException {
/* 3189 */     this.returnAST = null;
/* 3190 */     ASTPair aSTPair = new ASTPair();
/* 3191 */     TNode tNode1 = null;
/* 3192 */     TNode tNode2 = null;
/* 3193 */     TNode tNode3 = null;
/* 3194 */     TNode tNode4 = null;
/* 3195 */     TNode tNode5 = null; try {
/*      */       TNode tNode6; TNode tNode7; TNode tNode8;
/*      */       TNode tNode9;
/* 3198 */       switch (LA(1)) {
/*      */         
/*      */         case 9:
/* 3201 */           tNode6 = null;
/* 3202 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3203 */           this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 3204 */           match(9);
/* 3205 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/* 3210 */           compoundStatement(getAScopeName());
/* 3211 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3212 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 52:
/* 3217 */           tNode6 = null;
/* 3218 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3219 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 3220 */           match(52);
/* 3221 */           match(47);
/* 3222 */           expr();
/* 3223 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3224 */           match(48);
/* 3225 */           statement();
/* 3226 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3227 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 53:
/* 3232 */           tNode6 = null;
/* 3233 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3234 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 3235 */           match(53);
/* 3236 */           statement();
/* 3237 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3238 */           match(52);
/* 3239 */           match(47);
/* 3240 */           expr();
/* 3241 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3242 */           match(48);
/* 3243 */           match(9);
/* 3244 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 54:
/* 3249 */           match(54);
/* 3250 */           tNode6 = null;
/* 3251 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3252 */           match(47);
/*      */           
/* 3254 */           switch (LA(1)) {
/*      */             
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 101:
/*      */             case 102:
/*      */             case 103:
/*      */             case 104:
/*      */             case 105:
/*      */             case 106:
/*      */             case 107:
/*      */             case 108:
/*      */             case 109:
/*      */             case 110:
/*      */             case 111:
/*      */             case 112:
/* 3281 */               expr();
/* 3282 */               tNode2 = (TNode)this.returnAST;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3291 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 3295 */           tNode7 = null;
/* 3296 */           tNode7 = (TNode)this.astFactory.create(LT(1));
/* 3297 */           match(9);
/*      */           
/* 3299 */           switch (LA(1)) {
/*      */             
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 101:
/*      */             case 102:
/*      */             case 103:
/*      */             case 104:
/*      */             case 105:
/*      */             case 106:
/*      */             case 107:
/*      */             case 108:
/*      */             case 109:
/*      */             case 110:
/*      */             case 111:
/*      */             case 112:
/* 3326 */               expr();
/* 3327 */               tNode3 = (TNode)this.returnAST;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3336 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 3340 */           tNode8 = null;
/* 3341 */           tNode8 = (TNode)this.astFactory.create(LT(1));
/* 3342 */           match(9);
/*      */           
/* 3344 */           switch (LA(1)) {
/*      */             
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 101:
/*      */             case 102:
/*      */             case 103:
/*      */             case 104:
/*      */             case 105:
/*      */             case 106:
/*      */             case 107:
/*      */             case 108:
/*      */             case 109:
/*      */             case 110:
/*      */             case 111:
/*      */             case 112:
/* 3371 */               expr();
/* 3372 */               tNode4 = (TNode)this.returnAST;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 48:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3381 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 3385 */           tNode9 = null;
/* 3386 */           tNode9 = (TNode)this.astFactory.create(LT(1));
/* 3387 */           match(48);
/* 3388 */           statement();
/* 3389 */           tNode5 = (TNode)this.returnAST;
/* 3390 */           if (this.inputState.guessing == 0) {
/* 3391 */             tNode1 = (TNode)aSTPair.root;
/*      */             
/* 3393 */             if (tNode2 == null) tNode2 = (TNode)this.astFactory.create(125); 
/* 3394 */             if (tNode3 == null) tNode3 = (TNode)this.astFactory.create(125); 
/* 3395 */             if (tNode4 == null) tNode4 = (TNode)this.astFactory.create(125); 
/* 3396 */             tNode1 = (TNode)this.astFactory.make((new ASTArray(5)).add(this.astFactory.create(54, "for")).add((AST)tNode2).add((AST)tNode3).add((AST)tNode4).add((AST)tNode5));
/*      */             
/* 3398 */             aSTPair.root = (AST)tNode1;
/* 3399 */             aSTPair
/* 3400 */               .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 3401 */             aSTPair.advanceChildToEnd();
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 55:
/* 3407 */           tNode6 = null;
/* 3408 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3409 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 3410 */           match(55);
/* 3411 */           tNode7 = null;
/* 3412 */           tNode7 = (TNode)this.astFactory.create(LT(1));
/* 3413 */           this.astFactory.addASTChild(aSTPair, (AST)tNode7);
/* 3414 */           match(42);
/* 3415 */           match(9);
/* 3416 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 56:
/* 3421 */           tNode6 = null;
/* 3422 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3423 */           this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 3424 */           match(56);
/* 3425 */           match(9);
/* 3426 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 57:
/* 3431 */           tNode6 = null;
/* 3432 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3433 */           this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 3434 */           match(57);
/* 3435 */           match(9);
/* 3436 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 58:
/* 3441 */           tNode6 = null;
/* 3442 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3443 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 3444 */           match(58);
/*      */           
/* 3446 */           switch (LA(1)) {
/*      */             
/*      */             case 42:
/*      */             case 46:
/*      */             case 47:
/*      */             case 79:
/*      */             case 88:
/*      */             case 89:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 95:
/*      */             case 96:
/*      */             case 99:
/*      */             case 100:
/*      */             case 101:
/*      */             case 102:
/*      */             case 103:
/*      */             case 104:
/*      */             case 105:
/*      */             case 106:
/*      */             case 107:
/*      */             case 108:
/*      */             case 109:
/*      */             case 110:
/*      */             case 111:
/*      */             case 112:
/* 3473 */               expr();
/* 3474 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3483 */               throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 3487 */           match(9);
/* 3488 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 59:
/* 3493 */           tNode6 = null;
/* 3494 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3495 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 3496 */           match(59);
/* 3497 */           constExpr();
/* 3498 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3499 */           match(44);
/* 3500 */           statement();
/* 3501 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3502 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 60:
/* 3507 */           tNode6 = null;
/* 3508 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3509 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 3510 */           match(60);
/* 3511 */           match(44);
/* 3512 */           statement();
/* 3513 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3514 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 61:
/* 3519 */           tNode6 = null;
/* 3520 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3521 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 3522 */           match(61);
/* 3523 */           match(47);
/* 3524 */           expr();
/* 3525 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3526 */           match(48);
/* 3527 */           statement();
/* 3528 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           
/* 3530 */           if (LA(1) == 62 && _tokenSet_42.member(LA(2))) {
/* 3531 */             tNode7 = null;
/* 3532 */             tNode7 = (TNode)this.astFactory.create(LT(1));
/* 3533 */             this.astFactory.addASTChild(aSTPair, (AST)tNode7);
/* 3534 */             match(62);
/* 3535 */             statement();
/* 3536 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           }
/* 3538 */           else if (!_tokenSet_43.member(LA(1)) || !_tokenSet_40.member(LA(2))) {
/*      */ 
/*      */             
/* 3541 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 3545 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 63:
/* 3550 */           tNode6 = null;
/* 3551 */           tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3552 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode6);
/* 3553 */           match(63);
/* 3554 */           match(47);
/* 3555 */           expr();
/* 3556 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3557 */           match(48);
/* 3558 */           statement();
/* 3559 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3560 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */         
/*      */         default:
/* 3564 */           if (_tokenSet_11.member(LA(1)) && _tokenSet_44.member(LA(2))) {
/* 3565 */             expr();
/* 3566 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3567 */             match(9);
/* 3568 */             if (this.inputState.guessing == 0) {
/* 3569 */               tNode1 = (TNode)aSTPair.root;
/* 3570 */               tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(124)).add((AST)tNode1));
/* 3571 */               aSTPair.root = (AST)tNode1;
/* 3572 */               aSTPair
/* 3573 */                 .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 3574 */               aSTPair.advanceChildToEnd();
/*      */             } 
/* 3576 */             tNode1 = (TNode)aSTPair.root; break;
/*      */           } 
/* 3578 */           if (LA(1) == 42 && LA(2) == 44) {
/* 3579 */             tNode6 = null;
/* 3580 */             tNode6 = (TNode)this.astFactory.create(LT(1));
/* 3581 */             this.astFactory.addASTChild(aSTPair, (AST)tNode6);
/* 3582 */             match(42);
/* 3583 */             match(44);
/*      */             
/* 3585 */             if (_tokenSet_42.member(LA(1)) && _tokenSet_45.member(LA(2))) {
/* 3586 */               statement();
/* 3587 */               this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             }
/* 3589 */             else if (!_tokenSet_43.member(LA(1)) || !_tokenSet_40.member(LA(2))) {
/*      */ 
/*      */               
/* 3592 */               throw new NoViableAltException(LT(1), getFilename());
/*      */             } 
/*      */ 
/*      */             
/* 3596 */             if (this.inputState.guessing == 0) {
/* 3597 */               tNode1 = (TNode)aSTPair.root;
/* 3598 */               tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(132)).add((AST)tNode1));
/* 3599 */               aSTPair.root = (AST)tNode1;
/* 3600 */               aSTPair
/* 3601 */                 .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 3602 */               aSTPair.advanceChildToEnd();
/*      */             } 
/* 3604 */             tNode1 = (TNode)aSTPair.root;
/*      */             break;
/*      */           } 
/* 3607 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 3611 */     } catch (RecognitionException recognitionException) {
/* 3612 */       if (this.inputState.guessing == 0) {
/* 3613 */         reportError(recognitionException);
/* 3614 */         recover(recognitionException, _tokenSet_43);
/*      */       } else {
/* 3616 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3619 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void conditionalExpr() throws RecognitionException, TokenStreamException {
/* 3624 */     this.returnAST = null;
/* 3625 */     ASTPair aSTPair = new ASTPair();
/* 3626 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 3629 */       logicalOrExpr();
/* 3630 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 3632 */       switch (LA(1)) {
/*      */         
/*      */         case 74:
/* 3635 */           tNode1 = null;
/* 3636 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3637 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 3638 */           match(74);
/* 3639 */           expr();
/* 3640 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 3641 */           match(44);
/* 3642 */           conditionalExpr();
/* 3643 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 9:
/*      */         case 43:
/*      */         case 44:
/*      */         case 45:
/*      */         case 48:
/*      */         case 50:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3668 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 3672 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3674 */     catch (RecognitionException recognitionException) {
/* 3675 */       if (this.inputState.guessing == 0) {
/* 3676 */         reportError(recognitionException);
/* 3677 */         recover(recognitionException, _tokenSet_46);
/*      */       } else {
/* 3679 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3682 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void assignOperator() throws RecognitionException, TokenStreamException {
/* 3687 */     this.returnAST = null;
/* 3688 */     ASTPair aSTPair = new ASTPair();
/* 3689 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 3692 */       switch (LA(1)) {
/*      */         
/*      */         case 45:
/* 3695 */           tNode1 = null;
/* 3696 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3697 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3698 */           match(45);
/* 3699 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 64:
/* 3704 */           tNode1 = null;
/* 3705 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3706 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3707 */           match(64);
/* 3708 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 65:
/* 3713 */           tNode1 = null;
/* 3714 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3715 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3716 */           match(65);
/* 3717 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 66:
/* 3722 */           tNode1 = null;
/* 3723 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3724 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3725 */           match(66);
/* 3726 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 67:
/* 3731 */           tNode1 = null;
/* 3732 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3733 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3734 */           match(67);
/* 3735 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 68:
/* 3740 */           tNode1 = null;
/* 3741 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3742 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3743 */           match(68);
/* 3744 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 69:
/* 3749 */           tNode1 = null;
/* 3750 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3751 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3752 */           match(69);
/* 3753 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 70:
/* 3758 */           tNode1 = null;
/* 3759 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3760 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3761 */           match(70);
/* 3762 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 71:
/* 3767 */           tNode1 = null;
/* 3768 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3769 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3770 */           match(71);
/* 3771 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 72:
/* 3776 */           tNode1 = null;
/* 3777 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3778 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3779 */           match(72);
/* 3780 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 73:
/* 3785 */           tNode1 = null;
/* 3786 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3787 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 3788 */           match(73);
/* 3789 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3794 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 3798 */     } catch (RecognitionException recognitionException) {
/* 3799 */       if (this.inputState.guessing == 0) {
/* 3800 */         reportError(recognitionException);
/* 3801 */         recover(recognitionException, _tokenSet_11);
/*      */       } else {
/* 3803 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3806 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalOrExpr() throws RecognitionException, TokenStreamException {
/* 3811 */     this.returnAST = null;
/* 3812 */     ASTPair aSTPair = new ASTPair();
/* 3813 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3816 */       logicalAndExpr();
/* 3817 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 3821 */       while (LA(1) == 75) {
/* 3822 */         TNode tNode1 = null;
/* 3823 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3824 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 3825 */         match(75);
/* 3826 */         logicalAndExpr();
/* 3827 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3835 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3837 */     catch (RecognitionException recognitionException) {
/* 3838 */       if (this.inputState.guessing == 0) {
/* 3839 */         reportError(recognitionException);
/* 3840 */         recover(recognitionException, _tokenSet_47);
/*      */       } else {
/* 3842 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3845 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalAndExpr() throws RecognitionException, TokenStreamException {
/* 3850 */     this.returnAST = null;
/* 3851 */     ASTPair aSTPair = new ASTPair();
/* 3852 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3855 */       inclusiveOrExpr();
/* 3856 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 3860 */       while (LA(1) == 76) {
/* 3861 */         TNode tNode1 = null;
/* 3862 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3863 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 3864 */         match(76);
/* 3865 */         inclusiveOrExpr();
/* 3866 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3874 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3876 */     catch (RecognitionException recognitionException) {
/* 3877 */       if (this.inputState.guessing == 0) {
/* 3878 */         reportError(recognitionException);
/* 3879 */         recover(recognitionException, _tokenSet_48);
/*      */       } else {
/* 3881 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3884 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void inclusiveOrExpr() throws RecognitionException, TokenStreamException {
/* 3889 */     this.returnAST = null;
/* 3890 */     ASTPair aSTPair = new ASTPair();
/* 3891 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3894 */       exclusiveOrExpr();
/* 3895 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 3899 */       while (LA(1) == 77) {
/* 3900 */         TNode tNode1 = null;
/* 3901 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3902 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 3903 */         match(77);
/* 3904 */         exclusiveOrExpr();
/* 3905 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3913 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3915 */     catch (RecognitionException recognitionException) {
/* 3916 */       if (this.inputState.guessing == 0) {
/* 3917 */         reportError(recognitionException);
/* 3918 */         recover(recognitionException, _tokenSet_49);
/*      */       } else {
/* 3920 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3923 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void exclusiveOrExpr() throws RecognitionException, TokenStreamException {
/* 3928 */     this.returnAST = null;
/* 3929 */     ASTPair aSTPair = new ASTPair();
/* 3930 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3933 */       bitAndExpr();
/* 3934 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 3938 */       while (LA(1) == 78) {
/* 3939 */         TNode tNode1 = null;
/* 3940 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3941 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 3942 */         match(78);
/* 3943 */         bitAndExpr();
/* 3944 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3952 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3954 */     catch (RecognitionException recognitionException) {
/* 3955 */       if (this.inputState.guessing == 0) {
/* 3956 */         reportError(recognitionException);
/* 3957 */         recover(recognitionException, _tokenSet_50);
/*      */       } else {
/* 3959 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3962 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void bitAndExpr() throws RecognitionException, TokenStreamException {
/* 3967 */     this.returnAST = null;
/* 3968 */     ASTPair aSTPair = new ASTPair();
/* 3969 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 3972 */       equalityExpr();
/* 3973 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 3977 */       while (LA(1) == 79) {
/* 3978 */         TNode tNode1 = null;
/* 3979 */         tNode1 = (TNode)this.astFactory.create(LT(1));
/* 3980 */         this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 3981 */         match(79);
/* 3982 */         equalityExpr();
/* 3983 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3991 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 3993 */     catch (RecognitionException recognitionException) {
/* 3994 */       if (this.inputState.guessing == 0) {
/* 3995 */         reportError(recognitionException);
/* 3996 */         recover(recognitionException, _tokenSet_51);
/*      */       } else {
/* 3998 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4001 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void equalityExpr() throws RecognitionException, TokenStreamException {
/* 4006 */     this.returnAST = null;
/* 4007 */     ASTPair aSTPair = new ASTPair();
/* 4008 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4011 */       relationalExpr();
/* 4012 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 4016 */       while (LA(1) == 80 || LA(1) == 81) {
/*      */         TNode tNode1;
/* 4018 */         switch (LA(1)) {
/*      */           
/*      */           case 80:
/* 4021 */             tNode1 = null;
/* 4022 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4023 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4024 */             match(80);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 81:
/* 4029 */             tNode1 = null;
/* 4030 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4031 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4032 */             match(81);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4037 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 4041 */         relationalExpr();
/* 4042 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4050 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4052 */     catch (RecognitionException recognitionException) {
/* 4053 */       if (this.inputState.guessing == 0) {
/* 4054 */         reportError(recognitionException);
/* 4055 */         recover(recognitionException, _tokenSet_52);
/*      */       } else {
/* 4057 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4060 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void relationalExpr() throws RecognitionException, TokenStreamException {
/* 4065 */     this.returnAST = null;
/* 4066 */     ASTPair aSTPair = new ASTPair();
/* 4067 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4070 */       shiftExpr();
/* 4071 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 4075 */       while (LA(1) >= 82 && LA(1) <= 85) {
/*      */         TNode tNode1;
/* 4077 */         switch (LA(1)) {
/*      */           
/*      */           case 82:
/* 4080 */             tNode1 = null;
/* 4081 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4082 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4083 */             match(82);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 83:
/* 4088 */             tNode1 = null;
/* 4089 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4090 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4091 */             match(83);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 84:
/* 4096 */             tNode1 = null;
/* 4097 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4098 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4099 */             match(84);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 85:
/* 4104 */             tNode1 = null;
/* 4105 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4106 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4107 */             match(85);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4112 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 4116 */         shiftExpr();
/* 4117 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4125 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4127 */     catch (RecognitionException recognitionException) {
/* 4128 */       if (this.inputState.guessing == 0) {
/* 4129 */         reportError(recognitionException);
/* 4130 */         recover(recognitionException, _tokenSet_53);
/*      */       } else {
/* 4132 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4135 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void shiftExpr() throws RecognitionException, TokenStreamException {
/* 4140 */     this.returnAST = null;
/* 4141 */     ASTPair aSTPair = new ASTPair();
/* 4142 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4145 */       additiveExpr();
/* 4146 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 4150 */       while (LA(1) == 86 || LA(1) == 87) {
/*      */         TNode tNode1;
/* 4152 */         switch (LA(1)) {
/*      */           
/*      */           case 86:
/* 4155 */             tNode1 = null;
/* 4156 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4157 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4158 */             match(86);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 87:
/* 4163 */             tNode1 = null;
/* 4164 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4165 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4166 */             match(87);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4171 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 4175 */         additiveExpr();
/* 4176 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4184 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4186 */     catch (RecognitionException recognitionException) {
/* 4187 */       if (this.inputState.guessing == 0) {
/* 4188 */         reportError(recognitionException);
/* 4189 */         recover(recognitionException, _tokenSet_54);
/*      */       } else {
/* 4191 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4194 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void additiveExpr() throws RecognitionException, TokenStreamException {
/* 4199 */     this.returnAST = null;
/* 4200 */     ASTPair aSTPair = new ASTPair();
/* 4201 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4204 */       multExpr();
/* 4205 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 4209 */       while (LA(1) == 88 || LA(1) == 89) {
/*      */         TNode tNode1;
/* 4211 */         switch (LA(1)) {
/*      */           
/*      */           case 88:
/* 4214 */             tNode1 = null;
/* 4215 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4216 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4217 */             match(88);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 89:
/* 4222 */             tNode1 = null;
/* 4223 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4224 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4225 */             match(89);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4230 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 4234 */         multExpr();
/* 4235 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4243 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4245 */     catch (RecognitionException recognitionException) {
/* 4246 */       if (this.inputState.guessing == 0) {
/* 4247 */         reportError(recognitionException);
/* 4248 */         recover(recognitionException, _tokenSet_55);
/*      */       } else {
/* 4250 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4253 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void multExpr() throws RecognitionException, TokenStreamException {
/* 4258 */     this.returnAST = null;
/* 4259 */     ASTPair aSTPair = new ASTPair();
/* 4260 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4263 */       castExpr();
/* 4264 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 4268 */       while (_tokenSet_56.member(LA(1))) {
/*      */         TNode tNode1;
/* 4270 */         switch (LA(1)) {
/*      */           
/*      */           case 46:
/* 4273 */             tNode1 = null;
/* 4274 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4275 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4276 */             match(46);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 90:
/* 4281 */             tNode1 = null;
/* 4282 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4283 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4284 */             match(90);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 91:
/* 4289 */             tNode1 = null;
/* 4290 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4291 */             this.astFactory.makeASTRoot(aSTPair, (AST)tNode1);
/* 4292 */             match(91);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4297 */             throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */ 
/*      */         
/* 4301 */         castExpr();
/* 4302 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4310 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4312 */     catch (RecognitionException recognitionException) {
/* 4313 */       if (this.inputState.guessing == 0) {
/* 4314 */         reportError(recognitionException);
/* 4315 */         recover(recognitionException, _tokenSet_57);
/*      */       } else {
/* 4317 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4320 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void castExpr() throws RecognitionException, TokenStreamException {
/* 4325 */     this.returnAST = null;
/* 4326 */     ASTPair aSTPair = new ASTPair();
/* 4327 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4330 */       boolean bool = false;
/* 4331 */       if (LA(1) == 47 && _tokenSet_20.member(LA(2))) {
/* 4332 */         int i = mark();
/* 4333 */         bool = true;
/* 4334 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 4337 */           match(47);
/* 4338 */           typeName();
/* 4339 */           match(48);
/*      */         
/*      */         }
/* 4342 */         catch (RecognitionException recognitionException) {
/* 4343 */           bool = false;
/*      */         } 
/* 4345 */         rewind(i);
/* 4346 */         this.inputState.guessing--;
/*      */       } 
/* 4348 */       if (bool) {
/* 4349 */         match(47);
/* 4350 */         typeName();
/* 4351 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4352 */         match(48);
/*      */         
/* 4354 */         castExpr();
/* 4355 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */         
/* 4357 */         if (this.inputState.guessing == 0) {
/* 4358 */           tNode = (TNode)aSTPair.root;
/* 4359 */           tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(118, "(")).add((AST)tNode));
/* 4360 */           aSTPair.root = (AST)tNode;
/* 4361 */           aSTPair
/* 4362 */             .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 4363 */           aSTPair.advanceChildToEnd();
/*      */         } 
/* 4365 */         tNode = (TNode)aSTPair.root;
/*      */       }
/* 4367 */       else if (_tokenSet_11.member(LA(1)) && _tokenSet_58.member(LA(2))) {
/* 4368 */         unaryExpr();
/* 4369 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4370 */         tNode = (TNode)aSTPair.root;
/*      */       } else {
/*      */         
/* 4373 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     
/*      */     }
/* 4377 */     catch (RecognitionException recognitionException) {
/* 4378 */       if (this.inputState.guessing == 0) {
/* 4379 */         reportError(recognitionException);
/* 4380 */         recover(recognitionException, _tokenSet_59);
/*      */       } else {
/* 4382 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4385 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typeName() throws RecognitionException, TokenStreamException {
/* 4390 */     this.returnAST = null;
/* 4391 */     ASTPair aSTPair = new ASTPair();
/* 4392 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4395 */       specifierQualifierList();
/* 4396 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 4398 */       switch (LA(1)) {
/*      */         
/*      */         case 46:
/*      */         case 47:
/*      */         case 49:
/* 4403 */           nonemptyAbstractDeclarator();
/* 4404 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4413 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 4417 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4419 */     catch (RecognitionException recognitionException) {
/* 4420 */       if (this.inputState.guessing == 0) {
/* 4421 */         reportError(recognitionException);
/* 4422 */         recover(recognitionException, _tokenSet_33);
/*      */       } else {
/* 4424 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4427 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void unaryExpr() throws RecognitionException, TokenStreamException {
/* 4432 */     this.returnAST = null;
/* 4433 */     ASTPair aSTPair = new ASTPair();
/* 4434 */     TNode tNode1 = null;
/* 4435 */     TNode tNode2 = null; try {
/*      */       TNode tNode;
/*      */       boolean bool;
/* 4438 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/*      */         case 47:
/*      */         case 99:
/*      */         case 100:
/*      */         case 101:
/*      */         case 102:
/*      */         case 103:
/*      */         case 104:
/*      */         case 105:
/*      */         case 106:
/*      */         case 107:
/*      */         case 108:
/*      */         case 109:
/*      */         case 110:
/*      */         case 111:
/*      */         case 112:
/* 4456 */           postfixExpr();
/* 4457 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4458 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 92:
/* 4463 */           tNode = null;
/* 4464 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 4465 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 4466 */           match(92);
/* 4467 */           unaryExpr();
/* 4468 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4469 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 93:
/* 4474 */           tNode = null;
/* 4475 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 4476 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 4477 */           match(93);
/* 4478 */           unaryExpr();
/* 4479 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4480 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/*      */         case 79:
/*      */         case 88:
/*      */         case 89:
/*      */         case 95:
/*      */         case 96:
/* 4490 */           unaryOperator();
/* 4491 */           tNode2 = (TNode)this.returnAST;
/* 4492 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4493 */           castExpr();
/* 4494 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4495 */           if (this.inputState.guessing == 0) {
/* 4496 */             tNode1 = (TNode)aSTPair.root;
/* 4497 */             tNode1 = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(131)).add((AST)tNode1));
/* 4498 */             aSTPair.root = (AST)tNode1;
/* 4499 */             aSTPair
/* 4500 */               .child = (tNode1 != null && tNode1.getFirstChild() != null) ? tNode1.getFirstChild() : (AST)tNode1;
/* 4501 */             aSTPair.advanceChildToEnd();
/*      */           } 
/* 4503 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 94:
/* 4508 */           tNode = null;
/* 4509 */           tNode = (TNode)this.astFactory.create(LT(1));
/* 4510 */           this.astFactory.makeASTRoot(aSTPair, (AST)tNode);
/* 4511 */           match(94);
/*      */           
/* 4513 */           bool = false;
/* 4514 */           if (LA(1) == 47 && _tokenSet_20.member(LA(2))) {
/* 4515 */             int i = mark();
/* 4516 */             bool = true;
/* 4517 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 4520 */               match(47);
/* 4521 */               typeName();
/*      */             
/*      */             }
/* 4524 */             catch (RecognitionException recognitionException) {
/* 4525 */               bool = false;
/*      */             } 
/* 4527 */             rewind(i);
/* 4528 */             this.inputState.guessing--;
/*      */           } 
/* 4530 */           if (bool) {
/* 4531 */             TNode tNode3 = null;
/* 4532 */             tNode3 = (TNode)this.astFactory.create(LT(1));
/* 4533 */             this.astFactory.addASTChild(aSTPair, (AST)tNode3);
/* 4534 */             match(47);
/* 4535 */             typeName();
/* 4536 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4537 */             TNode tNode4 = null;
/* 4538 */             tNode4 = (TNode)this.astFactory.create(LT(1));
/* 4539 */             this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 4540 */             match(48);
/*      */           }
/* 4542 */           else if (_tokenSet_11.member(LA(1)) && _tokenSet_58.member(LA(2))) {
/* 4543 */             unaryExpr();
/* 4544 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           } else {
/*      */             
/* 4547 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           } 
/*      */ 
/*      */           
/* 4551 */           tNode1 = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4556 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 4560 */     } catch (RecognitionException recognitionException) {
/* 4561 */       if (this.inputState.guessing == 0) {
/* 4562 */         reportError(recognitionException);
/* 4563 */         recover(recognitionException, _tokenSet_59);
/*      */       } else {
/* 4565 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4568 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void postfixExpr() throws RecognitionException, TokenStreamException {
/* 4573 */     this.returnAST = null;
/* 4574 */     ASTPair aSTPair = new ASTPair();
/* 4575 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 4578 */       primaryExpr();
/* 4579 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       
/* 4581 */       switch (LA(1)) {
/*      */         
/*      */         case 47:
/*      */         case 49:
/*      */         case 92:
/*      */         case 93:
/*      */         case 97:
/*      */         case 98:
/* 4589 */           postfixSuffix();
/* 4590 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4591 */           if (this.inputState.guessing == 0) {
/* 4592 */             tNode = (TNode)aSTPair.root;
/* 4593 */             tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(133)).add((AST)tNode));
/* 4594 */             aSTPair.root = (AST)tNode;
/* 4595 */             aSTPair
/* 4596 */               .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 4597 */             aSTPair.advanceChildToEnd();
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 9:
/*      */         case 43:
/*      */         case 44:
/*      */         case 45:
/*      */         case 46:
/*      */         case 48:
/*      */         case 50:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4642 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 4646 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4648 */     catch (RecognitionException recognitionException) {
/* 4649 */       if (this.inputState.guessing == 0) {
/* 4650 */         reportError(recognitionException);
/* 4651 */         recover(recognitionException, _tokenSet_59);
/*      */       } else {
/* 4653 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4656 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void unaryOperator() throws RecognitionException, TokenStreamException {
/* 4661 */     this.returnAST = null;
/* 4662 */     ASTPair aSTPair = new ASTPair();
/* 4663 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 4666 */       switch (LA(1)) {
/*      */         
/*      */         case 79:
/* 4669 */           tNode1 = null;
/* 4670 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4671 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4672 */           match(79);
/* 4673 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/* 4678 */           tNode1 = null;
/* 4679 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4680 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4681 */           match(46);
/* 4682 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 88:
/* 4687 */           tNode1 = null;
/* 4688 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4689 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4690 */           match(88);
/* 4691 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 4696 */           tNode1 = null;
/* 4697 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4698 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4699 */           match(89);
/* 4700 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 95:
/* 4705 */           tNode1 = null;
/* 4706 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4707 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4708 */           match(95);
/* 4709 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 96:
/* 4714 */           tNode1 = null;
/* 4715 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4716 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4717 */           match(96);
/* 4718 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4723 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 4727 */     } catch (RecognitionException recognitionException) {
/* 4728 */       if (this.inputState.guessing == 0) {
/* 4729 */         reportError(recognitionException);
/* 4730 */         recover(recognitionException, _tokenSet_11);
/*      */       } else {
/* 4732 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4735 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void primaryExpr() throws RecognitionException, TokenStreamException {
/* 4740 */     this.returnAST = null;
/* 4741 */     ASTPair aSTPair = new ASTPair();
/* 4742 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 4745 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/* 4748 */           tNode1 = null;
/* 4749 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4750 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4751 */           match(42);
/* 4752 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 99:
/* 4757 */           charConst();
/* 4758 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4759 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 101:
/*      */         case 102:
/*      */         case 103:
/*      */         case 104:
/*      */         case 105:
/*      */         case 106:
/*      */         case 107:
/*      */         case 108:
/*      */         case 109:
/* 4772 */           intConst();
/* 4773 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4774 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 110:
/*      */         case 111:
/*      */         case 112:
/* 4781 */           floatConst();
/* 4782 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4783 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 100:
/* 4788 */           stringConst();
/* 4789 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4790 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/* 4795 */           match(47);
/* 4796 */           expr();
/* 4797 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4798 */           match(48);
/* 4799 */           if (this.inputState.guessing == 0) {
/* 4800 */             tNode = (TNode)aSTPair.root;
/* 4801 */             tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(120, "(")).add((AST)tNode));
/* 4802 */             aSTPair.root = (AST)tNode;
/* 4803 */             aSTPair
/* 4804 */               .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 4805 */             aSTPair.advanceChildToEnd();
/*      */           } 
/* 4807 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4812 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 4816 */     } catch (RecognitionException recognitionException) {
/* 4817 */       if (this.inputState.guessing == 0) {
/* 4818 */         reportError(recognitionException);
/* 4819 */         recover(recognitionException, _tokenSet_60);
/*      */       } else {
/* 4821 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4824 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void postfixSuffix() throws RecognitionException, TokenStreamException {
/* 4829 */     this.returnAST = null;
/* 4830 */     ASTPair aSTPair = new ASTPair();
/* 4831 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 4835 */       byte b = 0;
/*      */       while (true) {
/*      */         TNode tNode1, tNode2;
/* 4838 */         switch (LA(1)) {
/*      */           
/*      */           case 97:
/* 4841 */             tNode1 = null;
/* 4842 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4843 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4844 */             match(97);
/* 4845 */             tNode2 = null;
/* 4846 */             tNode2 = (TNode)this.astFactory.create(LT(1));
/* 4847 */             this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 4848 */             match(42);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 98:
/* 4853 */             tNode1 = null;
/* 4854 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4855 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4856 */             match(98);
/* 4857 */             tNode2 = null;
/* 4858 */             tNode2 = (TNode)this.astFactory.create(LT(1));
/* 4859 */             this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 4860 */             match(42);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 47:
/* 4865 */             functionCall();
/* 4866 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 49:
/* 4871 */             tNode1 = null;
/* 4872 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4873 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4874 */             match(49);
/* 4875 */             expr();
/* 4876 */             this.astFactory.addASTChild(aSTPair, this.returnAST);
/* 4877 */             tNode2 = null;
/* 4878 */             tNode2 = (TNode)this.astFactory.create(LT(1));
/* 4879 */             this.astFactory.addASTChild(aSTPair, (AST)tNode2);
/* 4880 */             match(50);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 92:
/* 4885 */             tNode1 = null;
/* 4886 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4887 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4888 */             match(92);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 93:
/* 4893 */             tNode1 = null;
/* 4894 */             tNode1 = (TNode)this.astFactory.create(LT(1));
/* 4895 */             this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 4896 */             match(93);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4901 */             if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 4904 */         b++;
/*      */       } 
/*      */       
/* 4907 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 4909 */     catch (RecognitionException recognitionException) {
/* 4910 */       if (this.inputState.guessing == 0) {
/* 4911 */         reportError(recognitionException);
/* 4912 */         recover(recognitionException, _tokenSet_59);
/*      */       } else {
/* 4914 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4917 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void functionCall() throws RecognitionException, TokenStreamException {
/* 4922 */     this.returnAST = null;
/* 4923 */     ASTPair aSTPair = new ASTPair();
/* 4924 */     TNode tNode1 = null;
/* 4925 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 4928 */       TNode tNode3 = null;
/* 4929 */       tNode3 = (TNode)this.astFactory.create(LT(1));
/* 4930 */       this.astFactory.makeASTRoot(aSTPair, (AST)tNode3);
/* 4931 */       match(47);
/*      */       
/* 4933 */       switch (LA(1)) {
/*      */         
/*      */         case 42:
/*      */         case 46:
/*      */         case 47:
/*      */         case 79:
/*      */         case 88:
/*      */         case 89:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 99:
/*      */         case 100:
/*      */         case 101:
/*      */         case 102:
/*      */         case 103:
/*      */         case 104:
/*      */         case 105:
/*      */         case 106:
/*      */         case 107:
/*      */         case 108:
/*      */         case 109:
/*      */         case 110:
/*      */         case 111:
/*      */         case 112:
/* 4960 */           argExprList();
/* 4961 */           tNode2 = (TNode)this.returnAST;
/* 4962 */           this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4971 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */       
/* 4975 */       TNode tNode4 = null;
/* 4976 */       tNode4 = (TNode)this.astFactory.create(LT(1));
/* 4977 */       this.astFactory.addASTChild(aSTPair, (AST)tNode4);
/* 4978 */       match(48);
/* 4979 */       if (this.inputState.guessing == 0) {
/* 4980 */         tNode1 = (TNode)aSTPair.root;
/*      */         
/* 4982 */         tNode1.setType(121);
/*      */       } 
/*      */       
/* 4985 */       tNode1 = (TNode)aSTPair.root;
/*      */     }
/* 4987 */     catch (RecognitionException recognitionException) {
/* 4988 */       if (this.inputState.guessing == 0) {
/* 4989 */         reportError(recognitionException);
/* 4990 */         recover(recognitionException, _tokenSet_60);
/*      */       } else {
/* 4992 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4995 */     this.returnAST = (AST)tNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void argExprList() throws RecognitionException, TokenStreamException {
/* 5000 */     this.returnAST = null;
/* 5001 */     ASTPair aSTPair = new ASTPair();
/* 5002 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 5005 */       assignExpr();
/* 5006 */       this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */ 
/*      */ 
/*      */       
/* 5010 */       while (LA(1) == 43) {
/* 5011 */         match(43);
/* 5012 */         assignExpr();
/* 5013 */         this.astFactory.addASTChild(aSTPair, this.returnAST);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5021 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 5023 */     catch (RecognitionException recognitionException) {
/* 5024 */       if (this.inputState.guessing == 0) {
/* 5025 */         reportError(recognitionException);
/* 5026 */         recover(recognitionException, _tokenSet_33);
/*      */       } else {
/* 5028 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5031 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void charConst() throws RecognitionException, TokenStreamException {
/* 5036 */     this.returnAST = null;
/* 5037 */     ASTPair aSTPair = new ASTPair();
/* 5038 */     TNode tNode = null;
/*      */     
/*      */     try {
/* 5041 */       TNode tNode1 = null;
/* 5042 */       tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5043 */       this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5044 */       match(99);
/* 5045 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 5047 */     catch (RecognitionException recognitionException) {
/* 5048 */       if (this.inputState.guessing == 0) {
/* 5049 */         reportError(recognitionException);
/* 5050 */         recover(recognitionException, _tokenSet_60);
/*      */       } else {
/* 5052 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5055 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void intConst() throws RecognitionException, TokenStreamException {
/* 5060 */     this.returnAST = null;
/* 5061 */     ASTPair aSTPair = new ASTPair();
/* 5062 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 5065 */       switch (LA(1)) {
/*      */         
/*      */         case 101:
/* 5068 */           tNode1 = null;
/* 5069 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5070 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5071 */           match(101);
/* 5072 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 102:
/* 5077 */           tNode1 = null;
/* 5078 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5079 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5080 */           match(102);
/* 5081 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 103:
/* 5086 */           tNode1 = null;
/* 5087 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5088 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5089 */           match(103);
/* 5090 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 104:
/* 5095 */           tNode1 = null;
/* 5096 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5097 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5098 */           match(104);
/* 5099 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 105:
/* 5104 */           tNode1 = null;
/* 5105 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5106 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5107 */           match(105);
/* 5108 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 106:
/* 5113 */           tNode1 = null;
/* 5114 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5115 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5116 */           match(106);
/* 5117 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 107:
/* 5122 */           tNode1 = null;
/* 5123 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5124 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5125 */           match(107);
/* 5126 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 108:
/* 5131 */           tNode1 = null;
/* 5132 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5133 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5134 */           match(108);
/* 5135 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 109:
/* 5140 */           tNode1 = null;
/* 5141 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5142 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5143 */           match(109);
/* 5144 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5149 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 5153 */     } catch (RecognitionException recognitionException) {
/* 5154 */       if (this.inputState.guessing == 0) {
/* 5155 */         reportError(recognitionException);
/* 5156 */         recover(recognitionException, _tokenSet_60);
/*      */       } else {
/* 5158 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5161 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void floatConst() throws RecognitionException, TokenStreamException {
/* 5166 */     this.returnAST = null;
/* 5167 */     ASTPair aSTPair = new ASTPair();
/* 5168 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 5171 */       switch (LA(1)) {
/*      */         
/*      */         case 110:
/* 5174 */           tNode1 = null;
/* 5175 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5176 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5177 */           match(110);
/* 5178 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 111:
/* 5183 */           tNode1 = null;
/* 5184 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5185 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5186 */           match(111);
/* 5187 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 112:
/* 5192 */           tNode1 = null;
/* 5193 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5194 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5195 */           match(112);
/* 5196 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5201 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 5205 */     } catch (RecognitionException recognitionException) {
/* 5206 */       if (this.inputState.guessing == 0) {
/* 5207 */         reportError(recognitionException);
/* 5208 */         recover(recognitionException, _tokenSet_60);
/*      */       } else {
/* 5210 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5213 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void stringConst() throws RecognitionException, TokenStreamException {
/* 5218 */     this.returnAST = null;
/* 5219 */     ASTPair aSTPair = new ASTPair();
/* 5220 */     TNode tNode = null;
/*      */ 
/*      */     
/*      */     try {
/* 5224 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 5227 */         if (LA(1) == 100) {
/* 5228 */           TNode tNode1 = null;
/* 5229 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5230 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5231 */           match(100);
/*      */         } else {
/*      */           
/* 5234 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*      */         } 
/*      */         
/* 5237 */         b++;
/*      */       } 
/*      */       
/* 5240 */       if (this.inputState.guessing == 0) {
/* 5241 */         tNode = (TNode)aSTPair.root;
/* 5242 */         tNode = (TNode)this.astFactory.make((new ASTArray(2)).add(this.astFactory.create(135)).add((AST)tNode));
/* 5243 */         aSTPair.root = (AST)tNode;
/* 5244 */         aSTPair
/* 5245 */           .child = (tNode != null && tNode.getFirstChild() != null) ? tNode.getFirstChild() : (AST)tNode;
/* 5246 */         aSTPair.advanceChildToEnd();
/*      */       } 
/* 5248 */       tNode = (TNode)aSTPair.root;
/*      */     }
/* 5250 */     catch (RecognitionException recognitionException) {
/* 5251 */       if (this.inputState.guessing == 0) {
/* 5252 */         reportError(recognitionException);
/* 5253 */         recover(recognitionException, _tokenSet_60);
/*      */       } else {
/* 5255 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5258 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void dummy() throws RecognitionException, TokenStreamException {
/* 5263 */     this.returnAST = null;
/* 5264 */     ASTPair aSTPair = new ASTPair();
/* 5265 */     TNode tNode = null;
/*      */     try {
/*      */       TNode tNode1;
/* 5268 */       switch (LA(1)) {
/*      */         
/*      */         case 113:
/* 5271 */           tNode1 = null;
/* 5272 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5273 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5274 */           match(113);
/* 5275 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 114:
/* 5280 */           tNode1 = null;
/* 5281 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5282 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5283 */           match(114);
/* 5284 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 115:
/* 5289 */           tNode1 = null;
/* 5290 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5291 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5292 */           match(115);
/* 5293 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 116:
/* 5298 */           tNode1 = null;
/* 5299 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5300 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5301 */           match(116);
/* 5302 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 117:
/* 5307 */           tNode1 = null;
/* 5308 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5309 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5310 */           match(117);
/* 5311 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 118:
/* 5316 */           tNode1 = null;
/* 5317 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5318 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5319 */           match(118);
/* 5320 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 119:
/* 5325 */           tNode1 = null;
/* 5326 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5327 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5328 */           match(119);
/* 5329 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 120:
/* 5334 */           tNode1 = null;
/* 5335 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5336 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5337 */           match(120);
/* 5338 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 121:
/* 5343 */           tNode1 = null;
/* 5344 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5345 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5346 */           match(121);
/* 5347 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 122:
/* 5352 */           tNode1 = null;
/* 5353 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5354 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5355 */           match(122);
/* 5356 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 123:
/* 5361 */           tNode1 = null;
/* 5362 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5363 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5364 */           match(123);
/* 5365 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 124:
/* 5370 */           tNode1 = null;
/* 5371 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5372 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5373 */           match(124);
/* 5374 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 125:
/* 5379 */           tNode1 = null;
/* 5380 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5381 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5382 */           match(125);
/* 5383 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 126:
/* 5388 */           tNode1 = null;
/* 5389 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5390 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5391 */           match(126);
/* 5392 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 127:
/* 5397 */           tNode1 = null;
/* 5398 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5399 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5400 */           match(127);
/* 5401 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 128:
/* 5406 */           tNode1 = null;
/* 5407 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5408 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5409 */           match(128);
/* 5410 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 129:
/* 5415 */           tNode1 = null;
/* 5416 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5417 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5418 */           match(129);
/* 5419 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 130:
/* 5424 */           tNode1 = null;
/* 5425 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5426 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5427 */           match(130);
/* 5428 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 131:
/* 5433 */           tNode1 = null;
/* 5434 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5435 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5436 */           match(131);
/* 5437 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 132:
/* 5442 */           tNode1 = null;
/* 5443 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5444 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5445 */           match(132);
/* 5446 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 133:
/* 5451 */           tNode1 = null;
/* 5452 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5453 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5454 */           match(133);
/* 5455 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 134:
/* 5460 */           tNode1 = null;
/* 5461 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5462 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5463 */           match(134);
/* 5464 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 135:
/* 5469 */           tNode1 = null;
/* 5470 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5471 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5472 */           match(135);
/* 5473 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 136:
/* 5478 */           tNode1 = null;
/* 5479 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5480 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5481 */           match(136);
/* 5482 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 137:
/* 5487 */           tNode1 = null;
/* 5488 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5489 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5490 */           match(137);
/* 5491 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 138:
/* 5496 */           tNode1 = null;
/* 5497 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5498 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5499 */           match(138);
/* 5500 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 139:
/* 5505 */           tNode1 = null;
/* 5506 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5507 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5508 */           match(139);
/* 5509 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 140:
/* 5514 */           tNode1 = null;
/* 5515 */           tNode1 = (TNode)this.astFactory.create(LT(1));
/* 5516 */           this.astFactory.addASTChild(aSTPair, (AST)tNode1);
/* 5517 */           match(140);
/* 5518 */           tNode = (TNode)aSTPair.root;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5523 */           throw new NoViableAltException(LT(1), getFilename());
/*      */       } 
/*      */ 
/*      */     
/* 5527 */     } catch (RecognitionException recognitionException) {
/* 5528 */       if (this.inputState.guessing == 0) {
/* 5529 */         reportError(recognitionException);
/* 5530 */         recover(recognitionException, _tokenSet_0);
/*      */       } else {
/* 5532 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5535 */     this.returnAST = (AST)tNode;
/*      */   }
/*      */ 
/*      */   
/* 5539 */   public static final String[] _tokenNames = new String[] { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"typedef\"", "\"asm\"", "\"volatile\"", "LCURLY", "RCURLY", "SEMI", "\"struct\"", "\"union\"", "\"enum\"", "\"auto\"", "\"register\"", "\"extern\"", "\"static\"", "\"const\"", "\"void\"", "\"char\"", "\"short\"", "\"int\"", "\"long\"", "\"float\"", "\"double\"", "\"signed\"", "\"unsigned\"", "\"int8_t\"", "\"uint8_t\"", "\"int16_t\"", "\"uint16_t\"", "\"__int32\"", "\"int32_t\"", "\"wchar_t\"", "\"uint32_t\"", "\"__int64\"", "\"int64_t\"", "\"uint64_t\"", "\"ptrdiff_t\"", "\"intptr_t\"", "\"size_t\"", "\"uintptr_t\"", "ID", "COMMA", "COLON", "ASSIGN", "STAR", "LPAREN", "RPAREN", "LBRACKET", "RBRACKET", "VARARGS", "\"while\"", "\"do\"", "\"for\"", "\"goto\"", "\"continue\"", "\"break\"", "\"return\"", "\"case\"", "\"default\"", "\"if\"", "\"else\"", "\"switch\"", "DIV_ASSIGN", "PLUS_ASSIGN", "MINUS_ASSIGN", "STAR_ASSIGN", "MOD_ASSIGN", "RSHIFT_ASSIGN", "LSHIFT_ASSIGN", "BAND_ASSIGN", "BOR_ASSIGN", "BXOR_ASSIGN", "QUESTION", "LOR", "LAND", "BOR", "BXOR", "BAND", "EQUAL", "NOT_EQUAL", "LT", "LTE", "GT", "GTE", "LSHIFT", "RSHIFT", "PLUS", "MINUS", "DIV", "MOD", "INC", "DEC", "\"sizeof\"", "BNOT", "LNOT", "PTR", "DOT", "CharLiteral", "StringLiteral", "IntOctalConst", "LongOctalConst", "UnsignedOctalConst", "IntIntConst", "LongIntConst", "UnsignedIntConst", "IntHexConst", "LongHexConst", "UnsignedHexConst", "FloatDoubleConst", "DoubleDoubleConst", "LongDoubleConst", "NTypedefName", "NInitDecl", "NDeclarator", "NStructDeclarator", "NDeclaration", "NCast", "NPointerGroup", "NExpressionGroup", "NFunctionCallArgs", "NNonemptyAbstractDeclarator", "NInitializer", "NStatementExpr", "NEmptyExpression", "NParameterTypeList", "NFunctionDef", "NCompoundStatement", "NParameterDeclaration", "NCommaExpr", "NUnaryExpr", "NLabel", "NPostfixExpr", "NRangeExpr", "NStringSeq", "NInitializerElementLabel", "NLcurlyInitializer", "NAsmAttribute", "NGnuAsmExpr", "NTypeMissing", "Vocabulary", "Whitespace", "Comment", "CPPComment", "NonWhitespace", "a line directive", "DefineExpr", "DefineExpr2", "Space", "LineDirective", "BadStringLiteral", "Escape", "Digit", "LongSuffix", "UnsignedSuffix", "FloatSuffix", "Exponent", "Number" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void buildTokenTypeASTClassMap() {
/* 5702 */     this.tokenTypeToASTClassMap = null;
/*      */   }
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 5706 */     return new long[] { 2L, 0L, 0L };
/*      */   }
/*      */   
/* 5709 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 5711 */     return new long[] { 219902325554288L, 0L, 0L };
/*      */   }
/*      */   
/* 5714 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 5716 */     return new long[] { 8796093021264L, 0L, 0L };
/*      */   }
/*      */   
/* 5719 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 5721 */     return new long[] { 219902325554896L, 0L, 0L };
/*      */   }
/*      */   
/* 5724 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 5726 */     return new long[] { 219902325529664L, 0L, 0L };
/*      */   }
/*      */   
/* 5729 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 5731 */     return new long[] { 3034652092661456L, 0L, 0L };
/*      */   }
/*      */   
/* 5734 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 5736 */     return new long[] { 219902325554290L, 0L, 0L };
/*      */   }
/*      */   
/* 5739 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 5741 */     return new long[] { -4613717915915517966L, 562923965546496L, 0L, 0L };
/*      */   }
/*      */   
/* 5744 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 5746 */     return new long[] { 8796092996672L, 0L, 0L };
/*      */   }
/*      */   
/* 5749 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 5751 */     return new long[] { 219902325529792L, 0L, 0L };
/*      */   }
/*      */   
/* 5754 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 5756 */     return new long[] { 215504279044096L, 0L, 0L };
/*      */   }
/*      */   
/* 5759 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 5761 */     return new long[] { 215504279044096L, 562923965546496L, 0L, 0L };
/*      */   }
/*      */   
/* 5764 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 5766 */     return new long[] { 1433763162620672L, 0L, 0L };
/*      */   }
/*      */   
/* 5769 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 5771 */     return new long[] { 8796092767232L, 0L, 0L };
/*      */   }
/*      */   
/* 5774 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 5776 */     return new long[] { 1073123348709072L, 0L, 0L };
/*      */   }
/*      */   
/* 5779 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 5781 */     return new long[] { 1068725302198784L, 0L, 0L };
/*      */   }
/*      */   
/* 5784 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 5786 */     return new long[] { 512L, 0L, 0L };
/*      */   }
/*      */   
/* 5789 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 5791 */     return new long[] { 1073123348708944L, 0L, 0L };
/*      */   }
/*      */   
/* 5794 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 5796 */     return new long[] { 1090715534753360L, 0L, 0L };
/*      */   }
/*      */   
/* 5799 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 5801 */     return new long[] { 4398046511232L, 0L, 0L };
/*      */   }
/*      */   
/* 5804 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 5806 */     return new long[] { 8796092898368L, 0L, 0L };
/*      */   }
/*      */   
/* 5809 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 5811 */     return new long[] { 256L, 0L, 0L };
/*      */   }
/*      */   
/* 5814 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 5816 */     return new long[] { 8796092898624L, 0L, 0L };
/*      */   }
/*      */   
/* 5819 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */   private static final long[] mk_tokenSet_23() {
/* 5821 */     return new long[] { 1081919441607872L, 0L, 0L };
/*      */   }
/*      */   
/* 5824 */   public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
/*      */   private static final long[] mk_tokenSet_24() {
/* 5826 */     return new long[] { 1077521395220480L, 0L, 0L };
/*      */   }
/*      */   
/* 5829 */   public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
/*      */   private static final long[] mk_tokenSet_25() {
/* 5831 */     return new long[] { 8796093022720L, 0L, 0L };
/*      */   }
/*      */   
/* 5834 */   public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
/*      */   private static final long[] mk_tokenSet_26() {
/* 5836 */     return new long[] { 1152288185910016L, 0L, 0L };
/*      */   }
/*      */   
/* 5839 */   public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
/*      */   private static final long[] mk_tokenSet_27() {
/* 5841 */     return new long[] { 1073123348708560L, 0L, 0L };
/*      */   }
/*      */   
/* 5844 */   public static final BitSet _tokenSet_27 = new BitSet(mk_tokenSet_27());
/*      */   private static final long[] mk_tokenSet_28() {
/* 5846 */     return new long[] { 3307330976349904L, 0L, 0L };
/*      */   }
/*      */   
/* 5849 */   public static final BitSet _tokenSet_28 = new BitSet(mk_tokenSet_28());
/*      */   private static final long[] mk_tokenSet_29() {
/* 5851 */     return new long[] { 2603643534573264L, 0L, 0L };
/*      */   }
/*      */   
/* 5854 */   public static final BitSet _tokenSet_29 = new BitSet(mk_tokenSet_29());
/*      */   private static final long[] mk_tokenSet_30() {
/* 5856 */     return new long[] { 8796093022464L, 0L, 0L };
/*      */   }
/*      */   
/* 5859 */   public static final BitSet _tokenSet_30 = new BitSet(mk_tokenSet_30());
/*      */   private static final long[] mk_tokenSet_31() {
/* 5861 */     return new long[] { 8796093022976L, 0L, 0L };
/*      */   }
/*      */   
/* 5864 */   public static final BitSet _tokenSet_31 = new BitSet(mk_tokenSet_31());
/*      */   private static final long[] mk_tokenSet_32() {
/* 5866 */     return new long[] { 998356558020608L, 0L, 0L };
/*      */   }
/*      */   
/* 5869 */   public static final BitSet _tokenSet_32 = new BitSet(mk_tokenSet_32());
/*      */   private static final long[] mk_tokenSet_33() {
/* 5871 */     return new long[] { 281474976710656L, 0L, 0L };
/*      */   }
/*      */   
/* 5874 */   public static final BitSet _tokenSet_33 = new BitSet(mk_tokenSet_33());
/*      */   private static final long[] mk_tokenSet_34() {
/* 5876 */     return new long[] { 215504279044224L, 562923965546496L, 0L, 0L };
/*      */   }
/*      */   
/* 5879 */   public static final BitSet _tokenSet_34 = new BitSet(mk_tokenSet_34());
/*      */   private static final long[] mk_tokenSet_35() {
/* 5881 */     return new long[] { 1068725302329408L, 0L, 0L };
/*      */   }
/*      */   
/* 5884 */   public static final BitSet _tokenSet_35 = new BitSet(mk_tokenSet_35());
/*      */   private static final long[] mk_tokenSet_36() {
/* 5886 */     return new long[] { 774056185954304L, 0L, 0L };
/*      */   }
/*      */   
/* 5889 */   public static final BitSet _tokenSet_36 = new BitSet(mk_tokenSet_36());
/*      */   private static final long[] mk_tokenSet_37() {
/* 5891 */     return new long[] { 2199023255551056L, 562923965546496L, 0L, 0L };
/*      */   }
/*      */   
/* 5894 */   public static final BitSet _tokenSet_37 = new BitSet(mk_tokenSet_37());
/*      */   private static final long[] mk_tokenSet_38() {
/* 5896 */     return new long[] { 290271069732864L, 0L, 0L };
/*      */   }
/*      */   
/* 5899 */   public static final BitSet _tokenSet_38 = new BitSet(mk_tokenSet_38());
/*      */   private static final long[] mk_tokenSet_39() {
/* 5901 */     return new long[] { -4615974113775713408L, 562923965546496L, 0L, 0L };
/*      */   }
/*      */   
/* 5904 */   public static final BitSet _tokenSet_39 = new BitSet(mk_tokenSet_39());
/*      */   private static final long[] mk_tokenSet_40() {
/* 5906 */     return new long[] { -3659174697238542L, 562949953421311L, 0L, 0L };
/*      */   }
/*      */   
/* 5909 */   public static final BitSet _tokenSet_40 = new BitSet(mk_tokenSet_40());
/*      */   private static final long[] mk_tokenSet_41() {
/* 5911 */     return new long[] { -4283697301815310L, 562923965546496L, 0L, 0L };
/*      */   }
/*      */   
/* 5914 */   public static final BitSet _tokenSet_41 = new BitSet(mk_tokenSet_41());
/*      */   private static final long[] mk_tokenSet_42() {
/* 5916 */     return new long[] { -4615974113775713664L, 562923965546496L, 0L, 0L };
/*      */   }
/*      */   
/* 5919 */   public static final BitSet _tokenSet_42 = new BitSet(mk_tokenSet_42());
/*      */   private static final long[] mk_tokenSet_43() {
/* 5921 */     return new long[] { -4288095348325504L, 562923965546496L, 0L, 0L };
/*      */   }
/*      */   
/* 5924 */   public static final BitSet _tokenSet_43 = new BitSet(mk_tokenSet_43());
/*      */   private static final long[] mk_tokenSet_44() {
/* 5926 */     return new long[] { 826832743964224L, 562949953421311L, 0L, 0L };
/*      */   }
/*      */   
/* 5929 */   public static final BitSet _tokenSet_44 = new BitSet(mk_tokenSet_44());
/*      */   private static final long[] mk_tokenSet_45() {
/* 5931 */     return new long[] { -3659174697238576L, 562949953421311L, 0L, 0L };
/*      */   }
/*      */   
/* 5934 */   public static final BitSet _tokenSet_45 = new BitSet(mk_tokenSet_45());
/*      */   private static final long[] mk_tokenSet_46() {
/* 5936 */     return new long[] { 1468947534709504L, 1023L, 0L, 0L };
/*      */   }
/*      */   
/* 5939 */   public static final BitSet _tokenSet_46 = new BitSet(mk_tokenSet_46());
/*      */   private static final long[] mk_tokenSet_47() {
/* 5941 */     return new long[] { 1468947534709504L, 2047L, 0L, 0L };
/*      */   }
/*      */   
/* 5944 */   public static final BitSet _tokenSet_47 = new BitSet(mk_tokenSet_47());
/*      */   private static final long[] mk_tokenSet_48() {
/* 5946 */     return new long[] { 1468947534709504L, 4095L, 0L, 0L };
/*      */   }
/*      */   
/* 5949 */   public static final BitSet _tokenSet_48 = new BitSet(mk_tokenSet_48());
/*      */   private static final long[] mk_tokenSet_49() {
/* 5951 */     return new long[] { 1468947534709504L, 8191L, 0L, 0L };
/*      */   }
/*      */   
/* 5954 */   public static final BitSet _tokenSet_49 = new BitSet(mk_tokenSet_49());
/*      */   private static final long[] mk_tokenSet_50() {
/* 5956 */     return new long[] { 1468947534709504L, 16383L, 0L, 0L };
/*      */   }
/*      */   
/* 5959 */   public static final BitSet _tokenSet_50 = new BitSet(mk_tokenSet_50());
/*      */   private static final long[] mk_tokenSet_51() {
/* 5961 */     return new long[] { 1468947534709504L, 32767L, 0L, 0L };
/*      */   }
/*      */   
/* 5964 */   public static final BitSet _tokenSet_51 = new BitSet(mk_tokenSet_51());
/*      */   private static final long[] mk_tokenSet_52() {
/* 5966 */     return new long[] { 1468947534709504L, 65535L, 0L, 0L };
/*      */   }
/*      */   
/* 5969 */   public static final BitSet _tokenSet_52 = new BitSet(mk_tokenSet_52());
/*      */   private static final long[] mk_tokenSet_53() {
/* 5971 */     return new long[] { 1468947534709504L, 262143L, 0L, 0L };
/*      */   }
/*      */   
/* 5974 */   public static final BitSet _tokenSet_53 = new BitSet(mk_tokenSet_53());
/*      */   private static final long[] mk_tokenSet_54() {
/* 5976 */     return new long[] { 1468947534709504L, 4194303L, 0L, 0L };
/*      */   }
/*      */   
/* 5979 */   public static final BitSet _tokenSet_54 = new BitSet(mk_tokenSet_54());
/*      */   private static final long[] mk_tokenSet_55() {
/* 5981 */     return new long[] { 1468947534709504L, 16777215L, 0L, 0L };
/*      */   }
/*      */   
/* 5984 */   public static final BitSet _tokenSet_55 = new BitSet(mk_tokenSet_55());
/*      */   private static final long[] mk_tokenSet_56() {
/* 5986 */     return new long[] { 70368744177664L, 201326592L, 0L, 0L };
/*      */   }
/*      */   
/* 5989 */   public static final BitSet _tokenSet_56 = new BitSet(mk_tokenSet_56());
/*      */   private static final long[] mk_tokenSet_57() {
/* 5991 */     return new long[] { 1468947534709504L, 67108863L, 0L, 0L };
/*      */   }
/*      */   
/* 5994 */   public static final BitSet _tokenSet_57 = new BitSet(mk_tokenSet_57());
/*      */   private static final long[] mk_tokenSet_58() {
/* 5996 */     return new long[] { 2247401767174912L, 562949953421311L, 0L, 0L };
/*      */   }
/*      */   
/* 5999 */   public static final BitSet _tokenSet_58 = new BitSet(mk_tokenSet_58());
/*      */   private static final long[] mk_tokenSet_59() {
/* 6001 */     return new long[] { 1539316278887168L, 268435455L, 0L, 0L };
/*      */   }
/*      */   
/* 6004 */   public static final BitSet _tokenSet_59 = new BitSet(mk_tokenSet_59());
/*      */   private static final long[] mk_tokenSet_60() {
/* 6006 */     return new long[] { 2243003720663808L, 26843545599L, 0L, 0L };
/*      */   }
/*      */   
/* 6009 */   public static final BitSet _tokenSet_60 = new BitSet(mk_tokenSet_60());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/StdCParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */