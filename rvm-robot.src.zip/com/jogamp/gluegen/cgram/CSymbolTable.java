/*     */ package com.jogamp.gluegen.cgram;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSymbolTable
/*     */ {
/*  17 */   private final Vector<String> scopeStack = new Vector<>(10);
/*  18 */   private final Hashtable<String, TNode> symTable = new Hashtable<>(533);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushScope(String paramString) {
/*  26 */     this.scopeStack.addElement(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void popScope() {
/*  33 */     int i = this.scopeStack.size();
/*  34 */     if (i > 0) {
/*  35 */       this.scopeStack.removeElementAt(i - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String currentScopeAsString() {
/*  41 */     StringBuilder stringBuilder = new StringBuilder(100);
/*  42 */     boolean bool = true;
/*  43 */     Enumeration<String> enumeration = this.scopeStack.elements();
/*  44 */     while (enumeration.hasMoreElements()) {
/*  45 */       if (bool) {
/*  46 */         bool = false;
/*     */       } else {
/*  48 */         stringBuilder.append("::");
/*  49 */       }  stringBuilder.append(((String)enumeration.nextElement()).toString());
/*     */     } 
/*  51 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String addCurrentScopeToName(String paramString) {
/*  58 */     String str = currentScopeAsString();
/*  59 */     return addScopeToName(str, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String addScopeToName(String paramString1, String paramString2) {
/*  66 */     if (paramString1 == null || paramString1.length() > 0) {
/*  67 */       return paramString1 + "::" + paramString2;
/*     */     }
/*  69 */     return paramString2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String removeOneLevelScope(String paramString) {
/*  74 */     int i = paramString.lastIndexOf("::");
/*  75 */     if (i > 0) {
/*  76 */       return paramString.substring(0, i);
/*     */     }
/*  78 */     if (paramString.length() > 0) {
/*  79 */       return "";
/*     */     }
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode add(String paramString, TNode paramTNode) {
/*  87 */     return this.symTable.put(addCurrentScopeToName(paramString), paramTNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode lookupScopedName(String paramString) {
/*  93 */     return this.symTable.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TNode lookupNameInCurrentScope(String paramString) {
/* 101 */     String str = currentScopeAsString();
/*     */     
/* 103 */     TNode tNode = null;
/*     */ 
/*     */ 
/*     */     
/* 107 */     while (tNode == null && str != null) {
/* 108 */       String str1 = addScopeToName(str, paramString);
/*     */       
/* 110 */       tNode = this.symTable.get(str1);
/* 111 */       str = removeOneLevelScope(str);
/*     */     } 
/* 113 */     return tNode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 119 */     StringBuilder stringBuilder = new StringBuilder(300);
/* 120 */     stringBuilder.append("CSymbolTable { \nCurrentScope: " + currentScopeAsString() + "\nDefinedSymbols:\n");
/*     */     
/* 122 */     Enumeration<String> enumeration = this.symTable.keys();
/* 123 */     Enumeration<TNode> enumeration1 = this.symTable.elements();
/* 124 */     while (enumeration.hasMoreElements()) {
/* 125 */       stringBuilder.append(((String)enumeration.nextElement()).toString());
/* 126 */       stringBuilder.append(" (").append(TNode.getNameForType(((TNode)enumeration1.nextElement()).getType())).append(")\n");
/*     */     } 
/* 128 */     stringBuilder.append("}\n");
/* 129 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/CSymbolTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */