/*    */ package com.jogamp.gluegen.cgram;
/*    */ 
/*    */ import antlr.ASTFactory;
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TNodeFactory
/*    */   extends ASTFactory
/*    */ {
/*    */   public AST create() {
/* 13 */     return (AST)new TNode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AST create(int paramInt, String paramString) {
/* 19 */     TNode tNode = new TNode();
/* 20 */     tNode.setType(paramInt);
/* 21 */     tNode.setText(paramString);
/* 22 */     return (AST)tNode;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AST create(AST paramAST) {
/* 28 */     TNode tNode = new TNode();
/* 29 */     tNode.setType(paramAST.getType());
/* 30 */     tNode.setText(paramAST.getText());
/* 31 */     return (AST)tNode;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/TNodeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */