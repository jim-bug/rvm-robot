/*    */ package com.jogamp.gluegen.cgram;
/*    */ 
/*    */ import com.jogamp.gluegen.ASTLocusTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Define
/*    */   implements ASTLocusTag.ASTLocusTagProvider
/*    */ {
/*    */   private final String name;
/*    */   private final String value;
/*    */   private final ASTLocusTag astLocus;
/*    */   
/*    */   public Define(String paramString1, String paramString2) {
/* 54 */     this.name = paramString1;
/* 55 */     this.value = paramString2;
/* 56 */     this.astLocus = null;
/*    */   }
/*    */   
/*    */   public Define(String paramString1, String paramString2, ASTLocusTag paramASTLocusTag) {
/* 60 */     this.name = paramString1;
/* 61 */     this.value = paramString2;
/* 62 */     this.astLocus = paramASTLocusTag;
/*    */   }
/*    */   
/* 65 */   public String getName() { return this.name; } public String getValue() {
/* 66 */     return this.value;
/*    */   }
/*    */   public ASTLocusTag getASTLocusTag() {
/* 69 */     return this.astLocus;
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/Define.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */