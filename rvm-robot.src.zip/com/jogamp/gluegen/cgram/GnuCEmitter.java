/*      */ package com.jogamp.gluegen.cgram;
/*      */ 
/*      */ import antlr.ASTNULLType;
/*      */ import antlr.MismatchedTokenException;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.TreeParser;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import java.io.PrintStream;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Stack;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GnuCEmitter
/*      */   extends TreeParser
/*      */   implements GnuCEmitterTokenTypes
/*      */ {
/*   29 */   int tabs = 0;
/*   30 */   PrintStream currentOutput = System.out;
/*   31 */   int lineNum = 1;
/*   32 */   String currentSource = "";
/*      */   LineObject trueSourceFile;
/*   34 */   final int lineDirectiveThreshold = Integer.MAX_VALUE;
/*   35 */   PreprocessorInfoChannel preprocessorInfoChannel = null;
/*   36 */   Stack sourceFiles = new Stack();
/*      */ 
/*      */ 
/*      */   
/*      */   int traceDepth;
/*      */ 
/*      */ 
/*      */   
/*      */   void initializePrinting() {
/*   45 */     Vector<Object> vector = this.preprocessorInfoChannel.extractLinesPrecedingTokenNumber(new Integer(1));
/*   46 */     printPreprocs(vector);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void finalizePrinting() {
/*   58 */     printPreprocs(this.preprocessorInfoChannel
/*   59 */         .extractLinesPrecedingTokenNumber(new Integer(this.preprocessorInfoChannel
/*   60 */             .getMaxTokenNumber() + 1)));
/*      */     
/*   62 */     this.currentOutput.println();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printPreprocs(Vector paramVector) {
/*   69 */     if (paramVector.size() > 0) {
/*   70 */       if (this.trueSourceFile != null) {
/*   71 */         this.currentOutput.println();
/*      */       }
/*   73 */       this.lineNum++;
/*   74 */       Enumeration<Object> enumeration = paramVector.elements();
/*   75 */       while (enumeration.hasMoreElements()) {
/*      */         
/*   77 */         LineObject lineObject = (LineObject)enumeration.nextElement();
/*   78 */         if (lineObject.getClass().getName().equals("LineObject")) {
/*   79 */           LineObject lineObject1 = lineObject;
/*      */ 
/*      */ 
/*      */           
/*   83 */           if (this.trueSourceFile != null && 
/*   84 */             !this.currentSource.equals(this.trueSourceFile.getSource()) && this.trueSourceFile
/*   85 */             .getSource().equals(lineObject1.getSource())) {
/*   86 */             lineObject1.setEnteringFile(false);
/*   87 */             lineObject1.setReturningToFile(true);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*   92 */           this.currentOutput.println(lineObject1);
/*   93 */           this.lineNum = lineObject1.getLine();
/*   94 */           this.currentSource = lineObject1.getSource();
/*      */ 
/*      */ 
/*      */           
/*   98 */           if (this.trueSourceFile == null) {
/*   99 */             this.trueSourceFile = new LineObject(this.currentSource);
/*  100 */             this.sourceFiles.push(this.trueSourceFile);
/*      */           } 
/*      */ 
/*      */           
/*  104 */           if (lineObject1.getEnteringFile()) {
/*  105 */             this.sourceFiles.push(lineObject1);
/*      */           }
/*      */ 
/*      */           
/*  109 */           if (lineObject1.getReturningToFile()) {
/*  110 */             LineObject lineObject2 = this.sourceFiles.peek();
/*  111 */             while (lineObject2 != this.trueSourceFile && !lineObject1.getSource().equals(lineObject2.getSource())) {
/*  112 */               this.sourceFiles.pop();
/*  113 */               lineObject2 = this.sourceFiles.peek();
/*      */             } 
/*      */           } 
/*      */           continue;
/*      */         } 
/*  118 */         this.currentOutput.println(lineObject);
/*  119 */         this.lineNum++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void print(TNode paramTNode) {
/*  127 */     int i = paramTNode.getLocalLineNum();
/*  128 */     if (i == 0) i = this.lineNum;
/*      */     
/*  130 */     Vector<Object> vector = this.preprocessorInfoChannel.extractLinesPrecedingTokenNumber((Integer)paramTNode.getAttribute("tokenNumber"));
/*  131 */     printPreprocs(vector);
/*      */     
/*  133 */     if (this.lineNum != i) {
/*      */ 
/*      */ 
/*      */       
/*  137 */       this.currentOutput.println();
/*  138 */       this.lineNum++;
/*  139 */       printTabs();
/*      */     } 
/*      */     
/*  142 */     if (this.lineNum != i) {
/*      */ 
/*      */ 
/*      */       
/*  146 */       int j = i - this.lineNum;
/*  147 */       if (this.lineNum < i) {
/*      */         
/*  149 */         for (; this.lineNum < i; this.lineNum++) {
/*  150 */           this.currentOutput.println();
/*      */         }
/*  152 */         printTabs();
/*      */       } else {
/*      */         
/*  155 */         this.lineNum = i;
/*      */       } 
/*      */     } 
/*  158 */     this.currentOutput.print(paramTNode.getText() + " ");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printAddingLineDirectives(TNode paramTNode) {
/*  167 */     int i = paramTNode.getLocalLineNum();
/*  168 */     String str = (String)paramTNode.getAttribute("source");
/*      */     
/*  170 */     if (str == null) str = this.currentSource; 
/*  171 */     if (i == 0) i = this.lineNum;
/*      */     
/*  173 */     Vector<Object> vector = this.preprocessorInfoChannel.extractLinesPrecedingTokenNumber((Integer)paramTNode.getAttribute("tokenNumber"));
/*  174 */     printPreprocs(vector);
/*      */     
/*  176 */     if (this.lineNum != i || !this.currentSource.equals(str)) {
/*      */ 
/*      */ 
/*      */       
/*  180 */       this.currentOutput.println();
/*  181 */       this.lineNum++;
/*  182 */       printTabs();
/*      */     } 
/*      */     
/*  185 */     if (this.lineNum != i || !this.currentSource.equals(str))
/*      */     {
/*      */       
/*  188 */       if (this.currentSource.equals(str)) {
/*  189 */         int j = i - this.lineNum;
/*  190 */         if (j > 0 && j < Integer.MAX_VALUE) {
/*      */           
/*  192 */           for (; this.lineNum < i; this.lineNum++) {
/*  193 */             this.currentOutput.println();
/*      */           
/*      */           }
/*      */         
/*      */         }
/*  198 */         else if (!this.sourceFiles.empty()) {
/*  199 */           LineObject lineObject = this.sourceFiles.peek();
/*  200 */           StringBuilder stringBuilder = new StringBuilder("");
/*  201 */           if (lineObject.getSystemHeader()) {
/*  202 */             stringBuilder.append(" 3");
/*      */           }
/*  204 */           if (lineObject.getTreatAsC()) {
/*  205 */             stringBuilder.append(" 4");
/*      */           }
/*  207 */           this.currentOutput.println("# " + i + " \"" + str + "\"" + stringBuilder.toString());
/*  208 */           this.lineNum = i;
/*      */         } 
/*      */ 
/*      */         
/*  212 */         printTabs();
/*      */       } else {
/*      */         
/*  215 */         Enumeration<LineObject> enumeration = this.sourceFiles.elements();
/*      */         
/*  217 */         boolean bool = false;
/*  218 */         while (enumeration.hasMoreElements()) {
/*  219 */           LineObject lineObject = enumeration.nextElement();
/*  220 */           if (lineObject.getSource().equals(str)) {
/*  221 */             bool = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*  225 */         if (bool) {
/*      */           
/*  227 */           LineObject lineObject = this.sourceFiles.peek();
/*  228 */           while (lineObject != this.trueSourceFile && !lineObject.getSource().equals(str)) {
/*  229 */             this.sourceFiles.pop();
/*  230 */             lineObject = this.sourceFiles.peek();
/*      */           } 
/*      */ 
/*      */           
/*  234 */           StringBuilder stringBuilder = new StringBuilder(" 2");
/*  235 */           if (lineObject.getSystemHeader()) {
/*  236 */             stringBuilder.append(" 3");
/*      */           }
/*  238 */           if (lineObject.getTreatAsC()) {
/*  239 */             stringBuilder.append(" 4");
/*      */           }
/*      */           
/*  242 */           this.currentOutput.println("# " + i + " \"" + str + "\"" + stringBuilder);
/*  243 */           this.lineNum = i;
/*  244 */           this.currentSource = str;
/*  245 */           printTabs();
/*      */         }
/*      */         else {
/*      */           
/*  249 */           this.currentOutput.println("# " + i + " \"" + str + "\" 1");
/*  250 */           this.lineNum = i;
/*  251 */           this.currentSource = str;
/*  252 */           printTabs();
/*      */         } 
/*      */       }  } 
/*  255 */     this.currentOutput.print(paramTNode.getText() + " ");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void print(String paramString) {
/*  261 */     this.currentOutput.print(paramString + " ");
/*      */   }
/*      */   
/*      */   void printTabs() {
/*  265 */     for (byte b = 0; b < this.tabs; b++) {
/*  266 */       this.currentOutput.print("\t");
/*      */     }
/*      */   }
/*      */   
/*      */   void commaSep(TNode paramTNode) {
/*  271 */     print(paramTNode);
/*  272 */     if (paramTNode.getNextSibling() != null)
/*  273 */       print(","); 
/*      */   }
/*      */   
/*      */   public GnuCEmitter(PreprocessorInfoChannel paramPreprocessorInfoChannel) {
/*  277 */     this.traceDepth = 0; this.preprocessorInfoChannel = paramPreprocessorInfoChannel; } public GnuCEmitter() { this.traceDepth = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  328 */     this.tokenNames = _tokenNames; }
/*      */   public void reportError(RecognitionException paramRecognitionException) { if (paramRecognitionException != null) { System.err.println("ANTLR Tree Parsing RecognitionException Error: " + paramRecognitionException.getClass().getName() + " " + paramRecognitionException); paramRecognitionException.printStackTrace(System.err); }  }
/*      */   public void reportError(NoViableAltException paramNoViableAltException) { System.err.println("ANTLR Tree Parsing NoViableAltException Error: " + paramNoViableAltException.toString()); TNode.printTree(paramNoViableAltException.node); paramNoViableAltException.printStackTrace(System.err); }
/*      */   public void reportError(MismatchedTokenException paramMismatchedTokenException) { if (paramMismatchedTokenException != null) { TNode.printTree(paramMismatchedTokenException.node); System.err.println("ANTLR Tree Parsing MismatchedTokenException Error: " + paramMismatchedTokenException); paramMismatchedTokenException.printStackTrace(System.err); }  }
/*      */   public void reportError(String paramString) { System.err.println("ANTLR Error from String: " + paramString); }
/*  333 */   public void reportWarning(String paramString) { System.err.println("ANTLR Warning from String: " + paramString); } public final void translationUnit(AST paramAST) throws RecognitionException { ASTNULLType aSTNULLType; AST aST; TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*  335 */     if (this.inputState.guessing == 0) {
/*  336 */       initializePrinting();
/*      */     }
/*      */     
/*  339 */     if (paramAST == null) aSTNULLType = ASTNULL; 
/*  340 */     switch (aSTNULLType.getType()) {
/*      */       
/*      */       case 5:
/*      */       case 9:
/*      */       case 117:
/*      */       case 127:
/*      */       case 140:
/*  347 */         externalList((AST)aSTNULLType);
/*  348 */         aST = this._retTree;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  357 */         throw new NoViableAltException(aST);
/*      */     } 
/*      */ 
/*      */     
/*  361 */     if (this.inputState.guessing == 0) {
/*  362 */       finalizePrinting();
/*      */     }
/*  364 */     this._retTree = aST; }
/*      */   protected void match(AST paramAST, int paramInt) throws MismatchedTokenException { super.match(paramAST, paramInt); }
/*      */   public void match(AST paramAST, BitSet paramBitSet) throws MismatchedTokenException { super.match(paramAST, paramBitSet); }
/*      */   protected void matchNot(AST paramAST, int paramInt) throws MismatchedTokenException { super.matchNot(paramAST, paramInt); }
/*      */   public void traceIn(String paramString, AST paramAST) { this.traceDepth++; for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }  super.traceIn(paramString, paramAST); }
/*  369 */   public void traceOut(String paramString, AST paramAST) { for (byte b = 0; b < this.traceDepth; ) { System.out.print(" "); b++; }  super.traceOut(paramString, paramAST); this.traceDepth--; } public final void externalList(AST paramAST) throws RecognitionException { AST aST; TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/*  373 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*  376 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  377 */         if (_tokenSet_0.member(aSTNULLType.getType())) {
/*  378 */           externalDef((AST)aSTNULLType);
/*  379 */           aST = this._retTree;
/*      */         } else {
/*      */           
/*  382 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/*  385 */         b++;
/*      */       }
/*      */     
/*      */     }
/*  389 */     catch (RecognitionException recognitionException) {
/*  390 */       if (this.inputState.guessing == 0) {
/*  391 */         reportError(recognitionException);
/*  392 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  394 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  397 */     this._retTree = aST; }
/*      */ 
/*      */   
/*      */   public final void externalDef(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  402 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  403 */     TNode tNode2 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  406 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  407 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 117:
/*  410 */           declaration((AST)aSTNULLType);
/*  411 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 127:
/*  416 */           functionDef(aST);
/*  417 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*  422 */           asm_expr(aST);
/*  423 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 140:
/*  428 */           typelessDeclaration(aST);
/*  429 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*  434 */           tNode2 = (TNode)aST;
/*  435 */           match(aST, 9);
/*  436 */           aST = aST.getNextSibling();
/*  437 */           if (this.inputState.guessing == 0) {
/*  438 */             print(tNode2);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  444 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/*  448 */     } catch (RecognitionException recognitionException) {
/*  449 */       if (this.inputState.guessing == 0) {
/*  450 */         reportError(recognitionException);
/*  451 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  453 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  456 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declaration(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  461 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  462 */     TNode tNode2 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  465 */       AST aST1 = paramAST;
/*  466 */       TNode tNode = (TNode)paramAST;
/*  467 */       match(paramAST, 117);
/*  468 */       paramAST = paramAST.getFirstChild();
/*  469 */       declSpecifiers(paramAST);
/*  470 */       paramAST = this._retTree;
/*      */       
/*  472 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  473 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 114:
/*  476 */           initDeclList((AST)aSTNULLType);
/*  477 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  486 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  491 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType1;
/*      */         AST aST2;
/*  494 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/*  495 */         if (aSTNULLType1.getType() == 9) {
/*  496 */           tNode2 = (TNode)aSTNULLType1;
/*  497 */           match((AST)aSTNULLType1, 9);
/*  498 */           aST2 = aSTNULLType1.getNextSibling();
/*  499 */           if (this.inputState.guessing == 0) {
/*  500 */             print(tNode2);
/*      */           }
/*      */         } else {
/*      */           
/*  504 */           if (b >= 1) break;  throw new NoViableAltException(aST2);
/*      */         } 
/*      */         
/*  507 */         b++;
/*      */       } 
/*      */       
/*  510 */       aST = aST1;
/*  511 */       aST = aST.getNextSibling();
/*      */     }
/*  513 */     catch (RecognitionException recognitionException) {
/*  514 */       if (this.inputState.guessing == 0) {
/*  515 */         reportError(recognitionException);
/*  516 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  518 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  521 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void functionDef(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  526 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  527 */     TNode tNode2 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  530 */       AST aST1 = paramAST;
/*  531 */       TNode tNode = (TNode)paramAST;
/*  532 */       match(paramAST, 127);
/*  533 */       paramAST = paramAST.getFirstChild();
/*      */       
/*  535 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  536 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 6:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/*      */         case 18:
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 113:
/*      */         case 160:
/*      */         case 161:
/*      */         case 162:
/*  558 */           functionDeclSpecifiers((AST)aSTNULLType);
/*  559 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 115:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  568 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/*  572 */       declarator(aST);
/*  573 */       aST = this._retTree;
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType1;
/*  577 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/*  578 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 117:
/*  581 */             declaration((AST)aSTNULLType1);
/*  582 */             aST = this._retTree;
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 51:
/*  587 */             tNode2 = (TNode)aST;
/*  588 */             match(aST, 51);
/*  589 */             aST = aST.getNextSibling();
/*  590 */             if (this.inputState.guessing == 0) {
/*  591 */               print(tNode2);
/*      */             }
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  602 */       compoundStatement(aST);
/*  603 */       aST = this._retTree;
/*  604 */       aST = aST1;
/*  605 */       aST = aST.getNextSibling();
/*      */     }
/*  607 */     catch (RecognitionException recognitionException) {
/*  608 */       if (this.inputState.guessing == 0) {
/*  609 */         reportError(recognitionException);
/*  610 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  612 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  615 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void asm_expr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  620 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  621 */     TNode tNode2 = null;
/*  622 */     TNode tNode3 = null;
/*  623 */     TNode tNode4 = null;
/*  624 */     TNode tNode5 = null;
/*  625 */     TNode tNode6 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  628 */       AST aST1 = paramAST;
/*  629 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  630 */       match(paramAST, 5);
/*  631 */       paramAST = paramAST.getFirstChild();
/*  632 */       if (this.inputState.guessing == 0) {
/*  633 */         print(tNode2);
/*      */       }
/*      */       
/*  636 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  637 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 6:
/*  640 */           tNode3 = (TNode)aSTNULLType;
/*  641 */           match((AST)aSTNULLType, 6);
/*  642 */           aST = aSTNULLType.getNextSibling();
/*  643 */           if (this.inputState.guessing == 0) {
/*  644 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  654 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/*  658 */       tNode4 = (TNode)aST;
/*  659 */       match(aST, 7);
/*  660 */       aST = aST.getNextSibling();
/*  661 */       if (this.inputState.guessing == 0) {
/*  662 */         print(tNode4); this.tabs++;
/*      */       } 
/*  664 */       expr(aST);
/*  665 */       aST = this._retTree;
/*  666 */       tNode5 = (TNode)aST;
/*  667 */       match(aST, 8);
/*  668 */       aST = aST.getNextSibling();
/*  669 */       if (this.inputState.guessing == 0) {
/*  670 */         this.tabs--; print(tNode5);
/*      */       } 
/*  672 */       tNode6 = (TNode)aST;
/*  673 */       match(aST, 9);
/*  674 */       aST = aST.getNextSibling();
/*  675 */       if (this.inputState.guessing == 0) {
/*  676 */         print(tNode6);
/*      */       }
/*  678 */       aST = aST1;
/*  679 */       aST = aST.getNextSibling();
/*      */     }
/*  681 */     catch (RecognitionException recognitionException) {
/*  682 */       if (this.inputState.guessing == 0) {
/*  683 */         reportError(recognitionException);
/*  684 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  686 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  689 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typelessDeclaration(AST paramAST) throws RecognitionException {
/*  694 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  695 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/*  698 */       AST aST = paramAST;
/*  699 */       TNode tNode = (TNode)paramAST;
/*  700 */       match(paramAST, 140);
/*  701 */       paramAST = paramAST.getFirstChild();
/*  702 */       initDeclList(paramAST);
/*  703 */       paramAST = this._retTree;
/*  704 */       tNode2 = (TNode)paramAST;
/*  705 */       match(paramAST, 9);
/*  706 */       paramAST = paramAST.getNextSibling();
/*  707 */       paramAST = aST;
/*  708 */       paramAST = paramAST.getNextSibling();
/*  709 */       if (this.inputState.guessing == 0) {
/*  710 */         print(tNode2);
/*      */       }
/*      */     }
/*  713 */     catch (RecognitionException recognitionException) {
/*  714 */       if (this.inputState.guessing == 0) {
/*  715 */         reportError(recognitionException);
/*  716 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/*  718 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  721 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void initDeclList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  726 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/*  729 */       initDecl(paramAST);
/*  730 */       paramAST = this._retTree;
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*  734 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  735 */         if (aSTNULLType.getType() == 114) {
/*  736 */           if (this.inputState.guessing == 0) {
/*  737 */             print(",");
/*      */           }
/*  739 */           initDecl((AST)aSTNULLType);
/*  740 */           aST = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  749 */     } catch (RecognitionException recognitionException) {
/*  750 */       if (this.inputState.guessing == 0) {
/*  751 */         reportError(recognitionException);
/*  752 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  754 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  757 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void expr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  762 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  765 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  766 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/*      */         case 46:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 130:
/*  798 */           binaryExpr((AST)aSTNULLType);
/*  799 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 74:
/*  804 */           conditionalExpr(aST);
/*  805 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 118:
/*  810 */           castExpr(aST);
/*  811 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 131:
/*      */         case 164:
/*  820 */           unaryExpr(aST);
/*  821 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 133:
/*  826 */           postfixExpr(aST);
/*  827 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 99:
/*      */         case 120:
/*      */         case 135:
/*      */         case 158:
/*  836 */           primaryExpr(aST);
/*  837 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 125:
/*  842 */           emptyExpr(aST);
/*  843 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/*  848 */           compoundStatementExpr(aST);
/*  849 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 123:
/*      */         case 137:
/*  855 */           initializer(aST);
/*  856 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 134:
/*  861 */           rangeExpr(aST);
/*  862 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 139:
/*  867 */           gnuAsmExpr(aST);
/*  868 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  873 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/*  877 */     } catch (RecognitionException recognitionException) {
/*  878 */       if (this.inputState.guessing == 0) {
/*  879 */         reportError(recognitionException);
/*  880 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  882 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  885 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declSpecifiers(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  890 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/*  894 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*  897 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/*  898 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 4:
/*      */           case 13:
/*      */           case 14:
/*      */           case 15:
/*      */           case 16:
/*      */           case 160:
/*  906 */             storageClassSpecifier((AST)aSTNULLType);
/*  907 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/*  913 */             typeQualifier(aST);
/*  914 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/*  933 */             typeSpecifier(aST);
/*  934 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  939 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/*  942 */         b++;
/*      */       }
/*      */     
/*      */     }
/*  946 */     catch (RecognitionException recognitionException) {
/*  947 */       if (this.inputState.guessing == 0) {
/*  948 */         reportError(recognitionException);
/*  949 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/*  951 */         throw recognitionException;
/*      */       } 
/*      */     } 
/*  954 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void storageClassSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/*  959 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*  960 */     TNode tNode2 = null;
/*  961 */     TNode tNode3 = null;
/*  962 */     TNode tNode4 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/*  965 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/*  966 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 13:
/*  969 */           tNode2 = (TNode)aSTNULLType;
/*  970 */           match((AST)aSTNULLType, 13);
/*  971 */           aST = aSTNULLType.getNextSibling();
/*  972 */           if (this.inputState.guessing == 0) {
/*  973 */             print(tNode2);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 14:
/*  979 */           tNode3 = (TNode)aST;
/*  980 */           match(aST, 14);
/*  981 */           aST = aST.getNextSibling();
/*  982 */           if (this.inputState.guessing == 0) {
/*  983 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/*  989 */           tNode4 = (TNode)aST;
/*  990 */           match(aST, 4);
/*  991 */           aST = aST.getNextSibling();
/*  992 */           if (this.inputState.guessing == 0) {
/*  993 */             print(tNode4);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 15:
/*      */         case 16:
/*      */         case 160:
/* 1001 */           functionStorageClassSpecifier(aST);
/* 1002 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1007 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1011 */     } catch (RecognitionException recognitionException) {
/* 1012 */       if (this.inputState.guessing == 0) {
/* 1013 */         reportError(recognitionException);
/* 1014 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1016 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1019 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void typeQualifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1024 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1025 */     TNode tNode2 = null;
/* 1026 */     TNode tNode3 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1029 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1030 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 17:
/* 1033 */           tNode2 = (TNode)aSTNULLType;
/* 1034 */           match((AST)aSTNULLType, 17);
/* 1035 */           aST = aSTNULLType.getNextSibling();
/* 1036 */           if (this.inputState.guessing == 0) {
/* 1037 */             print(tNode2);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 6:
/* 1043 */           tNode3 = (TNode)aST;
/* 1044 */           match(aST, 6);
/* 1045 */           aST = aST.getNextSibling();
/* 1046 */           if (this.inputState.guessing == 0) {
/* 1047 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1053 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1057 */     } catch (RecognitionException recognitionException) {
/* 1058 */       if (this.inputState.guessing == 0) {
/* 1059 */         reportError(recognitionException);
/* 1060 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1062 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1065 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void typeSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1070 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1071 */     TNode tNode2 = null;
/* 1072 */     TNode tNode3 = null;
/* 1073 */     TNode tNode4 = null;
/* 1074 */     TNode tNode5 = null;
/* 1075 */     TNode tNode6 = null;
/* 1076 */     TNode tNode7 = null;
/* 1077 */     TNode tNode8 = null;
/* 1078 */     TNode tNode9 = null;
/* 1079 */     TNode tNode10 = null;
/* 1080 */     TNode tNode11 = null;
/* 1081 */     TNode tNode12 = null;
/* 1082 */     TNode tNode13 = null;
/* 1083 */     TNode tNode14 = null; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1;
/*      */       AST aST2;
/* 1086 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 1087 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 18:
/* 1090 */           tNode2 = (TNode)aSTNULLType2;
/* 1091 */           match((AST)aSTNULLType2, 18);
/* 1092 */           aST1 = aSTNULLType2.getNextSibling();
/* 1093 */           if (this.inputState.guessing == 0) {
/* 1094 */             print(tNode2);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 19:
/* 1100 */           tNode3 = (TNode)aST1;
/* 1101 */           match(aST1, 19);
/* 1102 */           aST1 = aST1.getNextSibling();
/* 1103 */           if (this.inputState.guessing == 0) {
/* 1104 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 20:
/* 1110 */           tNode4 = (TNode)aST1;
/* 1111 */           match(aST1, 20);
/* 1112 */           aST1 = aST1.getNextSibling();
/* 1113 */           if (this.inputState.guessing == 0) {
/* 1114 */             print(tNode4);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 21:
/* 1120 */           tNode5 = (TNode)aST1;
/* 1121 */           match(aST1, 21);
/* 1122 */           aST1 = aST1.getNextSibling();
/* 1123 */           if (this.inputState.guessing == 0) {
/* 1124 */             print(tNode5);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 22:
/* 1130 */           tNode6 = (TNode)aST1;
/* 1131 */           match(aST1, 22);
/* 1132 */           aST1 = aST1.getNextSibling();
/* 1133 */           if (this.inputState.guessing == 0) {
/* 1134 */             print(tNode6);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 23:
/* 1140 */           tNode7 = (TNode)aST1;
/* 1141 */           match(aST1, 23);
/* 1142 */           aST1 = aST1.getNextSibling();
/* 1143 */           if (this.inputState.guessing == 0) {
/* 1144 */             print(tNode7);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 24:
/* 1150 */           tNode8 = (TNode)aST1;
/* 1151 */           match(aST1, 24);
/* 1152 */           aST1 = aST1.getNextSibling();
/* 1153 */           if (this.inputState.guessing == 0) {
/* 1154 */             print(tNode8);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 25:
/* 1160 */           tNode9 = (TNode)aST1;
/* 1161 */           match(aST1, 25);
/* 1162 */           aST1 = aST1.getNextSibling();
/* 1163 */           if (this.inputState.guessing == 0) {
/* 1164 */             print(tNode9);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 26:
/* 1170 */           tNode10 = (TNode)aST1;
/* 1171 */           match(aST1, 26);
/* 1172 */           aST1 = aST1.getNextSibling();
/* 1173 */           if (this.inputState.guessing == 0) {
/* 1174 */             print(tNode10);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 10:
/* 1180 */           structSpecifier(aST1);
/* 1181 */           aST1 = this._retTree;
/*      */ 
/*      */           
/*      */           while (true) {
/* 1185 */             if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1186 */             if (aSTNULLType1.getType() == 138 || aSTNULLType1.getType() == 163) {
/* 1187 */               attributeDecl((AST)aSTNULLType1);
/* 1188 */               aST1 = this._retTree;
/*      */               continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 11:
/* 1200 */           unionSpecifier(aST1);
/* 1201 */           aST1 = this._retTree;
/*      */ 
/*      */           
/*      */           while (true) {
/* 1205 */             if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1206 */             if (aSTNULLType1.getType() == 138 || aSTNULLType1.getType() == 163) {
/* 1207 */               attributeDecl((AST)aSTNULLType1);
/* 1208 */               aST1 = this._retTree;
/*      */               continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 12:
/* 1220 */           enumSpecifier(aST1);
/* 1221 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 113:
/* 1226 */           typedefName(aST1);
/* 1227 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 161:
/* 1232 */           aST2 = aST1;
/* 1233 */           tNode11 = (aST1 == ASTNULL) ? null : (TNode)aST1;
/* 1234 */           match(aST1, 161);
/* 1235 */           aST1 = aST1.getFirstChild();
/* 1236 */           tNode12 = (TNode)aST1;
/* 1237 */           match(aST1, 47);
/* 1238 */           aST1 = aST1.getNextSibling();
/* 1239 */           if (this.inputState.guessing == 0) {
/* 1240 */             print(tNode11); print(tNode12);
/*      */           } 
/*      */           
/* 1243 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1244 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 6:
/*      */             case 10:
/*      */             case 11:
/*      */             case 12:
/*      */             case 17:
/*      */             case 18:
/*      */             case 19:
/*      */             case 20:
/*      */             case 21:
/*      */             case 22:
/*      */             case 23:
/*      */             case 24:
/*      */             case 25:
/*      */             case 26:
/*      */             case 113:
/*      */             case 161:
/*      */             case 162:
/* 1263 */               typeName((AST)aSTNULLType1);
/* 1264 */               aST = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 42:
/*      */             case 45:
/*      */             case 46:
/*      */             case 47:
/*      */             case 64:
/*      */             case 65:
/*      */             case 66:
/*      */             case 67:
/*      */             case 68:
/*      */             case 69:
/*      */             case 70:
/*      */             case 71:
/*      */             case 72:
/*      */             case 73:
/*      */             case 74:
/*      */             case 75:
/*      */             case 76:
/*      */             case 77:
/*      */             case 78:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/*      */             case 82:
/*      */             case 83:
/*      */             case 84:
/*      */             case 85:
/*      */             case 86:
/*      */             case 87:
/*      */             case 88:
/*      */             case 89:
/*      */             case 90:
/*      */             case 91:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 99:
/*      */             case 118:
/*      */             case 120:
/*      */             case 123:
/*      */             case 125:
/*      */             case 130:
/*      */             case 131:
/*      */             case 133:
/*      */             case 134:
/*      */             case 135:
/*      */             case 137:
/*      */             case 139:
/*      */             case 158:
/*      */             case 164:
/* 1317 */               expr(aST);
/* 1318 */               aST = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1323 */               throw new NoViableAltException(aST);
/*      */           } 
/*      */ 
/*      */           
/* 1327 */           tNode13 = (TNode)aST;
/* 1328 */           match(aST, 48);
/* 1329 */           aST = aST.getNextSibling();
/* 1330 */           if (this.inputState.guessing == 0) {
/* 1331 */             print(tNode13);
/*      */           }
/* 1333 */           aST = aST2;
/* 1334 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 162:
/* 1339 */           tNode14 = (TNode)aST;
/* 1340 */           match(aST, 162);
/* 1341 */           aST = aST.getNextSibling();
/* 1342 */           if (this.inputState.guessing == 0) {
/* 1343 */             print(tNode14);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1349 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1353 */     } catch (RecognitionException recognitionException) {
/* 1354 */       if (this.inputState.guessing == 0) {
/* 1355 */         reportError(recognitionException);
/* 1356 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1358 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1361 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void functionStorageClassSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1366 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1367 */     TNode tNode2 = null;
/* 1368 */     TNode tNode3 = null;
/* 1369 */     TNode tNode4 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1372 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1373 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 15:
/* 1376 */           tNode2 = (TNode)aSTNULLType;
/* 1377 */           match((AST)aSTNULLType, 15);
/* 1378 */           aST = aSTNULLType.getNextSibling();
/* 1379 */           if (this.inputState.guessing == 0) {
/* 1380 */             print(tNode2);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 16:
/* 1386 */           tNode3 = (TNode)aST;
/* 1387 */           match(aST, 16);
/* 1388 */           aST = aST.getNextSibling();
/* 1389 */           if (this.inputState.guessing == 0) {
/* 1390 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 160:
/* 1396 */           tNode4 = (TNode)aST;
/* 1397 */           match(aST, 160);
/* 1398 */           aST = aST.getNextSibling();
/* 1399 */           if (this.inputState.guessing == 0) {
/* 1400 */             print(tNode4);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1406 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1410 */     } catch (RecognitionException recognitionException) {
/* 1411 */       if (this.inputState.guessing == 0) {
/* 1412 */         reportError(recognitionException);
/* 1413 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1415 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1418 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structSpecifier(AST paramAST) throws RecognitionException {
/* 1423 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1424 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 1427 */       AST aST = paramAST;
/* 1428 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1429 */       match(paramAST, 10);
/* 1430 */       paramAST = paramAST.getFirstChild();
/* 1431 */       if (this.inputState.guessing == 0) {
/* 1432 */         print(tNode2);
/*      */       }
/* 1434 */       structOrUnionBody(paramAST);
/* 1435 */       paramAST = this._retTree;
/* 1436 */       paramAST = aST;
/* 1437 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 1439 */     catch (RecognitionException recognitionException) {
/* 1440 */       if (this.inputState.guessing == 0) {
/* 1441 */         reportError(recognitionException);
/* 1442 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1444 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1447 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void attributeDecl(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1452 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1453 */     TNode tNode2 = null;
/* 1454 */     TNode tNode3 = null;
/* 1455 */     TNode tNode4 = null;
/* 1456 */     TNode tNode5 = null;
/* 1457 */     TNode tNode6 = null; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3;
/*      */       AST aST2;
/* 1460 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 1461 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 163:
/* 1464 */           aSTNULLType3 = aSTNULLType2;
/* 1465 */           tNode2 = (aSTNULLType2 == ASTNULL) ? null : (TNode)aSTNULLType2;
/* 1466 */           match((AST)aSTNULLType2, 163);
/* 1467 */           aST1 = aSTNULLType2.getFirstChild();
/* 1468 */           if (this.inputState.guessing == 0) {
/* 1469 */             print(tNode2);
/*      */           }
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType;
/* 1474 */             if (aST1 == null) aSTNULLType = ASTNULL; 
/* 1475 */             if (aSTNULLType.getType() >= 4 && aSTNULLType.getType() <= 166) {
/* 1476 */               tNode3 = (TNode)aSTNULLType;
/* 1477 */               if (aSTNULLType == null) throw new MismatchedTokenException(); 
/* 1478 */               AST aST3 = aSTNULLType.getNextSibling();
/* 1479 */               if (this.inputState.guessing == 0) {
/* 1480 */                 print(tNode3);
/*      */               }
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/* 1489 */           aSTNULLType1 = aSTNULLType3;
/* 1490 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 138:
/* 1495 */           aST2 = aST;
/* 1496 */           tNode4 = (aST == ASTNULL) ? null : (TNode)aST;
/* 1497 */           match(aST, 138);
/* 1498 */           aST = aST.getFirstChild();
/* 1499 */           if (this.inputState.guessing == 0) {
/* 1500 */             print(tNode4);
/*      */           }
/* 1502 */           tNode5 = (TNode)aST;
/* 1503 */           match(aST, 47);
/* 1504 */           aST = aST.getNextSibling();
/* 1505 */           if (this.inputState.guessing == 0) {
/* 1506 */             print(tNode5);
/*      */           }
/* 1508 */           expr(aST);
/* 1509 */           aST = this._retTree;
/* 1510 */           if (this.inputState.guessing == 0) {
/* 1511 */             print(")");
/*      */           }
/* 1513 */           tNode6 = (TNode)aST;
/* 1514 */           match(aST, 48);
/* 1515 */           aST = aST.getNextSibling();
/* 1516 */           if (this.inputState.guessing == 0) {
/* 1517 */             print(tNode6);
/*      */           }
/* 1519 */           aST = aST2;
/* 1520 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1525 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 1529 */     } catch (RecognitionException recognitionException) {
/* 1530 */       if (this.inputState.guessing == 0) {
/* 1531 */         reportError(recognitionException);
/* 1532 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1534 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1537 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void unionSpecifier(AST paramAST) throws RecognitionException {
/* 1542 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1543 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 1546 */       AST aST = paramAST;
/* 1547 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1548 */       match(paramAST, 11);
/* 1549 */       paramAST = paramAST.getFirstChild();
/* 1550 */       if (this.inputState.guessing == 0) {
/* 1551 */         print(tNode2);
/*      */       }
/* 1553 */       structOrUnionBody(paramAST);
/* 1554 */       paramAST = this._retTree;
/* 1555 */       paramAST = aST;
/* 1556 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 1558 */     catch (RecognitionException recognitionException) {
/* 1559 */       if (this.inputState.guessing == 0) {
/* 1560 */         reportError(recognitionException);
/* 1561 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1563 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1566 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void enumSpecifier(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1571 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1572 */     TNode tNode2 = null;
/* 1573 */     TNode tNode3 = null;
/* 1574 */     TNode tNode4 = null;
/* 1575 */     TNode tNode5 = null; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/* 1578 */       AST aST2 = paramAST;
/* 1579 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1580 */       match(paramAST, 12);
/* 1581 */       paramAST = paramAST.getFirstChild();
/* 1582 */       if (this.inputState.guessing == 0) {
/* 1583 */         print(tNode2);
/*      */       }
/*      */       
/* 1586 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 1587 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 42:
/* 1590 */           tNode3 = (TNode)aSTNULLType2;
/* 1591 */           match((AST)aSTNULLType2, 42);
/* 1592 */           aST1 = aSTNULLType2.getNextSibling();
/* 1593 */           if (this.inputState.guessing == 0) {
/* 1594 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */         case 7:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1605 */           throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1610 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1611 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 7:
/* 1614 */           tNode4 = (TNode)aSTNULLType1;
/* 1615 */           match((AST)aSTNULLType1, 7);
/* 1616 */           aST = aSTNULLType1.getNextSibling();
/* 1617 */           if (this.inputState.guessing == 0) {
/* 1618 */             print(tNode4); this.tabs++;
/*      */           } 
/* 1620 */           enumList(aST);
/* 1621 */           aST = this._retTree;
/* 1622 */           tNode5 = (TNode)aST;
/* 1623 */           match(aST, 8);
/* 1624 */           aST = aST.getNextSibling();
/* 1625 */           if (this.inputState.guessing == 0) {
/* 1626 */             this.tabs--; print(tNode5);
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1636 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 1640 */       aST = aST2;
/* 1641 */       aST = aST.getNextSibling();
/*      */     }
/* 1643 */     catch (RecognitionException recognitionException) {
/* 1644 */       if (this.inputState.guessing == 0) {
/* 1645 */         reportError(recognitionException);
/* 1646 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1648 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1651 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void typedefName(AST paramAST) throws RecognitionException {
/* 1656 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1657 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 1660 */       AST aST = paramAST;
/* 1661 */       TNode tNode = (TNode)paramAST;
/* 1662 */       match(paramAST, 113);
/* 1663 */       paramAST = paramAST.getFirstChild();
/* 1664 */       tNode2 = (TNode)paramAST;
/* 1665 */       match(paramAST, 42);
/* 1666 */       paramAST = paramAST.getNextSibling();
/* 1667 */       if (this.inputState.guessing == 0) {
/* 1668 */         print(tNode2);
/*      */       }
/* 1670 */       paramAST = aST;
/* 1671 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 1673 */     catch (RecognitionException recognitionException) {
/* 1674 */       if (this.inputState.guessing == 0) {
/* 1675 */         reportError(recognitionException);
/* 1676 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1678 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1681 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void typeName(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1686 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1689 */       specifierQualifierList(paramAST);
/* 1690 */       paramAST = this._retTree;
/*      */       
/* 1692 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1693 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 122:
/* 1696 */           nonemptyAbstractDeclarator((AST)aSTNULLType);
/* 1697 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1706 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 1711 */     } catch (RecognitionException recognitionException) {
/* 1712 */       if (this.inputState.guessing == 0) {
/* 1713 */         reportError(recognitionException);
/* 1714 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1716 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1719 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void structOrUnionBody(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1724 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 1725 */     TNode tNode2 = null;
/* 1726 */     TNode tNode3 = null;
/* 1727 */     TNode tNode4 = null;
/* 1728 */     TNode tNode5 = null;
/* 1729 */     TNode tNode6 = null;
/* 1730 */     TNode tNode7 = null;
/*      */     
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 1734 */       boolean bool = false;
/* 1735 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1736 */       if (aSTNULLType.getType() == 42) {
/* 1737 */         ASTNULLType aSTNULLType1 = aSTNULLType;
/* 1738 */         bool = true;
/* 1739 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 1742 */           TNode tNode8 = (TNode)aSTNULLType;
/* 1743 */           match((AST)aSTNULLType, 42);
/* 1744 */           aST = aSTNULLType.getNextSibling();
/* 1745 */           TNode tNode9 = (TNode)aST;
/* 1746 */           match(aST, 7);
/* 1747 */           aST = aST.getNextSibling();
/*      */         
/*      */         }
/* 1750 */         catch (RecognitionException recognitionException) {
/* 1751 */           bool = false;
/*      */         } 
/* 1753 */         aSTNULLType = aSTNULLType1;
/* 1754 */         this.inputState.guessing--;
/*      */       } 
/* 1756 */       if (bool) {
/* 1757 */         ASTNULLType aSTNULLType1; tNode2 = (TNode)aSTNULLType;
/* 1758 */         match((AST)aSTNULLType, 42);
/* 1759 */         AST aST1 = aSTNULLType.getNextSibling();
/* 1760 */         tNode3 = (TNode)aST1;
/* 1761 */         match(aST1, 7);
/* 1762 */         aST1 = aST1.getNextSibling();
/* 1763 */         if (this.inputState.guessing == 0) {
/* 1764 */           print(tNode2); print("{"); this.tabs++;
/*      */         } 
/*      */         
/* 1767 */         if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 1768 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 1787 */             structDeclarationList((AST)aSTNULLType1);
/* 1788 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1797 */             throw new NoViableAltException(aST);
/*      */         } 
/*      */ 
/*      */         
/* 1801 */         tNode4 = (TNode)aST;
/* 1802 */         match(aST, 8);
/* 1803 */         aST = aST.getNextSibling();
/* 1804 */         if (this.inputState.guessing == 0) {
/* 1805 */           this.tabs--; print(tNode4);
/*      */         }
/*      */       
/* 1808 */       } else if (aST.getType() == 7) {
/* 1809 */         ASTNULLType aSTNULLType1; tNode5 = (TNode)aST;
/* 1810 */         match(aST, 7);
/* 1811 */         aST = aST.getNextSibling();
/* 1812 */         if (this.inputState.guessing == 0) {
/* 1813 */           print(tNode5); this.tabs++;
/*      */         } 
/*      */         
/* 1816 */         if (aST == null) aSTNULLType1 = ASTNULL; 
/* 1817 */         switch (aSTNULLType1.getType()) {
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 1836 */             structDeclarationList((AST)aSTNULLType1);
/* 1837 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1846 */             throw new NoViableAltException(aST);
/*      */         } 
/*      */ 
/*      */         
/* 1850 */         tNode6 = (TNode)aST;
/* 1851 */         match(aST, 8);
/* 1852 */         aST = aST.getNextSibling();
/* 1853 */         if (this.inputState.guessing == 0) {
/* 1854 */           this.tabs--; print(tNode6);
/*      */         }
/*      */       
/* 1857 */       } else if (aST.getType() == 42) {
/* 1858 */         tNode7 = (TNode)aST;
/* 1859 */         match(aST, 42);
/* 1860 */         aST = aST.getNextSibling();
/* 1861 */         if (this.inputState.guessing == 0) {
/* 1862 */           print(tNode7);
/*      */         }
/*      */       } else {
/*      */         
/* 1866 */         throw new NoViableAltException(aST);
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1871 */     catch (RecognitionException recognitionException) {
/* 1872 */       if (this.inputState.guessing == 0) {
/* 1873 */         reportError(recognitionException);
/* 1874 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1876 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1879 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void structDeclarationList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1884 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 1888 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1891 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1892 */         if (_tokenSet_1.member(aSTNULLType.getType())) {
/* 1893 */           structDeclaration((AST)aSTNULLType);
/* 1894 */           aST = this._retTree;
/* 1895 */           if (this.inputState.guessing == 0) {
/* 1896 */             print(";");
/*      */           }
/*      */         } else {
/*      */           
/* 1900 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 1903 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 1907 */     catch (RecognitionException recognitionException) {
/* 1908 */       if (this.inputState.guessing == 0) {
/* 1909 */         reportError(recognitionException);
/* 1910 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1912 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1915 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void structDeclaration(AST paramAST) throws RecognitionException {
/* 1920 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 1923 */       specifierQualifierList(paramAST);
/* 1924 */       paramAST = this._retTree;
/* 1925 */       structDeclaratorList(paramAST);
/* 1926 */       paramAST = this._retTree;
/*      */     }
/* 1928 */     catch (RecognitionException recognitionException) {
/* 1929 */       if (this.inputState.guessing == 0) {
/* 1930 */         reportError(recognitionException);
/* 1931 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 1933 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1936 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void specifierQualifierList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1941 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 1945 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 1948 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 1949 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 1966 */             typeSpecifier((AST)aSTNULLType);
/* 1967 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/* 1973 */             typeQualifier(aST);
/* 1974 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1979 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 1982 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 1986 */     catch (RecognitionException recognitionException) {
/* 1987 */       if (this.inputState.guessing == 0) {
/* 1988 */         reportError(recognitionException);
/* 1989 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 1991 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 1994 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void structDeclaratorList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 1999 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 2002 */       structDeclarator(paramAST);
/* 2003 */       paramAST = this._retTree;
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 2007 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2008 */         if (aSTNULLType.getType() == 116) {
/* 2009 */           if (this.inputState.guessing == 0) {
/* 2010 */             print(",");
/*      */           }
/* 2012 */           structDeclarator((AST)aSTNULLType);
/* 2013 */           aST = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2022 */     } catch (RecognitionException recognitionException) {
/* 2023 */       if (this.inputState.guessing == 0) {
/* 2024 */         reportError(recognitionException);
/* 2025 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2027 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2030 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void structDeclarator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2035 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2036 */     TNode tNode2 = null; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/* 2039 */       AST aST2 = paramAST;
/* 2040 */       TNode tNode = (TNode)paramAST;
/* 2041 */       match(paramAST, 116);
/* 2042 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 2044 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 2045 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 115:
/* 2048 */           declarator((AST)aSTNULLType2);
/* 2049 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */         case 44:
/*      */         case 138:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2061 */           throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2066 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 2067 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 44:
/* 2070 */           tNode2 = (TNode)aSTNULLType1;
/* 2071 */           match((AST)aSTNULLType1, 44);
/* 2072 */           aST = aSTNULLType1.getNextSibling();
/* 2073 */           if (this.inputState.guessing == 0) {
/* 2074 */             print(tNode2);
/*      */           }
/* 2076 */           expr(aST);
/* 2077 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */         case 138:
/*      */         case 163:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2088 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 2095 */         if (aST == null) aSTNULLType = ASTNULL; 
/* 2096 */         if (aSTNULLType.getType() == 138 || aSTNULLType.getType() == 163) {
/* 2097 */           attributeDecl((AST)aSTNULLType);
/* 2098 */           AST aST3 = this._retTree;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 2106 */       aST = aST2;
/* 2107 */       aST = aST.getNextSibling();
/*      */     }
/* 2109 */     catch (RecognitionException recognitionException) {
/* 2110 */       if (this.inputState.guessing == 0) {
/* 2111 */         reportError(recognitionException);
/* 2112 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2114 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2117 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declarator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2122 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2123 */     TNode tNode2 = null;
/* 2124 */     TNode tNode3 = null;
/* 2125 */     TNode tNode4 = null;
/* 2126 */     TNode tNode5 = null;
/* 2127 */     TNode tNode6 = null;
/* 2128 */     TNode tNode7 = null;
/* 2129 */     TNode tNode8 = null; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/* 2132 */       AST aST2 = paramAST;
/* 2133 */       TNode tNode = (TNode)paramAST;
/* 2134 */       match(paramAST, 115);
/* 2135 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 2137 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 2138 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 119:
/* 2141 */           pointerGroup((AST)aSTNULLType2);
/* 2142 */           aST1 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 42:
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2152 */           throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2157 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 2158 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 42:
/* 2161 */           tNode2 = (TNode)aSTNULLType1;
/* 2162 */           match((AST)aSTNULLType1, 42);
/* 2163 */           aST = aSTNULLType1.getNextSibling();
/* 2164 */           if (this.inputState.guessing == 0) {
/* 2165 */             print(tNode2);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/* 2171 */           tNode3 = (TNode)aST;
/* 2172 */           match(aST, 47);
/* 2173 */           aST = aST.getNextSibling();
/* 2174 */           if (this.inputState.guessing == 0) {
/* 2175 */             print(tNode3);
/*      */           }
/* 2177 */           declarator(aST);
/* 2178 */           aST = this._retTree;
/* 2179 */           tNode4 = (TNode)aST;
/* 2180 */           match(aST, 48);
/* 2181 */           aST = aST.getNextSibling();
/* 2182 */           if (this.inputState.guessing == 0) {
/* 2183 */             print(tNode4);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2189 */           throw new NoViableAltException(aST);
/*      */       }  while (true) {
/*      */         ASTNULLType aSTNULLType7; AST aST7; ASTNULLType aSTNULLType6; AST aST6; ASTNULLType aSTNULLType5; AST aST5; ASTNULLType aSTNULLType4;
/*      */         AST aST4;
/*      */         ASTNULLType aSTNULLType3;
/*      */         AST aST3;
/*      */         ASTNULLType aSTNULLType8;
/* 2196 */         if (aST == null) aSTNULLType7 = ASTNULL; 
/* 2197 */         switch (aSTNULLType7.getType()) {
/*      */           
/*      */           case 126:
/* 2200 */             aSTNULLType8 = aSTNULLType7;
/* 2201 */             tNode5 = (aSTNULLType7 == ASTNULL) ? null : (TNode)aSTNULLType7;
/* 2202 */             match((AST)aSTNULLType7, 126);
/* 2203 */             aST7 = aSTNULLType7.getFirstChild();
/* 2204 */             if (this.inputState.guessing == 0) {
/* 2205 */               print(tNode5);
/*      */             }
/*      */             
/* 2208 */             if (aST7 == null) aSTNULLType6 = ASTNULL; 
/* 2209 */             switch (aSTNULLType6.getType()) {
/*      */               
/*      */               case 129:
/* 2212 */                 parameterTypeList((AST)aSTNULLType6);
/* 2213 */                 aST6 = this._retTree;
/*      */                 break;
/*      */ 
/*      */ 
/*      */               
/*      */               case 42:
/*      */               case 48:
/* 2220 */                 if (aST6 == null) aSTNULLType5 = ASTNULL; 
/* 2221 */                 switch (aSTNULLType5.getType()) {
/*      */                   
/*      */                   case 42:
/* 2224 */                     idList((AST)aSTNULLType5);
/* 2225 */                     aST5 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */                 } 
/*      */ 
/*      */                 
/* 2234 */                 throw new NoViableAltException(aST5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               default:
/* 2242 */                 throw new NoViableAltException(aST5);
/*      */             } 
/*      */ 
/*      */             
/* 2246 */             tNode6 = (TNode)aST5;
/* 2247 */             match(aST5, 48);
/* 2248 */             aST5 = aST5.getNextSibling();
/* 2249 */             if (this.inputState.guessing == 0) {
/* 2250 */               print(tNode6);
/*      */             }
/* 2252 */             aSTNULLType4 = aSTNULLType8;
/* 2253 */             aST4 = aSTNULLType4.getNextSibling();
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 49:
/* 2258 */             tNode7 = (TNode)aST4;
/* 2259 */             match(aST4, 49);
/* 2260 */             aST4 = aST4.getNextSibling();
/* 2261 */             if (this.inputState.guessing == 0) {
/* 2262 */               print(tNode7);
/*      */             }
/*      */             
/* 2265 */             if (aST4 == null) aSTNULLType3 = ASTNULL; 
/* 2266 */             switch (aSTNULLType3.getType()) {
/*      */               
/*      */               case 42:
/*      */               case 45:
/*      */               case 46:
/*      */               case 47:
/*      */               case 64:
/*      */               case 65:
/*      */               case 66:
/*      */               case 67:
/*      */               case 68:
/*      */               case 69:
/*      */               case 70:
/*      */               case 71:
/*      */               case 72:
/*      */               case 73:
/*      */               case 74:
/*      */               case 75:
/*      */               case 76:
/*      */               case 77:
/*      */               case 78:
/*      */               case 79:
/*      */               case 80:
/*      */               case 81:
/*      */               case 82:
/*      */               case 83:
/*      */               case 84:
/*      */               case 85:
/*      */               case 86:
/*      */               case 87:
/*      */               case 88:
/*      */               case 89:
/*      */               case 90:
/*      */               case 91:
/*      */               case 92:
/*      */               case 93:
/*      */               case 94:
/*      */               case 99:
/*      */               case 118:
/*      */               case 120:
/*      */               case 123:
/*      */               case 125:
/*      */               case 130:
/*      */               case 131:
/*      */               case 133:
/*      */               case 134:
/*      */               case 135:
/*      */               case 137:
/*      */               case 139:
/*      */               case 158:
/*      */               case 164:
/* 2317 */                 expr((AST)aSTNULLType3);
/* 2318 */                 aST3 = this._retTree;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 50:
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 2327 */                 throw new NoViableAltException(aST3);
/*      */             } 
/*      */ 
/*      */             
/* 2331 */             tNode8 = (TNode)aST3;
/* 2332 */             match(aST3, 50);
/* 2333 */             aST3 = aST3.getNextSibling();
/* 2334 */             if (this.inputState.guessing == 0) {
/* 2335 */               print(tNode8);
/*      */             }
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2346 */       aST = aST2;
/* 2347 */       aST = aST.getNextSibling();
/*      */     }
/* 2349 */     catch (RecognitionException recognitionException) {
/* 2350 */       if (this.inputState.guessing == 0) {
/* 2351 */         reportError(recognitionException);
/* 2352 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2354 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2357 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void enumList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2362 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 2365 */       enumerator(paramAST);
/* 2366 */       paramAST = this._retTree;
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 2370 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2371 */         if (aSTNULLType.getType() == 42) {
/* 2372 */           if (this.inputState.guessing == 0) {
/* 2373 */             print(",");
/*      */           }
/* 2375 */           enumerator((AST)aSTNULLType);
/* 2376 */           aST = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2385 */     } catch (RecognitionException recognitionException) {
/* 2386 */       if (this.inputState.guessing == 0) {
/* 2387 */         reportError(recognitionException);
/* 2388 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2390 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2393 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void enumerator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2398 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2399 */     TNode tNode2 = null;
/* 2400 */     TNode tNode3 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 2403 */       tNode2 = (TNode)paramAST;
/* 2404 */       match(paramAST, 42);
/* 2405 */       paramAST = paramAST.getNextSibling();
/* 2406 */       if (this.inputState.guessing == 0) {
/* 2407 */         print(tNode2);
/*      */       }
/*      */       
/* 2410 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2411 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/* 2414 */           tNode3 = (TNode)aSTNULLType;
/* 2415 */           match((AST)aSTNULLType, 45);
/* 2416 */           aST = aSTNULLType.getNextSibling();
/* 2417 */           if (this.inputState.guessing == 0) {
/* 2418 */             print(tNode3);
/*      */           }
/* 2420 */           expr(aST);
/* 2421 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 42:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2431 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 2436 */     } catch (RecognitionException recognitionException) {
/* 2437 */       if (this.inputState.guessing == 0) {
/* 2438 */         reportError(recognitionException);
/* 2439 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2441 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2444 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void initDecl(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2449 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2450 */     TNode tNode2 = null;
/* 2451 */     TNode tNode3 = null;
/* 2452 */     String str = ""; try {
/*      */       AST aST1;
/*      */       ASTNULLType aSTNULLType;
/* 2455 */       AST aST2 = paramAST;
/* 2456 */       TNode tNode = (TNode)paramAST;
/* 2457 */       match(paramAST, 114);
/* 2458 */       paramAST = paramAST.getFirstChild();
/* 2459 */       declarator(paramAST);
/* 2460 */       paramAST = this._retTree;
/*      */ 
/*      */       
/*      */       while (true) {
/* 2464 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2465 */         if (aSTNULLType.getType() == 138 || aSTNULLType.getType() == 163) {
/* 2466 */           attributeDecl((AST)aSTNULLType);
/* 2467 */           aST1 = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 2476 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/* 2477 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/* 2480 */           tNode2 = (TNode)aSTNULLType;
/* 2481 */           match((AST)aSTNULLType, 45);
/* 2482 */           aST = aSTNULLType.getNextSibling();
/* 2483 */           if (this.inputState.guessing == 0) {
/* 2484 */             print(tNode2);
/*      */           }
/* 2486 */           initializer(aST);
/* 2487 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/* 2492 */           tNode3 = (TNode)aST;
/* 2493 */           match(aST, 44);
/* 2494 */           aST = aST.getNextSibling();
/* 2495 */           if (this.inputState.guessing == 0) {
/* 2496 */             print(tNode3);
/*      */           }
/* 2498 */           expr(aST);
/* 2499 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2508 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 2512 */       aST = aST2;
/* 2513 */       aST = aST.getNextSibling();
/*      */     }
/* 2515 */     catch (RecognitionException recognitionException) {
/* 2516 */       if (this.inputState.guessing == 0) {
/* 2517 */         reportError(recognitionException);
/* 2518 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2520 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2523 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void initializer(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2528 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType4;
/*      */       TNode tNode1;
/* 2531 */       if (paramAST == null) aSTNULLType3 = ASTNULL; 
/* 2532 */       switch (aSTNULLType3.getType()) {
/*      */         
/*      */         case 123:
/* 2535 */           aSTNULLType4 = aSTNULLType3;
/* 2536 */           tNode1 = (TNode)aSTNULLType3;
/* 2537 */           match((AST)aSTNULLType3, 123);
/* 2538 */           aST2 = aSTNULLType3.getFirstChild();
/*      */           
/* 2540 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 2541 */           switch (aSTNULLType2.getType()) {
/*      */             
/*      */             case 136:
/* 2544 */               initializerElementLabel((AST)aSTNULLType2);
/* 2545 */               aST1 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 42:
/*      */             case 45:
/*      */             case 46:
/*      */             case 47:
/*      */             case 64:
/*      */             case 65:
/*      */             case 66:
/*      */             case 67:
/*      */             case 68:
/*      */             case 69:
/*      */             case 70:
/*      */             case 71:
/*      */             case 72:
/*      */             case 73:
/*      */             case 74:
/*      */             case 75:
/*      */             case 76:
/*      */             case 77:
/*      */             case 78:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/*      */             case 82:
/*      */             case 83:
/*      */             case 84:
/*      */             case 85:
/*      */             case 86:
/*      */             case 87:
/*      */             case 88:
/*      */             case 89:
/*      */             case 90:
/*      */             case 91:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 99:
/*      */             case 118:
/*      */             case 120:
/*      */             case 123:
/*      */             case 125:
/*      */             case 130:
/*      */             case 131:
/*      */             case 133:
/*      */             case 134:
/*      */             case 135:
/*      */             case 137:
/*      */             case 139:
/*      */             case 158:
/*      */             case 164:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 2602 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 2606 */           expr(aST1);
/* 2607 */           aST1 = this._retTree;
/* 2608 */           aSTNULLType1 = aSTNULLType4;
/* 2609 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 137:
/* 2614 */           lcurlyInitializer(aST);
/* 2615 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2620 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 2624 */     } catch (RecognitionException recognitionException) {
/* 2625 */       if (this.inputState.guessing == 0) {
/* 2626 */         reportError(recognitionException);
/* 2627 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2629 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2632 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void pointerGroup(AST paramAST) throws RecognitionException {
/* 2637 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2638 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 2641 */       AST aST = paramAST;
/* 2642 */       TNode tNode = (TNode)paramAST;
/* 2643 */       match(paramAST, 119);
/* 2644 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 2646 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/* 2649 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2650 */         if (aSTNULLType.getType() == 46) {
/* 2651 */           tNode2 = (TNode)aSTNULLType;
/* 2652 */           match((AST)aSTNULLType, 46);
/* 2653 */           aST1 = aSTNULLType.getNextSibling();
/* 2654 */           if (this.inputState.guessing == 0) {
/* 2655 */             print(tNode2);
/*      */           }
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType1;
/* 2660 */             if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 2661 */             if (aSTNULLType1.getType() == 6 || aSTNULLType1.getType() == 17) {
/* 2662 */               typeQualifier((AST)aSTNULLType1);
/* 2663 */               aST1 = this._retTree;
/*      */ 
/*      */               
/*      */               continue;
/*      */             } 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } else {
/* 2673 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 2676 */         b++;
/*      */       } 
/*      */       
/* 2679 */       paramAST = aST;
/* 2680 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 2682 */     catch (RecognitionException recognitionException) {
/* 2683 */       if (this.inputState.guessing == 0) {
/* 2684 */         reportError(recognitionException);
/* 2685 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 2687 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2690 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void idList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2695 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2696 */     TNode tNode2 = null;
/* 2697 */     TNode tNode3 = null;
/* 2698 */     TNode tNode4 = null;
/*      */     
/*      */     try {
/* 2701 */       tNode2 = (TNode)paramAST;
/* 2702 */       match(paramAST, 42);
/* 2703 */       paramAST = paramAST.getNextSibling();
/* 2704 */       if (this.inputState.guessing == 0) {
/* 2705 */         print(tNode2);
/*      */       }
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 2710 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2711 */         if (aSTNULLType.getType() == 43) {
/* 2712 */           tNode3 = (TNode)aSTNULLType;
/* 2713 */           match((AST)aSTNULLType, 43);
/* 2714 */           aST = aSTNULLType.getNextSibling();
/* 2715 */           if (this.inputState.guessing == 0) {
/* 2716 */             print(tNode3);
/*      */           }
/* 2718 */           tNode4 = (TNode)aST;
/* 2719 */           match(aST, 42);
/* 2720 */           aST = aST.getNextSibling();
/* 2721 */           if (this.inputState.guessing == 0) {
/* 2722 */             print(tNode4);
/*      */           }
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2732 */     } catch (RecognitionException recognitionException) {
/* 2733 */       if (this.inputState.guessing == 0) {
/* 2734 */         reportError(recognitionException);
/* 2735 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2737 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2740 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void initializerElementLabel(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2745 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2746 */     TNode tNode2 = null;
/* 2747 */     TNode tNode3 = null;
/* 2748 */     TNode tNode4 = null;
/* 2749 */     TNode tNode5 = null;
/* 2750 */     TNode tNode6 = null;
/* 2751 */     TNode tNode7 = null;
/* 2752 */     TNode tNode8 = null;
/* 2753 */     TNode tNode9 = null; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/* 2756 */       AST aST2 = paramAST;
/* 2757 */       TNode tNode = (TNode)paramAST;
/* 2758 */       match(paramAST, 136);
/* 2759 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 2761 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 2762 */       switch (aSTNULLType2.getType()) {
/*      */ 
/*      */         
/*      */         case 49:
/* 2766 */           tNode2 = (TNode)aSTNULLType2;
/* 2767 */           match((AST)aSTNULLType2, 49);
/* 2768 */           aST1 = aSTNULLType2.getNextSibling();
/* 2769 */           if (this.inputState.guessing == 0) {
/* 2770 */             print(tNode2);
/*      */           }
/* 2772 */           expr(aST1);
/* 2773 */           aST1 = this._retTree;
/* 2774 */           tNode3 = (TNode)aST1;
/* 2775 */           match(aST1, 50);
/* 2776 */           aST1 = aST1.getNextSibling();
/* 2777 */           if (this.inputState.guessing == 0) {
/* 2778 */             print(tNode3);
/*      */           }
/*      */           
/* 2781 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 2782 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 45:
/* 2785 */               tNode4 = (TNode)aSTNULLType1;
/* 2786 */               match((AST)aSTNULLType1, 45);
/* 2787 */               aST = aSTNULLType1.getNextSibling();
/* 2788 */               if (this.inputState.guessing == 0) {
/* 2789 */                 print(tNode4);
/*      */               }
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/* 2799 */           throw new NoViableAltException(aST);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 42:
/* 2808 */           tNode5 = (TNode)aST;
/* 2809 */           match(aST, 42);
/* 2810 */           aST = aST.getNextSibling();
/* 2811 */           tNode6 = (TNode)aST;
/* 2812 */           match(aST, 44);
/* 2813 */           aST = aST.getNextSibling();
/* 2814 */           if (this.inputState.guessing == 0) {
/* 2815 */             print(tNode5); print(tNode6);
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 98:
/* 2821 */           tNode7 = (TNode)aST;
/* 2822 */           match(aST, 98);
/* 2823 */           aST = aST.getNextSibling();
/* 2824 */           tNode8 = (TNode)aST;
/* 2825 */           match(aST, 42);
/* 2826 */           aST = aST.getNextSibling();
/* 2827 */           tNode9 = (TNode)aST;
/* 2828 */           match(aST, 45);
/* 2829 */           aST = aST.getNextSibling();
/* 2830 */           if (this.inputState.guessing == 0) {
/* 2831 */             print(tNode7); print(tNode8); print(tNode9);
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2837 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 2841 */       aST = aST2;
/* 2842 */       aST = aST.getNextSibling();
/*      */     }
/* 2844 */     catch (RecognitionException recognitionException) {
/* 2845 */       if (this.inputState.guessing == 0) {
/* 2846 */         reportError(recognitionException);
/* 2847 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2849 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2852 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void lcurlyInitializer(AST paramAST) throws RecognitionException {
/* 2857 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2858 */     TNode tNode2 = null;
/* 2859 */     TNode tNode3 = null;
/*      */     
/*      */     try {
/* 2862 */       AST aST = paramAST;
/* 2863 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2864 */       match(paramAST, 137);
/* 2865 */       paramAST = paramAST.getFirstChild();
/* 2866 */       if (this.inputState.guessing == 0) {
/* 2867 */         print(tNode2); this.tabs++;
/*      */       } 
/* 2869 */       initializerList(paramAST);
/* 2870 */       paramAST = this._retTree;
/* 2871 */       tNode3 = (TNode)paramAST;
/* 2872 */       match(paramAST, 8);
/* 2873 */       paramAST = paramAST.getNextSibling();
/* 2874 */       if (this.inputState.guessing == 0) {
/* 2875 */         this.tabs--; print(tNode3);
/*      */       } 
/* 2877 */       paramAST = aST;
/* 2878 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 2880 */     catch (RecognitionException recognitionException) {
/* 2881 */       if (this.inputState.guessing == 0) {
/* 2882 */         reportError(recognitionException);
/* 2883 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 2885 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2888 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void initializerList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2893 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2894 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         
/* 2900 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2901 */         if (aSTNULLType.getType() == 123 || aSTNULLType.getType() == 137) {
/* 2902 */           tNode2 = (aSTNULLType == ASTNULL) ? null : (TNode)aSTNULLType;
/* 2903 */           initializer((AST)aSTNULLType);
/* 2904 */           aST = this._retTree;
/* 2905 */           if (this.inputState.guessing == 0) {
/* 2906 */             commaSep(tNode2);
/*      */           }
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2916 */     } catch (RecognitionException recognitionException) {
/* 2917 */       if (this.inputState.guessing == 0) {
/* 2918 */         reportError(recognitionException);
/* 2919 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 2921 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 2924 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void parameterTypeList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 2929 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 2930 */     TNode tNode2 = null;
/* 2931 */     TNode tNode3 = null;
/* 2932 */     TNode tNode4 = null;
/*      */     try {
/*      */       AST aST1;
/*      */       ASTNULLType aSTNULLType;
/* 2936 */       byte b = 0;
/*      */       
/*      */       while (true) {
/* 2939 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 2940 */         if (aSTNULLType.getType() == 129) {
/* 2941 */           ASTNULLType aSTNULLType1; parameterDeclaration((AST)aSTNULLType);
/* 2942 */           AST aST2 = this._retTree;
/*      */           
/* 2944 */           if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 2945 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 43:
/* 2948 */               tNode2 = (TNode)aSTNULLType1;
/* 2949 */               match((AST)aSTNULLType1, 43);
/* 2950 */               aST1 = aSTNULLType1.getNextSibling();
/* 2951 */               if (this.inputState.guessing == 0) {
/* 2952 */                 print(tNode2);
/*      */               }
/*      */               break;
/*      */ 
/*      */             
/*      */             case 9:
/* 2958 */               tNode3 = (TNode)aST1;
/* 2959 */               match(aST1, 9);
/* 2960 */               aST1 = aST1.getNextSibling();
/* 2961 */               if (this.inputState.guessing == 0) {
/* 2962 */                 print(tNode3);
/*      */               }
/*      */               break;
/*      */ 
/*      */             
/*      */             case 48:
/*      */             case 51:
/*      */             case 129:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 2974 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*      */         } else {
/* 2980 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 2983 */         b++;
/*      */       } 
/*      */ 
/*      */       
/* 2987 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/* 2988 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 51:
/* 2991 */           tNode4 = (TNode)aSTNULLType;
/* 2992 */           match((AST)aSTNULLType, 51);
/* 2993 */           aST = aSTNULLType.getNextSibling();
/* 2994 */           if (this.inputState.guessing == 0) {
/* 2995 */             print(tNode4);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3005 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 3010 */     } catch (RecognitionException recognitionException) {
/* 3011 */       if (this.inputState.guessing == 0) {
/* 3012 */         reportError(recognitionException);
/* 3013 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3015 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3018 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void parameterDeclaration(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3023 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 3026 */       AST aST1 = paramAST;
/* 3027 */       TNode tNode1 = (TNode)paramAST;
/* 3028 */       match(paramAST, 129);
/* 3029 */       paramAST = paramAST.getFirstChild();
/* 3030 */       declSpecifiers(paramAST);
/* 3031 */       paramAST = this._retTree;
/*      */       
/* 3033 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3034 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 115:
/* 3037 */           declarator((AST)aSTNULLType);
/* 3038 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 122:
/* 3043 */           nonemptyAbstractDeclarator(aST);
/* 3044 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3053 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3057 */       aST = aST1;
/* 3058 */       aST = aST.getNextSibling();
/*      */     }
/* 3060 */     catch (RecognitionException recognitionException) {
/* 3061 */       if (this.inputState.guessing == 0) {
/* 3062 */         reportError(recognitionException);
/* 3063 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3065 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3068 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void nonemptyAbstractDeclarator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3073 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 3074 */     TNode tNode2 = null;
/* 3075 */     TNode tNode3 = null;
/* 3076 */     TNode tNode4 = null;
/* 3077 */     TNode tNode5 = null;
/* 3078 */     TNode tNode6 = null;
/* 3079 */     TNode tNode7 = null;
/* 3080 */     TNode tNode8 = null;
/* 3081 */     TNode tNode9 = null; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       byte b;
/* 3084 */       AST aST1 = paramAST;
/* 3085 */       TNode tNode = (TNode)paramAST;
/* 3086 */       match(paramAST, 122);
/* 3087 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 3089 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3090 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 119:
/* 3093 */           pointerGroup((AST)aSTNULLType);
/* 3094 */           aST = this._retTree; while (true) {
/*      */             ASTNULLType aSTNULLType3; AST aST3; ASTNULLType aSTNULLType2;
/*      */             AST aST2;
/*      */             ASTNULLType aSTNULLType1;
/* 3098 */             if (aST == null) aSTNULLType3 = ASTNULL; 
/* 3099 */             switch (aSTNULLType3.getType()) {
/*      */ 
/*      */               
/*      */               case 47:
/* 3103 */                 tNode2 = (TNode)aSTNULLType3;
/* 3104 */                 match((AST)aSTNULLType3, 47);
/* 3105 */                 aST3 = aSTNULLType3.getNextSibling();
/* 3106 */                 if (this.inputState.guessing == 0) {
/* 3107 */                   print(tNode2);
/*      */                 }
/*      */                 
/* 3110 */                 if (aST3 == null) aSTNULLType2 = ASTNULL; 
/* 3111 */                 switch (aSTNULLType2.getType()) {
/*      */                   
/*      */                   case 122:
/* 3114 */                     nonemptyAbstractDeclarator((AST)aSTNULLType2);
/* 3115 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 129:
/* 3120 */                     parameterTypeList(aST2);
/* 3121 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 3130 */                     throw new NoViableAltException(aST2);
/*      */                 } 
/*      */ 
/*      */                 
/* 3134 */                 tNode3 = (TNode)aST2;
/* 3135 */                 match(aST2, 48);
/* 3136 */                 aST2 = aST2.getNextSibling();
/* 3137 */                 if (this.inputState.guessing == 0) {
/* 3138 */                   print(tNode3);
/*      */                 }
/*      */                 continue;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 3146 */                 tNode4 = (TNode)aST2;
/* 3147 */                 match(aST2, 49);
/* 3148 */                 aST2 = aST2.getNextSibling();
/* 3149 */                 if (this.inputState.guessing == 0) {
/* 3150 */                   print(tNode4);
/*      */                 }
/*      */                 
/* 3153 */                 if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 3154 */                 switch (aSTNULLType1.getType()) {
/*      */                   
/*      */                   case 42:
/*      */                   case 45:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 64:
/*      */                   case 65:
/*      */                   case 66:
/*      */                   case 67:
/*      */                   case 68:
/*      */                   case 69:
/*      */                   case 70:
/*      */                   case 71:
/*      */                   case 72:
/*      */                   case 73:
/*      */                   case 74:
/*      */                   case 75:
/*      */                   case 76:
/*      */                   case 77:
/*      */                   case 78:
/*      */                   case 79:
/*      */                   case 80:
/*      */                   case 81:
/*      */                   case 82:
/*      */                   case 83:
/*      */                   case 84:
/*      */                   case 85:
/*      */                   case 86:
/*      */                   case 87:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 90:
/*      */                   case 91:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 99:
/*      */                   case 118:
/*      */                   case 120:
/*      */                   case 123:
/*      */                   case 125:
/*      */                   case 130:
/*      */                   case 131:
/*      */                   case 133:
/*      */                   case 134:
/*      */                   case 135:
/*      */                   case 137:
/*      */                   case 139:
/*      */                   case 158:
/*      */                   case 164:
/* 3205 */                     expr((AST)aSTNULLType1);
/* 3206 */                     aST = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 3215 */                     throw new NoViableAltException(aST);
/*      */                 } 
/*      */ 
/*      */                 
/* 3219 */                 tNode5 = (TNode)aST;
/* 3220 */                 match(aST, 50);
/* 3221 */                 aST = aST.getNextSibling();
/* 3222 */                 if (this.inputState.guessing == 0) {
/* 3223 */                   print(tNode5);
/*      */                 }
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 47:
/*      */         case 49:
/* 3241 */           b = 0; while (true) {
/*      */             ASTNULLType aSTNULLType3; AST aST3; ASTNULLType aSTNULLType2; AST aST2;
/*      */             ASTNULLType aSTNULLType1;
/* 3244 */             if (aST == null) aSTNULLType3 = ASTNULL; 
/* 3245 */             switch (aSTNULLType3.getType()) {
/*      */ 
/*      */               
/*      */               case 47:
/* 3249 */                 tNode6 = (TNode)aSTNULLType3;
/* 3250 */                 match((AST)aSTNULLType3, 47);
/* 3251 */                 aST3 = aSTNULLType3.getNextSibling();
/* 3252 */                 if (this.inputState.guessing == 0) {
/* 3253 */                   print(tNode6);
/*      */                 }
/*      */                 
/* 3256 */                 if (aST3 == null) aSTNULLType2 = ASTNULL; 
/* 3257 */                 switch (aSTNULLType2.getType()) {
/*      */                   
/*      */                   case 122:
/* 3260 */                     nonemptyAbstractDeclarator((AST)aSTNULLType2);
/* 3261 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 129:
/* 3266 */                     parameterTypeList(aST2);
/* 3267 */                     aST2 = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 48:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 3276 */                     throw new NoViableAltException(aST2);
/*      */                 } 
/*      */ 
/*      */                 
/* 3280 */                 tNode7 = (TNode)aST2;
/* 3281 */                 match(aST2, 48);
/* 3282 */                 aST2 = aST2.getNextSibling();
/* 3283 */                 if (this.inputState.guessing == 0) {
/* 3284 */                   print(tNode7);
/*      */                 }
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 49:
/* 3292 */                 tNode8 = (TNode)aST2;
/* 3293 */                 match(aST2, 49);
/* 3294 */                 aST2 = aST2.getNextSibling();
/* 3295 */                 if (this.inputState.guessing == 0) {
/* 3296 */                   print(tNode8);
/*      */                 }
/*      */                 
/* 3299 */                 if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 3300 */                 switch (aSTNULLType1.getType()) {
/*      */                   
/*      */                   case 42:
/*      */                   case 45:
/*      */                   case 46:
/*      */                   case 47:
/*      */                   case 64:
/*      */                   case 65:
/*      */                   case 66:
/*      */                   case 67:
/*      */                   case 68:
/*      */                   case 69:
/*      */                   case 70:
/*      */                   case 71:
/*      */                   case 72:
/*      */                   case 73:
/*      */                   case 74:
/*      */                   case 75:
/*      */                   case 76:
/*      */                   case 77:
/*      */                   case 78:
/*      */                   case 79:
/*      */                   case 80:
/*      */                   case 81:
/*      */                   case 82:
/*      */                   case 83:
/*      */                   case 84:
/*      */                   case 85:
/*      */                   case 86:
/*      */                   case 87:
/*      */                   case 88:
/*      */                   case 89:
/*      */                   case 90:
/*      */                   case 91:
/*      */                   case 92:
/*      */                   case 93:
/*      */                   case 94:
/*      */                   case 99:
/*      */                   case 118:
/*      */                   case 120:
/*      */                   case 123:
/*      */                   case 125:
/*      */                   case 130:
/*      */                   case 131:
/*      */                   case 133:
/*      */                   case 134:
/*      */                   case 135:
/*      */                   case 137:
/*      */                   case 139:
/*      */                   case 158:
/*      */                   case 164:
/* 3351 */                     expr((AST)aSTNULLType1);
/* 3352 */                     aST = this._retTree;
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 50:
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   default:
/* 3361 */                     throw new NoViableAltException(aST);
/*      */                 } 
/*      */ 
/*      */                 
/* 3365 */                 tNode9 = (TNode)aST;
/* 3366 */                 match(aST, 50);
/* 3367 */                 aST = aST.getNextSibling();
/* 3368 */                 if (this.inputState.guessing == 0) {
/* 3369 */                   print(tNode9);
/*      */                 }
/*      */                 break;
/*      */ 
/*      */ 
/*      */               
/*      */               default:
/* 3376 */                 if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */             } 
/*      */             
/* 3379 */             b++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 3386 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3390 */       aST = aST1;
/* 3391 */       aST = aST.getNextSibling();
/*      */     }
/* 3393 */     catch (RecognitionException recognitionException) {
/* 3394 */       if (this.inputState.guessing == 0) {
/* 3395 */         reportError(recognitionException);
/* 3396 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3398 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3401 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void functionDeclSpecifiers(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3406 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 3410 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3413 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3414 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 15:
/*      */           case 16:
/*      */           case 160:
/* 3419 */             functionStorageClassSpecifier((AST)aSTNULLType);
/* 3420 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 17:
/* 3426 */             typeQualifier(aST);
/* 3427 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 18:
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 113:
/*      */           case 161:
/*      */           case 162:
/* 3446 */             typeSpecifier(aST);
/* 3447 */             aST = this._retTree;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 3452 */             if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3455 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3459 */     catch (RecognitionException recognitionException) {
/* 3460 */       if (this.inputState.guessing == 0) {
/* 3461 */         reportError(recognitionException);
/* 3462 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3464 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3467 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void compoundStatement(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3472 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 3473 */     TNode tNode2 = null;
/* 3474 */     TNode tNode3 = null; try {
/*      */       AST aST1;
/*      */       ASTNULLType aSTNULLType;
/* 3477 */       AST aST2 = paramAST;
/* 3478 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 3479 */       match(paramAST, 128);
/* 3480 */       paramAST = paramAST.getFirstChild();
/* 3481 */       if (this.inputState.guessing == 0) {
/* 3482 */         print(tNode2); this.tabs++;
/*      */       } 
/*      */ 
/*      */       
/*      */       while (true) {
/* 3487 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3488 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 117:
/*      */           case 159:
/* 3492 */             declarationList((AST)aSTNULLType);
/* 3493 */             aST1 = this._retTree;
/*      */             continue;
/*      */ 
/*      */           
/*      */           case 127:
/* 3498 */             functionDef(aST1);
/* 3499 */             aST1 = this._retTree;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 3510 */       if (aST1 == null) aSTNULLType = ASTNULL; 
/* 3511 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 9:
/*      */         case 52:
/*      */         case 53:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 63:
/*      */         case 124:
/*      */         case 128:
/*      */         case 132:
/* 3528 */           statementList((AST)aSTNULLType);
/* 3529 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3538 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 3542 */       tNode3 = (TNode)aST;
/* 3543 */       match(aST, 8);
/* 3544 */       aST = aST.getNextSibling();
/* 3545 */       if (this.inputState.guessing == 0) {
/* 3546 */         this.tabs--; print(tNode3);
/*      */       } 
/* 3548 */       aST = aST2;
/* 3549 */       aST = aST.getNextSibling();
/*      */     }
/* 3551 */     catch (RecognitionException recognitionException) {
/* 3552 */       if (this.inputState.guessing == 0) {
/* 3553 */         reportError(recognitionException);
/* 3554 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3556 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3559 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void declarationList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3564 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 3568 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3571 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3572 */         if (aSTNULLType.getType() == 159) {
/* 3573 */           localLabelDecl((AST)aSTNULLType);
/* 3574 */           aST = this._retTree;
/*      */         }
/* 3576 */         else if (aST.getType() == 117) {
/* 3577 */           declaration(aST);
/* 3578 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 3581 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3584 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3588 */     catch (RecognitionException recognitionException) {
/* 3589 */       if (this.inputState.guessing == 0) {
/* 3590 */         reportError(recognitionException);
/* 3591 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3593 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3596 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void localLabelDecl(AST paramAST) throws RecognitionException {
/* 3601 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 3602 */     TNode tNode2 = null;
/* 3603 */     TNode tNode3 = null;
/*      */     
/*      */     try {
/* 3606 */       AST aST = paramAST;
/* 3607 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 3608 */       match(paramAST, 159);
/* 3609 */       paramAST = paramAST.getFirstChild();
/* 3610 */       if (this.inputState.guessing == 0) {
/* 3611 */         print(tNode2);
/*      */       }
/*      */       
/* 3614 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/* 3617 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3618 */         if (aSTNULLType.getType() == 42) {
/* 3619 */           tNode3 = (TNode)aSTNULLType;
/* 3620 */           match((AST)aSTNULLType, 42);
/* 3621 */           aST1 = aSTNULLType.getNextSibling();
/* 3622 */           if (this.inputState.guessing == 0) {
/* 3623 */             commaSep(tNode3);
/*      */           }
/*      */         } else {
/*      */           
/* 3627 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 3630 */         b++;
/*      */       } 
/*      */       
/* 3633 */       if (this.inputState.guessing == 0) {
/* 3634 */         print(";");
/*      */       }
/* 3636 */       paramAST = aST;
/* 3637 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 3639 */     catch (RecognitionException recognitionException) {
/* 3640 */       if (this.inputState.guessing == 0) {
/* 3641 */         reportError(recognitionException);
/* 3642 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 3644 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3647 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void statementList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3652 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */ 
/*      */     
/*      */     try {
/* 3656 */       byte b = 0;
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 3659 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 3660 */         if (_tokenSet_2.member(aSTNULLType.getType())) {
/* 3661 */           statement((AST)aSTNULLType);
/* 3662 */           aST = this._retTree;
/*      */         } else {
/*      */           
/* 3665 */           if (b >= 1) break;  throw new NoViableAltException(aST);
/*      */         } 
/*      */         
/* 3668 */         b++;
/*      */       }
/*      */     
/*      */     }
/* 3672 */     catch (RecognitionException recognitionException) {
/* 3673 */       if (this.inputState.guessing == 0) {
/* 3674 */         reportError(recognitionException);
/* 3675 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 3677 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3680 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void statement(AST paramAST) throws RecognitionException {
/* 3685 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 3688 */       statementBody(paramAST);
/* 3689 */       paramAST = this._retTree;
/*      */     }
/* 3691 */     catch (RecognitionException recognitionException) {
/* 3692 */       if (this.inputState.guessing == 0) {
/* 3693 */         reportError(recognitionException);
/* 3694 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 3696 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 3699 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void statementBody(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 3704 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 3705 */     TNode tNode2 = null;
/* 3706 */     TNode tNode3 = null;
/* 3707 */     TNode tNode4 = null;
/* 3708 */     TNode tNode5 = null;
/* 3709 */     TNode tNode6 = null;
/* 3710 */     TNode tNode7 = null;
/* 3711 */     TNode tNode8 = null;
/* 3712 */     TNode tNode9 = null;
/* 3713 */     TNode tNode10 = null;
/* 3714 */     TNode tNode11 = null;
/* 3715 */     TNode tNode12 = null;
/* 3716 */     TNode tNode13 = null;
/* 3717 */     TNode tNode14 = null;
/* 3718 */     TNode tNode15 = null; try {
/*      */       ASTNULLType aSTNULLType6; AST aST5; ASTNULLType aSTNULLType5; AST aST4; ASTNULLType aSTNULLType4; AST aST3; ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; AST aST6;
/*      */       TNode tNode;
/* 3721 */       if (paramAST == null) aSTNULLType6 = ASTNULL; 
/* 3722 */       switch (aSTNULLType6.getType()) {
/*      */         
/*      */         case 9:
/* 3725 */           tNode2 = (TNode)aSTNULLType6;
/* 3726 */           match((AST)aSTNULLType6, 9);
/* 3727 */           aST5 = aSTNULLType6.getNextSibling();
/* 3728 */           if (this.inputState.guessing == 0) {
/* 3729 */             print(tNode2);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 128:
/* 3735 */           compoundStatement(aST5);
/* 3736 */           aST5 = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 124:
/* 3741 */           aST6 = aST5;
/* 3742 */           tNode = (TNode)aST5;
/* 3743 */           match(aST5, 124);
/* 3744 */           aST5 = aST5.getFirstChild();
/* 3745 */           expr(aST5);
/* 3746 */           aST5 = this._retTree;
/* 3747 */           if (this.inputState.guessing == 0) {
/* 3748 */             print(";");
/*      */           }
/* 3750 */           aST5 = aST6;
/* 3751 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 52:
/* 3756 */           aST6 = aST5;
/* 3757 */           tNode3 = (aST5 == ASTNULL) ? null : (TNode)aST5;
/* 3758 */           match(aST5, 52);
/* 3759 */           aST5 = aST5.getFirstChild();
/* 3760 */           if (this.inputState.guessing == 0) {
/* 3761 */             print(tNode3); print("(");
/*      */           } 
/* 3763 */           expr(aST5);
/* 3764 */           aST5 = this._retTree;
/* 3765 */           if (this.inputState.guessing == 0) {
/* 3766 */             print(")");
/*      */           }
/* 3768 */           statement(aST5);
/* 3769 */           aST5 = this._retTree;
/* 3770 */           aST5 = aST6;
/* 3771 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 53:
/* 3776 */           aST6 = aST5;
/* 3777 */           tNode4 = (aST5 == ASTNULL) ? null : (TNode)aST5;
/* 3778 */           match(aST5, 53);
/* 3779 */           aST5 = aST5.getFirstChild();
/* 3780 */           if (this.inputState.guessing == 0) {
/* 3781 */             print(tNode4);
/*      */           }
/* 3783 */           statement(aST5);
/* 3784 */           aST5 = this._retTree;
/* 3785 */           if (this.inputState.guessing == 0) {
/* 3786 */             print(" while ( ");
/*      */           }
/* 3788 */           expr(aST5);
/* 3789 */           aST5 = this._retTree;
/* 3790 */           if (this.inputState.guessing == 0) {
/* 3791 */             print(" );");
/*      */           }
/* 3793 */           aST5 = aST6;
/* 3794 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 54:
/* 3799 */           aST6 = aST5;
/* 3800 */           tNode5 = (aST5 == ASTNULL) ? null : (TNode)aST5;
/* 3801 */           match(aST5, 54);
/* 3802 */           aST5 = aST5.getFirstChild();
/* 3803 */           if (this.inputState.guessing == 0) {
/* 3804 */             print(tNode5); print("(");
/*      */           } 
/* 3806 */           expr(aST5);
/* 3807 */           aST5 = this._retTree;
/* 3808 */           if (this.inputState.guessing == 0) {
/* 3809 */             print(";");
/*      */           }
/* 3811 */           expr(aST5);
/* 3812 */           aST5 = this._retTree;
/* 3813 */           if (this.inputState.guessing == 0) {
/* 3814 */             print(";");
/*      */           }
/* 3816 */           expr(aST5);
/* 3817 */           aST5 = this._retTree;
/* 3818 */           if (this.inputState.guessing == 0) {
/* 3819 */             print(")");
/*      */           }
/* 3821 */           statement(aST5);
/* 3822 */           aST5 = this._retTree;
/* 3823 */           aST5 = aST6;
/* 3824 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 55:
/* 3829 */           aST6 = aST5;
/* 3830 */           tNode6 = (aST5 == ASTNULL) ? null : (TNode)aST5;
/* 3831 */           match(aST5, 55);
/* 3832 */           aST5 = aST5.getFirstChild();
/* 3833 */           if (this.inputState.guessing == 0) {
/* 3834 */             print(tNode6);
/*      */           }
/* 3836 */           expr(aST5);
/* 3837 */           aST5 = this._retTree;
/* 3838 */           if (this.inputState.guessing == 0) {
/* 3839 */             print(";");
/*      */           }
/* 3841 */           aST5 = aST6;
/* 3842 */           aST5 = aST5.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 56:
/* 3847 */           tNode7 = (TNode)aST5;
/* 3848 */           match(aST5, 56);
/* 3849 */           aST5 = aST5.getNextSibling();
/* 3850 */           if (this.inputState.guessing == 0) {
/* 3851 */             print(tNode7); print(";");
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 57:
/* 3857 */           tNode8 = (TNode)aST5;
/* 3858 */           match(aST5, 57);
/* 3859 */           aST5 = aST5.getNextSibling();
/* 3860 */           if (this.inputState.guessing == 0) {
/* 3861 */             print(tNode8); print(";");
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 58:
/* 3867 */           aST6 = aST5;
/* 3868 */           tNode9 = (aST5 == ASTNULL) ? null : (TNode)aST5;
/* 3869 */           match(aST5, 58);
/* 3870 */           aST5 = aST5.getFirstChild();
/* 3871 */           if (this.inputState.guessing == 0) {
/* 3872 */             print(tNode9);
/*      */           }
/*      */           
/* 3875 */           if (aST5 == null) aSTNULLType5 = ASTNULL; 
/* 3876 */           switch (aSTNULLType5.getType()) {
/*      */             
/*      */             case 42:
/*      */             case 45:
/*      */             case 46:
/*      */             case 47:
/*      */             case 64:
/*      */             case 65:
/*      */             case 66:
/*      */             case 67:
/*      */             case 68:
/*      */             case 69:
/*      */             case 70:
/*      */             case 71:
/*      */             case 72:
/*      */             case 73:
/*      */             case 74:
/*      */             case 75:
/*      */             case 76:
/*      */             case 77:
/*      */             case 78:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/*      */             case 82:
/*      */             case 83:
/*      */             case 84:
/*      */             case 85:
/*      */             case 86:
/*      */             case 87:
/*      */             case 88:
/*      */             case 89:
/*      */             case 90:
/*      */             case 91:
/*      */             case 92:
/*      */             case 93:
/*      */             case 94:
/*      */             case 99:
/*      */             case 118:
/*      */             case 120:
/*      */             case 123:
/*      */             case 125:
/*      */             case 130:
/*      */             case 131:
/*      */             case 133:
/*      */             case 134:
/*      */             case 135:
/*      */             case 137:
/*      */             case 139:
/*      */             case 158:
/*      */             case 164:
/* 3927 */               expr((AST)aSTNULLType5);
/* 3928 */               aST4 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3937 */               throw new NoViableAltException(aST4);
/*      */           } 
/*      */ 
/*      */           
/* 3941 */           if (this.inputState.guessing == 0) {
/* 3942 */             print(";");
/*      */           }
/* 3944 */           aST4 = aST6;
/* 3945 */           aST4 = aST4.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 132:
/* 3950 */           aST6 = aST4;
/* 3951 */           tNode = (TNode)aST4;
/* 3952 */           match(aST4, 132);
/* 3953 */           aST4 = aST4.getFirstChild();
/* 3954 */           tNode10 = (TNode)aST4;
/* 3955 */           match(aST4, 42);
/* 3956 */           aST4 = aST4.getNextSibling();
/* 3957 */           if (this.inputState.guessing == 0) {
/* 3958 */             print(tNode10); print(":");
/*      */           } 
/*      */           
/* 3961 */           if (aST4 == null) aSTNULLType4 = ASTNULL; 
/* 3962 */           switch (aSTNULLType4.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 3979 */               statement((AST)aSTNULLType4);
/* 3980 */               aST3 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3989 */               throw new NoViableAltException(aST3);
/*      */           } 
/*      */ 
/*      */           
/* 3993 */           aST3 = aST6;
/* 3994 */           aST3 = aST3.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 59:
/* 3999 */           aST6 = aST3;
/* 4000 */           tNode11 = (aST3 == ASTNULL) ? null : (TNode)aST3;
/* 4001 */           match(aST3, 59);
/* 4002 */           aST3 = aST3.getFirstChild();
/* 4003 */           if (this.inputState.guessing == 0) {
/* 4004 */             print(tNode11);
/*      */           }
/* 4006 */           expr(aST3);
/* 4007 */           aST3 = this._retTree;
/* 4008 */           if (this.inputState.guessing == 0) {
/* 4009 */             print(":");
/*      */           }
/*      */           
/* 4012 */           if (aST3 == null) aSTNULLType3 = ASTNULL; 
/* 4013 */           switch (aSTNULLType3.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 4030 */               statement((AST)aSTNULLType3);
/* 4031 */               aST2 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4040 */               throw new NoViableAltException(aST2);
/*      */           } 
/*      */ 
/*      */           
/* 4044 */           aST2 = aST6;
/* 4045 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 60:
/* 4050 */           aST6 = aST2;
/* 4051 */           tNode12 = (aST2 == ASTNULL) ? null : (TNode)aST2;
/* 4052 */           match(aST2, 60);
/* 4053 */           aST2 = aST2.getFirstChild();
/* 4054 */           if (this.inputState.guessing == 0) {
/* 4055 */             print(tNode12); print(":");
/*      */           } 
/*      */           
/* 4058 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 4059 */           switch (aSTNULLType2.getType()) {
/*      */             
/*      */             case 9:
/*      */             case 52:
/*      */             case 53:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 59:
/*      */             case 60:
/*      */             case 61:
/*      */             case 63:
/*      */             case 124:
/*      */             case 128:
/*      */             case 132:
/* 4076 */               statement((AST)aSTNULLType2);
/* 4077 */               aST1 = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4086 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 4090 */           aST1 = aST6;
/* 4091 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 61:
/* 4096 */           aST6 = aST1;
/* 4097 */           tNode13 = (aST1 == ASTNULL) ? null : (TNode)aST1;
/* 4098 */           match(aST1, 61);
/* 4099 */           aST1 = aST1.getFirstChild();
/* 4100 */           if (this.inputState.guessing == 0) {
/* 4101 */             print(tNode13); print("(");
/*      */           } 
/* 4103 */           expr(aST1);
/* 4104 */           aST1 = this._retTree;
/* 4105 */           if (this.inputState.guessing == 0) {
/* 4106 */             print(")");
/*      */           }
/* 4108 */           statement(aST1);
/* 4109 */           aST1 = this._retTree;
/*      */           
/* 4111 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 4112 */           switch (aSTNULLType1.getType()) {
/*      */             
/*      */             case 62:
/* 4115 */               tNode14 = (TNode)aSTNULLType1;
/* 4116 */               match((AST)aSTNULLType1, 62);
/* 4117 */               aST = aSTNULLType1.getNextSibling();
/* 4118 */               if (this.inputState.guessing == 0) {
/* 4119 */                 print(tNode14);
/*      */               }
/* 4121 */               statement(aST);
/* 4122 */               aST = this._retTree;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4131 */               throw new NoViableAltException(aST);
/*      */           } 
/*      */ 
/*      */           
/* 4135 */           aST = aST6;
/* 4136 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 63:
/* 4141 */           aST6 = aST;
/* 4142 */           tNode15 = (aST == ASTNULL) ? null : (TNode)aST;
/* 4143 */           match(aST, 63);
/* 4144 */           aST = aST.getFirstChild();
/* 4145 */           if (this.inputState.guessing == 0) {
/* 4146 */             print(tNode15); print("(");
/*      */           } 
/* 4148 */           expr(aST);
/* 4149 */           aST = this._retTree;
/* 4150 */           if (this.inputState.guessing == 0) {
/* 4151 */             print(")");
/*      */           }
/* 4153 */           statement(aST);
/* 4154 */           aST = this._retTree;
/* 4155 */           aST = aST6;
/* 4156 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4161 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4165 */     } catch (RecognitionException recognitionException) {
/* 4166 */       if (this.inputState.guessing == 0) {
/* 4167 */         reportError(recognitionException);
/* 4168 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4170 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4173 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void binaryExpr(AST paramAST) throws RecognitionException {
/* 4178 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4179 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 4182 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4183 */       binaryOperator(paramAST);
/* 4184 */       paramAST = this._retTree;
/* 4185 */       if (this.inputState.guessing == 0)
/*      */       {
/* 4187 */         TNode tNode3 = (TNode)tNode2.getFirstChild();
/* 4188 */         TNode tNode4 = (TNode)tNode3.getNextSibling();
/* 4189 */         expr((AST)tNode3);
/* 4190 */         print(tNode2);
/* 4191 */         expr((AST)tNode4);
/*      */       }
/*      */     
/*      */     }
/* 4195 */     catch (RecognitionException recognitionException) {
/* 4196 */       if (this.inputState.guessing == 0) {
/* 4197 */         reportError(recognitionException);
/* 4198 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4200 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4203 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void conditionalExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4208 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4209 */     TNode tNode2 = null;
/* 4210 */     TNode tNode3 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 4213 */       AST aST1 = paramAST;
/* 4214 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4215 */       match(paramAST, 74);
/* 4216 */       paramAST = paramAST.getFirstChild();
/* 4217 */       expr(paramAST);
/* 4218 */       paramAST = this._retTree;
/* 4219 */       if (this.inputState.guessing == 0) {
/* 4220 */         print(tNode2);
/*      */       }
/*      */       
/* 4223 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4224 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 42:
/*      */         case 45:
/*      */         case 46:
/*      */         case 47:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 99:
/*      */         case 118:
/*      */         case 120:
/*      */         case 123:
/*      */         case 125:
/*      */         case 130:
/*      */         case 131:
/*      */         case 133:
/*      */         case 134:
/*      */         case 135:
/*      */         case 137:
/*      */         case 139:
/*      */         case 158:
/*      */         case 164:
/* 4275 */           expr((AST)aSTNULLType);
/* 4276 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4285 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 4289 */       tNode3 = (TNode)aST;
/* 4290 */       match(aST, 44);
/* 4291 */       aST = aST.getNextSibling();
/* 4292 */       if (this.inputState.guessing == 0) {
/* 4293 */         print(tNode3);
/*      */       }
/* 4295 */       expr(aST);
/* 4296 */       aST = this._retTree;
/* 4297 */       aST = aST1;
/* 4298 */       aST = aST.getNextSibling();
/*      */     }
/* 4300 */     catch (RecognitionException recognitionException) {
/* 4301 */       if (this.inputState.guessing == 0) {
/* 4302 */         reportError(recognitionException);
/* 4303 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4305 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4308 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void castExpr(AST paramAST) throws RecognitionException {
/* 4313 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4314 */     TNode tNode2 = null;
/* 4315 */     TNode tNode3 = null;
/*      */     
/*      */     try {
/* 4318 */       AST aST = paramAST;
/* 4319 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4320 */       match(paramAST, 118);
/* 4321 */       paramAST = paramAST.getFirstChild();
/* 4322 */       if (this.inputState.guessing == 0) {
/* 4323 */         print(tNode2);
/*      */       }
/* 4325 */       typeName(paramAST);
/* 4326 */       paramAST = this._retTree;
/* 4327 */       tNode3 = (TNode)paramAST;
/* 4328 */       match(paramAST, 48);
/* 4329 */       paramAST = paramAST.getNextSibling();
/* 4330 */       if (this.inputState.guessing == 0) {
/* 4331 */         print(tNode3);
/*      */       }
/* 4333 */       expr(paramAST);
/* 4334 */       paramAST = this._retTree;
/* 4335 */       paramAST = aST;
/* 4336 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4338 */     catch (RecognitionException recognitionException) {
/* 4339 */       if (this.inputState.guessing == 0) {
/* 4340 */         reportError(recognitionException);
/* 4341 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4343 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4346 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void unaryExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4351 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4352 */     TNode tNode2 = null;
/* 4353 */     TNode tNode3 = null;
/* 4354 */     TNode tNode4 = null;
/* 4355 */     TNode tNode5 = null;
/* 4356 */     TNode tNode6 = null;
/* 4357 */     TNode tNode7 = null;
/* 4358 */     TNode tNode8 = null;
/* 4359 */     TNode tNode9 = null;
/* 4360 */     TNode tNode10 = null; try {
/*      */       ASTNULLType aSTNULLType4; AST aST3; ASTNULLType aSTNULLType3; AST aST2; ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType5; AST aST4; TNode tNode;
/*      */       boolean bool;
/* 4363 */       if (paramAST == null) aSTNULLType4 = ASTNULL; 
/* 4364 */       switch (aSTNULLType4.getType()) {
/*      */         
/*      */         case 92:
/* 4367 */           aSTNULLType5 = aSTNULLType4;
/* 4368 */           tNode2 = (aSTNULLType4 == ASTNULL) ? null : (TNode)aSTNULLType4;
/* 4369 */           match((AST)aSTNULLType4, 92);
/* 4370 */           aST3 = aSTNULLType4.getFirstChild();
/* 4371 */           if (this.inputState.guessing == 0) {
/* 4372 */             print(tNode2);
/*      */           }
/* 4374 */           expr(aST3);
/* 4375 */           aST3 = this._retTree;
/* 4376 */           aSTNULLType3 = aSTNULLType5;
/* 4377 */           aST2 = aSTNULLType3.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 93:
/* 4382 */           aST4 = aST2;
/* 4383 */           tNode3 = (aST2 == ASTNULL) ? null : (TNode)aST2;
/* 4384 */           match(aST2, 93);
/* 4385 */           aST2 = aST2.getFirstChild();
/* 4386 */           if (this.inputState.guessing == 0) {
/* 4387 */             print(tNode3);
/*      */           }
/* 4389 */           expr(aST2);
/* 4390 */           aST2 = this._retTree;
/* 4391 */           aST2 = aST4;
/* 4392 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 131:
/* 4397 */           aST4 = aST2;
/* 4398 */           tNode = (TNode)aST2;
/* 4399 */           match(aST2, 131);
/* 4400 */           aST2 = aST2.getFirstChild();
/* 4401 */           tNode4 = (aST2 == ASTNULL) ? null : (TNode)aST2;
/* 4402 */           unaryOperator(aST2);
/* 4403 */           aST2 = this._retTree;
/* 4404 */           if (this.inputState.guessing == 0) {
/* 4405 */             print(tNode4);
/*      */           }
/* 4407 */           expr(aST2);
/* 4408 */           aST2 = this._retTree;
/* 4409 */           aST2 = aST4;
/* 4410 */           aST2 = aST2.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 94:
/* 4415 */           aST4 = aST2;
/* 4416 */           tNode5 = (aST2 == ASTNULL) ? null : (TNode)aST2;
/* 4417 */           match(aST2, 94);
/* 4418 */           aST2 = aST2.getFirstChild();
/* 4419 */           if (this.inputState.guessing == 0) {
/* 4420 */             print(tNode5);
/*      */           }
/*      */           
/* 4423 */           bool = false;
/* 4424 */           if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 4425 */           if (aSTNULLType2.getType() == 47) {
/* 4426 */             ASTNULLType aSTNULLType = aSTNULLType2;
/* 4427 */             bool = true;
/* 4428 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 4431 */               TNode tNode11 = (TNode)aSTNULLType2;
/* 4432 */               match((AST)aSTNULLType2, 47);
/* 4433 */               aST1 = aSTNULLType2.getNextSibling();
/* 4434 */               typeName(aST1);
/* 4435 */               aST1 = this._retTree;
/*      */             
/*      */             }
/* 4438 */             catch (RecognitionException recognitionException) {
/* 4439 */               bool = false;
/*      */             } 
/* 4441 */             aSTNULLType2 = aSTNULLType;
/* 4442 */             this.inputState.guessing--;
/*      */           } 
/* 4444 */           if (bool) {
/* 4445 */             tNode6 = (TNode)aSTNULLType2;
/* 4446 */             match((AST)aSTNULLType2, 47);
/* 4447 */             aST1 = aSTNULLType2.getNextSibling();
/* 4448 */             if (this.inputState.guessing == 0) {
/* 4449 */               print(tNode6);
/*      */             }
/* 4451 */             typeName(aST1);
/* 4452 */             aST1 = this._retTree;
/* 4453 */             tNode7 = (TNode)aST1;
/* 4454 */             match(aST1, 48);
/* 4455 */             aST1 = aST1.getNextSibling();
/* 4456 */             if (this.inputState.guessing == 0) {
/* 4457 */               print(tNode7);
/*      */             }
/*      */           }
/* 4460 */           else if (_tokenSet_3.member(aST1.getType())) {
/* 4461 */             expr(aST1);
/* 4462 */             aST1 = this._retTree;
/*      */           } else {
/*      */             
/* 4465 */             throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */           
/* 4469 */           aST1 = aST4;
/* 4470 */           aST1 = aST1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 164:
/* 4475 */           aST4 = aST1;
/* 4476 */           tNode8 = (aST1 == ASTNULL) ? null : (TNode)aST1;
/* 4477 */           match(aST1, 164);
/* 4478 */           aST1 = aST1.getFirstChild();
/* 4479 */           if (this.inputState.guessing == 0) {
/* 4480 */             print(tNode8);
/*      */           }
/*      */           
/* 4483 */           bool = false;
/* 4484 */           if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 4485 */           if (aSTNULLType1.getType() == 47) {
/* 4486 */             ASTNULLType aSTNULLType = aSTNULLType1;
/* 4487 */             bool = true;
/* 4488 */             this.inputState.guessing++;
/*      */             
/*      */             try {
/* 4491 */               TNode tNode11 = (TNode)aSTNULLType1;
/* 4492 */               match((AST)aSTNULLType1, 47);
/* 4493 */               aST = aSTNULLType1.getNextSibling();
/* 4494 */               typeName(aST);
/* 4495 */               aST = this._retTree;
/*      */             
/*      */             }
/* 4498 */             catch (RecognitionException recognitionException) {
/* 4499 */               bool = false;
/*      */             } 
/* 4501 */             aSTNULLType1 = aSTNULLType;
/* 4502 */             this.inputState.guessing--;
/*      */           } 
/* 4504 */           if (bool) {
/* 4505 */             tNode9 = (TNode)aSTNULLType1;
/* 4506 */             match((AST)aSTNULLType1, 47);
/* 4507 */             aST = aSTNULLType1.getNextSibling();
/* 4508 */             if (this.inputState.guessing == 0) {
/* 4509 */               print(tNode9);
/*      */             }
/* 4511 */             typeName(aST);
/* 4512 */             aST = this._retTree;
/* 4513 */             tNode10 = (TNode)aST;
/* 4514 */             match(aST, 48);
/* 4515 */             aST = aST.getNextSibling();
/* 4516 */             if (this.inputState.guessing == 0) {
/* 4517 */               print(tNode10);
/*      */             }
/*      */           }
/* 4520 */           else if (_tokenSet_3.member(aST.getType())) {
/* 4521 */             expr(aST);
/* 4522 */             aST = this._retTree;
/*      */           } else {
/*      */             
/* 4525 */             throw new NoViableAltException(aST);
/*      */           } 
/*      */ 
/*      */           
/* 4529 */           aST = aST4;
/* 4530 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4535 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4539 */     } catch (RecognitionException recognitionException) {
/* 4540 */       if (this.inputState.guessing == 0) {
/* 4541 */         reportError(recognitionException);
/* 4542 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4544 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4547 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void postfixExpr(AST paramAST) throws RecognitionException {
/* 4552 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4553 */     TNode tNode2 = null;
/* 4554 */     TNode tNode3 = null;
/* 4555 */     TNode tNode4 = null;
/* 4556 */     TNode tNode5 = null;
/* 4557 */     TNode tNode6 = null;
/* 4558 */     TNode tNode7 = null;
/* 4559 */     TNode tNode8 = null;
/* 4560 */     TNode tNode9 = null;
/* 4561 */     TNode tNode10 = null;
/* 4562 */     TNode tNode11 = null;
/*      */     
/*      */     try {
/* 4565 */       AST aST = paramAST;
/* 4566 */       TNode tNode = (TNode)paramAST;
/* 4567 */       match(paramAST, 133);
/* 4568 */       paramAST = paramAST.getFirstChild();
/* 4569 */       primaryExpr(paramAST);
/* 4570 */       paramAST = this._retTree;
/*      */       
/* 4572 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType2; AST aST2; ASTNULLType aSTNULLType1;
/*      */         AST aST1, aST3;
/* 4575 */         if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 4576 */         switch (aSTNULLType2.getType()) {
/*      */           
/*      */           case 97:
/* 4579 */             tNode2 = (TNode)aSTNULLType2;
/* 4580 */             match((AST)aSTNULLType2, 97);
/* 4581 */             aST2 = aSTNULLType2.getNextSibling();
/* 4582 */             tNode3 = (TNode)aST2;
/* 4583 */             match(aST2, 42);
/* 4584 */             aST2 = aST2.getNextSibling();
/* 4585 */             if (this.inputState.guessing == 0) {
/* 4586 */               print(tNode2); print(tNode3);
/*      */             } 
/*      */             break;
/*      */ 
/*      */           
/*      */           case 98:
/* 4592 */             tNode4 = (TNode)aST2;
/* 4593 */             match(aST2, 98);
/* 4594 */             aST2 = aST2.getNextSibling();
/* 4595 */             tNode5 = (TNode)aST2;
/* 4596 */             match(aST2, 42);
/* 4597 */             aST2 = aST2.getNextSibling();
/* 4598 */             if (this.inputState.guessing == 0) {
/* 4599 */               print(tNode4); print(tNode5);
/*      */             } 
/*      */             break;
/*      */ 
/*      */           
/*      */           case 121:
/* 4605 */             aST3 = aST2;
/* 4606 */             tNode6 = (aST2 == ASTNULL) ? null : (TNode)aST2;
/* 4607 */             match(aST2, 121);
/* 4608 */             aST2 = aST2.getFirstChild();
/* 4609 */             if (this.inputState.guessing == 0) {
/* 4610 */               print(tNode6);
/*      */             }
/*      */             
/* 4613 */             if (aST2 == null) aSTNULLType1 = ASTNULL; 
/* 4614 */             switch (aSTNULLType1.getType()) {
/*      */               
/*      */               case 42:
/*      */               case 45:
/*      */               case 46:
/*      */               case 47:
/*      */               case 64:
/*      */               case 65:
/*      */               case 66:
/*      */               case 67:
/*      */               case 68:
/*      */               case 69:
/*      */               case 70:
/*      */               case 71:
/*      */               case 72:
/*      */               case 73:
/*      */               case 74:
/*      */               case 75:
/*      */               case 76:
/*      */               case 77:
/*      */               case 78:
/*      */               case 79:
/*      */               case 80:
/*      */               case 81:
/*      */               case 82:
/*      */               case 83:
/*      */               case 84:
/*      */               case 85:
/*      */               case 86:
/*      */               case 87:
/*      */               case 88:
/*      */               case 89:
/*      */               case 90:
/*      */               case 91:
/*      */               case 92:
/*      */               case 93:
/*      */               case 94:
/*      */               case 99:
/*      */               case 118:
/*      */               case 120:
/*      */               case 123:
/*      */               case 125:
/*      */               case 130:
/*      */               case 131:
/*      */               case 133:
/*      */               case 134:
/*      */               case 135:
/*      */               case 137:
/*      */               case 139:
/*      */               case 158:
/*      */               case 164:
/* 4665 */                 argExprList((AST)aSTNULLType1);
/* 4666 */                 aST1 = this._retTree;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 48:
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 4675 */                 throw new NoViableAltException(aST1);
/*      */             } 
/*      */ 
/*      */             
/* 4679 */             tNode7 = (TNode)aST1;
/* 4680 */             match(aST1, 48);
/* 4681 */             aST1 = aST1.getNextSibling();
/* 4682 */             if (this.inputState.guessing == 0) {
/* 4683 */               print(tNode7);
/*      */             }
/* 4685 */             aST1 = aST3;
/* 4686 */             aST1 = aST1.getNextSibling();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 49:
/* 4691 */             tNode8 = (TNode)aST1;
/* 4692 */             match(aST1, 49);
/* 4693 */             aST1 = aST1.getNextSibling();
/* 4694 */             if (this.inputState.guessing == 0) {
/* 4695 */               print(tNode8);
/*      */             }
/* 4697 */             expr(aST1);
/* 4698 */             aST1 = this._retTree;
/* 4699 */             tNode9 = (TNode)aST1;
/* 4700 */             match(aST1, 50);
/* 4701 */             aST1 = aST1.getNextSibling();
/* 4702 */             if (this.inputState.guessing == 0) {
/* 4703 */               print(tNode9);
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 92:
/* 4709 */             tNode10 = (TNode)aST1;
/* 4710 */             match(aST1, 92);
/* 4711 */             aST1 = aST1.getNextSibling();
/* 4712 */             if (this.inputState.guessing == 0) {
/* 4713 */               print(tNode10);
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 93:
/* 4719 */             tNode11 = (TNode)aST1;
/* 4720 */             match(aST1, 93);
/* 4721 */             aST1 = aST1.getNextSibling();
/* 4722 */             if (this.inputState.guessing == 0) {
/* 4723 */               print(tNode11);
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 4729 */             if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 4732 */         b++;
/*      */       } 
/*      */       
/* 4735 */       paramAST = aST;
/* 4736 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4738 */     catch (RecognitionException recognitionException) {
/* 4739 */       if (this.inputState.guessing == 0) {
/* 4740 */         reportError(recognitionException);
/* 4741 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4743 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4746 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void primaryExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4751 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4752 */     TNode tNode2 = null;
/* 4753 */     TNode tNode3 = null;
/* 4754 */     TNode tNode4 = null; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       AST aST1;
/* 4757 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 4758 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 42:
/* 4761 */           tNode2 = (TNode)aSTNULLType;
/* 4762 */           match((AST)aSTNULLType, 42);
/* 4763 */           aST = aSTNULLType.getNextSibling();
/* 4764 */           if (this.inputState.guessing == 0) {
/* 4765 */             print(tNode2);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 158:
/* 4771 */           tNode3 = (TNode)aST;
/* 4772 */           match(aST, 158);
/* 4773 */           aST = aST.getNextSibling();
/* 4774 */           if (this.inputState.guessing == 0) {
/* 4775 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 99:
/* 4781 */           charConst(aST);
/* 4782 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 135:
/* 4787 */           stringConst(aST);
/* 4788 */           aST = this._retTree;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 120:
/* 4793 */           aST1 = aST;
/* 4794 */           tNode4 = (aST == ASTNULL) ? null : (TNode)aST;
/* 4795 */           match(aST, 120);
/* 4796 */           aST = aST.getFirstChild();
/* 4797 */           if (this.inputState.guessing == 0) {
/* 4798 */             print(tNode4);
/*      */           }
/* 4800 */           expr(aST);
/* 4801 */           aST = this._retTree;
/* 4802 */           if (this.inputState.guessing == 0) {
/* 4803 */             print(")");
/*      */           }
/* 4805 */           aST = aST1;
/* 4806 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4811 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 4815 */     } catch (RecognitionException recognitionException) {
/* 4816 */       if (this.inputState.guessing == 0) {
/* 4817 */         reportError(recognitionException);
/* 4818 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 4820 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4823 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void emptyExpr(AST paramAST) throws RecognitionException {
/* 4828 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 4831 */       TNode tNode1 = (TNode)paramAST;
/* 4832 */       match(paramAST, 125);
/* 4833 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4835 */     catch (RecognitionException recognitionException) {
/* 4836 */       if (this.inputState.guessing == 0) {
/* 4837 */         reportError(recognitionException);
/* 4838 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4840 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4843 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void compoundStatementExpr(AST paramAST) throws RecognitionException {
/* 4848 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4849 */     TNode tNode2 = null;
/* 4850 */     TNode tNode3 = null;
/*      */     
/*      */     try {
/* 4853 */       AST aST = paramAST;
/* 4854 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4855 */       match(paramAST, 47);
/* 4856 */       paramAST = paramAST.getFirstChild();
/* 4857 */       if (this.inputState.guessing == 0) {
/* 4858 */         print(tNode2);
/*      */       }
/* 4860 */       compoundStatement(paramAST);
/* 4861 */       paramAST = this._retTree;
/* 4862 */       tNode3 = (TNode)paramAST;
/* 4863 */       match(paramAST, 48);
/* 4864 */       paramAST = paramAST.getNextSibling();
/* 4865 */       if (this.inputState.guessing == 0) {
/* 4866 */         print(tNode3);
/*      */       }
/* 4868 */       paramAST = aST;
/* 4869 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4871 */     catch (RecognitionException recognitionException) {
/* 4872 */       if (this.inputState.guessing == 0) {
/* 4873 */         reportError(recognitionException);
/* 4874 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4876 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4879 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void rangeExpr(AST paramAST) throws RecognitionException {
/* 4884 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4885 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 4888 */       AST aST = paramAST;
/* 4889 */       TNode tNode = (TNode)paramAST;
/* 4890 */       match(paramAST, 134);
/* 4891 */       paramAST = paramAST.getFirstChild();
/* 4892 */       expr(paramAST);
/* 4893 */       paramAST = this._retTree;
/* 4894 */       tNode2 = (TNode)paramAST;
/* 4895 */       match(paramAST, 51);
/* 4896 */       paramAST = paramAST.getNextSibling();
/* 4897 */       if (this.inputState.guessing == 0) {
/* 4898 */         print(tNode2);
/*      */       }
/* 4900 */       expr(paramAST);
/* 4901 */       paramAST = this._retTree;
/* 4902 */       paramAST = aST;
/* 4903 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 4905 */     catch (RecognitionException recognitionException) {
/* 4906 */       if (this.inputState.guessing == 0) {
/* 4907 */         reportError(recognitionException);
/* 4908 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 4910 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 4913 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void gnuAsmExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 4918 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4919 */     TNode tNode2 = null;
/* 4920 */     TNode tNode3 = null;
/* 4921 */     TNode tNode4 = null;
/* 4922 */     TNode tNode5 = null;
/* 4923 */     TNode tNode6 = null;
/* 4924 */     TNode tNode7 = null;
/* 4925 */     TNode tNode8 = null;
/* 4926 */     TNode tNode9 = null;
/* 4927 */     TNode tNode10 = null;
/* 4928 */     TNode tNode11 = null; try {
/*      */       ASTNULLType aSTNULLType3, aSTNULLType2; AST aST1;
/*      */       ASTNULLType aSTNULLType1;
/* 4931 */       AST aST3 = paramAST;
/* 4932 */       tNode2 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 4933 */       match(paramAST, 139);
/* 4934 */       paramAST = paramAST.getFirstChild();
/* 4935 */       if (this.inputState.guessing == 0) {
/* 4936 */         print(tNode2);
/*      */       }
/*      */       
/* 4939 */       if (paramAST == null) aSTNULLType3 = ASTNULL; 
/* 4940 */       switch (aSTNULLType3.getType()) {
/*      */         
/*      */         case 6:
/* 4943 */           tNode3 = (TNode)aSTNULLType3;
/* 4944 */           match((AST)aSTNULLType3, 6);
/* 4945 */           aST2 = aSTNULLType3.getNextSibling();
/* 4946 */           if (this.inputState.guessing == 0) {
/* 4947 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 4957 */           throw new NoViableAltException(aST2);
/*      */       } 
/*      */ 
/*      */       
/* 4961 */       tNode4 = (TNode)aST2;
/* 4962 */       match(aST2, 47);
/* 4963 */       AST aST2 = aST2.getNextSibling();
/* 4964 */       if (this.inputState.guessing == 0) {
/* 4965 */         print(tNode4);
/*      */       }
/* 4967 */       stringConst(aST2);
/* 4968 */       aST2 = this._retTree;
/*      */       
/* 4970 */       if (aST2 == null) aSTNULLType2 = ASTNULL; 
/* 4971 */       if (aSTNULLType2.getType() == 44) {
/* 4972 */         ASTNULLType aSTNULLType; AST aST4; tNode5 = (TNode)aSTNULLType2;
/* 4973 */         match((AST)aSTNULLType2, 44);
/* 4974 */         AST aST5 = aSTNULLType2.getNextSibling();
/* 4975 */         if (this.inputState.guessing == 0) {
/* 4976 */           print(tNode5);
/*      */         }
/*      */         
/* 4979 */         if (aST5 == null) aSTNULLType = ASTNULL; 
/* 4980 */         switch (aSTNULLType.getType()) {
/*      */           
/*      */           case 135:
/* 4983 */             strOptExprPair((AST)aSTNULLType);
/* 4984 */             aST4 = this._retTree;
/*      */ 
/*      */             
/*      */             while (true) {
/* 4988 */               if (aST4 == null) aSTNULLType1 = ASTNULL; 
/* 4989 */               if (aSTNULLType1.getType() == 43) {
/* 4990 */                 tNode6 = (TNode)aSTNULLType1;
/* 4991 */                 match((AST)aSTNULLType1, 43);
/* 4992 */                 aST4 = aSTNULLType1.getNextSibling();
/* 4993 */                 if (this.inputState.guessing == 0) {
/* 4994 */                   print(tNode6);
/*      */                 }
/* 4996 */                 strOptExprPair(aST4);
/* 4997 */                 aST4 = this._retTree;
/*      */                 continue;
/*      */               } 
/*      */               break;
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 44:
/*      */           case 48:
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 5014 */             throw new NoViableAltException(aST4);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 5019 */         if (aST4 == null) aSTNULLType1 = ASTNULL; 
/* 5020 */         if (aSTNULLType1.getType() == 44) {
/* 5021 */           ASTNULLType aSTNULLType4; tNode7 = (TNode)aSTNULLType1;
/* 5022 */           match((AST)aSTNULLType1, 44);
/* 5023 */           AST aST6 = aSTNULLType1.getNextSibling();
/* 5024 */           if (this.inputState.guessing == 0) {
/* 5025 */             print(tNode7);
/*      */           }
/*      */           
/* 5028 */           if (aST6 == null) aSTNULLType4 = ASTNULL; 
/* 5029 */           switch (aSTNULLType4.getType()) {
/*      */             
/*      */             case 135:
/* 5032 */               strOptExprPair((AST)aSTNULLType4);
/* 5033 */               aST1 = this._retTree;
/*      */               
/*      */               while (true) {
/*      */                 ASTNULLType aSTNULLType5;
/* 5037 */                 if (aST1 == null) aSTNULLType5 = ASTNULL; 
/* 5038 */                 if (aSTNULLType5.getType() == 43) {
/* 5039 */                   tNode8 = (TNode)aSTNULLType5;
/* 5040 */                   match((AST)aSTNULLType5, 43);
/* 5041 */                   aST1 = aSTNULLType5.getNextSibling();
/* 5042 */                   if (this.inputState.guessing == 0) {
/* 5043 */                     print(tNode8);
/*      */                   }
/* 5045 */                   strOptExprPair(aST1);
/* 5046 */                   aST1 = this._retTree;
/*      */                   continue;
/*      */                 } 
/*      */                 break;
/*      */               } 
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 44:
/*      */             case 48:
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             default:
/* 5063 */               throw new NoViableAltException(aST1);
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/* 5068 */         } else if (aST1.getType() != 44 && aST1.getType() != 48) {
/*      */ 
/*      */           
/* 5071 */           throw new NoViableAltException(aST1);
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 5076 */       else if (aST1.getType() != 44 && aST1.getType() != 48) {
/*      */ 
/*      */         
/* 5079 */         throw new NoViableAltException(aST1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 5084 */       if (aST1 == null) aSTNULLType1 = ASTNULL; 
/* 5085 */       switch (aSTNULLType1.getType()) {
/*      */         
/*      */         case 44:
/* 5088 */           tNode9 = (TNode)aSTNULLType1;
/* 5089 */           match((AST)aSTNULLType1, 44);
/* 5090 */           aST = aSTNULLType1.getNextSibling();
/* 5091 */           if (this.inputState.guessing == 0) {
/* 5092 */             print(tNode9);
/*      */           }
/* 5094 */           stringConst(aST);
/* 5095 */           aST = this._retTree;
/*      */           
/*      */           while (true) {
/*      */             ASTNULLType aSTNULLType;
/* 5099 */             if (aST == null) aSTNULLType = ASTNULL; 
/* 5100 */             if (aSTNULLType.getType() == 43) {
/* 5101 */               tNode10 = (TNode)aSTNULLType;
/* 5102 */               match((AST)aSTNULLType, 43);
/* 5103 */               aST = aSTNULLType.getNextSibling();
/* 5104 */               if (this.inputState.guessing == 0) {
/* 5105 */                 print(tNode10);
/*      */               }
/* 5107 */               stringConst(aST);
/* 5108 */               aST = this._retTree;
/*      */               continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 5124 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */       
/* 5128 */       tNode11 = (TNode)aST;
/* 5129 */       match(aST, 48);
/* 5130 */       aST = aST.getNextSibling();
/* 5131 */       if (this.inputState.guessing == 0) {
/* 5132 */         print(tNode11);
/*      */       }
/* 5134 */       aST = aST3;
/* 5135 */       aST = aST.getNextSibling();
/*      */     }
/* 5137 */     catch (RecognitionException recognitionException) {
/* 5138 */       if (this.inputState.guessing == 0) {
/* 5139 */         reportError(recognitionException);
/* 5140 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5142 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5145 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void stringConst(AST paramAST) throws RecognitionException {
/* 5150 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 5151 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 5154 */       AST aST = paramAST;
/* 5155 */       TNode tNode = (TNode)paramAST;
/* 5156 */       match(paramAST, 135);
/* 5157 */       paramAST = paramAST.getFirstChild();
/*      */       
/* 5159 */       byte b = 0; while (true) {
/*      */         ASTNULLType aSTNULLType;
/*      */         AST aST1;
/* 5162 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5163 */         if (aSTNULLType.getType() == 100) {
/* 5164 */           tNode2 = (TNode)aSTNULLType;
/* 5165 */           match((AST)aSTNULLType, 100);
/* 5166 */           aST1 = aSTNULLType.getNextSibling();
/* 5167 */           if (this.inputState.guessing == 0) {
/* 5168 */             print(tNode2);
/*      */           }
/*      */         } else {
/*      */           
/* 5172 */           if (b >= 1) break;  throw new NoViableAltException(aST1);
/*      */         } 
/*      */         
/* 5175 */         b++;
/*      */       } 
/*      */       
/* 5178 */       paramAST = aST;
/* 5179 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5181 */     catch (RecognitionException recognitionException) {
/* 5182 */       if (this.inputState.guessing == 0) {
/* 5183 */         reportError(recognitionException);
/* 5184 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5186 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5189 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void strOptExprPair(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5194 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 5195 */     TNode tNode2 = null;
/* 5196 */     TNode tNode3 = null;
/*      */     try {
/*      */       ASTNULLType aSTNULLType;
/* 5199 */       stringConst(paramAST);
/* 5200 */       paramAST = this._retTree;
/*      */       
/* 5202 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5203 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 47:
/* 5206 */           tNode2 = (TNode)aSTNULLType;
/* 5207 */           match((AST)aSTNULLType, 47);
/* 5208 */           aST = aSTNULLType.getNextSibling();
/* 5209 */           if (this.inputState.guessing == 0) {
/* 5210 */             print(tNode2);
/*      */           }
/* 5212 */           expr(aST);
/* 5213 */           aST = this._retTree;
/* 5214 */           tNode3 = (TNode)aST;
/* 5215 */           match(aST, 48);
/* 5216 */           aST = aST.getNextSibling();
/* 5217 */           if (this.inputState.guessing == 0) {
/* 5218 */             print(tNode3);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 43:
/*      */         case 44:
/*      */         case 48:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5230 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 5235 */     } catch (RecognitionException recognitionException) {
/* 5236 */       if (this.inputState.guessing == 0) {
/* 5237 */         reportError(recognitionException);
/* 5238 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5240 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5243 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void binaryOperator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5248 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 5251 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5252 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 45:
/* 5255 */           tNode1 = (TNode)aSTNULLType;
/* 5256 */           match((AST)aSTNULLType, 45);
/* 5257 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 64:
/* 5262 */           tNode1 = (TNode)aST;
/* 5263 */           match(aST, 64);
/* 5264 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 65:
/* 5269 */           tNode1 = (TNode)aST;
/* 5270 */           match(aST, 65);
/* 5271 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 66:
/* 5276 */           tNode1 = (TNode)aST;
/* 5277 */           match(aST, 66);
/* 5278 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 67:
/* 5283 */           tNode1 = (TNode)aST;
/* 5284 */           match(aST, 67);
/* 5285 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 68:
/* 5290 */           tNode1 = (TNode)aST;
/* 5291 */           match(aST, 68);
/* 5292 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 69:
/* 5297 */           tNode1 = (TNode)aST;
/* 5298 */           match(aST, 69);
/* 5299 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 70:
/* 5304 */           tNode1 = (TNode)aST;
/* 5305 */           match(aST, 70);
/* 5306 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 71:
/* 5311 */           tNode1 = (TNode)aST;
/* 5312 */           match(aST, 71);
/* 5313 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 72:
/* 5318 */           tNode1 = (TNode)aST;
/* 5319 */           match(aST, 72);
/* 5320 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 73:
/* 5325 */           tNode1 = (TNode)aST;
/* 5326 */           match(aST, 73);
/* 5327 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 75:
/* 5332 */           tNode1 = (TNode)aST;
/* 5333 */           match(aST, 75);
/* 5334 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 76:
/* 5339 */           tNode1 = (TNode)aST;
/* 5340 */           match(aST, 76);
/* 5341 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 77:
/* 5346 */           tNode1 = (TNode)aST;
/* 5347 */           match(aST, 77);
/* 5348 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 78:
/* 5353 */           tNode1 = (TNode)aST;
/* 5354 */           match(aST, 78);
/* 5355 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 79:
/* 5360 */           tNode1 = (TNode)aST;
/* 5361 */           match(aST, 79);
/* 5362 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 80:
/* 5367 */           tNode1 = (TNode)aST;
/* 5368 */           match(aST, 80);
/* 5369 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 81:
/* 5374 */           tNode1 = (TNode)aST;
/* 5375 */           match(aST, 81);
/* 5376 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 82:
/* 5381 */           tNode1 = (TNode)aST;
/* 5382 */           match(aST, 82);
/* 5383 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 83:
/* 5388 */           tNode1 = (TNode)aST;
/* 5389 */           match(aST, 83);
/* 5390 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 84:
/* 5395 */           tNode1 = (TNode)aST;
/* 5396 */           match(aST, 84);
/* 5397 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 85:
/* 5402 */           tNode1 = (TNode)aST;
/* 5403 */           match(aST, 85);
/* 5404 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 86:
/* 5409 */           tNode1 = (TNode)aST;
/* 5410 */           match(aST, 86);
/* 5411 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 87:
/* 5416 */           tNode1 = (TNode)aST;
/* 5417 */           match(aST, 87);
/* 5418 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 88:
/* 5423 */           tNode1 = (TNode)aST;
/* 5424 */           match(aST, 88);
/* 5425 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 5430 */           tNode1 = (TNode)aST;
/* 5431 */           match(aST, 89);
/* 5432 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/* 5437 */           tNode1 = (TNode)aST;
/* 5438 */           match(aST, 46);
/* 5439 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 90:
/* 5444 */           tNode1 = (TNode)aST;
/* 5445 */           match(aST, 90);
/* 5446 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 91:
/* 5451 */           tNode1 = (TNode)aST;
/* 5452 */           match(aST, 91);
/* 5453 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 130:
/* 5458 */           tNode1 = (TNode)aST;
/* 5459 */           match(aST, 130);
/* 5460 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5465 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5469 */     } catch (RecognitionException recognitionException) {
/* 5470 */       if (this.inputState.guessing == 0) {
/* 5471 */         reportError(recognitionException);
/* 5472 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5474 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5477 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void unaryOperator(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5482 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 5485 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5486 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 79:
/* 5489 */           tNode1 = (TNode)aSTNULLType;
/* 5490 */           match((AST)aSTNULLType, 79);
/* 5491 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 46:
/* 5496 */           tNode1 = (TNode)aST;
/* 5497 */           match(aST, 46);
/* 5498 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 88:
/* 5503 */           tNode1 = (TNode)aST;
/* 5504 */           match(aST, 88);
/* 5505 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 5510 */           tNode1 = (TNode)aST;
/* 5511 */           match(aST, 89);
/* 5512 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 95:
/* 5517 */           tNode1 = (TNode)aST;
/* 5518 */           match(aST, 95);
/* 5519 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 96:
/* 5524 */           tNode1 = (TNode)aST;
/* 5525 */           match(aST, 96);
/* 5526 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 76:
/* 5531 */           tNode1 = (TNode)aST;
/* 5532 */           match(aST, 76);
/* 5533 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 165:
/* 5538 */           tNode1 = (TNode)aST;
/* 5539 */           match(aST, 165);
/* 5540 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 166:
/* 5545 */           tNode1 = (TNode)aST;
/* 5546 */           match(aST, 166);
/* 5547 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5552 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5556 */     } catch (RecognitionException recognitionException) {
/* 5557 */       if (this.inputState.guessing == 0) {
/* 5558 */         reportError(recognitionException);
/* 5559 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5561 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5564 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void argExprList(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5569 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5572 */       expr(paramAST);
/* 5573 */       paramAST = this._retTree;
/*      */       
/*      */       while (true) {
/*      */         ASTNULLType aSTNULLType;
/* 5577 */         if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5578 */         if (_tokenSet_3.member(aSTNULLType.getType())) {
/* 5579 */           if (this.inputState.guessing == 0) {
/* 5580 */             print(",");
/*      */           }
/* 5582 */           expr((AST)aSTNULLType);
/* 5583 */           aST = this._retTree;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 5592 */     } catch (RecognitionException recognitionException) {
/* 5593 */       if (this.inputState.guessing == 0) {
/* 5594 */         reportError(recognitionException);
/* 5595 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5597 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5600 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void charConst(AST paramAST) throws RecognitionException {
/* 5605 */     TNode tNode1 = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/* 5606 */     TNode tNode2 = null;
/*      */     
/*      */     try {
/* 5609 */       tNode2 = (TNode)paramAST;
/* 5610 */       match(paramAST, 99);
/* 5611 */       paramAST = paramAST.getNextSibling();
/* 5612 */       if (this.inputState.guessing == 0) {
/* 5613 */         print(tNode2);
/*      */       }
/*      */     }
/* 5616 */     catch (RecognitionException recognitionException) {
/* 5617 */       if (this.inputState.guessing == 0) {
/* 5618 */         reportError(recognitionException);
/* 5619 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5621 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5624 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   protected final void intConst(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5629 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 5632 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5633 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 101:
/* 5636 */           tNode1 = (TNode)aSTNULLType;
/* 5637 */           match((AST)aSTNULLType, 101);
/* 5638 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 102:
/* 5643 */           tNode1 = (TNode)aST;
/* 5644 */           match(aST, 102);
/* 5645 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 103:
/* 5650 */           tNode1 = (TNode)aST;
/* 5651 */           match(aST, 103);
/* 5652 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 104:
/* 5657 */           tNode1 = (TNode)aST;
/* 5658 */           match(aST, 104);
/* 5659 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 105:
/* 5664 */           tNode1 = (TNode)aST;
/* 5665 */           match(aST, 105);
/* 5666 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 106:
/* 5671 */           tNode1 = (TNode)aST;
/* 5672 */           match(aST, 106);
/* 5673 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 107:
/* 5678 */           tNode1 = (TNode)aST;
/* 5679 */           match(aST, 107);
/* 5680 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 108:
/* 5685 */           tNode1 = (TNode)aST;
/* 5686 */           match(aST, 108);
/* 5687 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 109:
/* 5692 */           tNode1 = (TNode)aST;
/* 5693 */           match(aST, 109);
/* 5694 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5699 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5703 */     } catch (RecognitionException recognitionException) {
/* 5704 */       if (this.inputState.guessing == 0) {
/* 5705 */         reportError(recognitionException);
/* 5706 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5708 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5711 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   protected final void floatConst(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5716 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType;
/*      */       TNode tNode1;
/* 5719 */       if (paramAST == null) aSTNULLType = ASTNULL; 
/* 5720 */       switch (aSTNULLType.getType()) {
/*      */         
/*      */         case 110:
/* 5723 */           tNode1 = (TNode)aSTNULLType;
/* 5724 */           match((AST)aSTNULLType, 110);
/* 5725 */           aST = aSTNULLType.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 111:
/* 5730 */           tNode1 = (TNode)aST;
/* 5731 */           match(aST, 111);
/* 5732 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 112:
/* 5737 */           tNode1 = (TNode)aST;
/* 5738 */           match(aST, 112);
/* 5739 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5744 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5748 */     } catch (RecognitionException recognitionException) {
/* 5749 */       if (this.inputState.guessing == 0) {
/* 5750 */         reportError(recognitionException);
/* 5751 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5753 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5756 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void commaExpr(AST paramAST) throws RecognitionException {
/* 5761 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5764 */       AST aST = paramAST;
/* 5765 */       TNode tNode1 = (TNode)paramAST;
/* 5766 */       match(paramAST, 130);
/* 5767 */       paramAST = paramAST.getFirstChild();
/* 5768 */       expr(paramAST);
/* 5769 */       paramAST = this._retTree;
/* 5770 */       expr(paramAST);
/* 5771 */       paramAST = this._retTree;
/* 5772 */       paramAST = aST;
/* 5773 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5775 */     catch (RecognitionException recognitionException) {
/* 5776 */       if (this.inputState.guessing == 0) {
/* 5777 */         reportError(recognitionException);
/* 5778 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5780 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5783 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void assignExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 5788 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 5791 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 5792 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 45:
/* 5795 */           aSTNULLType3 = aSTNULLType2;
/* 5796 */           tNode1 = (TNode)aSTNULLType2;
/* 5797 */           match((AST)aSTNULLType2, 45);
/* 5798 */           aST1 = aSTNULLType2.getFirstChild();
/* 5799 */           expr(aST1);
/* 5800 */           aST1 = this._retTree;
/* 5801 */           expr(aST1);
/* 5802 */           aST1 = this._retTree;
/* 5803 */           aSTNULLType1 = aSTNULLType3;
/* 5804 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 64:
/* 5809 */           aST2 = aST;
/* 5810 */           tNode1 = (TNode)aST;
/* 5811 */           match(aST, 64);
/* 5812 */           aST = aST.getFirstChild();
/* 5813 */           expr(aST);
/* 5814 */           aST = this._retTree;
/* 5815 */           expr(aST);
/* 5816 */           aST = this._retTree;
/* 5817 */           aST = aST2;
/* 5818 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 65:
/* 5823 */           aST2 = aST;
/* 5824 */           tNode1 = (TNode)aST;
/* 5825 */           match(aST, 65);
/* 5826 */           aST = aST.getFirstChild();
/* 5827 */           expr(aST);
/* 5828 */           aST = this._retTree;
/* 5829 */           expr(aST);
/* 5830 */           aST = this._retTree;
/* 5831 */           aST = aST2;
/* 5832 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 66:
/* 5837 */           aST2 = aST;
/* 5838 */           tNode1 = (TNode)aST;
/* 5839 */           match(aST, 66);
/* 5840 */           aST = aST.getFirstChild();
/* 5841 */           expr(aST);
/* 5842 */           aST = this._retTree;
/* 5843 */           expr(aST);
/* 5844 */           aST = this._retTree;
/* 5845 */           aST = aST2;
/* 5846 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 67:
/* 5851 */           aST2 = aST;
/* 5852 */           tNode1 = (TNode)aST;
/* 5853 */           match(aST, 67);
/* 5854 */           aST = aST.getFirstChild();
/* 5855 */           expr(aST);
/* 5856 */           aST = this._retTree;
/* 5857 */           expr(aST);
/* 5858 */           aST = this._retTree;
/* 5859 */           aST = aST2;
/* 5860 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 68:
/* 5865 */           aST2 = aST;
/* 5866 */           tNode1 = (TNode)aST;
/* 5867 */           match(aST, 68);
/* 5868 */           aST = aST.getFirstChild();
/* 5869 */           expr(aST);
/* 5870 */           aST = this._retTree;
/* 5871 */           expr(aST);
/* 5872 */           aST = this._retTree;
/* 5873 */           aST = aST2;
/* 5874 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 69:
/* 5879 */           aST2 = aST;
/* 5880 */           tNode1 = (TNode)aST;
/* 5881 */           match(aST, 69);
/* 5882 */           aST = aST.getFirstChild();
/* 5883 */           expr(aST);
/* 5884 */           aST = this._retTree;
/* 5885 */           expr(aST);
/* 5886 */           aST = this._retTree;
/* 5887 */           aST = aST2;
/* 5888 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 70:
/* 5893 */           aST2 = aST;
/* 5894 */           tNode1 = (TNode)aST;
/* 5895 */           match(aST, 70);
/* 5896 */           aST = aST.getFirstChild();
/* 5897 */           expr(aST);
/* 5898 */           aST = this._retTree;
/* 5899 */           expr(aST);
/* 5900 */           aST = this._retTree;
/* 5901 */           aST = aST2;
/* 5902 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 71:
/* 5907 */           aST2 = aST;
/* 5908 */           tNode1 = (TNode)aST;
/* 5909 */           match(aST, 71);
/* 5910 */           aST = aST.getFirstChild();
/* 5911 */           expr(aST);
/* 5912 */           aST = this._retTree;
/* 5913 */           expr(aST);
/* 5914 */           aST = this._retTree;
/* 5915 */           aST = aST2;
/* 5916 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 72:
/* 5921 */           aST2 = aST;
/* 5922 */           tNode1 = (TNode)aST;
/* 5923 */           match(aST, 72);
/* 5924 */           aST = aST.getFirstChild();
/* 5925 */           expr(aST);
/* 5926 */           aST = this._retTree;
/* 5927 */           expr(aST);
/* 5928 */           aST = this._retTree;
/* 5929 */           aST = aST2;
/* 5930 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 73:
/* 5935 */           aST2 = aST;
/* 5936 */           tNode1 = (TNode)aST;
/* 5937 */           match(aST, 73);
/* 5938 */           aST = aST.getFirstChild();
/* 5939 */           expr(aST);
/* 5940 */           aST = this._retTree;
/* 5941 */           expr(aST);
/* 5942 */           aST = this._retTree;
/* 5943 */           aST = aST2;
/* 5944 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 5949 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 5953 */     } catch (RecognitionException recognitionException) {
/* 5954 */       if (this.inputState.guessing == 0) {
/* 5955 */         reportError(recognitionException);
/* 5956 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 5958 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5961 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalOrExpr(AST paramAST) throws RecognitionException {
/* 5966 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5969 */       AST aST = paramAST;
/* 5970 */       TNode tNode1 = (TNode)paramAST;
/* 5971 */       match(paramAST, 75);
/* 5972 */       paramAST = paramAST.getFirstChild();
/* 5973 */       expr(paramAST);
/* 5974 */       paramAST = this._retTree;
/* 5975 */       expr(paramAST);
/* 5976 */       paramAST = this._retTree;
/* 5977 */       paramAST = aST;
/* 5978 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 5980 */     catch (RecognitionException recognitionException) {
/* 5981 */       if (this.inputState.guessing == 0) {
/* 5982 */         reportError(recognitionException);
/* 5983 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 5985 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 5988 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalAndExpr(AST paramAST) throws RecognitionException {
/* 5993 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 5996 */       AST aST = paramAST;
/* 5997 */       TNode tNode1 = (TNode)paramAST;
/* 5998 */       match(paramAST, 76);
/* 5999 */       paramAST = paramAST.getFirstChild();
/* 6000 */       expr(paramAST);
/* 6001 */       paramAST = this._retTree;
/* 6002 */       expr(paramAST);
/* 6003 */       paramAST = this._retTree;
/* 6004 */       paramAST = aST;
/* 6005 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 6007 */     catch (RecognitionException recognitionException) {
/* 6008 */       if (this.inputState.guessing == 0) {
/* 6009 */         reportError(recognitionException);
/* 6010 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 6012 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6015 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void inclusiveOrExpr(AST paramAST) throws RecognitionException {
/* 6020 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 6023 */       AST aST = paramAST;
/* 6024 */       TNode tNode1 = (TNode)paramAST;
/* 6025 */       match(paramAST, 77);
/* 6026 */       paramAST = paramAST.getFirstChild();
/* 6027 */       expr(paramAST);
/* 6028 */       paramAST = this._retTree;
/* 6029 */       expr(paramAST);
/* 6030 */       paramAST = this._retTree;
/* 6031 */       paramAST = aST;
/* 6032 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 6034 */     catch (RecognitionException recognitionException) {
/* 6035 */       if (this.inputState.guessing == 0) {
/* 6036 */         reportError(recognitionException);
/* 6037 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 6039 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6042 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void exclusiveOrExpr(AST paramAST) throws RecognitionException {
/* 6047 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 6050 */       AST aST = paramAST;
/* 6051 */       TNode tNode1 = (TNode)paramAST;
/* 6052 */       match(paramAST, 78);
/* 6053 */       paramAST = paramAST.getFirstChild();
/* 6054 */       expr(paramAST);
/* 6055 */       paramAST = this._retTree;
/* 6056 */       expr(paramAST);
/* 6057 */       paramAST = this._retTree;
/* 6058 */       paramAST = aST;
/* 6059 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 6061 */     catch (RecognitionException recognitionException) {
/* 6062 */       if (this.inputState.guessing == 0) {
/* 6063 */         reportError(recognitionException);
/* 6064 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 6066 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6069 */     this._retTree = paramAST;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void bitAndExpr(AST paramAST) throws RecognitionException {
/* 6074 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST;
/*      */     
/*      */     try {
/* 6077 */       AST aST = paramAST;
/* 6078 */       TNode tNode1 = (TNode)paramAST;
/* 6079 */       match(paramAST, 79);
/* 6080 */       paramAST = paramAST.getFirstChild();
/* 6081 */       expr(paramAST);
/* 6082 */       paramAST = this._retTree;
/* 6083 */       expr(paramAST);
/* 6084 */       paramAST = this._retTree;
/* 6085 */       paramAST = aST;
/* 6086 */       paramAST = paramAST.getNextSibling();
/*      */     }
/* 6088 */     catch (RecognitionException recognitionException) {
/* 6089 */       if (this.inputState.guessing == 0) {
/* 6090 */         reportError(recognitionException);
/* 6091 */         if (paramAST != null) paramAST = paramAST.getNextSibling(); 
/*      */       } else {
/* 6093 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6096 */     this._retTree = paramAST;
/*      */   }
/*      */   
/*      */   public final void equalityExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6101 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 6104 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 6105 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 80:
/* 6108 */           aSTNULLType3 = aSTNULLType2;
/* 6109 */           tNode1 = (TNode)aSTNULLType2;
/* 6110 */           match((AST)aSTNULLType2, 80);
/* 6111 */           aST1 = aSTNULLType2.getFirstChild();
/* 6112 */           expr(aST1);
/* 6113 */           aST1 = this._retTree;
/* 6114 */           expr(aST1);
/* 6115 */           aST1 = this._retTree;
/* 6116 */           aSTNULLType1 = aSTNULLType3;
/* 6117 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 81:
/* 6122 */           aST2 = aST;
/* 6123 */           tNode1 = (TNode)aST;
/* 6124 */           match(aST, 81);
/* 6125 */           aST = aST.getFirstChild();
/* 6126 */           expr(aST);
/* 6127 */           aST = this._retTree;
/* 6128 */           expr(aST);
/* 6129 */           aST = this._retTree;
/* 6130 */           aST = aST2;
/* 6131 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6136 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 6140 */     } catch (RecognitionException recognitionException) {
/* 6141 */       if (this.inputState.guessing == 0) {
/* 6142 */         reportError(recognitionException);
/* 6143 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6145 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6148 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void relationalExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6153 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 6156 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 6157 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 82:
/* 6160 */           aSTNULLType3 = aSTNULLType2;
/* 6161 */           tNode1 = (TNode)aSTNULLType2;
/* 6162 */           match((AST)aSTNULLType2, 82);
/* 6163 */           aST1 = aSTNULLType2.getFirstChild();
/* 6164 */           expr(aST1);
/* 6165 */           aST1 = this._retTree;
/* 6166 */           expr(aST1);
/* 6167 */           aST1 = this._retTree;
/* 6168 */           aSTNULLType1 = aSTNULLType3;
/* 6169 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 83:
/* 6174 */           aST2 = aST;
/* 6175 */           tNode1 = (TNode)aST;
/* 6176 */           match(aST, 83);
/* 6177 */           aST = aST.getFirstChild();
/* 6178 */           expr(aST);
/* 6179 */           aST = this._retTree;
/* 6180 */           expr(aST);
/* 6181 */           aST = this._retTree;
/* 6182 */           aST = aST2;
/* 6183 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 84:
/* 6188 */           aST2 = aST;
/* 6189 */           tNode1 = (TNode)aST;
/* 6190 */           match(aST, 84);
/* 6191 */           aST = aST.getFirstChild();
/* 6192 */           expr(aST);
/* 6193 */           aST = this._retTree;
/* 6194 */           expr(aST);
/* 6195 */           aST = this._retTree;
/* 6196 */           aST = aST2;
/* 6197 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 85:
/* 6202 */           aST2 = aST;
/* 6203 */           tNode1 = (TNode)aST;
/* 6204 */           match(aST, 85);
/* 6205 */           aST = aST.getFirstChild();
/* 6206 */           expr(aST);
/* 6207 */           aST = this._retTree;
/* 6208 */           expr(aST);
/* 6209 */           aST = this._retTree;
/* 6210 */           aST = aST2;
/* 6211 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6216 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 6220 */     } catch (RecognitionException recognitionException) {
/* 6221 */       if (this.inputState.guessing == 0) {
/* 6222 */         reportError(recognitionException);
/* 6223 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6225 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6228 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void shiftExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6233 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 6236 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 6237 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 86:
/* 6240 */           aSTNULLType3 = aSTNULLType2;
/* 6241 */           tNode1 = (TNode)aSTNULLType2;
/* 6242 */           match((AST)aSTNULLType2, 86);
/* 6243 */           aST1 = aSTNULLType2.getFirstChild();
/* 6244 */           expr(aST1);
/* 6245 */           aST1 = this._retTree;
/* 6246 */           expr(aST1);
/* 6247 */           aST1 = this._retTree;
/* 6248 */           aSTNULLType1 = aSTNULLType3;
/* 6249 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 87:
/* 6254 */           aST2 = aST;
/* 6255 */           tNode1 = (TNode)aST;
/* 6256 */           match(aST, 87);
/* 6257 */           aST = aST.getFirstChild();
/* 6258 */           expr(aST);
/* 6259 */           aST = this._retTree;
/* 6260 */           expr(aST);
/* 6261 */           aST = this._retTree;
/* 6262 */           aST = aST2;
/* 6263 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6268 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 6272 */     } catch (RecognitionException recognitionException) {
/* 6273 */       if (this.inputState.guessing == 0) {
/* 6274 */         reportError(recognitionException);
/* 6275 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6277 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6280 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void additiveExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6285 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 6288 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 6289 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 88:
/* 6292 */           aSTNULLType3 = aSTNULLType2;
/* 6293 */           tNode1 = (TNode)aSTNULLType2;
/* 6294 */           match((AST)aSTNULLType2, 88);
/* 6295 */           aST1 = aSTNULLType2.getFirstChild();
/* 6296 */           expr(aST1);
/* 6297 */           aST1 = this._retTree;
/* 6298 */           expr(aST1);
/* 6299 */           aST1 = this._retTree;
/* 6300 */           aSTNULLType1 = aSTNULLType3;
/* 6301 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 89:
/* 6306 */           aST2 = aST;
/* 6307 */           tNode1 = (TNode)aST;
/* 6308 */           match(aST, 89);
/* 6309 */           aST = aST.getFirstChild();
/* 6310 */           expr(aST);
/* 6311 */           aST = this._retTree;
/* 6312 */           expr(aST);
/* 6313 */           aST = this._retTree;
/* 6314 */           aST = aST2;
/* 6315 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6320 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 6324 */     } catch (RecognitionException recognitionException) {
/* 6325 */       if (this.inputState.guessing == 0) {
/* 6326 */         reportError(recognitionException);
/* 6327 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6329 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6332 */     this._retTree = aST;
/*      */   }
/*      */   
/*      */   public final void multExpr(AST paramAST) throws RecognitionException {
/*      */     AST aST;
/* 6337 */     TNode tNode = (paramAST == ASTNULL) ? null : (TNode)paramAST; try {
/*      */       ASTNULLType aSTNULLType2; AST aST1; ASTNULLType aSTNULLType1; ASTNULLType aSTNULLType3; AST aST2;
/*      */       TNode tNode1;
/* 6340 */       if (paramAST == null) aSTNULLType2 = ASTNULL; 
/* 6341 */       switch (aSTNULLType2.getType()) {
/*      */         
/*      */         case 46:
/* 6344 */           aSTNULLType3 = aSTNULLType2;
/* 6345 */           tNode1 = (TNode)aSTNULLType2;
/* 6346 */           match((AST)aSTNULLType2, 46);
/* 6347 */           aST1 = aSTNULLType2.getFirstChild();
/* 6348 */           expr(aST1);
/* 6349 */           aST1 = this._retTree;
/* 6350 */           expr(aST1);
/* 6351 */           aST1 = this._retTree;
/* 6352 */           aSTNULLType1 = aSTNULLType3;
/* 6353 */           aST = aSTNULLType1.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 90:
/* 6358 */           aST2 = aST;
/* 6359 */           tNode1 = (TNode)aST;
/* 6360 */           match(aST, 90);
/* 6361 */           aST = aST.getFirstChild();
/* 6362 */           expr(aST);
/* 6363 */           aST = this._retTree;
/* 6364 */           expr(aST);
/* 6365 */           aST = this._retTree;
/* 6366 */           aST = aST2;
/* 6367 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 91:
/* 6372 */           aST2 = aST;
/* 6373 */           tNode1 = (TNode)aST;
/* 6374 */           match(aST, 91);
/* 6375 */           aST = aST.getFirstChild();
/* 6376 */           expr(aST);
/* 6377 */           aST = this._retTree;
/* 6378 */           expr(aST);
/* 6379 */           aST = this._retTree;
/* 6380 */           aST = aST2;
/* 6381 */           aST = aST.getNextSibling();
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 6386 */           throw new NoViableAltException(aST);
/*      */       } 
/*      */ 
/*      */     
/* 6390 */     } catch (RecognitionException recognitionException) {
/* 6391 */       if (this.inputState.guessing == 0) {
/* 6392 */         reportError(recognitionException);
/* 6393 */         if (aST != null) aST = aST.getNextSibling(); 
/*      */       } else {
/* 6395 */         throw recognitionException;
/*      */       } 
/*      */     } 
/* 6398 */     this._retTree = aST;
/*      */   }
/*      */ 
/*      */   
/* 6402 */   public static final String[] _tokenNames = new String[] { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"typedef\"", "\"asm\"", "\"volatile\"", "LCURLY", "RCURLY", "SEMI", "\"struct\"", "\"union\"", "\"enum\"", "\"auto\"", "\"register\"", "\"extern\"", "\"static\"", "\"const\"", "\"void\"", "\"char\"", "\"short\"", "\"int\"", "\"long\"", "\"float\"", "\"double\"", "\"signed\"", "\"unsigned\"", "\"int8_t\"", "\"uint8_t\"", "\"int16_t\"", "\"uint16_t\"", "\"__int32\"", "\"int32_t\"", "\"wchar_t\"", "\"uint32_t\"", "\"__int64\"", "\"int64_t\"", "\"uint64_t\"", "\"ptrdiff_t\"", "\"intptr_t\"", "\"size_t\"", "\"uintptr_t\"", "ID", "COMMA", "COLON", "ASSIGN", "STAR", "LPAREN", "RPAREN", "LBRACKET", "RBRACKET", "VARARGS", "\"while\"", "\"do\"", "\"for\"", "\"goto\"", "\"continue\"", "\"break\"", "\"return\"", "\"case\"", "\"default\"", "\"if\"", "\"else\"", "\"switch\"", "DIV_ASSIGN", "PLUS_ASSIGN", "MINUS_ASSIGN", "STAR_ASSIGN", "MOD_ASSIGN", "RSHIFT_ASSIGN", "LSHIFT_ASSIGN", "BAND_ASSIGN", "BOR_ASSIGN", "BXOR_ASSIGN", "QUESTION", "LOR", "LAND", "BOR", "BXOR", "BAND", "EQUAL", "NOT_EQUAL", "LT", "LTE", "GT", "GTE", "LSHIFT", "RSHIFT", "PLUS", "MINUS", "DIV", "MOD", "INC", "DEC", "\"sizeof\"", "BNOT", "LNOT", "PTR", "DOT", "CharLiteral", "StringLiteral", "IntOctalConst", "LongOctalConst", "UnsignedOctalConst", "IntIntConst", "LongIntConst", "UnsignedIntConst", "IntHexConst", "LongHexConst", "UnsignedHexConst", "FloatDoubleConst", "DoubleDoubleConst", "LongDoubleConst", "NTypedefName", "NInitDecl", "NDeclarator", "NStructDeclarator", "NDeclaration", "NCast", "NPointerGroup", "NExpressionGroup", "NFunctionCallArgs", "NNonemptyAbstractDeclarator", "NInitializer", "NStatementExpr", "NEmptyExpression", "NParameterTypeList", "NFunctionDef", "NCompoundStatement", "NParameterDeclaration", "NCommaExpr", "NUnaryExpr", "NLabel", "NPostfixExpr", "NRangeExpr", "NStringSeq", "NInitializerElementLabel", "NLcurlyInitializer", "NAsmAttribute", "NGnuAsmExpr", "NTypeMissing", "Vocabulary", "Whitespace", "Comment", "CPPComment", "NonWhitespace", "a line directive", "DefineExpr", "DefineExpr2", "Space", "LineDirective", "BadStringLiteral", "Escape", "Digit", "LongSuffix", "UnsignedSuffix", "FloatSuffix", "Exponent", "Number", "\"__label__\"", "\"inline\"", "\"typeof\"", "\"__complex\"", "\"__attribute\"", "\"__alignof\"", "\"__real\"", "\"__imag\"" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 6573 */     return new long[] { 544L, -9214364837600034816L, 4096L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 6576 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 6578 */     return new long[] { 134093888L, 562949953421312L, 25769803776L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 6581 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 6583 */     return new long[] { -4616189618054757888L, 1152921504606846976L, 17L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 6586 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 6588 */     return new long[] { 250688651132928L, 2972375790571749375L, 69793221356L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 6591 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/GnuCEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */