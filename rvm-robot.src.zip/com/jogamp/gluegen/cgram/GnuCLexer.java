/*      */ package com.jogamp.gluegen.cgram;
/*      */ 
/*      */ import antlr.ANTLRHashString;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import com.jogamp.gluegen.ASTLocusTag;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GnuCLexer
/*      */   extends CharScanner
/*      */   implements GnuCLexerTokenTypes, TokenStream
/*      */ {
/*      */   public void initialize(String paramString) {
/*   44 */     setOriginalSource(paramString);
/*   45 */     initialize();
/*      */   }
/*      */ 
/*      */   
/*      */   public void initialize() {
/*   50 */     this.literals.put(new ANTLRHashString("__alignof__", this), new Integer(164));
/*   51 */     this.literals.put(new ANTLRHashString("__asm", this), new Integer(5));
/*   52 */     this.literals.put(new ANTLRHashString("__asm__", this), new Integer(5));
/*   53 */     this.literals.put(new ANTLRHashString("__attribute__", this), new Integer(163));
/*   54 */     this.literals.put(new ANTLRHashString("__complex__", this), new Integer(162));
/*   55 */     this.literals.put(new ANTLRHashString("__const", this), new Integer(17));
/*   56 */     this.literals.put(new ANTLRHashString("__const__", this), new Integer(17));
/*   57 */     this.literals.put(new ANTLRHashString("__imag__", this), new Integer(166));
/*   58 */     this.literals.put(new ANTLRHashString("__inline", this), new Integer(160));
/*   59 */     this.literals.put(new ANTLRHashString("__inline__", this), new Integer(160));
/*   60 */     this.literals.put(new ANTLRHashString("__real__", this), new Integer(165));
/*   61 */     this.literals.put(new ANTLRHashString("__signed", this), new Integer(25));
/*   62 */     this.literals.put(new ANTLRHashString("__signed__", this), new Integer(25));
/*   63 */     this.literals.put(new ANTLRHashString("__typeof", this), new Integer(161));
/*   64 */     this.literals.put(new ANTLRHashString("__typeof__", this), new Integer(161));
/*   65 */     this.literals.put(new ANTLRHashString("__volatile", this), new Integer(6));
/*   66 */     this.literals.put(new ANTLRHashString("__volatile__", this), new Integer(6));
/*      */   }
/*      */ 
/*      */   
/*   70 */   LineObject lineObject = new LineObject();
/*   71 */   String originalSource = "";
/*   72 */   PreprocessorInfoChannel preprocessorInfoChannel = new PreprocessorInfoChannel();
/*   73 */   int tokenNumber = 0;
/*      */   boolean countingTokens = true;
/*   75 */   int deferredLineCount = 0;
/*   76 */   List defines = new ArrayList();
/*      */ 
/*      */   
/*      */   public void setCountingTokens(boolean paramBoolean) {
/*   80 */     this.countingTokens = paramBoolean;
/*   81 */     if (this.countingTokens) {
/*   82 */       this.tokenNumber = 0;
/*      */     } else {
/*      */       
/*   85 */       this.tokenNumber = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOriginalSource(String paramString) {
/*   91 */     this.originalSource = paramString;
/*   92 */     this.lineObject.setSource(paramString);
/*      */   }
/*      */   
/*      */   public void setSource(String paramString) {
/*   96 */     this.lineObject.setSource(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public PreprocessorInfoChannel getPreprocessorInfoChannel() {
/*  101 */     return this.preprocessorInfoChannel;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPreprocessingDirective(String paramString) {
/*  106 */     this.preprocessorInfoChannel.addLineForTokenNumber(paramString, new Integer(this.tokenNumber));
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDefine(String paramString1, String paramString2) {
/*  111 */     this.defines.add(new Define(paramString1, paramString2, new ASTLocusTag(this.lineObject.getSource(), this.lineObject.getLine() + this.deferredLineCount, -1, paramString1)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List getDefines() {
/*  117 */     return this.defines;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Token makeToken(int paramInt) {
/*  122 */     if (paramInt != -1 && this.countingTokens) {
/*  123 */       this.tokenNumber++;
/*      */     }
/*  125 */     CToken cToken = (CToken)super.makeToken(paramInt);
/*  126 */     cToken.setLine(this.lineObject.line);
/*  127 */     cToken.setSource(this.lineObject.source);
/*  128 */     cToken.setTokenNumber(this.tokenNumber);
/*      */     
/*  130 */     this.lineObject.line += this.deferredLineCount;
/*  131 */     this.deferredLineCount = 0;
/*  132 */     return (Token)cToken;
/*      */   }
/*      */   
/*      */   public void deferredNewline() {
/*  136 */     this.deferredLineCount++;
/*      */   }
/*      */   
/*      */   public void newline() {
/*  140 */     this.lineObject.newline();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GnuCLexer(InputStream paramInputStream) {
/*  149 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public GnuCLexer(Reader paramReader) {
/*  152 */     this((InputBuffer)new CharBuffer(paramReader));
/*      */   }
/*      */   public GnuCLexer(InputBuffer paramInputBuffer) {
/*  155 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public GnuCLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  158 */     super(paramLexerSharedInputState);
/*  159 */     this.caseSensitiveLiterals = true;
/*  160 */     setCaseSensitive(true);
/*  161 */     this.literals = new Hashtable<>();
/*  162 */     this.literals.put(new ANTLRHashString("intptr_t", this), new Integer(39));
/*  163 */     this.literals.put(new ANTLRHashString("extern", this), new Integer(15));
/*  164 */     this.literals.put(new ANTLRHashString("__real", this), new Integer(165));
/*  165 */     this.literals.put(new ANTLRHashString("case", this), new Integer(59));
/*  166 */     this.literals.put(new ANTLRHashString("short", this), new Integer(20));
/*  167 */     this.literals.put(new ANTLRHashString("break", this), new Integer(57));
/*  168 */     this.literals.put(new ANTLRHashString("while", this), new Integer(52));
/*  169 */     this.literals.put(new ANTLRHashString("uint32_t", this), new Integer(34));
/*  170 */     this.literals.put(new ANTLRHashString("int16_t", this), new Integer(29));
/*  171 */     this.literals.put(new ANTLRHashString("ptrdiff_t", this), new Integer(38));
/*  172 */     this.literals.put(new ANTLRHashString("typeof", this), new Integer(161));
/*  173 */     this.literals.put(new ANTLRHashString("inline", this), new Integer(160));
/*  174 */     this.literals.put(new ANTLRHashString("unsigned", this), new Integer(26));
/*  175 */     this.literals.put(new ANTLRHashString("const", this), new Integer(17));
/*  176 */     this.literals.put(new ANTLRHashString("float", this), new Integer(23));
/*  177 */     this.literals.put(new ANTLRHashString("return", this), new Integer(58));
/*  178 */     this.literals.put(new ANTLRHashString("int64_t", this), new Integer(36));
/*  179 */     this.literals.put(new ANTLRHashString("sizeof", this), new Integer(94));
/*  180 */     this.literals.put(new ANTLRHashString("size_t", this), new Integer(40));
/*  181 */     this.literals.put(new ANTLRHashString("do", this), new Integer(53));
/*  182 */     this.literals.put(new ANTLRHashString("__label__", this), new Integer(159));
/*  183 */     this.literals.put(new ANTLRHashString("typedef", this), new Integer(4));
/*  184 */     this.literals.put(new ANTLRHashString("uint16_t", this), new Integer(30));
/*  185 */     this.literals.put(new ANTLRHashString("if", this), new Integer(61));
/*  186 */     this.literals.put(new ANTLRHashString("__int32", this), new Integer(31));
/*  187 */     this.literals.put(new ANTLRHashString("double", this), new Integer(24));
/*  188 */     this.literals.put(new ANTLRHashString("volatile", this), new Integer(6));
/*  189 */     this.literals.put(new ANTLRHashString("__attribute", this), new Integer(163));
/*  190 */     this.literals.put(new ANTLRHashString("union", this), new Integer(11));
/*  191 */     this.literals.put(new ANTLRHashString("register", this), new Integer(14));
/*  192 */     this.literals.put(new ANTLRHashString("auto", this), new Integer(13));
/*  193 */     this.literals.put(new ANTLRHashString("goto", this), new Integer(55));
/*  194 */     this.literals.put(new ANTLRHashString("enum", this), new Integer(12));
/*  195 */     this.literals.put(new ANTLRHashString("int", this), new Integer(21));
/*  196 */     this.literals.put(new ANTLRHashString("for", this), new Integer(54));
/*  197 */     this.literals.put(new ANTLRHashString("int32_t", this), new Integer(32));
/*  198 */     this.literals.put(new ANTLRHashString("uint64_t", this), new Integer(37));
/*  199 */     this.literals.put(new ANTLRHashString("char", this), new Integer(19));
/*  200 */     this.literals.put(new ANTLRHashString("default", this), new Integer(60));
/*  201 */     this.literals.put(new ANTLRHashString("__imag", this), new Integer(166));
/*  202 */     this.literals.put(new ANTLRHashString("__alignof", this), new Integer(164));
/*  203 */     this.literals.put(new ANTLRHashString("static", this), new Integer(16));
/*  204 */     this.literals.put(new ANTLRHashString("int8_t", this), new Integer(27));
/*  205 */     this.literals.put(new ANTLRHashString("uint8_t", this), new Integer(28));
/*  206 */     this.literals.put(new ANTLRHashString("continue", this), new Integer(56));
/*  207 */     this.literals.put(new ANTLRHashString("struct", this), new Integer(10));
/*  208 */     this.literals.put(new ANTLRHashString("__int64", this), new Integer(35));
/*  209 */     this.literals.put(new ANTLRHashString("signed", this), new Integer(25));
/*  210 */     this.literals.put(new ANTLRHashString("else", this), new Integer(62));
/*  211 */     this.literals.put(new ANTLRHashString("uintptr_t", this), new Integer(41));
/*  212 */     this.literals.put(new ANTLRHashString("void", this), new Integer(18));
/*  213 */     this.literals.put(new ANTLRHashString("wchar_t", this), new Integer(33));
/*  214 */     this.literals.put(new ANTLRHashString("switch", this), new Integer(63));
/*  215 */     this.literals.put(new ANTLRHashString("long", this), new Integer(22));
/*  216 */     this.literals.put(new ANTLRHashString("__extension__", this), new Integer(167));
/*  217 */     this.literals.put(new ANTLRHashString("asm", this), new Integer(5));
/*  218 */     this.literals.put(new ANTLRHashString("__complex", this), new Integer(162));
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  222 */     Token token = null;
/*      */     
/*      */     while (true) {
/*  225 */       Object object = null;
/*  226 */       int i = 0;
/*  227 */       resetText();
/*      */       
/*      */       try {
/*  230 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\f':
/*      */           case '\r':
/*      */           case ' ':
/*  234 */             mWhitespace(true);
/*  235 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\'':
/*  240 */             mCharLiteral(true);
/*  241 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '"':
/*  246 */             mStringLiteral(true);
/*  247 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ':':
/*  252 */             mCOLON(true);
/*  253 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ',':
/*  258 */             mCOMMA(true);
/*  259 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '?':
/*  264 */             mQUESTION(true);
/*  265 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ';':
/*  270 */             mSEMI(true);
/*  271 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*  276 */             mRPAREN(true);
/*  277 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '[':
/*  282 */             mLBRACKET(true);
/*  283 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ']':
/*  288 */             mRBRACKET(true);
/*  289 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '{':
/*  294 */             mLCURLY(true);
/*  295 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '}':
/*  300 */             mRCURLY(true);
/*  301 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '~':
/*  306 */             mBNOT(true);
/*  307 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '#':
/*  312 */             mPREPROC_DIRECTIVE(true);
/*  313 */             token = this._returnToken;
/*      */             break;
/*      */           
/*      */           default:
/*  317 */             if (LA(1) == '>' && LA(2) == '>' && LA(3) == '=') {
/*  318 */               mRSHIFT_ASSIGN(true);
/*  319 */               token = this._returnToken; break;
/*      */             } 
/*  321 */             if (LA(1) == '<' && LA(2) == '<' && LA(3) == '=') {
/*  322 */               mLSHIFT_ASSIGN(true);
/*  323 */               token = this._returnToken; break;
/*      */             } 
/*  325 */             if (LA(1) == 'L' && LA(2) == '\'') {
/*  326 */               mWideCharLiteral(true);
/*  327 */               token = this._returnToken; break;
/*      */             } 
/*  329 */             if (LA(1) == 'L' && LA(2) == '"') {
/*  330 */               mWideStringLiteral(true);
/*  331 */               token = this._returnToken; break;
/*      */             } 
/*  333 */             if (LA(1) == '-' && LA(2) == '>') {
/*  334 */               mPTR(true);
/*  335 */               token = this._returnToken; break;
/*      */             } 
/*  337 */             if (LA(1) == '=' && LA(2) == '=') {
/*  338 */               mEQUAL(true);
/*  339 */               token = this._returnToken; break;
/*      */             } 
/*  341 */             if (LA(1) == '!' && LA(2) == '=') {
/*  342 */               mNOT_EQUAL(true);
/*  343 */               token = this._returnToken; break;
/*      */             } 
/*  345 */             if (LA(1) == '<' && LA(2) == '=') {
/*  346 */               mLTE(true);
/*  347 */               token = this._returnToken; break;
/*      */             } 
/*  349 */             if (LA(1) == '>' && LA(2) == '=') {
/*  350 */               mGTE(true);
/*  351 */               token = this._returnToken; break;
/*      */             } 
/*  353 */             if (LA(1) == '/' && LA(2) == '=') {
/*  354 */               mDIV_ASSIGN(true);
/*  355 */               token = this._returnToken; break;
/*      */             } 
/*  357 */             if (LA(1) == '+' && LA(2) == '=') {
/*  358 */               mPLUS_ASSIGN(true);
/*  359 */               token = this._returnToken; break;
/*      */             } 
/*  361 */             if (LA(1) == '+' && LA(2) == '+') {
/*  362 */               mINC(true);
/*  363 */               token = this._returnToken; break;
/*      */             } 
/*  365 */             if (LA(1) == '-' && LA(2) == '=') {
/*  366 */               mMINUS_ASSIGN(true);
/*  367 */               token = this._returnToken; break;
/*      */             } 
/*  369 */             if (LA(1) == '-' && LA(2) == '-') {
/*  370 */               mDEC(true);
/*  371 */               token = this._returnToken; break;
/*      */             } 
/*  373 */             if (LA(1) == '*' && LA(2) == '=') {
/*  374 */               mSTAR_ASSIGN(true);
/*  375 */               token = this._returnToken; break;
/*      */             } 
/*  377 */             if (LA(1) == '%' && LA(2) == '=') {
/*  378 */               mMOD_ASSIGN(true);
/*  379 */               token = this._returnToken; break;
/*      */             } 
/*  381 */             if (LA(1) == '>' && LA(2) == '>') {
/*  382 */               mRSHIFT(true);
/*  383 */               token = this._returnToken; break;
/*      */             } 
/*  385 */             if (LA(1) == '<' && LA(2) == '<') {
/*  386 */               mLSHIFT(true);
/*  387 */               token = this._returnToken; break;
/*      */             } 
/*  389 */             if (LA(1) == '&' && LA(2) == '&') {
/*  390 */               mLAND(true);
/*  391 */               token = this._returnToken; break;
/*      */             } 
/*  393 */             if (LA(1) == '|' && LA(2) == '|') {
/*  394 */               mLOR(true);
/*  395 */               token = this._returnToken; break;
/*      */             } 
/*  397 */             if (LA(1) == '&' && LA(2) == '=') {
/*  398 */               mBAND_ASSIGN(true);
/*  399 */               token = this._returnToken; break;
/*      */             } 
/*  401 */             if (LA(1) == '|' && LA(2) == '=') {
/*  402 */               mBOR_ASSIGN(true);
/*  403 */               token = this._returnToken; break;
/*      */             } 
/*  405 */             if (LA(1) == '^' && LA(2) == '=') {
/*  406 */               mBXOR_ASSIGN(true);
/*  407 */               token = this._returnToken; break;
/*      */             } 
/*  409 */             if (LA(1) == '/' && LA(2) == '*') {
/*  410 */               mComment(true);
/*  411 */               token = this._returnToken; break;
/*      */             } 
/*  413 */             if (LA(1) == '/' && LA(2) == '/') {
/*  414 */               mCPPComment(true);
/*  415 */               token = this._returnToken; break;
/*      */             } 
/*  417 */             if (_tokenSet_0.member(LA(1))) {
/*  418 */               mNumber(true);
/*  419 */               token = this._returnToken; break;
/*      */             } 
/*  421 */             if (_tokenSet_1.member(LA(1))) {
/*  422 */               mIDMEAT(true);
/*  423 */               token = this._returnToken; break;
/*      */             } 
/*  425 */             if (LA(1) == '=') {
/*  426 */               mASSIGN(true);
/*  427 */               token = this._returnToken; break;
/*      */             } 
/*  429 */             if (LA(1) == '(') {
/*  430 */               mLPAREN(true);
/*  431 */               token = this._returnToken; break;
/*      */             } 
/*  433 */             if (LA(1) == '<') {
/*  434 */               mLT(true);
/*  435 */               token = this._returnToken; break;
/*      */             } 
/*  437 */             if (LA(1) == '>') {
/*  438 */               mGT(true);
/*  439 */               token = this._returnToken; break;
/*      */             } 
/*  441 */             if (LA(1) == '/') {
/*  442 */               mDIV(true);
/*  443 */               token = this._returnToken; break;
/*      */             } 
/*  445 */             if (LA(1) == '+') {
/*  446 */               mPLUS(true);
/*  447 */               token = this._returnToken; break;
/*      */             } 
/*  449 */             if (LA(1) == '-') {
/*  450 */               mMINUS(true);
/*  451 */               token = this._returnToken; break;
/*      */             } 
/*  453 */             if (LA(1) == '*') {
/*  454 */               mSTAR(true);
/*  455 */               token = this._returnToken; break;
/*      */             } 
/*  457 */             if (LA(1) == '%') {
/*  458 */               mMOD(true);
/*  459 */               token = this._returnToken; break;
/*      */             } 
/*  461 */             if (LA(1) == '!') {
/*  462 */               mLNOT(true);
/*  463 */               token = this._returnToken; break;
/*      */             } 
/*  465 */             if (LA(1) == '&') {
/*  466 */               mBAND(true);
/*  467 */               token = this._returnToken; break;
/*      */             } 
/*  469 */             if (LA(1) == '|') {
/*  470 */               mBOR(true);
/*  471 */               token = this._returnToken; break;
/*      */             } 
/*  473 */             if (LA(1) == '^') {
/*  474 */               mBXOR(true);
/*  475 */               token = this._returnToken; break;
/*      */             } 
/*  477 */             if (_tokenSet_2.member(LA(1))) {
/*  478 */               mDefineExpr(true);
/*  479 */               token = this._returnToken; break;
/*      */             } 
/*  481 */             if (_tokenSet_0.member(LA(1))) {
/*  482 */               mDefineExpr2(true);
/*  483 */               token = this._returnToken;
/*      */               break;
/*      */             } 
/*  486 */             if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); break; }
/*  487 */              throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */         
/*  490 */         if (this._returnToken == null)
/*  491 */           continue;  i = this._returnToken.getType();
/*  492 */         this._returnToken.setType(i);
/*  493 */         return this._returnToken;
/*      */       }
/*  495 */       catch (RecognitionException recognitionException) {
/*  496 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  499 */       catch (CharStreamException charStreamException) {
/*  500 */         if (charStreamException instanceof CharStreamIOException) {
/*  501 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  504 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void mWhitespace(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  511 */     Token token = null; int i = this.text.length();
/*  512 */     short s = 142;
/*      */ 
/*      */ 
/*      */     
/*  516 */     if (LA(1) == '\r' && LA(2) == '\n') {
/*  517 */       match("\r\n");
/*  518 */       if (this.inputState.guessing == 0) {
/*  519 */         newline();
/*      */       }
/*      */     }
/*  522 */     else if (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/*      */       
/*  524 */       switch (LA(1)) {
/*      */         
/*      */         case ' ':
/*  527 */           match(' ');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\t':
/*  532 */           match('\t');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\f':
/*  537 */           match('\f');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  542 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/*  547 */     } else if (LA(1) == '\n' || LA(1) == '\r') {
/*      */       
/*  549 */       switch (LA(1)) {
/*      */         
/*      */         case '\n':
/*  552 */           match('\n');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\r':
/*  557 */           match('\r');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  562 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */       
/*  566 */       if (this.inputState.guessing == 0) {
/*  567 */         newline();
/*      */       }
/*      */     } else {
/*      */       
/*  571 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  575 */     if (this.inputState.guessing == 0) {
/*  576 */       s = -1;
/*      */     }
/*  578 */     if (paramBoolean && token == null && s != -1) {
/*  579 */       token = makeToken(s);
/*  580 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  582 */     this._returnToken = token;
/*      */   }
/*      */   protected final void mEscape(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     byte b;
/*  586 */     Token token = null; int i = this.text.length();
/*  587 */     char c = '';
/*      */ 
/*      */     
/*  590 */     match('\\');
/*      */     
/*  592 */     switch (LA(1)) { case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/*  596 */         matchRange('0', '3');
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  601 */         while (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/*  602 */           mDigit(false);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*  615 */         matchRange('4', '7');
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  620 */         while (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/*  621 */           mDigit(false);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 'x':
/*  633 */         match('x');
/*      */         
/*  635 */         b = 0;
/*      */         
/*      */         while (true) {
/*  638 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/*  639 */             mDigit(false);
/*      */           }
/*  641 */           else if (LA(1) >= 'a' && LA(1) <= 'f' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/*  642 */             matchRange('a', 'f');
/*      */           }
/*  644 */           else if (LA(1) >= 'A' && LA(1) <= 'F' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/*  645 */             matchRange('A', 'F');
/*      */           } else {
/*      */             
/*  648 */             if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/*  651 */           b++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  657 */         if (_tokenSet_3.member(LA(1))) {
/*      */           
/*  659 */           match(_tokenSet_3);
/*      */           
/*      */           break;
/*      */         } 
/*  663 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/*  667 */     if (paramBoolean && token == null && c != -1) {
/*  668 */       token = makeToken(c);
/*  669 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  671 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDigit(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  675 */     Token token = null; int i = this.text.length();
/*  676 */     char c = '';
/*      */ 
/*      */     
/*  679 */     matchRange('0', '9');
/*  680 */     if (paramBoolean && token == null && c != -1) {
/*  681 */       token = makeToken(c);
/*  682 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  684 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mIntSuffix(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  688 */     Token token = null; int i = this.text.length();
/*  689 */     char c = '¨';
/*      */ 
/*      */     
/*  692 */     switch (LA(1)) {
/*      */       
/*      */       case 'L':
/*  695 */         match('L');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'l':
/*  700 */         match('l');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'U':
/*  705 */         match('U');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'u':
/*  710 */         match('u');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'I':
/*  715 */         match('I');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'i':
/*  720 */         match('i');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'J':
/*  725 */         match('J');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'j':
/*  730 */         match('j');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  735 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  738 */     if (paramBoolean && token == null && c != -1) {
/*  739 */       token = makeToken(c);
/*  740 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  742 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mNumberSuffix(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  746 */     Token token = null; int i = this.text.length();
/*  747 */     char c = '©';
/*      */ 
/*      */     
/*  750 */     switch (LA(1)) { case 'I': case 'J': case 'L': case 'U': case 'i':
/*      */       case 'j':
/*      */       case 'l':
/*      */       case 'u':
/*  754 */         mIntSuffix(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'F':
/*  759 */         match('F');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/*  764 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  769 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */     
/*  772 */     if (paramBoolean && token == null && c != -1) {
/*  773 */       token = makeToken(c);
/*  774 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  776 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mNumber(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  780 */     Token token = null; int i = this.text.length();
/*  781 */     char c = '';
/*      */ 
/*      */     
/*  784 */     boolean bool = false;
/*  785 */     if (LA(1) == '.' && LA(2) == '.' && LA(3) == '.') {
/*  786 */       int j = mark();
/*  787 */       bool = true;
/*  788 */       this.inputState.guessing++;
/*      */       
/*      */       try {
/*  791 */         match("...");
/*      */       
/*      */       }
/*  794 */       catch (RecognitionException recognitionException) {
/*  795 */         bool = false;
/*      */       } 
/*  797 */       rewind(j);
/*  798 */       this.inputState.guessing--;
/*      */     } 
/*  800 */     if (bool) {
/*  801 */       match("...");
/*  802 */       if (this.inputState.guessing == 0) {
/*  803 */         c = '3';
/*      */       }
/*      */     }
/*  806 */     else if (LA(1) == '0' && (LA(2) == 'X' || LA(2) == 'x') && _tokenSet_4.member(LA(3))) {
/*  807 */       match('0');
/*      */       
/*  809 */       switch (LA(1)) {
/*      */         
/*      */         case 'x':
/*  812 */           match('x');
/*      */           break;
/*      */ 
/*      */         
/*      */         case 'X':
/*  817 */           match('X');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  822 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  827 */       byte b = 0;
/*      */       
/*      */       while (true) {
/*  830 */         if (LA(1) >= 'a' && LA(1) <= 'f') {
/*  831 */           matchRange('a', 'f');
/*      */         }
/*  833 */         else if (LA(1) >= 'A' && LA(1) <= 'F') {
/*  834 */           matchRange('A', 'F');
/*      */         }
/*  836 */         else if (LA(1) >= '0' && LA(1) <= '9') {
/*  837 */           mDigit(false);
/*      */         } else {
/*      */           
/*  840 */           if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */         
/*  843 */         b++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  849 */       while (_tokenSet_5.member(LA(1))) {
/*  850 */         mIntSuffix(false);
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  860 */       boolean bool1 = false;
/*  861 */       if (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_6.member(LA(2))) {
/*  862 */         int j = mark();
/*  863 */         bool1 = true;
/*  864 */         this.inputState.guessing++;
/*      */ 
/*      */         
/*      */         try {
/*  868 */           byte b = 0;
/*      */           
/*      */           while (true) {
/*  871 */             if (LA(1) >= '0' && LA(1) <= '9') {
/*  872 */               mDigit(false);
/*      */             } else {
/*      */               
/*  875 */               if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */             
/*  878 */             b++;
/*      */           } 
/*      */ 
/*      */           
/*  882 */           switch (LA(1)) {
/*      */             
/*      */             case '.':
/*  885 */               match('.');
/*      */               break;
/*      */ 
/*      */             
/*      */             case 'e':
/*  890 */               match('e');
/*      */               break;
/*      */ 
/*      */             
/*      */             case 'E':
/*  895 */               match('E');
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/*  900 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  906 */         } catch (RecognitionException recognitionException) {
/*  907 */           bool1 = false;
/*      */         } 
/*  909 */         rewind(j);
/*  910 */         this.inputState.guessing--;
/*      */       } 
/*  912 */       if (bool1) {
/*      */         
/*  914 */         byte b = 0;
/*      */         
/*      */         while (true) {
/*  917 */           if (LA(1) >= '0' && LA(1) <= '9') {
/*  918 */             mDigit(false);
/*      */           } else {
/*      */             
/*  921 */             if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/*  924 */           b++;
/*      */         } 
/*      */ 
/*      */         
/*  928 */         switch (LA(1)) {
/*      */           
/*      */           case '.':
/*  931 */             match('.');
/*      */ 
/*      */ 
/*      */             
/*  935 */             while (LA(1) >= '0' && LA(1) <= '9') {
/*  936 */               mDigit(false);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  945 */             if ((LA(1) == 'E' || LA(1) == 'e') && _tokenSet_7.member(LA(2))) {
/*  946 */               mExponent(false);
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 'E':
/*      */           case 'e':
/*  956 */             mExponent(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  961 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  968 */         while (_tokenSet_8.member(LA(1))) {
/*  969 */           mNumberSuffix(false);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  978 */       else if (LA(1) == '.') {
/*  979 */         match('.');
/*  980 */         if (this.inputState.guessing == 0) {
/*  981 */           c = 'b';
/*      */         }
/*      */         
/*  984 */         if (LA(1) >= '0' && LA(1) <= '9')
/*      */         {
/*  986 */           byte b = 0;
/*      */           
/*      */           while (true) {
/*  989 */             if (LA(1) >= '0' && LA(1) <= '9') {
/*  990 */               mDigit(false);
/*      */             } else {
/*      */               
/*  993 */               if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */             
/*  996 */             b++;
/*      */           } 
/*      */ 
/*      */           
/* 1000 */           if ((LA(1) == 'E' || LA(1) == 'e') && _tokenSet_7.member(LA(2))) {
/* 1001 */             mExponent(false);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1007 */           if (this.inputState.guessing == 0) {
/* 1008 */             c = '';
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 1013 */           while (_tokenSet_8.member(LA(1))) {
/* 1014 */             mNumberSuffix(false);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1028 */       else if (LA(1) == '0') {
/* 1029 */         match('0');
/*      */ 
/*      */ 
/*      */         
/* 1033 */         while (LA(1) >= '0' && LA(1) <= '7') {
/* 1034 */           matchRange('0', '7');
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1045 */         while (_tokenSet_8.member(LA(1))) {
/* 1046 */           mNumberSuffix(false);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1055 */       else if (LA(1) >= '1' && LA(1) <= '9') {
/* 1056 */         matchRange('1', '9');
/*      */ 
/*      */ 
/*      */         
/* 1060 */         while (LA(1) >= '0' && LA(1) <= '9') {
/* 1061 */           mDigit(false);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1072 */         while (_tokenSet_8.member(LA(1))) {
/* 1073 */           mNumberSuffix(false);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1083 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */     } 
/* 1086 */     if (paramBoolean && token == null && c != -1) {
/* 1087 */       token = makeToken(c);
/* 1088 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1090 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mExponent(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1094 */     Token token = null; int i = this.text.length();
/* 1095 */     char c = '';
/*      */ 
/*      */ 
/*      */     
/* 1099 */     switch (LA(1)) {
/*      */       
/*      */       case 'e':
/* 1102 */         match('e');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'E':
/* 1107 */         match('E');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1112 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1117 */     switch (LA(1)) {
/*      */       
/*      */       case '+':
/* 1120 */         match('+');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '-':
/* 1125 */         match('-'); break;
/*      */       case '0': case '1': case '2':
/*      */       case '3':
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/*      */         break;
/*      */       default:
/* 1136 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1141 */     byte b = 0;
/*      */     
/*      */     while (true) {
/* 1144 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 1145 */         mDigit(false);
/*      */       } else {
/*      */         
/* 1148 */         if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1151 */       b++;
/*      */     } 
/*      */     
/* 1154 */     if (paramBoolean && token == null && c != -1) {
/* 1155 */       token = makeToken(c);
/* 1156 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1158 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mIDMEAT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1162 */     Token token1 = null; int j = this.text.length();
/* 1163 */     int i = 170;
/*      */     
/* 1165 */     Token token2 = null;
/*      */     
/* 1167 */     mID(true);
/* 1168 */     token2 = this._returnToken;
/* 1169 */     if (this.inputState.guessing == 0)
/*      */     {
/*      */       
/* 1172 */       if (token2.getType() == 167) {
/* 1173 */         i = -1;
/*      */       } else {
/*      */         
/* 1176 */         i = token2.getType();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1181 */     if (paramBoolean && token1 == null && i != -1) {
/* 1182 */       token1 = makeToken(i);
/* 1183 */       token1.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/* 1185 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mID(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1189 */     Token token = null; int j = this.text.length();
/* 1190 */     int i = 42;
/*      */ 
/*      */ 
/*      */     
/* 1194 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1203 */         matchRange('a', 'z'); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */       case 'R':
/*      */       case 'S':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       case 'Z':
/* 1214 */         matchRange('A', 'Z');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '_':
/* 1219 */         match('_');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '$':
/* 1224 */         match('$');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1229 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1236 */       if (LA(1) >= 'a' && LA(1) <= 'z') {
/* 1237 */         matchRange('a', 'z'); continue;
/*      */       } 
/* 1239 */       if (LA(1) >= 'A' && LA(1) <= 'Z') {
/* 1240 */         matchRange('A', 'Z'); continue;
/*      */       } 
/* 1242 */       if (LA(1) == '_') {
/* 1243 */         match('_'); continue;
/*      */       } 
/* 1245 */       if (LA(1) == '$') {
/* 1246 */         match('$'); continue;
/*      */       } 
/* 1248 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 1249 */         matchRange('0', '9');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1257 */     i = testLiteralsTable(new String(this.text.getBuffer(), j, this.text.length() - j), i);
/* 1258 */     if (paramBoolean && token == null && i != -1) {
/* 1259 */       token = makeToken(i);
/* 1260 */       token.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/* 1262 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mWideCharLiteral(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1266 */     Token token = null; int i = this.text.length();
/* 1267 */     char c = '«';
/*      */ 
/*      */     
/* 1270 */     match('L');
/* 1271 */     mCharLiteral(false);
/* 1272 */     if (this.inputState.guessing == 0) {
/* 1273 */       c = 'c';
/*      */     }
/* 1275 */     if (paramBoolean && token == null && c != -1) {
/* 1276 */       token = makeToken(c);
/* 1277 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1279 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCharLiteral(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1283 */     Token token = null; int i = this.text.length();
/* 1284 */     byte b = 99;
/*      */ 
/*      */     
/* 1287 */     match('\'');
/*      */     
/* 1289 */     if (LA(1) == '\\' && LA(2) >= '\000' && LA(2) <= 'ÿ' && _tokenSet_9.member(LA(3))) {
/* 1290 */       mEscape(false);
/*      */     }
/* 1292 */     else if (_tokenSet_10.member(LA(1)) && LA(2) == '\'') {
/*      */       
/* 1294 */       match(_tokenSet_10);
/*      */     }
/*      */     else {
/*      */       
/* 1298 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1302 */     match('\'');
/* 1303 */     if (paramBoolean && token == null && b != -1) {
/* 1304 */       token = makeToken(b);
/* 1305 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1307 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mWideStringLiteral(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1311 */     Token token = null; int i = this.text.length();
/* 1312 */     char c = '¬';
/*      */ 
/*      */     
/* 1315 */     match('L');
/* 1316 */     mStringLiteral(false);
/* 1317 */     if (this.inputState.guessing == 0) {
/* 1318 */       c = 'd';
/*      */     }
/* 1320 */     if (paramBoolean && token == null && c != -1) {
/* 1321 */       token = makeToken(c);
/* 1322 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1324 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mStringLiteral(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1328 */     Token token = null; int i = this.text.length();
/* 1329 */     byte b = 100;
/*      */ 
/*      */     
/* 1332 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/* 1336 */       boolean bool = false;
/* 1337 */       if (LA(1) == '\\' && LA(2) >= '\000' && LA(2) <= 'ÿ' && LA(3) >= '\000' && LA(3) <= 'ÿ') {
/* 1338 */         int j = mark();
/* 1339 */         bool = true;
/* 1340 */         this.inputState.guessing++;
/*      */         
/*      */         try {
/* 1343 */           match('\\');
/*      */           
/* 1345 */           match(_tokenSet_11);
/*      */ 
/*      */         
/*      */         }
/* 1349 */         catch (RecognitionException recognitionException) {
/* 1350 */           bool = false;
/*      */         } 
/* 1352 */         rewind(j);
/* 1353 */         this.inputState.guessing--;
/*      */       } 
/* 1355 */       if (bool) {
/* 1356 */         mEscape(false); continue;
/*      */       } 
/* 1358 */       if ((LA(1) == '\n' || LA(1) == '\r' || LA(1) == '\\') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/*      */         
/* 1360 */         switch (LA(1)) {
/*      */           
/*      */           case '\r':
/* 1363 */             match('\r');
/* 1364 */             if (this.inputState.guessing == 0) {
/* 1365 */               newline();
/*      */             }
/*      */             continue;
/*      */ 
/*      */           
/*      */           case '\n':
/* 1371 */             match('\n');
/* 1372 */             if (this.inputState.guessing == 0)
/*      */             {
/* 1374 */               newline();
/*      */             }
/*      */             continue;
/*      */ 
/*      */ 
/*      */           
/*      */           case '\\':
/* 1381 */             match('\\');
/* 1382 */             match('\n');
/* 1383 */             if (this.inputState.guessing == 0)
/*      */             {
/* 1385 */               newline();
/*      */             }
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1392 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1397 */       if (_tokenSet_12.member(LA(1))) {
/*      */         
/* 1399 */         match(_tokenSet_12);
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1408 */     match('"');
/* 1409 */     if (paramBoolean && token == null && b != -1) {
/* 1410 */       token = makeToken(b);
/* 1411 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1413 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mVocabulary(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1417 */     Token token = null; int i = this.text.length();
/* 1418 */     char c = '';
/*      */ 
/*      */     
/* 1421 */     matchRange('\003', 'ÿ');
/* 1422 */     if (paramBoolean && token == null && c != -1) {
/* 1423 */       token = makeToken(c);
/* 1424 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1426 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1430 */     Token token = null; int i = this.text.length();
/* 1431 */     byte b = 45;
/*      */ 
/*      */     
/* 1434 */     match('=');
/* 1435 */     if (paramBoolean && token == null && b != -1) {
/* 1436 */       token = makeToken(b);
/* 1437 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1439 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOLON(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1443 */     Token token = null; int i = this.text.length();
/* 1444 */     byte b = 44;
/*      */ 
/*      */     
/* 1447 */     match(':');
/* 1448 */     if (paramBoolean && token == null && b != -1) {
/* 1449 */       token = makeToken(b);
/* 1450 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1452 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOMMA(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1456 */     Token token = null; int i = this.text.length();
/* 1457 */     byte b = 43;
/*      */ 
/*      */     
/* 1460 */     match(',');
/* 1461 */     if (paramBoolean && token == null && b != -1) {
/* 1462 */       token = makeToken(b);
/* 1463 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1465 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mQUESTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1469 */     Token token = null; int i = this.text.length();
/* 1470 */     byte b = 74;
/*      */ 
/*      */     
/* 1473 */     match('?');
/* 1474 */     if (paramBoolean && token == null && b != -1) {
/* 1475 */       token = makeToken(b);
/* 1476 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1478 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSEMI(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1482 */     Token token = null; int i = this.text.length();
/* 1483 */     byte b = 9;
/*      */ 
/*      */     
/* 1486 */     match(';');
/* 1487 */     if (paramBoolean && token == null && b != -1) {
/* 1488 */       token = makeToken(b);
/* 1489 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1491 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPTR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1495 */     Token token = null; int i = this.text.length();
/* 1496 */     byte b = 97;
/*      */ 
/*      */     
/* 1499 */     match("->");
/* 1500 */     if (paramBoolean && token == null && b != -1) {
/* 1501 */       token = makeToken(b);
/* 1502 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1504 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDOT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1508 */     Token token = null; int i = this.text.length();
/* 1509 */     byte b = 98;
/*      */ 
/*      */     
/* 1512 */     if (paramBoolean && token == null && b != -1) {
/* 1513 */       token = makeToken(b);
/* 1514 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1516 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mVARARGS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1520 */     Token token = null; int i = this.text.length();
/* 1521 */     byte b = 51;
/*      */ 
/*      */     
/* 1524 */     if (paramBoolean && token == null && b != -1) {
/* 1525 */       token = makeToken(b);
/* 1526 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1528 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1532 */     Token token = null; int i = this.text.length();
/* 1533 */     byte b = 47;
/*      */ 
/*      */     
/* 1536 */     match('(');
/* 1537 */     if (paramBoolean && token == null && b != -1) {
/* 1538 */       token = makeToken(b);
/* 1539 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1541 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1545 */     Token token = null; int i = this.text.length();
/* 1546 */     byte b = 48;
/*      */ 
/*      */     
/* 1549 */     match(')');
/* 1550 */     if (paramBoolean && token == null && b != -1) {
/* 1551 */       token = makeToken(b);
/* 1552 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1554 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLBRACKET(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1558 */     Token token = null; int i = this.text.length();
/* 1559 */     byte b = 49;
/*      */ 
/*      */     
/* 1562 */     match('[');
/* 1563 */     if (paramBoolean && token == null && b != -1) {
/* 1564 */       token = makeToken(b);
/* 1565 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1567 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRBRACKET(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1571 */     Token token = null; int i = this.text.length();
/* 1572 */     byte b = 50;
/*      */ 
/*      */     
/* 1575 */     match(']');
/* 1576 */     if (paramBoolean && token == null && b != -1) {
/* 1577 */       token = makeToken(b);
/* 1578 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1580 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLCURLY(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1584 */     Token token = null; int i = this.text.length();
/* 1585 */     byte b = 7;
/*      */ 
/*      */     
/* 1588 */     match('{');
/* 1589 */     if (paramBoolean && token == null && b != -1) {
/* 1590 */       token = makeToken(b);
/* 1591 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1593 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRCURLY(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1597 */     Token token = null; int i = this.text.length();
/* 1598 */     byte b = 8;
/*      */ 
/*      */     
/* 1601 */     match('}');
/* 1602 */     if (paramBoolean && token == null && b != -1) {
/* 1603 */       token = makeToken(b);
/* 1604 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1606 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mEQUAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1610 */     Token token = null; int i = this.text.length();
/* 1611 */     byte b = 80;
/*      */ 
/*      */     
/* 1614 */     match("==");
/* 1615 */     if (paramBoolean && token == null && b != -1) {
/* 1616 */       token = makeToken(b);
/* 1617 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1619 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mNOT_EQUAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1623 */     Token token = null; int i = this.text.length();
/* 1624 */     byte b = 81;
/*      */ 
/*      */     
/* 1627 */     match("!=");
/* 1628 */     if (paramBoolean && token == null && b != -1) {
/* 1629 */       token = makeToken(b);
/* 1630 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1632 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLTE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1636 */     Token token = null; int i = this.text.length();
/* 1637 */     byte b = 83;
/*      */ 
/*      */     
/* 1640 */     match("<=");
/* 1641 */     if (paramBoolean && token == null && b != -1) {
/* 1642 */       token = makeToken(b);
/* 1643 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1645 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1649 */     Token token = null; int i = this.text.length();
/* 1650 */     byte b = 82;
/*      */ 
/*      */     
/* 1653 */     match("<");
/* 1654 */     if (paramBoolean && token == null && b != -1) {
/* 1655 */       token = makeToken(b);
/* 1656 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1658 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mGTE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1662 */     Token token = null; int i = this.text.length();
/* 1663 */     byte b = 85;
/*      */ 
/*      */     
/* 1666 */     match(">=");
/* 1667 */     if (paramBoolean && token == null && b != -1) {
/* 1668 */       token = makeToken(b);
/* 1669 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1671 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mGT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1675 */     Token token = null; int i = this.text.length();
/* 1676 */     byte b = 84;
/*      */ 
/*      */     
/* 1679 */     match(">");
/* 1680 */     if (paramBoolean && token == null && b != -1) {
/* 1681 */       token = makeToken(b);
/* 1682 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1684 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDIV(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1688 */     Token token = null; int i = this.text.length();
/* 1689 */     byte b = 90;
/*      */ 
/*      */     
/* 1692 */     match('/');
/* 1693 */     if (paramBoolean && token == null && b != -1) {
/* 1694 */       token = makeToken(b);
/* 1695 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1697 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDIV_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1701 */     Token token = null; int i = this.text.length();
/* 1702 */     byte b = 64;
/*      */ 
/*      */     
/* 1705 */     match("/=");
/* 1706 */     if (paramBoolean && token == null && b != -1) {
/* 1707 */       token = makeToken(b);
/* 1708 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1710 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPLUS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1714 */     Token token = null; int i = this.text.length();
/* 1715 */     byte b = 88;
/*      */ 
/*      */     
/* 1718 */     match('+');
/* 1719 */     if (paramBoolean && token == null && b != -1) {
/* 1720 */       token = makeToken(b);
/* 1721 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1723 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPLUS_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1727 */     Token token = null; int i = this.text.length();
/* 1728 */     byte b = 65;
/*      */ 
/*      */     
/* 1731 */     match("+=");
/* 1732 */     if (paramBoolean && token == null && b != -1) {
/* 1733 */       token = makeToken(b);
/* 1734 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1736 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mINC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1740 */     Token token = null; int i = this.text.length();
/* 1741 */     byte b = 92;
/*      */ 
/*      */     
/* 1744 */     match("++");
/* 1745 */     if (paramBoolean && token == null && b != -1) {
/* 1746 */       token = makeToken(b);
/* 1747 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1749 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMINUS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1753 */     Token token = null; int i = this.text.length();
/* 1754 */     byte b = 89;
/*      */ 
/*      */     
/* 1757 */     match('-');
/* 1758 */     if (paramBoolean && token == null && b != -1) {
/* 1759 */       token = makeToken(b);
/* 1760 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1762 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMINUS_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1766 */     Token token = null; int i = this.text.length();
/* 1767 */     byte b = 66;
/*      */ 
/*      */     
/* 1770 */     match("-=");
/* 1771 */     if (paramBoolean && token == null && b != -1) {
/* 1772 */       token = makeToken(b);
/* 1773 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1775 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDEC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1779 */     Token token = null; int i = this.text.length();
/* 1780 */     byte b = 93;
/*      */ 
/*      */     
/* 1783 */     match("--");
/* 1784 */     if (paramBoolean && token == null && b != -1) {
/* 1785 */       token = makeToken(b);
/* 1786 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1788 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTAR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1792 */     Token token = null; int i = this.text.length();
/* 1793 */     byte b = 46;
/*      */ 
/*      */     
/* 1796 */     match('*');
/* 1797 */     if (paramBoolean && token == null && b != -1) {
/* 1798 */       token = makeToken(b);
/* 1799 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1801 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTAR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1805 */     Token token = null; int i = this.text.length();
/* 1806 */     byte b = 67;
/*      */ 
/*      */     
/* 1809 */     match("*=");
/* 1810 */     if (paramBoolean && token == null && b != -1) {
/* 1811 */       token = makeToken(b);
/* 1812 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1814 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMOD(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1818 */     Token token = null; int i = this.text.length();
/* 1819 */     byte b = 91;
/*      */ 
/*      */     
/* 1822 */     match('%');
/* 1823 */     if (paramBoolean && token == null && b != -1) {
/* 1824 */       token = makeToken(b);
/* 1825 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1827 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mMOD_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1831 */     Token token = null; int i = this.text.length();
/* 1832 */     byte b = 68;
/*      */ 
/*      */     
/* 1835 */     match("%=");
/* 1836 */     if (paramBoolean && token == null && b != -1) {
/* 1837 */       token = makeToken(b);
/* 1838 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1840 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRSHIFT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1844 */     Token token = null; int i = this.text.length();
/* 1845 */     byte b = 87;
/*      */ 
/*      */     
/* 1848 */     match(">>");
/* 1849 */     if (paramBoolean && token == null && b != -1) {
/* 1850 */       token = makeToken(b);
/* 1851 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1853 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRSHIFT_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1857 */     Token token = null; int i = this.text.length();
/* 1858 */     byte b = 69;
/*      */ 
/*      */     
/* 1861 */     match(">>=");
/* 1862 */     if (paramBoolean && token == null && b != -1) {
/* 1863 */       token = makeToken(b);
/* 1864 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1866 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLSHIFT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1870 */     Token token = null; int i = this.text.length();
/* 1871 */     byte b = 86;
/*      */ 
/*      */     
/* 1874 */     match("<<");
/* 1875 */     if (paramBoolean && token == null && b != -1) {
/* 1876 */       token = makeToken(b);
/* 1877 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1879 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLSHIFT_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1883 */     Token token = null; int i = this.text.length();
/* 1884 */     byte b = 70;
/*      */ 
/*      */     
/* 1887 */     match("<<=");
/* 1888 */     if (paramBoolean && token == null && b != -1) {
/* 1889 */       token = makeToken(b);
/* 1890 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1892 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLAND(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1896 */     Token token = null; int i = this.text.length();
/* 1897 */     byte b = 76;
/*      */ 
/*      */     
/* 1900 */     match("&&");
/* 1901 */     if (paramBoolean && token == null && b != -1) {
/* 1902 */       token = makeToken(b);
/* 1903 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1905 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLNOT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1909 */     Token token = null; int i = this.text.length();
/* 1910 */     byte b = 96;
/*      */ 
/*      */     
/* 1913 */     match('!');
/* 1914 */     if (paramBoolean && token == null && b != -1) {
/* 1915 */       token = makeToken(b);
/* 1916 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1918 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1922 */     Token token = null; int i = this.text.length();
/* 1923 */     byte b = 75;
/*      */ 
/*      */     
/* 1926 */     match("||");
/* 1927 */     if (paramBoolean && token == null && b != -1) {
/* 1928 */       token = makeToken(b);
/* 1929 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1931 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBAND(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1935 */     Token token = null; int i = this.text.length();
/* 1936 */     byte b = 79;
/*      */ 
/*      */     
/* 1939 */     match('&');
/* 1940 */     if (paramBoolean && token == null && b != -1) {
/* 1941 */       token = makeToken(b);
/* 1942 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1944 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBAND_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1948 */     Token token = null; int i = this.text.length();
/* 1949 */     byte b = 71;
/*      */ 
/*      */     
/* 1952 */     match("&=");
/* 1953 */     if (paramBoolean && token == null && b != -1) {
/* 1954 */       token = makeToken(b);
/* 1955 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1957 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBNOT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1961 */     Token token = null; int i = this.text.length();
/* 1962 */     byte b = 95;
/*      */ 
/*      */     
/* 1965 */     match('~');
/* 1966 */     if (paramBoolean && token == null && b != -1) {
/* 1967 */       token = makeToken(b);
/* 1968 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1970 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1974 */     Token token = null; int i = this.text.length();
/* 1975 */     byte b = 77;
/*      */ 
/*      */     
/* 1978 */     match('|');
/* 1979 */     if (paramBoolean && token == null && b != -1) {
/* 1980 */       token = makeToken(b);
/* 1981 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1983 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBOR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1987 */     Token token = null; int i = this.text.length();
/* 1988 */     byte b = 72;
/*      */ 
/*      */     
/* 1991 */     match("|=");
/* 1992 */     if (paramBoolean && token == null && b != -1) {
/* 1993 */       token = makeToken(b);
/* 1994 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1996 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBXOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2000 */     Token token = null; int i = this.text.length();
/* 2001 */     byte b = 78;
/*      */ 
/*      */     
/* 2004 */     match('^');
/* 2005 */     if (paramBoolean && token == null && b != -1) {
/* 2006 */       token = makeToken(b);
/* 2007 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2009 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBXOR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2013 */     Token token = null; int i = this.text.length();
/* 2014 */     byte b = 73;
/*      */ 
/*      */     
/* 2017 */     match("^=");
/* 2018 */     if (paramBoolean && token == null && b != -1) {
/* 2019 */       token = makeToken(b);
/* 2020 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2022 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mComment(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2026 */     Token token = null; int i = this.text.length();
/* 2027 */     short s = 143;
/*      */ 
/*      */     
/* 2030 */     match("/*");
/*      */ 
/*      */     
/*      */     while (true) {
/* 2034 */       if (LA(1) == '*' && LA(2) >= '\000' && LA(2) <= 'ÿ' && LA(3) >= '\000' && LA(3) <= 'ÿ' && LA(2) != '/') {
/* 2035 */         match('*'); continue;
/*      */       } 
/* 2037 */       if (LA(1) == '\r' && LA(2) == '\n' && LA(3) >= '\000' && LA(3) <= 'ÿ') {
/* 2038 */         match("\r\n");
/* 2039 */         if (this.inputState.guessing == 0)
/* 2040 */           deferredNewline(); 
/*      */         continue;
/*      */       } 
/* 2043 */       if ((LA(1) == '\n' || LA(1) == '\r') && LA(2) >= '\000' && LA(2) <= 'ÿ' && LA(3) >= '\000' && LA(3) <= 'ÿ') {
/*      */         
/* 2045 */         switch (LA(1)) {
/*      */           
/*      */           case '\r':
/* 2048 */             match('\r');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\n':
/* 2053 */             match('\n');
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2058 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */         
/* 2062 */         if (this.inputState.guessing == 0)
/* 2063 */           deferredNewline(); 
/*      */         continue;
/*      */       } 
/* 2066 */       if (_tokenSet_13.member(LA(1))) {
/*      */         
/* 2068 */         match(_tokenSet_13);
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 2077 */     match("*/");
/* 2078 */     if (this.inputState.guessing == 0) {
/* 2079 */       s = -1;
/*      */     }
/*      */     
/* 2082 */     if (paramBoolean && token == null && s != -1) {
/* 2083 */       token = makeToken(s);
/* 2084 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2086 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCPPComment(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2090 */     Token token = null; int i = this.text.length();
/* 2091 */     short s = 144;
/*      */ 
/*      */     
/* 2094 */     match("//");
/*      */ 
/*      */ 
/*      */     
/* 2098 */     while (_tokenSet_11.member(LA(1)))
/*      */     {
/* 2100 */       match(_tokenSet_11);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2109 */     if (this.inputState.guessing == 0)
/*      */     {
/* 2111 */       s = -1;
/*      */     }
/*      */     
/* 2114 */     if (paramBoolean && token == null && s != -1) {
/* 2115 */       token = makeToken(s);
/* 2116 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2118 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mNonWhitespace(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2122 */     Token token = null; int i = this.text.length();
/* 2123 */     char c = '';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2129 */     while (_tokenSet_14.member(LA(1)))
/*      */     {
/* 2131 */       match(_tokenSet_14);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2140 */     if (paramBoolean && token == null && c != -1) {
/* 2141 */       token = makeToken(c);
/* 2142 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2144 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPREPROC_DIRECTIVE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2148 */     Token token1 = null; int i = this.text.length();
/* 2149 */     short s = 146;
/*      */     
/* 2151 */     Token token2 = null;
/* 2152 */     Token token3 = null;
/* 2153 */     Token token4 = null;
/*      */     
/* 2155 */     match('#');
/*      */     
/* 2157 */     boolean bool = false;
/* 2158 */     if (_tokenSet_15.member(LA(1)) && _tokenSet_16.member(LA(2)) && _tokenSet_17.member(LA(3))) {
/* 2159 */       int j = mark();
/* 2160 */       bool = true;
/* 2161 */       this.inputState.guessing++;
/*      */       try {
/*      */         byte b;
/* 2164 */         switch (LA(1)) {
/*      */           
/*      */           case 'l':
/* 2167 */             match("line");
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\t':
/*      */           case '\f':
/*      */           case ' ':
/* 2174 */             b = 0;
/*      */             
/*      */             while (true) {
/* 2177 */               switch (LA(1)) {
/*      */                 
/*      */                 case ' ':
/* 2180 */                   match(' ');
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case '\t':
/* 2185 */                   match('\t');
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case '\f':
/* 2190 */                   match('\f');
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 default:
/* 2195 */                   if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */               } 
/*      */               
/* 2198 */               b++;
/*      */             } 
/*      */             
/* 2201 */             matchRange('0', '9');
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2211 */       } catch (RecognitionException recognitionException) {
/* 2212 */         bool = false;
/*      */       } 
/* 2214 */       rewind(j);
/* 2215 */       this.inputState.guessing--;
/*      */     } 
/* 2217 */     if (bool) {
/* 2218 */       mLineDirective(false);
/*      */     }
/* 2220 */     else if (_tokenSet_18.member(LA(1)) && _tokenSet_19.member(LA(2)) && _tokenSet_20.member(LA(3))) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2225 */       while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 2226 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2234 */       match("define");
/*      */ 
/*      */ 
/*      */       
/* 2238 */       while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 2239 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2247 */       mID(true);
/* 2248 */       token2 = this._returnToken;
/*      */ 
/*      */ 
/*      */       
/* 2252 */       while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2253 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2262 */       if (_tokenSet_2.member(LA(1)) && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2263 */         mDefineExpr(true);
/* 2264 */         token3 = this._returnToken;
/*      */       }
/* 2266 */       else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */         
/* 2269 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */       
/* 2273 */       mNonWhitespace(true);
/* 2274 */       token4 = this._returnToken;
/*      */       
/* 2276 */       if (LA(1) == '\r' && LA(2) == '\n') {
/* 2277 */         match("\r\n");
/*      */       }
/* 2279 */       else if (LA(1) == '\r') {
/* 2280 */         match("\r");
/*      */       }
/* 2282 */       else if (LA(1) == '\n') {
/* 2283 */         match("\n");
/*      */       } else {
/*      */         
/* 2286 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2291 */       if (this.inputState.guessing == 0)
/*      */       {
/* 2293 */         if (token3 != null) {
/*      */           
/* 2295 */           addDefine(token2.getText(), token3.getText());
/*      */         } else {
/* 2297 */           setPreprocessingDirective("#define " + token2.getText() + " " + token4.getText());
/*      */         } 
/* 2299 */         deferredNewline();
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2307 */       while (_tokenSet_11.member(LA(1))) {
/* 2308 */         matchNot('\n');
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2316 */       if (this.inputState.guessing == 0) {
/* 2317 */         setPreprocessingDirective(getText());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 2322 */     if (this.inputState.guessing == 0)
/*      */     {
/* 2324 */       s = -1;
/*      */     }
/*      */     
/* 2327 */     if (paramBoolean && token1 == null && s != -1) {
/* 2328 */       token1 = makeToken(s);
/* 2329 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2331 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mLineDirective(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2335 */     Token token1 = null; int i = this.text.length();
/* 2336 */     char c = '';
/*      */     
/* 2338 */     Token token2 = null;
/* 2339 */     Token token3 = null;
/* 2340 */     Token token4 = null;
/*      */     
/* 2342 */     boolean bool = this.countingTokens;
/* 2343 */     this.countingTokens = false;
/*      */ 
/*      */     
/* 2346 */     if (this.inputState.guessing == 0) {
/*      */       
/* 2348 */       this.lineObject = new LineObject();
/* 2349 */       this.deferredLineCount = 0;
/*      */     } 
/*      */ 
/*      */     
/* 2353 */     switch (LA(1)) {
/*      */       
/*      */       case 'l':
/* 2356 */         match("line");
/*      */         break;
/*      */       
/*      */       case '\t':
/*      */       case '\f':
/*      */       case ' ':
/*      */         break;
/*      */       
/*      */       default:
/* 2365 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2370 */     byte b = 0;
/*      */     
/*      */     while (true) {
/* 2373 */       if (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 2374 */         mSpace(false);
/*      */       } else {
/*      */         
/* 2377 */         if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 2380 */       b++;
/*      */     } 
/*      */     
/* 2383 */     mNumber(true);
/* 2384 */     token2 = this._returnToken;
/* 2385 */     if (this.inputState.guessing == 0)
/*      */     {
/* 2387 */       this.lineObject.setLine(Integer.parseInt(token2.getText()));
/*      */     }
/*      */ 
/*      */     
/* 2391 */     b = 0;
/*      */     
/*      */     while (true) {
/* 2394 */       if ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2395 */         mSpace(false);
/*      */       } else {
/*      */         
/* 2398 */         if (b >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 2401 */       b++;
/*      */     } 
/*      */ 
/*      */     
/* 2405 */     if (LA(1) == '"' && LA(2) >= '\000' && LA(2) <= 'ÿ' && LA(3) >= '\000' && LA(3) <= 'ÿ') {
/* 2406 */       mStringLiteral(true);
/* 2407 */       token3 = this._returnToken;
/* 2408 */       if (this.inputState.guessing == 0) {
/*      */         try {
/* 2410 */           String str = token3.getText().substring(1, token3.getText().length() - 1);
/*      */           
/* 2412 */           this.lineObject.setSource(str);
/*      */         }
/* 2414 */         catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
/*      */       
/*      */       }
/*      */     }
/* 2418 */     else if (_tokenSet_1.member(LA(1)) && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2419 */       mID(true);
/* 2420 */       token4 = this._returnToken;
/* 2421 */       if (this.inputState.guessing == 0) {
/* 2422 */         this.lineObject.setSource(token4.getText());
/*      */       }
/*      */     }
/* 2425 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 2428 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2435 */     while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2436 */       mSpace(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2445 */     if (LA(1) == '1' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2446 */       match("1");
/* 2447 */       if (this.inputState.guessing == 0) {
/* 2448 */         this.lineObject.setEnteringFile(true);
/*      */       }
/*      */     }
/* 2451 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 2454 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2461 */     while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2462 */       mSpace(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2471 */     if (LA(1) == '2' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2472 */       match("2");
/* 2473 */       if (this.inputState.guessing == 0) {
/* 2474 */         this.lineObject.setReturningToFile(true);
/*      */       }
/*      */     }
/* 2477 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 2480 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2487 */     while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2488 */       mSpace(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2497 */     if (LA(1) == '3' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2498 */       match("3");
/* 2499 */       if (this.inputState.guessing == 0) {
/* 2500 */         this.lineObject.setSystemHeader(true);
/*      */       }
/*      */     }
/* 2503 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 2506 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2513 */     while ((LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2514 */       mSpace(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2523 */     if (LA(1) == '4' && LA(2) >= '\000' && LA(2) <= 'ÿ') {
/* 2524 */       match("4");
/* 2525 */       if (this.inputState.guessing == 0) {
/* 2526 */         this.lineObject.setTreatAsC(true);
/*      */       }
/*      */     }
/* 2529 */     else if (LA(1) < '\000' || LA(1) > 'ÿ') {
/*      */ 
/*      */       
/* 2532 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2539 */     while (_tokenSet_14.member(LA(1)))
/*      */     {
/* 2541 */       match(_tokenSet_14);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2551 */     if (LA(1) == '\r' && LA(2) == '\n') {
/* 2552 */       match("\r\n");
/*      */     }
/* 2554 */     else if (LA(1) == '\r') {
/* 2555 */       match("\r");
/*      */     }
/* 2557 */     else if (LA(1) == '\n') {
/* 2558 */       match("\n");
/*      */     } else {
/*      */       
/* 2561 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2565 */     if (this.inputState.guessing == 0) {
/*      */       
/* 2567 */       this.preprocessorInfoChannel.addLineForTokenNumber(new LineObject(this.lineObject), new Integer(this.tokenNumber));
/* 2568 */       this.countingTokens = bool;
/*      */     } 
/*      */     
/* 2571 */     if (paramBoolean && token1 == null && c != -1) {
/* 2572 */       token1 = makeToken(c);
/* 2573 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2575 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mSpace(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2579 */     Token token = null; int i = this.text.length();
/* 2580 */     char c = '';
/*      */ 
/*      */ 
/*      */     
/* 2584 */     switch (LA(1)) {
/*      */       
/*      */       case ' ':
/* 2587 */         match(' ');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\t':
/* 2592 */         match('\t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\f':
/* 2597 */         match('\f');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2602 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2606 */     if (paramBoolean && token == null && c != -1) {
/* 2607 */       token = makeToken(c);
/* 2608 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2610 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDefineExpr(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2614 */     Token token = null; int i = this.text.length();
/* 2615 */     char c = '';
/*      */ 
/*      */     
/* 2618 */     switch (LA(1)) {
/*      */ 
/*      */ 
/*      */       
/*      */       case '(':
/* 2623 */         mLPAREN(false);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2628 */         while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 2629 */           mSpace(false);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2638 */         mDefineExpr2(false);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2643 */         while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 2644 */           mSpace(false);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2653 */         mRPAREN(false); break;
/*      */       case '.': case '0': case '1':
/*      */       case '2':
/*      */       case '3':
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 2663 */         mDefineExpr2(false);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 2669 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 2672 */     if (paramBoolean && token == null && c != -1) {
/* 2673 */       token = makeToken(c);
/* 2674 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2676 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mDefineExpr2(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2680 */     Token token = null; int i = this.text.length();
/* 2681 */     char c = '';
/*      */ 
/*      */ 
/*      */     
/* 2685 */     mNumber(false);
/*      */ 
/*      */     
/* 2688 */     if (_tokenSet_21.member(LA(1)) && _tokenSet_22.member(LA(2))) {
/*      */ 
/*      */ 
/*      */       
/* 2692 */       while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 2693 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2702 */       switch (LA(1)) {
/*      */         
/*      */         case '<':
/* 2705 */           mLSHIFT(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '>':
/* 2710 */           mRSHIFT(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '+':
/* 2715 */           mPLUS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '-':
/* 2720 */           mMINUS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '*':
/* 2725 */           mSTAR(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '/':
/* 2730 */           mDIV(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '%':
/* 2735 */           mMOD(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2740 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2747 */       while (LA(1) == '\t' || LA(1) == '\f' || LA(1) == ' ') {
/* 2748 */         mSpace(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2757 */       mDefineExpr(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2764 */     if (paramBoolean && token == null && c != -1) {
/* 2765 */       token = makeToken(c);
/* 2766 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2768 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mBadStringLiteral(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2772 */     Token token = null; int i = this.text.length();
/* 2773 */     char c = '';
/*      */ 
/*      */     
/* 2776 */     if (paramBoolean && token == null && c != -1) {
/* 2777 */       token = makeToken(c);
/* 2778 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2780 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongSuffix(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2784 */     Token token = null; int i = this.text.length();
/* 2785 */     char c = '';
/*      */ 
/*      */     
/* 2788 */     switch (LA(1)) {
/*      */       
/*      */       case 'l':
/* 2791 */         match('l');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'L':
/* 2796 */         match('L');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2801 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 2804 */     if (paramBoolean && token == null && c != -1) {
/* 2805 */       token = makeToken(c);
/* 2806 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2808 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mUnsignedSuffix(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2812 */     Token token = null; int i = this.text.length();
/* 2813 */     char c = '';
/*      */ 
/*      */     
/* 2816 */     switch (LA(1)) {
/*      */       
/*      */       case 'u':
/* 2819 */         match('u');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'U':
/* 2824 */         match('U');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2829 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 2832 */     if (paramBoolean && token == null && c != -1) {
/* 2833 */       token = makeToken(c);
/* 2834 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2836 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mFloatSuffix(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2840 */     Token token = null; int i = this.text.length();
/* 2841 */     char c = '';
/*      */ 
/*      */     
/* 2844 */     switch (LA(1)) {
/*      */       
/*      */       case 'f':
/* 2847 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'F':
/* 2852 */         match('F');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2857 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 2860 */     if (paramBoolean && token == null && c != -1) {
/* 2861 */       token = makeToken(c);
/* 2862 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2864 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDoubleDoubleConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2868 */     Token token = null; int i = this.text.length();
/* 2869 */     byte b = 111;
/*      */ 
/*      */     
/* 2872 */     if (paramBoolean && token == null && b != -1) {
/* 2873 */       token = makeToken(b);
/* 2874 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2876 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mFloatDoubleConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2880 */     Token token = null; int i = this.text.length();
/* 2881 */     byte b = 110;
/*      */ 
/*      */     
/* 2884 */     if (paramBoolean && token == null && b != -1) {
/* 2885 */       token = makeToken(b);
/* 2886 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2888 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongDoubleConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2892 */     Token token = null; int i = this.text.length();
/* 2893 */     byte b = 112;
/*      */ 
/*      */     
/* 2896 */     if (paramBoolean && token == null && b != -1) {
/* 2897 */       token = makeToken(b);
/* 2898 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2900 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mIntOctalConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2904 */     Token token = null; int i = this.text.length();
/* 2905 */     byte b = 101;
/*      */ 
/*      */     
/* 2908 */     if (paramBoolean && token == null && b != -1) {
/* 2909 */       token = makeToken(b);
/* 2910 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2912 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongOctalConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2916 */     Token token = null; int i = this.text.length();
/* 2917 */     byte b = 102;
/*      */ 
/*      */     
/* 2920 */     if (paramBoolean && token == null && b != -1) {
/* 2921 */       token = makeToken(b);
/* 2922 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2924 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mUnsignedOctalConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2928 */     Token token = null; int i = this.text.length();
/* 2929 */     byte b = 103;
/*      */ 
/*      */     
/* 2932 */     if (paramBoolean && token == null && b != -1) {
/* 2933 */       token = makeToken(b);
/* 2934 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2936 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mIntIntConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2940 */     Token token = null; int i = this.text.length();
/* 2941 */     byte b = 104;
/*      */ 
/*      */     
/* 2944 */     if (paramBoolean && token == null && b != -1) {
/* 2945 */       token = makeToken(b);
/* 2946 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2948 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongIntConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2952 */     Token token = null; int i = this.text.length();
/* 2953 */     byte b = 105;
/*      */ 
/*      */     
/* 2956 */     if (paramBoolean && token == null && b != -1) {
/* 2957 */       token = makeToken(b);
/* 2958 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2960 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mUnsignedIntConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2964 */     Token token = null; int i = this.text.length();
/* 2965 */     byte b = 106;
/*      */ 
/*      */     
/* 2968 */     if (paramBoolean && token == null && b != -1) {
/* 2969 */       token = makeToken(b);
/* 2970 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2972 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mIntHexConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2976 */     Token token = null; int i = this.text.length();
/* 2977 */     byte b = 107;
/*      */ 
/*      */     
/* 2980 */     if (paramBoolean && token == null && b != -1) {
/* 2981 */       token = makeToken(b);
/* 2982 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2984 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mLongHexConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2988 */     Token token = null; int i = this.text.length();
/* 2989 */     byte b = 108;
/*      */ 
/*      */     
/* 2992 */     if (paramBoolean && token == null && b != -1) {
/* 2993 */       token = makeToken(b);
/* 2994 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2996 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mUnsignedHexConst(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 3000 */     Token token = null; int i = this.text.length();
/* 3001 */     byte b = 109;
/*      */ 
/*      */     
/* 3004 */     if (paramBoolean && token == null && b != -1) {
/* 3005 */       token = makeToken(b);
/* 3006 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 3008 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 3013 */     return new long[] { 288019269919178752L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3016 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 3018 */     return new long[] { 68719476736L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3021 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 3023 */     return new long[] { 288020369430806528L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3026 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 3028 */     long[] arrayOfLong = new long[8];
/* 3029 */     arrayOfLong[0] = -71776119061217281L;
/* 3030 */     arrayOfLong[1] = -72057594037927937L;
/* 3031 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 3032 */      return arrayOfLong;
/*      */   }
/* 3034 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 3036 */     return new long[] { 287948901175001088L, 541165879422L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3039 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 3041 */     return new long[] { 0L, 9031388512654848L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3044 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 3046 */     return new long[] { 288019269919178752L, 137438953504L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3049 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 3051 */     return new long[] { 287992881640112128L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3054 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 3056 */     return new long[] { 0L, 9031663390561856L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3059 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 3061 */     return new long[] { 287949450930814976L, 541165879422L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3064 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 3066 */     long[] arrayOfLong = new long[8];
/* 3067 */     arrayOfLong[0] = -549755813889L;
/* 3068 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 3069 */      return arrayOfLong;
/*      */   }
/* 3071 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 3073 */     long[] arrayOfLong = new long[8];
/* 3074 */     arrayOfLong[0] = -1025L;
/* 3075 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 3076 */      return arrayOfLong;
/*      */   }
/* 3078 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 3080 */     long[] arrayOfLong = new long[8];
/* 3081 */     arrayOfLong[0] = -17179878401L;
/* 3082 */     arrayOfLong[1] = -268435457L;
/* 3083 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 3084 */      return arrayOfLong;
/*      */   }
/* 3086 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 3088 */     long[] arrayOfLong = new long[8];
/* 3089 */     arrayOfLong[0] = -4398046520321L;
/* 3090 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 3091 */      return arrayOfLong;
/*      */   }
/* 3093 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 3095 */     long[] arrayOfLong = new long[8];
/* 3096 */     arrayOfLong[0] = -9217L;
/* 3097 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 3098 */      return arrayOfLong;
/*      */   }
/* 3100 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 3102 */     return new long[] { 4294971904L, 17592186044416L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3105 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 3107 */     return new long[] { 288019274214150656L, 2199023255552L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3110 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 3112 */     return new long[] { 288019274214150656L, 81159763628398176L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3115 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 3117 */     return new long[] { 4294971904L, 68719476736L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3120 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 3122 */     return new long[] { 4294971904L, 206158430208L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3125 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 3127 */     return new long[] { 4294971904L, 481036337152L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3130 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 3132 */     return new long[] { 5764796780768137728L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3135 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 3137 */     return new long[] { 6052817150198944256L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 3140 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/cgram/GnuCLexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */