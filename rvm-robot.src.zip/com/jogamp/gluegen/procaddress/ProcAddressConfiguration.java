/*     */ package com.jogamp.gluegen.procaddress;
/*     */ 
/*     */ import com.jogamp.gluegen.JavaConfiguration;
/*     */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.text.FieldPosition;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProcAddressConfiguration
/*     */   extends JavaConfiguration
/*     */ {
/*     */   private boolean emitProcAddressTable = false;
/*     */   private boolean forceProcAddressGen4All = false;
/*     */   private String tableClassPackage;
/*  57 */   private String tableClassName = "ProcAddressTable";
/*     */   private String getProcAddressTableExpr;
/*  59 */   private String localProcAddressCallingConvention4All = null;
/*     */   
/*     */   private ConvNode procAddressNameConverter;
/*  62 */   private final Set<String> skipProcAddressGen = new HashSet<>();
/*  63 */   private final List<String> forceProcAddressGen = new ArrayList<>();
/*  64 */   private final Set<String> forceProcAddressGenSet = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private final Map<String, String> localProcAddressCallingConventionMap = new HashMap<>();
/*     */ 
/*     */   
/*     */   protected void dispatch(String paramString1, StringTokenizer paramStringTokenizer, File paramFile, String paramString2, int paramInt) throws IOException {
/*  73 */     if (paramString1.equalsIgnoreCase("EmitProcAddressTable")) {
/*  74 */       this.emitProcAddressTable = readBoolean("EmitProcAddressTable", paramStringTokenizer, paramString2, paramInt).booleanValue();
/*  75 */     } else if (paramString1.equalsIgnoreCase("ProcAddressTablePackage")) {
/*  76 */       this.tableClassPackage = readString("ProcAddressTablePackage", paramStringTokenizer, paramString2, paramInt);
/*  77 */     } else if (paramString1.equalsIgnoreCase("ProcAddressTableClassName")) {
/*  78 */       this.tableClassName = readString("ProcAddressTableClassName", paramStringTokenizer, paramString2, paramInt);
/*  79 */     } else if (paramString1.equalsIgnoreCase("SkipProcAddressGen")) {
/*  80 */       String str = readString("SkipProcAddressGen", paramStringTokenizer, paramString2, paramInt);
/*  81 */       this.skipProcAddressGen.add(str);
/*  82 */     } else if (paramString1.equalsIgnoreCase("ForceProcAddressGen")) {
/*  83 */       String str = readString("ForceProcAddressGen", paramStringTokenizer, paramString2, paramInt);
/*  84 */       if (str.equals("__ALL__")) {
/*  85 */         this.forceProcAddressGen4All = true;
/*     */       } else {
/*  87 */         addForceProcAddressGen(str);
/*     */       } 
/*  89 */     } else if (paramString1.equalsIgnoreCase("GetProcAddressTableExpr")) {
/*  90 */       setProcAddressTableExpr(readGetProcAddressTableExpr(paramStringTokenizer, paramString2, paramInt));
/*  91 */     } else if (paramString1.equalsIgnoreCase("ProcAddressNameExpr")) {
/*  92 */       readProcAddressNameExpr(paramStringTokenizer, paramString2, paramInt);
/*  93 */     } else if (paramString1.equalsIgnoreCase("LocalProcAddressCallingConvention")) {
/*  94 */       readLocalProcAddressCallingConvention(paramStringTokenizer, paramString2, paramInt);
/*     */     } else {
/*  96 */       super.dispatch(paramString1, paramStringTokenizer, paramFile, paramString2, paramInt);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String readGetProcAddressTableExpr(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*     */     try {
/* 102 */       String str = paramStringTokenizer.nextToken("\n\r\f");
/* 103 */       return str.trim();
/* 104 */     } catch (NoSuchElementException noSuchElementException) {
/* 105 */       throw new RuntimeException("Error parsing \"GetProcAddressTableExpr\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProcAddressNameExpr(String paramString) {
/* 113 */     ArrayList<String> arrayList = new ArrayList();
/* 114 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString);
/* 115 */     while (stringTokenizer.hasMoreTokens()) {
/* 116 */       String str = stringTokenizer.nextToken();
/* 117 */       StringTokenizer stringTokenizer1 = new StringTokenizer(str, "$()", true);
/* 118 */       while (stringTokenizer1.hasMoreTokens()) {
/* 119 */         arrayList.add(stringTokenizer1.nextToken());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 124 */     this.procAddressNameConverter = makeConverter(arrayList.iterator());
/* 125 */     if (this.procAddressNameConverter == null) {
/* 126 */       throw new NoSuchElementException("Error creating converter from string");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void readProcAddressNameExpr(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*     */     try {
/* 132 */       String str = paramStringTokenizer.nextToken("\n\r\f");
/* 133 */       str = str.trim();
/* 134 */       setProcAddressNameExpr(str);
/* 135 */     } catch (NoSuchElementException noSuchElementException) {
/* 136 */       throw new RuntimeException("Error parsing \"ProcAddressNameExpr\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void readLocalProcAddressCallingConvention(StringTokenizer paramStringTokenizer, String paramString, int paramInt) throws IOException {
/*     */     try {
/* 143 */       String str1 = paramStringTokenizer.nextToken();
/* 144 */       String str2 = paramStringTokenizer.nextToken();
/* 145 */       if (str1.equals("__ALL__")) {
/* 146 */         this.localProcAddressCallingConvention4All = str2;
/*     */       } else {
/* 148 */         this.localProcAddressCallingConventionMap.put(str1, str2);
/*     */       } 
/* 150 */     } catch (NoSuchElementException noSuchElementException) {
/* 151 */       throw new RuntimeException("Error parsing \"LocalProcAddressCallingConvention\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static ConvNode makeConverter(Iterator<String> paramIterator) {
/* 157 */     ArrayList<CaseNode> arrayList = new ArrayList();
/*     */     
/* 159 */     while (paramIterator.hasNext()) {
/* 160 */       String str = paramIterator.next();
/* 161 */       if (str.equals("$")) {
/* 162 */         String str1 = paramIterator.next();
/* 163 */         String str2 = paramIterator.next();
/* 164 */         if (!str2.equals("(")) {
/* 165 */           throw new NoSuchElementException("Expected \"(\"");
/*     */         }
/* 167 */         boolean bool = false;
/* 168 */         if (str1.equalsIgnoreCase("UPPERCASE")) {
/* 169 */           bool = true;
/* 170 */         } else if (!str1.equalsIgnoreCase("LOWERCASE")) {
/* 171 */           throw new NoSuchElementException("Unknown ProcAddressNameExpr command \"" + str1 + "\"");
/*     */         } 
/* 173 */         arrayList.add(new CaseNode(bool, makeConverter(paramIterator))); continue;
/* 174 */       }  if (str.equals(")"))
/*     */         continue; 
/* 176 */       if (str.indexOf('{') >= 0) {
/* 177 */         arrayList.add(new FormatNode(str)); continue;
/*     */       } 
/* 179 */       arrayList.add(new ConstStringNode(str));
/*     */     } 
/*     */     
/* 182 */     if (arrayList.isEmpty())
/* 183 */       return null; 
/* 184 */     if (arrayList.size() == 1) {
/* 185 */       return arrayList.get(0);
/*     */     }
/* 187 */     return new ConcatNode((List)arrayList);
/*     */   }
/*     */ 
/*     */   
/*     */   static abstract class ConvNode
/*     */   {
/*     */     abstract String convert(String param1String);
/*     */   }
/*     */   
/*     */   static class FormatNode
/*     */     extends ConvNode
/*     */   {
/*     */     private final MessageFormat msgFmt;
/*     */     
/*     */     FormatNode(String param1String) {
/* 202 */       this.msgFmt = new MessageFormat(param1String);
/*     */     }
/*     */ 
/*     */     
/*     */     String convert(String param1String) {
/* 207 */       StringBuffer stringBuffer = new StringBuffer();
/* 208 */       this.msgFmt.format(new Object[] { param1String }, stringBuffer, (FieldPosition)null);
/* 209 */       return stringBuffer.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   static class ConstStringNode
/*     */     extends ConvNode {
/*     */     private final String str;
/*     */     
/*     */     ConstStringNode(String param1String) {
/* 218 */       this.str = param1String;
/*     */     }
/*     */ 
/*     */     
/*     */     String convert(String param1String) {
/* 223 */       return this.str;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ConcatNode
/*     */     extends ConvNode {
/*     */     private final List<ProcAddressConfiguration.ConvNode> children;
/*     */     
/*     */     ConcatNode(List<ProcAddressConfiguration.ConvNode> param1List) {
/* 232 */       this.children = param1List;
/*     */     }
/*     */ 
/*     */     
/*     */     String convert(String param1String) {
/* 237 */       StringBuilder stringBuilder = new StringBuilder();
/* 238 */       for (ProcAddressConfiguration.ConvNode convNode : this.children) {
/* 239 */         stringBuilder.append(convNode.convert(param1String));
/*     */       }
/* 241 */       return stringBuilder.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   static class CaseNode
/*     */     extends ConvNode {
/*     */     private final boolean upperCase;
/*     */     private final ProcAddressConfiguration.ConvNode child;
/*     */     
/*     */     CaseNode(boolean param1Boolean, ProcAddressConfiguration.ConvNode param1ConvNode) {
/* 251 */       this.upperCase = param1Boolean;
/* 252 */       this.child = param1ConvNode;
/*     */     }
/*     */ 
/*     */     
/*     */     public String convert(String param1String) {
/* 257 */       if (this.upperCase) {
/* 258 */         return this.child.convert(param1String).toUpperCase();
/*     */       }
/* 260 */       return this.child.convert(param1String).toLowerCase();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean emitProcAddressTable() {
/* 266 */     return this.emitProcAddressTable;
/*     */   }
/*     */   
/*     */   public String tableClassPackage() {
/* 270 */     return this.tableClassPackage;
/*     */   }
/*     */   
/*     */   public String tableClassName() {
/* 274 */     return this.tableClassName;
/*     */   }
/*     */   
/*     */   public boolean skipProcAddressGen(FunctionSymbol paramFunctionSymbol) {
/* 278 */     if (this.skipProcAddressGen.contains(paramFunctionSymbol.getName()) || 
/* 279 */       oneInSet(this.skipProcAddressGen, paramFunctionSymbol.getAliasedNames())) {
/*     */ 
/*     */       
/* 282 */       this.LOG.log(Level.INFO, paramFunctionSymbol.getASTLocusTag(), "Skip ProcAddress: {0}", paramFunctionSymbol);
/* 283 */       return true;
/*     */     } 
/* 285 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isForceProcAddressGen4All() {
/* 289 */     return this.forceProcAddressGen4All;
/*     */   }
/*     */   
/*     */   public List<String> getForceProcAddressGen() {
/* 293 */     return this.forceProcAddressGen;
/*     */   }
/*     */   
/*     */   public String getProcAddressTableExpr() {
/* 297 */     if (this.getProcAddressTableExpr == null) {
/* 298 */       throw new RuntimeException("GetProcAddressTableExpr was not defined in .cfg file");
/*     */     }
/* 300 */     return this.getProcAddressTableExpr;
/*     */   }
/*     */   protected void setProcAddressTableExpr(String paramString) {
/* 303 */     this.getProcAddressTableExpr = paramString;
/*     */   }
/*     */   
/*     */   public String convertToFunctionPointerName(String paramString) {
/* 307 */     if (this.procAddressNameConverter == null) {
/* 308 */       throw new RuntimeException("ProcAddressNameExpr was not defined in .cfg file");
/*     */     }
/* 310 */     return this.procAddressNameConverter.convert(paramString);
/*     */   }
/*     */   
/*     */   public boolean forceProcAddressGen(FunctionSymbol paramFunctionSymbol) {
/* 314 */     if (this.forceProcAddressGen4All) {
/* 315 */       if (!forceProcAddressGen4AllOnce) {
/* 316 */         forceProcAddressGen4AllOnce = true;
/* 317 */         this.LOG.log(Level.INFO, paramFunctionSymbol.getASTLocusTag(), "Force ALL ProcAddress");
/*     */       } 
/* 319 */       return true;
/*     */     } 
/*     */     
/* 322 */     if (this.forceProcAddressGenSet.contains(paramFunctionSymbol.getName()) || 
/* 323 */       oneInSet(this.forceProcAddressGenSet, paramFunctionSymbol.getAliasedNames())) {
/*     */ 
/*     */       
/* 326 */       this.LOG.log(Level.INFO, paramFunctionSymbol.getASTLocusTag(), "Force ProcAddress: {0}", paramFunctionSymbol);
/* 327 */       return true;
/*     */     } 
/* 329 */     return false;
/*     */   }
/*     */   private static boolean forceProcAddressGen4AllOnce = false;
/*     */   
/*     */   public void addForceProcAddressGen(String paramString) {
/* 334 */     this.forceProcAddressGen.add(paramString);
/* 335 */     this.forceProcAddressGenSet.add(paramString);
/*     */   }
/*     */   
/*     */   public void addLocalProcAddressCallingConvention(String paramString1, String paramString2) {
/* 339 */     this.localProcAddressCallingConventionMap.put(paramString1, paramString2);
/*     */   }
/*     */   
/*     */   public String getLocalProcAddressCallingConvention(FunctionSymbol paramFunctionSymbol) {
/* 343 */     if (isLocalProcAddressCallingConvention4All()) {
/* 344 */       return getLocalProcAddressCallingConvention4All();
/*     */     }
/* 346 */     String str = this.localProcAddressCallingConventionMap.get(paramFunctionSymbol.getName());
/* 347 */     if (null != str) {
/* 348 */       return str;
/*     */     }
/* 350 */     return (String)oneInMap(this.localProcAddressCallingConventionMap, paramFunctionSymbol.getAliasedNames());
/*     */   }
/*     */   
/*     */   public boolean isLocalProcAddressCallingConvention4All() {
/* 354 */     return (this.localProcAddressCallingConvention4All != null);
/*     */   }
/*     */   
/*     */   public String getLocalProcAddressCallingConvention4All() {
/* 358 */     return this.localProcAddressCallingConvention4All;
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/procaddress/ProcAddressConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */