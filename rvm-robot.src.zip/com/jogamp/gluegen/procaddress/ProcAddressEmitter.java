/*     */ package com.jogamp.gluegen.procaddress;
/*     */ 
/*     */ import com.jogamp.gluegen.CMethodBindingEmitter;
/*     */ import com.jogamp.gluegen.CodeGenUtils;
/*     */ import com.jogamp.gluegen.FunctionEmitter;
/*     */ import com.jogamp.gluegen.JavaCodeUnit;
/*     */ import com.jogamp.gluegen.JavaConfiguration;
/*     */ import com.jogamp.gluegen.JavaEmitter;
/*     */ import com.jogamp.gluegen.JavaMethodBindingEmitter;
/*     */ import com.jogamp.gluegen.cgram.types.AliasedSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.FunctionSymbol;
/*     */ import com.jogamp.gluegen.cgram.types.Type;
/*     */ import com.jogamp.gluegen.cgram.types.TypeDictionary;
/*     */ import com.jogamp.gluegen.runtime.FunctionAddressResolver;
/*     */ import com.jogamp.gluegen.runtime.ProcAddressTable;
/*     */ import java.io.File;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProcAddressEmitter
/*     */   extends JavaEmitter
/*     */ {
/*     */   public static final String PROCADDRESS_VAR_PREFIX = "_addressof_";
/*     */   protected static final String WRAP_PREFIX = "dispatch_";
/*     */   private TypeDictionary typedefDictionary;
/*     */   protected JavaCodeUnit tableJavaUnit;
/*     */   protected Set<String> emittedTableEntries;
/*     */   protected String tableClassPackage;
/*     */   protected String tableClassName;
/*     */   
/*     */   public void beginFunctions(TypeDictionary paramTypeDictionary1, TypeDictionary paramTypeDictionary2, Map<Type, Type> paramMap, List<FunctionSymbol> paramList) throws Exception {
/*  83 */     this.typedefDictionary = paramTypeDictionary1;
/*     */     
/*  85 */     if (getProcAddressConfig().emitProcAddressTable()) {
/*  86 */       beginProcAddressTable();
/*     */     }
/*  88 */     super.beginFunctions(paramTypeDictionary1, paramTypeDictionary2, paramMap, paramList);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endFunctions() throws Exception {
/*  93 */     if (getProcAddressConfig().emitProcAddressTable()) {
/*  94 */       endProcAddressTable();
/*     */     }
/*  96 */     super.endFunctions();
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStructs(TypeDictionary paramTypeDictionary1, TypeDictionary paramTypeDictionary2, Map<Type, Type> paramMap) throws Exception {
/* 101 */     super.beginStructs(paramTypeDictionary1, paramTypeDictionary2, paramMap);
/*     */   }
/*     */   
/*     */   public String runtimeExceptionType() {
/* 105 */     return getConfig().runtimeExceptionType();
/*     */   }
/*     */   
/*     */   public String unsupportedExceptionType() {
/* 109 */     return getConfig().unsupportedExceptionType();
/*     */   }
/*     */ 
/*     */   
/*     */   protected JavaConfiguration createConfig() {
/* 114 */     return new ProcAddressConfiguration();
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<? extends FunctionEmitter> generateMethodBindingEmitters(FunctionSymbol paramFunctionSymbol) throws Exception {
/* 119 */     return generateMethodBindingEmittersImpl(paramFunctionSymbol);
/*     */   }
/*     */   
/*     */   protected boolean needsModifiedEmitters(FunctionSymbol paramFunctionSymbol) {
/* 123 */     if (!callThroughProcAddress(paramFunctionSymbol) || getConfig().isUnimplemented((AliasedSymbol)paramFunctionSymbol)) {
/* 124 */       return false;
/*     */     }
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<? extends FunctionEmitter> generateMethodBindingEmittersImpl(FunctionSymbol paramFunctionSymbol) throws Exception {
/* 131 */     List<? extends FunctionEmitter> list = super.generateMethodBindingEmitters(paramFunctionSymbol);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (list.isEmpty()) {
/* 137 */       this.LOG.log(Level.INFO, paramFunctionSymbol.getASTLocusTag(), "genModProcAddrEmitter: SKIP, empty binding set: {0}", paramFunctionSymbol);
/* 138 */       return list;
/*     */     } 
/*     */     
/* 141 */     boolean bool1 = callThroughProcAddress(paramFunctionSymbol);
/* 142 */     boolean bool2 = getConfig().isUnimplemented((AliasedSymbol)paramFunctionSymbol);
/*     */ 
/*     */     
/* 145 */     if (!bool1 || bool2) {
/* 146 */       this.LOG.log(Level.INFO, paramFunctionSymbol.getASTLocusTag(), "genModProcAddrEmitter: SKIP, not needed: callThrough {0}, isUnimplemented {1}: {2}", new Object[] {
/* 147 */             Boolean.valueOf(bool1), Boolean.valueOf(bool2), paramFunctionSymbol });
/* 148 */       return list;
/*     */     } 
/*     */     
/* 151 */     ArrayList<FunctionEmitter> arrayList = new ArrayList(list.size());
/*     */     
/* 153 */     if (bool1 && 
/* 154 */       getProcAddressConfig().emitProcAddressTable())
/*     */     {
/* 156 */       emitProcAddressTableEntryForString(paramFunctionSymbol.getName());
/*     */     }
/*     */     
/* 159 */     for (FunctionEmitter functionEmitter : list) {
/* 160 */       if (functionEmitter instanceof JavaMethodBindingEmitter) {
/* 161 */         generateModifiedEmitters((JavaMethodBindingEmitter)functionEmitter, arrayList); continue;
/* 162 */       }  if (functionEmitter instanceof CMethodBindingEmitter) {
/* 163 */         generateModifiedEmitters((CMethodBindingEmitter)functionEmitter, arrayList); continue;
/*     */       } 
/* 165 */       throw new RuntimeException("Unexpected emitter type: " + functionEmitter.getClass().getName());
/*     */     } 
/*     */ 
/*     */     
/* 169 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFunctionPointerTypedefName(FunctionSymbol paramFunctionSymbol) {
/* 181 */     return getProcAddressConfig().convertToFunctionPointerName(paramFunctionSymbol.getOrigName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fixSecurityModifiers(JavaMethodBindingEmitter paramJavaMethodBindingEmitter) {
/* 190 */     if (paramJavaMethodBindingEmitter.hasModifier(JavaMethodBindingEmitter.NATIVE) && 
/* 191 */       !paramJavaMethodBindingEmitter.hasModifier(JavaMethodBindingEmitter.PRIVATE)) {
/*     */       
/* 193 */       paramJavaMethodBindingEmitter.removeModifier(JavaMethodBindingEmitter.PUBLIC);
/* 194 */       paramJavaMethodBindingEmitter.removeModifier(JavaMethodBindingEmitter.PROTECTED);
/* 195 */       paramJavaMethodBindingEmitter.removeModifier(JavaMethodBindingEmitter.NATIVE);
/* 196 */       paramJavaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.PRIVATE);
/* 197 */       paramJavaMethodBindingEmitter.addModifier(JavaMethodBindingEmitter.NATIVE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void generateModifiedEmitters(JavaMethodBindingEmitter paramJavaMethodBindingEmitter, List<FunctionEmitter> paramList) {
/* 203 */     boolean bool = callThroughProcAddress(paramJavaMethodBindingEmitter.getBinding().getCSymbol());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     boolean bool1 = (paramJavaMethodBindingEmitter.signatureOnly() && paramJavaMethodBindingEmitter.isNativeMethod() && !paramJavaMethodBindingEmitter.isPrivateNativeMethod() && bool) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     ProcAddressJavaMethodBindingEmitter procAddressJavaMethodBindingEmitter = new ProcAddressJavaMethodBindingEmitter(paramJavaMethodBindingEmitter, bool, getProcAddressConfig().getProcAddressTableExpr(), paramJavaMethodBindingEmitter.isPrivateNativeMethod(), this);
/*     */     
/* 220 */     if (bool1) {
/* 221 */       procAddressJavaMethodBindingEmitter.setEmitBody(true);
/* 222 */       procAddressJavaMethodBindingEmitter.removeModifier(JavaMethodBindingEmitter.NATIVE);
/* 223 */     } else if (bool) {
/* 224 */       fixSecurityModifiers(procAddressJavaMethodBindingEmitter);
/*     */     } 
/* 226 */     paramList.add(procAddressJavaMethodBindingEmitter);
/*     */ 
/*     */     
/* 229 */     if (bool1) {
/*     */ 
/*     */       
/* 232 */       procAddressJavaMethodBindingEmitter = new ProcAddressJavaMethodBindingEmitter(paramJavaMethodBindingEmitter, bool, getProcAddressConfig().getProcAddressTableExpr(), true, this);
/*     */ 
/*     */       
/* 235 */       procAddressJavaMethodBindingEmitter.setPrivateNativeMethod(true);
/* 236 */       fixSecurityModifiers(procAddressJavaMethodBindingEmitter);
/* 237 */       paramList.add(procAddressJavaMethodBindingEmitter);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void generateModifiedEmitters(CMethodBindingEmitter paramCMethodBindingEmitter, List<FunctionEmitter> paramList) {
/* 243 */     FunctionSymbol functionSymbol = paramCMethodBindingEmitter.getBinding().getCSymbol();
/*     */ 
/*     */     
/* 246 */     boolean bool = hasFunctionPointerTypedef(functionSymbol);
/* 247 */     boolean bool1 = (bool || callThroughProcAddress(functionSymbol)) ? true : false;
/* 248 */     String str = getProcAddressConfig().getLocalProcAddressCallingConvention(functionSymbol);
/*     */     
/* 250 */     this.LOG.log(Level.INFO, functionSymbol.getASTLocusTag(), "genModProcAddrEmitter: callThrough {0}, hasTypedef {1}, localCallConv {2}: {3}", new Object[] {
/* 251 */           Boolean.valueOf(bool1), Boolean.valueOf(bool), str, functionSymbol
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     ProcAddressCMethodBindingEmitter procAddressCMethodBindingEmitter = new ProcAddressCMethodBindingEmitter(paramCMethodBindingEmitter, bool1, bool, str, this);
/*     */ 
/*     */     
/* 263 */     MessageFormat messageFormat = paramCMethodBindingEmitter.getReturnValueCapacityExpression();
/* 264 */     if (messageFormat != null) {
/* 265 */       procAddressCMethodBindingEmitter.setReturnValueCapacityExpression(messageFormat);
/*     */     }
/* 267 */     paramList.add(procAddressCMethodBindingEmitter);
/*     */   }
/*     */   
/*     */   protected boolean callThroughProcAddress(FunctionSymbol paramFunctionSymbol) {
/* 271 */     ProcAddressConfiguration procAddressConfiguration = getProcAddressConfig();
/* 272 */     boolean bool = false;
/* 273 */     byte b = 0;
/* 274 */     if (procAddressConfiguration.forceProcAddressGen(paramFunctionSymbol)) {
/* 275 */       bool = true;
/* 276 */       b = 1;
/*     */     }
/* 278 */     else if (procAddressConfiguration.skipProcAddressGen(paramFunctionSymbol)) {
/* 279 */       bool = false;
/* 280 */       b = 2;
/*     */     } else {
/* 282 */       bool = hasFunctionPointerTypedef(paramFunctionSymbol);
/* 283 */       b = 3;
/*     */     } 
/*     */     
/* 286 */     this.LOG.log(Level.INFO, paramFunctionSymbol.getASTLocusTag(), "callThroughProcAddress: {0} [m {1}]: {2}", new Object[] { Boolean.valueOf(bool), Integer.valueOf(b), paramFunctionSymbol });
/* 287 */     return bool;
/*     */   }
/*     */   protected boolean hasFunctionPointerTypedef(FunctionSymbol paramFunctionSymbol) {
/* 290 */     String str = getFunctionPointerTypedefName(paramFunctionSymbol);
/* 291 */     boolean bool = this.typedefDictionary.containsKey(str);
/* 292 */     this.LOG.log(Level.INFO, paramFunctionSymbol.getASTLocusTag(), "hasFunctionPointerTypedef: {0}: {1}", new Object[] { Boolean.valueOf(bool), paramFunctionSymbol });
/* 293 */     return bool;
/*     */   }
/*     */   
/*     */   protected void beginProcAddressTable() throws Exception {
/* 297 */     ProcAddressConfiguration procAddressConfiguration = getProcAddressConfig();
/* 298 */     this.tableClassPackage = procAddressConfiguration.tableClassPackage();
/* 299 */     this.tableClassName = procAddressConfiguration.tableClassName();
/*     */ 
/*     */     
/* 302 */     String str1 = this.tableClassPackage;
/* 303 */     if (str1 == null) {
/* 304 */       str1 = getImplPackageName();
/*     */     }
/* 306 */     String str2 = str1 + "." + this.tableClassName;
/* 307 */     String[] arrayOfString = getClassAccessModifiers(str2);
/*     */     
/* 309 */     String str3 = getJavaOutputDir() + File.separator + CodeGenUtils.packageAsPath(str1);
/*     */     
/* 311 */     String str4 = str3 + File.separator + this.tableClassName + ".java";
/* 312 */     this.tableJavaUnit = openJavaUnit(str4, str1, this.tableClassName);
/*     */     
/* 314 */     this.emittedTableEntries = new HashSet<>();
/*     */     
/* 316 */     this.tableJavaUnit.emitln("package " + str1 + ";");
/* 317 */     this.tableJavaUnit.emitln();
/* 318 */     for (String str : getConfig().imports()) {
/* 319 */       this.tableJavaUnit.emitln("import " + str + ";");
/*     */     }
/* 321 */     this.tableJavaUnit.emitln("import " + ProcAddressTable.class.getName() + ";");
/* 322 */     this.tableJavaUnit.emitln("import com.jogamp.common.util.SecurityUtil;");
/* 323 */     this.tableJavaUnit.emitln();
/*     */     
/* 325 */     this.tableJavaUnit.emitln("/**");
/* 326 */     this.tableJavaUnit.emitln(" * This table is a cache of pointers to the dynamically-linkable C library.");
/* 327 */     this.tableJavaUnit.emitln(" * @see " + ProcAddressTable.class.getSimpleName());
/* 328 */     this.tableJavaUnit.emitln(" */");
/* 329 */     for (byte b = 0; arrayOfString != null && b < arrayOfString.length; b++) {
/* 330 */       this.tableJavaUnit.emit(arrayOfString[b]);
/* 331 */       this.tableJavaUnit.emit(" ");
/*     */     } 
/* 333 */     this.tableJavaUnit.emitln("final class " + this.tableClassName + " extends " + ProcAddressTable.class.getSimpleName() + " {");
/* 334 */     this.tableJavaUnit.emitln();
/*     */     
/* 336 */     for (String str : getProcAddressConfig().getForceProcAddressGen()) {
/* 337 */       emitProcAddressTableEntryForString(str);
/*     */     }
/*     */     
/* 340 */     this.tableJavaUnit.emitln();
/* 341 */     this.tableJavaUnit.emitln("  public " + this.tableClassName + "(){ super(); }");
/* 342 */     this.tableJavaUnit.emitln();
/* 343 */     this.tableJavaUnit.emitln("  public " + this.tableClassName + "(" + FunctionAddressResolver.class.getName() + " resolver){ super(resolver); }");
/* 344 */     this.tableJavaUnit.emitln();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void endProcAddressTable() throws Exception {
/* 349 */     this.tableJavaUnit.emitln("} // end of class " + this.tableClassName);
/* 350 */     this.tableJavaUnit.close();
/* 351 */     this.tableJavaUnit = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void emitProcAddressTableEntryForString(String paramString) {
/* 357 */     if (this.emittedTableEntries.contains(paramString)) {
/*     */       return;
/*     */     }
/* 360 */     this.emittedTableEntries.add(paramString);
/* 361 */     this.tableJavaUnit.emit("  /* pp */ long ");
/* 362 */     this.tableJavaUnit.emit("_addressof_");
/* 363 */     this.tableJavaUnit.emit(paramString);
/* 364 */     this.tableJavaUnit.emitln(";");
/*     */   }
/*     */   
/*     */   protected ProcAddressConfiguration getProcAddressConfig() {
/* 368 */     return (ProcAddressConfiguration)getConfig();
/*     */   }
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/procaddress/ProcAddressEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */