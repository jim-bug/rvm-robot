/*     */ package com.jogamp.gluegen.procaddress;
/*     */ 
/*     */ import com.jogamp.gluegen.CommentEmitter;
/*     */ import com.jogamp.gluegen.FunctionEmitter;
/*     */ import com.jogamp.gluegen.JavaMethodBindingEmitter;
/*     */ import com.jogamp.gluegen.MethodBinding;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProcAddressJavaMethodBindingEmitter
/*     */   extends JavaMethodBindingEmitter
/*     */ {
/*     */   protected boolean callThroughProcAddress;
/*     */   protected boolean changeNameAndArguments;
/*     */   protected String getProcAddressTableExpr;
/*     */   protected ProcAddressEmitter emitter;
/*     */   
/*     */   public ProcAddressJavaMethodBindingEmitter(JavaMethodBindingEmitter paramJavaMethodBindingEmitter, boolean paramBoolean1, String paramString, boolean paramBoolean2, ProcAddressEmitter paramProcAddressEmitter) {
/*  61 */     super(paramJavaMethodBindingEmitter);
/*     */     
/*  63 */     this.callThroughProcAddress = paramBoolean1;
/*  64 */     this.getProcAddressTableExpr = paramString;
/*  65 */     this.changeNameAndArguments = paramBoolean2;
/*  66 */     this.emitter = paramProcAddressEmitter;
/*     */     
/*  68 */     if (paramBoolean1) {
/*  69 */       setCommentEmitter((CommentEmitter)new WrappedMethodCommentEmitter());
/*     */     }
/*     */     
/*  72 */     if (paramJavaMethodBindingEmitter.getBinding().hasContainingType()) {
/*  73 */       throw new IllegalArgumentException("Cannot create proc. address wrapper; method has containing type: \"" + paramJavaMethodBindingEmitter
/*     */           
/*  75 */           .getBinding() + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */   public ProcAddressJavaMethodBindingEmitter(ProcAddressJavaMethodBindingEmitter paramProcAddressJavaMethodBindingEmitter) {
/*  80 */     this(paramProcAddressJavaMethodBindingEmitter, paramProcAddressJavaMethodBindingEmitter.callThroughProcAddress, paramProcAddressJavaMethodBindingEmitter.getProcAddressTableExpr, paramProcAddressJavaMethodBindingEmitter.changeNameAndArguments, paramProcAddressJavaMethodBindingEmitter.emitter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImplName() {
/*  86 */     String str = super.getImplName();
/*  87 */     if (this.changeNameAndArguments) {
/*  88 */       return "dispatch_" + str;
/*     */     }
/*  90 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int appendArguments(StringBuilder paramStringBuilder) {
/*  95 */     int i = super.appendArguments(paramStringBuilder);
/*  96 */     if (this.callThroughProcAddress && 
/*  97 */       this.changeNameAndArguments) {
/*  98 */       if (i > 0) {
/*  99 */         paramStringBuilder.append(", ");
/*     */       }
/*     */       
/* 102 */       paramStringBuilder.append("long procAddress");
/* 103 */       i++;
/*     */     } 
/*     */     
/* 106 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getNativeImplMethodName() {
/* 111 */     String str = super.getNativeImplMethodName();
/* 112 */     if (this.callThroughProcAddress) {
/* 113 */       return "dispatch_" + str;
/*     */     }
/* 115 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void emitPreCallSetup(MethodBinding paramMethodBinding) {
/* 120 */     super.emitPreCallSetup(paramMethodBinding);
/*     */     
/* 122 */     if (this.callThroughProcAddress) {
/* 123 */       String str = "_addressof_" + paramMethodBinding.getNativeName();
/* 124 */       this.unit.emitln("    final long __addr_ = " + this.getProcAddressTableExpr + "." + str + ";");
/* 125 */       this.unit.emitln("    if (__addr_ == 0) {");
/* 126 */       this.unit.emitf("      throw new %s(String.format(\"Method \\\"%%s\\\" not available\", \"%s\"));%n", new Object[] { this.emitter
/* 127 */             .unsupportedExceptionType(), paramMethodBinding.getName() });
/* 128 */       this.unit.emitln("    }");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int emitCallArguments(MethodBinding paramMethodBinding) {
/* 134 */     int i = super.emitCallArguments(paramMethodBinding);
/* 135 */     if (this.callThroughProcAddress) {
/* 136 */       if (i > 0) {
/* 137 */         this.unit.emit(", ");
/*     */       }
/* 139 */       this.unit.emit("__addr_");
/* 140 */       i++;
/*     */     } 
/*     */     
/* 143 */     return i;
/*     */   }
/*     */   
/*     */   public class WrappedMethodCommentEmitter extends JavaMethodBindingEmitter.DefaultCommentEmitter { public WrappedMethodCommentEmitter() {
/* 147 */       super(ProcAddressJavaMethodBindingEmitter.this);
/*     */     }
/*     */     
/*     */     protected void emitBeginning(FunctionEmitter param1FunctionEmitter, PrintWriter param1PrintWriter) {
/* 151 */       param1PrintWriter.print("Entry point (through function pointer) to C language function: <br> ");
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/procaddress/ProcAddressJavaMethodBindingEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */