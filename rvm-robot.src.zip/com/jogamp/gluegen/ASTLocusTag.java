/*    */ package com.jogamp.gluegen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTLocusTag
/*    */ {
/*    */   public final Object source;
/*    */   public final int line;
/*    */   public final int column;
/*    */   public final String text;
/*    */   
/*    */   public ASTLocusTag(Object paramObject, int paramInt1, int paramInt2, String paramString) {
/* 44 */     this.source = paramObject;
/* 45 */     this.line = paramInt1;
/* 46 */     this.column = paramInt2;
/* 47 */     this.text = paramString;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 51 */     return toString(new StringBuilder(), null, true).toString();
/*    */   }
/*    */   public StringBuilder toString(StringBuilder paramStringBuilder, String paramString, boolean paramBoolean) {
/* 54 */     boolean bool = false;
/* 55 */     if (this.source != null) {
/* 56 */       paramStringBuilder.append(this.source);
/* 57 */       bool = true;
/*    */     } 
/* 59 */     if (this.line != -1) {
/* 60 */       if (bool) {
/* 61 */         paramStringBuilder.append(":");
/*    */       } else {
/* 63 */         paramStringBuilder.append("line ");
/*    */       } 
/* 65 */       paramStringBuilder.append(this.line);
/* 66 */       if (this.column != -1) {
/* 67 */         paramStringBuilder.append(":" + this.column);
/*    */       }
/* 69 */       bool = true;
/*    */     } 
/* 71 */     if (null != paramString && paramString.length() > 0) {
/* 72 */       if (bool) {
/* 73 */         paramStringBuilder.append(": ");
/*    */       }
/* 75 */       paramStringBuilder.append(paramString);
/* 76 */       bool = true;
/*    */     } 
/* 78 */     if (paramBoolean && null != this.text && this.text.length() > 0) {
/* 79 */       if (bool) {
/* 80 */         paramStringBuilder.append(": ");
/*    */       } else {
/* 82 */         paramStringBuilder.append("text ");
/*    */       } 
/* 84 */       paramStringBuilder.append("'").append(this.text).append("'");
/*    */     } 
/* 86 */     return paramStringBuilder;
/*    */   }
/*    */   
/*    */   public static interface ASTLocusTagProvider {
/*    */     ASTLocusTag getASTLocusTag();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/ASTLocusTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */