/*    */ package com.jogamp.gluegen;
/*    */ 
/*    */ import com.jogamp.common.JogampRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlueGenException
/*    */   extends JogampRuntimeException
/*    */ {
/*    */   final ASTLocusTag locus;
/*    */   
/*    */   public ASTLocusTag getASTLocusTag() {
/* 40 */     return this.locus;
/*    */   }
/*    */ 
/*    */   
/*    */   public GlueGenException() {
/* 45 */     this.locus = null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GlueGenException(String paramString) {
/* 51 */     super(paramString);
/* 52 */     this.locus = null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GlueGenException(String paramString, Throwable paramThrowable) {
/* 58 */     super(paramString, paramThrowable);
/* 59 */     this.locus = null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GlueGenException(Throwable paramThrowable) {
/* 65 */     super(paramThrowable);
/* 66 */     this.locus = null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GlueGenException(String paramString, ASTLocusTag paramASTLocusTag) {
/* 72 */     super(paramString);
/* 73 */     this.locus = paramASTLocusTag;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GlueGenException(String paramString, ASTLocusTag paramASTLocusTag, Throwable paramThrowable) {
/* 79 */     super(paramString, paramThrowable);
/* 80 */     this.locus = paramASTLocusTag;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 84 */     StringBuilder stringBuilder = new StringBuilder(256);
/* 85 */     if (null != this.locus) {
/* 86 */       this.locus.toString(stringBuilder, "error", true).append(": ");
/*    */     }
/* 88 */     stringBuilder.append(getClass().getSimpleName()).append(": ").append(getLocalizedMessage());
/* 89 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/GlueGenException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */