/*    */ package com.jogamp.gluegen;
/*    */ 
/*    */ import com.jogamp.gluegen.cgram.types.CompoundType;
/*    */ import com.jogamp.gluegen.cgram.types.PointerType;
/*    */ import com.jogamp.gluegen.cgram.types.Type;
/*    */ import com.jogamp.gluegen.cgram.types.TypeVisitor;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReferencedStructs
/*    */   implements TypeVisitor
/*    */ {
/* 47 */   private final Map<String, Type> resultMap = new HashMap<>();
/* 48 */   private final Set<CompoundType> layoutSet = new HashSet<>();
/* 49 */   private final Set<Type> skip = new HashSet<>();
/*    */   
/*    */   public void clear() {
/* 52 */     this.resultMap.clear();
/*    */   }
/*    */   
/*    */   public Iterator<Type> results() {
/* 56 */     return this.resultMap.values().iterator();
/*    */   }
/*    */   public Iterator<CompoundType> layouts() {
/* 59 */     return this.layoutSet.iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitType(Type paramType) {
/* 64 */     if (this.skip.contains(paramType)) {
/*    */       return;
/*    */     }
/* 67 */     if (paramType.isPointer()) {
/* 68 */       PointerType pointerType = paramType.asPointer();
/* 69 */       CompoundType compoundType = pointerType.getTargetType().asCompound();
/* 70 */       if (pointerType.isTypedef() && null != compoundType)
/*    */       {
/* 72 */         this.skip.add(compoundType);
/* 73 */         this.resultMap.put(compoundType.getName(), pointerType);
/* 74 */         this.layoutSet.add(compoundType);
/*    */       }
/*    */     
/*    */     }
/* 78 */     else if (paramType.isCompound()) {
/*    */       
/* 80 */       if (!this.resultMap.containsKey(paramType.getName())) {
/* 81 */         this.resultMap.put(paramType.getName(), paramType);
/*    */       }
/* 83 */       this.layoutSet.add(paramType.asCompound());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/ReferencedStructs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */