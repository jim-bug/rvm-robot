package com.jogamp.gluegen;

import java.io.PrintWriter;

public interface CommentEmitter {
  void emit(FunctionEmitter paramFunctionEmitter, PrintWriter paramPrintWriter);
}


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/CommentEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */