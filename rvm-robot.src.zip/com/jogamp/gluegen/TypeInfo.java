/*    */ package com.jogamp.gluegen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeInfo
/*    */ {
/*    */   private final String name;
/*    */   private final int pointerDepth;
/*    */   private final JavaType javaType;
/*    */   private TypeInfo next;
/*    */   
/*    */   public TypeInfo(String paramString, int paramInt, JavaType paramJavaType) {
/* 52 */     this.name = paramString;
/* 53 */     this.pointerDepth = paramInt;
/* 54 */     this.javaType = paramJavaType;
/*    */   }
/*    */   
/* 57 */   public String name() { return this.name; }
/* 58 */   public int pointerDepth() { return this.pointerDepth; }
/* 59 */   public JavaType javaType() { return this.javaType; }
/* 60 */   public void setNext(TypeInfo paramTypeInfo) { this.next = paramTypeInfo; } public TypeInfo next() {
/* 61 */     return this.next;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 65 */     StringBuilder stringBuilder = new StringBuilder("TypeInfo: ");
/* 66 */     stringBuilder.append(this.name);
/* 67 */     stringBuilder.append(" pointerDepth ");
/* 68 */     stringBuilder.append(this.pointerDepth);
/* 69 */     stringBuilder.append(" JavaType " + this.javaType.getDebugString());
/* 70 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/TypeInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */