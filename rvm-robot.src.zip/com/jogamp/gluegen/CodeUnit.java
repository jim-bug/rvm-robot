/*    */ package com.jogamp.gluegen;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CodeUnit
/*    */ {
/*    */   public final String filename;
/*    */   public final PrintWriter output;
/* 45 */   private final Set<String> tailCode = new HashSet<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected CodeUnit(String paramString, Object paramObject) throws IOException {
/* 53 */     this.filename = paramString;
/* 54 */     this.output = openFile(paramString);
/*    */   }
/*    */   
/*    */   private static PrintWriter openFile(String paramString) throws IOException {
/* 58 */     File file = new File(paramString);
/* 59 */     String str = file.getParent();
/* 60 */     if (str != null) {
/* 61 */       (new File(str)).mkdirs();
/*    */     }
/* 63 */     return new PrintWriter(new BufferedWriter(new FileWriter(file)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean addTailCode(String paramString) {
/* 72 */     return this.tailCode.add(paramString);
/*    */   }
/*    */   
/*    */   public void emitln() {
/* 76 */     this.output.println();
/*    */   }
/*    */   public void emitln(String paramString) {
/* 79 */     this.output.println(paramString);
/*    */   }
/*    */   public void emit(String paramString) {
/* 82 */     this.output.print(paramString);
/*    */   }
/*    */   public void emitf(String paramString, Object... paramVarArgs) {
/* 85 */     this.output.printf(paramString, paramVarArgs);
/*    */   }
/*    */   public void emitTailCode() {
/* 88 */     this.tailCode.forEach(paramString -> { this.output.write(paramString); this.output.println();
/* 89 */         }); this.tailCode.clear();
/*    */   }
/*    */   public void close() {
/* 92 */     emitTailCode();
/* 93 */     this.output.flush();
/* 94 */     this.output.close();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 98 */     return "CodeUnit[file " + this.filename + "]";
/*    */   }
/*    */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/CodeUnit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */