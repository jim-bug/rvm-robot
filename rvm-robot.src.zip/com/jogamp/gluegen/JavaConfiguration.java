/*      */ package com.jogamp.gluegen;
/*      */ 
/*      */ import antlr.TokenStream;
/*      */ import com.jogamp.gluegen.cgram.types.AliasedSymbol;
/*      */ import com.jogamp.gluegen.cgram.types.FunctionType;
/*      */ import com.jogamp.gluegen.cgram.types.Type;
/*      */ import com.jogamp.gluegen.jgram.JavaLexer;
/*      */ import com.jogamp.gluegen.jgram.JavaParser;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.logging.Level;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JavaConfiguration
/*      */ {
/*      */   private int nestedReads;
/*      */   private String libraryOnLoadName;
/*      */   private String packageName;
/*      */   private String implPackageName;
/*      */   private String className;
/*      */   private String implClassName;
/*      */   protected final Logging.LoggerIf LOG;
/*   73 */   public static String NEWLINE = System.getProperty("line.separator");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   79 */   private String javaOutputDir = ".";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   84 */   private String outputRootDir = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   private String nativeOutputDir = ".";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean nativeOutputUsesJavaHierarchy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean tagNativeBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean relaxedEqualSemanticsTest;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  118 */   private JavaEmitter.EmissionStyle emissionStyle = JavaEmitter.EmissionStyle.AllStatic;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   private final List<String> imports = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   private String gluegenRuntimePackage = "com.jogamp.gluegen.runtime";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  136 */   private String runtimeExceptionType = "RuntimeException";
/*  137 */   private String unsupportedExceptionType = "UnsupportedOperationException";
/*      */   
/*  139 */   private final Map<String, JavaEmitter.MethodAccess> accessControl = new HashMap<>();
/*  140 */   private final Map<String, TypeInfo> typeInfoMap = new HashMap<>();
/*  141 */   private final Set<String> returnsString = new HashSet<>();
/*  142 */   private final Set<String> returnsStringOnly = new HashSet<>();
/*  143 */   private final Map<String, JavaType> returnsOpaqueJType = new HashMap<>();
/*  144 */   private final Map<String, String> returnedArrayLengths = new HashMap<>();
/*  145 */   private final Set<String> maxOneElement = new HashSet<>();
/*      */   
/*      */   public static class PascalStringIdx
/*      */   {
/*      */     public final int lengthIndex;
/*      */     public final int valueIndex;
/*      */     
/*      */     PascalStringIdx(int param1Int1, int param1Int2) {
/*  153 */       this.lengthIndex = param1Int1;
/*  154 */       this.valueIndex = param1Int2;
/*      */     }
/*      */     
/*      */     public void pushValueIndex(List<Integer> param1List) {
/*  158 */       param1List.add(Integer.valueOf(this.valueIndex));
/*      */     }
/*      */     public static final List<Integer> pushValueIndex(List<PascalStringIdx> param1List, List<Integer> param1List1) {
/*  161 */       if (null == param1List1) {
/*  162 */         param1List1 = new ArrayList<>(2);
/*      */       }
/*  164 */       for (PascalStringIdx pascalStringIdx : param1List) {
/*  165 */         pascalStringIdx.pushValueIndex(param1List1);
/*      */       }
/*  167 */       return param1List1;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  172 */       return "PascalString[lenIdx " + this.lengthIndex + ", valIdx " + this.valueIndex + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  180 */   private final Map<String, List<Integer>> argumentsAreString = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  186 */   private final Map<String, List<PascalStringIdx>> argumentsArePascalString = new HashMap<>();
/*      */   
/*      */   public static class JavaCallbackDef
/*      */   {
/*      */     final String cbFuncTypeName;
/*      */     final int cbFuncUserParamIdx;
/*      */     final String setFuncName;
/*      */     final int setFuncUserParamIdx;
/*  194 */     final List<Integer> cbFuncKeyIndices = new ArrayList<>();
/*      */     final String userParamClassName;
/*      */     final String customKeyClassName;
/*  197 */     final List<Integer> setFuncKeyIndices = new ArrayList<>();
/*      */     
/*      */     JavaCallbackDef(String param1String1, int param1Int1, String param1String2, int param1Int2, String param1String3, String param1String4) {
/*  200 */       this.cbFuncTypeName = param1String1;
/*  201 */       this.cbFuncUserParamIdx = param1Int1;
/*  202 */       this.setFuncName = param1String2;
/*  203 */       this.setFuncUserParamIdx = param1Int2;
/*  204 */       this.userParamClassName = param1String3;
/*  205 */       this.customKeyClassName = param1String4;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  209 */       return String.format("JavaCallbackDef[cbFunc[type %s, userParamIdx %d, keys %s], set[%s, keys %s, userParamIdx %d], Class[UserParam %s, Key %s]]", new Object[] { this.cbFuncTypeName, 
/*  210 */             Integer.valueOf(this.cbFuncUserParamIdx), this.cbFuncKeyIndices.toString(), this.setFuncName, this.setFuncKeyIndices.toString(), Integer.valueOf(this.setFuncUserParamIdx), this.userParamClassName, this.customKeyClassName });
/*      */     }
/*      */   }
/*      */   
/*  214 */   private final List<JavaCallbackDef> javaCallbackList = new ArrayList<>();
/*  215 */   private final Map<String, JavaCallbackDef> javaCallbackSetFuncToDef = new HashMap<>();
/*      */   
/*  217 */   private final Set<String> extendedIntfSymbolsIgnore = new HashSet<>();
/*  218 */   private final Set<String> extendedIntfSymbolsOnly = new HashSet<>();
/*  219 */   private final Set<String> extendedImplSymbolsIgnore = new HashSet<>();
/*  220 */   private final Set<String> extendedImplSymbolsOnly = new HashSet<>();
/*  221 */   private final Set<Pattern> ignores = new HashSet<>();
/*  222 */   private final Map<String, Pattern> ignoreMap = new HashMap<>();
/*  223 */   private final Set<Pattern> ignoreNots = new HashSet<>();
/*  224 */   private final Set<Pattern> unignores = new HashSet<>();
/*  225 */   private final Set<Pattern> unimplemented = new HashSet<>();
/*      */   private boolean forceUseNIOOnly4All = false;
/*  227 */   private final Set<String> useNIOOnly = new HashSet<>();
/*      */   private boolean forceUseNIODirectOnly4All = false;
/*  229 */   private final Set<String> useNIODirectOnly = new HashSet<>();
/*  230 */   private final Set<String> immutableAccessSymbols = new HashSet<>();
/*  231 */   private final Set<String> manuallyImplement = new HashSet<>();
/*  232 */   private final Map<String, String> delegatedImplementation = new HashMap<>();
/*  233 */   private final Map<String, List<String>> customJavaCode = new HashMap<>();
/*  234 */   private final Map<String, List<String>> customJNICode = new HashMap<>();
/*  235 */   private final Map<String, List<String>> classJavadoc = new HashMap<>();
/*  236 */   private final Map<String, List<String>> methodJavadoc = new HashMap<>();
/*  237 */   private final Map<String, String> structPackages = new HashMap<>();
/*  238 */   private final List<String> customCCode = new ArrayList<>();
/*  239 */   private final List<String> forcedStructs = new ArrayList<>();
/*  240 */   private final Map<String, String> structMachineDataInfoIndex = new HashMap<>();
/*  241 */   private final Map<String, String> returnValueCapacities = new HashMap<>();
/*  242 */   private final Map<String, String> returnValueLengths = new HashMap<>();
/*  243 */   private final Map<String, List<String>> temporaryCVariableDeclarations = new HashMap<>();
/*  244 */   private final Map<String, List<String>> temporaryCVariableAssignments = new HashMap<>();
/*  245 */   private final Map<String, List<String>> extendedInterfaces = new HashMap<>();
/*  246 */   private final Map<String, List<String>> implementedInterfaces = new HashMap<>();
/*  247 */   private final Map<String, String> parentClass = new HashMap<>();
/*  248 */   private final Map<String, String> javaTypeRenames = new HashMap<>();
/*  249 */   private final Map<String, String> javaSymbolRenames = new HashMap<>();
/*  250 */   private final Map<String, Set<String>> javaRenamedSymbols = new HashMap<>();
/*  251 */   private final Map<String, List<String>> javaPrologues = new HashMap<>();
/*  252 */   private final Map<String, List<String>> javaEpilogues = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean DEBUG_TYPE_INFO = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void read(String paramString) throws IOException {
/*  262 */     read(paramString, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void read(String paramString1, String paramString2) throws IOException {
/*  272 */     File file = new File(paramString1);
/*  273 */     BufferedReader bufferedReader = null;
/*      */     try {
/*  275 */       bufferedReader = new BufferedReader(new FileReader(file));
/*      */     }
/*  277 */     catch (FileNotFoundException fileNotFoundException) {
/*  278 */       throw new RuntimeException("Could not read file \"" + file + "\"", fileNotFoundException);
/*      */     } 
/*  280 */     byte b = 0;
/*  281 */     String str = null;
/*  282 */     boolean bool = (paramString2 != null && paramString2.length() > 0) ? true : false;
/*      */     try {
/*  284 */       this.nestedReads++;
/*  285 */       while ((str = bufferedReader.readLine()) != null) {
/*  286 */         b++;
/*  287 */         if (bool) {
/*  288 */           str = paramString2 + " " + str;
/*      */         }
/*      */         
/*  291 */         if (str.trim().startsWith("#")) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/*  296 */         StringTokenizer stringTokenizer = new StringTokenizer(str);
/*  297 */         if (stringTokenizer.hasMoreTokens()) {
/*      */           
/*  299 */           String str1 = stringTokenizer.nextToken(" \t\n\r\f");
/*      */           
/*  301 */           dispatch(str1, stringTokenizer, file, paramString1, b);
/*      */         } 
/*      */       } 
/*  304 */       bufferedReader.close();
/*      */     } finally {
/*  306 */       this.nestedReads--;
/*      */     } 
/*      */     
/*  309 */     if (this.nestedReads == 0) {
/*  310 */       if (allStatic() && this.implClassName != null) {
/*  311 */         throw new IllegalStateException("Error in configuration file \"" + paramString1 + "\": Cannot use directive \"ImplJavaClass\" in conjunction with \"Style AllStatic\"");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  316 */       if (this.className != null || emissionStyle() != JavaEmitter.EmissionStyle.ImplOnly);
/*      */ 
/*      */       
/*  319 */       if (this.packageName == null && emissionStyle() != JavaEmitter.EmissionStyle.ImplOnly) {
/*  320 */         throw new RuntimeException("Output package name was not specified in configuration file \"" + paramString1 + "\"");
/*      */       }
/*      */       
/*  323 */       if (allStatic()) {
/*  324 */         this.implClassName = this.className;
/*      */ 
/*      */         
/*  327 */         this.implPackageName = this.packageName;
/*      */       } else {
/*  329 */         if (this.implClassName == null) {
/*      */ 
/*      */           
/*  332 */           if (this.className == null) {
/*  333 */             throw new RuntimeException("If ImplJavaClass is not specified, must specify JavaClass");
/*      */           }
/*  335 */           this.implClassName = this.className + "Impl";
/*      */         } 
/*  337 */         if (this.implPackageName == null) {
/*      */ 
/*      */           
/*  340 */           if (this.packageName == null) {
/*  341 */             throw new RuntimeException("If ImplPackageName is not specified, must specify PackageName");
/*      */           }
/*  343 */           this.implPackageName = this.packageName + ".impl";
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   public void setOutputRootDir(String paramString) {
/*  349 */     this.outputRootDir = paramString;
/*      */   }
/*      */   
/*      */   public String libraryOnLoadName() {
/*  353 */     return this.libraryOnLoadName;
/*      */   }
/*      */ 
/*      */   
/*      */   public String packageName() {
/*  358 */     return this.packageName;
/*      */   }
/*      */ 
/*      */   
/*      */   public String implPackageName() {
/*  363 */     return this.implPackageName;
/*      */   }
/*      */ 
/*      */   
/*      */   public String className() {
/*  368 */     return this.className;
/*      */   }
/*      */ 
/*      */   
/*      */   public String implClassName() {
/*  373 */     return this.implClassName;
/*      */   }
/*      */   
/*      */   public boolean structsOnly() {
/*  377 */     return (this.className == null && this.implClassName == null);
/*      */   }
/*      */ 
/*      */   
/*      */   public String javaOutputDir() {
/*  382 */     return (null != this.outputRootDir) ? (this.outputRootDir + "/" + this.javaOutputDir) : this.javaOutputDir;
/*      */   }
/*      */ 
/*      */   
/*      */   public String nativeOutputDir() {
/*  387 */     return (null != this.outputRootDir) ? (this.outputRootDir + "/" + this.nativeOutputDir) : this.nativeOutputDir;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nativeOutputUsesJavaHierarchy() {
/*  392 */     return this.nativeOutputUsesJavaHierarchy;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean tagNativeBinding() {
/*  397 */     return this.tagNativeBinding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relaxedEqualSemanticsTest() {
/*  406 */     return this.relaxedEqualSemanticsTest;
/*      */   }
/*      */ 
/*      */   
/*      */   public JavaEmitter.EmissionStyle emissionStyle() {
/*  411 */     return this.emissionStyle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaEmitter.MethodAccess accessControl(String paramString) {
/*  419 */     JavaEmitter.MethodAccess methodAccess = this.accessControl.get(paramString);
/*  420 */     if (methodAccess != null) {
/*  421 */       return methodAccess;
/*      */     }
/*      */     
/*  424 */     return JavaEmitter.MethodAccess.PUBLIC;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String gluegenRuntimePackage() {
/*  431 */     return this.gluegenRuntimePackage;
/*      */   }
/*      */ 
/*      */   
/*      */   public String runtimeExceptionType() {
/*  436 */     return this.runtimeExceptionType;
/*      */   }
/*      */ 
/*      */   
/*      */   public String unsupportedExceptionType() {
/*  441 */     return this.unsupportedExceptionType;
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> imports() {
/*  446 */     return this.imports;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeInfo canonicalNameOpaque(String paramString) {
/*  463 */     return this.typeInfoMap.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeInfo typeInfo(Type paramType) {
/*  475 */     int i = paramType.pointerDepth();
/*  476 */     for (byte b = 0; b <= i; b++) {
/*  477 */       String str = paramType.getName();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  482 */       if (str != null) {
/*  483 */         TypeInfo typeInfo = closestTypeInfo(str, b + paramType.pointerDepth());
/*  484 */         if (typeInfo != null) {
/*  485 */           return promoteTypeInfo(typeInfo, b);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  495 */       if (paramType.isCompound()) {
/*      */         
/*  497 */         str = paramType.asCompound().getStructName();
/*  498 */         if (str != null) {
/*  499 */           TypeInfo typeInfo = closestTypeInfo(str, b + paramType.pointerDepth());
/*  500 */           if (typeInfo != null) {
/*  501 */             return promoteTypeInfo(typeInfo, b);
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  512 */       if (paramType.isPointer()) {
/*  513 */         paramType = paramType.asPointer().getTargetType();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  519 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private TypeInfo closestTypeInfo(String paramString, int paramInt) {
/*  524 */     TypeInfo typeInfo1 = this.typeInfoMap.get(paramString);
/*  525 */     TypeInfo typeInfo2 = null;
/*  526 */     while (typeInfo1 != null) {
/*      */ 
/*      */ 
/*      */       
/*  530 */       if (typeInfo1.pointerDepth() <= paramInt && (typeInfo2 == null || typeInfo1.pointerDepth() > typeInfo2.pointerDepth()))
/*      */       {
/*      */ 
/*      */         
/*  534 */         typeInfo2 = typeInfo1;
/*      */       }
/*  536 */       typeInfo1 = typeInfo1.next();
/*      */     } 
/*  538 */     return typeInfo2;
/*      */   }
/*      */ 
/*      */   
/*      */   private TypeInfo promoteTypeInfo(TypeInfo paramTypeInfo, int paramInt) {
/*  543 */     int i = paramTypeInfo.pointerDepth();
/*  544 */     int j = paramInt - i;
/*  545 */     if (j == 0) {
/*  546 */       return paramTypeInfo;
/*      */     }
/*      */     
/*  549 */     if (j < 0) {
/*  550 */       throw new RuntimeException("TypeInfo for " + paramTypeInfo.name() + " and pointerDepth " + paramTypeInfo
/*  551 */           .pointerDepth() + " should not have matched for depth " + paramInt);
/*      */     }
/*      */ 
/*      */     
/*  555 */     Class<?> clazz = paramTypeInfo.javaType().getJavaClass();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  560 */     if (j == 1) {
/*  561 */       JavaType javaType = null;
/*  562 */       if (clazz == boolean.class) { javaType = JavaType.createForCCharPointer(); }
/*  563 */       else if (clazz == byte.class) { javaType = JavaType.createForCCharPointer(); }
/*  564 */       else if (clazz == short.class) { javaType = JavaType.createForCShortPointer(); }
/*  565 */       else if (clazz == int.class) { javaType = JavaType.createForCInt32Pointer(); }
/*  566 */       else if (clazz == long.class) { javaType = JavaType.createForCInt64Pointer(); }
/*  567 */       else if (clazz == float.class) { javaType = JavaType.createForCFloatPointer(); }
/*  568 */       else if (clazz == double.class) { javaType = JavaType.createForCDoublePointer(); }
/*      */       
/*  570 */       if (javaType != null) {
/*  571 */         return new TypeInfo(paramTypeInfo.name(), paramInt, javaType);
/*      */       }
/*      */     } 
/*  574 */     while (j > 0) {
/*  575 */       clazz = Array.newInstance(clazz, 0).getClass();
/*  576 */       j--;
/*      */     } 
/*      */     
/*  579 */     return new TypeInfo(paramTypeInfo.name(), paramInt, 
/*      */         
/*  581 */         JavaType.createForClass(clazz));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean returnsString(String paramString) {
/*  588 */     return this.returnsString.contains(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean returnsString(AliasedSymbol paramAliasedSymbol) {
/*  594 */     return (this.returnsString.contains(paramAliasedSymbol.getName()) || 
/*  595 */       oneInSet(this.returnsString, paramAliasedSymbol.getAliasedNames()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean returnsStringOnly(String paramString) {
/*  602 */     return this.returnsStringOnly.contains(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public List<JavaCallbackDef> getJavaCallbackList() {
/*  607 */     return this.javaCallbackList;
/*      */   }
/*      */ 
/*      */   
/*      */   public JavaCallbackDef javaCallbackSetFuncToDef(AliasedSymbol paramAliasedSymbol) {
/*  612 */     String str = paramAliasedSymbol.getName();
/*  613 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/*      */     
/*  615 */     JavaCallbackDef javaCallbackDef = this.javaCallbackSetFuncToDef.get(str);
/*  616 */     if (null == javaCallbackDef) {
/*  617 */       javaCallbackDef = oneInMap(this.javaCallbackSetFuncToDef, set);
/*      */     }
/*  619 */     return javaCallbackDef;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String returnedArrayLength(String paramString) {
/*  638 */     return this.returnedArrayLengths.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean maxOneElement(String paramString) {
/*  647 */     return this.maxOneElement.contains(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Integer> stringArguments(AliasedSymbol paramAliasedSymbol) {
/*  654 */     String str = paramAliasedSymbol.getName();
/*  655 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/*      */     
/*  657 */     List<Integer> list = this.argumentsAreString.get(str);
/*  658 */     if (null == list) {
/*  659 */       list = oneInMap((Map)this.argumentsAreString, set);
/*  660 */       if (null == list) {
/*  661 */         return null;
/*      */       }
/*      */     } 
/*  664 */     this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "ArgumentsAreString: {0} -> {1}", new Object[] { paramAliasedSymbol, list });
/*  665 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<PascalStringIdx> pascalStringArgument(AliasedSymbol paramAliasedSymbol) {
/*  672 */     String str = paramAliasedSymbol.getName();
/*  673 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/*      */     
/*  675 */     List<PascalStringIdx> list = this.argumentsArePascalString.get(str);
/*  676 */     if (null == list) {
/*  677 */       list = oneInMap((Map)this.argumentsArePascalString, set);
/*  678 */       if (null == list) {
/*  679 */         return null;
/*      */       }
/*      */     } 
/*  682 */     this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "ArgumentIsPascalString: {0} -> {1}", new Object[] { paramAliasedSymbol, list });
/*  683 */     return list;
/*      */   }
/*      */   
/*      */   public int pascalStringLengthIndex(AliasedSymbol paramAliasedSymbol, int paramInt) {
/*  687 */     List<PascalStringIdx> list = pascalStringArgument(paramAliasedSymbol);
/*  688 */     if (null != list) {
/*  689 */       for (PascalStringIdx pascalStringIdx : list) {
/*  690 */         if (paramInt == pascalStringIdx.valueIndex) {
/*  691 */           return pascalStringIdx.lengthIndex;
/*      */         }
/*      */       } 
/*      */     }
/*  695 */     return -1;
/*      */   }
/*      */   public boolean isForceUsingNIOOnly4All() {
/*  698 */     return this.forceUseNIOOnly4All;
/*      */   }
/*      */   public void addUseNIOOnly(String paramString) {
/*  701 */     this.useNIOOnly.add(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean useNIOOnly(String paramString) {
/*  707 */     return (useNIODirectOnly(paramString) || this.forceUseNIOOnly4All || this.useNIOOnly.contains(paramString));
/*      */   }
/*      */   
/*      */   public void addUseNIODirectOnly(String paramString) {
/*  711 */     this.useNIODirectOnly.add(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean useNIODirectOnly(String paramString) {
/*  719 */     return (this.forceUseNIODirectOnly4All || this.useNIODirectOnly.contains(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> customJavaCodeForClass(String paramString) {
/*  727 */     List<String> list = this.customJavaCode.get(paramString);
/*  728 */     if (list == null) {
/*  729 */       list = new ArrayList();
/*  730 */       this.customJavaCode.put(paramString, list);
/*      */     } 
/*  732 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> customJNICodeForClass(String paramString) {
/*  740 */     List<String> list = this.customJNICode.get(paramString);
/*  741 */     if (list == null) {
/*  742 */       list = new ArrayList();
/*  743 */       this.customJNICode.put(paramString, list);
/*      */     } 
/*  745 */     return list;
/*      */   }
/*      */   
/*      */   public List<String> javadocForMethod(String paramString) {
/*  749 */     List<String> list = this.methodJavadoc.get(paramString);
/*  750 */     if (list == null) {
/*  751 */       list = new ArrayList();
/*  752 */       this.methodJavadoc.put(paramString, list);
/*      */     } 
/*  754 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> javadocForClass(String paramString) {
/*  762 */     List<String> list = this.classJavadoc.get(paramString);
/*  763 */     if (list == null) {
/*  764 */       list = new ArrayList();
/*  765 */       this.classJavadoc.put(paramString, list);
/*      */     } 
/*  767 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String packageForStruct(String paramString) {
/*  774 */     String str = this.structPackages.get(paramString);
/*  775 */     if (str == null) {
/*  776 */       str = this.packageName;
/*      */     }
/*  778 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> customCCode() {
/*  784 */     return this.customCCode;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> forcedStructs() {
/*  790 */     return this.forcedStructs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String returnStructMachineDataInfoIndex(String paramString) {
/*  804 */     return this.structMachineDataInfoIndex.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String returnValueCapacity(String paramString) {
/*  817 */     return this.returnValueCapacities.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String returnValueLength(String paramString) {
/*  829 */     return this.returnValueLengths.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> temporaryCVariableDeclarations(String paramString) {
/*  835 */     return this.temporaryCVariableDeclarations.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> temporaryCVariableAssignments(String paramString) {
/*  842 */     return this.temporaryCVariableAssignments.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> extendedInterfaces(String paramString) {
/*  849 */     List<String> list = this.extendedInterfaces.get(paramString);
/*  850 */     if (list == null) {
/*  851 */       list = new ArrayList();
/*  852 */       this.extendedInterfaces.put(paramString, list);
/*      */     } 
/*  854 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> implementedInterfaces(String paramString) {
/*  861 */     List<String> list = this.implementedInterfaces.get(paramString);
/*  862 */     if (list == null) {
/*  863 */       list = new ArrayList();
/*  864 */       this.implementedInterfaces.put(paramString, list);
/*      */     } 
/*  866 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String extendedParentClass(String paramString) {
/*  873 */     return this.parentClass.get(paramString);
/*      */   }
/*      */   
/*      */   public void logIgnoresOnce() {
/*  877 */     if (!loggedIgnores) {
/*  878 */       loggedIgnores = true;
/*  879 */       logIgnores();
/*      */     } 
/*      */   }
/*      */   private static boolean loggedIgnores = false;
/*      */   
/*      */   public void logIgnores() {
/*  885 */     this.LOG.log(Level.INFO, "Extended Intf: {0}", Integer.valueOf(this.extendedIntfSymbolsIgnore.size()));
/*  886 */     for (String str : this.extendedIntfSymbolsIgnore) {
/*  887 */       this.LOG.log(Level.INFO, "\t{0}", str);
/*      */     }
/*  889 */     this.LOG.log(Level.INFO, "Extended Impl: {0}", Integer.valueOf(this.extendedImplSymbolsIgnore.size()));
/*  890 */     for (String str : this.extendedImplSymbolsIgnore) {
/*  891 */       this.LOG.log(Level.INFO, "\t{0}", str);
/*      */     }
/*  893 */     this.LOG.log(Level.INFO, "Ignores (All): {0}", Integer.valueOf(this.ignores.size()));
/*  894 */     for (Pattern pattern : this.ignores) {
/*  895 */       this.LOG.log(Level.INFO, "\t{0}", pattern);
/*      */     }
/*      */   }
/*      */   
/*      */   public void logRenamesOnce() {
/*  900 */     if (!loggedRenames) {
/*  901 */       loggedRenames = true;
/*  902 */       logRenames();
/*      */     } 
/*      */   }
/*      */   private static boolean loggedRenames = false;
/*      */   
/*      */   public void logRenames() {
/*  908 */     this.LOG.log(Level.INFO, "Symbol Renames: {0}", Integer.valueOf(this.javaSymbolRenames.size()));
/*  909 */     for (String str : this.javaSymbolRenames.keySet()) {
/*  910 */       this.LOG.log(Level.INFO, "\t{0} -> {1}", new Object[] { str, this.javaSymbolRenames.get(str) });
/*      */     } 
/*      */     
/*  913 */     this.LOG.log(Level.INFO, "Symbol Aliasing (through renaming): {0}", Integer.valueOf(this.javaSymbolRenames.size()));
/*  914 */     for (String str : this.javaSymbolRenames.values()) {
/*  915 */       Set set = this.javaRenamedSymbols.get(str);
/*  916 */       if (null != set) {
/*  917 */         this.LOG.log(Level.INFO, "\t{0} <- {1}", new Object[] { str, set });
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Map<String, JavaCallbackInfo> setFuncToJavaCallbackMap;
/*      */ 
/*      */ 
/*      */   
/*      */   final Set<String> emittedJavaCallbackUserParamClasses;
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> V oneInMap(Map<K, V> paramMap, Set<K> paramSet) {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: aload_0
/*      */     //   2: if_acmpeq -> 72
/*      */     //   5: aload_0
/*      */     //   6: invokeinterface size : ()I
/*      */     //   11: ifle -> 72
/*      */     //   14: aconst_null
/*      */     //   15: aload_1
/*      */     //   16: if_acmpeq -> 72
/*      */     //   19: aload_1
/*      */     //   20: invokeinterface size : ()I
/*      */     //   25: ifle -> 72
/*      */     //   28: aload_1
/*      */     //   29: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   34: astore_2
/*      */     //   35: aload_2
/*      */     //   36: invokeinterface hasNext : ()Z
/*      */     //   41: ifeq -> 72
/*      */     //   44: aload_2
/*      */     //   45: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   50: astore_3
/*      */     //   51: aload_0
/*      */     //   52: aload_3
/*      */     //   53: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   58: astore #4
/*      */     //   60: aconst_null
/*      */     //   61: aload #4
/*      */     //   63: if_acmpeq -> 69
/*      */     //   66: aload #4
/*      */     //   68: areturn
/*      */     //   69: goto -> 35
/*      */     //   72: aconst_null
/*      */     //   73: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #923	-> 0
/*      */     //   #924	-> 20
/*      */     //   #925	-> 28
/*      */     //   #926	-> 51
/*      */     //   #927	-> 60
/*      */     //   #928	-> 66
/*      */     //   #930	-> 69
/*      */     //   #932	-> 72
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> boolean oneInSet(Set<K> paramSet1, Set<K> paramSet2) {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: aload_0
/*      */     //   2: if_acmpeq -> 66
/*      */     //   5: aload_0
/*      */     //   6: invokeinterface size : ()I
/*      */     //   11: ifle -> 66
/*      */     //   14: aconst_null
/*      */     //   15: aload_1
/*      */     //   16: if_acmpeq -> 66
/*      */     //   19: aload_1
/*      */     //   20: invokeinterface size : ()I
/*      */     //   25: ifle -> 66
/*      */     //   28: aload_1
/*      */     //   29: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   34: astore_2
/*      */     //   35: aload_2
/*      */     //   36: invokeinterface hasNext : ()Z
/*      */     //   41: ifeq -> 66
/*      */     //   44: aload_2
/*      */     //   45: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   50: astore_3
/*      */     //   51: aload_0
/*      */     //   52: aload_3
/*      */     //   53: invokeinterface contains : (Ljava/lang/Object;)Z
/*      */     //   58: ifeq -> 63
/*      */     //   61: iconst_1
/*      */     //   62: ireturn
/*      */     //   63: goto -> 35
/*      */     //   66: iconst_0
/*      */     //   67: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #935	-> 0
/*      */     //   #936	-> 20
/*      */     //   #937	-> 28
/*      */     //   #938	-> 51
/*      */     //   #939	-> 61
/*      */     //   #941	-> 63
/*      */     //   #943	-> 66
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean onePatternMatch(Pattern paramPattern, Set<String> paramSet) {
/*  946 */     if (null != paramPattern && null != paramSet && paramSet.size() > 0) {
/*  947 */       for (String str : paramSet) {
/*  948 */         Matcher matcher = paramPattern.matcher(str);
/*  949 */         if (matcher.matches()) {
/*  950 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*  954 */     return false;
/*      */   }
/*      */   protected static ASTLocusTag getASTLocusTag(AliasedSymbol paramAliasedSymbol) {
/*  957 */     if (paramAliasedSymbol instanceof ASTLocusTag.ASTLocusTagProvider) {
/*  958 */       return ((ASTLocusTag.ASTLocusTagProvider)paramAliasedSymbol).getASTLocusTag();
/*      */     }
/*  960 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String canonicalStructFieldSymbol(String paramString1, String paramString2) {
/*  969 */     return paramString1 + "." + paramString2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean immutableAccess(AliasedSymbol paramAliasedSymbol) {
/*  981 */     String str = paramAliasedSymbol.getName();
/*  982 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/*      */     
/*  984 */     if (this.immutableAccessSymbols.contains(str) || 
/*  985 */       oneInSet(this.immutableAccessSymbols, set)) {
/*      */ 
/*      */       
/*  988 */       this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "Immutable access: {0}", paramAliasedSymbol);
/*  989 */       return true;
/*      */     } 
/*  991 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean immutableAccess(String paramString) {
/* 1002 */     if (this.immutableAccessSymbols.contains(paramString)) {
/* 1003 */       this.LOG.log(Level.INFO, "Immutable access: {0}", paramString);
/* 1004 */       return true;
/*      */     } 
/* 1006 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean manuallyImplement(String paramString) {
/* 1015 */     if (this.manuallyImplement.contains(paramString)) {
/* 1016 */       this.LOG.log(Level.INFO, "ManuallyImplement: \"{0}\"", paramString);
/* 1017 */       return true;
/*      */     } 
/* 1019 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean manuallyImplement(AliasedSymbol paramAliasedSymbol) {
/* 1037 */     String str = paramAliasedSymbol.getName();
/* 1038 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/*      */     
/* 1040 */     if (this.manuallyImplement.contains(str) || 
/* 1041 */       oneInSet(this.manuallyImplement, set)) {
/*      */ 
/*      */       
/* 1044 */       this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "ManuallyImplement: {0}", paramAliasedSymbol);
/* 1045 */       return true;
/*      */     } 
/* 1047 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDelegatedImplementation(String paramString) {
/* 1057 */     String str = this.delegatedImplementation.get(paramString);
/* 1058 */     if (null == str) {
/* 1059 */       return null;
/*      */     }
/* 1061 */     this.LOG.log(Level.INFO, "DelegatedImplementation: {0} -> {1}", new Object[] { paramString, str });
/* 1062 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDelegatedImplementation(AliasedSymbol paramAliasedSymbol) {
/* 1085 */     String str1 = paramAliasedSymbol.getName();
/* 1086 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/*      */     
/* 1088 */     String str2 = this.delegatedImplementation.get(str1);
/* 1089 */     if (null == str2) {
/* 1090 */       str2 = oneInMap(this.delegatedImplementation, set);
/* 1091 */       if (null == str2) {
/* 1092 */         return null;
/*      */       }
/*      */     } 
/* 1095 */     this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "DelegatedImplementation: {0} -> {1}", new Object[] { paramAliasedSymbol, str2 });
/* 1096 */     return str2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getOpaqueReturnType(String paramString) {
/* 1105 */     JavaType javaType = this.returnsOpaqueJType.get(paramString);
/* 1106 */     if (null == javaType) {
/* 1107 */       return null;
/*      */     }
/* 1109 */     this.LOG.log(Level.INFO, "ReturnsOpaque: {0} -> {1}", new Object[] { paramString, javaType });
/* 1110 */     return javaType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getOpaqueReturnType(AliasedSymbol paramAliasedSymbol) {
/* 1121 */     String str = paramAliasedSymbol.getName();
/* 1122 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/* 1123 */     JavaType javaType = this.returnsOpaqueJType.get(str);
/* 1124 */     if (null == javaType) {
/* 1125 */       javaType = oneInMap(this.returnsOpaqueJType, set);
/* 1126 */       if (null == javaType) {
/* 1127 */         return null;
/*      */       }
/*      */     } 
/* 1130 */     this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "ReturnsOpaque: {0} -> {1}", new Object[] { paramAliasedSymbol, javaType });
/* 1131 */     return javaType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean shouldIgnoreInInterface(String paramString) {
/* 1140 */     return shouldIgnoreInInterface((AliasedSymbol)new AliasedSymbol.NoneAliasedSymbol(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean shouldIgnoreInInterface(AliasedSymbol paramAliasedSymbol) {
/* 1156 */     return shouldIgnoreInInterface_Int(paramAliasedSymbol);
/*      */   }
/*      */   
/*      */   protected final boolean shouldIgnoreInInterface_Int(AliasedSymbol paramAliasedSymbol) {
/* 1160 */     if (GlueGen.debug()) {
/* 1161 */       logIgnoresOnce();
/*      */     }
/* 1163 */     String str = paramAliasedSymbol.getName();
/* 1164 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/*      */ 
/*      */     
/* 1167 */     if (this.extendedIntfSymbolsIgnore.contains(str) || 
/* 1168 */       oneInSet(this.extendedIntfSymbolsIgnore, set)) {
/*      */ 
/*      */       
/* 1171 */       this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "Ignore Intf ignore (one): {0}", paramAliasedSymbol);
/* 1172 */       return true;
/*      */     } 
/*      */     
/* 1175 */     if (!this.extendedIntfSymbolsOnly.isEmpty() && 
/* 1176 */       !this.extendedIntfSymbolsOnly.contains(str) && 
/* 1177 */       !oneInSet(this.extendedIntfSymbolsOnly, set)) {
/* 1178 */       this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "Ignore Intf !extended (all): {0}", paramAliasedSymbol);
/* 1179 */       return true;
/*      */     } 
/* 1181 */     return shouldIgnoreInImpl_Int(paramAliasedSymbol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean shouldIgnoreInImpl(AliasedSymbol paramAliasedSymbol) {
/* 1198 */     return shouldIgnoreInImpl_Int(paramAliasedSymbol);
/*      */   }
/*      */   
/*      */   protected final boolean shouldIgnoreInImpl_Int(AliasedSymbol paramAliasedSymbol) {
/* 1202 */     String str = paramAliasedSymbol.getName();
/* 1203 */     Set<String> set = paramAliasedSymbol.getAliasedNames();
/*      */ 
/*      */     
/* 1206 */     if (this.extendedImplSymbolsIgnore.contains(str) || 
/* 1207 */       oneInSet(this.extendedImplSymbolsIgnore, set)) {
/*      */ 
/*      */       
/* 1210 */       this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "Ignore Impl ignore (one): {0}", paramAliasedSymbol);
/* 1211 */       return true;
/*      */     } 
/*      */     
/* 1214 */     if (!this.extendedImplSymbolsOnly.isEmpty() && 
/* 1215 */       !this.extendedImplSymbolsOnly.contains(str) && 
/* 1216 */       !oneInSet(this.extendedImplSymbolsOnly, set)) {
/* 1217 */       this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "Ignore Impl !extended (all): {0}", paramAliasedSymbol);
/* 1218 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1223 */     for (Pattern pattern : this.ignores) {
/* 1224 */       Matcher matcher = pattern.matcher(str);
/* 1225 */       if (matcher.matches() || onePatternMatch(pattern, set)) {
/* 1226 */         this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "Ignore Impl RegEx: {0}", paramAliasedSymbol);
/* 1227 */         return true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1232 */     if (this.ignoreNots.size() > 0)
/*      */     {
/*      */       
/* 1235 */       for (Pattern pattern : this.ignoreNots) {
/* 1236 */         Matcher matcher = pattern.matcher(str);
/* 1237 */         if (!matcher.matches() && !onePatternMatch(pattern, set)) {
/*      */ 
/*      */           
/* 1240 */           if (this.unignores.isEmpty()) {
/* 1241 */             this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "Ignore Impl unignores==0: {0} -> {1}", new Object[] { paramAliasedSymbol, str });
/* 1242 */             return true;
/*      */           } 
/* 1244 */           boolean bool = false;
/* 1245 */           for (Pattern pattern1 : this.unignores) {
/* 1246 */             Matcher matcher1 = pattern1.matcher(str);
/* 1247 */             if (matcher1.matches() || onePatternMatch(pattern1, set)) {
/* 1248 */               bool = true;
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/* 1253 */           if (!bool) {
/* 1254 */             this.LOG.log(Level.INFO, getASTLocusTag(paramAliasedSymbol), "Ignore Impl !unignore: {0} -> {1}", new Object[] { paramAliasedSymbol, str });
/* 1255 */             return true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/* 1260 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUnimplemented(AliasedSymbol paramAliasedSymbol) {
/* 1269 */     for (Pattern pattern : this.unimplemented) {
/* 1270 */       Matcher matcher = pattern.matcher(paramAliasedSymbol.getName());
/* 1271 */       if (matcher.matches() || onePatternMatch(pattern, paramAliasedSymbol.getAliasedNames())) {
/* 1272 */         return true;
/*      */       }
/*      */     } 
/* 1275 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getAliasedDocNames(AliasedSymbol paramAliasedSymbol) {
/* 1289 */     return paramAliasedSymbol.getAliasedNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String renameJavaType(String paramString) {
/* 1297 */     String str = this.javaTypeRenames.get(paramString);
/* 1298 */     if (str != null) {
/* 1299 */       return str;
/*      */     }
/* 1301 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getJavaSymbolRename(String paramString) {
/* 1310 */     if (this.LOG.isLoggable(Level.INFO)) {
/* 1311 */       logRenamesOnce();
/*      */     }
/* 1313 */     return this.javaSymbolRenames.get(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getRenamedJavaSymbols(String paramString) {
/* 1318 */     return this.javaRenamedSymbols.get(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addJavaSymbolRename(String paramString1, String paramString2) {
/* 1323 */     this.LOG.log(Level.INFO, "\tRename {0} -> {1}", new Object[] { paramString1, paramString2 });
/* 1324 */     String str = this.javaSymbolRenames.put(paramString1, paramString2);
/* 1325 */     if (null != str && !str.equals(paramString2)) {
/* 1326 */       throw new RuntimeException("Rename-Override Attampt: " + paramString1 + " -> " + paramString2 + ", but " + paramString1 + " -> " + str + " already exist. Run in 'debug' mode to analyze!");
/*      */     }
/*      */     
/* 1329 */     Set<String> set = this.javaRenamedSymbols.get(paramString2);
/* 1330 */     if (null == set) {
/* 1331 */       set = new HashSet();
/* 1332 */       this.javaRenamedSymbols.put(paramString2, set);
/*      */     } 
/* 1334 */     set.add(paramString1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDelegateImplementation(String paramString1, String paramString2) {
/* 1339 */     this.LOG.log(Level.INFO, "\tDelegateImplementation {0} -> {1}", new Object[] { paramString1, paramString2 });
/* 1340 */     String str = this.delegatedImplementation.put(paramString1, paramString2);
/* 1341 */     if (null != str && !str.equals(paramString2)) {
/* 1342 */       throw new RuntimeException("Rename-Override Attampt: " + paramString1 + " -> " + paramString2 + ", but " + paramString1 + " -> " + str + " already exist. Run in 'debug' mode to analyze!");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean allStatic() {
/* 1349 */     return (this.emissionStyle == JavaEmitter.EmissionStyle.AllStatic);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean emitInterface() {
/* 1354 */     return (emissionStyle() == JavaEmitter.EmissionStyle.InterfaceAndImpl || emissionStyle() == JavaEmitter.EmissionStyle.InterfaceOnly);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean emitImpl() {
/* 1359 */     return (emissionStyle() == JavaEmitter.EmissionStyle.AllStatic || emissionStyle() == JavaEmitter.EmissionStyle.InterfaceAndImpl || emissionStyle() == JavaEmitter.EmissionStyle.ImplOnly);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> javaPrologueForMethod(MethodBinding paramMethodBinding, boolean paramBoolean1, boolean paramBoolean2) {
/* 1368 */     List<String> list = this.javaPrologues.get(paramMethodBinding.getName());
/* 1369 */     if (list == null)
/*      */     {
/* 1371 */       list = this.javaPrologues.get(paramMethodBinding.getName() + paramMethodBinding.getDescriptor(paramBoolean1, paramBoolean2));
/*      */     }
/* 1373 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> javaEpilogueForMethod(MethodBinding paramMethodBinding, boolean paramBoolean1, boolean paramBoolean2) {
/* 1382 */     List<String> list = this.javaEpilogues.get(paramMethodBinding.getName());
/* 1383 */     if (list == null)
/*      */     {
/* 1385 */       list = this.javaEpilogues.get(paramMethodBinding.getName() + paramMethodBinding.getDescriptor(paramBoolean1, paramBoolean2));
/*      */     }
/* 1387 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void dispatch(String paramString1, StringTokenizer paramStringTokenizer, File paramFile, String paramString2, int paramInt) throws IOException {
/* 1396 */     if (paramString1.equalsIgnoreCase("LibraryOnLoad")) {
/* 1397 */       this.libraryOnLoadName = readString("LibraryOnLoad", paramStringTokenizer, paramString2, paramInt);
/* 1398 */     } else if (paramString1.equalsIgnoreCase("Package")) {
/* 1399 */       this.packageName = readString("Package", paramStringTokenizer, paramString2, paramInt);
/* 1400 */     } else if (paramString1.equalsIgnoreCase("GlueGenRuntimePackage")) {
/* 1401 */       this.gluegenRuntimePackage = readString("GlueGenRuntimePackage", paramStringTokenizer, paramString2, paramInt);
/* 1402 */     } else if (paramString1.equalsIgnoreCase("ImplPackage")) {
/* 1403 */       this.implPackageName = readString("ImplPackage", paramStringTokenizer, paramString2, paramInt);
/* 1404 */     } else if (paramString1.equalsIgnoreCase("JavaClass")) {
/* 1405 */       this.className = readString("JavaClass", paramStringTokenizer, paramString2, paramInt);
/* 1406 */     } else if (paramString1.equalsIgnoreCase("ImplJavaClass")) {
/* 1407 */       this.implClassName = readString("ImplJavaClass", paramStringTokenizer, paramString2, paramInt);
/* 1408 */     } else if (paramString1.equalsIgnoreCase("JavaOutputDir")) {
/* 1409 */       this.javaOutputDir = readString("JavaOutputDir", paramStringTokenizer, paramString2, paramInt);
/* 1410 */     } else if (paramString1.equalsIgnoreCase("NativeOutputDir")) {
/* 1411 */       this.nativeOutputDir = readString("NativeOutputDir", paramStringTokenizer, paramString2, paramInt);
/* 1412 */     } else if (paramString1.equalsIgnoreCase("HierarchicalNativeOutput")) {
/* 1413 */       String str = readString("HierarchicalNativeOutput", paramStringTokenizer, paramString2, paramInt);
/* 1414 */       this.nativeOutputUsesJavaHierarchy = Boolean.valueOf(str).booleanValue();
/* 1415 */     } else if (paramString1.equalsIgnoreCase("TagNativeBinding")) {
/* 1416 */       this.tagNativeBinding = readBoolean("TagNativeBinding", paramStringTokenizer, paramString2, paramInt).booleanValue();
/* 1417 */     } else if (paramString1.equalsIgnoreCase("RelaxedEqualSemanticsTest")) {
/* 1418 */       this.relaxedEqualSemanticsTest = readBoolean("RelaxedEqualSemanticsTest", paramStringTokenizer, paramString2, paramInt).booleanValue();
/* 1419 */       TypeConfig.setRelaxedEqualSemanticsTest(this.relaxedEqualSemanticsTest);
/* 1420 */     } else if (paramString1.equalsIgnoreCase("Style")) {
/*      */       try {
/* 1422 */         this.emissionStyle = JavaEmitter.EmissionStyle.valueOf(readString("Style", paramStringTokenizer, paramString2, paramInt));
/* 1423 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 1424 */         this.LOG.log(Level.WARNING, "Error parsing \"style\" command at line {0} in file \"{1}\"", new Object[] { Integer.valueOf(paramInt), paramString2 });
/*      */       } 
/* 1426 */     } else if (paramString1.equalsIgnoreCase("AccessControl")) {
/* 1427 */       readAccessControl(paramStringTokenizer, paramString2, paramInt);
/* 1428 */     } else if (paramString1.equalsIgnoreCase("Import")) {
/* 1429 */       this.imports.add(readString("Import", paramStringTokenizer, paramString2, paramInt));
/* 1430 */     } else if (paramString1.equalsIgnoreCase("Opaque")) {
/* 1431 */       readOpaque(paramStringTokenizer, paramString2, paramInt);
/* 1432 */     } else if (paramString1.equalsIgnoreCase("ReturnsString")) {
/* 1433 */       readReturnsString(paramStringTokenizer, paramString2, paramInt);
/* 1434 */     } else if (paramString1.equalsIgnoreCase("ReturnsStringOnly")) {
/* 1435 */       readReturnsStringOnly(paramStringTokenizer, paramString2, paramInt);
/* 1436 */     } else if (paramString1.equalsIgnoreCase("ReturnsOpaque")) {
/* 1437 */       readReturnsOpaque(paramStringTokenizer, paramString2, paramInt);
/* 1438 */     } else if (paramString1.equalsIgnoreCase("ReturnedArrayLength")) {
/* 1439 */       readReturnedArrayLength(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1442 */     else if (paramString1.equalsIgnoreCase("MaxOneElement")) {
/* 1443 */       readMaxOneElement(paramStringTokenizer, paramString2, paramInt);
/* 1444 */     } else if (paramString1.equalsIgnoreCase("ArgumentIsString")) {
/* 1445 */       readArgumentIsString(paramStringTokenizer, paramString2, paramInt);
/* 1446 */     } else if (paramString1.equalsIgnoreCase("ArgumentIsPascalString")) {
/* 1447 */       readArgumentIsPascalString(paramStringTokenizer, paramString2, paramInt);
/* 1448 */     } else if (paramString1.equalsIgnoreCase("JavaCallbackDef")) {
/* 1449 */       readJavaCallbackDef(paramStringTokenizer, paramString2, paramInt);
/* 1450 */     } else if (paramString1.equalsIgnoreCase("JavaCallbackKey")) {
/* 1451 */       readJavaCallbackKey(paramStringTokenizer, paramString2, paramInt);
/* 1452 */     } else if (paramString1.equalsIgnoreCase("ExtendedInterfaceSymbolsIgnore")) {
/* 1453 */       readExtendedIntfImplSymbols(paramStringTokenizer, paramString2, paramInt, true, false, false);
/* 1454 */     } else if (paramString1.equalsIgnoreCase("ExtendedInterfaceSymbolsOnly")) {
/* 1455 */       readExtendedIntfImplSymbols(paramStringTokenizer, paramString2, paramInt, true, false, true);
/* 1456 */     } else if (paramString1.equalsIgnoreCase("ExtendedImplementationSymbolsIgnore")) {
/* 1457 */       readExtendedIntfImplSymbols(paramStringTokenizer, paramString2, paramInt, false, true, false);
/* 1458 */     } else if (paramString1.equalsIgnoreCase("ExtendedImplementationSymbolsOnly")) {
/* 1459 */       readExtendedIntfImplSymbols(paramStringTokenizer, paramString2, paramInt, false, true, true);
/* 1460 */     } else if (paramString1.equalsIgnoreCase("ExtendedIntfAndImplSymbolsIgnore")) {
/* 1461 */       readExtendedIntfImplSymbols(paramStringTokenizer, paramString2, paramInt, true, true, false);
/* 1462 */     } else if (paramString1.equalsIgnoreCase("ExtendedIntfAndImplSymbolsOnly")) {
/* 1463 */       readExtendedIntfImplSymbols(paramStringTokenizer, paramString2, paramInt, true, true, true);
/* 1464 */     } else if (paramString1.equalsIgnoreCase("Ignore")) {
/* 1465 */       readIgnore(paramStringTokenizer, paramString2, paramInt);
/* 1466 */     } else if (paramString1.equalsIgnoreCase("Unignore")) {
/* 1467 */       readUnignore(paramStringTokenizer, paramString2, paramInt);
/* 1468 */     } else if (paramString1.equalsIgnoreCase("IgnoreNot")) {
/* 1469 */       readIgnoreNot(paramStringTokenizer, paramString2, paramInt);
/* 1470 */     } else if (paramString1.equalsIgnoreCase("Unimplemented")) {
/* 1471 */       readUnimplemented(paramStringTokenizer, paramString2, paramInt);
/* 1472 */     } else if (paramString1.equalsIgnoreCase("IgnoreField")) {
/* 1473 */       readIgnoreField(paramStringTokenizer, paramString2, paramInt);
/* 1474 */     } else if (paramString1.equalsIgnoreCase("ImmutableAccess")) {
/* 1475 */       readImmutableAccess(paramStringTokenizer, paramString2, paramInt);
/* 1476 */     } else if (paramString1.equalsIgnoreCase("ManuallyImplement")) {
/* 1477 */       readManuallyImplement(paramStringTokenizer, paramString2, paramInt);
/* 1478 */     } else if (paramString1.equalsIgnoreCase("CustomJavaCode")) {
/* 1479 */       readCustomJavaCode(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1482 */     else if (paramString1.equalsIgnoreCase("CustomCCode")) {
/* 1483 */       readCustomCCode(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1486 */     else if (paramString1.equalsIgnoreCase("CustomJNICode")) {
/* 1487 */       readCustomJNICode(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1490 */     else if (paramString1.equalsIgnoreCase("MethodJavadoc")) {
/* 1491 */       readMethodJavadoc(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1494 */     else if (paramString1.equalsIgnoreCase("ClassJavadoc")) {
/* 1495 */       readClassJavadoc(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1498 */     else if (paramString1.equalsIgnoreCase("NIOOnly")) {
/* 1499 */       String str = readString("NIOOnly", paramStringTokenizer, paramString2, paramInt);
/* 1500 */       if (str.equals("__ALL__")) {
/* 1501 */         this.forceUseNIOOnly4All = true;
/*      */       } else {
/* 1503 */         addUseNIOOnly(str);
/*      */       } 
/* 1505 */     } else if (paramString1.equalsIgnoreCase("NIODirectOnly")) {
/* 1506 */       String str = readString("NIODirectOnly", paramStringTokenizer, paramString2, paramInt);
/* 1507 */       if (str.equals("__ALL__")) {
/* 1508 */         this.forceUseNIODirectOnly4All = true;
/*      */       } else {
/* 1510 */         addUseNIODirectOnly(str);
/*      */       } 
/* 1512 */     } else if (paramString1.equalsIgnoreCase("EmitStruct")) {
/* 1513 */       this.forcedStructs.add(readString("EmitStruct", paramStringTokenizer, paramString2, paramInt));
/* 1514 */     } else if (paramString1.equalsIgnoreCase("StructPackage")) {
/* 1515 */       readStructPackage(paramStringTokenizer, paramString2, paramInt);
/* 1516 */     } else if (paramString1.equalsIgnoreCase("TemporaryCVariableDeclaration")) {
/* 1517 */       readTemporaryCVariableDeclaration(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1520 */     else if (paramString1.equalsIgnoreCase("TemporaryCVariableAssignment")) {
/* 1521 */       readTemporaryCVariableAssignment(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1524 */     else if (paramString1.equalsIgnoreCase("StructMachineDataInfoIndex")) {
/* 1525 */       readStructMachineDataInfoIndex(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1528 */     else if (paramString1.equalsIgnoreCase("ReturnValueCapacity")) {
/* 1529 */       readReturnValueCapacity(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1532 */     else if (paramString1.equalsIgnoreCase("ReturnValueLength")) {
/* 1533 */       readReturnValueLength(paramStringTokenizer, paramString2, paramInt);
/*      */     
/*      */     }
/* 1536 */     else if (paramString1.equalsIgnoreCase("Include")) {
/* 1537 */       doInclude(paramStringTokenizer, paramFile, paramString2, paramInt);
/* 1538 */     } else if (paramString1.equalsIgnoreCase("IncludeAs")) {
/* 1539 */       doIncludeAs(paramStringTokenizer, paramFile, paramString2, paramInt);
/* 1540 */     } else if (paramString1.equalsIgnoreCase("Extends")) {
/* 1541 */       readExtend(paramStringTokenizer, paramString2, paramInt);
/* 1542 */     } else if (paramString1.equalsIgnoreCase("Implements")) {
/* 1543 */       readImplements(paramStringTokenizer, paramString2, paramInt);
/* 1544 */     } else if (paramString1.equalsIgnoreCase("ParentClass")) {
/* 1545 */       readParentClass(paramStringTokenizer, paramString2, paramInt);
/* 1546 */     } else if (paramString1.equalsIgnoreCase("RenameJavaType")) {
/* 1547 */       readRenameJavaType(paramStringTokenizer, paramString2, paramInt);
/* 1548 */     } else if (paramString1.equalsIgnoreCase("RenameJavaSymbol")) {
/* 1549 */       readRenameJavaSymbol(paramStringTokenizer, paramString2, paramInt);
/* 1550 */     } else if (paramString1.equalsIgnoreCase("DelegateImplementation")) {
/* 1551 */       readDelegateImplementation(paramStringTokenizer, paramString2, paramInt);
/* 1552 */     } else if (paramString1.equalsIgnoreCase("RuntimeExceptionType")) {
/* 1553 */       this.runtimeExceptionType = readString("RuntimeExceptionType", paramStringTokenizer, paramString2, paramInt);
/* 1554 */     } else if (paramString1.equalsIgnoreCase("UnsupportedExceptionType")) {
/* 1555 */       this.unsupportedExceptionType = readString("UnsupportedExceptionType", paramStringTokenizer, paramString2, paramInt);
/* 1556 */     } else if (paramString1.equalsIgnoreCase("JavaPrologue")) {
/* 1557 */       readJavaPrologueOrEpilogue(paramStringTokenizer, paramString2, paramInt, true);
/*      */     
/*      */     }
/* 1560 */     else if (paramString1.equalsIgnoreCase("JavaEpilogue")) {
/* 1561 */       readJavaPrologueOrEpilogue(paramStringTokenizer, paramString2, paramInt, false);
/*      */     
/*      */     }
/* 1564 */     else if (paramString1.equalsIgnoreCase("RangeCheck")) {
/* 1565 */       readRangeCheck(paramStringTokenizer, paramString2, paramInt, false);
/*      */     
/*      */     }
/* 1568 */     else if (paramString1.equalsIgnoreCase("RangeCheckBytes")) {
/* 1569 */       readRangeCheck(paramStringTokenizer, paramString2, paramInt, true);
/*      */     }
/*      */     else {
/*      */       
/* 1573 */       throw new RuntimeException("Unknown command \"" + paramString1 + "\" in command file " + paramString2 + " at line number " + paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String readString(String paramString1, StringTokenizer paramStringTokenizer, String paramString2, int paramInt) {
/*      */     try {
/* 1581 */       return paramStringTokenizer.nextToken();
/* 1582 */     } catch (NoSuchElementException noSuchElementException) {
/* 1583 */       throw new RuntimeException("Error parsing \"" + paramString1 + "\" command at line " + paramInt + " in file \"" + paramString2 + "\": missing expected parameter", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected Boolean readBoolean(String paramString1, StringTokenizer paramStringTokenizer, String paramString2, int paramInt) {
/*      */     try {
/* 1590 */       return Boolean.valueOf(paramStringTokenizer.nextToken());
/* 1591 */     } catch (NoSuchElementException noSuchElementException) {
/* 1592 */       throw new RuntimeException("Error parsing \"" + paramString1 + "\" command at line " + paramInt + " in file \"" + paramString2 + "\": missing expected boolean value", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected Class<?> stringToPrimitiveType(String paramString) throws ClassNotFoundException {
/* 1598 */     if (paramString.equals("boolean")) return boolean.class; 
/* 1599 */     if (paramString.equals("byte")) return byte.class; 
/* 1600 */     if (paramString.equals("char")) return char.class; 
/* 1601 */     if (paramString.equals("short")) return short.class; 
/* 1602 */     if (paramString.equals("int")) return int.class; 
/* 1603 */     if (paramString.equals("long")) return long.class; 
/* 1604 */     if (paramString.equals("float")) return float.class; 
/* 1605 */     if (paramString.equals("double")) return double.class; 
/* 1606 */     throw new RuntimeException("Only primitive types are supported here");
/*      */   }
/*      */   
/*      */   protected void readAccessControl(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1611 */       String str1 = paramStringTokenizer.nextToken();
/* 1612 */       String str2 = paramStringTokenizer.nextToken();
/* 1613 */       JavaEmitter.MethodAccess methodAccess = JavaEmitter.MethodAccess.valueOf(str2.toUpperCase());
/* 1614 */       this.accessControl.put(str1, methodAccess);
/* 1615 */     } catch (Exception exception) {
/* 1616 */       throw new RuntimeException("Error parsing \"AccessControl\" command at line " + paramInt + " in file \"" + paramString + "\"", exception);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readOpaque(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1623 */       JavaType javaType = JavaType.createForOpaqueClass(stringToPrimitiveType(paramStringTokenizer.nextToken()));
/* 1624 */       String str = null;
/* 1625 */       while (paramStringTokenizer.hasMoreTokens()) {
/* 1626 */         if (str == null) {
/* 1627 */           str = paramStringTokenizer.nextToken(); continue;
/*      */         } 
/* 1629 */         str = str + " " + paramStringTokenizer.nextToken();
/*      */       } 
/*      */       
/* 1632 */       if (str == null) {
/* 1633 */         throw new RuntimeException("No C type for \"Opaque\" command at line " + paramInt + " in file \"" + paramString + "\"");
/*      */       }
/*      */       
/* 1636 */       TypeInfo typeInfo = parseTypeInfo(str, javaType);
/* 1637 */       addTypeInfo(typeInfo);
/* 1638 */     } catch (Exception exception) {
/* 1639 */       throw new RuntimeException("Error parsing \"Opaque\" command at line " + paramInt + " in file \"" + paramString + "\"", exception);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readReturnsOpaque(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1646 */       JavaType javaType = JavaType.createForOpaqueClass(stringToPrimitiveType(paramStringTokenizer.nextToken()));
/* 1647 */       String str = paramStringTokenizer.nextToken();
/* 1648 */       this.returnsOpaqueJType.put(str, javaType);
/* 1649 */     } catch (Exception exception) {
/* 1650 */       throw new RuntimeException("Error parsing \"ReturnsOpaque\" command at line " + paramInt + " in file \"" + paramString + "\"", exception);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readReturnsString(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1657 */       String str = paramStringTokenizer.nextToken();
/* 1658 */       this.returnsString.add(str);
/* 1659 */     } catch (NoSuchElementException noSuchElementException) {
/* 1660 */       throw new RuntimeException("Error parsing \"ReturnsString\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readReturnsStringOnly(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1667 */       String str = paramStringTokenizer.nextToken();
/* 1668 */       this.returnsStringOnly.add(str);
/* 1669 */     } catch (NoSuchElementException noSuchElementException) {
/* 1670 */       throw new RuntimeException("Error parsing \"ReturnsStringOnly\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readReturnedArrayLength(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1677 */       String str1 = paramStringTokenizer.nextToken();
/* 1678 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 1679 */       str2 = str2.trim();
/* 1680 */       this.returnedArrayLengths.put(str1, str2);
/* 1681 */     } catch (NoSuchElementException noSuchElementException) {
/* 1682 */       throw new RuntimeException("Error parsing \"ReturnedArrayLength\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readMaxOneElement(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1689 */       String str = paramStringTokenizer.nextToken();
/* 1690 */       this.maxOneElement.add(str);
/* 1691 */     } catch (NoSuchElementException noSuchElementException) {
/* 1692 */       throw new RuntimeException("Error parsing \"MaxOneElement\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readJavaCallbackDef(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1699 */       String str3, str4, str1 = paramStringTokenizer.nextToken();
/* 1700 */       int i = Integer.parseInt(paramStringTokenizer.nextToken());
/* 1701 */       String str2 = paramStringTokenizer.nextToken();
/* 1702 */       int j = Integer.parseInt(paramStringTokenizer.nextToken());
/*      */ 
/*      */       
/* 1705 */       if (paramStringTokenizer.hasMoreTokens()) {
/* 1706 */         String str = paramStringTokenizer.nextToken();
/* 1707 */         if (str.length() == 0 || str.equals("null")) {
/* 1708 */           str3 = null;
/*      */         } else {
/* 1710 */           str3 = str;
/*      */         } 
/* 1712 */         if (paramStringTokenizer.hasMoreTokens()) {
/* 1713 */           str4 = paramStringTokenizer.nextToken();
/*      */         } else {
/* 1715 */           str4 = null;
/*      */         } 
/*      */       } else {
/* 1718 */         str3 = null;
/* 1719 */         str4 = null;
/*      */       } 
/* 1721 */       JavaCallbackDef javaCallbackDef = new JavaCallbackDef(str2, j, str1, i, str3, str4);
/*      */       
/* 1723 */       this.javaCallbackList.add(javaCallbackDef);
/* 1724 */       this.javaCallbackSetFuncToDef.put(str1, javaCallbackDef);
/* 1725 */     } catch (NoSuchElementException noSuchElementException) {
/* 1726 */       throw new RuntimeException("Error parsing \"JavaCallbackDef\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readJavaCallbackKey(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1733 */       String str1 = paramStringTokenizer.nextToken();
/* 1734 */       JavaCallbackDef javaCallbackDef = this.javaCallbackSetFuncToDef.get(str1);
/* 1735 */       if (null == javaCallbackDef) {
/* 1736 */         throw new IllegalArgumentException("JavaCallbackDef '" + str1 + "' not (yet) defined.");
/*      */       }
/*      */ 
/*      */       
/* 1740 */       String str2 = null;
/* 1741 */       while (paramStringTokenizer.hasMoreTokens()) {
/* 1742 */         str2 = paramStringTokenizer.nextToken();
/* 1743 */         if (!isInteger(str2)) {
/*      */           break;
/*      */         }
/* 1746 */         int i = Integer.parseInt(str2);
/* 1747 */         if (0 > i) {
/* 1748 */           throw new IllegalArgumentException("JavaCallbackKey '" + str1 + "' SetCallback-ParamIndex " + i + " not in range [0..n].");
/*      */         }
/* 1750 */         javaCallbackDef.setFuncKeyIndices.add(Integer.valueOf(i));
/*      */       } 
/*      */ 
/*      */       
/* 1754 */       if (null == str2) {
/* 1755 */         throw new IllegalArgumentException("JavaCallbackKey '" + str1 + "': CallbackFuncType missing.");
/*      */       }
/* 1757 */       if (!str2.equals(javaCallbackDef.cbFuncTypeName)) {
/* 1758 */         throw new IllegalArgumentException("JavaCallbackKey '" + str1 + "': CallbackFuncType '" + str2 + "' not matching JavaCallbackDef: " + javaCallbackDef);
/*      */       }
/*      */ 
/*      */       
/* 1762 */       while (paramStringTokenizer.hasMoreTokens()) {
/* 1763 */         int i = Integer.parseInt(paramStringTokenizer.nextToken());
/* 1764 */         if (0 > i) {
/* 1765 */           throw new IllegalArgumentException("JavaCallbackKey '" + str1 + "' CallbackFunc-ParamIndex " + i + " not in range [0..n].");
/*      */         }
/* 1767 */         javaCallbackDef.cbFuncKeyIndices.add(Integer.valueOf(i));
/*      */       } 
/* 1769 */       if (javaCallbackDef.setFuncKeyIndices.size() != javaCallbackDef.cbFuncKeyIndices.size()) {
/* 1770 */         throw new IllegalArgumentException("JavaCallbackKey '" + str1 + "' SetCallback-ParamIndex list count " + javaCallbackDef.setFuncKeyIndices.toString() + " != CallbackFunc-ParamIndex count " + javaCallbackDef.cbFuncKeyIndices
/* 1771 */             .toString());
/*      */       }
/* 1773 */     } catch (NoSuchElementException noSuchElementException) {
/* 1774 */       throw new RuntimeException("Error parsing \"JavaCallbackKey\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean isInteger(String paramString) {
/*      */     try {
/* 1780 */       Integer.parseInt(paramString);
/* 1781 */       return true;
/* 1782 */     } catch (Exception exception) {
/* 1783 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void readExtendedIntfImplSymbols(StringTokenizer paramStringTokenizer, String paramString, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*      */     File file;
/*      */     BufferedReader bufferedReader;
/*      */     try {
/* 1791 */       file = new File(paramStringTokenizer.nextToken());
/* 1792 */       bufferedReader = new BufferedReader(new FileReader(file));
/* 1793 */     } catch (FileNotFoundException fileNotFoundException) {
/* 1794 */       throw new RuntimeException(fileNotFoundException);
/*      */     } 
/*      */     
/* 1797 */     JavaLexer javaLexer = new JavaLexer(bufferedReader);
/* 1798 */     javaLexer.setFilename(file.getName());
/*      */     
/* 1800 */     JavaParser javaParser = new JavaParser((TokenStream)javaLexer);
/* 1801 */     javaParser.setFilename(file.getName());
/*      */     
/*      */     try {
/* 1804 */       javaParser.compilationUnit();
/* 1805 */     } catch (Exception exception) {
/* 1806 */       throw new RuntimeException(exception);
/*      */     } 
/*      */     
/* 1809 */     Set<? extends String> set1 = javaParser.getParsedEnumNames();
/* 1810 */     Set<? extends String> set2 = javaParser.getParsedFunctionNames();
/* 1811 */     Set<? extends String> set3 = javaParser.getParsedInnerInterfacesNames();
/* 1812 */     Set<? extends String> set4 = javaParser.getParsedInnerClassesNames();
/*      */     
/* 1814 */     if (paramBoolean1) {
/* 1815 */       if (paramBoolean3) {
/* 1816 */         this.extendedIntfSymbolsOnly.addAll(set1);
/* 1817 */         this.extendedIntfSymbolsOnly.addAll(set2);
/* 1818 */         this.extendedIntfSymbolsOnly.addAll(set3);
/* 1819 */         this.extendedIntfSymbolsOnly.addAll(set4);
/*      */       } else {
/* 1821 */         this.extendedIntfSymbolsIgnore.addAll(set1);
/* 1822 */         this.extendedIntfSymbolsIgnore.addAll(set2);
/* 1823 */         this.extendedIntfSymbolsIgnore.addAll(set3);
/* 1824 */         this.extendedIntfSymbolsIgnore.addAll(set4);
/*      */       } 
/*      */     }
/* 1827 */     if (paramBoolean2) {
/* 1828 */       if (paramBoolean3) {
/* 1829 */         this.extendedImplSymbolsOnly.addAll(set1);
/* 1830 */         this.extendedImplSymbolsOnly.addAll(set2);
/* 1831 */         this.extendedImplSymbolsOnly.addAll(set3);
/* 1832 */         this.extendedImplSymbolsOnly.addAll(set4);
/*      */       } else {
/* 1834 */         this.extendedImplSymbolsIgnore.addAll(set1);
/* 1835 */         this.extendedImplSymbolsIgnore.addAll(set2);
/* 1836 */         this.extendedImplSymbolsIgnore.addAll(set3);
/* 1837 */         this.extendedImplSymbolsIgnore.addAll(set4);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   protected void readIgnore(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1844 */       String str = paramStringTokenizer.nextToken();
/* 1845 */       Pattern pattern = Pattern.compile(str);
/* 1846 */       this.ignores.add(pattern);
/* 1847 */       this.ignoreMap.put(str, pattern);
/*      */     }
/* 1849 */     catch (NoSuchElementException noSuchElementException) {
/* 1850 */       throw new RuntimeException("Error parsing \"Ignore\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readUnignore(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1857 */       String str = paramStringTokenizer.nextToken();
/* 1858 */       Pattern pattern = this.ignoreMap.get(str);
/* 1859 */       this.ignoreMap.remove(str);
/* 1860 */       this.ignores.remove(pattern);
/*      */ 
/*      */ 
/*      */       
/* 1864 */       if (pattern == null)
/* 1865 */         pattern = Pattern.compile(str); 
/* 1866 */       this.unignores.add(pattern);
/*      */     
/*      */     }
/* 1869 */     catch (NoSuchElementException noSuchElementException) {
/* 1870 */       throw new RuntimeException("Error parsing \"Unignore\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readIgnoreNot(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1877 */       String str = paramStringTokenizer.nextToken();
/* 1878 */       this.ignoreNots.add(Pattern.compile(str));
/*      */     }
/* 1880 */     catch (NoSuchElementException noSuchElementException) {
/* 1881 */       throw new RuntimeException("Error parsing \"IgnoreNot\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readUnimplemented(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1888 */       String str = paramStringTokenizer.nextToken();
/* 1889 */       this.unimplemented.add(Pattern.compile(str));
/* 1890 */     } catch (NoSuchElementException noSuchElementException) {
/* 1891 */       throw new RuntimeException("Error parsing \"Unimplemented\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readIgnoreField(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1898 */       String str1 = paramStringTokenizer.nextToken();
/* 1899 */       String str2 = paramStringTokenizer.nextToken();
/* 1900 */       this.ignores.add(Pattern.compile(str1 + "\\." + str2));
/* 1901 */     } catch (NoSuchElementException noSuchElementException) {
/* 1902 */       throw new RuntimeException("Error parsing \"IgnoreField\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readImmutableAccess(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1909 */       String str = paramStringTokenizer.nextToken();
/* 1910 */       this.immutableAccessSymbols.add(str);
/* 1911 */     } catch (NoSuchElementException noSuchElementException) {
/* 1912 */       throw new RuntimeException("Error parsing \"ImmutableAccess\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readManuallyImplement(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1919 */       String str = paramStringTokenizer.nextToken();
/* 1920 */       this.manuallyImplement.add(str);
/* 1921 */     } catch (NoSuchElementException noSuchElementException) {
/* 1922 */       throw new RuntimeException("Error parsing \"ManuallyImplement\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readCustomJavaCode(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1929 */       String str = paramStringTokenizer.nextToken();
/*      */       try {
/* 1931 */         String str1 = paramStringTokenizer.nextToken("\n\r\f");
/* 1932 */         addCustomJavaCode(str, str1);
/* 1933 */       } catch (NoSuchElementException noSuchElementException) {
/* 1934 */         addCustomJavaCode(str, "");
/*      */       } 
/* 1936 */     } catch (NoSuchElementException noSuchElementException) {
/* 1937 */       throw new RuntimeException("Error parsing \"CustomJavaCode\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void addCustomJavaCode(String paramString1, String paramString2) {
/* 1943 */     List<String> list = customJavaCodeForClass(paramString1);
/* 1944 */     list.add(paramString2);
/*      */   }
/*      */   
/*      */   protected void readCustomCCode(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1949 */       String str = paramStringTokenizer.nextToken("\n\r\f");
/* 1950 */       this.customCCode.add(str);
/* 1951 */     } catch (NoSuchElementException noSuchElementException) {
/* 1952 */       this.customCCode.add("");
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void readCustomJNICode(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1958 */       String str = paramStringTokenizer.nextToken();
/*      */       try {
/* 1960 */         String str1 = paramStringTokenizer.nextToken("\n\r\f");
/* 1961 */         addCustomJNICode(str, str1);
/* 1962 */       } catch (NoSuchElementException noSuchElementException) {
/* 1963 */         addCustomJNICode(str, "");
/*      */       } 
/* 1965 */     } catch (NoSuchElementException noSuchElementException) {
/* 1966 */       throw new RuntimeException("Error parsing \"CustomJNICode\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void addCustomJNICode(String paramString1, String paramString2) {
/* 1972 */     List<String> list = customJNICodeForClass(paramString1);
/* 1973 */     list.add(paramString2);
/*      */   }
/*      */   
/*      */   protected void readMethodJavadoc(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1978 */       String str1 = paramStringTokenizer.nextToken();
/* 1979 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 1980 */       addMethodJavadoc(str1, str2);
/* 1981 */     } catch (NoSuchElementException noSuchElementException) {
/* 1982 */       throw new RuntimeException("Error parsing \"MethodJavadoc\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void addMethodJavadoc(String paramString1, String paramString2) {
/* 1987 */     List<String> list = javadocForMethod(paramString1);
/* 1988 */     list.add(paramString2);
/*      */   }
/*      */   
/*      */   protected void readClassJavadoc(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 1993 */       String str1 = paramStringTokenizer.nextToken();
/* 1994 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 1995 */       addClassJavadoc(str1, str2);
/* 1996 */     } catch (NoSuchElementException noSuchElementException) {
/* 1997 */       throw new RuntimeException("Error parsing \"ClassJavadoc\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void addClassJavadoc(String paramString1, String paramString2) {
/* 2003 */     List<String> list = javadocForClass(paramString1);
/* 2004 */     list.add(paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readArgumentIsString(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2038 */       String str = paramStringTokenizer.nextToken();
/* 2039 */       ArrayList<Integer> arrayList = new ArrayList(2);
/* 2040 */       while (paramStringTokenizer.hasMoreTokens()) {
/* 2041 */         Integer integer = Integer.valueOf(paramStringTokenizer.nextToken());
/* 2042 */         arrayList.add(integer);
/*      */       } 
/*      */       
/* 2045 */       if (arrayList.size() > 0) {
/* 2046 */         this.argumentsAreString.put(str, arrayList);
/*      */       } else {
/* 2048 */         throw new RuntimeException("ERROR: Error parsing \"ArgumentIsString\" command at line " + paramInt + " in file \"" + paramString + "\": directive requires specification of at least 1 index");
/*      */       }
/*      */     
/* 2051 */     } catch (NoSuchElementException noSuchElementException) {
/* 2052 */       throw new RuntimeException("Error parsing \"ArgumentIsString\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readArgumentIsPascalString(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2060 */       String str = paramStringTokenizer.nextToken();
/* 2061 */       ArrayList<PascalStringIdx> arrayList = new ArrayList(2);
/* 2062 */       while (paramStringTokenizer.countTokens() >= 2) {
/* 2063 */         int i = Integer.valueOf(paramStringTokenizer.nextToken()).intValue();
/* 2064 */         int j = Integer.valueOf(paramStringTokenizer.nextToken()).intValue();
/* 2065 */         arrayList.add(new PascalStringIdx(i, j));
/*      */       } 
/* 2067 */       if (arrayList.size() > 0) {
/* 2068 */         this.argumentsArePascalString.put(str, arrayList);
/*      */       }
/* 2070 */     } catch (NoSuchElementException noSuchElementException) {
/* 2071 */       throw new RuntimeException("Error parsing \"ArgumentIsPascalString\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readStructPackage(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2079 */       String str1 = paramStringTokenizer.nextToken();
/* 2080 */       String str2 = paramStringTokenizer.nextToken();
/* 2081 */       this.structPackages.put(str1, str2);
/* 2082 */     } catch (NoSuchElementException noSuchElementException) {
/* 2083 */       throw new RuntimeException("Error parsing \"StructPackage\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readStructMachineDataInfoIndex(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2090 */       String str1 = paramStringTokenizer.nextToken();
/* 2091 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 2092 */       str2 = str2.trim();
/* 2093 */       this.structMachineDataInfoIndex.put(str1, str2);
/* 2094 */     } catch (NoSuchElementException noSuchElementException) {
/* 2095 */       throw new RuntimeException("Error parsing \"StructMachineDataInfoIndex\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readReturnValueCapacity(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2102 */       String str1 = paramStringTokenizer.nextToken();
/* 2103 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 2104 */       str2 = str2.trim();
/* 2105 */       this.returnValueCapacities.put(str1, str2);
/* 2106 */     } catch (NoSuchElementException noSuchElementException) {
/* 2107 */       throw new RuntimeException("Error parsing \"ReturnValueCapacity\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readReturnValueLength(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2114 */       String str1 = paramStringTokenizer.nextToken();
/* 2115 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 2116 */       str2 = str2.trim();
/* 2117 */       this.returnValueLengths.put(str1, str2);
/* 2118 */     } catch (NoSuchElementException noSuchElementException) {
/* 2119 */       throw new RuntimeException("Error parsing \"ReturnValueLength\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readTemporaryCVariableDeclaration(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2126 */       String str1 = paramStringTokenizer.nextToken();
/* 2127 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 2128 */       str2 = str2.trim();
/* 2129 */       List<String> list = this.temporaryCVariableDeclarations.get(str1);
/* 2130 */       if (list == null) {
/* 2131 */         list = new ArrayList();
/* 2132 */         this.temporaryCVariableDeclarations.put(str1, list);
/*      */       } 
/* 2134 */       list.add(str2);
/* 2135 */     } catch (NoSuchElementException noSuchElementException) {
/* 2136 */       throw new RuntimeException("Error parsing \"TemporaryCVariableDeclaration\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readTemporaryCVariableAssignment(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2143 */       String str1 = paramStringTokenizer.nextToken();
/* 2144 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 2145 */       str2 = str2.trim();
/* 2146 */       List<String> list = this.temporaryCVariableAssignments.get(str1);
/* 2147 */       if (list == null) {
/* 2148 */         list = new ArrayList();
/* 2149 */         this.temporaryCVariableAssignments.put(str1, list);
/*      */       } 
/* 2151 */       list.add(str2);
/* 2152 */     } catch (NoSuchElementException noSuchElementException) {
/* 2153 */       throw new RuntimeException("Error parsing \"TemporaryCVariableAssignment\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doInclude(StringTokenizer paramStringTokenizer, File paramFile, String paramString, int paramInt) throws IOException {
/*      */     try {
/* 2160 */       String str = paramStringTokenizer.nextToken();
/* 2161 */       File file = new File(str);
/* 2162 */       if (!file.isAbsolute()) {
/* 2163 */         file = new File(paramFile.getParentFile(), str);
/*      */       }
/* 2165 */       read(file.getAbsolutePath());
/* 2166 */     } catch (NoSuchElementException noSuchElementException) {
/* 2167 */       throw new RuntimeException("Error parsing \"Include\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doIncludeAs(StringTokenizer paramStringTokenizer, File paramFile, String paramString, int paramInt) throws IOException {
/*      */     try {
/* 2174 */       StringBuilder stringBuilder = new StringBuilder(128);
/* 2175 */       while (paramStringTokenizer.countTokens() > 1) {
/*      */         
/* 2177 */         stringBuilder.append(paramStringTokenizer.nextToken());
/* 2178 */         stringBuilder.append(" ");
/*      */       } 
/*      */       
/* 2181 */       String str = paramStringTokenizer.nextToken();
/* 2182 */       File file = new File(str);
/* 2183 */       if (!file.isAbsolute()) {
/* 2184 */         file = new File(paramFile.getParentFile(), str);
/*      */       }
/* 2186 */       read(file.getAbsolutePath(), stringBuilder.toString());
/* 2187 */     } catch (NoSuchElementException noSuchElementException) {
/* 2188 */       throw new RuntimeException("Error parsing \"IncludeAs\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readExtend(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2195 */       String str = paramStringTokenizer.nextToken();
/* 2196 */       List<String> list = extendedInterfaces(str);
/* 2197 */       list.add(paramStringTokenizer.nextToken());
/* 2198 */     } catch (NoSuchElementException noSuchElementException) {
/* 2199 */       throw new RuntimeException("Error parsing \"Extends\" command at line " + paramInt + " in file \"" + paramString + "\": missing expected parameter", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readImplements(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2206 */       String str = paramStringTokenizer.nextToken();
/* 2207 */       List<String> list = implementedInterfaces(str);
/* 2208 */       list.add(paramStringTokenizer.nextToken());
/* 2209 */     } catch (NoSuchElementException noSuchElementException) {
/* 2210 */       throw new RuntimeException("Error parsing \"Implements\" command at line " + paramInt + " in file \"" + paramString + "\": missing expected parameter", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readParentClass(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2217 */       String str = paramStringTokenizer.nextToken();
/* 2218 */       this.parentClass.put(str, paramStringTokenizer.nextToken());
/* 2219 */     } catch (NoSuchElementException noSuchElementException) {
/* 2220 */       throw new RuntimeException("Error parsing \"ParentClass\" command at line " + paramInt + " in file \"" + paramString + "\": missing expected parameter", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readRenameJavaType(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2227 */       String str1 = paramStringTokenizer.nextToken();
/* 2228 */       String str2 = paramStringTokenizer.nextToken();
/* 2229 */       this.javaTypeRenames.put(str1, str2);
/* 2230 */     } catch (NoSuchElementException noSuchElementException) {
/* 2231 */       throw new RuntimeException("Error parsing \"RenameJavaType\" command at line " + paramInt + " in file \"" + paramString + "\": missing expected parameter", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readRenameJavaSymbol(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2238 */       String str1 = paramStringTokenizer.nextToken();
/* 2239 */       String str2 = paramStringTokenizer.nextToken();
/* 2240 */       addJavaSymbolRename(str1, str2);
/* 2241 */     } catch (NoSuchElementException noSuchElementException) {
/* 2242 */       throw new RuntimeException("Error parsing \"RenameJavaSymbol\" command at line " + paramInt + " in file \"" + paramString + "\": missing expected parameter", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void readDelegateImplementation(StringTokenizer paramStringTokenizer, String paramString, int paramInt) {
/*      */     try {
/* 2249 */       String str1 = paramStringTokenizer.nextToken();
/* 2250 */       String str2 = paramStringTokenizer.nextToken();
/* 2251 */       addDelegateImplementation(str1, str2);
/* 2252 */     } catch (NoSuchElementException noSuchElementException) {
/* 2253 */       throw new RuntimeException("Error parsing \"DelegateImplementation\" command at line " + paramInt + " in file \"" + paramString + "\": missing expected parameter", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readJavaPrologueOrEpilogue(StringTokenizer paramStringTokenizer, String paramString, int paramInt, boolean paramBoolean) {
/*      */     try {
/* 2260 */       String str1 = paramStringTokenizer.nextToken();
/* 2261 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 2262 */       str2 = str2.trim();
/* 2263 */       if (startsWithDescriptor(str2)) {
/*      */         
/* 2265 */         int i = str2.indexOf(' ');
/* 2266 */         if (i > 0) {
/* 2267 */           String str = str2.substring(0, i);
/* 2268 */           str2 = str2.substring(i + 1, str2.length());
/* 2269 */           str1 = str1 + str;
/*      */         } 
/*      */       } 
/* 2272 */       addJavaPrologueOrEpilogue(str1, str2, paramBoolean);
/* 2273 */     } catch (NoSuchElementException noSuchElementException) {
/* 2274 */       throw new RuntimeException("Error parsing \"" + (
/* 2275 */           paramBoolean ? "JavaPrologue" : "JavaEpilogue") + "\" command at line " + paramInt + " in file \"" + paramString + "\"", noSuchElementException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addJavaPrologueOrEpilogue(String paramString1, String paramString2, boolean paramBoolean) {
/* 2282 */     Map<String, List<String>> map = paramBoolean ? this.javaPrologues : this.javaEpilogues;
/* 2283 */     List<String> list = map.get(paramString1);
/* 2284 */     if (list == null) {
/* 2285 */       list = new ArrayList();
/* 2286 */       map.put(paramString1, list);
/*      */     } 
/* 2288 */     list.add(paramString2);
/*      */   }
/*      */   
/*      */   protected void readRangeCheck(StringTokenizer paramStringTokenizer, String paramString, int paramInt, boolean paramBoolean) {
/*      */     try {
/* 2293 */       String str1 = paramStringTokenizer.nextToken();
/* 2294 */       int i = Integer.parseInt(paramStringTokenizer.nextToken());
/* 2295 */       String str2 = paramStringTokenizer.nextToken("\n\r\f");
/* 2296 */       str2 = str2.trim();
/*      */       
/* 2298 */       addJavaPrologueOrEpilogue(str1, "Buffers.rangeCheck" + (
/*      */           
/* 2300 */           paramBoolean ? "Bytes" : "") + "({" + i + "}, " + str2 + ");", true);
/*      */     
/*      */     }
/* 2303 */     catch (Exception exception) {
/* 2304 */       throw new RuntimeException("Error parsing \"RangeCheck" + (paramBoolean ? "Bytes" : "") + "\" command at line " + paramInt + " in file \"" + paramString + "\"", exception);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected static TypeInfo parseTypeInfo(String paramString, JavaType paramJavaType) {
/* 2310 */     String str = null;
/* 2311 */     byte b1 = 0;
/* 2312 */     byte b2 = 0;
/* 2313 */     while (b2 < paramString.length() && paramString
/* 2314 */       .charAt(b2) != ' ' && paramString
/* 2315 */       .charAt(b2) != '*') {
/* 2316 */       b2++;
/*      */     }
/* 2318 */     str = paramString.substring(0, b2);
/*      */     
/* 2320 */     while (b2 < paramString.length()) {
/* 2321 */       if (paramString.charAt(b2) == '*') {
/* 2322 */         b1++;
/*      */       }
/* 2324 */       b2++;
/*      */     } 
/* 2326 */     return new TypeInfo(str, b1, paramJavaType);
/*      */   }
/*      */   
/*      */   public TypeInfo addTypeInfo(String paramString, Type paramType) {
/* 2330 */     TypeInfo typeInfo = typeInfo(paramType);
/* 2331 */     if (null != typeInfo) {
/* 2332 */       TypeInfo typeInfo1 = new TypeInfo(paramString, typeInfo.pointerDepth(), typeInfo.javaType());
/* 2333 */       addTypeInfo(typeInfo1);
/* 2334 */       return typeInfo1;
/*      */     } 
/* 2336 */     return null;
/*      */   }
/*      */   
/*      */   protected void addTypeInfo(TypeInfo paramTypeInfo) {
/* 2340 */     TypeInfo typeInfo = this.typeInfoMap.get(paramTypeInfo.name());
/* 2341 */     if (typeInfo == null) {
/* 2342 */       this.typeInfoMap.put(paramTypeInfo.name(), paramTypeInfo);
/*      */       return;
/*      */     } 
/* 2345 */     while (typeInfo.next() != null) {
/* 2346 */       typeInfo = typeInfo.next();
/*      */     }
/* 2348 */     typeInfo.setNext(paramTypeInfo);
/*      */   }
/*      */   
/*      */   private static int nextIndexAfterType(String paramString, int paramInt) {
/* 2352 */     int i = paramString.length();
/* 2353 */     while (paramInt < i) {
/* 2354 */       char c = paramString.charAt(paramInt);
/*      */       
/* 2356 */       if (Character.isJavaIdentifierStart(c) || 
/* 2357 */         Character.isJavaIdentifierPart(c) || c == '/') {
/*      */         
/* 2359 */         paramInt++; continue;
/* 2360 */       }  if (c == ';') {
/* 2361 */         return paramInt + 1;
/*      */       }
/* 2363 */       return -1;
/*      */     } 
/*      */     
/* 2366 */     return -1;
/*      */   }
/*      */   
/*      */   private static int nextIndexAfterDescriptor(String paramString, int paramInt) {
/* 2370 */     char c = paramString.charAt(paramInt);
/* 2371 */     switch (c) { case 'B':
/*      */       case 'C':
/*      */       case 'D':
/*      */       case 'F':
/*      */       case 'I':
/*      */       case 'J':
/*      */       case 'S':
/*      */       case 'V':
/*      */       case 'Z':
/* 2380 */         return 1 + paramInt;
/* 2381 */       case 'L': return nextIndexAfterType(paramString, paramInt + 1);
/* 2382 */       case ')': return paramInt; }
/*      */ 
/*      */     
/* 2385 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean startsWithDescriptor(String paramString) {
/* 2392 */     int i = 0;
/* 2393 */     int j = paramString.length();
/* 2394 */     while (i < j && paramString.charAt(i) == ' ') {
/* 2395 */       i++;
/*      */     }
/*      */     
/* 2398 */     if (i >= j) return false; 
/* 2399 */     if (paramString.charAt(i++) != '(') return false; 
/* 2400 */     while (i < j) {
/* 2401 */       int m = nextIndexAfterDescriptor(paramString, i);
/* 2402 */       if (m < 0) {
/* 2403 */         return false;
/*      */       }
/* 2405 */       if (m == i) {
/*      */         break;
/*      */       }
/*      */       
/* 2409 */       i = m;
/*      */     } 
/* 2411 */     int k = nextIndexAfterDescriptor(paramString, i + 1);
/* 2412 */     if (k < 0) {
/* 2413 */       return false;
/*      */     }
/* 2415 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public static class JavaCallbackInfo
/*      */   {
/*      */     final String cbFuncTypeName;
/*      */     
/*      */     final String cbSimpleClazzName;
/*      */     
/*      */     final String cbFQClazzName;
/*      */     
/*      */     final String staticCBMethodSignature;
/*      */     
/*      */     final FunctionType cbFuncType;
/*      */     
/*      */     final MethodBinding cbFuncBinding;
/*      */     
/*      */     final List<Integer> cbFuncKeyIndices;
/*      */     
/*      */     final int cbFuncUserParamIdx;
/*      */     
/*      */     final String cbFuncUserParamName;
/*      */     
/*      */     final Type cbFuncUserParamType;
/*      */     final boolean cbUserParamIsDefined;
/*      */     final String setFuncName;
/*      */     final List<Integer> setFuncKeyIndices;
/*      */     final int setFuncUserParamIdx;
/*      */     final String userParamClassName;
/*      */     final String customKeyClassName;
/*      */     boolean setFuncProcessed;
/*      */     int setFuncCBParamIdx;
/*      */     boolean keyClassEmitted;
/*      */     
/*      */     public JavaCallbackInfo(String param1String1, String param1String2, String param1String3, String param1String4, FunctionType param1FunctionType, MethodBinding param1MethodBinding, int param1Int1, List<Integer> param1List1, String param1String5, int param1Int2, List<Integer> param1List2, String param1String6, String param1String7) {
/* 2451 */       this.cbFuncTypeName = param1String1;
/* 2452 */       this.cbSimpleClazzName = param1String2;
/* 2453 */       this.cbFQClazzName = param1String3;
/* 2454 */       this.staticCBMethodSignature = param1String4;
/* 2455 */       this.cbFuncType = param1FunctionType;
/* 2456 */       this.cbFuncBinding = param1MethodBinding;
/* 2457 */       this.cbUserParamIsDefined = (param1Int2 >= 0);
/* 2458 */       if (this.cbUserParamIsDefined) {
/* 2459 */         int i = -2;
/* 2460 */         Type type = null;
/* 2461 */         String str = null;
/* 2462 */         if (0 <= param1Int1 && param1Int1 < param1FunctionType.getNumArguments()) {
/* 2463 */           Type type1 = param1FunctionType.getArgumentType(param1Int1);
/* 2464 */           if (null != type1 && type1.isPointer()) {
/*      */             
/* 2466 */             i = param1Int1;
/* 2467 */             str = param1FunctionType.getArgumentName(param1Int1);
/* 2468 */             type = type1.getTargetType();
/*      */           } 
/*      */         } 
/* 2471 */         this.cbFuncUserParamIdx = i;
/* 2472 */         this.cbFuncUserParamName = str;
/* 2473 */         this.cbFuncUserParamType = type;
/*      */       } else {
/* 2475 */         this.cbFuncUserParamIdx = -1;
/* 2476 */         this.cbFuncUserParamName = null;
/* 2477 */         this.cbFuncUserParamType = null;
/*      */       } 
/* 2479 */       this.cbFuncKeyIndices = param1List1;
/* 2480 */       this.setFuncName = param1String5;
/* 2481 */       this.setFuncKeyIndices = param1List2;
/* 2482 */       this.setFuncUserParamIdx = param1Int2;
/* 2483 */       this.userParamClassName = param1String6;
/* 2484 */       this.customKeyClassName = param1String7;
/* 2485 */       this.setFuncProcessed = false;
/* 2486 */       this.setFuncCBParamIdx = -1;
/* 2487 */       this.keyClassEmitted = false;
/*      */     }
/*      */     private void validateKeyIndices(FunctionType param1FunctionType) {
/* 2490 */       if (this.cbFuncKeyIndices.size() != this.setFuncKeyIndices.size()) {
/* 2491 */         throw new IllegalArgumentException("JavaCallback " + this.setFuncName + ": Key count mismatch: setFunc " + this.setFuncKeyIndices.toString() + " != cbFunc " + this.cbFuncKeyIndices
/* 2492 */             .toString());
/*      */       }
/* 2494 */       for (byte b = 0; b < this.cbFuncKeyIndices.size(); b++) {
/* 2495 */         int i = ((Integer)this.cbFuncKeyIndices.get(b)).intValue();
/* 2496 */         Type type1 = this.cbFuncType.getArgumentType(i);
/* 2497 */         int j = ((Integer)this.setFuncKeyIndices.get(b)).intValue();
/* 2498 */         Type type2 = param1FunctionType.getArgumentType(j);
/* 2499 */         if (!type1.equals(type2)) {
/* 2500 */           throw new IllegalArgumentException("JavaCallback " + this.setFuncName + ": Key Type mismatch: setFunc#" + j + " with " + type2.toString() + ", cbFunc#" + i + " with " + type1.toString());
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     public void setFuncProcessed(FunctionType param1FunctionType, int param1Int) {
/* 2506 */       if (!this.setFuncProcessed) {
/* 2507 */         if (0 <= param1Int) {
/* 2508 */           this.setFuncProcessed = true;
/* 2509 */           this.setFuncCBParamIdx = param1Int;
/* 2510 */           validateKeyIndices(param1FunctionType);
/*      */         } else {
/* 2512 */           this.setFuncCBParamIdx = -1;
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2519 */       return String.format("JavaCallbackInfo[cbFunc[%s%s, userParam[defined %b, idx %d, '%s', %s, keys %s], set[%s(ok %b, cbIdx %d, upIdx %d, keys %s], Class[UserParam '%s', Key '%s'], %s]", new Object[] { this.cbFuncTypeName, this.staticCBMethodSignature, 
/*      */             
/* 2521 */             Boolean.valueOf(this.cbUserParamIsDefined), Integer.valueOf(this.cbFuncUserParamIdx), this.cbFuncUserParamName, this.cbUserParamIsDefined ? this.cbFuncUserParamType.getSignature(null).toString() : null, this.cbFuncKeyIndices.toString(), this.setFuncName, 
/* 2522 */             Boolean.valueOf(this.setFuncProcessed), Integer.valueOf(this.setFuncCBParamIdx), Integer.valueOf(this.setFuncUserParamIdx), this.setFuncKeyIndices
/* 2523 */             .toString(), this.userParamClassName, this.customKeyClassName, this.cbFuncType
/* 2524 */             .toString(this.cbFuncTypeName, false, true) });
/*      */     } }
/*      */   
/*      */   public JavaConfiguration() {
/* 2528 */     this.setFuncToJavaCallbackMap = new HashMap<>();
/* 2529 */     this.emittedJavaCallbackUserParamClasses = new HashSet<>();
/*      */     this.LOG = Logging.getLogger(JavaConfiguration.class.getPackage().getName(), JavaConfiguration.class.getSimpleName());
/*      */   }
/*      */   final boolean requiresJavaCallbackCode(String paramString) {
/* 2533 */     JavaCallbackInfo javaCallbackInfo = this.setFuncToJavaCallbackMap.get(paramString);
/* 2534 */     return (null != javaCallbackInfo);
/*      */   }
/*      */ }


/* Location:              /home/jim_bug/rvm-robot/!/com/jogamp/gluegen/JavaConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */